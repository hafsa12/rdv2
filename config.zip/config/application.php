<?php
Atexo_Config::setAppMode(Atexo_Config::APP_MODE_PERFORMANCE);
Atexo_Config::setParameter('BASE_ROOT_DIR','F:\\files\\');
Atexo_Config::setParameter('OPENSSL_TS', 'C:\\OpenSSL-Win64/bin\\openssl.exe');
Atexo_Config::setParameter('LOG_FILE_PATH', 'C:\\wamp64\\logs');
Atexo_Config::setParameter('PHP_LIB_PATH', 'C:\\wamp64\\www\\lt_rdv\\lib');
Atexo_Config::setParameter('PF_URL', 'localhost');
Atexo_Config::setParameter('DB_PREFIX', 'rdvjustice');
Atexo_Config::setParameter('DB_NAME', 'bdd01');
Atexo_Config::setParameter('PF_MAIL_FROM', 'notification@rdv.gov.ma');
Atexo_Config::setParameter('PF_SHORT_NAME', 'RDV');
Atexo_Config::setParameter('PF_LONG_NAME', 'RDV');
Atexo_Config::setParameter('HOSTSPEC', 'localhost');
Atexo_Config::setParameter('USERNAME', 'root');
Atexo_Config::setParameter('PASSWORD', '');
Atexo_Config::setParameter('LOGO_RDV', '1');
Atexo_Config::setParameter('DOMAIN_MEET', 'meetin.intelcia-solutions.com');
Atexo_Config::setParameter('RDV_OU_ACTIVE', '1');
Atexo_Config::setParameter('CLE_SERVICE_GATEWAY','7811268B16BF99000A7C737FE8763');
Atexo_Config::setParameter('PROPEL_FRAMEWORK_PATH', Atexo_Config::getParameter('PHP_LIB_PATH'). '\propel');
Atexo_Config::setParameter('PRADO_FRAMEWORK_PATH', Atexo_Config::getParameter('PHP_LIB_PATH'). '\prado\framework');
Atexo_Config::setParameter('NIVEAU_ORG_62','2');
Atexo_Config::setParameter('LANGUE_PAR_DEFAUT_ENTREPRISE','ar');
Atexo_Config::setParameter('LANGUE_PAR_DEFAUT_CITOYEN','ar');
Atexo_Config::setParameter('LANGUE_PAR_DEFAUT_AGENT','ar');
Atexo_Config::setParameter('URL_SERVICE_SMS','http://x.x.x.x:9537/api/Account/SendSMSPost');
Atexo_Config::setParameter('MODULE_SMS','1');
Atexo_Config::getParameter('MODULE_TYPE_ETAB_62' ,'1');

