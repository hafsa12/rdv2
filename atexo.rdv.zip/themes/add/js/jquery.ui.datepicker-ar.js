/* French initialisation for the jQuery UI date picker plugin. */
jQuery(function($){
    $.datepicker.regional['ma'] = {
        closeText: 'إغلاق',
        prevText: 'السابق',
        nextText: 'التالي',
        currentText: 'اليوم',
        monthNames: ['يناير','فبراير','مارس','أبريل','ماي','يونيو',
        'يوليو','غشت','سبتمبر','أكتوبر','نوفمبر','ديسمبر'],
        monthNamesShort: ['يناير','فبراير','مارس','أبريل','ماي','يونيو',
        'يوليو','غشت','سبتمبر','أكتوبر','نوفمبر','ديسمبر'],
        dayNames: ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'],
        dayNamesShort: ['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'],
        dayNamesMin: ['أحد','اثنين','ثلاثاء','أربعاء','خميس','جمعة','سبت'],
        weekHeader: 'أسبوع',
        dateFormat: 'dd/mm/yy',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''};
    $.datepicker.setDefaults($.datepicker.regional['ma']);
});
