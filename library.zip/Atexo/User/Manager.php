<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Manager extends TUserManager {
	private $_userData = array (); // Tableau pour stocker les information sur l'utilisateur

	public function validateUser($compteVo, $param)
	{
		if ($compteVo instanceof Atexo_User_CompteVo && $compteVo->getLogin() !== null && $compteVo->getPassword() !== null)
		{
			$tAgent = Atexo_Agent_Gestion::retrieveAgentByLoginAndMdp($compteVo->getLogin(), $compteVo->getPassword(), true);
				
			if ($tAgent instanceof TAgent)
			{
				$tProfil = $tAgent->getTProfil();
				if(in_array($tProfil->getIdTypeProfil(), array(Atexo_Config::getParameter('ID_PROFIL_ADMIN_ORGANISATION'), Atexo_Config::getParameter('ID_PROFIL_ADMIN_ETABLISSSEMENT'))) ) {
					if($_SESSION['idOrg'] != $tAgent->getIdOrganisationAttache()) {
						return false;
					}
				}
				$this->_userData['sess_agent_profile'] = $param;//sonar
				//Si $tAgent->TentativeMdp est inferieur a 3 MAX_TENTATIVE_MDP
				if ($tAgent->getTentativesMdp() < Atexo_Config::getParameter('MAX_TENTATIVES_MDP') && $tAgent->getTentativesMdp() != 0)
				{
					//$this->_userData['modules'] = Atexo_Module::retrieveModules();
					//Mettre à 0 les tentatives de mot de passe
					$connexion = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_WRITE'));
					$tAgent->setTentativesMdp(0);
					$tAgent->save($connexion);
				}
				$this->_userData['sess_agent_profile'] = $tAgent;
			}else{
				//Si mot passe incorrect, recuprer $tAgent by Login.
				self::erreurPassword($compteVo);
			}
		}
		return ($this->_userData!=null);
	} //fin function validateUser
	
	private function erreurPassword($compteVo) {
		$tAgent = Atexo_Agent_Gestion::retrieveAgentByLogin($compteVo->getLogin());
		if ($tAgent instanceof TAgent) {
			$tentative = $tAgent->getTentativesMdp();
			if ($tentative < Atexo_Config::getParameter('MAX_TENTATIVES_MDP')) {
				$tentative++;
				//mettre la nouvelle valeur de tentative
				$connexion = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_WRITE'));
				$tAgent->setTentativesMdp($tentative);
				$tAgent->save($connexion);
				if ($tentative == Atexo_Config::getParameter('MAX_TENTATIVES_MDP')) {
					//Envoi du mail
					switch($tAgent->getIdProfil()) {
						case "1" : $compteVo->setType("administrateur");
									break;
						case "2" : $compteVo->setType("Agent téléopérateur");
									break;
						case "3" : $compteVo->setType("Agent accueil");
									break;
					}
					Atexo_Message_UserCompte::sendAlerteDesactivationCompte($compteVo, $tAgent);
				}
			}
		}
	}

	public function getUser($username = null) {
		if ($username === null) {
			$user = new Atexo_User_UserVo($this);////debug_print_backtrace();exit;
			return $user;
		}else{
			$user = new Atexo_User_UserVo($this);
			$roles = array();
			if ($this->_userData['sess_agent_profile'])
			{
				$compte = $this->_userData['sess_agent_profile'];
				$user->setIdAgent($compte->getIdAgent());
				$user->setLogin($compte->getLogin());
				$user->setEmail($compte->getEmailUtilisateur());
				$user->setIdProfil($compte->getIdProfil());
				$user->setIdTypeProfil($compte->getTProfil()->getIdTypeProfil());
				switch($compte->getTProfil()->getIdTypeProfil()) {
					case "1" : $roles[] = "adminSys";
					break;
					case "2" : $roles[] = "adminOrg";
					break;
					case "3" : $roles[] = "adminEtab";
					break;
					case "4" : $roles[] = "agent";
					break;
					case "5" : $roles[] = "agentTeleOperateur";
					break;
					case "6" : $roles[] = "agentAccueil";
					break;
                    case "7" : $roles[] = "ressource";
                    break;
				}
				$user->setIdEtablissementAttache($compte->getIdsEtablissements());
				$user->setIdOrganisationAttache($compte->getIdOrganisationAttache());
				$user->setIdEtablissementGere($compte->getIdsEtablissements());
				$user->setIdOrganisationGere($compte->getIdOrganisationGere());
				$user->setIdPrestationAttache($compte->getIdPrestationAttache());
				if($compte->getIdOrganisationGere()>0) {
					$tOrganisationQuery = new TOrganisationQuery();
					$tOrganisation = $tOrganisationQuery->getOrganisationById($compte->getIdOrganisationGere());
					$typePrestation = $tOrganisation->getTypePrestation();
					$user->setTypePrestation($typePrestation);
				}
				else {
					$user->setTypePrestation(Atexo_Config::getParameter('PRESTATION_SAISIE_LIBRE'));
				}
				$habilitation = $compte->getTProfil();
				if ($habilitation instanceof TProfil) {
					$roles = self::addRolesGestion($habilitation, $roles);
					$roles = self::addRolesRapport($habilitation, $roles);
				}
				$user->setRoles($roles);
				$user->setIsGuest(false);
			}
			unset($this->_userData);
			return $user;
		}
		return null;
	}

	private function addRolesGestion($habilitation, $roles) {
		$roles = self::addRoles($roles, $habilitation, "Organisation", 'GestionOrganisation');
		$roles = self::addRoles($roles, $habilitation, "Etablissement", 'GestionEtablissement');
		$roles = self::addRoles($roles, $habilitation, "ReferentielPrestation", 'GestionRefPrestation');
		$roles = self::addRoles($roles, $habilitation, "ReferentielTypePrestation", 'GestionRefTypePrestation');
		$roles = self::addRoles($roles, $habilitation, "ParametragePrestation", 'GestionParamPrestation');
		$roles = self::addRoles($roles, $habilitation, "Niveau1", 'GestionTypePrstation');
		$roles = self::addRoles($roles, $habilitation, "Niveau2", 'GestionPrestation');
		$roles = self::addRoles($roles, $habilitation, "Niveau3", 'GestionRessource');
		$roles = self::addRoles($roles, $habilitation, "JoursFeries", 'GestionJoursFeries');
		$roles = self::addRoles($roles, $habilitation, "Agenda", 'GestionAgenda');
		$roles = self::addRoles($roles, $habilitation, "JoursIndisponibilites", 'GestionJoursIndisponibilites');
		$roles = self::addRoles($roles, $habilitation, "Utilisateurs", 'GestionUtilisateurs');
		$roles = self::addRoles($roles, $habilitation, "Profils", 'GestionProfils');
		$roles = self::addRoles($roles, $habilitation, "GestionsDesRendezVous", 'GestionDesRendezVous');
		$roles = self::addRoles($roles, $habilitation, "RechercheEtendueRdv", 'RechercheEtendueRdv');
		$roles = self::addRoles($roles, $habilitation, "ModifDureeRdv", 'ModifDureeRdv');
		$roles = self::addRoles($roles, $habilitation, "AffectationRdv", 'AffectationRdv');
		$roles = self::addRoles($roles, $habilitation, "AnnulationRdv", 'AnnulationRdv');
		return $roles;
	}
	
	private function addRolesRapport($habilitation, $roles) {
		$roles = self::addRoles($roles, $habilitation, "RapportNbrRdv", 'RapportNbrRdv');
		$roles = self::addRoles($roles, $habilitation, "RapportDelaiObtention", 'RapportDelaiObtention');
		$roles = self::addRoles($roles, $habilitation, "RapportActivite", 'RapportActivite');
		$roles = self::addRoles($roles, $habilitation, "PerformanceGlobale", 'PerformanceGlobale');
		return $roles;
	}
	
	private function addRoles($roles, $habilitation, $type, $nomRole) {
		$f = "get".$type;
		if($habilitation->$f()) {
			$roles[] = $nomRole;
		}
		return $roles;
	}

}