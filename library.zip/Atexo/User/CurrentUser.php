<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

Class Atexo_User_CurrentUser
{

	/** Variable utilisee pour stoquer l'acces base afin d'eviter multiples requetes */
	public static $resTmp = null;

	/**
	 * Retourne la valeur de l'�lement d'indice $indexSessionProperty dans la session. S'il n'y a pas, alors retourne false.
	 *
	 * @param $indexSessionProperty : indice de la propri�t� dans la session
	 * @return string|false
	 */

	private static function getProperty($indexSessionProperty)
	{
		if (!session_id()) {
			session_start();
		}
		if (!is_array($_SESSION)) {
			return false;
		}
		$session = array_values($_SESSION);
		$nbr = count($session);
		for($i=0;$i<$nbr;$i++) {
			$sessionTab = unserialize($session[$i]);

			if($sessionTab[0]=="CompteVo") {
				break;
			}
		}
		
		if (!is_array($sessionTab)) {
			return false;
		}
		if (!is_array($sessionTab[$indexSessionProperty]))
		{
			$property = trim($sessionTab[$indexSessionProperty]);
		}else
		{
			$property = $sessionTab[$indexSessionProperty];
		}

		if (!isset($property)) {
			return false;
		}
		return $property;
	}

	/**
	 * Retourne l'Id de l'utilisateur connect�. S'il n'y a pas , alors retourne false.
	 *
	 * @return string|false
	 */
	public static function getId()
	{
		return self::getProperty(3);
	}

	public static function getIdAgentConnected()
	{
		return self::getProperty(3);
	}

	/**
	 * Retourne les r�les de l'agent connect�. S'il n'y a pas d'agent connect�, alors retourne false.
	 *
	 * @return array|false
	 */
	private static function getRoles()
	{
		$roles = self::getProperty(1);
		if (is_array($roles))
		{
			return array_flip($roles);
		}
		return $roles;

	}

	/**
	 * verifie si l'agent connect� � l'habilitation pass�e en param�tre
	 *
	 * @param string $habilitation : habilitation � tester
	 * @return boolean true si l'agent � l'habilitation false sinon
	 */
	public static function hasHabilitation($habilitation)
	{
		$roles = self ::getRoles();
		if(isset($roles[$habilitation]) && $roles[$habilitation] > 0) {
			return true;
		} else {
			return false;
		}

	}

	/**
	 * Ajoute la valeur $data � la session, identifi�e par la cl� $key
	 *
	 * @param string $key
	 * @param mixed $data
	 */
	public static function writeToSession($key, $data, $idElement = null)
	{
		$newArray = array();
		if(isset($idElement) && $idElement !='')
		{
			$newArray[$key][$idElement] = $data;
		}
		else
		{
			self::deleteFromSession($key);
			$newArray[$key] = $data;

		}
		if (is_array($_SESSION)) {
			$_SESSION = array_merge($newArray, $_SESSION);
		}
		else {
			$_SESSION = $newArray;
		}

	}

	/**
	 * Lire de la session
	 * @param integer $key
	 * @return
	 */
	public static function readFromSession($key)
	{
		return $_SESSION[$key];
	}
	/**
	 * Supprime l'element ayant la cl� $key de la session
	 * @param integer $key la cl� de l'element
	 * @param integer $idElement la cl� du sous-element
	 */
	public static function deleteFromSession($key, $idElement = null)
	{
		if(isset($idElement) && is_integer($idElement)) {
			unset($_SESSION[$key][$idElement]);
		}
		else
		{
			unset($_SESSION[$key]);
		}
	}

	/**
	 * retourn true si l'utilisateur connecté est de type 'agent'
	 *
	 */
	public static function isAgent()
	{
		$value = self::getProperty(1);
		if ($value[0]=='agent') {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static function isAgentTeleOperateur()
	{
		$value = self::getProperty(1);
		if ($value[0]=='agentTeleOperateur') {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static function isAgentAccueil()
	{
		$value = self::getProperty(1);
		if ($value[0]=='agentAccueil') {
			return true;
		}
		else {
			return false;
		}
	}

	/**
	 * retourn true si l'utilisateur connecté est de type 'admin'
	 *
	 */
	public static function isAdmin()
	{
		$value = self::getProperty(1);
		if ($value[0]=='adminSys' || $value[0]=='adminOrg' || $value[0]=='adminEtab') {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static function isAdminSys()
	{
		$value = self::getProperty(1);
		if ($value[0]=='adminSys') {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static function isAdminOrg()
	{
		$value = self::getProperty(1);
		if ($value[0]=='adminOrg') {
			return true;
		}
		else {
			return false;
		}
	}

	public static function isAdminOrgWithEtab()
	{
		$value = self::getProperty(1);
		if ($value[0]=='adminOrg' && self::getIdEtablissementAttache()) {
            return true;
		}
        return false;
	}
	
	public static function isAdminEtab()
	{
		$value = self::getProperty(1);
		if ($value[0]=='adminEtab') {
			return true;
		}
		else {
			return false;
		}
	}
	public function isCitoyen(){
	$value=self::getProperty(1);
	if($value!=''){
		return false;
	}
	else{
		return true;
	}
}
	/**
	 * retourn true si un utilisateur est connecté
	 */
	public function isConnected()
	{
		$value = self::getProperty(1);
		if($value!='') {
			return true;
		}
		else {
			return false;
		}
	}

    public function isRessource()
    {
        $value = self::getProperty(1);
        if($value[0]=='ressource') {
            return true;
        }
        else {
            return false;
        }
    }

	/**
	 * �crit le contenu s�rialis� de la session au format attendu par
	 * mpe-1.8 dans un fichier
	 */
	public function dumpSession()
	{
		$sess = array();

		$idAgent = self::getIdAgentConnected();
		$agent = Atexo_Agent_Gestion::retrieveAgent($idAgent);
		$sess['loginAgent'] = $agent->getLogin();
		$sess['organisme'] = $agent->getOrganisme();

		$sess_string = serialize($sess);

		$id = uniqid();
		$sess_file_name =  "/tmp/mpe_3_sess_" . $id;
		Atexo_Utils_Util::write_file($sess_file_name, $sess_string);

		return $id;
	}

	public static function getIsGuest(){
		return self::getProperty(2);
	}
	public static function getIdAgent(){
		return self::getProperty(3);
	}
	public static function getLogin(){
		return self::getProperty(4);
	}
	public static function getCodeNomUtilisateur(){
		return self::getProperty(5);
	}
	public static function getCodePrenomUtilisateur(){
		return self::getProperty(6);
	}
	public static function getEmail(){
		return self::getProperty(7);
	}
	public static function getIdProfil(){
		return self::getProperty(8);
	}
	public static function getType(){
		return self::getProperty(9);
	}
	public static function getIdEtablissementAttache(){
		return self::getProperty(10);
	}
	public static function getIdOrganisationAttache(){
		return self::getProperty(11);
	}
	public static function getIdEtablissementGere(){
		return self::getProperty(12);
	}
	public static function getIdOrganisationGere(){
		return self::getProperty(13);
	}
	public static function getIdPrestationAttache(){
		return self::getProperty(14);
	}
	public static function getConnectedWith(){
		return self::getProperty(15);
	}
	public static function getIdTypeProfil(){
		return self::getProperty(16);
	}
	public static function getCurrentOrganism(){
		return false;
	}
}
