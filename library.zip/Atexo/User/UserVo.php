<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_User_UserVo extends TUser {

	private $_idAgent;
	private $_login;
	private $_codeNomUtilisateur;
	private $_codePrenomUtilisateur;
	private $_email;
	private $_idProfil;
	private $_idTypeProfil;
	private $_type;
	private $_idEtablissementAttache;
	private $_idOrganisationAttache;
	private $_idEtablissementGere;
	private $_idOrganisationGere;
	private $_idPrestationAttache;
	private $_connectedWith = '';
	private $_typePrestation;


	public function getIdAgent()
	{
		return $this->_idAgent;
	}

	public function setIdAgent($idAgent)
	{
		$this->_idAgent = $idAgent;
	}
	public function getLogin()
	{
		return $this->_login;
	}

	public function setLogin($login)
	{
		$this->_login = $login;
	}

	public function getCodeNomUtilisateur()
	{
		return $this->_codeNomUtilisateur;
	}

	public function setCodeNomUtilisateur($codeNomUtilisateur)
	{
		$this->_codeNomUtilisateur = $codeNomUtilisateur;
	}

	public function getCodePrenomUtilisateur()
	{
		return $this->_codePrenomUtilisateur;
	}

	public function setCodePrenomUtilisateur($codePrenomUtilisateur)
	{
		$this->_codePrenomUtilisateur = $codePrenomUtilisateur;
	}

	public function getCurrentOrganism() {
		//return Atexo_Config::getParameter('ID_ORGANISATION');
		return $_SESSION["idOrg"];
	}

	public function setPrenomAr($prenomAr)
	{
		$this->_prenomAr = $prenomAr;
	}

	public function getPrenomFr()
	{
		return $this->_prenomFr;
	}

	public function setPrenomFr($prenomFr)
	{
		$this->_prenomFr = $prenomFr;
	}

	public function getEmail()
	{
		return $this->_email;
	}

	public function setEmail($email)
	{
		$this->_email = $email;
	}
	public function getIdProfil()
	{
		return $this->_idProfil;
	}

	public function setIdProfil($idProfil)
	{
		$this->_idProfil = $idProfil;
	}
	public function getIdTypeProfil()
	{
		return $this->_idTypeProfil;
	}

	public function setIdTypeProfil($idTypeProfil)
	{
		$this->_idTypeProfil = $idTypeProfil;
	}
	public function getType()
	{
		return $this->_type;
	}

	public function setType($type)
	{
		$this->_type = $type;
	}
	public function getIdEtablissementAttache()
	{
		return $this->_idEtablissementAttache;
	}

	public function setIdEtablissementAttache($idEtablissement)
	{
		$this->_idEtablissementAttache = $idEtablissement;
	}

	public function getIdOrganisationAttache()
	{
		return $this->_idOrganisationAttache;
	}

	public function setIdOrganisationAttache($idOrganisation)
	{
		$this->_idOrganisationAttache = $idOrganisation;
	}

	public function getIdEtablissementGere()
	{
		return $this->_idEtablissementGere;
	}

	public function setIdEtablissementGere($value){
		$this->_idEtablissementGere = $value;
	}

	public function getIdOrganisationGere()
	{
		return $this->_idOrganisationGere;
	}

	public function setIdOrganisationGere($value){
		$this->_idOrganisationGere = $value;
	}

	public function getIdPrestationAttache()
	{
		return $this->_idPrestationAttache;
	}

	public function setIdPrestationAttache($value) {
		$this->_idPrestationAttache = $value;
	}

	public function getTypePrestation()
	{
		return $this->_typePrestation;
	}

	public function setTypePrestation($value) {
		$this->_typePrestation = $value;
	}

	/**
	 * @return String
	 * @desc permet d'avoir le compte par lequel est connect� le gestionnaire.
	 */
	public function getConnectedWith() {
		return $this->_connectedWith;
	}

	/**
	 * @return void
	 * @param String $loginOfOF
	 * @desc permet de positionner le gestionnaire sur un Organisme de formation
	 */
	public function setConnectedWith($loginOfOF) {
		$this->_connectedWith = $loginOfOF;
	}

	/**
	 * @return string user data that is serialized and will be stored in session
	 */
	public function saveToString() {
		return serialize(array ("CompteVo",
		$this->getRoles(), $this->getIsGuest(), $this->getIdAgent(), $this->getLogin(), $this->getCodeNomUtilisateur(), $this->getCodePrenomUtilisateur(), 
		$this->getEmail(), $this->getIdProfil(), $this->getType(), $this->getIdEtablissementAttache(), $this->getIdOrganisationAttache(), 
		$this->getIdEtablissementGere(), $this->getIdOrganisationGere(), $this->getIdPrestationAttache(), $this->getConnectedWith(),
				$this->getIdTypeProfil(),$this->getTypePrestation())
		);
	}

	/**
	 * @param string user data that is serialized and restored from session
	 * @return IUser the user object
	 */
	public function loadFromString($data) {
		if (!empty ($data))
		{
			$array = unserialize($data);

			$this->setRoles($array[1]);
			$this->setIsGuest($array[2]);
			$this->setIdAgent($array[3]);
			$this->setLogin($array[4]);
			$this->setCodeNomUtilisateur($array[5]);
			$this->setCodePrenomUtilisateur($array[6]);
			$this->setEmail($array[7]);
			$this->setIdProfil($array[8]);
			$this->setType($array[9]);
			$this->setIdEtablissementAttache($array[10]);
			$this->setIdOrganisationAttache($array[11]);
			$this->setIdEtablissementGere($array[12]);
			$this->setIdOrganisationGere($array[13]);
			$this->setIdPrestationAttache($array[14]);
			$this->setConnectedWith($array[15]);
			$this->setIdTypeProfil($array[16]);
			$this->setTypePrestation($array[17]);
		}
		return $this;
	}
}