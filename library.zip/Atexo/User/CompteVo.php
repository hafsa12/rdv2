<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_User_CompteVo
{
	private $login;
	private $password;
	private $idEtablissementAttache;
	private $idProfil;
	private $idOrganisationAttache;
	private $type;
	private $mail;
	private $idAgent;
	private $codeNomUtilisateur;
	private $codePrenomUtilisateur;


	public function getCodeNomUtilisateur()
	{
		return $this->codeNomUtilisateur;
	}

	public function setCodeNomUtilisateur($codeNomUtilisateur)
	{
		$this->codeNomUtilisateur = $codeNomUtilisateur;
	}

	public function getCodePrenomUtilisateur()
	{
		return $this->codePrenomUtilisateur;
	}

	public function setCodePrenomUtilisateur($codePrenomUtilisateur)
	{
		$this->codePrenomUtilisateur = $codePrenomUtilisateur;
	}

	public function getIdAgent()
	{
		return $this->idAgent;
	}

	public function setIdagent($idAgent)
	{
		$this->idAgent = $idAgent;
	}

	public function getLogin()
	{
		return $this->login;
	}

	public function setLogin($login)
	{
		$this->login = $login;
	}

	public function getPassword()
	{
		return $this->password;
	}

	public function setPassword($value)
	{
		$this->password = $value;
	}

	public function getIdEtablissementAttache()
	{
		return $this->idEtablissementAttache;
	}

	public function setIdEtablissementAttache($idEtablissement)
	{
		$this->idEtablissementAttache = $idEtablissement;
	}

	public function getIdOrganisationAttache()
	{
		return $this->idOrganisationAttache;
	}

	public function setIdOrganisationAttache($idOrganisation)
	{
		$this->idOrganisationAttache = $idOrganisation;
	}

	public function getIdProfil()
	{
		return $this->idProfil;
	}

	public function setIdProfil($idProfil)
	{
		$this->idProfil = $idProfil;
	}

	public function getType()
	{
		return $this->type;
	}

	public function setType($type)
	{
		$this->type = $type;
	}

	public function getMail()
	{
		return $this->mail;
	}

	public function setMail($mail)
	{
		$this->mail = $mail;
	}

	public function genererPassWord()
	{
		$util = new Atexo_Utils_Util();
		return $util->randomMdp(Atexo_Config::getParameter("TAILLE_PASSWORD"));
	}
}