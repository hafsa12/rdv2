<?php

class Atexo_Rest_Action_SupprimerParticipant extends Atexo_Rest_Action_Actions {

    public function post(){
        try {
            $json = file_get_contents('php://input');
            if($json==""){
                $this->getHeaders("200");
                return $this->generateXmlError('OBJET_JSON_OBLIGATOIRE',(Prado::localize('OBJET_JSON_OBLIGATOIRE')));
            }
            $validateJSON = self::isJSON($json);
            if(!$validateJSON){
                $this->getHeaders("200");
                return $this->generateXmlError('JSON_INVALIDE',(Prado::localize('JSON_INVALIDE')));
            }
            $data = json_decode($json);
            $resultatVerification = self::verifierChampsObligatoire($data);
            if(count($resultatVerification) == 0)
                $result = self::deleteParticipant($data);
            else{
                $this->getHeaders("200");
                return $this->generateXmlError('FORMAT_INCORRECT',"<champs><champ>".implode("</champ><champ>",$resultatVerification)."</champ></champs>");
            }
        }catch (Exception $e){
            $result = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
            $this->getHeaders("200");
        }
        return $result;
    }

    public function isJSON($string){
        return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
    }

    public function verifierChampsObligatoire($params) {
        $erreur = array();
        if(trim($params->idApp) ==''){
            $erreur[]= 'ID_APP_OBLIGATOIRE';
        }
        else{
            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);
            $this->idOrg = $tOrg->getIdOrganisation();
            if(!$tOrg){
                $erreur[]= 'ORGANISATION_INTROUVABLE';
            }else{
                if($params->cle != Atexo_Config::getParameter("CLE_WS_ORG_".$tOrg->getIdOrganisation())){
                    $erreur[]= 'CLE_INCORRECTE';
                }
            }
        }

        if(trim($params->cle) ==''){
            $erreur[]= 'CLE_OBLIGATOIRE';
        }

        if(trim($params->code_rdv) ==''){
            $erreur[]= 'CODE_RDV_OBLIGATOIRE';
        }

        return $erreur;
    }


    public function deleteParticipant($data)
    {
        try {
            $rdv = TRendezVousPeer::getRdvGroupeAvailableByCode($data->code_rdv);
            if($rdv){
                $connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
                $c = new Criteria();
                $c->addJoin(TParticipantPeer::ID_RENDEZ_VOUS, TRendezVousPeer::ID_RENDEZ_VOUS);
                $c->add(TRendezVousPeer::CODE_RDV, $data->code_rdv, Criteria::EQUAL);
                $c->add(TParticipantPeer::EMAIL, $data->email, Criteria::EQUAL);
                $participant = TParticipantPeer::doSelectOne($c, $connexionCom);
                if($participant){
                    $participant->delete();
                    $nbrParticipant = $rdv->getNombreParticipant();
                    if($participant->isDeleted()){
                        $rdv->setNombreParticipant($nbrParticipant - 1);
                        $rdv->save();
                        return json_encode(["status"=>"OK"]);
                    }
                    return json_encode(["status" => "KO", "message" => "Erreur est survenue lors de la suppression de cettte participation"]);
                }
                return json_encode(["status" => "KO", "message" => "Ce participant n'est pas inscrit à cette formation"]);

            }
            return json_encode(["status" => "KO", "message" => "Rendez-vous introuvable"]);

        }catch (Exception $e){
            return $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
        }
    }
}