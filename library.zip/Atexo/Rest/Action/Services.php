<?php


class Atexo_Rest_Action_Services extends Atexo_Rest_Action_Actions {

	public function post(){
		try{
			Atexo_Utils_Languages::setLanguageCatalogue('admin');
			$json = $_POST['content'];
			if($json==""){
				$this->getHeaders("200");
				return $this->generateXmlError('OBJET_JSON_OBLIGATOIRE',(Prado::localize('OBJET_JSON_OBLIGATOIRE')));
			}

			$validateJSON = self::isJSON($json);
			if(!$validateJSON){
				$this->getHeaders("200");
				return $this->generateXmlError('JSON_INVALIDE',(Prado::localize('JSON_INVALIDE')));
			}
			$params = json_decode($json);
			Atexo_Utils_Languages::setLanguageCatalogue("admin");
			$resultatVerification = self::verifierChampsObligatoire($params);
			if(count($resultatVerification) == 0){
                $xmlResult = self::saveRdv($params);
            }
			else{
				$this->getHeaders("200");
				return $this->generateXmlError('FORMAT_INCORRECT',"<champs><champ>".implode("</champ><champ>",$resultatVerification)."</champ></champs>");
			}

		}catch(Exception $e){
			$xmlResult = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
			$this->getHeaders("200");
		}

		return $xmlResult;
	}
	
	public function saveRdv($params) {
		try{
			$idApp = $params->idApp;
			$raisonSociale = $params->demandeur->raisonSociale;
			$identifiant = $params->demandeur->identifiant;
			$nom = $params->demandeur->nom;
			$prenom = $params->demandeur->prenom;
			$adresse = $params->demandeur->adresse;
			$mail = $params->demandeur->mail;
			$telephone = $params->demandeur->telephone;
			$modeRdv = $params->modeRdv;
			$codeRdv = $params->codeRdv;

            $connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
            $c = new Criteria();
            $c->add(TRendezVousPeer::CODE_RDV,$codeRdv);
            $rdv =  TRendezVousPeer::doSelectOne($c,$connexion);

            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);

            if($rdv){
                $citoyen = $rdv->getTCitoyen();
				
				if($citoyen->getNom()!="" || $citoyen->getPrenom()!="" || $citoyen->getRaisonSocial()!="" || $citoyen->getIdentifiant()!="") {
					$xmlResult = $this->generateXmlError('RDV_DEJA_AJOUR', (Prado::localize('RDV_DEJA_AJOUR')));
					$this->getHeaders("200");
					return $xmlResult;
				}
				
                $citoyen->setNom($nom);
                $citoyen->setPrenom($prenom);
                $citoyen->setAdresse($adresse);
                $citoyen->setMail($mail);
                $citoyen->setTelephone($telephone);
                $citoyen->setIdentifiant($identifiant);
                $citoyen->setRaisonSocial($raisonSociale);
                $citoyen->save();
				
				switch($modeRdv) {
					case "SURPLACE" : $mode = Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_SURPLACE");break;
					case "TELEPHONE": $mode = Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_TELEPHONE");break;
					case "INTERNET": $mode = Atexo_Config::getParameter("MODE_AGENT_INTERNET");break;
					default : $mode = Atexo_Config::getParameter("MODE_AGENT_INTERNET");break;
				}

                $rdv->setModePriseRdv($mode);
                $rdv->save();
				
				$ressource = $rdv->getTAgentRelatedByIdAgentRessource();

                if($ressource){
                    self::envoieCalEvent($ressource, $tOrg->getIdOrganisation(), $rdv);
                }

                if ($rdv->getTCitoyen()->getMail() != "") {
                    self::envoiMail($rdv);
                }
            }else{
                $xmlResult = $this->generateXmlError('RDV_INTROUVABLE', (Prado::localize('RDV_INTROUVABLE')));
                $this->getHeaders("200");
                return $xmlResult;
            }
            $code = 'OK';
			$xmlRetour = new DOMDocument( "1.0", "UTF-8" );
			$xml_code = $xmlRetour->createElement( "code", $code);
			$xmlRetour->appendChild($xml_code);

			$xmlResult = $this->encapsulerNodeResponseWs($code,$xmlRetour->saveXML(),"code");
			$this->getHeaders("200");

		}catch(Exception $e){
			$xmlResult = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
			$this->getHeaders("200");
		}

		return $xmlResult;
	}

	public function verifierChampsObligatoire($params) {

		$erreur = array();

		if(trim($params->idApp) ==''){
			$erreur[]= 'ID_APP_OBLIGATOIRE';
		}
        else{
            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);
            if(!$tOrg){
                $erreur[]= 'ORGANISATION_INTROUVABLE';
            }else{
                if($params->cle != Atexo_Config::getParameter("CLE_WS_ORG_".$tOrg->getIdOrganisation())){
                    $erreur[]= 'CLE_INCORRECTE';
                }
            }
        }

        if(trim($params->cle) ==''){
            $erreur[]= 'CLE_OBLIGATOIRE';
        }

		if(trim($params->modeRdv) ==''){
			$erreur[] = Prado::localize('MODE_PRISE_RDV_OBLIGATOIRE');
		}elseif(trim($params->modeRdv) !=''){
            $modesRdv = array("SURPLACE","TELEPHONE","INTERNET");
            if(!in_array(trim($params->modeRdv), $modesRdv)){
                $erreur[] = 'MODE_PRISE_RDV_INCORRECT';
            }
        }

		if(trim($params->codeRdv) ==''){
			$erreur[]= 'CODE_RDV_OBLIGATOIRE';
		}
		
		return $erreur;
	}

	public function isJSON($string){
		return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
	}

    private function envoieCalEvent($ressource, $idOrganisme, $rdv){
        $to_name = $ressource->getPrenomUtilisateurTraduit('fr')." ".$ressource->getNomUtilisateurTraduit('fr');
        $visio = $rdv->getTPrestation()->getVisioconference();
        $from_name = Prado::localize('MAIL_FROM');
        $subject = Prado::localize('MAIL_SUBJECT')." - ".$rdv->getTCitoyen()->getRaisonSocial();
        $from_address = Atexo_Config::getParameter('SMTP_LOGIN_'.$idOrganisme);
        $description = "
					<br><br>".Prado::localize('MAIL_HEADER').
            "<br><br>Nom du client: ".$rdv->getTCitoyen()->getPrenom()." ".$rdv->getTCitoyen()->getNom()."
			<br><br>Raison sociale: ".$rdv->getTCitoyen()->getRaisonSocial()."
			<br><br>Siren: ".$rdv->getTCitoyen()->getIdentifiant();

        if($rdv->getModePriseRdv()==Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_TELEPHONE")) {
            $description .= "<br>Nature du RDV: Rdv téléphonique";
            $location = "";
        }
        else {
            $description .= "<br>Nature du RDV: Rdv Physique";
            $location = $rdv->getTCitoyen()->getAdresse();
        }
        $description .= "<br>Date et Heure du RDV: ".$rdv->getDateRdv("d/m/Y H:i").
            "<br>N du Tel du client: ".$rdv->getTCitoyen()->getTelephone();

        if($rdv->getModePriseRdv()!=Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_TELEPHONE")) {
            $description .="<br>Adresse du lieu :".$rdv->getTCitoyen()->getAdresse();
        }
        $description .= "<br><br>Je reste à votre disposition pour tout complément d'information.
					<br><br>Cordialement.";
        $startTime = $rdv->getDateRdv("m/d/Y H:i:s");
        $endTime = $rdv->getDateFinRdv("m/d/Y H:i:s");
        $tel = $rdv->getTCitoyen()->getTelephone();
        $address = $rdv->getTCitoyen()->getAdresse();
        $cc = array();
        $to = explode(',', $ressource->getEmailUtilisateur());
        $to_address = $to[0];
        if(count($to)>1){
            array_shift($to);
            $cc = $to;
        }
        $bcc = explode(',', Atexo_Config::getParameter('BCC_MAIL_'.$idOrganisme));
        if($to_address){
            $mail = self::sendIcalEvent($from_name, $from_address, $to_name, $to_address, $cc, $bcc, $startTime, $endTime, $subject, $description, $location, $tel, $address);
        }
    }

    private function sendIcalEvent($from_name, $from_address, $to_name, $to_address, $cc, $bcc, $startTime, $endTime, $subject, $description, $location, $tel, $address='')
    {
        $domain = 'rdv.com';

        $format = 'Y-m-d H:i:s';
        $icalformat = 'Ymd\THis';

        $headers = array();

        $message = "";
        $message .= "<html>\n";
        $message .= "<body>\n";
        $message .= '<p>Bonjour '.$to_name.',</p>';
        $message .= '<p>'.$description.'.</p>';
        $message .= "</body>\n";
        $message .= "</html>\n";

        $ical = 'BEGIN:VCALENDAR' . "\r\n" .
            'PRODID:-//Microsoft Corporation//Outlook 10.0 MIMEDIR//EN' . "\r\n" .
            'VERSION:2.0' . "\r\n" .
            'METHOD:REQUEST' . "\r\n" .
            'BEGIN:VTIMEZONE' . "\r\n" .
            'TZID:Europe/Paris' . "\r\n" .
            'BEGIN:STANDARD' . "\r\n" .
            'DTSTART:20091101T020000' . "\r\n" .
            'RRULE:FREQ=YEARLY;INTERVAL=1;BYDAY=1SU;BYMONTH=11' . "\r\n" .
            'TZOFFSETFROM:+0100' . "\r\n" .
            'TZOFFSETTO:+0100' . "\r\n" .
            'TZNAME:WEST' . "\r\n" .
            'END:STANDARD' . "\r\n" .
            'BEGIN:DAYLIGHT' . "\r\n" .
            'DTSTART:20090301T020000' . "\r\n" .
            'RRULE:FREQ=YEARLY;INTERVAL=1;BYDAY=2SU;BYMONTH=3' . "\r\n" .
            'TZOFFSETFROM:+0100' . "\r\n" .
            'TZOFFSETTO:+0100' . "\r\n" .
            'TZNAME:WEST' . "\r\n" .
            'END:DAYLIGHT' . "\r\n" .
            'END:VTIMEZONE' . "\r\n" .
            'BEGIN:VEVENT' . "\r\n" .
            'ORGANIZER;CN="'.$from_name.'":MAILTO:'.$from_address. "\r\n" .
            'ATTENDEE;CN="'.$to_name.'";ROLE=REQ-PARTICIPANT;RSVP=TRUE:MAILTO:'.$to_address. "\r\n" .
            'LAST-MODIFIED:' . date("Ymd\TGis") . "\r\n" .
            'UID:'.date("Ymd\TGis", strtotime($startTime)).rand()."@".$domain."\r\n" .
            'DTSTAMP:'.date("Ymd\TGis"). "\r\n" .
            'DTSTART:'.date("Ymd\THis", strtotime($startTime)). "\r\n" .
            'DTEND:'.date("Ymd\THis", strtotime($endTime)). "\r\n" .
            'TRANSP:OPAQUE'. "\r\n" .
            'SEQUENCE:1'. "\r\n" .
            'SUMMARY:' . $subject . "\r\n" .
            'LOCATION:' . $location . "\r\n" .
            'CLASS:PUBLIC'. "\r\n" .
            'PRIORITY:5'. "\r\n" .
            'BEGIN:VALARM' . "\r\n" .
            'TRIGGER:-PT15M' . "\r\n" .
            'ACTION:DISPLAY' . "\r\n" .
            'DESCRIPTION:Reminder' . "\r\n" .
            'END:VALARM' . "\r\n" .
            'END:VEVENT'. "\r\n" .
            'END:VCALENDAR'. "\r\n";

        $mailsent = Atexo_Message::phpMail($to_address, $subject, $message, $headers, $ical, $cc, $bcc);

        return ($mailsent)?(true):(false);
    }
	
	private function envoiMail($rdv)
    {
        $lang = "fr";
        $mail = new Atexo_Utils_Mail();

        $objet = prado::localize('RECAPITULATIF_DE_VOTRE_DEMANDE_DE_RENDEZ_VOUS');

        $corpsMessage = "<b>".prado::localize('RECAPITULATIF_DE_VOTRE_DEMANDE_DE_RENDEZ_VOUS')."</b><br><br>";
        $etab = $rdv->getTEtablissement();
        $corpsMessage .= "<ul><li>".prado::localize('NOM')." : ".$rdv->getTCitoyen()->getNom()." ".$rdv->getTCitoyen()->getPrenom()."</li>";
        //$corpsMessage .= "<li>".prado::localize('IDENTIFIANT')." : ".$rdv->getTCitoyen()->getIdentifiant()."</li>";
        if($rdv->getTPrestation()->getVisioconference() == 0){
//			$corpsMessage .= "<li>".prado::localize('ETABLISSEMENT')." : ".$etab->getDenominationEtablissementTraduit($lang)."</li>";
//			$corpsMessage .= "<li>".prado::localize('ADRESSE')." : ".$etab->getAdresseEtablissementTraduit($lang)."</li>";
            $corpsMessage .= "<li>".prado::localize('TELEPHONE_POUR_PRISE_RDV')." : ".$etab->getTelephoneRdv()."</li>";
        }
        $corpsMessage .= "<li>".prado::localize('NIVEAU1')." : ".$rdv->getTPrestation()->getTTypePrestation()->getLibelleTypePrestationTraduit($lang)."</li>";
        $corpsMessage .= "<li>".prado::localize('NIVEAU2')." : ".$rdv->getTPrestation()->getLibellePrestationTraduit($lang)."</li>";

        if($rdv->getIdAgentRessource()!=null && $rdv->getIdAgentRessource()!="" && $rdv->getTPrestation()->getRessourceVisible()=="1") {
            $tAgentQuery = new TAgentQuery();
            $tAgent = $tAgentQuery->getAgentById($rdv->getIdAgentRessource());
            if($_SESSION['typeRessource']) {
                $nomRessource = $tAgent->getCodeUtilisateurTraduit($lang);
            }
            else {
                $nomRessource = $tAgent->getNomPrenomUtilisateurTraduit($lang);
            }
//			$corpsMessage .= "<li>".prado::localize('NIVEAU3')." : ".$nomRessource."</li>";
        }

        $corpsMessage .= "<li>".prado::localize('HORAIRES')." : ".Prado::localize('LE')." ".$rdv->getDateRdv("d/m/Y")." ".Prado::localize('A')." ".$rdv->getDateRdv("H:i")."</li>";
        $corpsMessage .= "<li>".prado::localize('LE_CODE_DE_CONFIRMATION')." : ".$rdv->getCodeRdv()."</li>";
        /*		if($etab->getLatitudeEtablissement() && $etab->getLongitudeEtablissement()) {
                    $corpsMessage .= "<li><a href='https://maps.google.com/maps?hl=".$lang."&amp;q=loc:".
                                     $etab->getLatitudeEtablissement().",".$etab->getLongitudeEtablissement().
                                     "&amp;z=15&amp;output=embed&amp;iwloc=near'>".prado::localize('PLAN_D_ACCES')."</a><br><br></li>";
                }
        */		$corpsMessage .= "</ul><br><br>";
        /*		$corpsMessage .= "<li>".prado::localize('MSG_VOIR_DETAIL_OU_ANNULER_RDV').' <a href="'.$this->Page->getPfUrl().
                                 '?page=citoyen.GererRendezVous'.'">'.prado::localize('CLIQUER_ICI').'</a>'."<br><br></li>";
        */
        try {
            //$mail->envoyerMail(Atexo_Config::getParameter('PF_MAIL_FROM'),$rdv->getTCitoyen()->getMail(),$objet,$corpsMessage);
        }catch (Exception $e){
            //$logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            //$logger->error($e->getMessage());
            Atexo_Utils_GestionException::catchException($e);
        }
    }
}