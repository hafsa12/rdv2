<?php

class Atexo_Rest_Action_RecapitulatifRdv extends Atexo_Rest_Action_Actions {

    public function post(){
        try {
            $json = file_get_contents('php://input');
            if($json==""){
                $this->getHeaders("200");
                return $this->generateXmlError('OBJET_JSON_OBLIGATOIRE',(Prado::localize('OBJET_JSON_OBLIGATOIRE')));
            }
            $validateJSON = self::isJSON($json);
            if(!$validateJSON){
                $this->getHeaders("200");
                return $this->generateXmlError('JSON_INVALIDE',(Prado::localize('JSON_INVALIDE')));
            }
            $data = json_decode($json);
            $resultatVerification = self::verifierChampsObligatoire($data);
            if(count($resultatVerification) == 0)
                $Result = self::retrieveRecapitulatif($data);
            else{
                $this->getHeaders("200");
                return $this->generateXmlError('FORMAT_INCORRECT',"<champs><champ>".implode("</champ><champ>",$resultatVerification)."</champ></champs>");
            }
        }catch (Exception $e){
            $Result = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
            $this->getHeaders("200");
        }
        return $Result;
    }

    public function isJSON($string){
        return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
    }

    public function verifierChampsObligatoire($params) {
        $erreur = array();
        if(trim($params->idApp) ==''){
            $erreur[]= 'ID_APP_OBLIGATOIRE';
        }
        else{
            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);
            $this->idOrg = $tOrg->getIdOrganisation();
            if(!$tOrg){
                $erreur[]= 'ORGANISATION_INTROUVABLE';
            }else{
                if($params->cle != Atexo_Config::getParameter("CLE_WS_ORG_".$tOrg->getIdOrganisation())){
                    $erreur[]= 'CLE_INCORRECTE';
                }
            }
        }

        if(trim($params->cle) ==''){
            $erreur[]= 'CLE_OBLIGATOIRE';
        }

        if(trim($params->identifiant) ==''){
            $erreur[]= 'IDENTIFIANT_OBLIGATOIRE';
        }

        if(trim($params->lang) ==''){
            $erreur[]= 'LANG_OBLIGATOIRE';
        }else {
            if(!in_array(strtolower($params->lang), ['ar','fr'])){
                $erreur[]= 'LANG_EGALE_AR_OU_FR_OBLIGATOIR';
            }
        }

        return $erreur;
    }


    public function retrieveRecapitulatif($data)
    {
        $c = new Criteria();
        $c->addJoin(TRendezVousPeer::ID_CITOYEN,TCitoyenPeer::ID_CITOYEN);
        $c->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT);
        $c->addJoin(TEtablissementPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION);
        $c->add(TCitoyenPeer::IDENTIFIANT, $data->identifiant, CRITERIA::EQUAL);
        $c->add(TOrganisationPeer::ACRONYME, $data->idApp, CRITERIA::EQUAL);
        $c->add(TRendezVousPeer::CODE_RDV, $data->code_rdv, CRITERIA::EQUAL);
        $connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
        $tRdvsObject = TRendezVousPeer::doSelect($c, $connexionCom);
        if(count($tRdvsObject)>0) {
            Atexo_User_CurrentUser::writeToSession("lang", $data->lang);
            Atexo_Utils_Languages::setLanguageCatalogue("admin");
            $rdv = $tRdvsObject[0];
            $pdf = new Atexo_GenerationPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false, false);
            $pdf->SetMargins(PDF_MARGIN_LEFT, 10, PDF_MARGIN_RIGHT);
            $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
            $pdf->SetPrintHeader(false);
            $pdf->SetPrintFooter(false);
            $direction = (strtolower($data->lang) === 'ar') ? 'rtl' : 'ltr';
            $lg = array();
            $lg['a_meta_charset'] = 'UTF-8';
            $lg['a_meta_dir'] = $direction;
            $lg['a_meta_language'] = $data->lang;
            $lg['w_page'] = 'page';
            $pdf->setLanguageArray($lg);
            $pdf->AddPage();
            $pdf->SetFont('freeserif', '', 12);
            $template_1 = file_get_contents("ressources/pages/template_1.html");
            $template_2 = file_get_contents("ressources/pages/template_2.html");
            $template_explication = file_get_contents("ressources/pages/template_explication.html");
            $template_1 = str_replace("{V_LANG}", $data->lang, $template_1);
            $template_1 = str_replace("{V_DIRECTION}", $direction, $template_1);
            $template_1 = str_replace("{CONFIRMATION_DU_RENDEZ_VOUS}", Prado::localize("CONFIRMATION_DU_RENDEZ_VOUS"), $template_1);
            $template_1 = str_replace("{VOTRE_DEMANDE_DE_RENDEZ_VOUS_A_BIEN_ETE_PRISE_EN_COMPTE}", Prado::localize("VOTRE_DEMANDE_DE_RENDEZ_VOUS_A_BIEN_ETE_PRISE_EN_COMPTE"), $template_1);
            $template_1 = str_replace("{VOTRE_CODE_DE_CONFIRMATION_EST_LE}", str_replace(':','',Prado::localize("VOTRE_CODE_DE_CONFIRMATION_EST_LE")), $template_1);
            $template_1 = str_replace("{V_CODE_RDV}", $rdv->getCodeRdv(), $template_1);
            $template_2 = str_replace("{NOM}", Prado::localize("NOM"), $template_2);
            $template_2 = str_replace("{ET}", Prado::localize("ET"), $template_2);
            $template_2 = str_replace("{PRENOM}", Prado::localize("PRENOM"), $template_2);
            $template_2 = str_replace("{V_NOM_PRENOM}", $rdv->getTCitoyen()->getNom()." ".$rdv->getTCitoyen()->getPrenom(), $template_2);
            $template_2 = str_replace("{NIVEAU1}", Prado::localize("NIVEAU1"), $template_2);
            $template_2 = str_replace("{V_TYPE_PRESTATION}", $rdv->getTPrestation()->getTTypePrestation()->getLibelleTypePrestationTraduit($data->lang), $template_2);
            $template_2 = str_replace("{NIVEAU2}", Prado::localize("NIVEAU2"), $template_2);
            $template_2 = str_replace("{V_PRESTATION}", $rdv->getTPrestation()->getLibellePrestationTraduit($data->lang, Atexo_Config::getParameter ('PRESTATION_SAISIE_LIBRE')), $template_2);
            $template_2 = str_replace("{HORAIRES}", Prado::localize("HORAIRES"), $template_2);

            $day = Prado::localize("DAY".strftime('%u', strtotime($rdv->getDateRdv())));
            $date = date('d/m/Y', strtotime($rdv->getDateRdv()));
            $time = date('H:i', strtotime($rdv->getDateRdv()));
            $template_2 = str_replace("{V_DAY_RDV}", $day, $template_2);
            $template_2 = str_replace("{V_DATE_RDV}", $date, $template_2);
            $template_2 = str_replace("{A}", Prado::localize("A"), $template_2);
            $template_2 = str_replace("{V_TIME_RDV}", $time, $template_2);
            $template_2 = str_replace("{MESSAGE_ENVOYE_CONFIRMATION_RESERVATION_EMAIL}", Prado::localize("MESSAGE_ENVOYE_CONFIRMATION_RESERVATION_EMAIL", array('ar')), $template_2);
            $template_2 = str_replace("{V_EMAIL}", $rdv->getTCitoyen()->getMail(), $template_2);
            $template_2 = str_replace("{DES_ELEMENTS_SUIVANTS}", Prado::localize("DES_ELEMENTS_SUIVANTS"), $template_2);
            $template_2 = str_replace("{LE_RECAPITULATIF_DU_RENDEZ_VOUS_RESERVE}", Prado::localize("LE_RECAPITULATIF_DU_RENDEZ_VOUS_RESERVE"), $template_2);
            $template_2 = str_replace("{LE_CODE_DE_CONFIRMATION}", Prado::localize("LE_CODE_DE_CONFIRMATION"), $template_2);
            if($rdv->getTPrestation()->getVisioconference() != 0){
                $template_details = file_get_contents("ressources/pages/template_explication.html");
                $template_details = str_replace("{MSG_CONFIRM_TELECONSULTATION_1}", Prado::localize("MSG_CONFIRM_TELECONSULTATION_1"), $template_details);
                $template_details = str_replace("{V_URL_GERER_MES_RDV}", 'http://'.$_SERVER['SERVER_NAME'].'/index.php?page=citoyen.GererRendezVous', $template_details);
                $template_details = str_replace("{GERER_MES_RENDEZ_VOUS}", Prado::localize("GERER_MES_RENDEZ_VOUS"), $template_details);
                $template_details = str_replace("{MSG_CONFIRM_TELECONSULTATION_2}", Prado::localize("MSG_CONFIRM_TELECONSULTATION_2"), $template_details);
            }else {
                $template_details = file_get_contents("ressources/pages/template_entite_rdv.html");
                $template_details = str_replace("{ETABLISSEMENT}", Prado::localize("ETABLISSEMENT"), $template_details);
                $template_details = str_replace("{V_ETABLISSEMENT}", $rdv->getTEtablissement()->getDenominationEtablissementTraduit($data->lang), $template_details);
                $template_details = str_replace("{ADRESSE}", Prado::localize("ADRESSE"), $template_details);
                $template_details = str_replace("{V_ADRESSE}", $rdv->getTEtablissement()->getAdresseCompleteEtablissement($data->lang), $template_details);
                $template_details = str_replace("{TELEPHONE_POUR_PRISE_RDV}", Prado::localize("TELEPHONE_POUR_PRISE_RDV"), $template_details);
                $template_details = str_replace("{V_TELEPHONE}", $rdv->getTEtablissement()->getTelephoneRdv(), $template_details);
            }
            $tParamForm = $rdv->getTPrestation()->getTParametreForm();
            if($tParamForm->getVisibleIdentifiant()=="1" && $rdv->getTCitoyen()->getIdentifiant()!=""){
                $identifiantTag = "<br><span>".Prado::localize("IDENTIFIANT")." : </span><b>".$rdv->getTCitoyen()->getIdentifiant()."</b><br>";
            }else{
                $identifiantTag = "";
            }
            $template = $template_1.$template_details.$identifiantTag.$template_2;
            $pdf->writeHTML($template, true, 0, true, 0);
            $file = 'recapitulatif-rdv-'.$data->lang.'-'.date('dmY-His').'.pdf';
            $this->getHeaders("200",'application/pdf', $file);
            return $pdf->Output($file, "S");

        }
        else {
            return json_encode(["statut"=>"ko", "message"=>"le rendez-vous est intouvable"]);
        }

    }

}