<?php

class Atexo_Rest_Action_ListeFormationsRestreinte extends Atexo_Rest_Action_Actions {

    public function post(){
        try {
            $json = file_get_contents('php://input');
            if($json==""){
                $this->getHeaders("200");
                return $this->generateXmlError('OBJET_JSON_OBLIGATOIRE',(Prado::localize('OBJET_JSON_OBLIGATOIRE')));
            }
            $validateJSON = self::isJSON($json);
            if(!$validateJSON){
                $this->getHeaders("200");
                return $this->generateXmlError('JSON_INVALIDE',(Prado::localize('JSON_INVALIDE')));
            }
            $data = json_decode($json);
            $resultatVerification = self::verifierChampsObligatoire($data);
            if(count($resultatVerification) == 0){
                $estParticipant = (isset($data->participant) && $data->participant === false)? false : true;
                $result = self::retrieveRdvsAsJson($data->identifiant, $data->idApp, $data->lang, $estParticipant);
            } else{
                $this->getHeaders("200");
                return $this->generateXmlError('FORMAT_INCORRECT',"<champs><champ>".implode("</champ><champ>",$resultatVerification)."</champ></champs>");
            }
        }catch (Exception $e){
            $result = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
            $this->getHeaders("200");
        }
        return $result;
    }

    public function isJSON($string){
        return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
    }

    public function verifierChampsObligatoire($params) {
        $erreur = array();
        if(trim($params->idApp) ==''){
            $erreur[]= 'ID_APP_OBLIGATOIRE';
        }
        else{
            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);
            $this->idOrg = $tOrg->getIdOrganisation();
            if(!$tOrg){
                $erreur[]= 'ORGANISATION_INTROUVABLE';
            }else{
                if($params->cle != Atexo_Config::getParameter("CLE_WS_ORG_".$tOrg->getIdOrganisation())){
                    $erreur[]= 'CLE_INCORRECTE';
                }
            }
        }

        if(trim($params->cle) ==''){
            $erreur[]= 'CLE_OBLIGATOIRE';
        }
        if(trim($params->identifiant) ==''){
            $erreur[]= 'IDENTIFIANT_OBLIGATOIRE';
        }
        if(trim($params->lang) ==''){
            $erreur[]= 'LANG_OBLIGATOIRE';
        }else {
            if(!in_array(strtolower($params->lang), ['ar','fr'])){
                $erreur[]= 'LANG_EGALE_AR_OU_FR_OBLIGATOIR';
            }
        }

        return $erreur;
    }


    public function retrieveRdvsAsJson($identifiant, $idApp, $lang, $estParticipant)
    {
        $c = new Criteria();
        $c->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT);
        $c->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION);
        $c->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN);
        $c->addJoin(TEtablissementPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION);
        $c->add(TPrestationPeer::RDV_GROUPE, Atexo_Config::getParameter('RDV_GROUPE'), Criteria::EQUAL);
        $c->add(TOrganisationPeer::ACRONYME, $idApp, Criteria::EQUAL);
        $c->add(TCitoyenPeer::IDENTIFIANT, $identifiant, Criteria::EQUAL);
        $c->add(TRendezVousPeer::NATURE_SESSION, Atexo_Config::getParameter('SESSION_INTERNE'), Criteria::EQUAL);
        $fieldEtat = [Atexo_Config::getParameter('ETAT_NON_HONORE'), Atexo_Config::getParameter('ETAT_NON_HONORE_ETAB'), Atexo_Config::getParameter('ETAT_ANNULE'), Atexo_Config::getParameter('ETAT_ANNULE_ETAB')];
        if($estParticipant){
            array_push($fieldEtat, Atexo_Config::getParameter('ETAT_EN_ATTENTE'));
        }
        $c->add(TRendezVousPeer::ETAT_RDV, $fieldEtat, Criteria::NOT_IN);
        $c->addAscendingOrderByColumn(TRendezVousPeer::DATE_RDV);

//        $c->add(TRendezVousPeer::DATE_RDV, date('Y-m-d H:i'), Criteria::GREATER_THAN);
        $connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
        $tRdvsObject = TRendezVousPeer::doSelect($c, $connexionCom);
        $dataRdv = [];
        $i = 0;
        foreach ($tRdvsObject as $rdv){
            $dataRdv[$i]['code_rdv'] = $rdv->getCodeRdv();
            $dataRdv[$i]['date_rdv'] = $rdv->getDateRdv();
            $dataRdv[$i]['type_prestation'] = $rdv->getTPrestation()->getTTypePrestation()->getLibelleTypePrestationTraduit($lang);
            $dataRdv[$i]['prestation'] = $rdv->getTPrestation()->getLibellePrestationTraduit($lang, Atexo_Config::getParameter ( 'PRESTATION_SAISIE_LIBRE' ));
            $dataRdv[$i]['etat_rdv'] = $rdv->getEtatRdv();
            $dataRdv[$i]['nombre_participant'] = $rdv->getNombreParticipant();
            $dataRdv[$i]['date_fin_rdv'] = $rdv->getDateFinRdv();
            $dataRdv[$i]['identifiant'] = $rdv->getTCitoyen()->getIdentifiant();
            $dataRdv[$i]['nature_session'] = $rdv->getNatureSession();
            $dataRdv[$i]['administrateur'] = $rdv->getTCitoyen()->getMail();
            $dataRdv[$i]['nbr_max_participant'] = $rdv->getTPrestation()->getNombreMaxParticipants();
            $participantsListe = [];
            foreach ($rdv->getTParticipants() as $TParticipant){
                $participantsListe[] = $TParticipant->getEmail();
            }
            $dataRdv[$i]['liste_mail_participants'] = $participantsListe;
            $i++;
        }
        return json_encode($dataRdv);
    }
}