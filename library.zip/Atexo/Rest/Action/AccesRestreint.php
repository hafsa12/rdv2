<?php

class Atexo_Rest_Action_AccesRestreint extends Atexo_Rest_Action_Actions {

    public function post(){
        try {
            $json = file_get_contents('php://input');
            if($json==""){
                $this->getHeaders("500");
                return $this->generateXmlError('OBJET_JSON_OBLIGATOIRE',(Prado::localize('OBJET_JSON_OBLIGATOIRE')));
            }
            $validateJSON = self::isJSON($json);
            if(!$validateJSON){
                $this->getHeaders("500");
                return $this->generateXmlError('JSON_INVALIDE',(Prado::localize('JSON_INVALIDE')));
            }
            $data = json_decode($json);
            $resultatVerification = self::verifierChampsObligatoire($data);
            if(count($resultatVerification) == 0)
                $xmlResult = self::GenerateTokenAndSaveSession($data);
            else{
                $this->getHeaders("500");
                return $this->generateXmlError('FORMAT_INCORRECT',"<champs><champ>".implode("</champ><champ>",$resultatVerification)."</champ></champs>");
            }

        }catch(Exception $e){
            $this->getHeaders("500");
            $xmlResult = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
        }
        return $xmlResult;
    }

    public function isJSON($string){
        return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
    }

    public function verifierChampsObligatoire($params) {
        $erreur = array();
        if(trim($params->idApp) ==''){
            $erreur[]= 'ID_APP_OBLIGATOIRE';
        }
        else{
            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);
            if(!$tOrg){
                $erreur[]= 'ORGANISATION_INTROUVABLE';
            }else{
                if($params->cle != Atexo_Config::getParameter("CLE_WS_ORG_".$tOrg->getIdOrganisation())){
                    $erreur[]= 'CLE_INCORRECTE';
                }
            }
        }


        if(trim($params->cle) ==''){
            $erreur[]= 'CLE_OBLIGATOIRE';
        }

        return $erreur;
    }

    public function GenerateTokenAndSaveSession($params){

        foreach ($params->content as $key => $content){
            $params->content->$key = htmlspecialchars($content);
        }
        $tOrgQ = new TOrganisationQuery();
        $time = new DateTime('now');
        $time->add(new DateInterval('PT' . 10 . 'M'));
        $dateExpiration = $time->format('Y-m-d H:i');
        $jeton = uniqid(rand(), true);
        $demandeSession = new TDemandeSession();
        $demandeSession->setIdOrganisation($tOrgQ->findOneByAcronyme($params->idApp)->getIdOrganisation());
        $demandeSession->setDateExpiration($dateExpiration);
        $demandeSession->setJson(serialize(json_encode($params->content)));
        $demandeSession->setJeton($jeton);
        $demandeSession->save();
        return json_encode(["jeton"=>$jeton]);
    }



}