<?php

class Atexo_Rest_Action_Ressource extends Atexo_Rest_Action_Actions {

    public function post(){
        try{
            Atexo_Utils_Languages::setLanguageCatalogue('admin');
            $json = $_POST['content'];
            if($json==""){
                $this->getHeaders("200");
                return $this->generateXmlError('OBJET_JSON_OBLIGATOIRE',(Prado::localize('OBJET_JSON_OBLIGATOIRE')));
            }

            $validateJSON = self::isJSON($json);
            if(!$validateJSON){
                $this->getHeaders("200");
                return $this->generateXmlError('JSON_INVALIDE',(Prado::localize('JSON_INVALIDE')));
            }
            $params = json_decode($json);
            Atexo_Utils_Languages::setLanguageCatalogue("admin");
            $resultatVerification = self::verifierChampsObligatoire($params);
            if(count($resultatVerification) == 0)
                $xmlResult = self::checkIfRessourceExistAndSave($params);
            else{
                $this->getHeaders("200");
                return $this->generateXmlError('FORMAT_INCORRECT',"<champs><champ>".implode("</champ><champ>",$resultatVerification)."</champ></champs>");
            }

        }catch(Exception $e){
            $xmlResult = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
            $this->getHeaders("200");
        }

        return $xmlResult;
    }

    public function checkIfRessourceExistAndSave($params){
        $tAgentQ  = new TAgentQuery();
        $ressource = $tAgentQ->findOneByEmailUtilisateur($params->mail);
        if($ressource){
            $xmlResult = $this->generateXmlError('RESSOURCE_EXIST', (Prado::localize('RESSOURCE_EXIST')));
            $this->getHeaders("200");
            return $xmlResult;
        }else{
            $xmlResult = self::saveRessource($params);
            return $xmlResult;
        }
    }

    public function saveRessource($params) {
        try{
            $idApp = $params->idApp;
            $nom = $params->nom;
            $prenom = $params->prenom;
            $email = $params->mail;
            $horaire = $params->horaire;

            $tAgent = new TAgent();
            $tTraductionNom = new TTraduction();
            $tTraductionPrenom = new TTraduction();

            $tAgent->setTentativesMdp("0");

            $tTraductionLibelle = new TTraductionLibelle();
            $tTraductionLibelle->setLang('fr');
            $tTraductionLibelle->setLibelle(strtoupper($nom));
            $tTraductionNom->addTTraductionLibelle($tTraductionLibelle);

            $tTraductionLibelle = new TTraductionLibelle();
            $tTraductionLibelle->setLang('ar');
            $tTraductionLibelle->setLibelle(strtoupper($nom));
            $tTraductionNom->addTTraductionLibelle($tTraductionLibelle);

            $tTraductionLibelle = new TTraductionLibelle();
            $tTraductionLibelle->setLang('fr');
            $tTraductionLibelle->setLibelle(ucfirst($prenom));
            $tTraductionPrenom->addTTraductionLibelle($tTraductionLibelle);

            $tTraductionLibelle = new TTraductionLibelle();
            $tTraductionLibelle->setLang('ar');
            $tTraductionLibelle->setLibelle(ucfirst($prenom));
            $tTraductionPrenom->addTTraductionLibelle($tTraductionLibelle);

            $tAgent->setTTraductionRelatedByCodeNomUtilisateur($tTraductionNom);
            $tAgent->setTTraductionRelatedByCodePrenomUtilisateur($tTraductionPrenom);
            $tAgent->setEmailUtilisateur($email);
            $tAgent->setTelephoneUtilisateur('');

            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($idApp);

            $tAgent->setIdOrganisationAttache($tOrg->getIdOrganisation());

            $connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
            $c = new Criteria();
            $c->add(TProfilPeer::ID_TYPE_PROFIL,7);
            $c->add(TProfilPeer::ID_ORGANISATION,$tOrg->getIdOrganisation());
            $profil =  TProfilPeer::doSelectOne($c,$connexion);

            $tAgent->setIdProfil($profil->getIdProfil());
            $tAgent->setActif(1);

            $tAgent->save();
            $creationAgenda = self::majRessource($tAgent->getIdAgent(), $tOrg->getIdOrganisation(), $horaire);
            if(!$creationAgenda){
                $xmlResult = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE')));
                $this->getHeaders("200");
            }

            $code = 'OK';
            $xmlRetour = new DOMDocument( "1.0", "UTF-8" );
            $xml_code = $xmlRetour->createElement( "code", $code);
            $xmlRetour->appendChild($xml_code);

            $xmlResult = $this->encapsulerNodeResponseWs($code,$xmlRetour->saveXML(),"code");
            $this->getHeaders("200");

        }catch(Exception $e){
            $xmlResult = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
            $this->getHeaders("200");
        }

        return $xmlResult;
    }

    public function verifierChampsObligatoire($params) {

        $erreur = array();

        if(trim($params->idApp) ==''){
            $erreur[]= 'ID_APP_OBLIGATOIRE';
        }
        else{
            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);
            if(!$tOrg){
                $erreur[]= 'ORGANISATION_INTROUVABLE';
            }else{
                if($params->cle != Atexo_Config::getParameter("CLE_WS_ORG_".$tOrg->getIdOrganisation())){
                    $erreur[]= 'CLE_INCORRECTE';
                }
            }
        }

        if(trim($params->cle) ==''){
            $erreur[]= 'CLE_OBLIGATOIRE';
        }

        if(trim($params->mail) ==''){
            $erreur[]= 'MAIL_RESSOURCE_OBLIGATOIRE';
        }else{
            if(!filter_var(trim($params->mail), FILTER_VALIDATE_EMAIL)) {
                $erreur[]= 'MAIL_RESSOURCE_INVALIDE';
            }
        }

        if(trim($params->nom) ==''){
            $erreur[]= 'NOM_RESSOURCE_OBLIGATOIRE';
        }

        if(trim($params->prenom) ==''){
            $erreur[]= 'PRENOM_RESSOURCE_OBLIGATOIRE';
        }
        return $erreur;
    }

    public function isJSON($string){
        return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
    }

    private static function majRessource($idRessource, $idOrg, $horaire) {
        $tEtabQ = new TEtablissementQuery();
        $tEtab = $tEtabQ->findOneByIdOrganisation($idOrg);
        if(!$tEtab){
            return false;
        }
        $prestaQuery = new TPrestationQuery();
        $prestations = $prestaQuery->getPrestationByCriteres(null,null,$tEtab->getIdEtablissement());
        if(count($prestations)){
            $prestation = $prestations[0];
        }else{
            return false;
        }

        $arrayHoraire = array(
            "lundiMatinDebut" => $horaire->lundiMatinDebut,
            "mardiMatinDebut" => $horaire->mardiMatinDebut,
            "mercrediMatinDebut" => $horaire->mercrediMatinDebut,
            "jeudiMatinDebut" => $horaire->jeudiMatinDebut,
            "vendrediMatinDebut" => $horaire->vendrediMatinDebut,
            "samediMatinDebut" => $horaire->samediMatinDebut,
            "dimancheMatinDebut" => $horaire->dimancheMatinDebut,

            "lundiMatinFin" => $horaire->lundiMatinFin,
            "mardiMatinFin" => $horaire->mardiMatinFin,
            "mercrediMatinFin" => $horaire->mercrediMatinFin,
            "jeudiMatinFin" => $horaire->jeudiMatinFin,
            "vendrediMatinFin" => $horaire->vendrediMatinFin,
            "samediMatinFin" => $horaire->samediMatinFin,
            "dimancheMatinFin" => $horaire->dimancheMatinFin,

            "lundiApresmidiDebut" => $horaire->lundiApresmidiDebut,
            "mardiApresmidiDebut" => $horaire->mardiApresmidiDebut,
            "mercrediApresmidiDebut" => $horaire->mercrediApresmidiDebut,
            "jeudiApresmidiDebut" => $horaire->jeudiApresmidiDebut,
            "vendrediApresmidiDebut" => $horaire->vendrediApresmidiDebut,
            "samediApresmidiDebut" => $horaire->samediApresmidiDebut,
            "dimancheApresmidiDebut" => $horaire->dimancheApresmidiDebut,

            "lundiApresmidiFin" => $horaire->lundiApresmidiFin,
            "mardiApresmidiFin" => $horaire->mardiApresmidiFin,
            "mercrediApresmidiFin" => $horaire->mercrediApresmidiFin,
            "jeudiApresmidiFin" => $horaire->jeudiApresmidiFin,
            "vendrediApresmidiFin" => $horaire->vendrediApresmidiFin,
            "samediApresmidiFin" => $horaire->samediApresmidiFin,
            "dimancheApresmidiFin" => $horaire->dimancheApresmidiFin
        );

        foreach($arrayHoraire as $value){
            if(is_string($value)){
                $match = preg_match('#^([01]?[0-9]|2[0-3]):[0-5][0-9]?$#', $value);
                if(!$match){
                    return false;
                }
            }
        }
            try{
                $agenda = new TAgenda();
                $agenda->setIdPrestation($prestation->getIdPrestation());
                $agenda->setIdAgent($idRessource);
                $agenda->save();
                $tPeriodes = $agenda->getTPeriodes();
                if(count($tPeriodes)>0) {
                    $tperiode = $tPeriodes->getData()[0];
                }
                else {
                    $tperiode = new TPeriode();
                    $tperiode->setIdAgenda($agenda->getIdAgenda());
                }

                $tperiode->setDebutPeriode(date("Y-m-d"));
                $tperiode->setFinPeriode("2100-01-01");
                $tperiode->setPeriodicite($prestation->getPeriodicite());
				
				if($arrayHoraire["lundiMatinDebut"]!="" && $arrayHoraire["lundiMatinFin"]!="") {

					$cap1 = self::getCapacite($arrayHoraire["lundiMatinDebut"],$arrayHoraire["lundiMatinFin"],$prestation->getPeriodicite());
				
					$tperiode->setLundiHeureDebut1($arrayHoraire["lundiMatinDebut"]);
					$tperiode->setLundiHeureFin1($arrayHoraire["lundiMatinFin"]);
					$tperiode->setLundiCapacite1($cap1);
					$tperiode->setLundiNbRdvSite1(0);
				}
				
                if($arrayHoraire["lundiApresmidiDebut"]!="" && $arrayHoraire["lundiApresmidiFin"]!="") {

					$cap2 = self::getCapacite($arrayHoraire["lundiApresmidiDebut"],$arrayHoraire["lundiApresmidiFin"],$prestation->getPeriodicite());
				
					$tperiode->setLundiHeureDebut2($arrayHoraire["lundiApresmidiDebut"]);
					$tperiode->setLundiHeureFin2($arrayHoraire["lundiApresmidiFin"]);
					$tperiode->setLundiCapacite2($cap2);
					$tperiode->setLundiNbRdvSite2(0);
				}
				
                if($arrayHoraire["mardiMatinDebut"]!="" && $arrayHoraire["mardiMatinFin"]!="") {

                    $cap1 = self::getCapacite($arrayHoraire["mardiMatinDebut"],$arrayHoraire["mardiMatinFin"],$prestation->getPeriodicite());
                
                    $tperiode->setMardiHeureDebut1($arrayHoraire["mardiMatinDebut"]);
                    $tperiode->setMardiHeureFin1($arrayHoraire["mardiMatinFin"]);
                    $tperiode->setMardiCapacite1($cap1);
                    $tperiode->setMardiNbRdvSite1(0);
                }
                
                if($arrayHoraire["mardiApresmidiDebut"]!="" && $arrayHoraire["mardiApresmidiFin"]!="") {

                    $cap2 = self::getCapacite($arrayHoraire["mardiApresmidiDebut"],$arrayHoraire["mardiApresmidiFin"],$prestation->getPeriodicite());
                
                    $tperiode->setMardiHeureDebut2($arrayHoraire["mardiApresmidiDebut"]);
                    $tperiode->setMardiHeureFin2($arrayHoraire["mardiApresmidiFin"]);
                    $tperiode->setMardiCapacite2($cap2);
                    $tperiode->setMardiNbRdvSite2(0);
                }


                if($arrayHoraire["mercrediMatinDebut"]!="" && $arrayHoraire["mercrediMatinFin"]!="") {

                    $cap1 = self::getCapacite($arrayHoraire["mercrediMatinDebut"],$arrayHoraire["mercrediMatinFin"],$prestation->getPeriodicite());
                
                    $tperiode->setMercrediHeureDebut1($arrayHoraire["mercrediMatinDebut"]);
                    $tperiode->setMercrediHeureFin1($arrayHoraire["mercrediMatinFin"]);
                    $tperiode->setMercrediCapacite1($cap1);
                    $tperiode->setMercrediNbRdvSite1(0);
                }
                
                if($arrayHoraire["mercrediApresmidiDebut"]!="" && $arrayHoraire["mercrediApresmidiFin"]!="") {

                    $cap2 = self::getCapacite($arrayHoraire["mercrediApresmidiDebut"],$arrayHoraire["mercrediApresmidiFin"],$prestation->getPeriodicite());
                
                    $tperiode->setMercrediHeureDebut2($arrayHoraire["mercrediApresmidiDebut"]);
                    $tperiode->setMercrediHeureFin2($arrayHoraire["mercrediApresmidiFin"]);
                    $tperiode->setMercrediCapacite2($cap2);
                    $tperiode->setMercrediNbRdvSite2(0);
                }
                
                if($arrayHoraire["jeudiMatinDebut"]!="" && $arrayHoraire["jeudiMatinFin"]!="") {

                    $cap1 = self::getCapacite($arrayHoraire["jeudiMatinDebut"],$arrayHoraire["jeudiMatinFin"],$prestation->getPeriodicite());
                
                    $tperiode->setJeudiHeureDebut1($arrayHoraire["jeudiMatinDebut"]);
                    $tperiode->setJeudiHeureFin1($arrayHoraire["jeudiMatinFin"]);
                    $tperiode->setJeudiCapacite1($cap1);
                    $tperiode->setJeudiNbRdvSite1(0);
                }
                
                if($arrayHoraire["jeudiApresmidiDebut"]!="" && $arrayHoraire["jeudiApresmidiFin"]!="") {

                    $cap2 = self::getCapacite($arrayHoraire["jeudiApresmidiDebut"],$arrayHoraire["jeudiApresmidiFin"],$prestation->getPeriodicite());
                
                    $tperiode->setJeudiHeureDebut2($arrayHoraire["jeudiApresmidiDebut"]);
                    $tperiode->setJeudiHeureFin2($arrayHoraire["jeudiApresmidiFin"]);
                    $tperiode->setJeudiCapacite2($cap2);
                    $tperiode->setJeudiNbRdvSite2(0);
                }
                
                if($arrayHoraire["vendrediMatinDebut"]!="" && $arrayHoraire["vendrediMatinFin"]!="") {

                    $cap1 = self::getCapacite($arrayHoraire["vendrediMatinDebut"],$arrayHoraire["vendrediMatinFin"],$prestation->getPeriodicite());
                
                    $tperiode->setVendrediHeureDebut1($arrayHoraire["vendrediMatinDebut"]);
                    $tperiode->setVendrediHeureFin1($arrayHoraire["vendrediMatinFin"]);
                    $tperiode->setVendrediCapacite1($cap1);
                    $tperiode->setVendrediNbRdvSite1(0);
                }
                
                if($arrayHoraire["vendrediApresmidiDebut"]!="" && $arrayHoraire["vendrediApresmidiFin"]!="") {

                    $cap2 = self::getCapacite($arrayHoraire["vendrediApresmidiDebut"],$arrayHoraire["vendrediApresmidiFin"],$prestation->getPeriodicite());
                
                    $tperiode->setVendrediHeureDebut2($arrayHoraire["vendrediApresmidiDebut"]);
                    $tperiode->setVendrediHeureFin2($arrayHoraire["vendrediApresmidiFin"]);
                    $tperiode->setVendrediCapacite2($cap2);
                    $tperiode->setVendrediNbRdvSite2(0);
                }
                
                if($arrayHoraire["samediMatinDebut"]!="" && $arrayHoraire["samediMatinFin"]!="") {

                    $cap1 = self::getCapacite($arrayHoraire["samediMatinDebut"],$arrayHoraire["samediMatinFin"],$prestation->getPeriodicite());
                
                    $tperiode->setSamediHeureDebut1($arrayHoraire["samediMatinDebut"]);
                    $tperiode->setSamediHeureFin1($arrayHoraire["samediMatinFin"]);
                    $tperiode->setSamediCapacite1($cap1);
                    $tperiode->setSamediNbRdvSite1(0);
                }
                
                if($arrayHoraire["samediApresmidiDebut"]!="" && $arrayHoraire["samediApresmidiFin"]!="") {

                    $cap2 = self::getCapacite($arrayHoraire["samediApresmidiDebut"],$arrayHoraire["samediApresmidiFin"],$prestation->getPeriodicite());
                
                    $tperiode->setSamediHeureDebut2($arrayHoraire["samediApresmidiDebut"]);
                    $tperiode->setSamediHeureFin2($arrayHoraire["samediApresmidiFin"]);
                    $tperiode->setSamediCapacite2($cap2);
                    $tperiode->setSamediNbRdvSite2(0);
                }
                

                if($arrayHoraire["dimancheMatinDebut"]!="" && $arrayHoraire["dimancheMatinFin"]!="") {

                    $cap1 = self::getCapacite($arrayHoraire["dimancheMatinDebut"],$arrayHoraire["dimancheMatinFin"],$prestation->getPeriodicite());
                
                    $tperiode->setDimancheHeureDebut1($arrayHoraire["dimancheMatinDebut"]);
                    $tperiode->setDimancheHeureFin1($arrayHoraire["dimancheMatinFin"]);
                    $tperiode->setDimancheCapacite1($cap1);
                    $tperiode->setDimancheNbRdvSite1(0);
                }
                
                if($arrayHoraire["dimancheApresmidiDebut"]!="" && $arrayHoraire["dimancheApresmidiFin"]!="") {

                    $cap2 = self::getCapacite($arrayHoraire["dimancheApresmidiDebut"],$arrayHoraire["dimancheApresmidiFin"],$prestation->getPeriodicite());
                
                    $tperiode->setDimancheHeureDebut2($arrayHoraire["dimancheApresmidiDebut"]);
                    $tperiode->setDimancheHeureFin2($arrayHoraire["dimancheApresmidiFin"]);
                    $tperiode->setDimancheCapacite2($cap2);
                    $tperiode->setDimancheNbRdvSite2(0);
                }
                
                $tperiode->save();
            }
            catch(Exception $e) {echo $e->getMessage();exit;}
        return true;
    }


    private function getCapacite($heureDeb,$heureFin,$duree) {
        if($heureDeb=="" || $heureFin=="" || $duree==0) {
            return 0;
        }
        $capacite=0;
        while($heureFin>$heureDeb) {
            $capacite++;
            $heureDeb=Atexo_Utils_Util::addMinutes($heureDeb,$duree);
        }
        if($heureDeb>$heureFin) {
            $capacite--;
        }
        return $capacite;
    }
}