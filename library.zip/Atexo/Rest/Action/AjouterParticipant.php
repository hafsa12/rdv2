<?php

class Atexo_Rest_Action_AjouterParticipant extends Atexo_Rest_Action_Actions {

    public function post(){
        try {
            $json = file_get_contents('php://input');
            if($json==""){
                $this->getHeaders("200");
                return $this->generateXmlError('OBJET_JSON_OBLIGATOIRE',(Prado::localize('OBJET_JSON_OBLIGATOIRE')));
            }
            $validateJSON = self::isJSON($json);
            if(!$validateJSON){
                $this->getHeaders("200");
                return $this->generateXmlError('JSON_INVALIDE',(Prado::localize('JSON_INVALIDE')));
            }
            $data = json_decode($json);
            $resultatVerification = self::verifierChampsObligatoire($data);
            if(count($resultatVerification) == 0)
                $result = self::addParticipant($data);
            else{
                $this->getHeaders("200");
                return $this->generateXmlError('FORMAT_INCORRECT',"<champs><champ>".implode("</champ><champ>",$resultatVerification)."</champ></champs>");
            }
        }catch (Exception $e){
            $result = $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
            $this->getHeaders("200");
        }
        return $result;
    }

    public function isJSON($string){
        return is_string($string) && is_array(json_decode($string, true)) && (json_last_error() == JSON_ERROR_NONE) ? true : false;
    }

    public function verifierChampsObligatoire($params) {
        $erreur = array();
        if(trim($params->idApp) ==''){
            $erreur[]= 'ID_APP_OBLIGATOIRE';
        }
        else{
            $tOrgQ = new TOrganisationQuery();
            $tOrg = $tOrgQ->findOneByAcronyme($params->idApp);
            $this->idOrg = $tOrg->getIdOrganisation();
            if(!$tOrg){
                $erreur[]= 'ORGANISATION_INTROUVABLE';
            }else{
                if($params->cle != Atexo_Config::getParameter("CLE_WS_ORG_".$tOrg->getIdOrganisation())){
                    $erreur[]= 'CLE_INCORRECTE';
                }
            }
        }

        if(trim($params->cle) ==''){
            $erreur[]= 'CLE_OBLIGATOIRE';
        }

        if(trim($params->nom) ==''){
            $erreur[]= 'NOM_OBLIGATOIRE';
        }

        if(trim($params->prenom) ==''){
            $erreur[]= 'PRENOM_OBLIGATOIRE';
        }

        if(trim($params->email) ==''){
            $erreur[]= 'EMAIL_OBLIGATOIRE';
        }

        if(trim($params->code_rdv) ==''){
            $erreur[]= 'CODE_RDV_OBLIGATOIRE';
        }

        return $erreur;
    }


    public function addParticipant($participantData)
    {
        try {
            $connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
            $c = new Criteria();
            $c->addJoin(TParticipantPeer::ID_RENDEZ_VOUS, TRendezVousPeer::ID_RENDEZ_VOUS);
            $c->add(TRendezVousPeer::CODE_RDV, $participantData->code_rdv, Criteria::EQUAL);
            $c->add(TParticipantPeer::EMAIL, $participantData->email, Criteria::EQUAL);
            $c->add(TParticipantPeer::EMAIL, $participantData->email, Criteria::EQUAL);
            $c->add(TRendezVousPeer::ETAT_RDV, [Atexo_Config::getParameter('ETAT_NON_HONORE'), Atexo_Config::getParameter('ETAT_NON_HONORE_ETAB'), Atexo_Config::getParameter('ETAT_ANNULE'), Atexo_Config::getParameter('ETAT_ANNULE_ETAB')], Criteria::NOT_IN);
            $tParts = TParticipantPeer::doSelect($c, $connexionCom);
            if(count($tParts) == 0) {
                $rdv = TRendezVousPeer::getRdvGroupeAvailableByCode($participantData->code_rdv);
                if ($rdv) {
                    $nbrMaxPart = $rdv->getTPrestation()->getNombreMaxParticipants();
                    $nbrPartc = $rdv->getNombreParticipant();
                    if($nbrPartc < $nbrMaxPart){
                        $participant = new TParticipant();
                        $participant->setNom($participantData->nom);
                        $participant->setPrenom($participantData->prenom);
                        $participant->setEmail($participantData->email);
                        $participant->setTRendezVous($rdv);
                        $participant->setOrganisation($participantData->idApp);
                        $participant->save();
                        $nbrParticipant = $rdv->getNombreParticipant();
                        $rdv->setNombreParticipant($nbrParticipant + 1);
                        $rdv->save();
                        return json_encode(["status" => "OK"]);
                    }
                    return json_encode(["status" => "KO", "message" => "La formation a atteint sa nombre maximal des participants"]);

                }
                $this->getHeaders("404");
                return json_encode(["status" => "KO", "message" => "Formation est introuvable"]);
            }
            return json_encode(["status" => "KO", "message" => "Le participant déja inscrit à cette formation"]);

        }catch (Exception $e){
            return $this->generateXmlError('ERREUR_TECHNIQUE', (Prado::localize('ERREUR_TECHNIQUE').$e->getMessage()));
        }
    }
}