<?php
/*
 * contient les fonctions utiles pour les ws
 *
 * @version 1.0
 * @since 4.6.0
 * @copyright Atexo 2015
 * @package Atexo_Rest_Action
 */
class Atexo_Rest_Action_Actions
{
	protected $utilisateur;
	protected $idCoffreFort;

	public function isCompteValide($compte) {
		$tUtilisateurQuery = new TUtilisateurQuery();

		if (trim($compte[Atexo_Config::getParameter("CODE_KEY_CERTIFICAT_1")]) != "")
		{
			$tUtilisateur = $tUtilisateurQuery->getUtilisateurByCert($compte[Atexo_Config::getParameter("CODE_KEY_CERTIFICAT_1")]
								,$compte[Atexo_Config::getParameter("CODE_KEY_CERTIFICAT_2")]);
			if ($tUtilisateur instanceof TUtilisateur
				 && $tUtilisateur->getTProfilHabilitation()->getIdTypeProfil()==Atexo_Config::getParameter("ID_TYPE_PROFIL_CLIENT"))
			{
				$this->utilisateur = $tUtilisateur;
				self::getIdCf($tUtilisateur);
				return true;
			}
		}
		elseif ($compte["login"] && $compte["password"])
		{
			$tUtilisateur = $tUtilisateurQuery->getUtilisateurByLoginPass($compte["login"], sha1($compte["password"]));
			if ($tUtilisateur instanceof TUtilisateur
				 && $tUtilisateur->getTProfilHabilitation()->getIdTypeProfil()==Atexo_Config::getParameter("ID_TYPE_PROFIL_CLIENT"))
			{
				$this->utilisateur = $tUtilisateur;
				self::getIdCf($tUtilisateur);
				return true;
			}
		}
		return false;
	}

	private function getIdCf($tUtilisateur) {
		$repertoireQuery = new TRepertoireQuery();
		$repRacine = $repertoireQuery->getRepertoireRacineByIdUtilisateur($tUtilisateur->getIdUtilisateur());
		$this->idCoffreFort = $repRacine->getIdRepertoire();
	}

	/*
	 * generer un xml d'invalidit� du ticket
	 * 
	 * @param string $ticket,le ticket(sso) 
	 * @return DOMDocument $domDocument xml d'invalidit� du ticket
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function erreurTicket($ticket) {
		//TODO message erreur et type erreur
		$messageErreur = "Ticket invalide";
		return self::erreur($ticket, array("500", "Internal Server Error", $messageErreur,"006"));
	}
	/*
	 * generer un xml d'erreur
	 * 
	 * @param string $id,l'id de la ressource concern� par l'erreur
	 * @param array $erreurs,tableau des erreurs
	 * @return DOMDocument $domDocument xml d'erreur
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function erreur($id=null, $erreurs=array())
	{
		$domDocument = new DOMDocument('1.0', "UTF-8");
		$domDocument->xmlStandalone = true;

	 	$error=$domDocument->createElement('error', '');
	 	$domDocument->appendChild($error);

	 	$attribute = $domDocument->createAttribute("xmlns:xsi");
		$error->appendChild($attribute);
		$attributeValue = $domDocument->createTextNode("http://www.w3.org/2001/XMLSchema-instance");
		$attribute->appendChild($attributeValue);

		$attribute = $domDocument->createAttribute("xsi:noNamespaceSchemaLocation");
		$error->appendChild($attribute);
		$attributeValue = $domDocument->createTextNode("error.xsd");
		$attribute->appendChild($attributeValue);

		if (isset($erreurs[4])) {
			$classType = $domDocument->createElement('classType',utf8_encode($erreurs[4]));
			$error->appendChild($classType);
		}
		$errorCode=$domDocument->createElement('errorCode', utf8_encode($erreurs[3]));
	 	$error->appendChild($errorCode);

	 	$errorLabel=$domDocument->createElement('errorLabel', utf8_encode($erreurs[1]));
	 	$error->appendChild($errorLabel);

	 	$errorMessage=$domDocument->createElement('errorMessage', utf8_encode($erreurs[2]));
	 	$error->appendChild($errorMessage);

	 	$errorMessage=$domDocument->createElement('methodType', utf8_encode(strtoupper($_SERVER['REQUEST_METHOD'])));
	 	$error->appendChild($errorMessage);


	 	$ressourceId=$domDocument->createElement('resourceId', $id);
	 	$error->appendChild($ressourceId);


	 	header('HTTP/1.1 '.$erreurs[0].' '.$erreurs[1]);

		return $domDocument;
	}
	/*
	 * generer un xml d'erreur de fonction invoqu�e non suport�e
	 * 
	 * @return DOMDocument $domDocument xml d'erreur de fonction invoqu�e non suport�e
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version  1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function unsupportedMethod()
	{
		return $this->erreur(null, array("405", "Method Not Allowed", "Method Not Allowed, use POST|PUT|DELETE"));
	}

	protected function processXml($xml){}
	/*
	 * verifie la validit� d'un xml
	 * 
	 * @param string $xml,la chaine xml a charger
	 * @param string $schema,le schemaxsd
	 * @return mixed boolean true en cas d'xml valid,string xml d'erreur si l'xml n'est pas valid
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function isValid($xml,$schema=null)
	{
		if(trim($xml)=="") {
			$message="Bad Request : input was empty, no xml found";
   	     	return self::erreur(null, array("400", "Bad Request", $message, "001"));
		} else {
			$domDocument = new DOMDocument;
			$domDocument->loadXML($xml);

			if(!$schema) {
				$schema = "schemaPartageEnMasse.xsd";
			}
			if(!$domDocument->schemaValidate(Atexo_Controller_Front::getRootPath()."/ressources/".$schema))  {
				$message="Bad Request : xml didn't match xsd";
	   	     	return self::erreur(null, array("400", "Bad Request", $message, "001"));
			}
		}

		return true;
	}
    /*
	 * Permet de g�nerer l'xml de reponse du web service MPE
	 * 
	 * @param string $statut statut de la reponse (OK|KO)
	 * @param string $message message d'erreur en cas de $statut=KO
	 * @return string $xml xml reponse
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function generateXmlResponse($code, $message = null)
	{
		$xml = '<?xml version="1.0" encoding="UTF-8" ?>';
		$xml .= '<rdvServices xmlns="http://www.intelcia.com/rdvServices/xml" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" >'.
		    '<reponse>';
		$xml .= '<code>'.$code.'</code>' ;
		if($message){
			$xml .= '<messageErreur>'.$message.'</messageErreur>' ;
		}
		$xml .= '</reponse> </rdvServices>';
		return Atexo_Utils_Util::toUtf8($xml);
	}
	/*
	 * Permet de g�nerer l'xml de succes pour le web service MPE
	 * 
	 * @return string $xml xml reponse succes
	 * @author  ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function generateXmlSuccess()
	{
		return $this->generateXmlResponse('OK',null);
	}
	/*
	 * Permet de g�nerer l'xml d'erreur pour le web service MPE
	 * 
	 * @param string $message message d'erreur
	 * @return string $xml xml reponse Error
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function generateXmlError($code, $message = null)
	{
		return self::generateXmlResponse($code,$message);
	}
	
	/*
	 * recupere le header
	 * 
	 * @param Integer $code le code http
	 * @param string $contentTypele contentType
	 * @return http header
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function getHeaders($code, $contentType = "", $nameFile="")
	{
		header('HTTP/1.1 ' . $code , true, $code);
		if (!$contentType) {
			$contentType = "application/xml";
		}

		if($nameFile) {
			header("Pragma: public");
			header("Expires: 0");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Cache-Control: private",false);
			header("Content-Description: File Transfer");
			header('Content-type: ' . $contentType);
			header("Content-Disposition: attachment; filename=\"".$nameFile."\"");
			header("Content-Transfer-Encoding: binary");
		}
		else {
			header('Content-type: ' . $contentType);
		}
	}
	/*
	 * ajoute l'entete xml pr ws
	 *
	 * @param string $xmlResponse chaine xml
	 * @param string $nodele nom du noeud a encapsuler
	 * @return string $xmlResult chaine xml contennant le noeud pass� en param avec l'entete xml Ws valide
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function encapsulerNodeResponseWs($code, $xmlResponse,$node){
		$entete = self::generateXmlResponse($code);
		$doc = new DOMDocument();
		$doc->loadXML(Atexo_Utils_Util::toUtf8($xmlResponse));
		$node = $doc->getElementsByTagName("$node")->item(0);
		$newdoc = new DOMDocument( "1.0", "UTF-8" );
		$newdoc->formatOutput = true;
		$newdoc->loadXML($entete);
		$node = $newdoc->importNode($node, true);
		$response = $newdoc->getElementsByTagName("reponse")->item(0);
		$response->appendChild($node);

		return Atexo_Utils_Util::toUtf8($newdoc->saveXML());
	}
	/*
	 * Permet de verifier la validation du compte
	 * 
	 * @param string $logger objet du Atexo_LoggerManager
	 * @return boolean true or false
	 * @author ASO <ayoub.souidahmed@atexo.com>
	 * @version 1.0
	 * @since 4.6.0
	 * @copyright Atexo 2015
	 */
	public function validateCompte($compte){
		if(!self::isCompteValide($compte)) {
			$msgToLog = "Compte invalide ";
			return $msgToLog;
		}
		return true;
	}
}
