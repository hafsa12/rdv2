<?
/**
 *
 * Enter description here ...
 * @author Propriétaire
 *
 */
class Atexo_Rapport_AlerteRapport
{
	public static function nbreRdv($user,$dateDu,$dateAu) {

		$util = new Atexo_Utils_Util();

		$criteriaVo = new Atexo_RendezVous_CriteriaVo();
		$lang = "fr";
		$criteriaVo->setLang($lang);
		$criteriaVo->setNonAnnule();

		$criteriaVo->setDateDu($dateDu);
		$criteriaVo->setDateAu($dateAu);

		$criteriaVo->setIdEtablissementAttache($user->getIdsEtablissements());

		$data = TRendezVousPeer::getNbRdvByCriteres($criteriaVo);

		$dateDeb = $util->frnDate2iso($criteriaVo->getDateDu());
		$dateFin = $util->frnDate2iso($criteriaVo->getDateAu());

		$total = array();
		$totalEtab = array();

		while($dateDeb<=$dateFin) {
			$total[Atexo_Config::getParameter('MODE_AGENT_INTERNET')]+=$data[$dateDeb][Atexo_Config::getParameter('MODE_AGENT_INTERNET')];
			$total[Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')]+=$data[$dateDeb][Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')];
			$total[Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')]+=$data[$dateDeb][Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')];
			$total["total"]+=$data[$dateDeb]["total"];
			$total["en_attente"]+=$data[$dateDeb]["en_attente"];
			$total["confirme"]+=$data[$dateDeb]["confirme"];
			$total["annule_agent"]+=$data[$dateDeb]["annule_agent"];
			$total["annule_citoyen"]+=$data[$dateDeb]["annule_citoyen"];
			$total["non_honore"]+=$data[$dateDeb]["non_honore"];

			$dateDeb=$util->addJours($dateDeb, 1);
		}

		if(count($user->getIdsEtablissements())>0) {

			$i=0;
			$tEtabQuery = new TEtablissementQuery();
			foreach($user->getTabIdsEtablissements() as $idEtab) {
				$criteriaVo->setIdEtablissementAttache($idEtab);
				$data = TRendezVousPeer::getNbRdvByCriteres($criteriaVo);
				$dateDeb = $util->frnDate2iso($criteriaVo->getDateDu());
				$dateFin = $util->frnDate2iso($criteriaVo->getDateAu());
				while($dateDeb<=$dateFin) {
					$totalEtab[$i][Atexo_Config::getParameter('MODE_AGENT_INTERNET')]+=$data[$dateDeb][Atexo_Config::getParameter('MODE_AGENT_INTERNET')];
					$totalEtab[$i][Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')]+=$data[$dateDeb][Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')];
					$totalEtab[$i][Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')]+=$data[$dateDeb][Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')];
					$totalEtab[$i]["total"]+=$data[$dateDeb]["total"];
					$totalEtab[$i]["en_attente"]+=$data[$dateDeb]["en_attente"];
					$totalEtab[$i]["confirme"]+=$data[$dateDeb]["confirme"];
					$totalEtab[$i]["annule_agent"]+=$data[$dateDeb]["annule_agent"];
					$totalEtab[$i]["annule_citoyen"]+=$data[$dateDeb]["annule_citoyen"];
					$totalEtab[$i]["non_honore"]+=$data[$dateDeb]["non_honore"];
					$dateDeb=$util->addJours($dateDeb, 1);
				}
				$etab = $tEtabQuery->getEtablissementById($idEtab);
				$totalEtab[$i]["NOM_ETAB"] = $etab->getTEntite()->getLibelleTraduit($lang)." - ".$etab->getDenominationEtablissementTraduit($lang);
				$i++;
			}
		}

		$table = '
				<table>
				<thead>
					<tr>
						<th></th>
						<th></th>
						<th colspan="5">'.Prado::localize('STATUT').'</th>
						<th colspan="3">'.Prado::localize('MODE_PRISE_RENDEZ_VOUS').'</th>
					</tr>
					<tr>
						<th>'.Prado::localize('ETABLISSEMENT').'</th>
						<th>'.Prado::localize('NOMBRE_TOTAL').'</th>
						<th>'.Prado::localize('HONORE').'</th>
						<th>'.Prado::localize('NON_HONORE').'</th>
						<th>'.Prado::localize('ANNULE_AGENT').'</th>
						<th>'.Prado::localize('ANNULE_CITOYEN').'</th>
						<th>'.Prado::localize('NON_DEFINI').'</th>
						<th>'.Prado::localize('SUR_PLACE').'</th>
						<th>'.Prado::localize('WEB').'</th>
						<th>'.Prado::localize('PHONE').'</th>
					</tr>
				</thead>';
		foreach($totalEtab as $dataEtab) {
			$table .= '<tr>
							<td>'.$dataEtab['NOM_ETAB'].'</td>
							<td>'.$dataEtab['total'].'</td>
							<td>'.$dataEtab['confirme'].'
								('.self::getPourcentage($dataEtab,"confirme").'%)</td>
							<td>'.$dataEtab['non_honore'].'
								('.self::getPourcentage($dataEtab,"non_honore").'%)</td>
							<td>'.$dataEtab['annule_agent'].'
								('.self::getPourcentage($dataEtab,"annule_agent").'%)</td>
							<td>'.$dataEtab['annule_citoyen'].'
								('.self::getPourcentage($dataEtab,"annule_citoyen").'%)</td>
							<td>'.$dataEtab['en_attente'].'
								('.self::getPourcentage($dataEtab,"en_attente").'%)</td>
							<td>'.$dataEtab[Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')].'
								('.self::getPourcentage($dataEtab,Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')).'%)</td>
							<td>'.$dataEtab[Atexo_Config::getParameter('MODE_AGENT_INTERNET')].'
								('.self::getPourcentage($dataEtab,Atexo_Config::getParameter('MODE_AGENT_INTERNET')).'%)</td>
							<td>'.$dataEtab[Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')].'
								('.self::getPourcentage($dataEtab,Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')).'%)</td>
						</tr>';
		}
		if(count($total)>0) {
			$table .= '<tr>
							<td><b>'.Prado::localize('TOUS_ETABLISSEMENTS').'</b></td>
							<td><b>'.$total['total'].'</b></td>
							<td>'.$total['confirme'].'
								('.self::getPourcentage($total,"confirme").'%)</td>
							<td>'.$total['non_honore'].'
								('.self::getPourcentage($total,"non_honore").'%)</td>
							<td>'.$total['annule_agent'].'
								('.self::getPourcentage($total,"annule_agent").'%)</td>
							<td>'.$total['annule_citoyen'].'
								('.self::getPourcentage($total,"annule_citoyen").'%)</td>
							<td>'.$total['en_attente'].'
								('.self::getPourcentage($total,"en_attente").'%)</td>
							<td><b>'.$total[Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')].'
								('.self::getPourcentage($total,Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_SURPLACE')).'%)</b></td>
							<td><b>'.$total[Atexo_Config::getParameter('MODE_AGENT_INTERNET')].'
								('.self::getPourcentage($total,Atexo_Config::getParameter('MODE_AGENT_INTERNET')).'%)</b></td>
							<td><b>'.$total[Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')].'
								('.self::getPourcentage($total,Atexo_Config::getParameter('MODE_AGENT_TELEOPERATEUR_TELEPHONE')).'%)</b></td>
						</tr>';
		}
		$table .="</table>";
		return $table;
	}

	private static function getPourcentage($data, $key) {
		if($data["total"]==0) {
			return 0;
		}
		return Atexo_Utils_Util::getMontantArrondit(($data[$key]/$data["total"])*100);
	}

	public static function activite($user,$dateDebut,$dateFin) {

		$util = new Atexo_Utils_Util();

		$criteriaVo = new Atexo_Prestation_CriteriaVo();
		$lang = "fr";
		$criteriaVo->setLang($lang);
		$criteriaVo->setPrestationReferentiel(true);

		$criteriaVo->setIdEtablissement($user->getIdsEtablissements());

		$dataPrestation = TPrestationPeer::getPrestationByCriteres($criteriaVo);

		$nbPr = count($dataPrestation);

		for($i=0; $i<$nbPr; $i++) {
			$tPeriodeQuery = new TPeriodeQuery();
			$capacite = $tPeriodeQuery->getCapacite($dataPrestation[$i]["ID_PRESTATION"],$dateDebut,$dateFin);
			$dataPrestation[$i]["CAPACITE"] = $capacite;
			$dataPrestation[$i]["MOYENNE"] = ($dataPrestation[$i]["NB_RESSOURCE"]==0)?0:
				$util->getMontantArrondit($capacite/$dataPrestation[$i]["NB_RESSOURCE"]);
			$dataPrestation[$i]["LIBELLE_ETP"]=$dataPrestation[$i]["LIBELLE_ETAB"]." - ".$dataPrestation[$i]["LIBELLE_ENTITE"]." : ".$dataPrestation[$i]["LIBELLE_ETP"];
		}

		$table = '
				<style>
					table {border-bottom: 1px solid #DDDDDD;}
					th {border-top-left-radius: 4px;background: #DDDDDD;border-right: 1px solid #fff;line-height: 20px;text-align: left;}
					 td, th {
						  border-right: 1px solid #fff;
						  vertical-align: top !important;
						  border-top: 1px solid #dddddd;
						}
					td {padding: 4px 5px;}
				</style>
				<table>
				<thead>
					<tr>
						<th>'.Prado::localize('LIBELLE_PRESTATION').'</th>
						<th>'.Prado::localize('NB_RESSOURCE').'</th>
						<th>'.Prado::localize('CAPACITE').'</th>
						<th>'.Prado::localize('MOYENNE').'</th>
					</tr>
				</thead>';
		foreach($dataPrestation as $dataEtab) {
			$table .= '<tr>
							<td>'.$dataEtab['LIBELLE_ETP'].'</td>
							<td>'.$dataEtab['NB_RESSOURCE'].'</td>
							<td>'.$dataEtab['CAPACITE'].'</td>
							<td>'.$dataEtab['MOYENNE'].'</td>
						</tr>';
		}
		$table .="</table>";
		return $table;
	}
}