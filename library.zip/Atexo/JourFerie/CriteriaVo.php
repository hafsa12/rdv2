<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_JourFerie_CriteriaVo{

	
	private $idOrganisation;
	private $motCle = null;
	private $lang;
	private $sortByElement="";
	private $sensOrderBy="ASC";
	private $offset=0;
	private $limit=0;
	private $suggest=false;
	private $count = false;
	private $_pages = false;
	private $_pageSize = false;

	
	public function getIdOrganisation()
	{
		return $this->idOrganisation;
	}

	public function setIdOrganisation($idOrganisation)
	{
		$this->idOrganisation = $idOrganisation;
	}

	public function getMotCle()
	{
		return $this->motCle;
	}

	public function setMotCle($motCle)
	{
		$this->motCle = $motCle;
	}

	public function getLang()
	{
		return $this->lang;
	}

	public function setLang($lang)
	{
		$this->lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->offset;
	}

	public function setOffset($offset)
	{
		$this->offset = $offset;
	}

	public function getLimit()
	{
		return $this->limit;
	}

	public function setLimit($limit)
	{
		$this->limit = $limit;
	}

	public function getSuggest()
	{
		return $this->suggest;
	}

	public function setSuggest($suggest)
	{
		$this->suggest = $suggest;

	}
	
	public function getCount()
	{
		return $this->count;
	}

	public function setCount($count)
	{
		$this->count = $count;

	}

	public function getPages()
	{
		return $this->_pages;
	}

	public function setPages($p)
	{
		$this->_pages = $p;
	}

	public function getPageSize()
	{
		return $this->_pageSize;
	}

	public function setPageSize($ps)
	{
		$this->_pageSize = $ps;
	}
}