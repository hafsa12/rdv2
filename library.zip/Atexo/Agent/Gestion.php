<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Agent_Gestion
{
	public function getRessourceByIdPrestation($lang,$idPres,$valeurParDefaur = false, $actif=false, $typeRessource=0, $disponible=false){
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
        if($disponible){
            $c->addJoin(TPeriodePeer::ID_AGENDA, TAgendaPeer::ID_AGENDA);
            $c->add(TPeriodePeer::FIN_PERIODE, date('Y-m-d'), Criteria::GREATER_EQUAL);
            $c->add(TPeriodePeer::DEBUT_PERIODE, date('Y-m-d'), Criteria::LESS_EQUAL);
        }
        $c->add(TAgendaPeer::ID_PRESTATION,$idPres);
        $c->addJoin(TAgendaPeer::ID_AGENT,TAgentPeer::ID_AGENT);
		if($actif) {
			$c->add(TAgentPeer::ACTIF,"1");
		}
		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
		//	$arrayRess[0] = $valeurParDefaur;
		}

		foreach($arrayObjetRess as $ressource){
			if(!$typeRessource || !$ressource->getCodeUtilisateur() || $ressource->getCodeUtilisateurTraduit($lang)=="") {
				$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);//Traduit($lang);
			}
			else {
				$arrayRess[$ressource->getIdAgent()] = $ressource->getCodeUtilisateurTraduit($lang);
			}
		}
		asort($arrayRess);
                if($valeurParDefaur){
                        $arrayRess = array(0=>$valeurParDefaur) + $arrayRess;
                }
		return $arrayRess;
	}

	public function getRessourceByIdRefPrestation($lang,$idPres,$valeurParDefaur = false, $actif=false,$typePrestation=null,$idEtab=null){
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TAgentPeer::ID_AGENT,TAgendaPeer::ID_AGENT);
		if($typePrestation!=Atexo_Config::getParameter ( 'PRESTATION_SAISIE_LIBRE' ))  {
			$c->addJoin(TAgendaPeer::ID_PRESTATION,TPrestationPeer::ID_PRESTATION);
			$c->add(TPrestationPeer::ID_REF_PRESTATION, $idPres);
		}
		else {
			$c->add(TAgendaPeer::ID_PRESTATION, $idPres);
		}
		if($actif) {
			$c->add(TAgentPeer::ACTIF,"1");
		}
		if(count($idEtab)>0) {
			$c->add(TAgentPeer::ID_ETABLISSEMENT_ATTACHE,$idEtab,Criteria::IN);
		}
		elseif($idEtab>0) {
			$c->add(TAgentPeer::ID_ETABLISSEMENT_ATTACHE,$idEtab);
		}
		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRess[0] = $valeurParDefaur;
		}
		
		foreach($arrayObjetRess as $ressource){
			$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);//Traduit($lang);
		}
		return $arrayRess;
	}
	
	public function getRessourcesObjectByIdPrestation($idPres,$onlyActive=false){
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TAgendaPeer::ID_PRESTATION,$idPres);			
		$c->addJoin(TAgendaPeer::ID_AGENT,TAgentPeer::ID_AGENT);
		if($onlyActive) {
			$c->add(TAgentPeer::ACTIF,"1");
		}
		$c->setDistinct();
		return TAgentPeer::doSelect($c,$connexion);
	}
	
	public function getRessourceByIdAgent($lang,$idAgent,$valeurParDefaur = false){
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TAgentPeer::ID_AGENT,TAgendaPeer::ID_AGENT);
		$c->addJoin(TAgendaPeer::ID_PRESTATION,TAgentPrestationPeer::ID_PRESTATION);
		$c->add(TAgentPrestationPeer::ID_AGENT,$idAgent);			
		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRess[0] = $valeurParDefaur;
		}
		
		foreach($arrayObjetRess as $ressource){
			$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);
		}
		return $arrayRess;
	}
	
	public function getRessourceByEtablissement($lang,$idEtab,$valeurParDefaur = false){
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TAgentPeer::ID_AGENT,TAgendaPeer::ID_AGENT);
		$c->add(TAgentPeer::ID_ETABLISSEMENT_ATTACHE,$idEtab);
		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRess[0] = $valeurParDefaur;
		}
		
		foreach($arrayObjetRess as $ressource){
			$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);
		}
		return $arrayRess;
	}
	
	public function getAgentByEtablissement($lang,$idEtab,$valeurParDefaur = false){
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TAgentPeer::ID_AGENT,TAgentEtablissementPeer::ID_AGENT);
		$c->add(TAgentEtablissementPeer::ID_ETABLISSEMENT,$idEtab);
		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRess[0] = $valeurParDefaur;
		}
		
		foreach($arrayObjetRess as $ressource){
			$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);
		}
		return $arrayRess;
	}
	
	public function getRessourceGere($lang,$valeurParDefaur = false) {
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TAgentPeer::ID_AGENT,TAgendaPeer::ID_AGENT);
		if(Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
			$c->add(TAgentPeer::ID_ETABLISSEMENT_ATTACHE,explode(",",Atexo_User_CurrentUser::getIdEtablissementGere()), Criteria::IN);
		}
		
		if(Atexo_User_CurrentUser::isAdminOrg()) {
			$c->add(TAgentPeer::ID_ORGANISATION_ATTACHE,Atexo_User_CurrentUser::getIdOrganisationGere());
		}
		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRess[0] = $valeurParDefaur;
		}
		
		foreach($arrayObjetRess as $ressource){
			$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);
		}
		return $arrayRess;
	}

	public function getRessourceByCriteres($lang, $idOrganisation = false, $idEtablissement = false, $idTypePrestation = false, $idPrestation = false, $valeurParDefaur = false){
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TAgentPeer::ID_AGENT,TAgendaPeer::ID_AGENT);
		$c->addJoin(TAgendaPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION);

		if($idOrganisation) {
			$c->add(TAgentPeer::ID_ORGANISATION_ATTACHE, $idOrganisation);
		}
		if(is_array($idEtablissement)) {
			$c->add(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $idEtablissement, Criteria::IN);
		}
		elseif($idEtablissement) {
			$c->add(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $idEtablissement);
		}
		if($idPrestation) {
			$c->add(TPrestationPeer::ID_PRESTATION, $idPrestation, Criteria::EQUAL);
		}
		if($idTypePrestation) {
			$c->add(TPrestationPeer::ID_TYPE_PRESTATION, $idTypePrestation, Criteria::EQUAL);
		}

		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRess[0] = $valeurParDefaur;
		}

		foreach($arrayObjetRess as $ressource){
			$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);
		}
		return $arrayRess;
	}

	/**
	 * retourne l'objet  Agent (nom, pr�nom, login ...) équivalent à l'id de l'agent pass� en param�tre
	 *
	 * @param : $idAgent : l'id de l'agent
	 * @return Agent si l'agent est trouv�, false sinon
	 */
	public function retrieveAgent($idAgent)
	{
		$c = new Criteria();
		$c->add(TAgentPeer::ID_AGENT, $idAgent, CRITERIA::EQUAL);
		$connexion = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
		$tAgentObject = TAgentPeer::doSelectOne($c, $connexion);
		return $tAgentObject ? $tAgentObject : false;
	}

	/**
	 * retourne l'objet  Agent (nom, pr�nom, ...) équivalent � l'login  de l'agent passé en paramètre
	 *
	 * @param $idAgent l'id de l'agent
	 * @return Agent si l'agent est trouv�, false sinon
	 */
	public function retrieveAgentByLogin($login){
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TAgentPeer::LOGIN,$login);
		return TAgentPeer::doSelectOne($c,$connexion);
	}

	/**
	 * Retourne l'objet propel Agent (nom, pr�nom, ...) �quivalent � l'email de l'agent pass� en param�tre
	 *
	 * @param $idAgent l'id de l'agent
	 * @return Agent Objet Agent si l'agent est trouv�, false sinon
	 */
	public function retrieveAgentByMail($email)
	{
		$c = new Criteria();
		$c->add(CommonAgentPeer::EMAIL, $email,CRITERIA::EQUAL);
		$connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
		$tAgentObject = CommonAgentPeer::doSelectOne($c, $connexionCom);
		return $tAgentObject ? $tAgentObject : false;
	}

	/**
	 * retourne l'objet  Agent (nom, pr�nom, ...) �quivalent � l'login  de l'agent pass� en param�tre
	 *
	 * @param $idAgent l'id de l'agent
	 * @return CommonAgent si l'agent est trouv�, false sinon
	 */
	public function retrieveAgentByLoginAndMdp($login, $password, $onlyActif=false)
	{
		$c = new Criteria();
		$c->add(TAgentPeer::LOGIN,$login, CRITERIA::EQUAL);
		$c->add(TAgentPeer::MOT_DE_PASSE,$password, CRITERIA::EQUAL);
		if($onlyActif) {
			$c->add(TAgentPeer::ACTIF,"0", CRITERIA::NOT_EQUAL);
		}
		$connexion = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
		$tAgentObject = TAgentPeer::doSelectOne($c, $connexion);
		return $tAgentObject ? $tAgentObject : false;
	}

	public function deleteAgent($idAgentSupprime, $idAgentSupprimeur)
	{
		$connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_WRITE'));
		$agentSupprime = CommonAgentPeer::retrieveByPK($idAgentSupprime, $connexionCom);
		$agentSupprimeur = CommonAgentPeer::retrieveByPK($idAgentSupprimeur, $connexionCom);
		try {
			$connexionCom->begin();
			$historique = new CommonHistoriqueSuppressionAgent();
			$historique->setIdAgentSupprime($idAgentSupprime);
			$historique->setDateSuppression(date('Y-m-d H:i:s'));
			$historique->setEmail($agentSupprimeur->getEmail());
			$historique->setIdAgentSuppresseur($idAgentSupprimeur);
			$historique->setIdService($agentSupprimeur->getServiceId());
			$historique->setNom($agentSupprimeur->getNom());
			$historique->setOrganisme($agentSupprimeur->getOrganisme());
			$historique->setPrenom($agentSupprimeur->getPrenom());
			$historique->save($connexionCom);
			$email = $agentSupprime->getEmail();
			$login = $agentSupprime->getLogin();
			$agentSupprime->setEmail($historique->getId() . "_" . $email);
			$agentSupprime->setLogin($historique->getId() . "_" . $login);
			$agentSupprime->setServiceId(10000);
			$agentSupprime->setTentativesMdp(3);
			$agentSupprime->setDateModification(date('Y-m-d H:i:s'));
			//$habilitationAgentSupprime = Atexo_Agent_EnablingsAgents::addOrModifyEnablingsOfTheAgents(0, $id);
			//$habilitationAgentSupprime->save($connexionCom);
	 	 
			$agentSupprime->save($connexionCom);
			$connexionCom->commit();
		}
		catch (Exception $e) {
			$connexionCom->rollback();
			$logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
		    $logger->error($e->getMessage());
		}
	}

	public function retrieveAgentById($idAgent)
	{
		$c = new Criteria();
		$connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
		$c->add(CommonAgentPeer::ID, $idAgent,CRITERIA::EQUAL);
		$agent = CommonAgentPeer::doSelectOne($c, $connexionCom);
		return $agent;
	}

	/*
	 * Recuperer les agents avec tentatives de mot de passe = 3.
	 */
	public function getAllAgentTentativesMdpMax($organisme=null)
	{
		$c = new Criteria();
		$connexionCom = Propel::getConnection(Atexo_Config::getParameter('DB_NAME').Atexo_Config::getParameter('CONST_READ_ONLY'));
		$c->add(CommonAgentPeer::TENTATIVES_MDP , Atexo_Config::getParameter('MAX_TENTATIVES_MDP'), CRITERIA::EQUAL);
		if($organisme) {
			$c->add(CommonAgentPeer::ORGANISME, $organisme,CRITERIA::EQUAL);
		}
		$agentsObjects = CommonAgentPeer::doSelect($c, $connexionCom);
		return $agentsObjects;
	}

	public function retreiveNomPrenomAgent($idAgent) {
		$agent = self::retrieveAgent($idAgent);
		if($agent instanceof CommonAgent) {
			return $agent->getPrenom()." ".$agent->getNom();
		}
		return "";
	}

	public function getMailAgentById($idAgent)
	{
		$agent = self::retrieveAgent($idAgent);
		if($agent instanceof CommonAgent) {
			return $agent->getEmail();
		}
	}

	public function getRessourceByIdEtablissement($lang,$idEtab,$valeurParDefaur = false){
		$arrayRess = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TAgentPeer::ID_AGENT,TAgendaPeer::ID_AGENT);
		$c->addJoin(TAgendaPeer::ID_PRESTATION,TPrestationPeer::ID_PRESTATION);
		$c->addJoin(TPrestationPeer::ID_TYPE_PRESTATION,TTypePrestationPeer::ID_TYPE_PRESTATION);
		$c->add(TTypePrestationPeer::ID_ETABLISSEMENT,$idEtab);			
		$c->setDistinct();
		$arrayObjetRess = TAgentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRess[0] = $valeurParDefaur;
		}
		
		foreach($arrayObjetRess as $ressource){
			$arrayRess[$ressource->getIdAgent()] = $ressource->getNomPrenomUtilisateurTraduit($lang);
		}
		return $arrayRess;
	}
}
