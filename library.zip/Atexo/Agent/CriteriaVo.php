<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Agent_CriteriaVo{

	private $_idAgent;
	private $_motCle = null;
	private $_lang;
	private $_sortByElement = "";
	private $_sensOrderBy = "ASC";
	private $_offset = 0;
	private $_limit = 0;
	private $_suggest = false;
	private $_idSuggest;
	private $_count = false;
	private $_idEtablissementGere;
	private $_idEtablissementAttache;
	private $_idOrganisationGere;
	private $_idOrganisationAttache;
	private $_idTypePrestation;
	private $_idPrestation;
	private $_forRessource = false;
	private $_forIndisponibilite = false;
	private $_idsProfil = array();
	private $_idTypeProfil = false;
	private $_pages = false;
	private $_pageSize = false;
	private $_idEntite = false;
	private $_entite1 = false;
	private $_entite2 = false;
	private $_entite3 = false;
	private $_codeRessource;

	public function getIdAgent()
	{
		return $this->_idAgent;
	}

	public function setIdAgent($idAgent)
	{
		$this->_idAgent = $idAgent;
	}

	public function getMotCle()
	{
		return $this->_motCle;
	}

	public function setMotCle($motCle)
	{
		$this->_motCle = $motCle;
	}

	public function getLang()
	{
		return $this->_lang;
	}

	public function setLang($lang)
	{
		$this->_lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->_sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->_sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->_sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->_sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->_offset;
	}

	public function setOffset($offset)
	{
		$this->_offset = $offset;
	}

	public function getLimit()
	{
		return $this->_limit;
	}

	public function setLimit($limit)
	{
		$this->_limit = $limit;
	}

	public function getSuggest()
	{
		return $this->_suggest;
	}

	public function setSuggest($suggest)
	{
		$this->_suggest = $suggest;

	}

	public function getIdSuggest()
	{
		return $this->_idSuggest;
	}

	public function setIdSuggest($idSuggest)
	{
		$this->_idSuggest = $idSuggest;
	}

	public function getCount()
	{
		return $this->_count;
	}

	public function setCount($count)
	{
		$this->_count = $count;

	}

	public function setIdEtablissementGere($value)
	{
		$this->_idEtablissementGere = $value;
	}
	public function getIdEtablissementGere()
	{
		return $this->_idEtablissementGere;
	}
	public function setIdEtablissementAttache($value)
	{
		$this->_idEtablissementAttache = $value;
	}
	public function getIdEtablissementAttache()
	{
		return $this->_idEtablissementAttache;
	}
	public function setIdOrganisationGere($value)
	{
		$this->_idOrganisationGere = $value;
	}
	public function getIdOrganisationGere()
	{
		return $this->_idOrganisationGere;
	}
	public function setIdOrganisationAttache($value)
	{
		$this->_idOrganisationAttache = $value;
	}
	public function getIdOrganisationAttache()
	{
		return $this->_idOrganisationAttache;
	}
	public function setIdTypePrestation($value)
	{
		$this->_idTypePrestation = $value;
	}
	public function getIdTypePrestation()
	{
		return $this->_idTypePrestation;
	}
	public function setIdPrestation($value)
	{
		$this->_idPrestation = $value;
	}
	public function getIdPrestation()
	{
		return $this->_idPrestation;
	}
	public function setForRessource($value)
	{
		$this->_forRessource = $value;
	}
	public function getForRessource()
	{
		return $this->_forRessource;
	}
	public function setForIndisponibilite($value)
	{
		$this->_forIndisponibilite = $value;
	}
	public function getForIndisponibilite()
	{
		return $this->_forIndisponibilite;
	}

	public function getIdsProfil()
	{
		return $this->_idsProfil;
	}

	public function setIdsProfil($idsProfil)
	{
		$this->_idsProfil = $idsProfil;
	}

	public function getIdTypeProfil()
	{
		return $this->_idTypeProfil;
	}

	public function setIdTypeProfil($idTypeProfil)
	{
		$this->_idTypeProfil = $idTypeProfil;
	}

	public function getPages()
	{
		return $this->_pages;
	}

	public function setPages($p)
	{
		$this->_pages = $p;
	}

	public function getPageSize()
	{
		return $this->_pageSize;
	}

	public function setPageSize($ps)
	{
		$this->_pageSize = $ps;
	}

	public function getIdEntite()
	{
		return $this->_idEntite;
	}

	public function setIdEntite($idEntitie)
	{
		$this->_idEntite = $idEntitie;
	}

	public function getEntite1()
	{
		return $this->_entite1;
	}

	public function setEntite1($entitie1)
	{
		$this->_entite1 = $entitie1;
	}

	public function getEntite2()
	{
		return $this->_entite2;
	}

	public function setEntite2($entitie2)
	{
		$this->_entite2 = $entitie2;
	}

	public function getEntite3()
	{
		return $this->_entite3;
	}

	public function setEntite3($entitie3)
	{
		$this->_entite3 = $entitie3;
	}

	public function getCodeRessource()
	{
		return $this->_codeRessource;
	}

	public function setCodeRessource($codeRessource)
	{
		$this->_codeRessource = $codeRessource;
	}
}