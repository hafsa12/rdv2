<?php
class Atexo_Organisation_Gestion {

	/**
	 * retourne un tableau des organisations de la table "TOrganisation"
	 * @param $lang, $valeurPraDefaut : gestion de mot selectionnez, $onlyGere : true pour avoir juste l'organisation gérée
	 * @return : tableau d'organisations la table "TOrganisation"
	 */
	public function getAllOrganisation($lang,$valeurParDefaur = false, $onlyGere=false){
		$arrayReg = array();

		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();

		if($onlyGere) {
			if(Atexo_User_CurrentUser::isAdminOrg() || Atexo_User_CurrentUser::isAdminEtab()) {
				$c->add(TOrganisationPeer::ID_ORGANISATION,Atexo_User_CurrentUser::getIdOrganisationGere());
			}
		}

		$arrayObjetReg = TOrganisationPeer::doSelect($c,$connexion);

		if($valeurParDefaur){
			$arrayReg[0] = $valeurParDefaur;
		}
		foreach($arrayObjetReg as $Reg){
			$arrayReg[$Reg->getIdOrganisation()] = $Reg->getDenominationTraduit($lang);
		}
		return $arrayReg;
	}

	/**
	 * retourne un tableau des organisations de la table "TOrganisation"
	 * @param  $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau des organisations la table "TOrganisation"
	 */
	public function getOrganisationByRef($lang,$valeurParDefaur = false){
		$arrayOrg = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		
		$c->add(TOrganisationPeer::TYPE_PRESTATION,1);
		$arrayObjetPres = TOrganisationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayOrg[0] = $valeurParDefaur;
		}

		foreach($arrayObjetPres as $pres){
			$arrayOrg[$pres->getIdOrganisation()] = $pres->getDenominationTraduit($lang);//Traduit($lang);
		}
		return $arrayOrg;
	}
}