<?php
class Atexo_Agenda_Gestion {

	public function getMaxMois($idAgenda) {

		$tAgendaQuery = new TAgendaQuery();
		$tAgenda = $tAgendaQuery->getAgendaById($idAgenda);

		$tPeriodePeer = new TPeriodePeer();
		$maxDateFinPeriode = $tPeriodePeer->getMaxDateFin($idAgenda);

		if($tAgenda->getMaxMoisPriseRdv()==0) {
			return $maxDateFinPeriode;
		}

		list($moisMax,$anneeMax) = Atexo_Utils_Util::getMoisWithInterval(date("m"), date("Y"), $tAgenda->getMaxMoisPriseRdv());
		return min($maxDateFinPeriode,$anneeMax.$moisMax);
	}

	public function getPrestationByIdAgent($idAgent){
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TAgendaPeer::ID_AGENT,$idAgent);
		return TAgendaPeer::doSelect($c,$connexion);
	}

}