<?php
/**
 * Class des controles de pagination
 *
 * @author Youssef EL ALAOUI <youssef.elalaoui@atexo.com>
 * @copyright Atexo 2016
 * @version 1.0
 * @since Atexo.Forpro
 * @package Atexo
 * @subpackage Pagination
 */
class Atexo_Pagination_Controller
{
    CONST PAGE_SIZE = "10#20";
    /**
     * Cette methode verifie le numero de la page � afficher,
     * il doit etre entre 1 et nombrePage
     * @param int $page numero de la page � afficher
     * @param int $currentPage la page courante
     * @param int $nombrePage le nombre total de page
     * @return int
     */
    public static function verifierPagePagination($page, $currentPage, $nombrePage)
    {
        $numPage = $page;
        if ( Atexo_Utils_Util::isEntier ( $numPage ) ) {
            if ( $numPage >= $nombrePage ) {
                $numPage = $nombrePage;
            } else if ( $numPage <= 0 ) {
                $numPage = 1;
            }
        } else {
            $numPage = $currentPage;
        }
        return $numPage;
    }
    /**
     * Cette methode verifie le nombre de resultat par page � afficher,
     * il doit etre une veleur du tableau PAGE_SIZE
     * @param int $pageSize la taille de la page
     * @return int
     */
    public static function verifierPageSizePagination($pageSize)
    {
        $array = explode('#', self::PAGE_SIZE);
        if ( ! in_array($pageSize, $array) ) {
            return $array[0];
        }
        return $pageSize;
    }
}