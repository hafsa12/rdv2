<?php

class Atexo_Utils_UrlProtector extends Api_UrlProtector
{
    
}