<?php
/**
 * description de la classe
 *
 * @author izgua fatima ezzahra <fatima.izgua@atexo.com>
 * @copyright Atexo 2010
 * @version 0.0
 * @since Atexo.Forpro
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Utils_Mail extends Api_Mail
{
    
}