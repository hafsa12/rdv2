<?php
/**
 * Classe de manipulation des langues de la plate-forme
 * @author ZAKI Anas <anas.zaki@atexo.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage consultation
 */
class Atexo_Utils_Languages extends Api_Languages
{
	public static function writeLanguageInSession($language)
	{
		Atexo_User_CurrentUser::deleteFromSession("lang");
		Atexo_User_CurrentUser::writeToSession("lang",$language);
	}

	public static function readLanguageFromSession()
	{
		return Atexo_User_CurrentUser::readFromSession("lang");
	}

	public static function generateXliffByLanguage($language,$org = null){
		if(!$org){
			if(!isset($_SESSION['selectedorg'])){
				Atexo_Controller_Front::setOrg();
			}
			$organisme = "";
			if($org = $_SESSION['selectedorg']){
				$organisme = $org;
				$org = $org.".";
			}
		}else{
			$organisme = $org;
			$org = $org.".";
		}


		if (!is_file("protected/config/messages/messages.".$org."$language.xml")) {
			if (!is_file("../config/messages/".$organisme."/messages.".$org."$language.xml")) {
				@copy("protected/config/messages/messages.default.$language.xml", "protected/config/messages/messages.".$org."$language.xml");
			} else {
				$domv1 = Atexo_Utils_Util::XliffToArray("../config/messages/".$organisme."/messages.".$org."$language.xml");
				$domv2 = Atexo_Utils_Util::XliffToArray("protected/config/messages/messages.default.$language.xml");
				$xml='<?xml version="1.0" encoding="utf-8"?>' . "\n";
				$xml.='<xliff version="1.0"><file datatype="plaintext" date="'.date("c").'" original="I18N Example IndexPage" source-language="'.strtoupper($language).'" target-language="'.strtoupper($language).'-'.strtoupper($language).'"><body>' . "\n";
				foreach ($domv1 as $k => $v) $domv2[$k] = $v;

				$row=0;
				foreach ($domv2 as $k => $v) {
					$row++;
					$se = array('>', '<');$re = array('&gt;', '&lt;');
					$v = str_replace($se, $re, $v);
					$xml .= "<trans-unit id=\"$row\"><source>$k</source><target>$v</target></trans-unit>\n";
				}
				$xml.="</body></file></xliff>";
				file_put_contents("protected/config/messages/messages.".$org."$language.xml", $xml);
			}
		}
	}

	/**
	 * Permet de charger le catalogue contenant les messages de la langue choisie
	 *
	 * @param unknown_type $calledFromPage
	 */

	public function setLanguageCatalogue($calledFromPage,$org = null)
	{
		if(!isset($_SESSION['selectedorg'])){
			Atexo_Controller_Front::setOrg();
		}
		if(!$org) {
			$org = $_SESSION[ 'selectedorg' ];
		}

		$organisme = $org;
		$org = $org . ".";

		$languesActive = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		$arrayLanguesActives = array();
		$arrayLanguesActives[] = 'atx';
		foreach($languesActive as $lang) {
			self::generateXliffByLanguage($lang,$organisme);
			$arrayLanguesActives[] = $lang;
		}

		$globalization = Prado::getApplication()->Modules["globalization"];
		if ($calledFromPage === "citoyen" || $calledFromPage === "agent"  || $calledFromPage === "admin" || $calledFromPage === "ressource" ) {

			if (!isset($_GET['lang']) or !in_array($_GET['lang'], $arrayLanguesActives)) {
				{
					if (!(Atexo_User_CurrentUser::readFromSession("lang"))) {
						if ($calledFromPage === "citoyen") {
							$langueEnSession = Atexo_Config::getParameter('LANGUE_PAR_DEFAUT_CITOYEN');
						} else {
							$langueEnSession = Atexo_Config::getParameter('LANGUE_PAR_DEFAUT_AGENT');
						}
					}
					else {
						$langueEnSession = Atexo_User_CurrentUser::readFromSession("lang");
					}
				}
			}
			else {
				$langueEnSession = $_GET['lang'];
			}

			// Enregistrement en session
			Atexo_User_CurrentUser::writeToSession("lang", $langueEnSession);
			$globalization->setTranslationCatalogue("messages.". $org. $langueEnSession);

		}
	}

	/****
	 * retourne l'abréviation de la langue disponible par rapport à la langue passée en parametre
	 * @param l'acronyme de la langue
	 */
	public function getAvailableLanguageAbbreviation($lang)
	{
		if(strcmp($lang, Atexo_Config::getParameter('ABREVIATION_LANGUE_AR')) == 0) {
			return self::getLanguageAbbreviation(Atexo_Config::getParameter('ABREVIATION_LANGUE_AR'));
		} else {
			return "";
		}

	}
}
