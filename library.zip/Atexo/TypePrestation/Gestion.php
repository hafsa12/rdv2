<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_TypePrestation_Gestion {

	/**
	 * retourne un tableau de type-prestations de la table "TTypePrestation"
	 * @param $lang, $idEtab : l'id d'établissement, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de type-prestations la table "TTypePrestation"
	 */
	public function getTypePrestationByIdEtab($lang,$idEtab,$valeurParDefaur = false,$visible=false, $onlyWithPrestation=false, $withGroupe = false, $idGroupe = null){
		try {
			$arrayPres = array ();
			$connexion = Propel:: getConnection ( Atexo_Config::getParameter ( "DB_NAME" ) . Atexo_Config::getParameter ( "CONST_READ_ONLY" ) );
			$c = new Criteria();
			if ( !is_numeric ( $idEtab ) ) {
				$idEtab = 0;
			}
			if($idEtab>0) {
				$c->add ( TTypePrestationPeer::ID_ETABLISSEMENT, $idEtab );
			}else {
				if (Atexo_User_CurrentUser::isAdminOrg()) {
					$c->addJoin(TTypePrestationPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT);
					$c->add(TEtablissementPeer::ID_ORGANISATION, Atexo_User_CurrentUser::getIdOrganisationGere());
				}
				elseif (Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
					$c->add(TTypePrestationPeer::ID_ETABLISSEMENT, explode(",", Atexo_User_CurrentUser::getIdEtablissementGere()), Criteria::IN);
				} else {
					$c->add(TTypePrestationPeer::ID_ETABLISSEMENT, 0);
				}
			}
			if ( $visible ) {
				$c->add ( TTypePrestationPeer::VISIBLE_CITOYEN, "1" );
			}
			if($onlyWithPrestation) {
				$c->addJoin(TTypePrestationPeer::ID_TYPE_PRESTATION, TPrestationPeer::ID_TYPE_PRESTATION);
				$c->addJoin(TPrestationPeer::ID_PRESTATION,TAgendaPeer::ID_PRESTATION);
				$c->addJoin(TAgendaPeer::ID_AGENT,TAgentPeer::ID_AGENT);
				$c->add(TAgentPeer::ACTIF,1);
			}
			if($withGroupe) {
				$c->addJoin(TTypePrestationPeer::ID_REF_TYPE_PRESTATION, TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION, Criteria::LEFT_JOIN);
				$c->addAscendingOrderByColumn(TRefTypePrestationPeer::ID_GROUPE);
			}
			$arrayObjetPres = TTypePrestationPeer::doSelect ( $c, $connexion );
			
			if ( $valeurParDefaur ) {
				$arrayPres[ 0 ] = $valeurParDefaur;
			}
			//$seen = array();
			$hasGroupe = false;
			$presIds = [];
			foreach ( $arrayObjetPres as $pres ) {
				if($withGroupe){
					if($pres->getTRefTypePrestation())
						$groupe = $pres->getTRefTypePrestation()->getTGroupe();
					if($groupe){
						$hasGroupe = true;
						$arrayPres[$pres->getIdTypePrestation()] = array(	"GROUPE" => $groupe->getLibelleGroupeTraduit($lang),
												"NOM_TYPE_PRESTATION" => $pres->getLibelleTypePrestationTraduit ( $lang, $_SESSION["typePrestation"] ),
												"ID_TYPE_PRESTATION" => $pres->getIdTypePrestation ());
                        // si la prestation appartient au groupe souhaité
                        if(!is_null($idGroupe) && $groupe->getIdGroupe() == $idGroupe){
                           $presIds[] = $pres->getIdTypePrestation();
                        }
					}else{
						$arrayPres[$pres->getIdTypePrestation()] = array(   "GROUPE" => $pres->getLibelleTypePrestationTraduit( $lang, $_SESSION["typePrestation"] ),
												"NOM_TYPE_PRESTATION" => $pres->getLibelleTypePrestationTraduit( $lang, $_SESSION["typePrestation"] ),
												"ID_TYPE_PRESTATION" => $pres->getIdTypePrestation());
					}
				
				}else{
					$arrayPres[ $pres->getIdTypePrestation () ] = $pres->getLibelleTypePrestationTraduit ( $lang, $_SESSION["typePrestation"] );
				}
			}
            if($withGroupe && !$hasGroupe){
				foreach(array_keys($arrayPres) as $key) {
					if(isset($arrayPres[$key]["GROUPE"]))
						unset($arrayPres[$key]["GROUPE"]);
				}
			}
            //supprimer les autres prestations si le groupe souhaité existe dans l'établissemant séléctionnée
            if(count($presIds) > 0){
                $arrayPres = array_intersect_key($arrayPres, array_flip($presIds));
                if ( $valeurParDefaur ) {
                    $arrayPres = [0=>$valeurParDefaur]+$arrayPres;
                }
            }
            uasort($arrayPres, function($a1, $a2){
                if(isset($a1['NOM_TYPE_PRESTATION']))
                    return $a1['NOM_TYPE_PRESTATION'] > $a2['NOM_TYPE_PRESTATION'];
            });
			return $arrayPres;
		}catch (Exception $e) {
			throw $e;
		}
	}

	/**
	 * retourne un tableau de type-prestations de la table "TTypePrestation"
	 * @param $lang, $idEtab : l'id d'établissement, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de type-prestations la table "TTypePrestation"
	 */
	public function getRefTypePrestationByIdEtab($lang,$idEtab,$valeurParDefaur = false){
		try {
			$arrayPres = array ();
			$connexion = Propel:: getConnection ( Atexo_Config::getParameter ( "DB_NAME" ) . Atexo_Config::getParameter ( "CONST_READ_ONLY" ) );
			$c = new Criteria();
			$c->addJoin(TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION, TTypePrestationPeer::ID_REF_TYPE_PRESTATION);
			if($idEtab>0) {
				$c->add ( TTypePrestationPeer::ID_ETABLISSEMENT, $idEtab );
			}else {
				if (Atexo_User_CurrentUser::isAdminOrg()) {
					$c->addJoin(TTypePrestationPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT);
					$c->add(TEtablissementPeer::ID_ORGANISATION, Atexo_User_CurrentUser::getIdOrganisationGere());
				}
				elseif (Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
					$c->add(TTypePrestationPeer::ID_ETABLISSEMENT, explode(",", Atexo_User_CurrentUser::getIdEtablissementGere()), Criteria::IN);
				} else {
					$c->add(TTypePrestationPeer::ID_ETABLISSEMENT, 0);
				}
			}
			$arrayObjetPres = TRefTypePrestationPeer::doSelect ( $c, $connexion );
			if ( $valeurParDefaur ) {
				$arrayPres[ 0 ] = $valeurParDefaur;
			}

			foreach ( $arrayObjetPres as $pres ) {
				$arrayPres[ $pres->getIdRefTypePrestation () ] = $pres->getLibelleRefTypePrestationTraduit ( $lang );//Traduit($lang);
			}
			return $arrayPres;
		}catch (Exception $e) {
			throw $e;
		}
	}
	
	/**
	 * retourne un tableau de type-prestations gérées de la table "TTypePrestation" et "TEtablissement"
	 * @param $lang, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de type-prestations gérées la table "TTypePrestation" et "TEtablissement"
	 */
	public function getTypePrestationGere($lang,$valeurParDefaur = false){
		$arrayPres = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		
		if(Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
			$c->add(TTypePrestationPeer::ID_ETABLISSEMENT,explode(",",Atexo_User_CurrentUser::getIdEtablissementGere()), Criteria::IN);
		}
		
		if(Atexo_User_CurrentUser::isAdminOrg()) {
			$c->addJoin(TTypePrestationPeer::ID_ETABLISSEMENT,TEtablissementPeer::ID_ETABLISSEMENT);
			$c->add(TEtablissementPeer::ID_ORGANISATION,Atexo_User_CurrentUser::getIdOrganisationGere());
		}
		
		$arrayObjetPres = TTypePrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayPres[0] = $valeurParDefaur;
		}

		foreach($arrayObjetPres as $pres){
			$arrayPres[$pres->getIdTypePrestation()] = $pres->getLibelleTypePrestationTraduit($lang);//Traduit($lang);
		}
		return $arrayPres;
	}

	/**
	 * retourne un tableau de types prestation de la table "TTypePrestation"
	 * @param $lang, $idRefTypePres : l'id de refTypePrestation, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de types prestation la table "TTypePrestation"
	 */
	public function getTypePrestationByIdRefTypePrestation($lang,$idRefTypePres,$valeurParDefaur = false){
		$arrayTypePres = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TTypePrestationPeer::ID_REF_TYPE_PRESTATION, $idRefTypePres);
		$arrayObjetTypePres = TTypePrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayTypePres[0] = $valeurParDefaur;
		}

		foreach($arrayObjetTypePres as $typePres){
			$arrayTypePres[$typePres->getIdTypePrestation()] = $typePres->getLibelleTypePrestationTraduit($lang);
		}
		return $arrayTypePres;
	}

}
