<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_TypePrestation_CriteriaVo{

	private $idTypePrestation;
	private $idRefTypePrestation;
	private $motCle = null;
	private $lang;
	private $sortByElement="";
	private $sensOrderBy="ASC";
	private $offset=0;
	private $limit=0;
	private $organisation=false;
	private $_idOrganisation;
	private $etablissement=false;
	private $_idEtablissement;
	private $count = false;
	private $_pages = false;
	private $_pageSize = false;
	private $_idEntite = false;
	private $_entite1 = false;
	private $_entite2 = false;
	private $_entite3 = false;
	private $_prestationReferentiel = false;
    private $_findOne = false;

	public function getIdTypePrestation()
	{
		return $this->idTypePrestation;
	}

	public function setIdTypePrestation($idTypePrestation)
	{
		$this->idTypePrestation = $idTypePrestation;
	}

	public function getIdRefTypePrestation()
	{
		return $this->idRefTypePrestation;
	}

	public function setIdRefTypePrestation($idRefTypePrestation)
	{
		$this->idRefTypePrestation = $idRefTypePrestation;
	}

	public function getMotCle()
	{
		return $this->motCle;
	}

	public function setMotCle($motCle)
	{
		$this->motCle = $motCle;
	}

	public function getLang()
	{
		return $this->lang;
	}

	public function setLang($lang)
	{
		$this->lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->offset;
	}

	public function setOffset($offset)
	{
		$this->offset = $offset;
	}

	public function getLimit()
	{
		return $this->limit;
	}

	public function setLimit($limit)
	{
		$this->limit = $limit;
	}

	public function getOrganisation()
	{
		return $this->organisation;
	}

	public function setOrganisation($organisation)
	{
		$this->organisation = $organisation;

	}
	public function getIdOrganisation()
	{
		return $this->_idOrganisation;
	}

	public function setIdOrganisation($idOrganisation)
	{
		$this->_idOrganisation = $idOrganisation;
	}
	public function getEtablissement()
	{
		return $this->etablissement;
	}

	public function setEtablissement($etablissement)
	{
		$this->etablissement = $etablissement;

	}
	public function getIdEtablissement()
	{
		return $this->_idEtablissement;
	}

	public function setIdEtablissement($idEtablissement)
	{
		$this->_idEtablissement = $idEtablissement;
	}


	public function getCount()
	{
		return $this->count;
	}

	public function setCount($count)
	{
		$this->count = $count;

	}

	public function getPages()
	{
		return $this->_pages;
	}

	public function setPages($p)
	{
		$this->_pages = $p;
	}

	public function getPageSize()
	{
		return $this->_pageSize;
	}

	public function setPageSize($ps)
	{
		$this->_pageSize = $ps;
	}

	public function getIdEntite()
	{
		return $this->_idEntite;
	}

	public function setIdEntite($idEntitie)
	{
		$this->_idEntite = $idEntitie;
	}

	public function getEntite1()
	{
		return $this->_entite1;
	}

	public function setEntite1($entitie1)
	{
		$this->_entite1 = $entitie1;
	}

	public function getEntite2()
	{
		return $this->_entite2;
	}

	public function setEntite2($entitie2)
	{
		$this->_entite2 = $entitie2;
	}

	public function getEntite3()
	{
		return $this->_entite3;
	}

	public function setEntite3($entitie3)
	{
		$this->_entite3 = $entitie3;
	}

    public function getPrestationReferentiel()
    {
        return $this->_prestationReferentiel;
    }

    public function setPrestationReferentiel($pr)
    {
        $this->_prestationReferentiel = $pr;
    }

    public function getFindOne()
    {
        return $this->_findOne;
    }

    public function setFindOne($v)
    {
        $this->_findOne = $v;
    }
}