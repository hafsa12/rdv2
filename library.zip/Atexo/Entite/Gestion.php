<?php
class Atexo_Entite_Gestion {
	
	
	/**
	 * retourne un tableau d'entites de la table "TEntite"
	 * @param $niveau : 1,2 ou 3 pour avoir region,province ou commune, $lang, $idParent : id entite parent, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau d'entites la table "TEntite"
	 */
	public function getAllEntite($niveau,$lang,$idParent=null,$valeurParDefaur = false){
		$arrayEntite = array();
		
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TEntitePeer::NIVEAU,$niveau);
		if($idParent) {
			$comparaison = Criteria::EQUAL;
			if(is_array($idParent)) {
				$comparaison = Criteria::IN;
			}
			$c->add(TEntitePeer::ID_ENTITE_PARENT,$idParent, $comparaison);
		}
		$arrayObjetEntite = TEntitePeer::doSelect($c,$connexion);

		foreach($arrayObjetEntite as $entite){
			$arrayEntite[$entite->getIdEntite()] = $entite->getLibelleTraduit($lang);
		}
		asort($arrayEntite);
		if($valeurParDefaur){
			$arrayEntite = array( 0 => $valeurParDefaur ) + $arrayEntite;
		}
		return $arrayEntite;
	}

	public function getAllIdChildEntite($idParent){
		$arrayEntite = array($idParent=>$idParent);

		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		if($idParent) {
			$c->add(TEntitePeer::ID_ENTITE_PARENT, $idParent);
		}
		$arrayObjetEntite = TEntitePeer::doSelect($c,$connexion);

		foreach($arrayObjetEntite as $entite){
			$arrayEntite[$entite->getIdEntite()] = $entite->getIdEntite();
			$arrayEntite += self::getAllIdChildEntite($entite->getIdEntite());
		}
		return $arrayEntite;
	}
	
}