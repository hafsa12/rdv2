<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_DelaiObtention_CriteriaVo{

	private $_lang;
	private $_sortByElement = "";
	private $_sensOrderBy = "DESC";
	private $_offset = 0;
	private $_limit = 0;
	private $_count = false;
	private $_dateDu;
	private $_dateAu;
	private $_idTypePrestation;
	private $_idRefTypePrestation;
	private $_idPrestation;
	private $_idRefPrestation;
	private $_idEtablissementAttache;
	private $_idOrganisationAttache;
	private $_idEntite;
	private $_prestationReferentiel = false;
    private $_idTypeEtablissement;

	public function getIdEntite()
	{
		return $this->_idEntite;
	}

	public function setIdEntite($entite)
	{
		$this->_idEntite = $entite;
	}

	public function getLang()
	{
		return $this->_lang;
	}

	public function setLang($lang)
	{
		$this->_lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->_sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->_sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->_sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->_sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->_offset;
	}

	public function setOffset($offset)
	{
		$this->_offset = $offset;
	}

	public function getLimit()
	{
		return $this->_limit;
	}

	public function setLimit($limit)
	{
		$this->_limit = $limit;
	}

	public function getCount()
	{
		return $this->_count;
	}

	public function setCount($count)
	{
		$this->_count = $count;
	}
	public function getDateAu()
	{
		return $this->_dateAu;
	}
	public function setDateAu($dateAu)
	{
		$this->_dateAu = $dateAu;
	}
	public function getDateDu()
	{
		return $this->_dateDu;
	}
	public function setDateDu($dateDu)
	{
		$this->_dateDu = $dateDu;
	}
	public function getIdTypePrestation()
	{
		return $this->_idTypePrestation;
	}

	public function setIdTypePrestation($idTypePrestation)
	{
		$this->_idTypePrestation = $idTypePrestation;
	}
	public function getIdPrestation()
	{
		return $this->_idPrestation;
	}

	public function setIdPrestation($idPrestation)
	{
		$this->_idPrestation = $idPrestation;
	}
	public function getIdRefPrestation()
	{
		return $this->_idRefPrestation;
	}

	public function setIdRefPrestation($idRefPrestation)
	{
		$this->_idRefPrestation = $idRefPrestation;
	}
	public function setIdEtablissementAttache($value)
	{
		$this->_idEtablissementAttache = $value;
	}
	public function getIdEtablissementAttache()
	{
		return $this->_idEtablissementAttache;
	}
	public function setIdOrganisationAttache($value)
	{
		$this->_idOrganisationAttache = $value;
	}
	public function getIdOrganisationAttache()
	{
		return $this->_idOrganisationAttache;
	}

	public function getPrestationReferentiel()
	{
		return $this->_prestationReferentiel;
	}

	public function setPrestationReferentiel($pr)
	{
		$this->_prestationReferentiel = $pr;
	}

	/**
	 * @return mixed
	 */
	public function getIdRefTypePrestation()
	{
		return $this->_idRefTypePrestation;
	}

	/**
	 * @param mixed $idRefTypePrestation
	 */
	public function setIdRefTypePrestation($idRefTypePrestation)
	{
		$this->_idRefTypePrestation = $idRefTypePrestation;
	}

    /**
     * @return mixed
     */
    public function getIdTypeEtablissement()
    {
        return $this->_idTypeEtablissement;
    }

    /**
     * @param mixed $idTypeEtablissement
     */
    public function setIdTypeEtablissement($idTypeEtablissement)
    {
        $this->_idTypeEtablissement = $idTypeEtablissement;
    }


}