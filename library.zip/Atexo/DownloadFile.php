<?php

/**
 * Telechargement
 * @category Atexo
 * @package Atexo_DownloadFile
 */
class Atexo_DownloadFile extends Api_DownloadFile 
{

	/**
	 * Permet de télécharger un fichier
	 *
	 * @param string $file_name le nom du fichier
	 * @param object $connection la connection
	 */
	public static function downloadFiles($idFichier, $nomFichier=null)
	{
		if($nomFichier==null) {
			$tBlobQuery = new TBlobQuery();
			$tBlob = $tBlobQuery->getBlobById($idFichier);
			$nomFichier = $tBlob->getNomBlob();
		}
$filename=Atexo_Config::getParameter("PATH_FILE")."/".$idFichier;
header('Content-type:application/pdf');
header('Content-Disposition: inline;filename="'.$nomFichier.'.pdf"');
header('Content-Transfer-Encoding: binary');
//header('Accept-Ranges: bytes');

//$url=URL.createObjectURL($tBlob);
//window.open(,$nomFichier);

//readfile($filename);
//echo '<img src="/'.$filename.'"/>';
//Navigator.msSaveOrOpenBlob($tBlob,$nomFichier);
parent::downloadFiles(Atexo_Config::getParameter("PATH_FILE")."/".$idFichier, $nomFichier);
//parent::downloadFileContent($nomFichier,readfile($filename));
	}
}
