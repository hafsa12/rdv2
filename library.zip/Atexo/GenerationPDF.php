<?php
require_once('protected/library/vendors/vendor/tecnickcom/tcpdf/tcpdf.php');

class Atexo_GenerationPDF extends TCPDF
{

}