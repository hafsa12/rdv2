<?php
/**
 * Contrôleur frontal de toute application mpe
 *
 * @author Guillaume Ponçon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage controller
 * @todo mettre les fichiers statiques en cache sauf mode débogage
 */
class Atexo_Controller_Front
{
	// Codes d'information du routeur de fichiers statiques
	const THEMES_NOT_FOUND = false;
	const THEMES_ORGANISM  = 0x01;
	const THEMES_PORTAL    = 0x02;
	const THEMES_MPE       = 0x04;
	const VERSION_PROPEL   = "propel";

	private static $currentOrganism = null;

	/**
	 * Route la requête vers le bon contrôleur ou le bon fichier.
	 *
	 * @return boolean
	 */
	public static function run()
	{

        // on construit le application.xml
		self::buildConfigurationFile();
		self::prepare();
		//Gestion de la charte selon nom de domaine
		self::setOrg();

		$url = Api_Front::getUrlRelative();
		if ($url == '/' || $url == '/index.php') {
			if($_SERVER['REQUEST_URI'] == '/' &&  isset($_COOKIE['selectedorg'])) {
				Api_Front::unsetCookie('selectedorg');
				Api_Front::unsetCookie('design');
			}
			Atexo_Controller_Prado::run();
		} else if (strpos($url, '/themes') === 0) {
			if (! self::displayThemeFileContent()) {
				Api_Front::erreur404();
			}
		} else if (strpos($url, '/pages') === 0) {
			if (! self::displayPhpFileContent()) {
				Api_Front::erreur404();
			}
		} else if (strpos($url, '/admin') === 0 || strpos($url, '/administration') === 0) {
			header("Location: " . Atexo_Utils_Util::getAbsoluteUrl() . "?page=administration.AdministrationAccueil");
			exit();
		}  else if (!in_array($url,array('tmp','logs','common')) && is_dir(realpath(Atexo_Config::getParameter('BASE_ROOT_DIR').$url))) {
			if (substr(realpath(Atexo_Config::getParameter('BASE_ROOT_DIR').$url), 0, strlen(Atexo_Config::getParameter('BASE_ROOT_DIR'))) == Atexo_Config::getParameter('BASE_ROOT_DIR')) {
				$design = eregi_replace("[^-_[:alnum:]]", "", $url);
				setcookie('design', $design, 0, '/');
				$_COOKIE['design'] = $design;
				setcookie('selectedorg', $design, 0, '/');
				$_COOKIE['selectedorg'] = $design;
				$myurl = substr($_SERVER['REQUEST_URI'], strpos($_SERVER['SCRIPT_NAME'], '/index.php'));
				$myurl = substr($myurl, strlen($url));
				if (strlen($myurl) == 0){ 
					$myurl = "?page=citoyen.Accueil";
				}
				header("Location: " . Atexo_Utils_Util::getAbsoluteUrl() . $myurl);
				exit();
			} else {
				Api_Front::erreur404('ressources/pages/error404.html');
			}
		}
		else {
			Api_Front::erreur404('ressources/pages/error404.html');
		}
		return true;
	}
	
	public static  function prepare() {
		// Gestion TimeZone
		if (Atexo_Config::getParameter('TIMEZONE') !== 'Europe/Paris') {
			date_default_timezone_set(Atexo_Config::getParameter('TIMEZONE'));
		}
		// Gestion charte graphique
		if (isset($_GET['design'])) {
			Api_Front::cookieDesign();
		}
		if (isset($_GET['selectedorg'])) {
			Api_Front::selectedOrg();
		}
	}

	/**
	 * Retourne le chemin pour le theme
	 * Si un dossier organisme existe dans /themes alors on va chercher dans /themes/orga sinon /themes
	 * TODO : portal
	 */
	public static function getThemesPath()
	{
		if (self::$currentOrganism === null) {
			self::$currentOrganism = false;
		}
		if (self::$currentOrganism !== false/* && file_exists(self::getRootPath(). '/themes/' . self::$currentOrganism)*/) {
			$sub = '/' . self::$currentOrganism;
		}
		else if (isset($_COOKIE['design'])) $sub = '/' . $_COOKIE['design'];
		else {
			$sub = '';
		}
		return "themes$sub";
/*
		if ($_GET['lang']) {
			$langChoisie = $_GET['lang'];
		}elseif (Atexo_User_CurrentUser::readFromSession("lang")) {
			$langChoisie = Atexo_User_CurrentUser::readFromSession("lang");
		}
		 
		return Api_Front::getThemesPath($langChoisie,self::getRootPath());*/
	}

	/**
	 * Page PHP mise en cache
	 * TODO : gérer le multi-thèmes et la langue !
	 * @return integer
	 */
	private static function displayPhpFileContent()
	{
		$lang = '';
		
		if(!isset($_SESSION)){
			session_start();
		}
		if(isset($_SESSION['lang']) && strlen($_SESSION['lang']) > 1 && strpos(Api_Front::getUrlRelative(), ".".$_SESSION['lang']) !== false) {
			$lang = $_SESSION['lang'];
		}
		return Api_Front::displayPhpFileContent(self::getRootPath(), Atexo_Config::getParameter('URL_INTERNE'), Atexo_Config::getParameter('PROJECT_NAME'), $lang);
	}
	
	private  static function getCurrentOrganisme() {
		$currentOrganism = self::$currentOrganism;
		if (trim($currentOrganism) == '') { 
			$currentOrganism = false;
		}
		if(isset($_COOKIE['design'])) { 
			$currentOrganism = false;
		}
		if ($_GET['lang']) {
			$langChoisie = $_GET['lang'];
		}elseif (Atexo_User_CurrentUser::readFromSession("lang")) {
			$langChoisie = Atexo_User_CurrentUser::readFromSession("lang");
		}
		if (self::hasThemeSpecifique($langChoisie)) {
			$currentOrganism = $langChoisie;
		}
		return $currentOrganism;
	}

	/**
	 * Affiche le contenu du fichier statique demandé avec le bon type mime.
	 *
	 * @return integer statut de l'affichage (organisme, portail, ape, erreur)
	 */
	private static function displayThemeFileContent()
	{
		$urlRelative = substr(Api_Front::getUrlRelative(), strlen('/themes'));
		$currentOrganism = self::getCurrentOrganisme();

		// Tentative d'extraction du fichier dans le thème de l'organisme courant
		if ($currentOrganism !== false || isset($_COOKIE['design'])) {
			$result = self::extraction($urlRelative, $currentOrganism);
			if($result!=null) {
				return $result;
			}
		}

		$urlRelative = substr(Api_Front::getUrlRelative(), strlen('/themes')); // /css/styles.css
		$filePath = Atexo_Config::getParameter('BASE_ROOT_DIR') . $urlRelative;
		 
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $urlRelative, $filePath);
			return self::THEMES_PORTAL;
		}
		if (strpos($urlRelative, 'logo-organisme') > 1) {
			$urlRelative = substr($urlRelative, strpos($urlRelative, '/', 1));
		}

		if (Atexo_Config::getParameter("THEMES_SECTION") != '') {
			$filePath = self::getRootPath() . '/themes/' . Atexo_Config::getParameter("THEMES_SECTION") . $urlRelative;
			if ($data = self::fileGetContent($filePath)) {
				self::displayStaticFile($data, $urlRelative, $filePath);
				return self::THEMES_PORTAL;
			}
			//		$urlRelative = substr(Api_Front::getUrlRelative(), strlen('/themes'));
			if (strpos($urlRelative, 'css') === false && strpos($urlRelative, Atexo_Config::getParameter("THEMES_SECTION")) !== false)
			{
				$urlRelative = substr($urlRelative, strlen(Atexo_Config::getParameter("THEMES_SECTION").'/'));
			}
		}
		// Tentative d'extraction dans themes client (orga)
		$filePath = self::getRootPath() . '/themes' . $urlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $urlRelative, $filePath);
			return self::THEMES_PORTAL;
		}

		// Tentative d'extraction dans le thème du portail
		$filePath = self::getRootPath() . '/../themes' . $urlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $urlRelative, $filePath);
			return self::THEMES_PORTAL;
		}

		// Tentative d'extraction dans le thème du portail
		$filePath = self::getRootPath() . '/../themes/portal' . $urlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $urlRelative, $filePath);
			return self::THEMES_PORTAL;
		}

		// Tentative d'extraction dans le thème
		$filePath = self::getRootPath() . '/protected/themes' . $urlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $urlRelative, $filePath);
			return self::THEMES_MPE;
		}

		$extension = strrchr($urlRelative, '.');
		if($extension == '.js') {
			$result = self::getJs($currentOrganism, $urlRelative);
			if($result!=null) {
				return $result;
			}
		}

		// Pas trouvé.
		return self::THEMES_NOT_FOUND;
	}
	
	private static function extraction($urlRelative, $currentOrganism) {
		$filePath = self::getRootPath() . '/themes' .  $urlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $urlRelative, $filePath);
			return self::THEMES_ORGANISM;
		}
		$trueUrlRelative = $urlRelative; // url en tampon pour recherche globale (sans orga)
		if ($currentOrganism !== false) {
			$urlRelative = substr(Api_Front::getUrlRelative(), strlen('/themes/' . $currentOrganism));
		}
		else {
			$urlRelative = substr(Api_Front::getUrlRelative(), strlen('/themes/' . $_COOKIE['design']));
		}

		if (strpos($_COOKIE['design'], '__') !== false) {
			$sub = substr($_COOKIE['design'], 0, (strpos($_COOKIE['design'], '__')));
			$filePath = self::getRootPath() . '/themes/' . $sub . $urlRelative;
			if ($data = self::fileGetContent($filePath)) {
				self::displayStaticFile($data, $trueUrlRelative, $filePath);
				return self::THEMES_PORTAL;
			}
		}
		$filePath = self::getRootPath() . '/../themes' . $trueUrlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $trueUrlRelative, $filePath);
			return self::THEMES_PORTAL;
		}

		// Tentative d'extraction dans le thème du portail
		$filePath = self::getRootPath() . '/themes' . $urlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $trueUrlRelative, $filePath);
			return self::THEMES_PORTAL;
		}

		// Tentative d'extraction dans le thème MPE
		$filePath = self::getRootPath() . '/protected/themes' . $urlRelative;
		if ($data = self::fileGetContent($filePath)) {
			self::displayStaticFile($data, $trueUrlRelative, $filePath);
			return self::THEMES_MPE;
		}
		return null;
	}
	
	private static function getJs($currentOrganism, $urlRelative) {
		if ($currentOrganism !== false) {
			$urlRelativeTmp = substr($urlRelative, strlen($currentOrganism) + 1);
			$name = split('\.', $urlRelativeTmp);
		} elseif (isset($_COOKIE['design'])) {
			$urlRelativeTmp = substr($urlRelative, strlen($_COOKIE['design']) + 1);
			$name = split('\.', $urlRelativeTmp);
		} else {
			$name = split('\.', $urlRelative);
		}
		if ($name[1] == 'js') { 
			$name[1] = 'fr';
		}
		$lang = $name[1];
		$org = $currentOrganism.'.'.$lang;
		if (is_file(self::getRootPath() . '/protected/themes' . $name[0] . ".js.php")
		&& is_file(self::getRootPath() . '/protected/config/messages/messages.' . $org . '.xml')) {
			Api_Util::XliffToArray(self::getRootPath() .'/protected/config/messages/messages.' . $lang . '.xml');
			
			$file = file_get_contents(self::getRootPath() .'/protected/themes' . $name[0] . ".js.php");
			if (Atexo_Config::getParameter('HTTP_ENCODING') == 'utf-8') {
				$js = preg_replace("/<\?php Prado::localize\('([^']+)'\) \?./e", "\$xml['\\1']", $file);
			} else {
				$js = preg_replace("/<\?php Prado::localize\('([^']+)'\) \?./e", "utf8_decode(\$xml['\\1'])", $file);
			}
			ob_start();
			eval("?>" .$js."<?");
			$js = ob_get_clean();
			self::displayStaticFile($js, $urlRelative, self::getRootPath() . '/protected/themes' . $name[0] . ".js.php");
			return self::THEMES_MPE;
		}
		return null;
	}

	/**
	 * Repère le type mime d'un fichier et affiche son contenu.
	 *
	 * @param string $content
	 * @param string $url
	 * @return boolean
	 */
	private static function displayStaticFile($content, $url, $fileName)
	{
		return Api_Front::displayStaticFile($content, 
									$url, 
									$fileName,
									self::getRootPath(),
									Atexo_Config::getParameter('CACHE_THEMES_JS'),
									Atexo_Config::getParameter('CACHE_THEMES'),
									Atexo_Config::getParameter('THEMES_FILES_NOT_CACHED'));
	}

	/**
	 * Retourne le chemin absolu vers la racine de l'application MPE.
	 *
	 * @return string
	 */
	public static function getRootPath()
	{
		static $mpePath = null;

		if ($mpePath === null) {
			$mpePath = realpath(dirname(__FILE__) . '/../../../..');
		}
		return $mpePath;
	}
	public static function setOrg(){

		$acronyme = null;
		if (!isset($_COOKIE['selectedorg'])  ||  !isset($_COOKIE['idOrg']) || !isset($_SESSION['idOrg'])) {
			$domaineName = $_SERVER['SERVER_NAME'];
			$dbh = new PDO('mysql:host='.Atexo_Config::getParameter('HOSTSPEC').';dbname='.Atexo_Config::getParameter('DB_PREFIX').'_'.Atexo_Config::getParameter('DB_NAME').'', Atexo_Config::getParameter('USERNAME'), Atexo_Config::getParameter('PASSWORD'));
			$stmt = $dbh->prepare("SELECT ID_ORGANISATION, ACRONYME, TYPE_PRESTATION, RESSOURCE FROM `T_ORGANISATION` WHERE `T_ORGANISATION`.`NOM_DOMAINE` like '%".$domaineName."%'");
			$stmt->setFetchMode(PDO::FETCH_ASSOC);
			$stmt->execute();
			$result = $stmt->fetchAll();
			session_start();
			if($result){
				$acronyme = $result[0]['ACRONYME'];

				$_COOKIE['idOrg'] = $result[0]['ID_ORGANISATION'];
				setcookie('idOrg', $result[0]['ID_ORGANISATION']);
				$_SESSION['idOrg'] = $result[0]['ID_ORGANISATION'];

				$_COOKIE['typePrestation'] = $result[0]['TYPE_PRESTATION'];
				setcookie('typePrestation', $result[0]['TYPE_PRESTATION']);
				$_SESSION['typePrestation'] = $result[0]['TYPE_PRESTATION'];

				$_COOKIE['typeRessource'] = $result[0]['RESSOURCE'];
				setcookie('typeRessource', $result[0]['RESSOURCE']);
				$_SESSION['typeRessource'] = $result[0]['RESSOURCE'];
			}

			if ($acronyme) {
				setcookie('selectedorg', $acronyme);
				$_COOKIE['selectedorg'] = $acronyme;
				$_SESSION['selectedorg'] = $acronyme;
			} else {
				unset($_COOKIE['selectedorg']);
				setcookie('selectedorg', '', time() - 86400);
			}
		}

		if(!self::$currentOrganism){
			self::$currentOrganism = $_COOKIE['selectedorg'];
		}
	}
	/**
	 * Retourne le contenu d'un fichier, avec une compilation préalable si celui-ci est semi-statique.
	 *
	 * @param string $filePath
	 * @param boolean $checkPhpFile
	 * @return string|boolean
	 */
	private static function fileGetContent($filePath, $checkPhpFile = true)
	{
		if ($checkPhpFile && Api_Front::isStaticPhpFile($filePath)) {
			ob_start();
			include $filePath . '.php';
			return ob_get_clean();
		}
		if (file_exists($filePath)) {
			if (strpos($filePath, 'styles.css') && $filePath != self::getRootPath() . '/'.Atexo_Config::getParameter('PROJECT_NAME').'/protected/themes/css/styles.css') {
				$css = file_get_contents($filePath);
				if (strpos($css, '@import url') !== false) {
					$css = preg_replace('/@import url\("([^"]+)"\);/e', 
							"\"\n/***********************************/\n/** couleur \\1 **/\n\" . 
							file_get_contents(self::getRootPath() . '/'.Atexo_Config::getParameter('PROJECT_NAME').'/protected/themes/css/' . '\\1') .
							 \"\n/** fin couleur \\1 **/ \n/***********************************/\n\"", 
							$css);
				}
				return file_get_contents(self::getRootPath() . '/protected/themes/css/styles.css')."\n".$css;
			} else {
				return file_get_contents($filePath);
			}
		}
		return false;
	}

	/**
	 * Génère le fichier de configuration application.xml si ce n'est pas déjà fait.
	 *
	 * @return boolean
	 * @todo fusion des fichiers XML
	 */
	public static function buildConfigurationFile()
	{
		// Informations sur le fichier de configuration commun
		$commonConfigFile = self::getRootPath() . Atexo_Config::CONFIG_MPE_FILE;
		if (!file_exists($commonConfigFile)) {
			throw new Atexo_Controller_Front_Exception("The configuration file ". $commonConfigFile ." do not exists");
		}
		$commonConfigStat = stat($commonConfigFile);

		// Informations sur le fichier de configuration spécifique
		$specificConfigFile = self::getRootPath() . Atexo_Config::CONFIG_SPE_FILE;
		if (file_exists($specificConfigFile)) {
			$specificConfigStat = stat($specificConfigFile);
		} else {
			$specificConfigStat = false;
		}

		// Informations sur le fichier de configuration généré
		$generatedConfigFile = self::getRootPath() . Atexo_Config::CONFIG_GEN_FILE;
		if (file_exists($generatedConfigFile)) {
			$generatedConfigStat = stat($generatedConfigFile);
		} else {
			$generatedConfigStat = false;
		}

		// Génération du fichier de configuration s'il le faut
		if ($generatedConfigStat === false
		|| $generatedConfigStat['mtime'] < $commonConfigStat['mtime']
		|| $generatedConfigStat['mtime'] < $specificConfigStat['mtime']) {
			Atexo_Config::buildApplicationXmlFile();
		}

		return true;
	}

	/**
	 * Handler d'auto-chargement des classes de la plateforme Atexo.
	 *
	 * Ce handler remplace celui de Prado (PradoBase::autoload)
	 *
	 * @param string $className
	 */
	public static function autoload($className)
	{
		if (class_exists('Propel') && Propel::autoload($className)) {
			return true;
		}
		if (class_exists('Logger') && LoggerAutoloader::autoload($className)) {
			return true;
		}
		@include_once strtr($className, '_', DIRECTORY_SEPARATOR) . '.php';
	}

	public static function runCli($configFile)
	{
		Atexo_Controller_Prado::runCli($configFile);
	}

	public static function hasThemeSpecifique ($langue)
	{
		return false;
	}
}

/**
 * Fonction de raccourcis pour le chemin dynamique de l'image
 */
function t() {
	return Atexo_Controller_Front::getThemesPath();
}

spl_autoload_register(array('Atexo_Controller_Front', 'autoload'));
try{
	require_once(Atexo_Config::getParameter('PROPEL_FRAMEWORK_PATH') . '/Propel.php');
} catch (Exception $e) {
	return;
}
