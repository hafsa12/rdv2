<?php

/**
 * Classe de chargement (bootstrapper) du framework prado.
 *
 * @author Guillaume Ponéon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage controller
 */
class Atexo_Controller_Prado
{
	/**
	 * Chargement de Prado
	 *
	 * @return boolean
	 */
	public static function run()
	{
		return Api_Prado::run(Atexo_Controller_Front::getRootPath(), Atexo_Config::getParameter('PRADO_FRAMEWORK_PATH'));
	}

	/**
	 * Chargement de Prado en mode CLI
	 *
	 * @return boolean
	 */
	public static function runCli($configFile='')
	{
		if ($configFile == '') {
			$configFile = realpath(dirname(__FILE__) . '/../../../application.xml');
		}
		chdir(realpath(dirname(__FILE__) . '/../../../../'));
		return Api_Prado::runCli(Atexo_Config::getParameter('PRADO_FRAMEWORK_PATH'), $configFile);
	}
}
