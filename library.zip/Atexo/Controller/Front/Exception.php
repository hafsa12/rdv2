<?php

/**
 * Exception personnalis�e du contr�leur frontal
 *
 * @author Guillaume Pon�on <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage controller
 */
class Atexo_Controller_Front_Exception extends Atexo_Controller_Exception   
{}