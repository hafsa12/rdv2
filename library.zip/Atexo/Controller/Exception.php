<?php

/**
 * Exception sp�cifique du composant contr�leur d'Atexo
 *
 * @author Guillaume Pon�on <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage controller
 */
class Atexo_Controller_Exception extends Api_Exception  
{}