<?php

/** Atexo_Controller_Front */
require 'Front.php';

/**
 * Gestion du projet mpe en ligne de commandes
 *
 * @package Atexo
 * @subpackage Controller
 */
class Atexo_Controller_Cli extends Atexo_Cli
{
	private static $nameProject="atexo.rdv";

    /**
     * Bootstrap de la fonctionnalité.
     */
    public static function run()
    {
		
    	if ($_SERVER['argv'][1] != 'install') {
	        // On force la génération du fichier de config
	        Atexo_Controller_Front::buildConfigurationFile();
	
	       	if (!is_dir(Atexo_Config::getParameter("LOG_FILE_PATH"))) {
	            mkdir(Atexo_Config::getParameter("LOG_FILE_PATH"));
	        }
	
	        // On lance une application prado en mode Shell
	        $app = Atexo_Controller_Prado::runCli();
	        
	        // On force la langue par défaut à FR
        	$globalization = $app->Modules["globalization"];
       		$globalization->setTranslationCatalogue("messages.".Atexo_Config::getParameter('LANGUE_PAR_DEFAUT_CITOYEN'));
        } else {
            chdir(realpath(dirname(__FILE__) . '/../../../../'));
        }
        // Si on a pas de paramétres passé en argument, on affiche l'aide (qui force le exit)
        if ($_SERVER['argc'] < 2) {
            self::helpAction();
        }

        $command = ucfirst($_SERVER['argv'][1]);
        $className = 'Cli_' . $command;
        $return_code = 0;
        if (is_file(self::getRootPath() . '/'.self::$nameProject.'/protected/bin/Cli/' . $command . '.php')) {
            include self::getRootPath() . '/'.self::$nameProject.'/protected/bin/Cli/' . $command . '.php';
            
            try {
                $class = new ReflectionMethod($className, 'run');
                if ($_SERVER['argv'][1] != 'install') {
                	Prado::log("Lancement commande $command ", TLogger::INFO, "Atexo.Cli.Controller");
                }
               
                $time_start = microtime(true);
                $class->invoke(NULL);
                $time_end = microtime(true);
                $time = round($time_end - $time_start, 4);
                if ($_SERVER['argv'][1] != 'install') {
                	Prado::log("Fin commande $command in " . $time, TLogger::INFO, "Atexo.Cli.Controller");
                }
            } catch (SoapFault $e) {
                Prado::log("Uncaught Exception ! Script $className interrompu ! Erreur WebService : " . $e, TLogger::FATAL, "Atexo.Cli.Controller");
                $return_code = 1;
            } catch (Exception $e) {
                if ($_SERVER['argv'][1] != 'install') { 
                	Prado::log("Uncaught Exception ! Script $className interrompu ! Exception : " . $e, TLogger::FATAL, "Atexo.Cli.Controller");
                }
                else { 
	                echo $e;
                }
                $return_code = 2;
            }
        } else {
            self::displayError("command unknown", true);
        }

        // On force la fin de l'appel prado pour forcer l'écriture des logs prado par exemple
        if ($_SERVER['argv'][1] != 'install') {
        	$app->onEndRequest();
        }

        // Change les droits du dossier de logs si jamais le script est lancé en root
        self::changerDroit();
        exit($return_code);
    }
    
    private function changerDroit() {
    	if (posix_getuid() == 0) {
            $user = Atexo_Config::getParameter('HTTPD_USER');
            if(is_file('./protected/application.xml')) {
            	shell_exec("chown -R $user " . './protected/application.xml');	
            }

            if(is_dir(Atexo_Config::getParameter("LOG_FILE_PATH"))) {
            	shell_exec("chown -R $user " . Atexo_Config::getParameter("LOG_FILE_PATH"));
            }
            if(is_dir('./protected/' . Atexo_Config::getParameter("LOG_FILE_PATH"))) {
            	shell_exec("chown -R $user " . './protected/' . Atexo_Config::getParameter("LOG_FILE_PATH"));
            }
            if(is_file('./protected/runtime/application.xml-3.1.1/sqlite.cache')) {
            	shell_exec("chown -R $user " . './protected/runtime/application.xml-3.1.1/*.cache');
            }
        }
    }
}
