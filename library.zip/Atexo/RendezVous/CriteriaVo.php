<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_RendezVous_CriteriaVo{

	private $_idAgent;
	private $_motCle = null;
	private $_lang;
	private $_sortByElement = "";
	private $_sensOrderBy = "DESC";
	private $_offset = 0;
	private $_limit = 0;
	private $_suggest = false;
	private $_idSuggest;
	private $_count = false;
	private $_dateDu;
	private $_dateAu;
	private $_dateDuCreation;
	private $_dateAuCreation;
	private $_dateCreation;
	private $_identifiant;
	private $_nom;
	private $_email;
	private $_idTypePrestation;
	private $_idPrestation;
	private $_idRefPrestation;
	private $_idRessource;
	private $_idEtat=-1;
	private $_idModePriseRdv=-1;
	private $_annule=false;
	private $_idEtablissementAttache;
	private $_idOrganisationAttache;
	private $_groupByDateJour=false;
	private $_groupByDateSemaine=false;
	private $_groupByDateMois=false;
	private $_nomCitoyen = null;
	private $_codeRdv = null;
	private $_non_annule = -1;
	private $_idEntite;
	private $_idRefTypePrestation;
	private $_idTypeEtablissement;

	/**
	 * @return mixed
	 */
	public function getIdRefTypePrestation()
	{
		return $this->_idRefTypePrestation;
	}

	/**
	 * @param mixed $idRefTypePrestation
	 */
	public function setIdRefTypePrestation($idRefTypePrestation)
	{
		$this->_idRefTypePrestation = $idRefTypePrestation;
	}

	public function getIdEntite()
	{
		return $this->_idEntite;
	}

	public function setIdEntite($entite)
	{
		$this->_idEntite = $entite;
	}
	
	public function isNonAnnule()
	{
		return $this->_non_annule==1;
	}

	public function setNonAnnule()
	{
		$this->_non_annule = 1;
	}

	public function getIdEtat()
	{
		return $this->_idEtat;
	}

	public function setIdEtat($idEtat)
	{
		$this->_idEtat = $idEtat;
	}
	public function getIdModePriseRdv()
	{
		return $this->_idModePriseRdv;
	}

	public function setIdModePriseRdv($idModePriseRdv)
	{
		$this->_idModePriseRdv = $idModePriseRdv;
	}

	public function getIdAgent()
	{
		return $this->_idAgent;
	}

	public function setIdAgent($idAgent)
	{
		$this->_idAgent = $idAgent;
	}

	public function getMotCle()
	{
		return $this->_motCle;
	}

	public function setMotCle($motCle)
	{
		$this->_motCle = $motCle;
	}
	public function getNomCitoyen()
	{
		return $this->_nomCitoyen;
	}

	public function setNomCitoyen($nomCitoyen)
	{
		$this->_nomCitoyen = $nomCitoyen;
	}
	public function getCodeRdv()
	{
		return $this->_codeRdv;
	}

	public function setCodeRdv($codeRdv)
	{
		$this->_codeRdv = $codeRdv;
	}

	public function getLang()
	{
		return $this->_lang;
	}

	public function setLang($lang)
	{
		$this->_lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->_sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->_sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->_sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->_sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->_offset;
	}

	public function setOffset($offset)
	{
		$this->_offset = $offset;
	}

	public function getLimit()
	{
		return $this->_limit;
	}

	public function setLimit($limit)
	{
		$this->_limit = $limit;
	}

	public function getSuggest()
	{
		return $this->_suggest;
	}

	public function setSuggest($suggest)
	{
		$this->_suggest = $suggest;
	}

	public function getIdSuggest()
	{
		return $this->_idSuggest;
	}

	public function setIdSuggest($idSuggest)
	{
		$this->_idSuggest = $idSuggest;
	}

	public function getCount()
	{
		return $this->_count;
	}

	public function setCount($count)
	{
		$this->_count = $count;
	}

	public function getDateDu()
	{
		return $this->_dateDu;
	}

	public function setDateDu($dateDu)
	{
		$this->_dateDu = $dateDu;
	}
	public function getDateCreation()
	{
		return $this->_dateCreation;
	}
	public function setDateCreation($dateCreation)
	{
		$this->_dateCreation = $dateCreation;
	}

	public function getDateAu()
	{
		return $this->_dateAu;
	}
	public function setDateAu($dateAu)
	{
		$this->_dateAu = $dateAu;
	}
	public function getDateDuCreation()
	{
		return $this->_dateDuCreation;
	}
	public function setDateDuCreation($dateDuCreation)
	{
		$this->_dateDuCreation = $dateDuCreation;
	}
	public function getDateAuCreation()
	{
		return $this->_dateAuCreation;
	}
	public function setDateAuCreation($dateAuCreation)
	{
		$this->_dateAuCreation = $dateAuCreation;
	}
	public function getIdentifiant()
	{
		return $this->_identifiant;
	}

	public function setIdentifiant($identifiant)
	{
		$this->_identifiant = $identifiant;
	}
	public function getNom()
	{
		return $this->_nom;
	}

	public function setNom($nom)
	{
		$this->_nom = $nom;
	}
	public function getEmail()
	{
		return $this->_email;
	}

	public function setEmail($email)
	{
		$this->_email = $email;
	}
	public function getIdTypePrestation()
	{
		return $this->_idTypePrestation;
	}

	public function setIdTypePrestation($idTypePrestation)
	{
		$this->_idTypePrestation = $idTypePrestation;
	}
	public function getIdPrestation()
	{
		return $this->_idPrestation;
	}

	public function setIdPrestation($idPrestation)
	{
		$this->_idPrestation = $idPrestation;
	}
	public function getIdRefPrestation()
	{
		return $this->_idRefPrestation;
	}

	public function setIdRefPrestation($idRefPrestation)
	{
		$this->_idRefPrestation = $idRefPrestation;
	}
	public function getIdRessource()
	{
		return $this->_idRessource;
	}

	public function setIdRessource($idRessource)
	{
		$this->_idRessource = $idRessource;
	}
	public function isAnnule()
	{
		return $this->_annule;
	}

	public function setAnnule($annule)
	{
		$this->_annule = $annule;
	}
	public function setIdEtablissementAttache($value)
	{
		$this->_idEtablissementAttache = $value;
	}
	public function getIdEtablissementAttache()
	{
		return $this->_idEtablissementAttache;
	}
	public function setIdOrganisationAttache($value)
	{
		$this->_idOrganisationAttache = $value;
	}
	public function getIdOrganisationAttache()
	{
		return $this->_idOrganisationAttache;
	}
	public function isGroupByDateJour()
	{
		return $this->_groupByDateJour;
	}

	public function setGroupByDateJour($value)
	{
		$this->_groupByDateJour = $value;
	}
	public function isGroupByDateSemaine()
	{
		return $this->_groupByDateSemaine;
	}

	public function setGroupByDateSemaine($value)
	{
		$this->_groupByDateSemaine = $value;
	}
	public function isGroupByDateMois()
	{
		return $this->_groupByDateMois;
	}

	public function setGroupByDateMois($value)
	{
		$this->_groupByDateMois = $value;
	}

    /**
     * @return mixed
     */
    public function getIdTypeEtablissement()
    {
        return $this->_idTypeEtablissement;
    }

    /**
     * @param mixed $idTypeEtablissement
     */
    public function setIdTypeEtablissement($idTypeEtablissement)
    {
        $this->_idTypeEtablissement = $idTypeEtablissement;
    }

}