<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_AgentPrestation_Gestion {

	public function getPrestationByIdAgent($idAgent){
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TAgentPrestationPeer::ID_AGENT,$idAgent);
		return TAgentPrestationPeer::doSelect($c,$connexion);
	}
}