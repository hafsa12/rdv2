<?php

/**
 * Gestion de la configuration.
 *
 * Cette classe permet d'accéder aux directives de configuration
 * n'importe ou dans le code ainsi que de gérer la génération du
 * fichier de configuration application.xml en tenant compte de
 * la configuration spécifique de l'application en cours.
 *
 * @author Guillaume Ponéon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage config
 */
class Atexo_Config extends Api_Config
{
	/**
     * Génération du fichier de configuration application.xml à partir
     * des fichiers /config/application.php et /mpe/protected/config/application.xml.php
     *
     * @return boolean
     */
    public static function buildApplicationXmlFile()
    {
        Api_Config::buildApplicationXmlFile(Atexo_Controller_Front::getRootPath());
    }
    
	/**
     * Ajoute un paramétre au fichier de configuration si celui-ci n'existe pas déjà.
     *
     * Note : utilisable uniquement pour la génération du fichier de configuration !
     *
     * @param string $key
     * @param string $value
     */
    public static function setParameterIfNotExists($key, $value)
    {
        Api_Config::setParameterIfNotExists(Atexo_Controller_Front::getRootPath(), $key, $value);
    }
    
	/**
     * Ajoute ou modifie un paramétre au fichier de configuration
     *
     * Note : utilisable uniquement pour la génération du fichier de configuration !
     *
     * @param string $key
     * @param string $value
     */
    public static function setParameter($key, $value)
    {
        Api_Config::setParameter(Atexo_Controller_Front::getRootPath(), $key, $value);
    }
    
	/**
     * Retourne un paramétre du fichier de configuration.
     *
     * Utilisable tout le temps.
     *
     * @param string $key
     * @return string
     */
    public static function getParameter($key)
    {
        return Api_Config::getParameter(Atexo_Controller_Front::getRootPath(), $key);
    }
    
	/**
     * Retrait d'un paramétre du fichier de configuration lors de sa génération.
     *
     * @param string $key
     */
    public static function removeParameter($key)
    {
        Api_Config::removeParameter(Atexo_Controller_Front::getRootPath(), $key);
    }

    /**
     * Retourne la liste des paramétres du fichier de configuration.
     *
     * Utilisable tout le temps.
     *
     * @return array
     */
    public static function getParameters()
    {
        return Api_Config::getParameters(Atexo_Controller_Front::getRootPath());
    }

    public static function getPathOrgDir()
    {
        return self::getParameter('BASE_ROOT_DIR') . Atexo_User_CurrentUser::getCurrentOrganism() . "/";
    }

	public static function getCommonPathDir()
    {
        return self::getParameter('BASE_ROOT_DIR') . self::getParameter('COMMON_DIRECTORY');
    }
}
