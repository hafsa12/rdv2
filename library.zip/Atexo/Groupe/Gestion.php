<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2020
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Groupe_Gestion {

	/**
	 * retourne un tableau de type-prestations de la table "TGroupe"
	 * @param $lang, $idOrg : l'id d'organisation, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de groupe la table "TGroupe"
	 */
	public function getListeGroupe($idOrg, $lang, $valeurPraDefaut) {
		
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$tTraductionLibelleQuery = new TTraductionLibelleQuery();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TGroupePeer::ID_ORGANISATION, $idOrg);
		$arrayObjetGroupes = TGroupePeer::doSelect($c,$connexion);
		$arrayGroupes = array(0 => $valeurPraDefaut);
		foreach($arrayObjetGroupes as $groupe){
			$arrayGroupes[$groupe->getIdGroupe()] = $tTraductionLibelleQuery->getLibelle($groupe->getCodeLibelle(), $lang);
		}
		return $arrayGroupes;
	}
}