<?php

/**
 * Scripts en ligne de commande
 * @category Atexo
 * @package Atexo_Cli
 */
class Atexo_Cli extends Api_Cli {
	
	private static $nameProject = 'atexo.rdv';
	
	public static function displayError($errorMessage, $displayHelp = false, $exit = true) {
		Api_Cli::displayError($errorMessage, 
						$displayHelp, 
						$exit,
						self::$nameProject, 
						self::getRootPath(), 
						dirname(__FILE__) . '/../../application.xml',
						dirname(__FILE__) . '/../../bin/Cli/',
						Atexo_Config::getParameter("PF_SHORT_NAME"));
	}
	
	public static function helpAction() {
		Api_Cli::helpAction(self::$nameProject, 
						self::getRootPath(), 
						dirname(__FILE__) . '/../../application.xml',
						dirname(__FILE__) . '/../../bin/Cli/',
						Atexo_Config::getParameter("PF_SHORT_NAME"));
	}

    protected static function getRootPath() {
        return realpath(dirname(__FILE__) . '/../../../../');
    }

    protected static function getRootPathApp() {
        return realpath(dirname(__FILE__) . '/../../../');
    }
}