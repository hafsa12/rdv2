<?php

/**
 * @package atexo
 * @subpackage log
 */
class Atexo_LoggerManager
{
	public static function getLogger($name='')
    {
        return Api_LoggerManager::getLogger(Atexo_Config::getParameter('PATH_LOG_CONF'),$name);
    }
}
