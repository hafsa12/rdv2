<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Message_UserCompte
{
	public function getCorpsMessageAlerteDesactivationCompte($compteVo)
	{
		$corpsMail="";
		$corpsMail.="
";
		$corpsMail.=prado::localize('DEFINE_BONJOUR')."
"; 
		$corpsMail.="
";
		$corpsMail.=prado::localize('LE_COMPTE').$compteVo->getType().prado::localize('CORPS_MESSAGE_DESACTIVATION')."
";
		$corpsMail.="
";
		$corpsMail.=self::getInfoPersonneConnecte($compteVo)."
";

		$corpsMail .= Prado::localize('PIED_MESSAGE_DESACTIVATION');
		$corpsMail.="
";
		$corpsMail.="
";
		$corpsMail.=prado::localize('CORDIALEMENT').",

";
		$corpsMail.=prado::localize('NOM_ETABLISSEMENT_ENVOYANT_MSG');
		return $corpsMail;

	}

	public function getInfoPersonneConnecte($compteVo){

		$tAgent = Atexo_Agent_Gestion::retrieveAgentByLogin($compteVo->getLogin());
		if($tAgent instanceof TAgent)
		{
			$string.=prado::localize('PRENOM')." : ".$tAgent->getPrenomUtilisateurTraduit(Atexo_User_CurrentUser::readFromSession("lang"))."
";
			$string.=prado::localize('NOM')." : ".$tAgent->getNomUtilisateurTraduit(Atexo_User_CurrentUser::readFromSession("lang"))."
";
			$string.=prado::localize('TEXT_ADRESSE_ELECTRONIQUE')." : ".$tAgent->getEmailUtilisateur()."
";
			$string.=prado::localize('TEXT_IDENTIFIANT')." : ".$compteVo->getLogin()."
";
			$string.="
";
		}
		return $string;

	}

	public function sendAlerteDesactivationCompte($compteVo, $tAgent)
	{
		//DEBUT envoi du mail de desactivation de compte a l'agent
		$corpsMail=self::getCorpsMessageAlerteDesactivationCompte($compteVo);
		if($tAgent->getEmailUtilisateur()) {
			Atexo_Message::simpleMail(Atexo_Config::getParameter('PF_MAIL_FROM'), $tAgent->getEmailUtilisateur(), prado::localize('OBJET_DESACTIVATION_COMPTE'), $corpsMail);
		}
		//FIN envoi du mail de desactivation de compte a l'agent
	}
}
?>