<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_RefTypePrestation_Gestion {

	/**
	 * retourne un tableau de ref-type-prestations de la table "TRefTypePrestation"
	 * @param $lang, $idEtab : l'id d'établissement, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de type-prestations la table "TTypePrestation"
	 */
	public function getRefTypePrestationByIdOrg($lang,$idOrg,$valeurParDefaur = false,$idEtab=false){
		try {
			$arrayPres = array ();
			$connexion = Propel:: getConnection ( Atexo_Config::getParameter ( "DB_NAME" ) . Atexo_Config::getParameter ( "CONST_READ_ONLY" ) );
			$c = new Criteria();
			$c->add ( TRefTypePrestationPeer::ID_ORGANISATION, $idOrg );

			if($idEtab>0) {
				$c->addJoin(TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION, TTypePrestationPeer::ID_REF_TYPE_PRESTATION);
				$c->add ( TTypePrestationPeer::ID_ETABLISSEMENT, $idEtab );
			}

			$arrayObjetPres = TRefTypePrestationPeer::doSelect ( $c, $connexion );
			if ( $valeurParDefaur ) {
				$arrayPres[ 0 ] = $valeurParDefaur;
			}

			foreach ( $arrayObjetPres as $pres ) {
				$arrayPres[ $pres->getIdRefTypePrestation () ] = $pres->getLibelleRefTypePrestationTraduit ( $lang );
			}
			return $arrayPres;
		}catch (Exception $e) {
			throw $e;
		}
	}
}