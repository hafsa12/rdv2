<?php

/**
 * Exception personnalis�e du module Config
 *
 * @author Guillaume Pon�on <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage config
 */
class Atexo_Config_Exception extends Api_Exception 
{}