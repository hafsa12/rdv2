<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Referent_Gestion
{
	public function getReferentByIdEntite($lang,$idEntite,$valeurParDefaur = false){
		$arrayRef = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TReferentPeer::ID_ENTITE,$idEntite);

		$arrayObjetRef = TReferentPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayRef[0] = $valeurParDefaur;
		}

		foreach($arrayObjetRef as $referent){
			$arrayRef[$referent->getIdReferent()] = $referent->getNomPrenomReferentTraduit($lang);//Traduit($lang);
		}
		return $arrayRef;
	}
}