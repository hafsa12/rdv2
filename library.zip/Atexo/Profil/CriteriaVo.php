<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Profil_CriteriaVo{

	private $_idProfil;
	private $_idTypeProfilGE;
	private $_motCle = null;
	private $_idOrganisation = null;
	private $_lang;
	private $_sortByElement = "";
	private $_sensOrderBy = "ASC";
	private $_offset = 0;
	private $_limit = 0;
	private $_pages = false;
	private $_pageSize = false;

	public function getIdProfil()
	{
		return $this->_idProfil;
	}

	public function setIdProfil($idProfil)
	{
		$this->_idProfil = $idProfil;
	}

	public function getIdTypeProfilGE()
	{
		return $this->_idTypeProfilGE;
	}

	public function setIdTypeProfilGE($idTypeProfilGE)
	{
		$this->_idTypeProfilGE = $idTypeProfilGE;
	}

	public function getMotCle()
	{
		return $this->_motCle;
	}

	public function setMotCle($motCle)
	{
		$this->_motCle = $motCle;
	}

	public function getIdOrganisation()
	{
		return $this->_idOrganisation;
	}

	public function setIdOrganisation($idOrganisation)
	{
		$this->_idOrganisation = $idOrganisation;
	}

	public function getLang()
	{
		return $this->_lang;
	}

	public function setLang($lang)
	{
		$this->_lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->_sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->_sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->_sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->_sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->_offset;
	}

	public function setOffset($offset)
	{
		$this->_offset = $offset;
	}

	public function getLimit()
	{
		return $this->_limit;
	}

	public function setLimit($limit)
	{
		$this->_limit = $limit;
	}

	public function getPages()
	{
		return $this->_pages;
	}

	public function setPages($p)
	{
		$this->_pages = $p;
	}

	public function getPageSize()
	{
		return $this->_pageSize;
	}

	public function setPageSize($ps)
	{
		$this->_pageSize = $ps;
	}
}