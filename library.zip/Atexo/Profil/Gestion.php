<?php
class Atexo_Profil_Gestion {

	// valeurPraDefaut : gestion de mot selectionnez
	public function getAllTypeProfil($lang,$valeurParDefaur = false){
		$arrayTP = array();

		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$arrayObjetTP = TTypeProfilPeer::doSelect($c,$connexion);

		if($valeurParDefaur){
			$arrayTP[0] = $valeurParDefaur;
		}
		foreach($arrayObjetTP as $TP){
			$arrayTP[$TP->getIdTypeProfil()] = $TP->getLibelleTypeProfilTraduit($lang);
		}
		return $arrayTP;
	}
	
	public function getAllPossibleTypeProfilByConnected($lang,$valeurParDefaur = false){
		$arrayTP = array();

		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		
		if(Atexo_User_CurrentUser::isAdminOrg()) {
			$c->add(TTypeProfilPeer::ID_TYPE_PROFIL,Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION"),Criteria::GREATER_EQUAL);
		}
		if(Atexo_User_CurrentUser::isAdminEtab()) {
			$c->add(TTypeProfilPeer::ID_TYPE_PROFIL,Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT"),Criteria::GREATER_EQUAL);
		}
		if(Atexo_User_CurrentUser::isAgent()) {
			$c->add(TTypeProfilPeer::ID_TYPE_PROFIL,Atexo_Config::getParameter("ID_PROFIL_AGENT"),Criteria::GREATER_EQUAL);
		}
        if(Atexo_User_CurrentUser::isRessource()) {
            $c->add(TTypeProfilPeer::ID_TYPE_PROFIL,"7" ,Criteria::GREATER_EQUAL);
        }
		
		$arrayObjetTP = TTypeProfilPeer::doSelect($c,$connexion);

		if($valeurParDefaur){
			$arrayTP[0] = $valeurParDefaur;
		}
		foreach($arrayObjetTP as $TP){
			$arrayTP[$TP->getIdTypeProfil()] = $TP->getLibelleTypeProfilTraduit($lang);
		}
		return $arrayTP;
	}
	
	public function getAllPossibleProfilRessourceByConnected($lang,$valeurParDefaur = false){
		$arrayTP = array();

                $connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
                $c = new Criteria();
		$c->add(TProfilPeer::ID_TYPE_PROFIL, 7, Criteria::EQUAL);

                $idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
                if($idOrg>0) {
                        $c->add(TProfilPeer::ID_ORGANISATION,$idOrg);
                }

                $arrayObjetTP = TProfilPeer::doSelect($c,$connexion);

                if($valeurParDefaur){
                        $arrayTP[0] = $valeurParDefaur;
                }
                foreach($arrayObjetTP as $TP){
                        $arrayTP[$TP->getIdProfil()] = $TP->getLibelleProfilTraduit($lang);
                }
                return $arrayTP;
	}	
	public function getAllPossibleProfilByConnected($lang,$valeurParDefaur = false){
		$arrayTP = array();

		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		
		if(Atexo_User_CurrentUser::isAdminOrg()) {
			$c->add(TProfilPeer::ID_TYPE_PROFIL,Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION"),Criteria::GREATER_EQUAL);
		}
		if(Atexo_User_CurrentUser::isAdminEtab()) {
			$c->add(TProfilPeer::ID_TYPE_PROFIL,Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT"),Criteria::GREATER_EQUAL);
		}
		if(Atexo_User_CurrentUser::isAgent()) {
			$c->add(TProfilPeer::ID_TYPE_PROFIL,Atexo_Config::getParameter("ID_PROFIL_AGENT"),Criteria::GREATER_EQUAL);
		}
		if(Atexo_User_CurrentUser::isAdminSys()) {
			$c->add(TProfilPeer::ID_TYPE_PROFIL,Atexo_Config::getParameter("ID_PROFIL_ADMIN_SYSTEM"),Criteria::GREATER_EQUAL);
		}
		$c->add(TProfilPeer::ID_TYPE_PROFIL, 7, Criteria::NOT_EQUAL);

		$idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
		if($idOrg>0) {
			$c->add(TProfilPeer::ID_ORGANISATION,$idOrg);
		}
		
		$arrayObjetTP = TProfilPeer::doSelect($c,$connexion);

		if($valeurParDefaur){
			$arrayTP[0] = $valeurParDefaur;
		}
		foreach($arrayObjetTP as $TP){
			$arrayTP[$TP->getIdProfil()] = $TP->getLibelleProfilTraduit($lang);
		}
		return $arrayTP;
	}
	

	/**
	 *
	 * Recuperer tous les
	 * @param unknown_type $lang
	 * @param unknown_type $valeurParDefaur
	 */
	public function getAllProfilByType($typeProfil, $lang,$valeurParDefaur = false){
		$arrayPrfl = array();

		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TProfilPeer::ID_TYPE_PROFIL,$typeProfil);
		$arrayObjetPrfl = TProfilPeer::doSelect($c,$connexion);

		if($valeurParDefaur){
			$arrayPrfl[0] = $valeurParDefaur;
		}
		foreach($arrayObjetPrfl as $prfl){
			$arrayPrfl[$prfl->getIdProfil()] = $prfl->getLibelleProfilTraduit($lang);
		}
		return $arrayPrfl;
	}


}
