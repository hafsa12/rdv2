<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Prestation_Gestion {

	/**
	 * retourne un tableau de prestations de la table "TPrestation"
	 * @param $lang, $idTypePres : l'id de type-prestation, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de prestations la table "TPrestation"
	 */
	public function getPrestationByIdTypePrestation($lang,$idTypePres, $typePrest, $valeurParDefaur = false, $withRessource=false){
		$arrayPres = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		if(is_array($idTypePres)) {
			$c->add(TPrestationPeer::ID_TYPE_PRESTATION, $idTypePres, Criteria::IN);
		}
		elseif($idTypePres) {
			$c->add(TPrestationPeer::ID_TYPE_PRESTATION,$idTypePres);
		}
		if($withRessource) {
			$c->addJoin(TPrestationPeer::ID_PRESTATION,TAgendaPeer::ID_PRESTATION);
			$c->addJoin(TAgendaPeer::ID_AGENT,TAgentPeer::ID_AGENT);
			$c->add(TAgentPeer::ACTIF,1);
		}
		$arrayObjetPres = TPrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayPres[0] = $valeurParDefaur;
		}
		
		foreach($arrayObjetPres as $pres){
			$arrayPres[$pres->getIdPrestation()] = $pres->getLibellePrestationTraduit($lang, $typePrest);//Traduit($lang);
		}
		return $arrayPres;
	}

	/**
	 * retourne un tableau de prestations de la table "TPrestation"
	 * @param $lang, $idTypePres : l'id de type-prestation, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de prestations la table "TPrestation"
	 */
	public function getRefPrestationByIdRefTypePrestation($lang,$idTypePres, $valeurParDefaur = false){
		$arrayPres = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TRefPrestationPeer::ID_REF_PRESTATION,TParametragePrestationPeer::ID_REF_PRESTATION);
		$c->addJoin(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION);
		$c->add(TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION, $idTypePres);
		$c->add(TParametragePrestationPeer::ID_ORGANISATION, Atexo_User_CurrentUser::getIdOrganisationGere());
		$arrayObjetPres = TRefPrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayPres[0] = $valeurParDefaur;
		}

		foreach($arrayObjetPres as $pres){
			$arrayPres[$pres->getIdRefPrestation()] = $pres->getLibelleRefPrestationTraduit($lang);//Traduit($lang);
		}
		return $arrayPres;
	}

	public function getPrestationByIdTypeRefPrestation($lang,$idTypeRefPres, $idEtabs, $valeurParDefaur = false){
		$arrayPres = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION);
		if(is_array($idTypeRefPres)) {
			$c->add(TTypePrestationPeer::ID_REF_TYPE_PRESTATION, $idTypeRefPres, Criteria::IN);
		}
		elseif($idTypeRefPres) {
			$c->add(TTypePrestationPeer::ID_REF_TYPE_PRESTATION,$idTypeRefPres);
		}
		$c->add(TTypePrestationPeer::ID_ETABLISSEMENT,$idEtabs, Criteria::IN);
		$arrayObjetPres = TPrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayPres[0] = $valeurParDefaur;
		}

		foreach($arrayObjetPres as $pres){
			$arrayPres[$pres->getIdRefPrestation()] = $pres->getLibellePrestationTraduit($lang, Atexo_Config::getParameter("PRESTATION_REFERENTIEL"));//Traduit($lang);
		}
		return $arrayPres;
	}
	/**
	 * retourne un tableau de prestations de la table "TPrestation"
	 * @param $lang, $idRefPres : l'id de refPrestation, $valeurPraDefaut : gestion de mot selectionnez
	 * @return : tableau de prestations la table "TPrestation"
	 */
	public function getPrestationByIdRefPrestation($lang,$idRefPres,$valeurParDefaur = false){
		$arrayPres = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		$c->add(TPrestationPeer::ID_REF_PRESTATION,$idRefPres);
		$arrayObjetPres = TPrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayPres[0] = $valeurParDefaur;
		}

		foreach($arrayObjetPres as $pres){
			$arrayPres[$pres->getIdPrestation()] = $pres->getLibellePrestationTraduit($lang);//Traduit($lang);
		}
		return $arrayPres;
	}
}