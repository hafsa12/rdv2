<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Prestation_CriteriaVo{

	private $idPrestation;
	private $motCle = null;
	private $lang;
	private $sortByElement="";
	private $sensOrderBy="DESC";
	private $offset=0;
	private $limit=0;
	private $organisation=false;
	private $_idOrganisation;
	private $etablissement=false;
	private $_idEtablissement;
	private $typePrestation=false;
	private $_idTypePrestation;
	private $_idRefPrestation;
	private $_idRefTypePrestation;
	private $count = false;
	private $_dateDu;
	private $_dateAu;
	private $_idEntite;
	private $_pages = false;
	private $_pageSize = false;
	private $_entite1 = false;
	private $_entite2 = false;
	private $_entite3 = false;
	private $_prestationReferentiel = false;
	private $_prestationModeRef = false;
	private $_recupIdsEtab = false;
    private $_etablissement_active;
    private $_idTypeEtablissement;

	public function getIdEntite()
	{
		return $this->_idEntite;
	}

	public function setIdEntite($entite)
	{
		$this->_idEntite = $entite;
	}

	public function getIdPrestation()
	{
		return $this->idPrestation;
	}

	public function setIdPrestation($idPrestation)
	{
		$this->idPrestation = $idPrestation;
	}

	public function getMotCle()
	{
		return $this->motCle;
	}

	public function setMotCle($motCle)
	{
		$this->motCle = $motCle;
	}

	public function getLang()
	{
		return $this->lang;
	}

	public function setLang($lang)
	{
		$this->lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->offset;
	}

	public function setOffset($offset)
	{
		$this->offset = $offset;
	}

	public function getLimit()
	{
		return $this->limit;
	}

	public function setLimit($limit)
	{
		$this->limit = $limit;
	}

	public function getOrganisation()
	{
		return $this->organisation;
	}

	public function setOrganisation($organisation)
	{
		$this->organisation = $organisation;

	}
	public function getIdOrganisation()
	{
		return $this->_idOrganisation;
	}

	public function setIdOrganisation($idOrganisation)
	{
		$this->_idOrganisation = $idOrganisation;
	}

	public function getEtablissement()
	{
		return $this->etablissement;
	}

	public function setEtablissement($etablissement)
	{
		$this->etablissement = $etablissement;

	}
	public function getIdEtablissement()
	{
		return $this->_idEtablissement;
	}

	public function setIdEtablissement($idEtablissement)
	{
		$this->_idEtablissement = $idEtablissement;
	}
	public function getTypePrestation()
	{
		return $this->typePrestation;
	}

	public function setTypePrestation($typePrestation)
	{
		$this->typePrestation = $typePrestation;

	}
	public function getIdTypePrestation()
	{
		return $this->_idTypePrestation;
	}

	public function setIdTypePrestation($idTypePrestation)
	{
		$this->_idTypePrestation = $idTypePrestation;
	}
	public function getIdRefPrestation()
	{
		return $this->_idRefPrestation;
	}

	public function setIdRefPrestation($idRefPrestation)
	{
		$this->_idRefPrestation = $idRefPrestation;
	}
	public function getIdRefTypePrestation()
	{
		return $this->_idRefTypePrestation;
	}

	public function setIdRefTypePrestation($idRefTypePrestation)
	{
		$this->_idRefTypePrestation = $idRefTypePrestation;
	}
	public function getCount()
	{
		return $this->count;
	}

	public function setCount($count)
	{
		$this->count = $count;

	}
	public function getDateDu()
	{
		return $this->_dateDu;
	}
	public function setDateDu($dateDu)
	{
		$this->_dateDu = $dateDu;
	}
	public function getDateAu()
	{
		return $this->_dateAu;
	}
	public function setDateAu($dateAu)
	{
		$this->_dateAu = $dateAu;
	}

	public function getPages()
	{
		return $this->_pages;
	}

	public function setPages($p)
	{
		$this->_pages = $p;
	}

	public function getPageSize()
	{
		return $this->_pageSize;
	}

	public function setPageSize($ps)
	{
		$this->_pageSize = $ps;
	}

	public function getEntite1()
	{
		return $this->_entite1;
	}

	public function setEntite1($entitie1)
	{
		$this->_entite1 = $entitie1;
	}

	public function getEntite2()
	{
		return $this->_entite2;
	}

	public function setEntite2($entitie2)
	{
		$this->_entite2 = $entitie2;
	}

	public function getEntite3()
	{
		return $this->_entite3;
	}

	public function setEntite3($entitie3)
	{
		$this->_entite3 = $entitie3;
	}

	public function getPrestationReferentiel()
	{
		return $this->_prestationReferentiel;
	}

	public function setPrestationReferentiel($pr)
	{
		$this->_prestationReferentiel = $pr;
	}

	public function getPrestationModeRef()
	{
		return $this->_prestationModeRef;
	}

	public function setPrestationModeRef($v)
	{
		$this->_prestationModeRef = $v;
	}

	public function getRecupIdsEtab()
	{
		return $this->_recupIdsEtab;
	}

	public function setRecupIdsEtab($v)
	{
		$this->_recupIdsEtab = $v;
	}

    /**
     * @return mixed
     */
    public function getEtablissementActive()
    {
        return $this->_etablissement_active;
    }

    /**
     * @param mixed $etablissement_active
     */
    public function setEtablissementActive($etablissement_active)
    {
        $this->_etablissement_active = $etablissement_active;
    }

    /**
     * @return mixed
     */
    public function getIdTypeEtablissement()
    {
        return $this->_idTypeEtablissement;
    }

    /**
     * @param mixed $idTypeEtablissement
     */
    public function setIdTypeEtablissement($idTypeEtablissement)
    {
        $this->_idTypeEtablissement = $idTypeEtablissement;
    }

}