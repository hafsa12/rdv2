<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_Prestation_PrestationAssocieeVo {

	private $idAgent;
	private $idTypePrestation;
	private $idPrestation;
	private $idAgenda;
	private $dureeRdv;
	private $debutPeriode;
	private $finPeriode;
	private $lundiHeureDebut1;
	private $lundiHeureFin1;
	private $lundiHeureDebut2;
	private $lundiHeureFin2;
	private $mardiHeureDebut1;
	private $mardiHeureFin1;
	private $mardiHeureDebut2;
	private $mardiHeureFin2;
	private $mercrediHeureDebut1;
	private $mercrediHeureFin1;
	private $mercrediHeureDebut2;
	private $mercrediHeureFin2;
	private $jeudiHeureDebut1;
	private $jeudiHeureFin1;
	private $jeudiHeureDebut2;
	private $jeudiHeureFin2;
	private $vendrediHeureDebut1;
	private $vendrediHeureFin1;
	private $vendrediHeureDebut2;
	private $vendrediHeureFin2;
	private $samediHeureDebut1;
	private $samediHeureFin1;
	private $samediHeureDebut2;
	private $samediHeureFin2;
	private $dimancheHeureDebut1;
	private $dimancheHeureFin1;
	private $dimancheHeureDebut2;
	private $dimancheHeureFin2;
	private $lundiCapacite1;
	private $lundiCapacite2;
	private $mardiCapacite1;
	private $mardiCapacite2;
	private $mercrediCapacite1;
	private $mercrediCapacite2;
	private $jeudiCapacite1;
	private $jeudiCapacite2;
	private $vendrediCapacite1;
	private $vendrediCapacite2;
	private $samediCapacite1;
	private $samediCapacite2;
	private $dimancheCapacite1;
	private $dimancheCapacite2;
	private $lundiNbRdvSite1;
	private $lundiNbRdvSite2;
	private $mardiNbRdvSite1;
	private $mardiNbRdvSite2;
	private $mercrediNbRdvSite1;
	private $mercrediNbRdvSite2;
	private $jeudiNbRdvSite1;
	private $jeudiNbRdvSite2;
	private $vendrediNbRdvSite1;
	private $vendrediNbRdvSite2;
	private $samediNbRdvSite1;
	private $samediNbRdvSite2;
	private $dimancheNbRdvSite1;
	private $dimancheNbRdvSite2;
	private $periodicite;

	public function setIdAgent($value) {
		$this->idAgent = $value;
	}
	public function getIdAgent() {
		return $this->idAgent;
	}
	public function setIdTypePrestation($value) {
		$this->idTypePrestation = $value;
	}
	public function getIdTypePrestation() {
		return $this->idTypePrestation;
	}
	public function setIdPrestation($value) {
		$this->idPrestation = $value;
	}
	public function getIdPrestation() {
		return $this->idPrestation;
	}
	public function setIdAgenda($value) {
		$this->idAgenda = $value;
	}
	public function getIdAgenda() {
		return $this->idAgenda;
	}
	public function setDureeRdv($value) {
		$this->dureeRdv = $value;
	}
	public function getDureeRdv() {
		return $this->dureeRdv;
	}
	public function setDebutPeriode($value) {
		$this->debutPeriode = $value;
	}
	public function getDebutPeriode() {
		return $this->debutPeriode;
	}
	public function setFinPeriode($value) {
		$this->finPeriode = $value;
	}
	public function getFinPeriode() {
		return $this->finPeriode;
	}
	public function setLundiHeureDebut1($value) {
		$this->lundiHeureDebut1 = $value;
	}
	public function getLundiHeureDebut1() {
		return $this->lundiHeureDebut1;
	}
	public function setLundiHeureFin1($value) {
		$this->lundiHeureFin1 = $value;
	}
	public function getLundiHeureFin1() {
		return $this->lundiHeureFin1;
	}
	public function setLundiHeureDebut2($value) {
		$this->lundiHeureDebut2 = $value;
	}
	public function getLundiHeureDebut2() {
		return $this->lundiHeureDebut2;
	}
	public function setLundiHeureFin2($value) {
		$this->lundiHeureFin2 = $value;
	}
	public function getLundiHeureFin2() {
		return $this->lundiHeureFin2;
	}
	public function setMardiHeureDebut1($value) {
		$this->mardiHeureDebut1 = $value;
	}
	public function getMardiHeureDebut1() {
		return $this->mardiHeureDebut1;
	}
	public function setMardiHeureFin1($value) {
		$this->mardiHeureFin1 = $value;
	}
	public function getMardiHeureFin1() {
		return $this->mardiHeureFin1;
	}
	public function setMardiHeureDebut2($value) {
		$this->mardiHeureDebut2 = $value;
	}
	public function getMardiHeureDebut2() {
		return $this->mardiHeureDebut2;
	}
	public function setMardiHeureFin2($value) {
		$this->mardiHeureFin2 = $value;
	}
	public function getMardiHeureFin2() {
		return $this->mardiHeureFin2;
	}
	public function setMercrediHeureDebut1($value) {
		$this->mercrediHeureDebut1 = $value;
	}
	public function getMercrediHeureDebut1() {
		return $this->mercrediHeureDebut1;
	}
	public function setMercrediHeureFin1($value) {
		$this->mercrediHeureFin1 = $value;
	}
	public function getMercrediHeureFin1() {
		return $this->mercrediHeureFin1;
	}
	public function setMercrediHeureDebut2($value) {
		$this->mercrediHeureDebut2 = $value;
	}
	public function getMercrediHeureDebut2() {
		return $this->mercrediHeureDebut2;
	}
	public function setMercrediHeureFin2($value) {
		$this->mercrediHeureFin2 = $value;
	}
	public function getMercrediHeureFin2() {
		return $this->mercrediHeureFin2;
	}
	public function setJeudiHeureDebut1($value) {
		$this->jeudiHeureDebut1 = $value;
	}
	public function getJeudiHeureDebut1() {
		return $this->jeudiHeureDebut1;
	}
	public function setJeudiHeureFin1($value) {
		$this->jeudiHeureFin1 = $value;
	}
	public function getJeudiHeureFin1() {
		return $this->jeudiHeureFin1;
	}
	public function setJeudiHeureDebut2($value) {
		$this->jeudiHeureDebut2 = $value;
	}
	public function getJeudiHeureDebut2() {
		return $this->jeudiHeureDebut2;
	}
	public function setJeudiHeureFin2($value) {
		$this->jeudiHeureFin2 = $value;
	}
	public function getJeudiHeureFin2() {
		return $this->jeudiHeureFin2;
	}
	public function setVendrediHeureDebut1($value) {
		$this->vendrediHeureDebut1 = $value;
	}
	public function getVendrediHeureDebut1() {
		return $this->vendrediHeureDebut1;
	}
	public function setVendrediHeureFin1($value) {
		$this->vendrediHeureFin1 = $value;
	}
	public function getVendrediHeureFin1() {
		return $this->vendrediHeureFin1;
	}
	public function setVendrediHeureDebut2($value) {
		$this->vendrediHeureDebut2 = $value;
	}
	public function getVendrediHeureDebut2() {
		return $this->vendrediHeureDebut2;
	}
	public function setVendrediHeureFin2($value) {
		$this->vendrediHeureFin2 = $value;
	}
	public function getVendrediHeureFin2() {
		return $this->vendrediHeureFin2;
	}
	public function setSamediHeureDebut1($value) {
		$this->samediHeureDebut1 = $value;
	}
	public function getSamediHeureDebut1() {
		return $this->samediHeureDebut1;
	}
	public function setSamediHeureFin1($value) {
		$this->samediHeureFin1 = $value;
	}
	public function getSamediHeureFin1() {
		return $this->samediHeureFin1;
	}
	public function setSamediHeureDebut2($value) {
		$this->samediHeureDebut2 = $value;
	}
	public function getSamediHeureDebut2() {
		return $this->samediHeureDebut2;
	}
	public function setSamediHeureFin2($value) {
		$this->samediHeureFin2 = $value;
	}
	public function getSamediHeureFin2() {
		return $this->samediHeureFin2;
	}
	public function setDimancheHeureDebut1($value) {
		$this->dimancheHeureDebut1 = $value;
	}
	public function getDimancheHeureDebut1() {
		return $this->dimancheHeureDebut1;
	}
	public function setDimancheHeureFin1($value) {
		$this->dimancheHeureFin1 = $value;
	}
	public function getDimancheHeureFin1() {
		return $this->dimancheHeureFin1;
	}
	public function setDimancheHeureDebut2($value) {
		$this->dimancheHeureDebut2 = $value;
	}
	public function getDimancheHeureDebut2() {
		return $this->dimancheHeureDebut2;
	}
	public function setDimancheHeureFin2($value) {
		$this->dimancheHeureFin2 = $value;
	}
	public function getDimancheHeureFin2() {
		return $this->dimancheHeureFin2;
	}

	public function getLundiCapacite1() {
		return $this->lundiCapacite1;
	}
	public function setLundiCapacite1($value) {
		$this->lundiCapacite1 = $value;
	}
	public function getLundiCapacite2() {
		return $this->lundiCapacite2;
	}
	public function setLundiCapacite2($value) {
		$this->lundiCapacite2 = $value;
	}
	public function getMardiCapacite1() {
		return $this->mardiCapacite1;
	}
	public function setMardiCapacite1($value) {
		$this->mardiCapacite1 = $value;
	}
	public function getMardiCapacite2() {
		return $this->mardiCapacite2;
	}
	public function setMardiCapacite2($value) {
		$this->mardiCapacite2 = $value;
	}
	public function getMercrediCapacite1() {
		return $this->mercrediCapacite1;
	}
	public function setMercrediCapacite1($value) {
		$this->mercrediCapacite1 = $value;
	}
	public function getMercrediCapacite2() {
		return $this->mercrediCapacite2;
	}
	public function setMercrediCapacite2($value) {
		$this->mercrediCapacite2 = $value;
	}
	public function getJeudiCapacite1() {
		return $this->jeudiCapacite1;
	}
	public function setJeudiCapacite1($value) {
		$this->jeudiCapacite1 = $value;
	}
	public function getJeudiCapacite2() {
		return $this->jeudiCapacite2;
	}
	public function setJeudiCapacite2($value) {
		$this->jeudiCapacite2 = $value;
	}
	public function getVendrediCapacite1() {
		return $this->vendrediCapacite1;
	}
	public function setVendrediCapacite1($value) {
		$this->vendrediCapacite1 = $value;
	}
	public function getVendrediCapacite2() {
		return $this->vendrediCapacite2;
	}
	public function setVendrediCapacite2($value) {
		$this->vendrediCapacite2 = $value;
	}
	public function getSamediCapacite1() {
		return $this->samediCapacite1;
	}
	public function setSamediCapacite1($value) {
		$this->samediCapacite1 = $value;
	}
	public function getSamediCapacite2() {
		return $this->samediCapacite2;
	}
	public function setSamediCapacite2($value) {
		$this->samediCapacite2 = $value;
	}
	public function getDimancheCapacite1() {
		return $this->dimancheCapacite1;
	}
	public function setDimancheCapacite1($value) {
		$this->dimancheCapacite1 = $value;
	}
	public function getDimancheCapacite2() {
		return $this->dimancheCapacite2;
	}
	public function setDimancheCapacite2($value) {
		$this->dimancheCapacite2 = $value;
	}
	public function setLundiNbRdvSite1($value) {
		$this->lundiNbRdvSite1 = $value;
	}
	public function getLundiNbRdvSite1() {
		return $this->lundiNbRdvSite1;
	}
	public function setLundiNbRdvSite2($value) {
		$this->lundiNbRdvSite2 = $value;
	}
	public function getLundiNbRdvSite2() {
		return $this->lundiNbRdvSite2;
	}
	public function setMardiNbRdvSite1($value) {
		$this->mardiNbRdvSite1 = $value;
	}
	public function getMardiNbRdvSite1() {
		return $this->mardiNbRdvSite1;
	}
	public function setMardiNbRdvSite2($value) {
		$this->mardiNbRdvSite2 = $value;
	}
	public function getMardiNbRdvSite2() {
		return $this->mardiNbRdvSite2;
	}
	public function setMercrediNbRdvSite1($value) {
		$this->mercrediNbRdvSite1 = $value;
	}
	public function getMercrediNbRdvSite1() {
		return $this->mercrediNbRdvSite1;
	}
	public function setMercrediNbRdvSite2($value) {
		$this->mercrediNbRdvSite2 = $value;
	}
	public function getMercrediNbRdvSite2() {
		return $this->mercrediNbRdvSite2;
	}
	public function setJeudiNbRdvSite1($value) {
		$this->jeudiNbRdvSite1 = $value;
	}
	public function getJeudiNbRdvSite1() {
		return $this->jeudiNbRdvSite1;
	}
	public function setJeudiNbRdvSite2($value) {
		$this->jeudiNbRdvSite2 = $value;
	}
	public function getJeudiNbRdvSite2() {
		return $this->jeudiNbRdvSite2;
	}
	public function setVendrediNbRdvSite1($value) {
		$this->vendrediNbRdvSite1 = $value;
	}
	public function getVendrediNbRdvSite1() {
		return $this->vendrediNbRdvSite1;
	}
	public function setVendrediNbRdvSite2($value) {
		$this->vendrediNbRdvSite2 = $value;
	}
	public function getVendrediNbRdvSite2() {
		return $this->vendrediNbRdvSite2;
	}
	public function setSamediNbRdvSite1($value) {
		$this->samediNbRdvSite1 = $value;
	}
	public function getSamediNbRdvSite1() {
		return $this->samediNbRdvSite1;
	}
	public function setSamediNbRdvSite2($value) {
		$this->samediNbRdvSite2 = $value;
	}
	public function getSamediNbRdvSite2() {
		return $this->samediNbRdvSite2;
	}
	public function setDimancheNbRdvSite1($value) {
		$this->dimancheNbRdvSite1 = $value;
	}
	public function getDimancheNbRdvSite1() {
		return $this->dimancheNbRdvSite1;
	}
	public function setDimancheNbRdvSite2($value) {
		$this->dimancheNbRdvSite2 = $value;
	}
	public function getDimancheNbRdvSite2() {
		return $this->dimancheNbRdvSite2;
	}
public function setPeriodicite($value) {
		$this->periodicite = $value;
	}
	public function getPeriodicite() {
		return $this->periodicite;
	}
}