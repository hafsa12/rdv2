<?php
class Atexo_RefPrestation_Gestion {

	/**
	 * retourne un tableau des refPrestations de la table "TRefPrestation"
	 * @param $lang, $idOrganisation : id de l'organisation, $valeurPraDefaut : gestion de mot selectionnez,
	 * @return : tableau de refPrestations la table "TRefPrestation"
	 */
	public function getRefPrestationByIdOrganisation($lang, $idOrganisation, $valeurParDefaur = false){
		$arrayEtab = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		if($idOrganisation>0) {
			$c->add(TRefPrestationPeer::ID_ORGANISATION,$idOrganisation);
		}
		$arrayObjetEtab = TRefPrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayEtab[] = $valeurParDefaur;
		}
		foreach($arrayObjetEtab as $etab){
			$arrayEtab[$etab->getIdRefPrestation()] = $etab->getLibelleRefPrestationTraduit($lang);//Traduit($lang);
		}
		return $arrayEtab;
	}
	/**
	 * retourne un tableau des refTypePrestations de la table "TRefTypePrestation"
	 * @param $lang, $idOrganisation : id de l'organisation, $valeurPraDefaut : gestion de mot selectionnez,
	 * @return : tableau de refTypePrestations la table "TRefTypePrestation"
	 */
	public function getRefTypePrestationByIdOrganisation($lang, $idOrganisation, $valeurParDefaur = false){
		$arrayEtab = array();
		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();
		if($idOrganisation>0) {
			$c->add(TRefTypePrestationPeer::ID_ORGANISATION,$idOrganisation);
		}
		$arrayObjets = TRefTypePrestationPeer::doSelect($c,$connexion);
		if($valeurParDefaur){
			$arrayEtab[] = $valeurParDefaur;
		}
		foreach($arrayObjets as $obj){
			$arrayEtab[$obj->getIdRefTypePrestation()] = $obj->getLibelleRefTypePrestationTraduit($lang);//Traduit($lang);
		}
		return $arrayEtab;
	}

	/**
	 * retourne un tableau des refPrestations de la table "TRefPrestation"
	 * @param $lang, $valeurPraDefaut : gestion de mot selectionnez,
	 * @return : tableau de refPrestations la table "TRefPrestation"
	 */
	public function getAllRefPrestation($lang,$idRefTypePrestation,$valeurParDefaur = false, $idEtab=false){
		$arrayReg = array();

		$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
		$c = new Criteria();

		if($idRefTypePrestation>0) {
			$c->addJoin(TRefPrestationPeer::ID_REF_PRESTATION,TParametragePrestationPeer::ID_REF_PRESTATION);
			$c->add(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION,$idRefTypePrestation);

			if($idEtab>0) {
				$c->addJoin(TRefPrestationPeer::ID_REF_PRESTATION, TPrestationPeer::ID_REF_PRESTATION);
				//$c->addJoin(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, TTypePrestationPeer::ID_REF_TYPE_PRESTATION);
				$c->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION);
				$c->add ( TTypePrestationPeer::ID_ETABLISSEMENT, $idEtab );
			}
		}
		$c->setDistinct();
		$arrayObjetReg = TRefPrestationPeer::doSelect($c,$connexion);

		if($valeurParDefaur){
			$arrayReg[0] = $valeurParDefaur;
		}
		foreach($arrayObjetReg as $Reg){
			$arrayReg[$Reg->getIdRefPrestation()] = $Reg->getLibelleRefPrestationTraduit($lang);
		}
		return $arrayReg;
	}
}
