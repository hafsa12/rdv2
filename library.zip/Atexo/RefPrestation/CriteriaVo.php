<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Atexo_RefPrestation_CriteriaVo{

	private $idRefPrestation;
	private $motCle = null;
	private $lang;
	private $sortByElement="";
	private $sensOrderBy="ASC";
	private $offset=0;
	private $limit=0;
	private $organisation=false;
	private $_idOrganisation;
	private $count = false;
	private $_pages = false;
	private $_pageSize = false;
	private $_defaultValue = false;


	public function getIdRefPrestation()
	{
		return $this->idRefPrestation;
	}

	public function setIdRefPrestation($idRefPrestation)
	{
		$this->idRefPrestation = $idRefPrestation;
	}

	public function getMotCle()
	{
		return $this->motCle;
	}

	public function setMotCle($motCle)
	{
		$this->motCle = $motCle;
	}

	public function getLang()
	{
		return $this->lang;
	}

	public function setLang($lang)
	{
		$this->lang = $lang;
	}

	public function getSortByElement()
	{
		return $this->sortByElement;
	}

	public function setSortByElement($sortByElement)
	{
		$this->sortByElement = $sortByElement;
	}

	public function getSensOrderBy()
	{
		return $this->sensOrderBy;
	}

	public function setSensOrderBy($sensOrderBy)
	{
		$this->sensOrderBy = $sensOrderBy;
	}

	public function getOffset()
	{
		return $this->offset;
	}

	public function setOffset($offset)
	{
		$this->offset = $offset;
	}

	public function getLimit()
	{
		return $this->limit;
	}

	public function setLimit($limit)
	{
		$this->limit = $limit;
	}

	public function getOrganisation()
	{
		return $this->organisation;
	}

	public function setOrganisation($organisation)
	{
		$this->organisation = $organisation;

	}
	public function getIdOrganisation()
	{
		return $this->_idOrganisation;
	}

	public function setIdOrganisation($idOrganisation)
	{
		$this->_idOrganisation = $idOrganisation;
	}
	public function getCount()
	{
		return $this->count;
	}

	public function setCount($count)
	{
		$this->count = $count;

	}

	public function getPages()
	{
		return $this->_pages;
	}

	public function setPages($p)
	{
		$this->_pages = $p;
	}

	public function getPageSize()
	{
		return $this->_pageSize;
	}

	public function setPageSize($ps)
	{
		$this->_pageSize = $ps;
	}

	public function getDefaultValue()
	{
		return $this->_defaultValue;
	}

	public function setDefaultValue($dv)
	{
		$this->_defaultValue = $dv;
	}
}