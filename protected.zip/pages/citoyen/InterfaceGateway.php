<?php
class InterfaceGateway extends AtexoPage{


    public function onLoad(){
        if(self::verificationParametre()) {
            Atexo_User_CurrentUser::writeToSession('infoRequerant', $_POST);
            Atexo_User_CurrentUser::writeToSession("lang", $_POST['langueNa']);
        }
        $this->response->redirect("index.php?page=citoyen.PrendreRendezVous");
    }




    // ajouter id teleservice
    public function verificationParametre(){
        if(
            isset($_POST['nom']) &&
            isset($_POST['prenom'])&&
            isset($_POST['adresse'])&&
            isset($_POST['id_utilisateur'])&&
            isset($_POST['langueNavigation'])&&
            isset($_POST['modifiable'])&&
            isset($_POST['hmac'])&&
            (self::calculerHash()==$_POST['hmac'])
        ){
            return true;
        }
        return false;
    }

    public function calculerHash(){//24
        // l'odre est important
        $cleService = Atexo_Config::getParameter('CLE_SERVICE_GATEWAY');;
        $cle = $_POST['nom'].
            $_POST['prenom'].
            $_POST['adresse'] .
            $_POST['dateNaissance'] .
            $_POST['email'] .
            $_POST['code_postal'] .
            $_POST['telephone'] .
            $_POST['raison_sociale'] .
            $_POST['identifiant'] .
            $_POST['champ_supp_rdv_1'] .
            $_POST['champ_supp_rdv_2'] .
            $_POST['champ_supp_rdv_3'] .
            $_POST['idEtablissement'] .
            $_POST['type_prestation'] .
            $_POST['prestation'] .
            $_POST['id_utilisateur'] .
            $_POST['langueNavigation'] .
            $_POST['libelle_pays'] .
            $_POST['code_pays'] .
            $_POST['libelle_region'] .
            $_POST['code_region'] .
            $_POST['libelle_province'] .
            $_POST['code_province'] .
            $_POST['libelle_localite'] .
            $_POST['code_localite'] .
            $_POST['modifiable'] .
            $cleService;
        return sha1($cle);
    }

}
