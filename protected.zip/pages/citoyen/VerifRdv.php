<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class VerifRdv extends AtexoPage {
	
	public function onLoad()
	{
		if(!$this->is_sha1($_GET['code'])) {
            echo "0";
            exit;
        }
        echo TRendezVousPeer::isVisioToStart($_GET['code']);
        exit;
	}
    
    
    private function is_sha1($str) {
        return (bool) preg_match('/^[0-9a-f]{64}$/i', $str);
    }
}