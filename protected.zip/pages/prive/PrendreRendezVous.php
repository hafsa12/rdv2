<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class PrendreRendezVous extends AtexoPage {

    public $data;
    public $jeton;
	public function onInit()
	{
		$this->Master->setCalledFrom("citoyen");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad($param)
    {
        if($_GET['jeton']){
            $demandeSession = new TDemandeSessionQuery();
            $session = $demandeSession->findOneByJeton($_GET['jeton']);
            if(!isset($session)){
                echo "Jeton invalide";
                exit;
            }
            $this->data = json_decode(unserialize($session->getJson()));
            $this->jeton = $session->getJeton();
            $dateExpiration = $session->getDateExpiration();
            $now = date("Y-m-d H:i:s");
            if (strtotime($dateExpiration) < strtotime($now)){
                echo "Jeton expiré";
                exit;
            }
            $org = TOrganisationPeer::retrieveByPK($session->getIdOrganisation());
            $_SESSION["typePrestation"] = $org->getTypePrestation();
            $_SESSION["idOrg"] = $session->getIdOrganisation();
        }else{
            echo "Ressource interdite";
            exit;
        }
    }
}