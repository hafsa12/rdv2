<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class PopUpImpression extends AtexoPage{

    public function onLoad() {
        if($_GET["idRdv"]) {
            $tRdvQuery = new TRendezVousQuery();
            $rdv = $tRdvQuery->getRendezVousById($_GET["idRdv"]);
            $lang = Atexo_User_CurrentUser::readFromSession("lang");
            $this->confirmationRdv->initialize($rdv->getTPrestation()->getTTypePrestation()->getLibelleTypePrestationTraduit($lang),
                $rdv->getTPrestation()->getLibellePrestationTraduit($lang), $rdv);
            $this->confirmationRdv->hidePanelConfirmation();
            $this->confirmationRdv->hideRetour();
            $this->confirmationRdv->hidePanelEmail();
            $this->confirmationRdv->hidePanelReservation();
            $this->confirmationRdv->hidePanelBtn();
            /*if(in_array($rdv->getEtatRdv(), array(Atexo_Config::getParameter("ETAT_ANNULE"), Atexo_Config::getParameter("ETAT_ANNULE_ETAB")))) {
                $this->confirmationRdv->showPanelAnnulation();
            }*/
            $this->confirmationRdv->showPanelStatut();
        }
    }
}