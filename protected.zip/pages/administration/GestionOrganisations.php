<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionOrganisations extends AtexoPage {

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionOrganisation')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {
			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$criteriaVo = new Atexo_Organisation_CriteriaVo();
			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$criteriaVo->setIdOrganisation($idOrganisation);
				$this->searchPanel->setVisible(false);
				$this->ajoutPanelHaut->setVisible(false);
				$this->ajoutPanelBas->setVisible(false);
			}
			$lang = Atexo_User_CurrentUser::readFromSession("lang");
			$criteriaVo->setLang($lang);
			$criteriaVo->setSortByElement("DENOMINATION_ORGANISATION");
			$this->fillRepeaterWithDataForSearchResult($criteriaVo);
		}
	}

	/**
	 * @param $criteriaVo
	 * Remplir repeater des organisations selon les critères de recherche
	 */
	public function fillRepeaterWithDataForSearchResult($criteriaVo)
	{
		$tOrganisationPeer = new TOrganisationPeer();
		//Nombre des organisations
		$nombreElement = $tOrganisationPeer->getOrganisationByCriteres($criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->panelBottom->setVisible(true);
			$this->panelTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->nombrePageTop->Text=ceil($nombreElement/$this->listeOrganisation->PageSize);
			$this->nombrePageBottom->Text=ceil($nombreElement/$this->listeOrganisation->PageSize);
			$this->listeOrganisation->setVirtualItemCount($nombreElement);
			$this->listeOrganisation->setCurrentPageIndex(0);
			$this->Page->setViewState("CriteriaVo",$criteriaVo);
			$this->populateData($criteriaVo);
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
			$this->panelTop->setVisible(false);
			$this->panelBottom->setVisible(false);
			$this->listeOrganisation->DataSource=array();
			$this->listeOrganisation->DataBind();
			$this->nombreElement->Text="0";
		}
	}

	/**
	 * Rechercher Organisation par critères 
	 */
	protected function suggestNames($sender,$param) {
		// Get the token
		$token=$this->motsCles->SafeText;
		// Sender is the Suggestions repeater
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$criteriaVo = new Atexo_Organisation_CriteriaVo();
		$criteriaVo->setLang($lang);
		$criteriaVo->setMotCle($token);
		$criteriaVo->setSuggest(true);
		$this->fillRepeaterWithDataForSearchResult($criteriaVo);
		$this->organisationPanel->render($param->getNewWriter());
	}

	/**
	 * @param $criteriaVo
	 * Peupler les données d'organisation
	 */
	public function populateData(Atexo_Organisation_CriteriaVo $criteriaVo)
	{
		$nombreElement = $this->getViewState("nombreElement");
		$offset = $this->listeOrganisation->CurrentPageIndex * $this->listeOrganisation->PageSize;
		$limit = $this->listeOrganisation->PageSize;
		if ($offset + $limit > $nombreElement) {
			$limit = $nombreElement - $offset;
		}
		$criteriaVo->setOffset($offset);
		$criteriaVo->setLimit($limit);
		$dataOrganisation = TOrganisationPeer::getOrganisationByCriteres($criteriaVo);
		$this->listeOrganisation->DataSource=$dataOrganisation;
		$this->listeOrganisation->DataBind();
	}

	public function Trier($sender,$param)
	{
		$champsOrderBy = $sender->CommandParameter;
		$this->setViewState('sortByElement',$champsOrderBy);
		$criteriaVo=$this->Page->getViewState("CriteriaVo");
		$criteriaVo->setSortByElement($champsOrderBy);
		$arraySensTri=$this->Page->getViewState("sensTriArray",array());
		$arraySensTri[$champsOrderBy]=($criteriaVo->getSensOrderBy()=="ASC")? "DESC" : "ASC";
		$criteriaVo->setSensOrderBy($arraySensTri[$champsOrderBy]);
		$this->Page->setViewState("sensTriArray",$arraySensTri);
		$this->Page->setViewState("CriteriaVo",$criteriaVo);
		$this->listeOrganisation->setCurrentPageIndex(0);
		$this->populateData($criteriaVo);
		$this->organisationPanel->render($param->getNewWriter());
	}

	public function pageChanged($sender,$param)
	{
		$this->listeOrganisation->CurrentPageIndex =$param->NewPageIndex;
		$this->numPageBottom->Text=$param->NewPageIndex+1;
		$this->numPageTop->Text=$param->NewPageIndex+1;
		$criteriaVo=$this->Page->getViewState("CriteriaVo");
		$this->populateData($criteriaVo);
	}

	public function goToPage($sender,$param)
	{
		switch ($sender->ID) {
			case "DefaultButtonTop" :    $numPage=$this->numPageTop->Text;
			break;
			case "DefaultButtonBottom" : $numPage=$this->numPageBottom->Text;
			break;
		}
		if (Atexo_Utils_Util::isEntier($numPage)) {
			if ($numPage>=$this->nombrePageTop->Text) {
				$numPage=$this->nombrePageTop->Text;
			} else if ($numPage<=0) {
				$numPage=1;
			}
			$this->listeOrganisation->CurrentPageIndex =$numPage-1;
			$this->numPageBottom->Text=$numPage;
			$this->numPageTop->Text=$numPage;
			$criteriaVo=$this->Page->getViewState("CriteriaVo");
			$this->populateData($criteriaVo);
		} else {
			$this->numPageTop->Text=$this->listeOrganisation->CurrentPageIndex+1;
			$this->numPageBottom->Text=$this->listeOrganisation->CurrentPageIndex+1;
		}
	}

	public function changePagerLenght($sender,$param)
	{
		switch ($sender->ID) {
			case "nombreResultatAfficherBottom" : $pageSize=$this->nombreResultatAfficherBottom->getSelectedValue();
			$this->nombreResultatAfficherTop->setSelectedValue($pageSize);
			break;
			case "nombreResultatAfficherTop" : $pageSize=$this->nombreResultatAfficherTop->getSelectedValue();
			$this->nombreResultatAfficherBottom->setSelectedValue($pageSize);
			break;
		}
			
		$this->listeOrganisation->PageSize=$pageSize;
		$nombreElement=$this->getViewState("nombreElement");
		$this->nombrePageTop->Text=ceil($nombreElement/$this->listeOrganisation->PageSize);
		$this->nombrePageBottom->Text=ceil($nombreElement/$this->listeOrganisation->PageSize);
		$criteriaVo=$this->Page->getViewState("CriteriaVo");
		$this->listeOrganisation->setCurrentPageIndex(0);
		$this->populateData($criteriaVo);
	}

	/**
	 * 
	 * Confirmer la suppression d'une organisation
	 */
	public function onConfirmSuppressionClick($sender,$param) {

		$tOrganisationQuery = new TOrganisationQuery();
		$idOrganisation = $this->organisationToDeleteHidden->Value;

		$tOrganisation = $tOrganisationQuery->getOrganisationById($idOrganisation);

		$etablissementGestion = new Atexo_Etablissement_Gestion();
		$lang = Atexo_User_CurrentUser::readFromSession("lang");

		$tabEtab = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,$idOrganisation) ;

		if($tOrganisation instanceof TOrganisation) {
			if (count($tabEtab)==0) {

				$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
				$connexion->beginTransaction();
				
				$tTraductionDenomination = $tOrganisation->getTTraductionRelatedByCodeDenominationOrganisation();
				$tTraductionAdresse = $tOrganisation->getTTraductionRelatedByCodeAdresseOrganisation();
				$tTraductionDescription = $tOrganisation->getTTraductionRelatedByCodeDescriptionOrganisation();
				$tTraductionMessage = $tOrganisation->getTTraductionRelatedByCodeMessageBienvenue();
				$tTraductionTitre = $tOrganisation->getTTraductionRelatedByCodeTitreBienvenue();

				$tOrganisation->delete($connexion);
				
				$tTraductionDenomination->deleteAll($connexion);
				$tTraductionAdresse->deleteAll($connexion);
				$tTraductionDescription->deleteAll($connexion);
				$tTraductionMessage->deleteAll($connexion);
				$tTraductionTitre->deleteAll($connexion);
				
				$connexion->commit();
				
				//Denomination
				$this->paneldeleteFail->style="display:none";
				$this->paneldeleteOk->style="display:block";

				//Remplir repeater Organisation
				$criteriaVo=$this->Page->getViewState("CriteriaVo");
				$this->populateData($criteriaVo);
			}

			else {

				$this->paneldeleteOk->style="display:none";
				$this->paneldeleteFail->style="display:block";
			}
		}

		//Remplir repeater Organisation
		$criteriaVo=$this->Page->getViewState("CriteriaVo");
		$this->fillRepeaterWithDataForSearchResult($criteriaVo);
		$this->organisationPanel->render($param->NewWriter);
	}

	public function isTrierPar($champ) {
		$sortByElement = $this->getViewState('sortByElement');
		if($champ!=$sortByElement) {
			return "";
		}
		$arraySens = $this->getViewState("sensTriArray");
		if($arraySens[$sortByElement]=="ASC") {
			return "tri-on tri-asc";
		}
		return "tri-on tri-desc";
	}
}