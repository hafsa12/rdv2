<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionParametragePrestations extends AtexoPage {

	private $_lang = "";
	/**
	 * @var Atexo_Prestation_CriteriaVo
	 */
	protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionParamPrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack) {
            if(!isset($_GET["search"])) {
                unset($_SESSION["parametragePresta"]["criteriaVoSearch"]);
                unset($_SESSION["parametragePresta"]["sensTri"]);
                unset($_SESSION["parametragePresta"]["sortByElement"]);
            }
            $this->init();
		}else{
            $this->_criteriaVo = $_SESSION["parametragePresta"]["criteriaVoSearch"];
        }
	}

	protected function init() {

		$this->_criteriaVo = $_SESSION["parametragePresta"]["criteriaVoSearch"];

		$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
		$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
		$this->loadOrganisation();
        $idOrganisation = null;
        $typePrestation = null;

		if(!$this->_criteriaVo) {

            $this->_criteriaVo = new Atexo_Prestation_CriteriaVo();

            if($adminOrg) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
                $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
                $this->listeOrganisation->SelectedValue = $idOrganisation;
                $this->listeOrganisation->Enabled = false;
            }
            if($adminEtab) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache ();
                $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
                $this->listeOrganisation->SelectedValue = $idOrganisation;
                $this->listeOrganisation->Enabled = false;
            }
            $this->loadRefTypePrestation();

			$this->_criteriaVo->setSortByElement("LIBELLE_REF_PRESTATION");
            $this->_criteriaVo->setSensOrderBy("ASC");

            $this->_criteriaVo->setPrestationReferentiel($_SESSION["typePrestation"]);

            $_SESSION["parametragePresta"]["sortByElement"] = "LIBELLE_REF_PRESTATION";
            $_SESSION["parametragePresta"]["sensTri"] =  "ASC";
		}
        else {
            $this->listeOrganisation->SelectedValue = $this->_criteriaVo->getIdOrganisation();

            $this->loadRefTypePrestation ();
            $this->listeTypePrestation->SelectedValue = $this->_criteriaVo->getIdTypePrestation ();

            if($adminOrg || $adminEtab) {
                $this->listeOrganisation->Enabled = false;
            }
        }
        $this->_criteriaVo->setLang($this->_lang);

        if(isset($_GET["pages"])) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if(isset($_GET["pageSize"])) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listePrestation->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif(!$this->_criteriaVo->getPageSize()) {
            $this->_criteriaVo->setPageSize(10);
        }
		$this->fillRepeaterWithDataForSearchResult();
	}

		/*
         * Remplir la liste des organisations
         */
	public function loadOrganisation() {
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($this->_lang, Prado::localize('ORGANISATION'));
		$this->listeOrganisation->DataBind();
	}

	/*
	 * Remplir la liste des types-prestations 
	 */
	public function loadRefTypePrestation() {
		try {
            $refTypePrestationPeer = new TRefTypePrestationPeer();

            $criteriaVo = new Atexo_RefPrestation_CriteriaVo();
            $criteriaVo->setDefaultValue(Prado::localize ( 'TYPE_PRESTATION' ));
            $criteriaVo->setIdOrganisation($this->listeOrganisation->getSelectedValue());
            $criteriaVo->setLang($this->_lang);

            $this->listeTypePrestation->DataSource = $refTypePrestationPeer->getRefTypePrestationByCriteres ( $criteriaVo );
            $this->listeTypePrestation->DataBind ();
        }catch(Exception $e){
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	/*
	 * @param $criteriaVo
	 * Remplir repeater des établissements selon les critères de recherche 
	 */
	public function fillRepeaterWithDataForSearchResult()
	{
		$tParametragePrestationPeer = new TParametragePrestationPeer();
		//Nombre des Prestations

		$nombreElement = $tParametragePrestationPeer->getParametragePrestationByCriteres($this->_criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
            $this->panelBottom->setVisible(true);
            $this->panelTop->setVisible(true);
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listePrestation->setVirtualItemCount($nombreElement);
			$this->listePrestation->setCurrentPageIndex(0);
			$this->populateData();
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
            $this->panelBottom->setVisible(false);
            $this->panelTop->setVisible(false);
			$this->listePrestation->DataSource=array();
			$this->listePrestation->DataBind();
			$this->nombreElement->Text="0";
		}
        $_SESSION["parametragePresta"]["criteriaVoSearch"] = $this->_criteriaVo;
	}

	/**
	 * Peupler les données des prestations
	 */
	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");
        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listePrestation->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listePrestation->CurrentPageIndex = $numPage -1;

        $offset = $this->listePrestation->CurrentPageIndex * $pageSize;
		$limit = $pageSize;
        $this->listePrestation->PageSize = $limit;

		if ($offset + $limit > $nombreElement) {
			$limit = $nombreElement - $offset;
		}
		$this->_criteriaVo->setOffset($offset);
		$this->_criteriaVo->setLimit($limit);

		$dataPrestation = TParametragePrestationPeer::getParametragePrestationByCriteres($this->_criteriaVo);
		$this->listePrestation->DataSource = $dataPrestation;
		$this->listePrestation->DataBind();

        $pageSize = $this->listePrestation->PageSize;

        $this->numPageBottom->Text = $numPage;
        $this->numPageTop->Text = $numPage;
        $this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
        $this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
        $this->nombrePageTop->Text = $nombrePages;
        $this->nombrePageBottom->Text = $nombrePages;
	}

	/*
	 * Rechercher Prestation par critères 
	 */
	protected function suggestNames($sender,$param) {
        try {
            $token = $this->motsCles->SafeText;
            $this->_criteriaVo = new Atexo_Prestation_CriteriaVo();
            $this->_criteriaVo->setLang ( $this->_lang );
            $this->_criteriaVo->setMotCle ( $token );

            if ( $this->listeTypePrestation->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdRefTypePrestation ( $this->listeTypePrestation->getSelectedValue () );
            }
            if ( $this->listeOrganisation->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdOrganisation ( $this->listeOrganisation->getSelectedValue () );
            }
            //$this->_criteriaVo->setPrestationReferentiel($_SESSION["typePrestation"]);
            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);

            // tri
            $this->_criteriaVo->setSortByElement($_SESSION["parametragePresta"]["sortByElement"]);
            $this->_criteriaVo->setSensOrderBy($_SESSION["parametragePresta"]["sensTri"]);

            unset($_GET["pageSize"]);
            unset($_GET["pages"]);

            $this->fillRepeaterWithDataForSearchResult ();
            $this->prestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}



	public function Trier($sender,$param)
	{
        try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["parametragePresta"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $_SESSION["parametragePresta"]["sensTri"] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $_SESSION["parametragePresta"]["sensTri"] );

            $_SESSION["parametragePresta"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
            $this->populateData ();
            $this->prestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function pageChanged($sender,$param)
	{
        $urlParams = "&pages=".($param->NewPageIndex+1);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionParametragePrestations&search".$urlParams);
	}

	public function goToPage($sender)
	{
        switch ($sender->ID) {
            case "DefaultButtonTop" :
                $numPage = $this->numPageTop->Text;
                break;
            case "DefaultButtonBottom" :
                $numPage = $this->numPageBottom->Text;
                break;
        }
        $urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeTypePrestation->CurrentPageIndex+1, $this->nombrePageTop->Text);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionParametragePrestations&search".$urlParams);
	}

	public function changePagerLenght($sender)
	{
        switch ($sender->ID) {
            case "nombreResultatAfficherBottom" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
                break;
            case "nombreResultatAfficherTop" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
                break;
        }
        $this->response->redirect("?page=administration.GestionParametragePrestations&search&pages=1&pageSize=".$pageSize);
	}

	/**
	 * 
	 * Confirmer la suppression d'une prestation
	 */
	public function onConfirmSuppressionClick($sender,$param) {
        $idParametragePrestation = $this->prestationToDeleteHidden->Value;
		$tParametragePrestation = TParametragePrestationQuery::create()->findPk($idParametragePrestation);

		if($tParametragePrestation instanceof TParametragePrestation && count($tParametragePrestation->getTPrestations())==0) {

			$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
			$connexion->beginTransaction();

			$tTraductionCommentaire = $tParametragePrestation->getTTraductionRelatedByCodeCommentaire();

            $tParametragePrestation->delete($connexion);

            $tTraductionCommentaire->deleteAll($connexion);

            $connexion->commit();
			
			$this->paneldeleteFail->style="display:none";
			$this->paneldeleteOk->style="display:block";
		}
		else {
			$this->paneldeleteFail->style="display:block";
			$this->paneldeleteOk->style="display:none";
		}

		//Remplir repeater Prestation
		$this->fillRepeaterWithDataForSearchResult();
		$this->prestationPanel->render($param->NewWriter);
	}

	public function isTrierPar($champ) {
        $sortByElement = $_SESSION["parametragePresta"]["sortByElement"];
		if($champ!=$sortByElement) {
			return "";
		}
		if( $_SESSION["parametragePresta"]["sensTri"] == "ASC" ) {
			return "tri-on tri-asc";
		}
		return "tri-on tri-desc";
	}

    public function getLibelleRessourceObligatoire($visible, $enumeration) {
        if($visible) {
            return Atexo_Utils_Util::getLibelleEnumOuiNon($enumeration);
        }
        return Prado::localize("TRANS_CHAMP_VIDE");
    }
}
