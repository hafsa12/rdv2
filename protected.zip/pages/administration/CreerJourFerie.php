<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

/**
 * @author user
 *
 */
class CreerJourFerie extends AtexoPage {

	private $_dataDenomination = null;
	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionJoursFeries')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {
			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$this->loadOrganisation();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}

			$this->loadJours();
			$this->loadMois();
			$this->loadAnnee();
			self::getListeChampsParLangues($this->_dataDenomination);
			if(isset($_GET["idJourFerie"])) {
				$this->remplir($_GET["idJourFerie"]);
			}
		}
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}


	public function getListeChampsParLangues($dataDenomination) {
		self::getListeDenominationParLangues($dataDenomination);
	}

	/**
	 * @param $data
	 * récuprer repeater nom du jour férié
	 */
	public function getListeDenominationParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeDenominationParLangues($data);
		} else {
			//recup�rer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['denominationLibelleLang'] = Prado::localize('NOM_JOUR_FERIE');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['denomination'] = '';
				$data[$index]['langDenomination'] = $lan;
				$index++;
			}
			$this->setListeDenominationParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater nom du jour férié
	 */
	public function setListeDenominationParLangues($data) {
		$this->listeDenominationLangues->dataSource = $data;
		$this->listeDenominationLangues->dataBind();
		$index = 0;
		foreach ($this->listeDenominationLangues->getItems() as $item) {
			$item->denominationLibelleLang->Text = $data[$index]['denominationLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->denomination->Text = $data[$index]['denomination'];
			$item->langDenomination->Value = $data[$index]['langDenomination'];
			$index++;
		}
	}

	/**
	 * Remplir la liste des jours
	 */
	public function loadJours() {
		$data = array();
		$data[0] = Prado::localize('JOUR');
		for($i=1;$i<=31;$i++) {
			$data[$i] = $i;
		}
			
		$this->listeJours->DataSource = $data;
		$this->listeJours->DataBind();
	}

	/**
	 * Remplir la liste des mois
	 */
	public function loadMois() {
		$data = array();
		$data[0] = Prado::localize('MOIS');
		for($i=1;$i<=12;$i++) {
			$data[$i] = Prado::localize('MONTH'.$i);
		}
			
		$this->listeMois->DataSource = $data;
		$this->listeMois->DataBind();
	}

	/**
	 * Remplir la liste des années
	 */
	public function loadAnnee() {
		$data = array();
		$data[0] = Prado::localize('ANNEE');
		for($i=date('Y');$i<=2035;$i++) {
			$data[$i] = $i;
		}

		$this->listeAnnees->DataSource = $data;
		$this->listeAnnees->DataBind();
	}

	/**
	 * enregistrer les informations du jour férié
	 */
	public function enregistrer() {

		if(isset($_GET["idJourFerie"])) {
			$tJourFerieQuery = new TJourFerieQuery();
			$tJourFerie = $tJourFerieQuery->getJourFerieById($_GET["idJourFerie"]);
			$tTraductionDenomination = $tJourFerie->getTTraduction();
		}
		if(!($tJourFerie instanceof TJourFerie)) {
			$tJourFerie = new TJourFerie();
			$tTraductionDenomination = new TTraduction();
		}

		foreach($this->listeDenominationLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionDenomination->getTTraductionLibelle($item->langDenomination->Value);
			$tTraductionLibelle->setLang($item->langDenomination->Value);
			$tTraductionLibelle->setLibelle($item->denomination->Text);
			$tTraductionDenomination->addTTraductionLibelle($tTraductionLibelle);
		}
		$tJourFerie->setTTraduction($tTraductionDenomination);
		$tJourFerie->setIdOrganisme($this->listeOrganisation->getSelectedValue());
		$tJourFerie->setJour($this->listeJours->getSelectedValue());
		$tJourFerie->setMois($this->listeMois->getSelectedValue());

		if($this->listeAnnees->getSelectedValue()) {
			$tJourFerie->setAnnee($this->listeAnnees->getSelectedValue());
		}
		else {
			$tJourFerie->setAnnee(NULL);
		}
			
		$tJourFerie->save();
		$url = "index.php?page=administration.GestionJoursFeries&search";
		$this->response->redirect($url);
	}

	/**
	 * récuperer les informations du jour férié
	 */
	public function remplir($idJourFerie)
	{
		if(isset($idJourFerie)) {
			$tJourFerieQuery = new TJourFerieQuery();
			$tJourFerie = $tJourFerieQuery->getJourFerieById($idJourFerie);
		}
		if ($tJourFerie instanceof TJourFerie){
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataDenomination[$index]['denominationLibelleLang'] = Prado::localize('NOM_JOUR_FERIE');
				$this->_dataDenomination[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataDenomination[$index]['denomination'] = $tJourFerie->getNomJourFerieTraduit($lan);
				$this->_dataDenomination[$index]['langDenomination'] = $lan;
				$index++;
			}
			$this->setListeDenominationParLangues($this->_dataDenomination);
			$this->listeOrganisation->SelectedValue = $tJourFerie->getIdOrganisme();
			$this->listeJours->SelectedValue = $tJourFerie->getJour();
			$this->listeMois->SelectedValue = $tJourFerie->getMois();
			if($tJourFerie->getAnnee()) {
				$this->listeAnnees->SelectedValue = $tJourFerie->getAnnee();
			}
		}
	}
}