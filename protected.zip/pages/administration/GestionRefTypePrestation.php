<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionRefTypePrestation extends AtexoPage {

    private $_lang = "";
    /**
     * @var Atexo_RefPrestation_CriteriaVo
     */
    protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionRefTypePrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
        $this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
        if(!$this->isPostBack) {
            if(!isset($_GET["search"])) {
                unset($_SESSION["refTypePresta"]["criteriaVoSearch"]);
                unset($_SESSION["refTypePresta"]["sensTriArray"]);
                unset($_SESSION["refTypePresta"]["sortByElement"]);
            }
            $this->init();
        }else{
            $this->_criteriaVo = $_SESSION["refTypePresta"]["criteriaVoSearch"];
        }
		$this->paneldeleteFail->style="display:none";
		$this->paneldeleteOk->style="display:none";
	}

    protected function init() {
        $this->_criteriaVo = $_SESSION["refTypePresta"]["criteriaVoSearch"];

        $adminOrg= Atexo_User_CurrentUser::isAdminOrg();
        $this->loadOrganisation();

        if(!$this->_criteriaVo) {

            $this->_criteriaVo = new Atexo_RefPrestation_CriteriaVo();

            if ( $adminOrg ) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
                $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
                $this->listeOrganisation->SelectedValue = $idOrganisation;
                $this->listeOrganisation->Enabled = false;
            }

            $this->_criteriaVo->setSortByElement ( "LIBELLE_REFERENTIEL_TYPE_PRESTATION" );
            $_SESSION["refTypePresta"]["sortByElement"] = "LIBELLE_REFERENTIEL_TYPE_PRESTATION";
            $_SESSION["refTypePresta"]["sensTriArray"] = array( "LIBELLE_REFERENTIEL_TYPE_PRESTATION" => "ASC" );
        }
        else {
            if ( $adminOrg ) {
                $this->listeOrganisation->SelectedValue = $this->_criteriaVo->getIdOrganisation ();
                $this->listeOrganisation->Enabled = false;
            }
            $this->motsCles->Text = $this->_criteriaVo->getMotCle();
        }
		$this->_criteriaVo->setLang ( $this->_lang );

        if( isset( $_GET["pages"] ) ) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if( isset( $_GET["pageSize"] ) ) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listeRefTypePrestation->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif ( !$this->_criteriaVo->getPageSize() ) {
            $this->_criteriaVo->setPageSize(10);
        }

        $this->fillRepeaterWithDataForSearchResult ();
    }
	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($this->_lang, Prado::localize('ORGANISATION'));
		$this->listeOrganisation->DataBind();
	}

	/**
	 * Remplir repeater des établissements selon les critères de recherche
	 */
	public function fillRepeaterWithDataForSearchResult()
	{
		$tRefTypePrestationPeer = new TRefTypePrestationPeer();
		//Nombre des Prestations
		$nombreElement = $tRefTypePrestationPeer->geTRefTypePrestationByCriteres($this->_criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->panelBottom->setVisible(true);
			$this->panelTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listeRefTypePrestation->setVirtualItemCount($nombreElement);
			$this->listeRefTypePrestation->setCurrentPageIndex(0);
			$this->populateData();
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
			$this->panelTop->setVisible(false);
			$this->panelBottom->setVisible(false);
			$this->listeRefTypePrestation->DataSource=array();
			$this->listeRefTypePrestation->DataBind();
			$this->nombreElement->Text="0";
		}
        $_SESSION["refTypePresta"]["criteriaVoSearch"] = $this->_criteriaVo;
	}

	/**
	 * Peupler les données des prestations
	 */
	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");

        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listeRefTypePrestation->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listeRefTypePrestation->CurrentPageIndex = $numPage -1;

        $offset = $this->listeRefTypePrestation->CurrentPageIndex * $pageSize;
        $limit = $pageSize;
        $this->listeRefTypePrestation->PageSize = $limit;

        if ($offset + $limit > $nombreElement) {
            $limit = $nombreElement - $offset;
        }
        $this->_criteriaVo->setOffset($offset);
        $this->_criteriaVo->setLimit($limit);

		$dataRefTypePrestation = TRefTypePrestationPeer::geTRefTypePrestationByCriteres($this->_criteriaVo);
		$this->listeRefTypePrestation->DataSource=$dataRefTypePrestation;
		$this->listeRefTypePrestation->DataBind();

		$pageSize = $this->listeRefTypePrestation->PageSize;

		$this->numPageBottom->Text = $numPage;
		$this->numPageTop->Text = $numPage;
		$this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
		$this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
		$this->nombrePageTop->Text = $nombrePages;
		$this->nombrePageBottom->Text = $nombrePages;
	}

	/**
	 * Rechercher Prestation par critères
	 */
	protected function suggestNames($sender,$param) {
        try {
            $token = $this->motsCles->SafeText;

            $this->_criteriaVo = new Atexo_RefPrestation_CriteriaVo();
            $this->_criteriaVo->setLang ( $this->_lang );
            $this->_criteriaVo->setMotCle ( $token );

            if ( $this->listeOrganisation->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdOrganisation ( $this->listeOrganisation->getSelectedValue () );
            }
            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);
            unset($_GET["pageSize"]);
            unset($_GET["pages"]);

            $this->fillRepeaterWithDataForSearchResult ();
            $this->refTypePrestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function Trier($sender,$param)
	{
		try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["refTypePresta"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $arraySensTri = $_SESSION["refTypePresta"]["sensTriArray"] ? $_SESSION["refTypePresta"]["sensTriArray"] : array ();
            $arraySensTri[ $champsOrderBy ] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $arraySensTri[ $champsOrderBy ] );
            $_SESSION["refTypePresta"]["sensTriArray"] = $arraySensTri;

            $_SESSION["refTypePresta"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
            $this->populateData ();
            $this->refTypePrestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
			$logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
			$logger->error($e->getMessage());
		}
	}

	public function pageChanged($sender,$param)
	{
		$urlParams = "&pages=".($param->NewPageIndex+1);
		if(isset($_GET["pageSize"])) {
			$urlParams .= "&pageSize=".$_GET["pageSize"];
		}
		$this->response->redirect("?page=administration.GestionRefTypePrestation&search".$urlParams);
	}

	public function goToPage($sender)
	{
		switch ($sender->ID) {
			case "DefaultButtonTop" :    $numPage=$this->numPageTop->Text;
				break;
			case "DefaultButtonBottom" : $numPage=$this->numPageBottom->Text;
				break;
		}
		$urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeRefTypePrestation->CurrentPageIndex+1, $this->nombrePageTop->Text);
		if(isset($_GET["pageSize"])) {
			$urlParams .= "&pageSize=".$_GET["pageSize"];
		}
		$this->response->redirect("?page=administration.GestionRefTypePrestation&search".$urlParams);
	}

	public function changePagerLenght($sender)
	{
		switch ($sender->ID) {
			case "nombreResultatAfficherBottom" :
				$pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
				break;
			case "nombreResultatAfficherTop" :
				$pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
				break;
		}
		$this->response->redirect("?page=administration.GestionRefTypePrestation&search&pages=1&pageSize=".$pageSize);
	}

	/**
	 * 
	 * Confirmer la suppression d'une organisation
	 */
	public function onConfirmSuppressionClick($sender,$param) {

		$tRefTypePrestationQuery = new TRefTypePrestationQuery();
		$idRefTypePrestation = $this->refTypePrestationToDeleteHidden->Value;

		$tRefTypePrestation = $tRefTypePrestationQuery->getRefTypePrestationById($idRefTypePrestation);


		if($tRefTypePrestation instanceof TRefTypePrestation) {

			$typePrestationGestion = new Atexo_TypePrestation_Gestion();
			$tabTypePrest = $typePrestationGestion->getTypePrestationByIdRefTypePrestation($this->_lang,$idRefTypePrestation);

			if (count($tabTypePrest)==0) {
				$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
				$connexion->beginTransaction();
				$tTraductionLibelle = $tRefTypePrestation->getTTraduction();
				$tRefTypePrestation->delete($connexion);
				$tTraductionLibelle->deleteAll($connexion);
				$connexion->commit();
				
				$this->paneldeleteFail->style="display:none";
				$this->paneldeleteOk->style="display:block";
			}
			else {
				$this->paneldeleteOk->style="display:none";
				$this->paneldeleteFail->style="display:block";
			}
		}

		//Remplir repeater Ref Prestation
		$this->fillRepeaterWithDataForSearchResult();
		$this->refTypePrestationPanel->render($param->NewWriter);
	}

	public function isTrierPar($champ) {
        $sortByElement = $_SESSION["refTypePresta"]["sortByElement"];
        if($champ!=$sortByElement) {
            return "";
        }
        $arraySens = $_SESSION["refTypePresta"]["sensTriArray"] ? $_SESSION["refTypePresta"]["sensTriArray"] : array ();
        if($arraySens[$sortByElement]=="ASC") {
            return "tri-on tri-asc";
        }
        return "tri-on tri-desc";
	}
}
