<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class PrendreRendezVousAdmin extends AtexoPage {

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
		$this->Master->setPrendreRdv(true);
	}
	
	public function onLoad() {
		
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionDesRendezVous')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
	}
}