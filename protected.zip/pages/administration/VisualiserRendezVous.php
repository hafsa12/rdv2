<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class VisualiserRendezVous extends AtexoPage {

	private $_lang;
	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack) {

			if(Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
				$this->entite1->Style="display:none";
				$this->entite2->Style="display:none";
				$this->entite3->Style="display:none";
			}
			$this->loadEntite1();
			$this->loadEntite2();
			$this->loadEntite3();
			$this->loadDataEtablissement();
			$this->loadDataTypePrestation();
			$this->loadDataPrestation();
			$this->loadRessources();

			$criteria = new Atexo_RendezVous_CriteriaVo();
			$date = date("d/m/Y");
			$criteria->setIdOrganisationAttache(Atexo_User_CurrentUser::getIdOrganisationGere());	
			$criteria->setIdEtablissementAttache(Atexo_User_CurrentUser::getIdEtablissementGere());
			if($this->etablissementRessource->getSelectedValue()) {
				$criteria->setIdEtablissementAttache($this->etablissementRessource->getSelectedValue());
			}
			if($this->typePrestationRessource->getSelectedValue()) {
				$criteria->setIdTypePrestation($this->typePrestationRessource->getSelectedValue());
			}
			if($this->prestationRessource->getSelectedValue()) {
				$criteria->setIdPrestation($this->prestationRessource->getSelectedValue());
			}
			$criteria->setDateDu($date);
			$criteria->setDateAu($date);
			$criteria->setLang($this->_lang);
			$criteria->setNonAnnule();
			$criteria->setSortByElement("DATE_RDV");
			$criteria->setSensOrderBy("ASC");
			$this->selectedDay->Text = $date;

			$this->setViewState("criteria",$criteria);
			$this->setRdvJour($date,$criteria);

		}
	}
	
	public function loadRessources() {
		if(Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
			$idetablissement = explode(",",Atexo_User_CurrentUser::getIdEtablissementGere());
		}else {
			$idetablissement = $this->etablissementRessource->getSelectedValue ();
		}
	    if(Atexo_User_CurrentUser::isAdminOrg() || Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
			$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
		}

		$gestion = new Atexo_Agent_Gestion();
		$this->listeRessources->DataSource = $gestion->getRessourceByCriteres($this->_lang, $idOrganisation, $idetablissement, $this->typePrestationRessource->getSelectedValue (), $this->prestationRessource->getSelectedValue (), Prado::localize('NIVEAU3'));
		$this->listeRessources->DataBind();
	}

	public function loadDataTypePrestation() {
		$idEtab = $this->etablissementRessource->getSelectedValue();
		//Remplir liste Type Prestation
		if($idEtab>0) {
			$typePrests = new Atexo_TypePrestation_Gestion();
			$this->typePrestationRessource->DataSource = $typePrests->getTypePrestationByIdEtab($this->_lang, $idEtab, Prado::localize('TYPE_PRESTATION'));
			$this->typePrestationRessource->DataBind();
		}
		else {
			$this->typePrestationRessource->DataSource = array();
			$this->typePrestationRessource->DataBind();
		}
	}

	public function loadDataPrestation() {
		$idTypePrestation = $this->typePrestationRessource->getSelectedValue();
		if(!$idTypePrestation) {
			$idTypePrestation = -1;
		}
		if(isset($_SESSION['idOrg'])) {
			$tOrganisation = TOrganisationQuery::create()->getOrganisationById($_SESSION['idOrg']);
		}
		$typePrestation = $tOrganisation instanceof TOrganisation ? $tOrganisation->getTypePrestation() : Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE");
		//Remplir liste Type Prestation
		$PrestationGestion = new Atexo_Prestation_Gestion();
		$this->prestationRessource->DataSource = $PrestationGestion->getPrestationByIdTypePrestation($this->_lang,$idTypePrestation, $typePrestation, Prado::localize('PRESTATION'));
		$this->prestationRessource->DataBind();
	}

	public function loadTypePrestation($sender,$param) {
		$this->loadDataTypePrestation();
		$this->loadDataPrestation();
		$this->loadRessources();
	}

	public function loadPrestation($sender,$param) {
		$this->loadDataPrestation();
		$this->loadRessources();
	}

	public function loadDataEtablissement($idEntite1 = null, $idsEntite2 = null) {

		$idOrganisation = $_SESSION["idOrg"];

		if($idEntite1) {
			$entiteGestion = new Atexo_Entite_Gestion();
			$idsCommune = $entiteGestion->getAllIdChildEntite ($idEntite1);
		}
		if($idsEntite2) {
			$entiteGestion = new Atexo_Entite_Gestion();
			$idsCommune = $entiteGestion->getAllIdChildEntite ($idsEntite2);
		}
		if($this->entite3->getSelectedValue ()) {
			$idsCommune = $this->entite3->getSelectedValue ();
		}

		//Remplir liste Etablissement
		$etablissements = new Atexo_Etablissement_Gestion();
		$this->etablissementRessource->DataSource = $etablissements->getEtablissementByIdProvinceIdOrganisation($this->_lang, $idOrganisation, $idsCommune, /*Prado::localize('ETABLISSEMENT')*/false, true);
		$this->etablissementRessource->DataBind();

		if(Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()) {
			$idetablissement = explode(",",Atexo_User_CurrentUser::getIdEtablissementGere());
			$this->etablissementRessource->SelectedValue = $idetablissement[0];
		}else{
			$this->etablissementRessource->SelectedIndex=0;
		}
		$this->loadTypePrestation(null,null);
	}
	
	public function suggestRdvs($sender,$param) {
		
		$this->hideAll();

		if(!$this->etablissementRessource->getSelectedValue()) {
			return;
		}
		$criteria = $this->getViewState("criteria");

        $criteria->setIdEtablissementAttache($this->etablissementRessource->getSelectedValue());
        $criteria->setIdTypePrestation($this->typePrestationRessource->getSelectedValue());
        $criteria->setIdPrestation($this->prestationRessource->getSelectedValue());
        $criteria->setIdRessource($this->listeRessources->SelectedValue);

        if($this->selectedDay->SafeText!='') {
			
			if($this->jour->Checked) {
				$criteria->setDateDu($this->selectedDay->SafeText);
				$criteria->setDateAu($this->selectedDay->SafeText);
				$this->setRdvJour($this->selectedDay->SafeText,$criteria);
			}
			elseif($this->semaine->Checked) {
				$dates = Atexo_Utils_Util::getDatesSemaine($this->selectedDay->SafeText);
				$criteria->setDateDu($dates['deb']);
				$criteria->setDateAu($dates['fin']);
                $criteria->setSortByElement("DATE_RDV");
                $criteria->setSensOrderBy("ASC");
				$this->setRdvSemaine($dates['deb'],$criteria);
			}
			elseif($this->mois->Checked) {
				$dates = Atexo_Utils_Util::getDatesMoisSemaine("01".substr($this->selectedDay->SafeText,2));
				$criteria->setDateDu($dates['deb']);
				$criteria->setDateAu($dates['fin']);
				$this->setRdvMois($criteria);
			}
		}

		$this->setViewState("criteria",$criteria);
		$this->rdvJourPanel->render($param->getNewWriter());
		$this->rdvSemainePanel->render($param->getNewWriter());
		$this->rdvMoisPanel->render($param->getNewWriter());
	}
	
	public function hideAll() {
		$this->rdvJourPanel->Style="display:none";
		$this->rdvSemainePanel->Style="display:none";
		$this->rdvMoisPanel->Style="display:none";
	}
	
	public function setRdvJour($date,$criteria) {

		$this->rdvJourPanel->Style="display:";
		
		$criteria->setGroupByDateJour(true);
		$criteria->setGroupByDateMois(false);
		$criteria->setGroupByDateSemaine(false);
		
		$tRdvPeer = new TRendezVousPeer();
		$data = $tRdvPeer->getRdvByCriteres($criteria);
		
		if(is_array($data)) {
			$dataRdv = $data;
		}
		else {
			$dataRdv = array();
		}
		
		$this->rdvJour->initialize($date, $dataRdv);
	}
	
	public function setRdvSemaine($date,$criteria) {

		$this->rdvSemainePanel->Style="display:";
		
		$criteria->setGroupByDateJour(false);
		$criteria->setGroupByDateMois(false);
		$criteria->setGroupByDateSemaine(true);
		
		$tRdvPeer = new TRendezVousPeer();
		$data = $tRdvPeer->getRdvByCriteres($criteria);
		
		if(is_array($data)) {
			$dataRdv = $data;
		}
		else {
			$dataRdv = array();
		}
		
		$this->rdvSemaine->initialize($date, $dataRdv);
	}
	
	public function setRdvMois($criteria) {

		$this->rdvMoisPanel->Style="display:";
		
		$criteria->setGroupByDateJour(false);
		$criteria->setGroupByDateSemaine(false);
		$criteria->setGroupByDateMois(true);
		
		$tRdvPeer = new TRendezVousPeer();
		$data = $tRdvPeer->getRdvByCriteres($criteria);
		
		if(is_array($data)) {
			$dataRdv = $data;
		}
		else {
			$dataRdv = array();
		}

		$this->rdvMois->initialize($criteria->getDateDu(),$criteria->getDateAu(), $dataRdv, $this->listeRessources->SelectedValue==0);
	}

	/**
	 * Remplir la liste des regions
	 */
	public function loadEntite1() {
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite1->DataSource = $entiteGestion->getAllEntite(1, $this->_lang, null, Prado::localize('ENTITE_1'));
		$this->entite1->DataBind();
	}

	/**
	 * Remplir la liste des provinces
	 */
	public function loadEntite2($sender = null, $param=null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
		$this->entite2->DataBind();
		if($sender) {
			//$this->viderEntite3 ();
			$this->loadEntite3($sender, $param);
		}
	}

	/**
	 * Remplir la liste des communes
	 */
	public function loadEntite3($sender = null, $param=null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$idEntite = null;

		if($this->entite2->SelectedValue) {
			$idEntite = $this->entite2->SelectedValue;
		}elseif($this->entite1->SelectedValue){
			$idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
		}
		$this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
		$this->entite3->DataBind();
		if($sender) {
			$this->loadEtablissement($sender, $param);//$this->loadDataEtablissement ($this->entite1->getSelectedValue(), $this->entite2->getSelectedValue());
		}
	}

	public function loadEtablissement($sender, $param) {
		$this->loadDataEtablissement($this->entite1->getSelectedValue(), $this->entite2->getSelectedValue());
		$this->etablissementRessource->SelectedIndex=0;
		$this->loadTypePrestation($sender,$param);
		$this->etablissementRessource->render($param->NewWriter);
	}

	/**
	 * vider la liste des provinces
	 */
	public function viderEntite2() {
		$this->_criteriaVo->setEntite2(false);
		$this->entite2->DataSource = array(Prado::localize('ENTITE_2'));
		$this->entite2->DataBind();
	}

	/**
	 * vider la liste des communes
	 */
	public function viderEntite3() {
		$this->_criteriaVo->setEntite3(false);
		$this->entite3->DataSource = array(Prado::localize('ENTITE_3'));
		$this->entite3->DataBind();
	}
}