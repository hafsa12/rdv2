<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerPrestationModeRef extends AtexoPage {

	private $_lang = "";
	protected $listeChampsSupp=array();
	/**
	 * @var Atexo_Prestation_CriteriaVo
	 */
	protected $_criteriaVo = "";
	protected $_idOrganisation = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionPrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE") || !$this->checkEtablissement()) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {
			$this->remplirChampsSupp();
			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();

			if($adminOrg) {
				$this->_idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
			}
			if($adminEtab) {
				$this->_idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
				if(is_numeric(Atexo_User_CurrentUser::getIdEtablissementGere())) {
					Atexo_User_CurrentUser::getIdEtablissementGere();
				}
			}

			$this->populateData();
		}
	}

	protected function remplirChampsSupp() {
		$tChampssuppQuery = new TChampsSuppQuery();
		$this->listeChampsSupp = $tChampssuppQuery->getListeChampsSupp(Atexo_User_CurrentUser::getIdOrganisationGere());
	}

	protected function populateData() {
		$this->_criteriaVo = new Atexo_Prestation_CriteriaVo();
		$this->_criteriaVo->setIdOrganisation($this->_idOrganisation);
		$this->_criteriaVo->setLang($this->_lang);
		$this->_criteriaVo->setSortByElement("LIBELLE_REF_PRESTATION");
		$this->_criteriaVo->setSensOrderBy("ASC");
		$this->_criteriaVo->setPrestationReferentiel(true);

		$dataPrestation = TParametragePrestationPeer::getParametragePrestationByCriteres($this->_criteriaVo);
		$dataSource = $this->_getDataSource($dataPrestation);
		//var_dump($dataPrestation);exit;

		$this->listeRefTypePrestation->DataSource = $dataSource;
		$this->listeRefTypePrestation->DataBind();
	}

	public function checkEtablissement() {
		if( !isset( $_GET["idEtab"] ) ) {
			return false;
		}

		// Admin Organisation
		$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
		if($adminOrg) {
			$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
			$tEtablissementQuery = new TEtablissementQuery();
			$tEtablissement = $tEtablissementQuery->getEtablissementById($_GET["idEtab"]);
			if(! $tEtablissement instanceof TEtablissement || $tEtablissement->getIdOrganisation() != $idOrganisation) {
				return false;
			}
			$this->nomEtab->Text = $tEtablissement->getDenominationEtablissementTraduit($this->_lang);
			return true;
		}

		// Admin Etablissement
		$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
		if($adminEtab) {
			$idEtablissement = Atexo_User_CurrentUser::getIdEtablissementGere ();
			$idsEtablissement = explode(',', $idEtablissement);
			if(! in_array($_GET["idEtab"], $idsEtablissement) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * enregistrer les informations de la prestation
	 */
	public function enregistrer() {

		$idEtablissement = $_GET["idEtab"];
        $c = new Criteria ();
        $c->setLimit (1);
        $criteria = new Atexo_TypePrestation_CriteriaVo();
        $criteria->setIdEtablissement($idEtablissement);
        $criteria->setFindOne(true);

		foreach ($this->listeRefTypePrestation->Items as $itemRefTypePresta) {

            $idRefTypePresta = $itemRefTypePresta->idRefTypePresta->getValue();
            $criteria->setIdRefTypePrestation($idRefTypePresta);
			$tTypePrestation = null;

			foreach ($itemRefTypePresta->listeParametragePrestation->Items as $itemParametragePresta) {
				$idRefPresta = $itemParametragePresta->idRefPresta->getValue();
				$idParametragePresta = $itemParametragePresta->idParametragePresta->getValue();
                $tParametragePrestation = TParametragePrestationQuery::create()->getParametragePrestationById($idParametragePresta);

				$tPrestationQuery = new TPrestationQuery();
				$tPrestation = $tPrestationQuery->getPrestationByCriteres($idRefTypePresta, $idRefPresta, $idEtablissement);
                $tPrestation = $tPrestation[0];
				if($itemParametragePresta->checkRefPresta->Checked) {
					$checked=true;
					if ( ! $tPrestation instanceof TPrestation ) {
						$tPrestation = new TPrestation();

						if(!$tTypePrestation) {
							$tTypePrestation = TTypePrestationQuery::create()->getTypePrestationByCriteres($criteria);

							if( ! $tTypePrestation instanceof TTypePrestation) {
								$tTypePrestation = new TTypePrestation ();
								$tTypePrestation->setIdEtablissement ( $idEtablissement );
								$tTypePrestation->setIdRefTypePrestation ( $idRefTypePresta );
							}
							$tTypePrestation->setVisibleCitoyen((int)$itemRefTypePresta->visibleCitoyen->Checked);
							$tTypePrestation->save();
						}
                        $tPrestation->setTTypePrestation ( $tTypePrestation );
                        $tPrestation->setIdRefPrestation($idRefPresta);
                        $tParametragePrestation->populateTPrestation($tPrestation);
                        $tPrestation->save();
					}
                    $tPrestation->setVisioconference((int)$itemParametragePresta->checkVisio->Checked);
					$idsChampsSupp = $itemParametragePresta->idsChampsSupp->SelectedValues;
					if($idsChampsSupp[0]>0) {
						$tPrestation->setIdChampsSupp1($idsChampsSupp[0]);
					}
					else {
						$tPrestation->setIdChampsSupp1(null);
					}
					if($idsChampsSupp[1]>0) {
						$tPrestation->setIdChampsSupp2($idsChampsSupp[1]);
					}
					else {
						$tPrestation->setIdChampsSupp2(null);
					}
					if($idsChampsSupp[2]>0) {
						$tPrestation->setIdChampsSupp3($idsChampsSupp[2]);
					}
					else {
						$tPrestation->setIdChampsSupp3(null);
					}
					$tPrestation->save();
				} else {
					if($tPrestation instanceof TPrestation) {
                        // suppression des prestations n'ayant pas un agenda
                        if(! count($tPrestation->getTAgendas($c)) && ! count($tPrestation->getTRendezVouss($c)) && ! count($tPrestation->getTDelaiObtentions($c)) ) {
                            $tPrestation->delete ();
                        }
					}
				}
			}
			if($checked) {
				$checked=false;
				if (!$tTypePrestation) {
					$tTypePrestation = TTypePrestationQuery::create()->getTypePrestationByCriteres($criteria);
				}
				if($tTypePrestation instanceof TTypePrestation) {
					$tTypePrestation->setVisibleCitoyen((int)$itemRefTypePresta->visibleCitoyen->Checked);
					$tTypePrestation->save();
				}
			}
		}
		$this->response->redirect("index.php?page=administration.GestionPrestationsModeRef&search");
	}

	private function _getDataSource($data) {
        $idsParametragePrestation = array();
        $idsRefTypePrestaVisibleCitoyen = array();
		$idsChampsSupp = array();
        if(isset($_GET["idEtab"])) {
            $idEtablissement = $_GET["idEtab"];
            $result = TPrestationPeer::getIdsParametragePrestationByEtablissement($idEtablissement);
            $idsParametragePrestation = $result['idsParametragePrestation'];
            $idsRefTypePrestaVisibleCitoyen = $result['idsRefTypePrestaVisibleCitoyen'];
			$idsChampsSupp = $result['idsChampsSuppPrestation'];
        }
		$dataSource = array();
		$refTypePrestationPeer = new TRefTypePrestationPeer();

		$criteriaVo = new Atexo_RefPrestation_CriteriaVo();
		$criteriaVo->setIdOrganisation($this->_idOrganisation);
		$criteriaVo->setLang($this->_lang);

		$listeRefTypePrestation = $refTypePrestationPeer->getRefTypePrestationByCriteres ( $criteriaVo );
		// initialisation des ref type prestation
		foreach ($listeRefTypePrestation as $refTypePrestation) {
			$dataSource [$refTypePrestation['ID_REF_TYPE_PRESTATION']] = array('ID_REF_TYPE_PRESTATION'=>$refTypePrestation['ID_REF_TYPE_PRESTATION'], 'LIBELLE_REFERENTIEL_TYPE_PRESTATION' => $refTypePrestation['LIBELLE_REFERENTIEL_TYPE_PRESTATION']);
			$dataSource [$refTypePrestation['ID_REF_TYPE_PRESTATION']]['refPrestations'] = array();
		}

		foreach ($data as $element) {
            $element['checked'] = isset($idsParametragePrestation[$element['ID_PARAMETRAGE_PRESTATION']]);
			$element['IDS_CHAMPS_SUPP'] = $idsChampsSupp[$element['ID_PARAMETRAGE_PRESTATION']];
            $dataSource [$element['ID_REF_TYPE_PRESTATION']]['visibleCitoyen'] = $idsRefTypePrestaVisibleCitoyen[$element['ID_REF_TYPE_PRESTATION']];
			$dataSource [$element['ID_REF_TYPE_PRESTATION']]['refPrestations'][$element['ID_REF_PRESTATION']] = $element;

			$tPrestationQuery = new TPrestationQuery();
            $tPrestation = $tPrestationQuery->getPrestationByCriteres($element['ID_REF_TYPE_PRESTATION'], $element['ID_REF_PRESTATION'], $idEtablissement);
            if($tPrestation[0] != null)
                $dataSource [$element['ID_REF_TYPE_PRESTATION']]['refPrestations'][$element['ID_REF_PRESTATION']]['VISIOCONFERENCE'] = $tPrestation[0]->getVisioconference();
		    else
                $dataSource [$element['ID_REF_TYPE_PRESTATION']]['refPrestations'][$element['ID_REF_PRESTATION']]['VISIOCONFERENCE'] = 0;
		}
		return $dataSource;
	}
}
