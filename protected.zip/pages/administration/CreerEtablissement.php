<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

/**
 * @author user
 *
 */
class CreerEtablissement extends AtexoPage {

	private $_dataDenomination = null;
	private $_dataDescription = null;
	private $_dataAdresse = null;
    public $isActiveModuleTypeEtab = 0;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
        try {
            $this->isActiveModuleTypeEtab = Atexo_Config::getParameter('MODULE_TYPE_ETAB_' . $this->User->getCurrentOrganism());
        } catch (Exception $e) {
        }

		$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();

		if(!Atexo_User_CurrentUser::hasHabilitation('GestionEtablissement') || $adminEtab) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {

			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();

			$this->loadOrganisation();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
				$this->listeOrganisationDup->SelectedValue=$idOrganisation;
				$this->listeOrganisationDup->Enabled=false;
				$this->loadEtablissement();
				if($this->isActiveModuleTypeEtab){
                    $this->loadListTypeEtab();
                }
			}

			if($adminEtab) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}
			$lang = Atexo_User_CurrentUser::readFromSession("lang");
			$entiteGestion = new Atexo_Entite_Gestion();
			$this->entite1->DataSource = $entiteGestion->getAllEntite(1,$lang,null,Prado::localize('SELECTIONNEZ'));
			$this->entite1->DataBind();

			if(isset($_GET["idEtablissement"])) {
				$this->remplir($_GET["idEtablissement"]);
			}

			self::getListeChampsParLangues($this->_dataDenomination, $this->_dataDescription, $this->_dataAdresse);
		}
	}

	/**
	 * Remplir la liste des provinces
	 */
	public function loadEntite() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite2->DataSource = $entiteGestion->getAllEntite(2,$lang,$this->entite1->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->entite2->DataBind();

        $this->entite3->DataSource = [0 => Prado::localize('SELECTIONNEZ')];
        $this->entite3->DataBind();
	}

	/**
	 * Remplir la liste des communes
	 */
	public function loadEntite3() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite3->DataSource = $entiteGestion->getAllEntite(3,$lang,$this->entite2->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->entite3->DataBind();
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$data = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataSource = $data;
		$this->listeOrganisation->DataBind();

		$this->listeOrganisationDup->DataSource = $data;
		$this->listeOrganisationDup->DataBind();
	}

	/**
	 * Remplir la liste des etablissements
	 */
	public function loadEtablissement() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$etablissementGestion = new Atexo_Etablissement_Gestion();
		$this->listeEtablissementDup->DataSource = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,$this->listeOrganisationDup->SelectedValue,null,Prado::localize('SELECTIONNEZ'),(Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab()));
		$this->listeEtablissementDup->DataBind();
	}

	public function getListeChampsParLangues($dataDenomination, $dataDescription, $dataAdresse) {
		self::getListeDenominationParLangues($dataDenomination);
		self::getListeDescriptionParLangues($dataDescription);
		self::getListeAdresseParLangues($dataAdresse);
	}

	/**
	 * Récupérer le nom d'établissement par langue
	 */
	public function getListeDenominationParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeDenominationParLangues($data);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['denominationLibelleLang'] = Prado::localize('DENOMINATION_ETABLISSEMENT');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['denomination'] = '';
				$data[$index]['langDenomination'] = $lan;
				$index++;
			}
			$this->setListeDenominationParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater nom d'établissement
	 */
	public function setListeDenominationParLangues($data) {
		$this->listeDenominationLangues->dataSource = $data;
		$this->listeDenominationLangues->dataBind();
		$index = 0;
		foreach ($this->listeDenominationLangues->getItems() as $item) {
			$item->denominationLibelleLang->Text = $data[$index]['denominationLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->denomination->Text = $data[$index]['denomination'];
			$item->langDenomination->Value = $data[$index]['langDenomination'];
			$index++;
		}
	}

	/**
	 * Récupérer la description d'établissement par langue
	 */
	public function getListeDescriptionParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeDescriptionParLangues($data);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['descriptionLibelleLang'] = Prado::localize('DESCRIPTION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['description'] = '';
				$data[$index]['langDescription'] = $lan;
				$index++;
			}
			$this->setListeDescriptionParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater description d'établissement
	 */
	public function setListeDescriptionParLangues($data) {
		$this->listeDescriptionLangues->dataSource = $data;
		$this->listeDescriptionLangues->dataBind();
		$index = 0;
		foreach ($this->listeDescriptionLangues->getItems() as $item) {
			$item->descriptionLibelleLang->Text = $data[$index]['descriptionLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->description->Text = $data[$index]['description'];
			$item->langDescription->Value = $data[$index]['langDescription'];
			$index++;
		}
	}

	/**
	 * Récupérer l'adresse d'établissement par langue
	 */
	public function getListeAdresseParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeAdresseParLangues($data);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['adresseLibelleLang'] = Prado::localize('ADRESSE');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['adresse'] = '';
				$data[$index]['langAdresse'] = $lan;
				$index++;
			}
			$this->setListeAdresseParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater adresse d'établissement
	 */
	public function setListeAdresseParLangues($data) {
		$this->listeAdresseLangues->dataSource = $data;
		$this->listeAdresseLangues->dataBind();
		$index = 0;
		foreach ($this->listeAdresseLangues->getItems() as $item) {
			$item->adresseLibelleLang->Text = $data[$index]['adresseLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->adresse->Text = $data[$index]['adresse'];
			$item->langAdresse->Value = $data[$index]['langAdresse'];
			$index++;
		}
	}


	/**
	 * dupliquer l'établissement
	 */
	public function duplicateEtab() {
		$idEtablissement = $this->listeEtablissementDup->SelectedValue;
		$tEtablissementQuery = new TEtablissementQuery();
		$tEtablissement = $tEtablissementQuery->getEtablissementById($idEtablissement);

		if ($tEtablissement instanceof TEtablissement){

			$newTEtab = $tEtablissement->getCopie($this->duplicationTypePrestation->Checked,
													$this->duplicationPrestation->Checked,
													$this->duplicationRessource->Checked);
			$newTEtab->save();

			$url = "index.php?page=administration.CreerEtablissement&idEtablissement=".$newTEtab->getIdEtablissement();
			$this->response->redirect($url);
		}
	}

	/**
	 * @param $idEtablissement
	 * récuperer les informations d'établissement
	 */
	public function remplir($idEtablissement) {

		$tEtablissementQuery = new TEtablissementQuery();
		$tEtablissement = $tEtablissementQuery->getEtablissementById($idEtablissement);

		if ($tEtablissement instanceof TEtablissement){

			$tel = explode(" , ",$tEtablissement->getTelephoneEtablissement());
			$this->inputTelephone->setText($tel[0]);
			$this->inputTelephone1->setText($tel[1]);
			$this->inputTelephone2->setText($tel[2]);
			$this->inputEmail->setText($tEtablissement->getMailEtablissement());
			$this->inputCP->setText($tEtablissement->getCodePostal());
			$this->listeOrganisation->SelectedValue = $tEtablissement->getIdOrganisation();

			$this->visibleOui->checked = ($tEtablissement->getActive()=="1");
			$this->visibleNon->checked = ($tEtablissement->getActive()=="0");

            $niveauTypeEtab = null;
            $idTypeEtab = $tEtablissement->getIdTypeEtab();
			if($this->isActiveModuleTypeEtab){
                if($idTypeEtab){
                    $lang = Atexo_User_CurrentUser::readFromSession("lang");
                    $idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
                    $tTypeEtabPeer = new TTypeEtabPeer();
                    $typeEtab = $tTypeEtabPeer->getTypeEtab($lang, $idOrg, $idTypeEtab);
                    $niveauTypeEtab = $typeEtab['NIVEAU'];
                    $this->niveatTypeEtab->value = $typeEtab['NIVEAU'];
                    $this->typeEtablissement->SelectedValue = $idTypeEtab;
                }
                if($niveauTypeEtab == 1){
                    $this->visibleEntite1->style = "display:block";
                    $this->entite1->SelectedValue = $tEtablissement->getIdEntite();
                    $this->loadEntite();
                }
                if($niveauTypeEtab == 2 && $tEtablissement->getIdEntite()>0){
                    $tEntiteQuery = new TEntiteQuery();
                    $tEntite = $tEntiteQuery->getEntiteById($tEtablissement->getIdEntite());
                    $this->visibleEntite1->style = "display:block";
                    $this->entite1->SelectedValue = $tEntite->getIdEntiteParent();
                    $this->loadEntite();
                    $this->visibleEntite2->style = "display:block";
                    $this->entite2->SelectedValue = $tEtablissement->getIdEntite();
                    $this->loadEntite3();
                }
            }
            if(($niveauTypeEtab == 3 || $idTypeEtab == null) && $tEtablissement->getIdEntite()>0){
                $tEntiteQuery = new TEntiteQuery();
                $tEntite = $tEntiteQuery->getEntiteById($tEtablissement->getIdEntite());
                $tEntiteQuery = new TEntiteQuery();
                $tEntiteParent = $tEntiteQuery->getEntiteById($tEntite->getIdEntiteParent());
                $this->visibleEntite1->style = "display:block";
                $this->entite1->SelectedValue = $tEntiteParent->getIdEntiteParent();
                $this->loadEntite();
                $this->visibleEntite2->style = "display:block";
                $this->entite2->SelectedValue = $tEntite->getIdEntiteParent();
                $this->loadEntite3();
                $this->visibleEntite3->style = "display:block";
                $this->entite3->SelectedValue = $tEtablissement->getIdEntite();
            }

			$this->lblLat->setValue($tEtablissement->getLatitudeEtablissement());
			$this->lblLong->setValue($tEtablissement->getLongitudeEtablissement());

			//Récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataDenomination[$index]['denominationLibelleLang'] = Prado::localize('DENOMINATION_ETABLISSEMENT');
				$this->_dataDenomination[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataDenomination[$index]['denomination'] = $tEtablissement->getDenominationEtablissementTraduit($lan);
				$this->_dataDenomination[$index]['langDenomination'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataDescription[$index]['descriptionLibelleLang'] = Prado::localize('DESCRIPTION');
				$this->_dataDescription[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataDescription[$index]['description'] = $tEtablissement->getDescriptionEtablissementTraduit($lan);
				$this->_dataDescription[$index]['langDescription'] = $lan;
				$index++;
			}

			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataAdresse[$index]['adresseLibelleLang'] = Prado::localize('ADRESSE');
				$this->_dataAdresse[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataAdresse[$index]['adresse'] = $tEtablissement->getAdresseEtablissementTraduit($lan);
				$this->_dataAdresse[$index]['langAdresse'] = $lan;
				$index++;
			}

			if($tEtablissement->getIdBlobPlan()>0) {
				$this->downloadPlan->Visible=true;
				$this->modifPlan->Visible=true;
				$this->planAcces->Style="display:none";
				$this->downloadPlan->Text = $tEtablissement->getTBlob()->getNomBlob();
				$this->downloadPlan->CommandParameter = $tEtablissement->getIdBlobPlan();
			}
		}
	}

	/**
	 * modifier le plan d'accès
	 */
	public function modifPlanAcces($sender, $param) {
		$this->downloadPlan->Visible=false;
		$this->modifPlan->Visible=false;
		$this->planAcces->Style="display:";

		$this->panelPlanAcces->render($param->getNewWriter());
	}

	/**
	 * enregistrer les informations d'établissement
	 */
	public function enregistrer() {

		if(isset($_GET["idEtablissement"])) {
			$tEtablissementQuery = new TEtablissementQuery();
			$tEtablissement = $tEtablissementQuery->getEtablissementById($_GET["idEtablissement"]);

			$tTraductionDenomination = $tEtablissement->getTTraductionRelatedByCodeDenominationEtablissement();
			$tTraductionDescription = $tEtablissement->getTTraductionRelatedByCodeDescriptionEtablissement();
			$tTraductionAdresse = $tEtablissement->getTTraductionRelatedByCodeAdresseEtablissement();
		}

		if(!($tEtablissement instanceof TEtablissement)) {
			$tEtablissement = new TEtablissement();
			$tTraductionDenomination = new TTraduction();
			$tTraductionDescription = new TTraduction();
			$tTraductionAdresse = new TTraduction();
		}

		//boucle
		foreach($this->listeDenominationLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionDenomination->getTTraductionLibelle($item->langDenomination->Value);
			$tTraductionLibelle->setLang($item->langDenomination->Value);
			$tTraductionLibelle->setLibelle($item->denomination->Text);
			$tTraductionDenomination->addTTraductionLibelle($tTraductionLibelle);
		}
		foreach($this->listeDescriptionLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionDescription->getTTraductionLibelle($item->langDescription->Value);
			$tTraductionLibelle->setLang($item->langDescription->Value);
			$tTraductionLibelle->setLibelle($item->description->Text);
			$tTraductionDescription->addTTraductionLibelle($tTraductionLibelle);
		}
		foreach($this->listeAdresseLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionAdresse->getTTraductionLibelle($item->langAdresse->Value);
			$tTraductionLibelle->setLang($item->langAdresse->Value);
			$tTraductionLibelle->setLibelle($item->adresse->Text);
			$tTraductionAdresse->addTTraductionLibelle($tTraductionLibelle);
		}
		//fin
		$tEtablissement->setTTraductionRelatedByCodeDenominationEtablissement($tTraductionDenomination);
		$tEtablissement->setTTraductionRelatedByCodeDescriptionEtablissement($tTraductionDescription);
		$tEtablissement->setTTraductionRelatedByCodeAdresseEtablissement($tTraductionAdresse);

		$tEtablissement->setIdOrganisation($this->listeOrganisation->getSelectedValue());

		if($this->inputTelephone1->SafeText != null) {
			if($this->inputTelephone2->SafeText != null) {
				$tEtablissement->setTelephoneEtablissement($this->inputTelephone->SafeText." , ".$this->inputTelephone1->SafeText." , ".$this->inputTelephone2->SafeText);
			}
			else {
				$tEtablissement->setTelephoneEtablissement($this->inputTelephone->SafeText." , ".$this->inputTelephone1->SafeText);
			}
		}
		else {
			$tEtablissement->setTelephoneEtablissement($this->inputTelephone->SafeText);

		}

		$tEtablissement->setMailEtablissement($this->inputEmail->SafeText);
		$tEtablissement->setCodePostal($this->inputCP->SafeText);

        if($this->isActiveModuleTypeEtab) {
            $idEntite = null;
            $idTypeEtab = $this->typeEtablissement->SelectedValue;
            if ($idTypeEtab > 0) {
                $lang = Atexo_User_CurrentUser::readFromSession("lang");
                $idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
                $tTypeEtabPeer = new TTypeEtabPeer();
                $typeEtab = $tTypeEtabPeer->getTypeEtab($lang, $idOrg, $idTypeEtab);
                if (($typeEtab['NIVEAU'] == 1)) {
                    $idEntite = $this->entite1->getSelectedValue();
                }
                if (($typeEtab['NIVEAU'] == 2)) {
                    $idEntite = $this->entite2->getSelectedValue();
                }
                if (($typeEtab['NIVEAU'] == 3)) {
                    $idEntite = $this->entite3->getSelectedValue();
                }
            }
            $tEtablissement->setIdEntite($idEntite);
            $tEtablissement->setIdTypeEtab($idTypeEtab);
        }else{
            $tEtablissement->setIdEntite($this->entite3->getSelectedValue());
        }

		$tEtablissement->setLatitudeEtablissement($this->lblLat->getValue());
		$tEtablissement->setLongitudeEtablissement($this->lblLong->getValue());

		$tEtablissement->setActive((int)$this->visibleOui->checked);

		if($this->planAcces->HasFile) {
			$tBlob = $tEtablissement->getTBlob();

			if($tBlob==null) {
				$tBlob = new TBlob();
				$tBlob->setNomBlob($this->planAcces->FileName);
				$tEtablissement->setTBlob($tBlob);
			}
		}

		$tEtablissement->save();

		if($this->planAcces->HasFile) {
			Atexo_Utils_Util::mvFile($this->planAcces->LocalName, Atexo_Config::getParameter("PATH_FILE"), $tEtablissement->getIdBlobPlan());
		}

		$url = "index.php?page=administration.GestionEtablissements&search";
		$this->response->redirect($url);
	}

	/**
	 * afficher panel duplication d'établissement
	 */
	public function affiche() {
		$this->panel_infosDuplication->style="display:block";
	}

	/**
	 * télécharger le plan d'accès
	 */
	public function downloadPlanAcces($sender) {
		$idFichier = $sender->CommandParameter;
		Atexo_DownloadFile::downloadFiles($idFichier);
	}

    public function loadListTypeEtab(){
        $lang = Atexo_User_CurrentUser::readFromSession("lang");
        $idOrg = Atexo_User_CurrentUser::getIdOrganisationGere ();
        $tTypeEtabPeer = new TTypeEtabPeer();
        $listTypeEtab = $tTypeEtabPeer->getTypeEtab($lang, $idOrg);
        $dataSource['0'] = Prado::localize('SELECTIONNEZ');
        foreach ($listTypeEtab as $item){
            $dataSource[$item['ID_TYPE_ETAB']] = $item['CODE_LIBELLE'];
        }
        $this->typeEtablissement->dataSource = $dataSource;
        $this->typeEtablissement->dataBind();
    }

    public function checkNiveauDecoupage($sender = null){
        if($this->isActiveModuleTypeEtab) {
            $idTypeEtab = $this->typeEtablissement->SelectedValue;
            $this->visibleEntite1->style="display:none";
            $this->visibleEntite2->style="display:none";
            $this->visibleEntite3->style="display:none";

            if ($idTypeEtab > 0) {
                $lang = Atexo_User_CurrentUser::readFromSession("lang");
                $idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
                $tTypeEtabPeer = new TTypeEtabPeer();
                $typeEtab = $tTypeEtabPeer->getTypeEtab($lang, $idOrg, $idTypeEtab);
                $this->initSelectedEntite($typeEtab['NIVEAU']);
                $this->niveatTypeEtab->value = $typeEtab['NIVEAU'];
                if (($typeEtab['NIVEAU'] == 1)) {
                    $this->visibleEntite1->style = "display:block";
                }
                if (($typeEtab['NIVEAU'] == 2)) {
                    $this->visibleEntite1->style = "display:block";
                    $this->visibleEntite2->style = "display:block";
                }
                if (($typeEtab['NIVEAU'] == 3)) {
                    $this->visibleEntite1->style = "display:block";
                    $this->visibleEntite2->style = "display:block";
                    $this->visibleEntite3->style = "display:block";
                }
            }else{
                $this->initSelectedEntite();
            }
        }
    }

    public function initSelectedEntite($currentNiveauType=null){
        $oldNiveatTypeEtab = $this->niveatTypeEtab->value;
        if($oldNiveatTypeEtab > $currentNiveauType){
            if (($currentNiveauType == 0)) {
                $this->entite1->SelectedValue = 0;
                $this->entite2->SelectedValue = 0;
                $this->entite3->SelectedValue = 0;
            }
            if (($currentNiveauType == 1)) {
                $this->entite2->SelectedValue = 0;
                $this->entite3->SelectedValue = 0;
            }
            if (($currentNiveauType == 2)) {
                $this->entite3->SelectedValue = 0;
            }
        }
    }
}