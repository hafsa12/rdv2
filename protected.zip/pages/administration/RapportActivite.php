<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class RapportActivite extends AtexoPage {

	public $prestation;
	public $nbRessource;
	public $capacite;
	public $moyenne;
	private $_lang;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");

		if(!Atexo_User_CurrentUser::hasHabilitation('RapportActivite')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}

		if(!$this->isPostBack) {
			$this->loadEntite();
			$this->loadEntite2();
			$this->loadEntite3();
			$this->loadTypeEtablissement();
			$this->loadEtablissement();
			$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
			if($adminEtab) {
				$idEtablissement = Atexo_User_CurrentUser::getIdEtablissementGere();
				$this->listeEtablissement->setSelectedValue($idEtablissement);
				$this->loadTypePrestation();
			}

			if($_GET["filtre"]!="") {
				$dates = explode("#",base64_decode($_GET["filtre"]));
				$this->datedebut->Text = $dates[0];
				$this->datefin->Text = $dates[1];
			}
			else {
				$util = new Atexo_Utils_Util();
				$this->datedebut->Text = $util->iso2frnDate($util->addMois(date("Y-m-d"), -1));
				$this->datefin->Text = date("d/m/Y");
			}
			$this->suggestNames();
		}
	}

	public function loadEntite() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite1->DataSource = $entiteGestion->getAllEntite(1,$lang,null,Prado::localize('ENTITE_1'));
		$this->entite1->DataBind();
	}

	public function loadEntite2($sender = null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
		$this->entite2->DataBind();
		if($sender) {
			$this->loadEntite3();
			$this->loadEtablissement($this->entite1->getSelectedValue());
		}
	}

	public function loadEntite3($sender = null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$idEntite = null;

		if($this->entite2->SelectedValue) {
			$idEntite = $this->entite2->SelectedValue;
		}elseif($this->entite1->SelectedValue){
			$idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
		}

		$this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
		$this->entite3->DataBind();
		if($sender) {
			$this->loadEtablissement(null, $this->entite2->getSelectedValue());
		}
	}

	public function loadEtablissementByEntite() {
		$this->loadEtablissement();
	}

	public function loadEtablissement($idEntite1 = null, $idsEntite2 = null) {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		if($idEntite1) {
			$entiteGestion = new Atexo_Entite_Gestion();
			$idsCommune = $entiteGestion->getAllIdChildEntite ($idEntite1);
		}
		if($idsEntite2) {
			$entiteGestion = new Atexo_Entite_Gestion();
			$idsCommune = $entiteGestion->getAllIdChildEntite ($idsEntite2);
		}
		if($this->entite3->getSelectedValue ()) {
			$idsCommune = array($this->entite3->getSelectedValue ());
		}
		$etablissementGestion = new Atexo_Etablissement_Gestion();
        if(Atexo_Config::getParameter('MODULE_TYPE_ETAB_' . $this->User->getCurrentOrganism()) == 1 && $this->listeTypeEtablissement->selectedValue > 0){
            $listEtab = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang, Atexo_User_CurrentUser::getIdOrganisationGere(),
                null, Prado::localize('ETABLISSEMENT'), true, false, $idsCommune, $this->listeTypeEtablissement->selectedValue);
        }else {
            $listEtab = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang, Atexo_User_CurrentUser::getIdOrganisationGere(),
                null, Prado::localize('ETABLISSEMENT'), true, false, $idsCommune);
        }
        $this->listeEtablissement->DataSource = $listEtab;
        $this->listeEtablissement->DataBind();
		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$this->loadRefPrestation();
		}
	}

	public function loadTypePrestation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");

		$idEtablissement = $this->listeEtablissement->getSelectedValue();

		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$refTypePrestationGestion = new Atexo_RefTypePrestation_Gestion();
			$this->listeTypePrestation->DataSource = $refTypePrestationGestion->getRefTypePrestationByIdOrg($lang,Atexo_User_CurrentUser::getIdOrganisationGere(),Prado::localize('NIVEAU1'),$idEtablissement);
			$this->listeTypePrestation->DataBind();
			$this->loadRefPrestation();
		} else {
			$typePrestationGestion = new Atexo_TypePrestation_Gestion();
			$this->listeTypePrestation->DataSource = $typePrestationGestion->getTypePrestationByIdEtab($lang,$idEtablissement,Prado::localize('NIVEAU1'));
			$this->listeTypePrestation->DataBind();

			$this->listePrestation->DataSource = array();
			$this->listePrestation->DataBind();
		}
	}
	
	public function loadRefPrestation() {
		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$idEtablissement = $this->listeEtablissement->getSelectedValue();
			$lang = Atexo_User_CurrentUser::readFromSession("lang");
			$refPrestationGestion = new Atexo_RefPrestation_Gestion();
			$this->listeRefPrestation->DataSource = $refPrestationGestion->getAllRefPrestation($lang,$this->listeTypePrestation->SelectedValue,Prado::localize('NIVEAU2'),$idEtablissement);
			$this->listeRefPrestation->DataBind();
			$this->listeRefPrestation->Visible = true;
		}
	}
	/**
	 * @param $criteriaVo
	 * Remplir repeater des rendez-vous selon les critères de recherche
	 */
	public function fillRepeaterWithDataForSearchResult($criteriaVo) {

		$nombreElement = TPrestationPeer::getPrestationByCriteres($criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->panelBottom->setVisible(true);
			$this->panelTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);

			$this->nombrePageTop->Text=ceil($nombreElement/$this->listePrestation->PageSize);
			$this->nombrePageBottom->Text=ceil($nombreElement/$this->listePrestation->PageSize);
			$this->listePrestation->setVirtualItemCount($nombreElement);
			$this->listePrestation->setCurrentPageIndex(0);
			$this->Page->setViewState("CriteriaVo",$criteriaVo);

			$this->populateData($criteriaVo);
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
			$this->panelTop->setVisible(false);
			$this->panelBottom->setVisible(false);
			$this->listePrestation->DataSource=array();
			$this->listePrestation->DataBind();
			$this->nombreElement->Text="0";
			$this->setViewState("nombreElement",$nombreElement);
		}
	}

	public function populateData(Atexo_Prestation_CriteriaVo $criteriaVo)
	{
		$util = new Atexo_Utils_Util();
		/*$nombreElement = $this->getViewState("nombreElement");
		$offset = $this->listePrestation->CurrentPageIndex * $this->listePrestation->PageSize;
		$limit = $this->listePrestation->PageSize;
		if ($offset + $limit > $nombreElement) {
			$limit = $nombreElement - $offset;
		}
		$criteriaVo->setOffset($offset);
		$criteriaVo->setLimit($limit);*/

		$dataPrestation = TPrestationPeer::getPrestationByCriteres($criteriaVo);

		$dateDebut=$this->datedebut->SafeText;
		$dateFin=$this->datefin->SafeText;
		$nbPr = count($dataPrestation);
		$dataEtab = array();
		for($i=0; $i<$nbPr; $i++) {
			$tPeriodeQuery = new TPeriodeQuery();
			$capacite = $tPeriodeQuery->getCapacite($dataPrestation[$i]["ID_PRESTATION"],$dateDebut,$dateFin);
			$dataPrestation[$i]["CAPACITE"] = $capacite;
			$dataPrestation[$i]["MOYENNE"] = ($dataPrestation[$i]["NB_RESSOURCE"]==0)?0:
			$util->getMontantArrondit($capacite/$dataPrestation[$i]["NB_RESSOURCE"]);

			if($this->listeEtablissement->getSelectedValue()>0) {
				$this->prestation .= '"'.$dataPrestation[$i]["LIBELLE_ETP"].' ('.$dataPrestation[$i]["NB_RESSOURCE"].' '.Prado::localize("RESSOURCES").')",';
				$this->nbRessource .= $dataPrestation[$i]["NB_RESSOURCE"].',';
				$this->capacite .= $dataPrestation[$i]["CAPACITE"].',';
				$this->moyenne .= str_replace(",",".",$dataPrestation[$i]["MOYENNE"]).',';
			}
			else {
				$idEtab = $dataPrestation[$i]["ID_ETABLISSEMENT"];
				$dataEtab[$idEtab]["LIBELLE_ETP"]=$dataPrestation[$i]["LIBELLE_ETAB"]." - ".$dataPrestation[$i]["LIBELLE_ENTITE"];
				$dataEtab[$idEtab]["NB_RESSOURCE"]+=$dataPrestation[$i]["NB_RESSOURCE"];
				$dataEtab[$idEtab]["CAPACITE"]+=$dataPrestation[$i]["CAPACITE"];
				$dataEtab[$idEtab]["MOYENNE"]+=$dataPrestation[$i]["MOYENNE"];
			}
			
		}
		if($this->listeEtablissement->getSelectedValue()==0) {
			foreach ($dataEtab as $etab) {
				$this->prestation .= '"'.$etab["LIBELLE_ETP"].' ('.$etab["NB_RESSOURCE"].' '.Prado::localize("RESSOURCES").')",';
				$this->nbRessource .= $etab["NB_RESSOURCE"].',';
				$this->capacite .= $etab["CAPACITE"].',';
				$moyenne = ($etab["NB_RESSOURCE"]==0)?0:$util->getMontantArrondit($etab["CAPACITE"]/$etab["NB_RESSOURCE"]);
				$this->moyenne .= str_replace(",",".",$moyenne).',';
			}
		}
		$this->listePrestation->DataSource=$dataPrestation;
		$this->listePrestation->DataBind();
	}

	protected function suggestNames() {

		$criteriaVo = new Atexo_Prestation_CriteriaVo();
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$criteriaVo->setLang($lang);
		$criteriaVo->setPrestationReferentiel($_SESSION["typePrestation"]);

		if($this->entite3->getSelectedValue()>0) {
			$criteriaVo->setIdEntite($this->entite3->getSelectedValue());
		}
		elseif($this->entite2->getSelectedValue()>0) {
			$criteriaVo->setIdEntite($this->entite2->getSelectedValue());
		}
		elseif($this->entite1->getSelectedValue()>0) {
			$criteriaVo->setIdEntite($this->entite1->getSelectedValue());
		}
		if($this->listeTypePrestation->getSelectedValue()>0) {
			if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
				$criteriaVo->setIdRefTypePrestation($this->listeTypePrestation->getSelectedValue());
			}
			else {
				$criteriaVo->setIdTypePrestation($this->listeTypePrestation->getSelectedValue());
			}
		}

		if($this->listeEtablissement->getSelectedValue()>0) {
			$criteriaVo->setIdEtablissement($this->listeEtablissement->getSelectedValue());
		}
		else {
			$criteriaVo->setIdEtablissement(Atexo_User_CurrentUser::getIdEtablissementGere());
		}
		
		if($this->listeRefPrestation->getSelectedValue()>0) {
			$criteriaVo->setIdRefPrestation($this->listeRefPrestation->getSelectedValue());
		}
		$idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
		if($idOrg>0) {
			$criteriaVo->setIdOrganisation($idOrg);
		}
        if($this->listeTypeEtablissement->selectedValue > 0) {
            $criteriaVo->setIdTypeEtablissement($this->listeTypeEtablissement->selectedValue);
        }
		$this->Page->setViewState("CriteriaVo",$criteriaVo);
		$this->fillRepeaterWithDataForSearchResult($criteriaVo);
	}

	public function Trier($sender,$param)
	{
		$champsOrderBy = $sender->CommandParameter;
		$this->setViewState('sortByElement',$champsOrderBy);
		$criteriaVo=$this->Page->getViewState("CriteriaVo");
		$criteriaVo->setSortByElement($champsOrderBy);
		$arraySensTri=$this->Page->getViewState("sensTriArray",array());
		$arraySensTri[$champsOrderBy]=($criteriaVo->getSensOrderBy()=="ASC")? "DESC" : "ASC";
		$criteriaVo->setSensOrderBy($arraySensTri[$champsOrderBy]);
		$this->Page->setViewState("sensTriArray",$arraySensTri);
		$this->Page->setViewState("CriteriaVo",$criteriaVo);
		$this->listePrestation->setCurrentPageIndex(0);
		$this->populateData($criteriaVo);
		$this->RapportAct->render($param->getNewWriter());
	}

	public function pageChanged($sender,$param)
	{
		$this->listePrestation->CurrentPageIndex =$param->NewPageIndex;
		$this->numPageBottom->Text=$param->NewPageIndex+1;
		$this->numPageTop->Text=$param->NewPageIndex+1;
		$criteriaVo=$this->Page->getViewState("CriteriaVo");
		$this->populateData($criteriaVo);
	}

	public function goToPage($sender)
	{
		switch ($sender->ID) {
			case "DefaultButtonTop" :    $numPage=$this->numPageTop->Text;
			break;
			case "DefaultButtonBottom" : $numPage=$this->numPageBottom->Text;
			break;
		}
		if (Atexo_Utils_Util::isEntier($numPage)) {
			if ($numPage>=$this->nombrePageTop->Text) {
				$numPage=$this->nombrePageTop->Text;
			} else if ($numPage<=0) {
				$numPage=1;
			}
			$this->listePrestation->CurrentPageIndex =$numPage-1;
			$this->numPageBottom->Text=$numPage;
			$this->numPageTop->Text=$numPage;
			$criteriaVo=$this->Page->getViewState("CriteriaVo");
			$this->populateData($criteriaVo);
		} else {
			$this->numPageTop->Text=$this->listePrestation->CurrentPageIndex+1;
			$this->numPageBottom->Text=$this->listePrestation->CurrentPageIndex+1;
		}
	}

	public function changePagerLenght($sender)
	{
		switch ($sender->ID) {
			case "nombreResultatAfficherBottom" : $pageSize=$this->nombreResultatAfficherBottom->getSelectedValue();
			$this->nombreResultatAfficherTop->setSelectedValue($pageSize);
			break;
			case "nombreResultatAfficherTop" : $pageSize=$this->nombreResultatAfficherTop->getSelectedValue();
			$this->nombreResultatAfficherBottom->setSelectedValue($pageSize);
			break;
		}
			
		$this->listePrestation->PageSize=$pageSize;
		$nombreElement=$this->getViewState("nombreElement");
		$this->nombrePageTop->Text=ceil($nombreElement/$this->listePrestation->PageSize);
		$this->nombrePageBottom->Text=ceil($nombreElement/$this->listePrestation->PageSize);
		$criteriaVo=$this->Page->getViewState("CriteriaVo");
		$this->listePrestation->setCurrentPageIndex(0);
		$this->populateData($criteriaVo);
	}

	public function isTrierPar($champ) {
		$sortByElement = $this->getViewState('sortByElement');
		if($champ!=$sortByElement) {
			return "";
		}
		$arraySens = $this->getViewState("sensTriArray");
		if($arraySens[$sortByElement]=="ASC") {
			return "tri-on tri-asc";
		}
		return "tri-on tri-desc";
	}

    public function loadTypeEtablissement() {
        if(Atexo_Config::getParameter('MODULE_TYPE_ETAB_' . $this->User->getCurrentOrganism()) == 1){
            $lang = Atexo_User_CurrentUser::readFromSession("lang");
            $idOrg = Atexo_User_UserVo::getCurrentOrganism();
            $tTypeEtabPeer = new TTypeEtabPeer();
            $listTypeEtab = $tTypeEtabPeer->getTypeEtab($lang, $idOrg);
            $dataSource['0'] = Prado::localize('TYPE_ETABLISSEMENT');
            foreach ($listTypeEtab as $item){
                $dataSource[$item['ID_TYPE_ETAB']] = $item['CODE_LIBELLE'];
            }
            $this->listeTypeEtablissement->DataSource = $dataSource;
            $this->listeTypeEtablissement->DataBind();
        }
    }

    public function loadEtabByTypeEtab($sender, $param){
        $this->loadEtablissement();
    }
}
