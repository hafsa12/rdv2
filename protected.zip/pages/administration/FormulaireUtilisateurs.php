<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class FormulaireUtilisateurs extends AtexoPage
{
	private $calledPage = "";
	private $_dataNom = null;
	private $_dataPrenom = null;
	private $_lang = "";
	private $_idAgentToEdit;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function setCalledPage ($param)
	{
		$this->calledPage = $param;
	}

	public function getCalledPage ()
	{
		return $this->calledPage;
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionUtilisateurs') && $_GET["idAgent"]!=Atexo_User_CurrentUser::getIdAgentConnected()) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}

        if($_GET["idAgent"]==Atexo_User_CurrentUser::getIdAgentConnected()){
            $this->panelActif->visible = false;
            $this->panelProfil->visible = false;
        }

		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack)
		{
			$idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
			if($idOrg>0) {
				$tOrganisationQuery = new TOrganisationQuery();
				$tOrganisation = $tOrganisationQuery->getOrganisationById($idOrg);
				$typePrestation = $tOrganisation->getTypePrestation();
			}
			else {
				$typePrestation = Atexo_Config::getParameter('PRESTATION_SAISIE_LIBRE');
			}
			$this->setViewState("typePrestation", $typePrestation);
			//$this->loadOrganisationAttache();
			if(isset($_GET["idAgent"])) {
				$this->_idAgentToEdit = $_GET["idAgent"];
				$this->remplir($_GET["idAgent"]);
				$this->modifPasswordPanel->setVisible(true);
			}else {
				$this->modifPasswordPanel->setVisible(false);
			}
			self::getListeNomPrenomParLangues($this->_dataNom, $this->_dataPrenom);
			$this->remplirListeOrganisation();

			//remplir liste des profils utilisateur selon le profil de l'utilisateur connecté.
			$this->remplirListeProfilsUtilisateur();
		}
	}

	public function remplirListeProfilsUtilisateur() {
		$profilGestion = new Atexo_Profil_Gestion();
		$this->profilUtilisateur->DataSource = $profilGestion->getAllPossibleProfilByConnected($this->_lang, Prado::localize('SELECTIONNEZ'));
		$this->profilUtilisateur->DataBind();
	}

	public function loadOrganisationAttache() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisationAttache->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisationAttache->DataBind();
	}

	public function loadEtablissementAttache() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$etablissementGestion = new Atexo_Etablissement_Gestion();
		$this->listeEtablissementAttache->DataSource = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,
																	$this->listeOrganisationAttache->SelectedValue,null,
																	Prado::localize('SELECTIONNEZ'));
		$this->listeEtablissementAttache->DataBind();
	}

	public function remplirListeProfil($typeProfil) {
		$profilGestion = new Atexo_Profil_Gestion();
		$this->profilUtilisateur->DataSource = $profilGestion->getAllProfilByType($typeProfil, $this->_lang, Prado::localize('SELECTIONNEZ'));
		$this->profilUtilisateur->DataBind();
	}

	public function remplirListeOrganisation() {
		$organisations = new Atexo_Organisation_Gestion();
		$this->organisationUtilisateur->DataSource = $organisations->getAllOrganisation($this->_lang, Prado::localize('SELECTIONNEZ'),true);
		$this->organisationUtilisateur->DataBind();
	}

	public function remplirListeEtablissement($idOrganisation) {

		$etablissements = new Atexo_Etablissement_Gestion();
		$this->etablissementUtilisateur->DataSource = $etablissements->getEtablissementByIdProvinceIdOrganisation($this->_lang,
																			$idOrganisation, null, null, true);
		$this->etablissementUtilisateur->DataBind();
	}

	public function onTypeProfilChoix($sender,$param) {
		$idTypeProfil = $this->typeProfil->getSelectedValue();
		//Remplir liste des profils
		$this->remplirListeProfil($idTypeProfil);

		//Afficher les panels selon le type de profil
		if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_SYSTEM")) {
			$this->organisation->setStyle('display:none');
			$this->etablissement->setStyle('display:none');
			$this->listePrestationsPanel->setStyle('display:none');
			$this->validatorOrg->Enabled=false;
			$this->validatorEtab->Enabled=false;
		}
		if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION")) {
			$this->organisation->setStyle('display:block');
			$this->etablissement->setStyle('display:none');
			$this->listePrestationsPanel->setStyle('display:none');
			//Remplir liste Organisation
			$this->remplirListeOrganisation();
			$this->validatorOrg->Enabled=true;
			$this->validatorEtab->Enabled=false;
			$this->etablissementUtilisateur->DataSource = array();
			$this->etablissementUtilisateur->DataBind();
		}
		if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT")) {
			$this->organisation->setStyle('display:block');
			//Remplir liste Organisation
			$this->remplirListeOrganisation();
			$this->etablissement->setStyle('display:block');
			$this->etablissementUtilisateur->DataSource = array();
			$this->etablissementUtilisateur->DataBind();
			$this->listePrestationsPanel->setStyle('display:none');
			$this->validatorOrg->Enabled=true;
			$this->validatorEtab->Enabled=true;
			$this->script->Text = "<script>J('.chosen-select').chosen({placeholder_text_multiple:\"".Prado::localize('SELECTIONNEZ')."\"});J('.chosen-select').trigger('chosen:updated');</script>";
		}
		if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_AGENT_TO")) {
			$this->organisation->setStyle('display:block');
			//Remplir liste Organisation
			$this->remplirListeOrganisation();
			$this->etablissement->setStyle('display:block');
			$this->etablissementUtilisateur->DataSource = array();
			$this->etablissementUtilisateur->DataBind();
			$this->listePrestationsPanel->setStyle('display:none');
			$this->validatorOrg->Enabled=false;
			$this->validatorEtab->Enabled=false;
			$this->script->Text = "<script>J('.chosen-select').chosen({placeholder_text_multiple:\"".Prado::localize('SELECTIONNEZ')."\"});J('.chosen-select').trigger('chosen:updated');</script>";
		}
		$this->organisation->render($param->NewWriter);
		$this->etablissement->render($param->NewWriter);
	}

	public function onProfilChange($sender,$param) {
		$idProfil = $this->profilUtilisateur->getSelectedValue();
		$tProfilQuery = new TProfilQuery();
		$tProfil = $tProfilQuery->getProfilById($idProfil);
		//Afficher les panels selon le type de profil
		if($tProfil->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_ADMIN_SYSTEM")) {
			$this->organisation->setStyle('display:none');
			$this->etablissement->setStyle('display:none');
			$this->listePrestationsPanel->setStyle('display:none');
			$this->validatorOrg->Enabled=false;
			$this->validatorEtab->Enabled=false;
		}
		if($tProfil->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION")) {
			$this->organisation->setStyle('display:block');
			$this->etablissement->setStyle('display:block');
			$this->listePrestationsPanel->setStyle('display:none');
			//Remplir liste Organisation
			$this->remplirListeOrganisation();
			$this->validatorOrg->Enabled=true;
			$this->validatorEtab->Enabled=false;
			$this->etablissementUtilisateur->DataSource = array();
			$this->etablissementUtilisateur->DataBind();
			$this->script->Text = "<script>J('.chosen-select').chosen({placeholder_text_multiple:\"".Prado::localize('SELECTIONNEZ')."\"});J('.chosen-select').trigger('chosen:updated');</script>";
		}
		if($tProfil->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT")) {
			$this->organisation->setStyle('display:block');
			//Remplir liste Organisation
			$this->remplirListeOrganisation();
			$this->etablissement->setStyle('display:block');
			$this->etablissementUtilisateur->DataSource = array();
			$this->etablissementUtilisateur->DataBind();
			$this->listePrestationsPanel->setStyle('display:none');
			$this->validatorOrg->Enabled=true;
			$this->validatorEtab->Enabled=true;
			$this->script->Text = "<script>J('.chosen-select').chosen({placeholder_text_multiple:\"".Prado::localize('SELECTIONNEZ')."\"});J('.chosen-select').trigger('chosen:updated');</script>";
		}
		if($tProfil->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_AGENT_TO")) {
			$this->organisation->setStyle('display:block');
			//Remplir liste Organisation
			$this->remplirListeOrganisation();
			$this->etablissement->setStyle('display:block');
			$this->etablissementUtilisateur->DataSource = array();
			$this->etablissementUtilisateur->DataBind();
			$this->listePrestationsPanel->setStyle('display:none');
			$this->validatorOrg->Enabled=false;
			$this->validatorEtab->Enabled=false;
			$this->script->Text = "<script>J('.chosen-select').chosen({placeholder_text_multiple:\"".Prado::localize('SELECTIONNEZ')."\"});J('.chosen-select').trigger('chosen:updated');</script>";
		}
		$this->organisation->render($param->NewWriter);
		$this->etablissement->render($param->NewWriter);
	}

	//
	public function initialiserListPrests() {
		$dataPrests = array();
		$dataPrests[$indexPrest]['idOrganisation'] = 0;
		$dataPrests[$indexPrest]['idEtablissement'] = 0;
		$dataPrests[$indexPrest]['idTypePrestation'] = 0;
		$dataPrests[$indexPrest]['idPrestation'] = 0;

		$this->listePrestations->dataSource = $dataPrests;
		$this->listePrestations->dataBind();
		$organisations = new Atexo_Organisation_Gestion();

		foreach ($this->listePrestations->getItems() as $item) {
			$item->organisationPrest->DataSource = $organisations->getAllOrganisation($this->_lang, Prado::localize('SELECTIONNEZ'),true);
			$item->organisationPrest->DataBind();

			$item->etablissementPrest->DataSource = array();
			$item->etablissementPrest->DataBind();
			$item->typesPrests->DataSource = array();
			$item->typesPrests->DataBind();
			$item->prests->DataSource = array();
			$item->prests->DataBind();
		}
		$this->listePrestationsPanel->setStyle('display:block');
	}

	public function ajouterPrestation($sender, $param) {
		$dataPrests = $this->getDataPrestations();
		$indexPrest = count($dataPrests);

		$dataPrests[$indexPrest]['idOrganisation'] = '';
		$dataPrests[$indexPrest]['idEtablissement'] = '';
		$dataPrests[$indexPrest]['idTypePrestation'] = '';
		$dataPrests[$indexPrest]['idPrestation'] = '';

		$this->remplirPrestations($dataPrests);
		$this->listePrestationsPanel->render($param->NewWriter);
	}

	public function remplirPrestations($dataPrests) {
		$typePrestation = $this->getViewState("typePrestation");
		$this->listePrestations->dataSource = $dataPrests;
		$this->listePrestations->dataBind();
		$organisations = new Atexo_Organisation_Gestion();
		$etablissements = new Atexo_Etablissement_Gestion();
		$typePrests = new Atexo_TypePrestation_Gestion();
		$prests = new Atexo_Prestation_Gestion();
		$indexPrest = 0;
		foreach ($this->listePrestations->getItems() as $item) {
			$item->organisationPrest->DataSource = $organisations->getAllOrganisation($this->_lang, Prado::localize('SELECTIONNEZ'));
			$item->organisationPrest->DataBind();
			if($dataPrests[$indexPrest]['idOrganisation']!='') {
				$item->organisationPrest->setSelectedValue($dataPrests[$indexPrest]['idOrganisation']);
				$item->etablissementPrest->DataSource = $etablissements->getEtablissementByIdProvinceIdOrganisation($this->_lang, 
																													$dataPrests[$indexPrest]['idOrganisation'], 
																													null, 
																													Prado::localize('SELECTIONNEZ'));
				$item->etablissementPrest->DataBind();
				if($dataPrests[$indexPrest]['idEtablissement']!='') {
					$item->etablissementPrest->setSelectedValue($dataPrests[$indexPrest]['idEtablissement']);
					$item->typesPrests->DataSource = $typePrests->getTypePrestationByIdEtab($this->_lang,
																							$dataPrests[$indexPrest]['idEtablissement'], 
																							Prado::localize('SELECTIONNEZ'));
					$item->typesPrests->DataBind();
					if($dataPrests[$indexPrest]['idTypePrestation']!='') {
						$item->typesPrests->setSelectedValue($dataPrests[$indexPrest]['idTypePrestation']);
						$item->prests->DataSource = $prests->getPrestationByIdTypePrestation($this->_lang,
																							$dataPrests[$indexPrest]['idTypePrestation'], 
																							$typePrestation,
																							Prado::localize('SELECTIONNEZ'));
						$item->prests->DataBind();
						if($dataPrests[$indexPrest]['idPrestation']!='') {
							$item->prests->setSelectedValue($dataPrests[$indexPrest]['idPrestation']);
						}
					}
				}
			}

			$indexPrest++;
		}
	}

	public function refresh($sender,$param)
	{
		$this->listePrestationsPanel->render($param->NewWriter);
	}

	public function deleteItemPrest($sender,$param)
	{
		$finalData = array();
		$itemIndex = $param->CommandParameter;
		if ($param->CommandName == "delete") {

			$dataPrests = $this->getDataPrestations();
			unset($dataPrests[$itemIndex]);
			$finalData = array_values($dataPrests);
			$this->remplirPrestations($finalData);
		}
	}

	public function getDataPrestations() {
		$indexPrest = 0;
		$dataPrests = array();

		foreach ($this->listePrestations->getItems() as $item) {
			$dataPrests[$indexPrest]['idOrganisation'] = $item->organisationPrest->getSelectedValue();
			$dataPrests[$indexPrest]['idEtablissement'] = $item->etablissementPrest->getSelectedValue();
			$dataPrests[$indexPrest]['idTypePrestation'] = $item->typesPrests->getSelectedValue();
			$dataPrests[$indexPrest]['idPrestation'] = $item->prests->getSelectedValue();
			$indexPrest++;
		}
		return $dataPrests;
	}

	public function loadEtablissementPrest($sender) {
		$idOrganisation = $sender->getSelectedValue();
		$etablissements = new Atexo_Etablissement_Gestion();
		//Remplir liste Etablissement
		$sender->Parent->etablissementPrest->DataSource = $etablissements->getEtablissementByIdProvinceIdOrganisation($this->_lang, $idOrganisation, null, Prado::localize('SELECTIONNEZ'),true);
		$sender->Parent->etablissementPrest->DataBind();
	}

	public function loadTypePrests($sender) {
		$idEtab = $sender->getSelectedValue();
		//Remplir liste Type Prestation
		$typePrests = new Atexo_TypePrestation_Gestion();
		$sender->Parent->typesPrests->DataSource = $typePrests->getTypePrestationByIdEtab($this->_lang,$idEtab, Prado::localize('SELECTIONNEZ'));
		$sender->Parent->typesPrests->DataBind();
	}

	public function loadPrests($sender) {
		$idTypePrest = $sender->getSelectedValue();
		$typePrestation = $this->getViewState("typePrestation");
		//Remplir liste Prestations
		$prests = new Atexo_Prestation_Gestion();
		$sender->Parent->prests->DataSource = $prests->getPrestationByIdTypePrestation($this->_lang,$idTypePrest,$typePrestation, Prado::localize('SELECTIONNEZ'));
		$sender->Parent->prests->DataBind();
	}

	public function loadEtablissement($sender, $param) {
		$idProfil = $this->profilUtilisateur->getSelectedValue();
		$tProfilQuery = new TProfilQuery();
		$tProfil = $tProfilQuery->getProfilById($idProfil);
		$typesProfil = array(	Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT"),
								Atexo_Config::getParameter("ID_PROFIL_AGENT_TO"),
								Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION")
								);
		if(in_array($tProfil->getIdTypeProfil(), $typesProfil)) {
			$idOrganisation = $this->organisationUtilisateur->getSelectedValue();
			//Remplir liste Etablissement
			$this->remplirListeEtablissement($idOrganisation);
			$this->validatorEtab->Enabled = $tProfil->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT");
			$this->etablissement->render($param->NewWriter);
		}
		$this->script->Text = "<script>J('.chosen-select').chosen({placeholder_text_multiple:\"".Prado::localize('SELECTIONNEZ')."\"});J('.chosen-select').trigger('chosen:updated');</script>";
	}

	public function getListeNomPrenomParLangues($dataNom, $dataPrenom) {
		self::getListeNomParLangues($dataNom);
		self::getListePrenomParLangues($dataPrenom);
	}

	public function getListeNomParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeNomParLangues($data);
		} else {
			//recupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['nom'] = '';
				$data[$index]['nomLibelleLang'] = Prado::localize('NOM_UTILISATEUR');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['langNom'] = $lan;
				$index++;
			}
			$this->setListeNomParLangues($data);
		}
	}

	public function getListePrenomParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListePrenomParLangues($data);
		} else {
			//recupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['prenom'] = '';
				$data[$index]['prenomLibelleLang'] = Prado::localize('PRENOM_UTILISATEUR');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['langPrenom'] = $lan;
				$index++;
			}
			$this->setListePrenomParLangues($data);
		}
	}

	public function setListePrenomParLangues($data) {
		$this->listePrenomLangues->dataSource = $data;
		$this->listePrenomLangues->dataBind();
		$index = 0;
		foreach ($this->listePrenomLangues->getItems() as $item) {
			$item->prenomLibelleLang->Text = $data[$index]['prenomLibelleLang'];
			$item->prenom->Text = $data[$index]['prenom'];
			$item->langPrenom->Value = $data[$index]['langPrenom'];
			$item->lang->Text = $data[$index]['lang'];
			$index++;
		}
	}

	public function setListeNomParLangues($data) {
		$this->listeNomLangues->dataSource = $data;
		$this->listeNomLangues->dataBind();
		$index = 0;
		foreach ($this->listeNomLangues->getItems() as $item) {
			$item->nomLibelleLang->Text = $data[$index]['nomLibelleLang'];
			$item->nom->Text = $data[$index]['nom'];
			$item->langNom->Value = $data[$index]['langNom'];
			$item->lang->Text = $data[$index]['lang'];
			$index++;
		}
	}

	/**
	 * Validation du formulaire 'mon compte'/gestion utilisateurs coté agent
	 */
	public function onValiderClick() {
		$tAgentQuery = new TAgentQuery();
		$tAgent = $tAgentQuery->getAgentById($_GET["idAgent"]);
		if($tAgent==null) {
			$tAgent = new TAgent();
		}
		$continue = false;
		$tTraductionNom = new TTraduction();
		$tTraductionPrenom = new TTraduction();
		$compteVo = new Atexo_User_CompteVo();

		//Verification existance et Insertion login
		$gestionAgent = new Atexo_Agent_Gestion();
		$agent = $gestionAgent->retrieveAgentByLogin($this->identifiant->getSafeText());
		if($agent) {
			if($agent->getIdAgent() != $tAgent->getIdAgent()) {
				$this->panelMsg->style="display:block";
			} else {
				$continue = true;
			}
		} 
		if(!$agent || $continue) {
			if (($this->passwordUser->Text!='')&&($this->passwordUser->Text!='xxxxxx'))  {
				$tAgent->setTentativesMdp("0");
				$tAgent->setMotDePasse(sha1(Atexo_Utils_Util::atexoHtmlEntities($this->passwordUser->Text)));
			}
			//Creation de mot de passe aléatoire
			if($tAgent->getMotDePasse() == null) {
				$mdp = $compteVo->genererPassWord();
				$tAgent->setMotDePasse(sha1($mdp));
				$this->passwordUser->Text = $mdp;
			}
			if($tAgent->getIdAgent() > 0) {
				//Debut Modification Agent Nom Prenom selon Langues
				$this->modifierTraductionAgent($tAgent);
				//Fin Modification Agent Nom Prenom selon Langues
				$tAgentEtabs = $tAgent->getTAgentEtablissements();
				foreach($tAgentEtabs as $oneAgentEtab) {
					$oneAgentEtab->delete();
				}
			} else {
				//Debut Ajout Agent Nom Prenom selon Langues
				foreach($this->listeNomLangues->getItems() as $item) {
					$tTraductionLibelle = new TTraductionLibelle();
					$tTraductionLibelle->setLang($item->langNom->Value);
					$tTraductionLibelle->setLibelle($item->nom->getSafeText());
					$tTraductionNom->addTTraductionLibelle($tTraductionLibelle);
				}
				foreach($this->listePrenomLangues->getItems() as $item) {
					$tTraductionLibelle = new TTraductionLibelle();
					$tTraductionLibelle->setLang($item->langPrenom->Value);
					$tTraductionLibelle->setLibelle($item->prenom->getSafeText());
					$tTraductionPrenom->addTTraductionLibelle($tTraductionLibelle);
				}
				//Fin Ajout Agent Nom Prenom selon Langues
				$tAgent->setTTraductionRelatedByCodeNomUtilisateur($tTraductionNom);
				$tAgent->setTTraductionRelatedByCodePrenomUtilisateur($tTraductionPrenom);
			}
			$tAgent->setEmailUtilisateur($this->emailUtilisateur->getSafeText());
			$tAgent->setTelephoneUtilisateur($this->telUtilisateur->getSafeText());
			$tAgent->setActif((int)$this->oui->Checked);
			$tAgent->setIdProfil($this->profilUtilisateur->getSelectedValue());
			$idProfil = $this->profilUtilisateur->getSelectedValue();
			$tProfilQuery = new TProfilQuery();
			$tProfil = $tProfilQuery->getProfilById($idProfil);
			$idTypeProfil = $tProfil->getIdTypeProfil();
			$tAgent->setIdOrganisationGere(null);
			$tAgent->setIdOrganisationAttache(null);
			$tAgent->setIdEtablissementAttache(null);
			$tAgent->setIdEtablissementGere(null);

			if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION")) {
				$tAgent->setIdOrganisationGere($this->organisationUtilisateur->getSelectedValue());
				$tAgent->setIdOrganisationAttache($this->organisationUtilisateur->getSelectedValue());
				// Cas d'un agent regional de type de profil admin org
				foreach($this->etablissementUtilisateur->getSelectedValues() as $value) {
					$tAgentEtab = new TAgentEtablissement();
					$tAgentEtab->setIdEtablissement($value);
					$tAgent->addTAgentEtablissement($tAgentEtab);
				}
			}
			if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT") || $idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_AGENT_TO")) {
				$tAgent->setIdOrganisationGere($this->organisationUtilisateur->getSelectedValue());
				$tAgent->setIdEtablissementGere($this->etablissementUtilisateur->getSelectedValue());
				$tAgent->setIdOrganisationAttache($this->organisationUtilisateur->getSelectedValue());
				$tAgent->setIdEtablissementAttache($this->etablissementUtilisateur->getSelectedValue());
				
				foreach($this->etablissementUtilisateur->getSelectedValues() as $value) {
					$tAgentEtab = new TAgentEtablissement();
					$tAgentEtab->setIdEtablissement($value);
					$tAgent->addTAgentEtablissement($tAgentEtab);
				}
			}
			$tAgent->setLogin($this->identifiant->getSafeText());
			$tAgent->save();
			//Suppression des prestations existante pr cet agent
			$prestsAgent = Atexo_AgentPrestation_Gestion::getPrestationByIdAgent($tAgent->getIdAgent());
			foreach($prestsAgent as $onePrestAgent) {
				$onePrestAgent->delete();
			}	
			if($tAgent->getIdAgent()>0 && (!isset($_GET["idAgent"]) || $this->passwordUser->Text!='xxxxxx')) {//Envoi de mail de creation ou de modification de compte Agent
				$this->envoiMail($tAgent->getLogin(), $this->passwordUser->Text, $tAgent->getEmailUtilisateur(), $idTypeProfil);
			}
			$this->response->redirect("?page=administration.GestionUtilisateurs&search");
		}
	}
	
	public function modifierTraductionAgent($tAgent) {
		$tTraductionNom = $tAgent->getTTraductionRelatedByCodeNomUtilisateur();
		if($tTraductionNom instanceof TTraduction) {
			foreach($this->listeNomLangues->getItems() as $item) {
				$tTraductionLibelleQuery = new TTraductionLibelleQuery();
				$tTraductionLibelleNom = $tTraductionLibelleQuery->getTraductionLibelleById($tTraductionNom->getIdTraduction(), $item->langNom->Value);

				if($tTraductionLibelleNom instanceof TTraductionLibelle) {
					$tTraductionLibelleNom->setLibelle($item->nom->getSafeText());
					$tTraductionLibelleNom->save();
				}
				else {//Si l'agent n'a pas de nom saisi dans une des langues
					$tTraductionLibelleNom = new TTraductionLibelle();
					$tTraductionLibelleNom->setIdTraduction($tTraductionNom->getIdTraduction());
					$tTraductionLibelleNom->setLang($item->langNom->Value);
					$tTraductionLibelleNom->setLibelle($item->nom->getSafeText());
					$tTraductionLibelleNom->save();
				}
			}
		} else {
			//Si l'agent n'a pas de nom saisi dans aucune langue
			$tTraductionNom = new TTraduction();
			foreach($this->listeNomLangues->getItems() as $item) {
				$tTraductionLibelle = new TTraductionLibelle();
				$tTraductionLibelle->setLang($item->langNom->Value);
				$tTraductionLibelle->setLibelle($item->nom->getSafeText());
				$tTraductionNom->addTTraductionLibelle($tTraductionLibelle);
			}
			$tAgent->setTTraductionRelatedByCodeNomUtilisateur($tTraductionNom);
		}
		//Preom
		$tTraductionPrenom = $tAgent->getTTraductionRelatedByCodePrenomUtilisateur();
		if($tTraductionPrenom instanceof TTraduction) {
			foreach($this->listePrenomLangues->getItems() as $item) {
				$tTraductionLibelleQuery = new TTraductionLibelleQuery();
				$tTraductionLibellePrenom = $tTraductionLibelleQuery->getTraductionLibelleById($tTraductionPrenom->getIdTraduction(), $item->langPrenom->Value);

				if($tTraductionLibellePrenom instanceof TTraductionLibelle) {
					$tTraductionLibellePrenom->setLibelle($item->prenom->getSafeText());
					$tTraductionLibellePrenom->save();
				}
				else {//Si l'agent n'a pas de prenomnom saisi dans une des langues
					$tTraductionLibellePrenom = new TTraductionLibelle();
					$tTraductionLibellePrenom->setIdTraduction($tTraductionPrenom->getIdTraduction());
					$tTraductionLibellePrenom->setLang($item->langPrenom->Value);
					$tTraductionLibellePrenom->setLibelle($item->prenom->getSafeText());
					$tTraductionLibellePrenom->save();
				}
			}
		} else {
			//Si l'agent n'a pas de prenom saisi
			$tTraductionPrenom = new TTraduction();
			foreach($this->listePrenomLangues->getItems() as $item) {
				$tTraductionLibelle = new TTraductionLibelle();
				$tTraductionLibelle->setLang($item->langPrenom->Value);
				$tTraductionLibelle->setLibelle($item->prenom->getSafeText());
				$tTraductionPrenom->addTTraductionLibelle($tTraductionLibelle);
			}
			$tAgent->setTTraductionRelatedByCodePrenomUtilisateur($tTraductionPrenom);
		}
	}

	public function remplir($idAgent) {

		$tAgentQuery = new TAgentQuery();
		$tAgent = $tAgentQuery->getAgentById($idAgent);

		if ($tAgent instanceof TAgent){
			$this->identifiant->setText($tAgent->getLogin());
			$this->emailUtilisateur->setText($tAgent->getEmailUtilisateur());
			$this->telUtilisateur->setText($tAgent->getTelephoneUtilisateur());
			if($tAgent->getActif()=="1") {
				$this->oui->Checked = true;
			}
			else {
				$this->non->Checked = true;
			}
			//recupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataNom[$index]['nom'] = $tAgent->getNomUtilisateurTraduit($lan);
				$this->_dataNom[$index]['nomLibelleLang'] = Prado::localize('NOM_UTILISATEUR');
				$this->_dataNom[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataNom[$index]['langNom'] = $lan;

				$this->_dataPrenom[$index]['prenom'] = $tAgent->getPrenomUtilisateurTraduit($lan);
				$this->_dataPrenom[$index]['prenomLibelleLang'] = Prado::localize('PRENOM_UTILISATEUR');
				$this->_dataPrenom[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataPrenom[$index]['langPrenom'] = $lan;
				$index++;
			}

			//type profil et profil
			$idProfil = $tAgent->getIdProfil();
			$tProfilQuery = new TProfilQuery();
			$profilGestion = new Atexo_Profil_Gestion();
			$profil = $tProfilQuery->getProfilById($idProfil);
			if($profil instanceof TProfil) {
				$idTypeProfil = $profil->getIdTypeProfil();

				$this->profilUtilisateur->DataSource = $profilGestion->getAllProfilByType($idTypeProfil, $this->_lang, Prado::localize('SELECTIONNEZ'));
				$this->profilUtilisateur->DataBind();
				$this->profilUtilisateur->setselectedValue($idProfil);
				if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_SYSTEM")) {
					$this->organisation->setStyle('display:none');
					$this->etablissement->setStyle('display:none');
					$this->listePrestationsPanel->setStyle('display:none');
					$this->validatorOrg->Enabled=false;
					$this->validatorEtab->Enabled=false;
				}
				if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION")) {
					$this->organisation->setStyle('display:block');
					$this->etablissement->setStyle('display:block');
					$this->listePrestationsPanel->setStyle('display:none');
					//Remplir liste Organisation
					$this->remplirListeOrganisation();
					$this->organisationUtilisateur->setSelectedValue($tAgent->getIdOrganisationGere());
					//Remplir liste Etablissements
					$this->remplirListeEtablissement($tAgent->getIdOrganisationGere());
					$idsAgentEtab = array();
					$agentEtabs = $tAgent->getTAgentEtablissements();
					foreach($agentEtabs as $agentEtab) {
						$idsAgentEtab[] = $agentEtab->getIdEtablissement();
					}
					$this->etablissementUtilisateur->setSelectedValues($idsAgentEtab);
					$this->validatorOrg->Enabled=true;
					$this->validatorEtab->Enabled=false;
				}
				if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT") || $idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_AGENT_TO")) {
					$this->organisation->setStyle('display:block');
					//Remplir liste Organisation
					$this->remplirListeOrganisation();
					$this->etablissement->setStyle('display:block');
					$this->listePrestationsPanel->setStyle('display:none');
					$this->organisationUtilisateur->setSelectedValue($tAgent->getIdOrganisationGere());
					$this->remplirListeEtablissement($tAgent->getIdOrganisationGere());
					
					$idsAgentEtab = array();
					
					$agentEtabs = $tAgent->getTAgentEtablissements();
					
					foreach($agentEtabs as $agentEtab) {
						$idsAgentEtab[] = $agentEtab->getIdEtablissement();
					}
					
					$this->etablissementUtilisateur->setSelectedValues($idsAgentEtab);
					if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_AGENT_TO")) {
						$this->validatorOrg->Enabled=false;
						$this->validatorEtab->Enabled=false;
					} else {
						$this->validatorOrg->Enabled=true;
						$this->validatorEtab->Enabled=true;
					}
				}
			}
			if($idAgent == Atexo_User_CurrentUser::getIdAgentConnected()) {
				//$this->typeProfil->setEnabled(false);
				$this->profilUtilisateur->setEnabled(false);
				$this->organisationUtilisateur->setEnabled(false);
				$this->etablissementUtilisateur->setEnabled(false);
			}

		}
	}

	/**
	 * Envoi des infos du compte par mail
	 *
	 * @param string $login
	 * @param string $mdp
	 * @param string $email
	 */
	protected function envoiMail($login, $mdp, $email, $idTypeProfil)
	{
		$mail = new Atexo_Utils_Mail();
		$pfUrl = $this->getPfUrl();

		if($idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION") || 
			$idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT") || 
			$idTypeProfil == Atexo_Config::getParameter("ID_PROFIL_ADMIN_SYSTEM")) {


			$urlAuthentification = $pfUrl.'?page=administration.AdministrationAccueil';
		} else {
			$urlAuthentification = $pfUrl.'?page=agent.AgentAccueil';
		}
		if(isset($_GET["idAgent"]))
		{
			$objet = prado::localize('COMPTE_MAIL_PREFIXE_OBJET') ." ".Prado::localize("TRANS_CHAMP_VIDE")." ". prado::localize('MDPREC_OBJET_COURRIEL_COMPTE_MODIFIE');
			$debutMail = prado::localize('MAIL_MODIFICATION_IDENTIFIANT_PART1');
		} else {
			$objet = prado::localize('COMPTE_MAIL_PREFIXE_OBJET') ." ".Prado::localize("TRANS_CHAMP_VIDE")." ". prado::localize('COMPTE_COMPTE_ACCES');
			$debutMail = prado::localize('MAIL_CREATION_COMPTE_PART1');
		}
		$corpsMessage = $debutMail . $login;
		if($mdp != prado::localize('TRANS_MDP_ETOILE'))
		{
  			$corpsMessage .= prado::localize('MAIL_CREATION_IDENTIFIANT_PART2') . $mdp;
		}
		$corpsMessage .= prado::localize('MAIL_CREATION_IDENTIFIANT_PART3').' <a href="'.$urlAuthentification.'">'.$urlAuthentification.'</a>';
		$corpsMessage .= prado::localize('MAIL_GENERATION_COMPTE_OF_PART4')
		. prado::localize('MAIL_CREATION_COMPTE_OF_PART6');
//		. prado::localize('MAIL_CREATION_COMPTE_OF_PART7');
		try {
			$mail->envoyerMail(Atexo_Config::getParameter('PF_MAIL_FROM'),$email,$objet,$corpsMessage);
		}catch (Exception $e){
			$logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
		    $logger->error($e->getMessage());
			Atexo_Utils_GestionException::catchException($e);
		}
	}

	protected function retour ()
	{
		if($this->getCalledPage() == Atexo_Config::getParameter('MENU_MON_COMPTE') || $this->getCalledPage() == Atexo_Config::getParameter('MENU_ORGANISME_MON_COMPTE') ) // depuis lien [Mon Compte]
		{
			if(Atexo_User_CurrentUser::isAgent())
			{
				$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=agent.Accueil'));
			}else{
				$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=organisme.Accueil'));
			}
		}elseif($this->idReferentRegion && $this->getCalledPage() == Atexo_Config::getParameter('MENU_UTILISATEUR')){
			$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=agent.RechercheUtilisateur&retourRecherche=1'));
		}elseif(!$this->idReferentRegion && $this->getCalledPage() == Atexo_Config::getParameter('MENU_UTILISATEUR')){
			$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=agent.Accueil'));
		}
	}


	/*
	 * Construction du mail - sujet + corps du message
	 */
	/*public function construireMailModificationCompte($login, $mdp, $email, $urlUnique, $role = 'organisme')
	 {
		$objet = prado::localize('COMPTE_MAIL_PREFIXE_OBJET') ." ".Prado::localize("TRANS_CHAMP_VIDE")." ".prado::localize('COMPTE_OBJET_COURRIEL_DEMANDE_DE_MODIFICATION') . ' ' . prado::localize('TITRE');

		$corpsMessage = prado::localize('MAIL_MODIFICATION_IDENTIFIANT_PART1') . '<br />';
		$corpsMessage .= prado::localize('TRANS_IDENTIFIANT') . ': ' . $login . '<br />';
		$corpsMessage .= prado::localize('TRANS_MOT_PASSE') . ': ' . $mdp . '<br /><br />';

		$corpsMessage .= prado::localize('MDPREC_DEMANDE_COURRIER_REINITIALISATION_PART2') . ' <a href="' . $urlUnique.'">'.$urlUnique.'</a>';
		$corpsMessage .=  prado::localize('MAIL_CREATION_COMPTE_OF_PART6');
		$corpsMessage .=  prado::localize('MAIL_CREATION_COMPTE_OF_PART7');
		return array('objet' => $objet, 'corpsMessage' => $corpsMessage);
		}*/
}
