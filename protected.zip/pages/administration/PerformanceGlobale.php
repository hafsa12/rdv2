<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class PerformanceGlobale extends AtexoPage {

	public $prestation;
	public $nbRessource;
	public $capacite;
	public $moyenne;
	private $_lang;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!Atexo_User_CurrentUser::hasHabilitation('PerformanceGlobale')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}

        if(!$this->isPostBack) {
            $this->loadEntite();
            $this->loadEntite2();
            $this->loadEntite3();
            $this->loadTypeEtablissement();
            $this->loadEtablissement();
            $adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
            if($adminEtab) {
                $idEtablissement = Atexo_User_CurrentUser::getIdEtablissementGere();
                $this->listeEtablissement->setSelectedValue($idEtablissement);
                $this->loadTypePrestation();
            }
            $util = new Atexo_Utils_Util();
            $this->datedebut->Text = $util->iso2frnDate($util->addMois(date("Y-m-d"),-1));
            $this->datefin->Text = date("d/m/Y");
            $this->suggestNames();
        }
	}

	public function loadEntite() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite1->DataSource = $entiteGestion->getAllEntite(1,$lang,null,Prado::localize('ENTITE_1'));
		$this->entite1->DataBind();
	}

	public function loadEntite2($sender = null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
		$this->entite2->DataBind();
		if($sender) {
			$this->loadEntite3();
			$this->loadEtablissement($this->entite1->getSelectedValue());
		}
	}

	public function loadEntite3($sender = null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$idEntite = null;

		if($this->entite2->SelectedValue) {
			$idEntite = $this->entite2->SelectedValue;
		}elseif($this->entite1->SelectedValue){
			$idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
		}

		$this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
		$this->entite3->DataBind();
		if($sender) {
			$this->loadEtablissement(null, $this->entite2->getSelectedValue());
		}
	}

	public function loadEtablissementByEntite() {
		$this->loadEtablissement();
	}

	public function loadEtablissement($idEntite1 = null, $idsEntite2 = null) {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		if($idEntite1) {
			$entiteGestion = new Atexo_Entite_Gestion();
			$idsCommune = $entiteGestion->getAllIdChildEntite ($idEntite1);
		}
		if($idsEntite2) {
			$entiteGestion = new Atexo_Entite_Gestion();
			$idsCommune = $entiteGestion->getAllIdChildEntite ($idsEntite2);
		}
		if($this->entite3->getSelectedValue ()) {
			$idsCommune = array($this->entite3->getSelectedValue ());
		}
		$etablissementGestion = new Atexo_Etablissement_Gestion();
        if(Atexo_Config::getParameter('MODULE_TYPE_ETAB_' . $this->User->getCurrentOrganism()) == 1 && $this->listeTypeEtablissement->selectedValue > 0){
            $listEtab = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,
                Atexo_User_CurrentUser::getIdOrganisationGere(), null, Prado::localize('ETABLISSEMENT'), true, false, $idsCommune, $this->listeTypeEtablissement->selectedValue);

        }else {
            $listEtab = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,
                Atexo_User_CurrentUser::getIdOrganisationGere(), null, Prado::localize('ETABLISSEMENT'), true, false, $idsCommune);
        }
        $this->listeEtablissement->DataSource = $listEtab;
        $this->listeEtablissement->DataBind();
		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$this->loadRefPrestation();
		}
	}

	public function loadTypePrestation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$idEtablissement = $this->listeEtablissement->getSelectedValue();

		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$refTypePrestationGestion = new Atexo_RefTypePrestation_Gestion();
			$this->listeTypePrestation->DataSource = $refTypePrestationGestion->getRefTypePrestationByIdOrg($lang,Atexo_User_CurrentUser::getIdOrganisationGere(),Prado::localize('NIVEAU1'),$idEtablissement);
			$this->listeTypePrestation->DataBind();
			$this->loadRefPrestation();
		} else {
			$typePrestationGestion = new Atexo_TypePrestation_Gestion();
			$this->listeTypePrestation->DataSource = $typePrestationGestion->getTypePrestationByIdEtab($lang,$idEtablissement,Prado::localize('NIVEAU1'));
			$this->listeTypePrestation->DataBind();

			$this->listePrestation->DataSource = array();
			$this->listePrestation->DataBind();
		}
	}
	
	public function loadRefPrestation() {
		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$lang = Atexo_User_CurrentUser::readFromSession("lang");
			$idEtablissement = $this->listeEtablissement->getSelectedValue();
			$refPrestationGestion = new Atexo_RefPrestation_Gestion();
			$this->listeRefPrestation->DataSource = $refPrestationGestion->getAllRefPrestation($lang,$this->listeTypePrestation->SelectedValue,Prado::localize('NIVEAU2'),$idEtablissement);
			$this->listeRefPrestation->DataBind();
			$this->listeRefPrestation->Visible = true;
		}
	}

	public function populateData(Atexo_Prestation_CriteriaVo $criteriaVo)
	{
		$dataPrestation = TPrestationPeer::getPrestationByCriteres($criteriaVo);
		
		$dateDebut=$this->datedebut->SafeText;
		$dateFin=$this->datefin->SafeText;
		$nbPr = count($dataPrestation);
		
		$criteria = new Atexo_DelaiObtention_CriteriaVo(); 
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$criteria->setLang($lang);

		if($this->entite1->getSelectedValue()>0) {
			$criteria->setIdEntite($this->entite1->getSelectedValue());
		}
		if($this->listeTypePrestation->getSelectedValue()>0) {
			$criteria->setIdTypePrestation($this->listeTypePrestation->getSelectedValue());
		}

		if($this->listeEtablissement->getSelectedValue()>0) {
			$criteria->setIdEtablissementAttache($this->listeEtablissement->getSelectedValue());
		}
		else {
			$criteria->setIdEtablissementAttache(Atexo_User_CurrentUser::getIdEtablissementGere());
		}
		if($this->listeRefPrestation->getSelectedValue()>0) {
			$criteriaVo->setIdRefPrestation($this->listeRefPrestation->getSelectedValue());
		}
		$idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
		if($idOrg>0) {
			$criteriaVo->setIdOrganisation($idOrg);
		}
		$criteria->setDateDu($dateDebut);
		$criteria->setDateAu($dateFin);
			
		for($i=0; $i<$nbPr; $i++) {
			$tPeriodeQuery = new TPeriodeQuery();
			$capacite = $tPeriodeQuery->getCapacite($dataPrestation[$i]["ID_PRESTATION"],$dateDebut,$dateFin);
			$dataPrestation[$i]["CAPACITE"] = $capacite;
			
			$idPrestation = $dataPrestation[$i]["ID_PRESTATION"];
			$criteria->setIdPrestation($idPrestation);
			
			$dataRdv = TDelaiObtentionPeer::getDelaiObtentionByCriteres($criteria);
			$dataRdv = $dataRdv;
			
			$dataPrestation[$i]["DELAI"] = (int)$dataRdv[0]["VALUE_MOYENNE"] ;
			
			$dataPrestation[$i]["data"] = "[".$dataPrestation[$i]["CAPACITE"].",".$dataPrestation[$i]["NB_RESSOURCE"].",".$dataPrestation[$i]["DELAI"]."]" ;
		}
		$dataPrestation = Atexo_Utils_Util::orderArrayByCol($dataPrestation,"DELAI");
		if($this->listeEtablissement->getSelectedValue()==0) {
			$dataPrestationEtab = array();
			for($i=0; $i<$nbPr; $i++) {
				
				$delaiEtab = $dataPrestationEtab[$dataPrestation[$i]["ID_ETABLISSEMENT"]]["DELAI"];
				if($delaiEtab<$dataPrestation[$i]["DELAI"]) {
					$dataPrestationEtab[$dataPrestation[$i]["ID_ETABLISSEMENT"]]["data"]=$dataPrestation[$i]["data"];
					$dataPrestationEtab[$dataPrestation[$i]["ID_ETABLISSEMENT"]]["DELAI"]=$dataPrestation[$i]["DELAI"];
					$dataPrestationEtab[$dataPrestation[$i]["ID_ETABLISSEMENT"]]["LIBELLE_ETP"]=$dataPrestation[$i]["LIBELLE_ETAB"]." - ".
																						$dataPrestation[$i]["LIBELLE_ENTITE"]."<br>".
																						$dataPrestation[$i]["LIBELLE_TYPE_PRESTATION"]." - ".
																						$dataPrestation[$i]["LIBELLE_PRESTATION"];
				}
			}
			$this->data->DataSource=$dataPrestationEtab;
			$this->data->DataBind();
		}
		else {
			$this->data->DataSource=$dataPrestation;
			$this->data->DataBind();
		}
	}

	protected function suggestNames() {

		$criteriaVo = new Atexo_Prestation_CriteriaVo();
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$criteriaVo->setLang($lang);
		$criteriaVo->setPrestationReferentiel($_SESSION["typePrestation"]);

		if($this->entite3->getSelectedValue()>0) {
			$criteriaVo->setIdEntite($this->entite3->getSelectedValue());
		}
		elseif($this->entite2->getSelectedValue()>0) {
			$criteriaVo->setIdEntite($this->entite2->getSelectedValue());
		}
		elseif($this->entite1->getSelectedValue()>0) {
			$criteriaVo->setIdEntite($this->entite1->getSelectedValue());
		}
		if($this->listeTypePrestation->getSelectedValue()>0) {
			if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
				$criteriaVo->setIdRefTypePrestation($this->listeTypePrestation->getSelectedValue());
			}
			else {
				$criteriaVo->setIdTypePrestation($this->listeTypePrestation->getSelectedValue());
			}
		}

		if($this->listeEtablissement->getSelectedValue()>0) {
			$criteriaVo->setIdEtablissement($this->listeEtablissement->getSelectedValue());
		}
		else {
			$criteriaVo->setIdEtablissement(Atexo_User_CurrentUser::getIdEtablissementGere());
		}
		
		if($this->listeRefPrestation->getSelectedValue()>0) {
			$criteriaVo->setIdRefPrestation($this->listeRefPrestation->getSelectedValue());
		}

		$idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
		if($idOrg>0) {
			$criteriaVo->setIdOrganisation($idOrg);
		}
        if($this->listeTypeEtablissement->selectedValue > 0) {
            $criteriaVo->setIdTypeEtablissement($this->listeTypeEtablissement->selectedValue);
        }
		$this->Page->setViewState("CriteriaVo",$criteriaVo);
		$this->populateData($criteriaVo);
	}

    public function loadTypeEtablissement() {
        if(Atexo_Config::getParameter('MODULE_TYPE_ETAB_' . $this->User->getCurrentOrganism()) == 1){
            $lang = Atexo_User_CurrentUser::readFromSession("lang");
            $idOrg = Atexo_User_UserVo::getCurrentOrganism();
            $tTypeEtabPeer = new TTypeEtabPeer();

            $listTypeEtab = $tTypeEtabPeer->getTypeEtab($lang, $idOrg);
            $dataSource['0'] = Prado::localize('TYPE_ETABLISSEMENT');
            foreach ($listTypeEtab as $item){
                $dataSource[$item['ID_TYPE_ETAB']] = $item['CODE_LIBELLE'];
            }
            $this->listeTypeEtablissement->DataSource = $dataSource;
            $this->listeTypeEtablissement->DataBind();
        }
    }

    public function loadEtabByTypeEtab($sender, $param){
        $this->loadEtablissement();
    }
}
