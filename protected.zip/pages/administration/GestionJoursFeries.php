<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionJoursFeries extends AtexoPage {

	private $_lang = "";
	/**
	 * @var Atexo_JourFerie_CriteriaVo
	 */
	protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionJoursFeries')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack) {
			if(!isset($_GET["search"])) {
				unset($_SESSION["JF"]["criteriaVoSearch"]);
				unset($_SESSION["JF"]["sensTriArray"]);
				unset($_SESSION["JF"]["sortByElement"]);
			}
			$this->init();
		}else{
			$this->_criteriaVo = $_SESSION["JF"]["criteriaVoSearch"];
		}
	}

	protected function init()
	{
		$this->_criteriaVo = $_SESSION["JF"]["criteriaVoSearch"];

		$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
		$adminEtab = Atexo_User_CurrentUser::isAdminEtab();
		$this->loadOrganisation();

		if(!$this->_criteriaVo) {
			$this->_criteriaVo = new Atexo_JourFerie_CriteriaVo();
			if ( $adminOrg ) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
				$this->_criteriaVo->setIdOrganisation ( $idOrganisation );
				$this->listeOrganisation->SelectedValue = $idOrganisation;
				$this->listeOrganisation->Enabled = false;
			}
			if ( $adminEtab ) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache ();
				$this->_criteriaVo->setIdOrganisation ( $idOrganisation );
				$this->listeOrganisation->SelectedValue = $idOrganisation;
				$this->listeOrganisation->Enabled = false;
			}
			$this->_criteriaVo->setSortByElement ( "LIBELLE_JOUR_FERIE" );
            $_SESSION["JF"]['sortByElement'] = "LIBELLE_JOUR_FERIE";
            $_SESSION["JF"]['sensTriArray'] = array( "LIBELLE_JOUR_FERIE" => "ASC" );
		}
        else{
			$idOrganisation = $this->_criteriaVo->getIdOrganisation();
			$this->listeOrganisation->SelectedValue = $idOrganisation;
			if ( $adminOrg ) {
                $this->listeOrganisation->Enabled = false;
            }
        }
		$this->_criteriaVo->setLang ( $this->_lang );
        if(isset($_GET["pages"])) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if(isset($_GET["pageSize"])) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listeJoursFeries->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif(!$this->_criteriaVo->getPageSize()) {
            $this->_criteriaVo->setPageSize(10);
        }
		$this->fillRepeaterWithDataForSearchResult();
	}
	
	/**
	 * Remplir liste Organisation
	 */
	public function loadOrganisation() {
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($this->_lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}
	
	/**
	 * Remplir repeater des jours fériés selon les critères de recherche
	 */
	public function fillRepeaterWithDataForSearchResult()
	{
		$tJourFeriePeer = new TJourFeriePeer();
        //Nombre de jours feriés
		$nombreElement = $tJourFeriePeer->getJoursFeriesByCriteres($this->_criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->panelBottom->setVisible(true);
			$this->panelTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listeJoursFeries->setVirtualItemCount($nombreElement);
			$this->listeJoursFeries->setCurrentPageIndex(0);
			$this->populateData();
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
			$this->panelTop->setVisible(false);
			$this->panelBottom->setVisible(false);
			$this->listeJoursFeries->DataSource=array();
			$this->listeJoursFeries->DataBind();
			$this->nombreElement->Text="0";
		}
        $_SESSION["JF"]["criteriaVoSearch"] = $this->_criteriaVo;
	}
	
	/**
	 * Rechercher un jour férié par mot-clé
	 */
	protected function suggestNames($sender,$param) {
        try {
            // Get the token
            $token = $this->listeOrganisation->getSelectedValue ();
            // Sender is the Suggestions repeater
            $this->_criteriaVo = new Atexo_JourFerie_CriteriaVo();
            $this->_criteriaVo->setLang ( $this->_lang );
            $this->_criteriaVo->setIdOrganisation ( $token );
            $this->_criteriaVo->setSuggest ( true );
            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);
            unset($_GET["pageSize"]);
            unset($_GET["pages"]);

            $this->fillRepeaterWithDataForSearchResult ();
            $this->jourFeriePanel->render ( $param->getNewWriter () );
            $this->jourFeriePanel->style = "display:block";
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}
	
	public function isTrierPar($champ) {
        $sortByElement = $_SESSION["JF"]["sortByElement"];
        if($champ!=$sortByElement) {
            return "";
        }
        $arraySens = $_SESSION["JF"]["sensTriArray"] ? $_SESSION["JF"]["sensTriArray"] : array ();
        if($arraySens[$sortByElement]=="ASC") {
            return "tri-on tri-asc";
        }
        return "tri-on tri-desc";
	}
	
	public function Trier($sender,$param)
	{
        try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["JF"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $arraySensTri = $_SESSION["JF"]["sensTriArray"] ? $_SESSION["JF"]["sensTriArray"] : array ();
            $arraySensTri[ $champsOrderBy ] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $arraySensTri[ $champsOrderBy ] );
            $_SESSION["JF"]["sensTriArray"] = $arraySensTri;

            $_SESSION["JF"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);

            $this->populateData ();
            $this->jourFeriePanel->render ( $param->getNewWriter () );
            $this->numPageTop->Text = 1;
            $this->numPageBottom->Text = 1;
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}
	
	public function pageChanged($sender,$param)
	{
        $urlParams = "&pages=".($param->NewPageIndex+1);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionJoursFeries&search".$urlParams);
	}

    public function goToPage($sender)
    {
        switch ($sender->ID) {
            case "DefaultButtonTop" :
                $numPage = $this->numPageTop->Text;
                break;
            case "DefaultButtonBottom" :
                $numPage = $this->numPageBottom->Text;
                break;
        }
        $urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeJoursFeries->CurrentPageIndex+1, $this->nombrePageTop->Text);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionJoursFeries&search".$urlParams);
    }

    public function changePagerLenght($sender)
    {
        switch ($sender->ID) {
            case "nombreResultatAfficherBottom" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
                break;
            case "nombreResultatAfficherTop" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
                break;
        }
        $this->response->redirect("?page=administration.GestionJoursFeries&search&pages=1&pageSize=".$pageSize);
    }
	
	/**
	 * Peupler les données des jours fériés
	 */
	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");
        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listeJoursFeries->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listeJoursFeries->CurrentPageIndex = $numPage -1;

        $offset = $this->listeJoursFeries->CurrentPageIndex * $pageSize;
		$limit = $pageSize;
        $this->listeJoursFeries->PageSize = $limit;

		if ($offset + $limit > $nombreElement) {
			$limit = $nombreElement - $offset;
		}
		$this->_criteriaVo->setOffset($offset);
		$this->_criteriaVo->setLimit($limit);
		$tJourFeriePeer = new TJourFeriePeer();
		$dataJourFerie = $tJourFeriePeer->getJoursFeriesByCriteres($this->_criteriaVo);
		$this->listeJoursFeries->DataSource=$dataJourFerie;
		$this->listeJoursFeries->DataBind();

        $this->numPageBottom->Text = $numPage;
        $this->numPageTop->Text = $numPage;
        $this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
        $this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
        $this->nombrePageTop->Text = $nombrePages;
        $this->nombrePageBottom->Text = $nombrePages;
	}
	
	/**
	 * Confirmer la suppression d'un jour fériés 
	 */
	public function onConfirmSuppressionClick($sender,$param) {
		$tJourFerieQuery = new TJourFerieQuery();
		$idJourFerie = $this->jourFerieToDeleteHidden->Value;
		$tJourFerie = $tJourFerieQuery->getJourFerieById($idJourFerie);

		if($tJourFerie instanceof TJourFerie) {
			$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
			$connexion->beginTransaction();
					
			$tTraductionNom = $tJourFerie->getTTraduction();
			
			$tJourFerie->delete();
			//Nom
			$tTraductionNom->deleteAll($connexion);
			
			$connexion->commit();
			
			$this->paneldeleteFail->style="display:none";
			$this->paneldeleteOk->style="display:block";

			//Remplir repeater 
			$this->fillRepeaterWithDataForSearchResult();
		}
		$this->jourFeriePanel->render($param->getNewWriter());
	}
}