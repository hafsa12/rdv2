<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerRefTypePrestation extends AtexoPage {

	private $_dataLibelleRef = null;


	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionRefTypePrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {

			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$adminEtab = Atexo_User_CurrentUser::isAdminEtab();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}

			if($adminEtab) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}

			$this->loadOrganisation();
			$this->loadGroupes();

			if(isset($_GET["idRefTypePrestation"])) {
				$this->remplir($_GET["idRefTypePrestation"]);
			}

			self::getListeLibelleRefParLangues($this->_dataLibelleRef);
		}
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}

	public function loadGroupes(){
		
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$groupeGestion = new Atexo_Groupe_Gestion();
		$data = $groupeGestion->getListeGroupe(Atexo_User_UserVo::getCurrentOrganism(), $lang, Prado::localize('SELECTIONNEZ'));
		$this->listeGroupes->DataSource = $data;
		$this->listeGroupes->DataBind();
		if(count($data)<=1) {
			$this->panelGroupe->Visible=false;
		}
	}

	/**
	 * @param $data
	 * récuperer repeater libelle du type-prestation
	 */
	public function getListeLibelleRefParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeLibelleRefParLangues($data);
		} else {
			//recupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['libelleRefLibelleLang'] = Prado::localize('LIBELLE_REFERENTIEL_TYPE_PRESTATION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['libelleRef'] = '';
				$data[$index]['langLibelleRef'] = $lan;
				$index++;
			}
			$this->setListeLibelleRefParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater libelle du type-prestation
	 */
	public function setListeLibelleRefParLangues($data) {
		$this->listeLibelleRefLangues->dataSource = $data;
		$this->listeLibelleRefLangues->dataBind();
		$index = 0;
		foreach ($this->listeLibelleRefLangues->getItems() as $item) {
			$item->libelleRefLibelleLang->Text = $data[$index]['libelleRefLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->libelleRef->Text = $data[$index]['libelleRef'];
			$item->langLibelleRef->Value = $data[$index]['langLibelleRef'];
			$index++;
		}
	}
	/**
	 * enregistrer les informations de référentiel prestation
	 */
	public function enregistrer() {

		if(isset($_GET["idRefTypePrestation"])) {
			$tRefTypePrestationQuery = new TRefTypePrestationQuery();
			$tRefTypePrestation = $tRefTypePrestationQuery->getRefTypePrestationById($_GET["idRefTypePrestation"]);
			$tTraductionLibelleRef = $tRefTypePrestation->getTTraduction();
		}

		if(!($tRefTypePrestation instanceof TRefTypePrestation)) {
			$tRefTypePrestation = new TRefTypePrestation();
			$tTraductionLibelleRef = new TTraduction();
		}

		//boucle
		foreach($this->listeLibelleRefLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionLibelleRef->getTTraductionLibelle($item->langLibelleRef->Value);
			$tTraductionLibelle->setLang($item->langLibelleRef->Value);
			$tTraductionLibelle->setLibelle($item->libelleRef->SafeText);
			$tTraductionLibelleRef->addTTraductionLibelle($tTraductionLibelle);
		}
		//fin
		$tRefTypePrestation->setTTraduction($tTraductionLibelleRef);

		$tRefTypePrestation->setIdOrganisation($this->listeOrganisation->getSelectedValue());
		if($this->listeGroupes->SelectedValue){
			$tRefTypePrestation->setIdGroupe($this->listeGroupes->SelectedValue);
		}else{
			$tRefTypePrestation->setIdGroupe(null);
		}
		

		$tRefTypePrestation->save();

		$url = "index.php?page=administration.GestionRefTypePrestation&search";
		$this->response->redirect($url);
	}
	/**
	 * @param $idRefTypePrestation
	 * récuperer les informations du refPrestation
	 */
	public function remplir($idRefTypePrestation) {

		$tRefTypePrestationQuery = new TRefTypePrestationQuery();
		$tRefTypePrestation = $tRefTypePrestationQuery->getRefTypePrestationById($idRefTypePrestation);

		if ($tRefTypePrestation instanceof TRefTypePrestation){

			$this->listeOrganisation->SelectedValue = $tRefTypePrestation->getIdOrganisation();
			//recupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataLibelleRef[$index]['libelleRef'] = $tRefTypePrestation->getLibelleRefTypePrestationTraduit($lan);
				$this->_dataLibelleRef[$index]['libelleRefLibelleLang'] = Prado::localize('LIBELLE_REFERENTIEL_TYPE_PRESTATION');
				$this->_dataLibelleRef[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataLibelleRef[$index]['langLibelleRef'] = $lan;
				$index++;
			}
		}

		
			$idGroupe = $tRefTypePrestation->getIdGroupe();
			if($idGroupe){
				$this->listeGroupes->SelectedValue = $idGroupe;
			}else{
				$this->listeGroupes->SelectedValue = 0;
			}
			
		
	}
}
