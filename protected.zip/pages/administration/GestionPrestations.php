<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionPrestations extends AtexoPage {

	private $_lang = "";
	/**
	 * @var Atexo_Prestation_CriteriaVo
	 */
	protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionPrestation') || $_SESSION["typePrestation"] != Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack) {
            if(!isset($_GET["search"])) {
                unset($_SESSION["prestation"]["criteriaVoSearch"]);
                unset($_SESSION["prestation"]["sensTri"]);
                unset($_SESSION["prestation"]["sortByElement"]);
            }
            $this->init();
		}else{
            $this->_criteriaVo = $_SESSION["prestation"]["criteriaVoSearch"];
        }
	}

	protected function init() {

		$this->_criteriaVo = $_SESSION["prestation"]["criteriaVoSearch"];

		$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
		$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
		$this->loadOrganisation();
        $this->loadEtablissement();
        $idOrganisation = null;
        $typePrestation = null;

		if(!$this->_criteriaVo) {
			$this->loadEntite1();
			$this->loadEntite2();
			$this->loadEntite3();

            $this->_criteriaVo = new Atexo_Prestation_CriteriaVo();

            if($adminOrg) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
                $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
                $this->listeOrganisation->SelectedValue = $idOrganisation;
                $this->listeOrganisation->Enabled = false;
                $this->loadEtablissement ();
            }
            if($adminEtab) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache ();
                $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
                $this->listeOrganisation->SelectedValue = $idOrganisation;
                $this->listeOrganisation->Enabled = false;

                $this->loadEtablissement ();
                $idEtablissement = Atexo_User_CurrentUser::getIdEtablissementGere ();
                $this->_criteriaVo->setIdEtablissement ( $idEtablissement );
                $this->listeEtablissement->setSelectedValue ( $idEtablissement );
            }
            $this->loadTypePrestation();

			$this->_criteriaVo->setSortByElement("LIBELLE_PRESTATION");
            $this->_criteriaVo->setSensOrderBy("ASC");

            $typePrestation = $this->_getTypePrestationByIdOrganisation($idOrganisation);
            $this->_criteriaVo->setPrestationReferentiel($typePrestation);

            $_SESSION["prestation"]["sortByElement"] = "LIBELLE_PRESTATION";
            $_SESSION["prestation"]["sensTri"] =  "ASC";
		}
        else {
            $this->listeOrganisation->SelectedValue = $this->_criteriaVo->getIdOrganisation();

            $this->populateFiltres();

            $this->listeEtablissement->SelectedValue = $this->_criteriaVo->getIdEtablissement ();

            $this->loadTypePrestation ();
            $this->listeTypePrestation->SelectedValue = $this->_criteriaVo->getIdTypePrestation ();

            if($adminOrg || $adminEtab) {
                $this->listeOrganisation->Enabled = false;
            }
        }
        $this->_criteriaVo->setLang($this->_lang);

        if(isset($_GET["pages"])) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if(isset($_GET["pageSize"])) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listePrestation->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif(!$this->_criteriaVo->getPageSize()) {
            $this->_criteriaVo->setPageSize(10);
        }
		$this->fillRepeaterWithDataForSearchResult();
	}

		/*
         * Remplir la liste des organisations
         */
	public function loadOrganisation() {
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($this->_lang, Prado::localize('ORGANISATION'));
		$this->listeOrganisation->DataBind();
	}

	/*
	 * Remplir la liste des établissements 
	 */
	public function loadEtablissement($idEntite1 = null, $idsEntite2 = null) {
        $idOrganisation = $this->listeOrganisation->getSelectedValue();
        if($idEntite1) {
            $entiteGestion = new Atexo_Entite_Gestion();
            $idsCommune = $entiteGestion->getAllIdChildEntite ($idEntite1);
        }
        if($idsEntite2) {
            $entiteGestion = new Atexo_Entite_Gestion();
            $idsCommune = $entiteGestion->getAllIdChildEntite ($idsEntite2);
        }
        if($this->entite3->getSelectedValue ()) {
            $idsCommune = $this->entite3->getSelectedValue ();
        }

		$etablissementGestion = new Atexo_Etablissement_Gestion();
		$this->listeEtablissement->DataSource = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($this->_lang, $idOrganisation, $idsCommune, Prado::localize('ETABLISSEMENT'), true);
		$this->listeEtablissement->DataBind();
        $this->listeEtablissement->SetSelectedIndex(0);
	}

    public function loadEtablissementPrestation($sender, $param) {
        $this->loadEtablissement();
        $this->loadTypePrestation();
    }

	/*
	 * Remplir la liste des types-prestations 
	 */
	public function loadTypePrestation() {
		try {
            $idEtablissement = $this->listeEtablissement->getSelectedValue ();
            $typePrestationGestion = new Atexo_TypePrestation_Gestion();
            $this->listeTypePrestation->DataSource = $typePrestationGestion->getTypePrestationByIdEtab ( $this->_lang, $idEtablissement, Prado::localize ( 'TYPE_PRESTATION' ) );
            $this->listeTypePrestation->DataBind ();
        }catch(Exception $e){
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	/*
	 * @param $criteriaVo
	 * Remplir repeater des établissements selon les critères de recherche 
	 */
	public function fillRepeaterWithDataForSearchResult()
	{
		$tPrestationPeer = new TPrestationPeer();
		//Nombre des Prestations

		$nombreElement = $tPrestationPeer->getPrestationByCriteres($this->_criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
            $this->panelBottom->setVisible(true);
            $this->panelTop->setVisible(true);
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listePrestation->setVirtualItemCount($nombreElement);
			$this->listePrestation->setCurrentPageIndex(0);
			$this->populateData();
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
            $this->panelBottom->setVisible(false);
            $this->panelTop->setVisible(false);
			$this->listePrestation->DataSource=array();
			$this->listePrestation->DataBind();
			$this->nombreElement->Text="0";
		}
        $_SESSION["prestation"]["criteriaVoSearch"] = $this->_criteriaVo;
	}

	/**
	 * Peupler les données des prestations
	 */
	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");
        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listePrestation->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listePrestation->CurrentPageIndex = $numPage -1;

        $offset = $this->listePrestation->CurrentPageIndex * $pageSize;
		$limit = $pageSize;
        $this->listePrestation->PageSize = $limit;

		if ($offset + $limit > $nombreElement) {
			$limit = $nombreElement - $offset;
		}
		$this->_criteriaVo->setOffset($offset);
		$this->_criteriaVo->setLimit($limit);

		$dataPrestation = TPrestationPeer::getPrestationByCriteres($this->_criteriaVo);
		$this->listePrestation->DataSource = $dataPrestation;
		$this->listePrestation->DataBind();

        $pageSize = $this->listePrestation->PageSize;

        $this->numPageBottom->Text = $numPage;
        $this->numPageTop->Text = $numPage;
        $this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
        $this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
        $this->nombrePageTop->Text = $nombrePages;
        $this->nombrePageBottom->Text = $nombrePages;
	}

    protected function populateFiltres () {
        $this->loadEntite1();
        if($this->_criteriaVo->getEntite1()) {
            $this->entite1->setSelectedValue($this->_criteriaVo->getEntite1());
        }
        $this->loadEntite2();
        if($this->_criteriaVo->getEntite2()) {
            $this->entite2->setSelectedValue($this->_criteriaVo->getEntite2());
        }
        $this->loadEntite3();
        if($this->_criteriaVo->getEntite3()) {
            $this->entite3->setSelectedValue($this->_criteriaVo->getEntite3());
        }

        $this->loadEtablissement($this->entite1->getSelectedValue(), $this->entite2->getSelectedValue());
    }

	/*
	 * Rechercher Prestation par critères 
	 */
	protected function suggestNames($sender,$param) {
        try {
            $typePrestation = null;
            $token = $this->motsCles->SafeText;
            $this->_criteriaVo = new Atexo_Prestation_CriteriaVo();
            $this->_criteriaVo->setLang ( $this->_lang );
            $this->_criteriaVo->setMotCle ( $token );

            if ( $this->entite1->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite1 ( $this->entite1->getSelectedValue () );
                $this->_criteriaVo->setIdEntite ( $this->entite1->getSelectedValue () );
            }
            if ( $this->entite2->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite2 ( $this->entite2->getSelectedValue () );
                $this->_criteriaVo->setIdEntite ( $this->entite2->getSelectedValue () );
            }
            if ( $this->entite3->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite3 ( $this->entite3->getSelectedValue () );
                $this->_criteriaVo->setIdEntite ( $this->entite3->getSelectedValue () );
            }

            if ( $this->listeTypePrestation->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdTypePrestation ( $this->listeTypePrestation->getSelectedValue () );
            }
            if ( $this->listeEtablissement->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdEtablissement ( $this->listeEtablissement->getSelectedValue () );
            }
            if ( $this->listeOrganisation->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdOrganisation ( $this->listeOrganisation->getSelectedValue () );
                $tOrganisation = TOrganisationQuery::create()->getOrganisationById($this->_criteriaVo->getIdOrganisation ());
                $typePrestation = $tOrganisation->getTypePrestation();
            }
            $this->_criteriaVo->setPrestationReferentiel($typePrestation);
            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);

            // tri
            $this->_criteriaVo->setSortByElement($_SESSION["prestation"]["sortByElement"]);
            $this->_criteriaVo->setSensOrderBy($_SESSION["prestation"]["sensTri"]);

            unset($_GET["pageSize"]);
            unset($_GET["pages"]);

            $this->fillRepeaterWithDataForSearchResult ();
            $this->prestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}



	public function Trier($sender,$param)
	{
        try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["prestation"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $_SESSION["prestation"]["sensTri"] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $_SESSION["prestation"]["sensTri"] );

            $_SESSION["prestation"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
            $this->populateData ();
            $this->prestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function pageChanged($sender,$param)
	{
        $urlParams = "&pages=".($param->NewPageIndex+1);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionPrestations&search".$urlParams);
	}

	public function goToPage($sender)
	{
        switch ($sender->ID) {
            case "DefaultButtonTop" :
                $numPage = $this->numPageTop->Text;
                break;
            case "DefaultButtonBottom" :
                $numPage = $this->numPageBottom->Text;
                break;
        }
        $urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeTypePrestation->CurrentPageIndex+1, $this->nombrePageTop->Text);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionPrestations&search".$urlParams);
	}

	public function changePagerLenght($sender)
	{
        switch ($sender->ID) {
            case "nombreResultatAfficherBottom" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
                break;
            case "nombreResultatAfficherTop" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
                break;
        }
        $this->response->redirect("?page=administration.GestionPrestations&search&pages=1&pageSize=".$pageSize);
	}

	/**
	 * 
	 * Confirmer la suppression d'une prestation
	 */
	public function onConfirmSuppressionClick($sender,$param) {
		$tPrestationQuery = new TPrestationQuery();
		$idPrestation = $this->prestationToDeleteHidden->Value;
		$tPrestation = $tPrestationQuery->getPrestationById($idPrestation);

		if($tPrestation instanceof TPrestation && count($tPrestation->getTAgendas())==0 && count($tPrestation->getTRendezVouss())==0) {

			$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
			$connexion->beginTransaction();

			$tDelaiObtQuery = new TDelaiObtentionQuery();
			$tDelaiObtQuery->deleteByIdPrestation($idPrestation, $connexion);

			$tPieceQuery = new TPiecePrestationQuery();
			$tPieceQuery->deleteByIdPrestation($idPrestation, $connexion);
			
			$tTraductionLibellePres = $tPrestation->getTTraductionRelatedByCodeLibellePrestation();
			$tTraductionCommentairePres = $tPrestation->getTTraductionRelatedByCodeCommentaire();
				
			$tPrestation->delete($connexion);

			//Libelle_prestation
			if($tTraductionLibellePres!=null) {
				$tTraductionLibellePres->deleteAll($connexion);
			}
			$tTraductionCommentairePres->deleteAll($connexion);
			
			$connexion->commit();
			
			$this->paneldeleteFail->style="display:none";
			$this->paneldeleteOk->style="display:block";

		}
		else {
			$this->paneldeleteFail->style="display:block";
			$this->paneldeleteOk->style="display:none";
		}

		//Remplir repeater Prestation
		$this->fillRepeaterWithDataForSearchResult();
		$this->prestationPanel->render($param->NewWriter);
	}

	public function isTrierPar($champ) {
        $sortByElement = $_SESSION["prestation"]["sortByElement"];
		if($champ!=$sortByElement) {
			return "";
		}
		if( $_SESSION["prestation"]["sensTri"] == "ASC" ) {
			return "tri-on tri-asc";
		}
		return "tri-on tri-desc";
	}

    /**
     * Remplir la liste des regions
     */
    public function loadEntite1() {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite1->DataSource = $entiteGestion->getAllEntite(1, $this->_lang, null, Prado::localize('ENTITE_1'));
        $this->entite1->DataBind();
    }

    /**
     * Remplir la liste des provinces
     */
    public function loadEntite2($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
        $this->entite2->DataBind();
        if($sender) {
            $this->loadEntite3();
            $this->loadEtablissement($this->entite1->getSelectedValue());
        }
    }

    /**
     * Remplir la liste des communes
     */
    public function loadEntite3($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $idEntite = null;

        if($this->entite2->SelectedValue) {
            $idEntite = $this->entite2->SelectedValue;
        }elseif($this->entite1->SelectedValue){
            $idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
        }

        $this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
        $this->entite3->DataBind();
        if($sender) {
            $this->loadEtablissement($this->entite1->getSelectedValue(), $this->entite2->getSelectedValue());
        }
    }

    public function getLibelleRessourceObligatoire($visible, $enumeration) {
        if($visible) {
            return Atexo_Utils_Util::getLibelleEnumOuiNon($enumeration);
        }
        return Prado::localize("TRANS_CHAMP_VIDE");
    }
    private function _getTypePrestationByIdOrganisation ($dOrganisation) {
        $tOrganisation = TOrganisationQuery::create()->getOrganisationById($dOrganisation);
        return $tOrganisation->getTypePrestation();
    }
}
