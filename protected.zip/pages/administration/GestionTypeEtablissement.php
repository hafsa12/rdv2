<?php

class GestionTypeEtablissement extends AtexoPage {

    public $isActiveModuleTypeEtab = 0;

    public function onInit()
    {
        $this->Master->setCalledFrom("admin");
        Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
    }

    public function onLoad()
    {
        try {
            $this->isActiveModuleTypeEtab = Atexo_Config::getParameter('MODULE_TYPE_ETAB_' . $this->User->getCurrentOrganism());
        } catch (Exception $e) {
        }

        if(Atexo_User_CurrentUser::hasHabilitation('GestionEtablissement') && $this->isActiveModuleTypeEtab) {
            $lang = Atexo_User_CurrentUser::readFromSession("lang");
            $this->getListTypeEtab();
            $this->paneldeleteFail->style="display:none";
            $this->paneldeleteOk->style="display:none";
        }else{
            $this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
        }
    }

    public function getListTypeEtab() {
        $lang = Atexo_User_CurrentUser::readFromSession("lang");
        $adminOrg= Atexo_User_CurrentUser::isAdminOrg();

        if ( $adminOrg ) {
            $idOrg = Atexo_User_CurrentUser::getIdOrganisationGere ();

            $tTypeEtabPeer = new TTypeEtabPeer();
            $listTypeEtab = $tTypeEtabPeer->getTypeEtab($lang, $idOrg);
            $this->listTypeEtab->DataSource = $listTypeEtab;
            $this->listTypeEtab->DataBind();
        }
    }

    public function getLibelleNiveauDecoupage($idNiveau)
    {
        $NIVEAU = array(
            '0' => Prado::localize('NIVEAU_0'),
            '1' => Prado::localize('NIVEAU_1'),
            '2' => Prado::localize('NIVEAU_2'),
            '3' => Prado::localize('NIVEAU_3')
        );
        return $NIVEAU[$idNiveau];
    }

    public function onConfirmSuppressionClick($sender,$param) {

        $idTypeEtab = $this->typeEtabToDeleteHidden->Value;
        $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
        $tTypeEtab = TTypeEtabQuery::create()->filterByIdTypeEtab($idTypeEtab)->filterByIdOrganisation($idOrganisation)->findOne();

        $etablissementGestion = new TEtablissementQuery();
        $tabEtab = $etablissementGestion->findByIdTypeEtab($idTypeEtab);

        if($tTypeEtab instanceof TTypeEtab) {
            if (count($tabEtab)==0) {
                $connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
                $connexion->beginTransaction();
                $tTraductionLibelle = $tTypeEtab->getTTraductionRelatedByCodeLibelle();
                $tTraductionLibelleEtab = $tTypeEtab->getTTraductionRelatedByCodeLibelleEtab();
                $tTypeEtab->delete($connexion);
                $tTraductionLibelle->deleteAll($connexion);
                $tTraductionLibelleEtab->deleteAll($connexion);
                $connexion->commit();

                $this->paneldeleteFail->style="display:none";
                $this->paneldeleteOk->style="display:block";
            }
            else {
                $this->paneldeleteOk->style="display:none";
                $this->paneldeleteFail->style="display:block";
            }
        }

        $this->getListTypeEtab();
        $this->typeEtabPanel->render($param->NewWriter);
    }
}
