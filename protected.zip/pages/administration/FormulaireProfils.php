<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class FormulaireProfils extends AtexoPage
{
	private $_dataLibelle = null;
	protected $affichageHabilitations = array (
		"0" => array ( // Au cas "Selectionnez", n'afficher aucune habilitation
			"habilitationOrganisation" => false,
			"habilitationEtabissement" => false,
			"habilitationProfil" =>false,
			"habilitationUtilisateur" => false,
			"habilitationRefPrestation" => false,
			"habilitaionParamPrestation" => false,
			"habilitationNiveau1" => false,
			"habilitationRefTypePrestation" => false,
			"habilitationNiveau2" => false,
			"habilitationNiveau3" => false,
			"habilitationModifDureeRdv" => false,
			"habilitationJoursFeries" => false,
			"habilitationJoursIndisponibilite" => false,
			"habilitationVisualiserRdv" => false,
			"habilitationGererRendezVous" => false,
			"habilitationRechercheEtendue" => false,
			"habilitationRapportNbrRdv" => false,
			"habilitationRapportDelaiObtention" => false,
			"habilitationRapportActivite" => false,
			"habilitationPerformanceGlobale" => false,
			"habilitationAlerteHebdomadaire" => false,
			"habilitationAlerteMensuelle" => false,
			"habilitationAffectationRdv" => false,
			"habilitationAnnulationRdv" => false,
		),

		"1" => array ( // administrateur systeme
			"habilitationOrganisation" => true,
			"habilitationEtabissement" => false,
			"habilitationProfil" => true,
			"habilitationUtilisateur" => true,
			"habilitationRefPrestation" => false,
			"habilitaionParamPrestation" => false,
			"habilitationNiveau1" => false,
			"habilitationRefTypePrestation" => false,
			"habilitationNiveau2" => false,
			"habilitationNiveau3" => false,
			"habilitationModifDureeRdv" => false,
			"habilitationJoursFeries" => false,
			"habilitationJoursIndisponibilite" => false,
			"habilitationVisualiserRdv" => false,
			"habilitationGererRendezVous" => false,
			"habilitationRechercheEtendue" => false,
			"habilitationRapportNbrRdv" => false,
			"habilitationRapportDelaiObtention" => false,
			"habilitationRapportActivite" => false,
			"habilitationPerformanceGlobale" => false,
			"habilitationAlerteHebdomadaire" => false,
			"habilitationAlerteMensuelle" => false,
			"habilitationAffectationRdv" => false,
            "habilitationAnnulationRdv" => false,
        ),
		"2" => array ( // administrateur organisation
			"habilitationOrganisation" => false,
			"habilitationEtabissement" => true,
			"habilitationProfil" => true,
			"habilitationUtilisateur" => true,
			"habilitationRefPrestation" => true,
			"habilitaionParamPrestation" => true,
			"habilitationNiveau1" => true,
			"habilitationRefTypePrestation" => true,
			"habilitationNiveau2" => true,
			"habilitationNiveau3" => true,
			"habilitationModifDureeRdv" => true,
			"habilitationJoursFeries" => true,
			"habilitationJoursIndisponibilite" => true,
			"habilitationVisualiserRdv" => true,
			"habilitationGererRendezVous" => true,
			"habilitationRechercheEtendue" => true,
			"habilitationRapportNbrRdv" => true,
			"habilitationRapportDelaiObtention" => true,
			"habilitationRapportActivite" => true,
			"habilitationPerformanceGlobale" => true,
			"habilitationAlerteHebdomadaire" => true,
			"habilitationAlerteMensuelle" => true,
			"habilitationAffectationRdv" => true,
            "habilitationAnnulationRdv" => true,

        ),
		"3" => array ( // administrateur etablissement
			"habilitationOrganisation" => false,
			"habilitationEtabissement" => false,
			"habilitationProfil" => false,
			"habilitationUtilisateur" => true,
			"habilitationRefPrestation" => true,
			"habilitaionParamPrestation" => false,
			"habilitationNiveau1" => true,
			"habilitationRefTypePrestation" => true,
			"habilitationNiveau2" => true,
			"habilitationNiveau3" => true,
			"habilitationModifDureeRdv" => true,
			"habilitationJoursFeries" => true,
			"habilitationJoursIndisponibilite" => true,
			"habilitationVisualiserRdv" => true,
			"habilitationGererRendezVous" => true,
			"habilitationRechercheEtendue" => true,
			"habilitationRapportNbrRdv" => true,
			"habilitationRapportDelaiObtention" => true,
			"habilitationRapportActivite" => true,
			"habilitationPerformanceGlobale" => true,
			"habilitationAlerteHebdomadaire" => true,
			"habilitationAlerteMensuelle" => true,
			"habilitationAffectationRdv" => true,
            "habilitationAnnulationRdv" => true,

        ),
        "7" => array ( // ressource
            "habilitationOrganisation" => false,
            "habilitationEtabissement" => false,
            "habilitationProfil" => false,
            "habilitationUtilisateur" => false,
            "habilitationRefPrestation" => false,
            "habilitaionParamPrestation" => false,
            "habilitationNiveau1" => false,
            "habilitationRefTypePrestation" => false,
            "habilitationNiveau2" => false,
            "habilitationNiveau3" => true,
            "habilitationModifDureeRdv" => false,
            "habilitationJoursFeries" => false,
            "habilitationJoursIndisponibilite" => true,
            "habilitationVisualiserRdv" => true,
            "habilitationGererRendezVous" => true,
            "habilitationRechercheEtendue" => true,
            "habilitationRapportNbrRdv" => false,
            "habilitationRapportDelaiObtention" => false,
            "habilitationRapportActivite" => false,
            "habilitationPerformanceGlobale" => false,
            "habilitationAlerteHebdomadaire" => false,
            "habilitationAlerteMensuelle" => false,
            "habilitationAffectationRdv" => true,
            "habilitationAnnulationRdv" => true,

        ),
	);

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionProfils')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack)
		{
            $adminOrg = Atexo_User_CurrentUser::isAdminOrg();
            $adminEtab = Atexo_User_CurrentUser::isAdminEtab();

            $this->loadOrganisation();

            if($adminOrg) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
                $this->listeOrganisation->SelectedValue=$idOrganisation;
                $this->listeOrganisation->Enabled=false;
            }

            if($adminEtab) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
                $this->listeOrganisation->SelectedValue=$idOrganisation;
                $this->listeOrganisation->Enabled=false;
            }

			if(isset($_GET["idProfil"])) {
				$this->remplir($_GET["idProfil"]);
			}
			$this->getListeLibelleProfilParLangues($this->_dataLibelle);
			$this->remplirListeTypeProfil();
			$this->gererAffichageHabilitations();
		}
	}

	public function remplirListeTypeProfil() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$profilGestion = new Atexo_Profil_Gestion();
		$this->typeProfil->DataSource = $profilGestion->getAllPossibleTypeProfilByConnected($lang, Prado::localize('SELECTIONNEZ'));
		$this->typeProfil->DataBind();
	}

	public function getListeLibelleProfilParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeLibelleParLangues($data);
		} else {
			//recupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['libelleProfil'] = '';
				$data[$index]['libelleChampLang'] = Prado::localize('NOM_PROFIL');
				$data[$index]['libelleLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['lang'] = $lan;
				$index++;
			}
			$this->setListeLibelleParLangues($data);
		}
	}

	public function setListeLibelleParLangues($data) {
		$this->listeLibellesProfilsLangues->dataSource = $data;
		$this->listeLibellesProfilsLangues->dataBind();
		$index = 0;
		foreach ($this->listeLibellesProfilsLangues->getItems() as $item) {
			$item->libelleChampLang->Text = $data[$index]['libelleChampLang'];
			$item->libelleProfil->Text = $data[$index]['libelleProfil'];
			$item->libelleLang->Text = $data[$index]['libelleLang'];
			$item->lang->Value = $data[$index]['lang'];
			$index++;
		}
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$data = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'), true);
		$this->listeOrganisation->DataSource = $data;
		$this->listeOrganisation->DataBind();
	}

	/**
	 * Validation du formulaire 'mon compte'/gestion utilisateurs coté agent
	 */
	public function onValiderClick()
	{
		$tProfilQuery = new TProfilQuery();
		$tProfil = $tProfilQuery->getProfilById($_GET["idProfil"]);
		$tTraduction = new TTraduction();

		if($tProfil!=null) {
			$tTraduction = $tProfil->getTTraduction();
			if($tTraduction instanceof TTraduction) {
				foreach($this->listeLibellesProfilsLangues->getItems() as $item) {
					$tTraductionLibelleQuery = new TTraductionLibelleQuery();
					$tTraductionLibelle = $tTraductionLibelleQuery->getTraductionLibelleById($tTraduction->getIdTraduction(), $item->lang->Value);

					if($tTraductionLibelle instanceof TTraductionLibelle) {
						$tTraductionLibelle->setLibelle($item->libelleProfil->SafeText);
						$tTraductionLibelle->save();
					}
					else {//Si le profil n'a pas de libelle saisi dans une des langues
						$tTraductionLibelle = new TTraductionLibelle();
						$tTraductionLibelle->setIdTraduction($tTraduction->getIdTraduction());
						$tTraductionLibelle->setLang($item->lang->Value);
						$tTraductionLibelle->setLibelle($item->libelleProfil->SafeText);
						$tTraductionLibelle->save();
					}
				}
			} else {//Si le profil existe sans libelle
				$tTraduction = new TTraduction();
				foreach($this->listeLibellesProfilsLangues->getItems() as $item) {
					$tTraductionLibelle = new TTraductionLibelle();
					$tTraductionLibelle->setLang($item->lang->Value);
					$tTraductionLibelle->setLibelle($item->libelleProfil->SafeText);
					$tTraduction->addTTraductionLibelle($tTraductionLibelle);
				}
				$tProfil->setTTraduction($tTraduction);
			}
		} else {
			$tProfil = new TProfil();
			//Céation du libelle profil
			foreach($this->listeLibellesProfilsLangues->getItems() as $item) {
				$tTraductionLibelle = new TTraductionLibelle();
				$tTraductionLibelle->setLang($item->lang->Value);
				$tTraductionLibelle->setLibelle($item->libelleProfil->SafeText);
				$tTraduction->addTTraductionLibelle($tTraductionLibelle);
			}
			$tProfil->setTTraduction($tTraduction);
		}
		$idTypeProfil = $this->typeProfil->getSelectedValue();
        $tProfil->setIdOrganisation ( $this->listeOrganisation->getSelectedValue() );
		$tProfil->setIdTypeProfil($idTypeProfil);
		$arrayHabilitation = $this->affichageHabilitations[$idTypeProfil];

		$tProfil->setOrganisation((int) ($arrayHabilitation["habilitationOrganisation"] ? $this->habilitationOrganisation->Checked : 0));
		$tProfil->setEtablissement((int) ($arrayHabilitation["habilitationEtabissement"] ? $this->habilitationEtabissement->Checked : 0));
		$tProfil->setProfils((int) ($arrayHabilitation["habilitationProfil"] ? $this->habilitationProfil->Checked : 0));
		$tProfil->setUtilisateurs((int) ($arrayHabilitation["habilitationUtilisateur"] ? $this->habilitationUtilisateur->Checked : 0));
		$tProfil->setReferentielPrestation((int) ($arrayHabilitation["habilitationRefPrestation"] ? $this->habilitationRefPrestation->Checked : 0));
		$tProfil->setParametragePrestation((int) ($arrayHabilitation["habilitaionParamPrestation"] ? $this->habilitaionParamPrestation->Checked : 0));
		$tProfil->setNiveau1((int) ($arrayHabilitation["habilitationNiveau1"] ? $this->habilitationNiveau1->Checked : 0));
		$tProfil->setReferentielTypePrestation((int) ($arrayHabilitation["habilitationRefTypePrestation"] ? $this->habilitationRefTypePrestation->Checked : 0));
		$tProfil->setNiveau2((int) ($arrayHabilitation["habilitationNiveau2"] ? $this->habilitationNiveau2->Checked : 0));
		$tProfil->setNiveau3((int) ($arrayHabilitation["habilitationNiveau3"] ? $this->habilitationNiveau3->Checked : 0));
		$tProfil->setJoursFeries((int) ($arrayHabilitation["habilitationJoursFeries"] ? $this->habilitationJoursFeries->Checked : 0));
		$tProfil->setJoursIndisponibilites((int) ($arrayHabilitation["habilitationJoursIndisponibilite"] ? $this->habilitationJoursIndisponibilite->Checked : 0));
		$tProfil->setAgenda((int) ($arrayHabilitation["habilitationVisualiserRdv"] ? $this->habilitationVisualiserRdv->Checked : 0));
		$tProfil->setRapportNbrRdv((int) ($arrayHabilitation["habilitationRapportNbrRdv"] ? $this->habilitationRapportNbrRdv->Checked : 0));
		$tProfil->setRapportDelaiObtention((int) ($arrayHabilitation["habilitationRapportDelaiObtention"] ? $this->habilitationRapportDelaiObtention->Checked : 0));
		$tProfil->setRapportActivite((int) ($arrayHabilitation["habilitationRapportActivite"] ? $this->habilitationRapportActivite->Checked : 0));
		$tProfil->setPerformanceGlobale((int) ($arrayHabilitation["habilitationPerformanceGlobale"] ? $this->habilitationPerformanceGlobale->Checked : 0));
		$tProfil->setGestionsDesRendezVous((int) ($arrayHabilitation["habilitationGererRendezVous"] ? $this->habilitationGererRendezVous->Checked : 0));
		$tProfil->setRechercheEtendueRdv((int) ($arrayHabilitation["habilitationRechercheEtendue"] ? $this->habilitationRechercheEtendue->Checked : 0));
		$tProfil->setAlertRapportHebdo((int) ($arrayHabilitation["habilitationAlerteHebdomadaire"] ? $this->habilitationAlerteHebdomadaire->Checked : 0));
		$tProfil->setAlertRapportMens((int) ($arrayHabilitation["habilitationAlerteMensuelle"] ? $this->habilitationAlerteMensuelle->Checked : 0));
		$tProfil->setModifDureeRdv((int) ($arrayHabilitation["habilitationModifDureeRdv"] ? $this->habilitationModifDureeRdv->Checked : 0));
		$tProfil->setAffectationRdv((int) ($arrayHabilitation["habilitationAffectationRdv"] ? $this->habilitationAffectationRdv->Checked : 0));
		$tProfil->setAnnulationRdv((int) ($arrayHabilitation["habilitationAnnulationRdv"] ? $this->habilitationAnnulationRdv->Checked : 0));

		$tProfil->save();
		$this->response->redirect("?page=administration.GestionProfils&search");
	}

	public function remplir($idProfil) {
		$tProfilQuery = new TProfilQuery();
		$tProfil = $tProfilQuery->getProfilById($idProfil);
		if ($tProfil instanceof TProfil) {
			$this->typeProfil->setSelectedValue($tProfil->getIdTypeProfil());
			$this->listeOrganisation->setSelectedValue($tProfil->getIdOrganisation());
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataLibelle[$index]['libelleProfil'] = $tProfil->getLibelleProfilTraduit($lan);
				$this->_dataLibelle[$index]['libelleChampLang'] = Prado::localize('NOM_PROFIL');
				$this->_dataLibelle[$index]['libelleLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataLibelle[$index]['lang'] = $lan;
				$index++;
			}
			$index=0;
			$this->habilitationOrganisation->Checked = ($tProfil->getOrganisation() == '1');
			$this->habilitationEtabissement->Checked = ($tProfil->getEtablissement() == '1');
			$this->habilitationProfil->Checked = ($tProfil->getProfils() == '1');
			$this->habilitationUtilisateur->Checked = ($tProfil->getUtilisateurs() == '1');
			$this->habilitationRefPrestation->Checked = ($tProfil->getReferentielPrestation() == '1');
			$this->habilitaionParamPrestation->Checked = ($tProfil->getParametragePrestation() == '1');
			$this->habilitationNiveau1->Checked = ($tProfil->getNiveau1() == '1');
			$this->habilitationRefTypePrestation->Checked = ($tProfil->getReferentielTypePrestation() == '1');
			$this->habilitationNiveau2->Checked = ($tProfil->getNiveau2() == '1');
			$this->habilitationNiveau3->Checked = ($tProfil->getNiveau3() == '1');
			$this->habilitationJoursFeries->Checked = ($tProfil->getJoursFeries() == '1');
			$this->habilitationJoursIndisponibilite->Checked = ($tProfil->getJoursIndisponibilites() == '1');
			$this->habilitationVisualiserRdv->Checked = ($tProfil->getAgenda() == '1');
			$this->habilitationGererRendezVous->Checked = ($tProfil->getGestionsDesRendezVous() == '1');
			$this->habilitationRapportNbrRdv->Checked = ($tProfil->getRapportNbrRdv() == '1');
			$this->habilitationRapportDelaiObtention->Checked = ($tProfil->getRapportDelaiObtention() == '1');
			$this->habilitationRapportActivite->Checked = ($tProfil->getRapportActivite() == '1');
			$this->habilitationPerformanceGlobale->Checked = ($tProfil->getPerformanceGlobale() == '1');
			$this->habilitationRechercheEtendue->Checked = ($tProfil->getRechercheEtendueRdv() == '1');
			$this->habilitationAlerteHebdomadaire->Checked = ($tProfil->getAlertRapportHebdo() == '1');
			$this->habilitationAlerteMensuelle->Checked = ($tProfil->getAlertRapportMens() == '1');
			$this->habilitationModifDureeRdv->Checked = ($tProfil->getModifDureeRdv() == '1');
			$this->habilitationAffectationRdv->Checked = ($tProfil->getAffectationRdv() == '1');
			$this->habilitationAnnulationRdv->Checked = ($tProfil->getAnnulationRdv() == '1');
		}
	}

	protected function refreshProfils ($sender, $param) {
		$this->gererAffichageHabilitations();
		$this->panelHabilitations->render($param->getNewWriter());
	}
	protected function gererAffichageHabilitations() {
		$idTypeProfil = (int)$this->typeProfil->getSelectedValue();
		if(isset($this->affichageHabilitations[$idTypeProfil])) {
			foreach ($this->affichageHabilitations[$idTypeProfil] as $id => $visible) {
				$this->$id->Visible = $visible;
			}
		}
	}

	protected function retour ()
	{
		if($this->getCalledPage() == Atexo_Config::getParameter('MENU_MON_COMPTE') || $this->getCalledPage() == Atexo_Config::getParameter('MENU_ORGANISME_MON_COMPTE') ) // depuis lien [Mon Compte]
		{
			if(Atexo_User_CurrentUser::isAgent())
			{
				$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=agent.Accueil'));
			}else{
				$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=organisme.Accueil'));
			}
		}elseif($this->idReferentRegion && $this->getCalledPage() == Atexo_Config::getParameter('MENU_UTILISATEUR')){
			$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=agent.RechercheUtilisateur&retourRecherche=1'));
		}elseif(!$this->idReferentRegion && $this->getCalledPage() == Atexo_Config::getParameter('MENU_UTILISATEUR')){
			$this->response->redirect(Atexo_Utils_UrlProtector::protectUrl('?page=agent.Accueil'));
		}
	}

	protected function visibiliteGestionStructures() {
		return (	$this->habilitationOrganisation->getVisible()
					|| $this->habilitationEtabissement->getVisible()
				) ? 'block':'none';
	}
	protected function visibiliteGestionRoles() {
		return (	$this->habilitationProfil->getVisible()
					|| $this->habilitationUtilisateur->getVisible()
				) ? 'block':'none';
	}
	protected function visibiliteGestionPrestations() {
		return (	$this->habilitationRefPrestation->getVisible()
					|| $this->habilitationNiveau1->getVisible()
					|| $this->habilitationNiveau2->getVisible()
					|| $this->habilitationNiveau3->getVisible()
					|| $this->habilitationModifDureeRdv->getVisible()
				) ? 'block':'none';
	}
	protected function visibiliteGestionAgenda() {
		return (	$this->habilitationJoursFeries->getVisible()
					|| $this->habilitationJoursIndisponibilite->getVisible()
				) ? 'block':'none';
	}
	protected function visibiliteGestionRDV() {
		return (	$this->habilitationVisualiserRdv->getVisible()
					|| $this->habilitationGererRendezVous->getVisible()
					|| $this->habilitationRechercheEtendue->getVisible()
				) ? 'block':'none';
	}
	protected function visibiliteGestionRapports() {
		return (	$this->habilitationRapportNbrRdv->getVisible()
					|| $this->habilitationRapportDelaiObtention->getVisible()
				) ? 'block':'none';
	}
}