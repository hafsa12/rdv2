<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerChampSupp extends AtexoPage {

	protected $_dataLibelle = array();

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionRefPrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {
			$this->loadTypeChamps();

			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();

			$this->loadOrganisation();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}

			if(isset($_GET["idChampSupp"])) {
				$this->remplir($_GET["idChampSupp"]);
			}

			self::getListeLibelleParLangues($this->_dataLibelle);
		}
	}

	public function loadTypeChamps() {

		$this->typeChamp->DataSource = array(
			" " => Prado::localize('SELECTIONNEZ'),
			"TEXT" => Prado::localize('TEXT'),
			"LONGTEXT" => Prado::localize('LONGTEXT'),
			"NUMERIC" => Prado::localize('NUMERIC'),
			"LISTE" => Prado::localize('LISTE'),
			"MULTICHOIX" => Prado::localize('MULTICHOIX')
		);
		$this->typeChamp->DataBind();
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}
	/**
	 * enregistrer les informations de référentiel prestation
	 */
	public function enregistrer() {

		if(isset($_GET["idChampSupp"])) {
			$tChampsSuppQuery = new TChampsSuppQuery();
			$tChampsSupp = $tChampsSuppQuery->getChampSuppById($_GET["idChampSupp"]);

			if(!$tChampsSupp) {
				$tChampsSupp = new TChampsSupp();
			}
		}

		if(!($tChampsSupp instanceof TChampsSupp)) {
			$tChampsSupp = new TChampsSupp();
		}
		$tChampsSupp->setIdOrganisation($this->listeOrganisation->SelectedValue);
		if($this->ouiChamps->checked){
			$tChampsSupp->setObligatoire('1');
		}
		else{
			$tChampsSupp->setObligatoire('0');
		}
		$tChampsSupp->setCodeChamps($this->codeChamps->SafeText);
		$tTraductionChamps = $tChampsSupp->getTTraduction();
		foreach ($this->listeChampsLangues->getItems() as $item) {
			if(!isset($tTraductionChamps)) {
				$tTraductionChamps = new TTraduction();
			}
			$tTraductionLibelle = $tTraductionChamps->getTTraductionLibelle($item->langLibelle->Value);
			$tTraductionLibelle->setLang($item->langLibelle->Value);
			$tTraductionLibelle->setLibelle($item->libelle->SafeText);
			$tTraductionChamps->addTTraductionLibelle($tTraductionLibelle);
			$tTraductionChamps->save();
		}
		$tChampsSupp->setTTraduction($tTraductionChamps);
		$tChampsSupp->setChampsType($this->typeChamp->SelectedValue);
		if($this->typeChamp->SelectedValue == "LISTE" || $this->typeChamp->SelectedValue == "MULTICHOIX") {
			$valeurs = json_encode(array("fr"=>$this->listeValuesFr->Value,"ar"=>$this->listeValuesAr->Value));
			$tChampsSupp->setValueListe($valeurs);
		}
		else {
			$tChampsSupp->setValueListe(null);
		}
		$tChampsSupp->save();

		$url = "index.php?page=administration.GestionChampsSupp&search";
		$this->response->redirect($url);
	}

	/**
	 * @param $idChampSupp
	 * récuperer les informations du TChampsSupp
	 */
	public function remplir($idChampSupp) {

		$tChampsSuppQuery = new TChampsSuppQuery();
		$tChampsSupp = $tChampsSuppQuery->getChampSuppById($idChampSupp);
		$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

		if ($tChampsSupp instanceof TChampsSupp){$index=0;
			foreach($langues as $lan){
				$this->_dataLibelle[$index]['libelle'] = $tChampsSupp->getLibelleChampsSuppTraduit($lan);
				$this->_dataLibelle[$index]['libelleLang'] = Prado::localize('LIBELLE_REFERENTIEL_PRESTATION');
				$this->_dataLibelle[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataLibelle[$index]['langLibelle'] = $lan;
				$index++;
			}
			$this->ouiChamps->checked=($tChampsSupp->getObligatoire()=='1');
			$this->nonChamps->checked=($tChampsSupp->getObligatoire()=='0');
			$this->typeChamp->SelectedValue=$tChampsSupp->getChampsType();
			$this->codeChamps->Text=$tChampsSupp->getCodeChamps();
			$liste = json_decode($tChampsSupp->getValueListe(), true);
			$this->listeValuesFr->Value=$liste["fr"];
			$this->listeValuesAr->Value=$liste["ar"];

			foreach($this->listeChampsLangues->getItems() as $itemLang){
				$tTraductionLibelle = $tChampsSupp->getTTraduction()->getTTraductionLibelle();
				$itemLang->champsLibelleLang->Text = Prado::localize('LIBELLE');
				$itemLang->lang->Text = '('.Prado::localize('LANG_'.strtoupper($tTraductionLibelle->getLang())).')';
				$itemLang->libelle->Text = $tTraductionLibelle->getLibelle();
				$itemLang->langLibelle->Value = $tTraductionLibelle->getLang();
			}
		}
	}

	/**
	 * @param $data
	 * récuperer repeater libelle du type-prestation
	 */
	public function getListeLibelleParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeLibelleParLangues($data);
		} else {
			//recupérer les langues
			$langues= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues as $lan){
				$data[$index]['libelleLang'] = Prado::localize('LIBELLE');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['libelle'] = '';
				$data[$index]['langLibelle'] = $lan;
				$index++;
			}
			$this->setListeLibelleParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater libelle du type-prestation
	 */
	public function setListeLibelleParLangues($data) {
		$this->listeChampsLangues->dataSource = $data;
		$this->listeChampsLangues->dataBind();
		$index = 0;
		foreach ($this->listeChampsLangues->getItems() as $item) {
			$item->libelleLang->Text = $data[$index]['libelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->libelle->Text = $data[$index]['libelle'];
			$item->langLibelle->Value = $data[$index]['langLibelle'];
			$index++;
		}
	}
}
