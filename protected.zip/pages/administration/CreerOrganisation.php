<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerOrganisation extends AtexoPage {

	private $_dataDenomination = null;
	private $_dataDescription = null;
	private $_dataAdresse = null;
	private $_dataTitre = null;
	private $_dataMessage = null;
	private $_dataIntituleLien1 = null;
	private $_dataIntituleLien2 = null;
	private $_dataIntituleLien3 = null;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionOrganisation')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {
			$lang = Atexo_User_CurrentUser::readFromSession("lang");
			//Remplir liste Région
			$entiteGestion = new Atexo_Entite_Gestion();
			$this->entite1->DataSource = $entiteGestion->getAllEntite(1,$lang,null,Prado::localize('ENTITE_1'));
			$this->entite1->DataBind();


			if(isset($_GET["idOrganisation"])) {
				$this->remplir($_GET["idOrganisation"]);
			}
			self::_getListeChampsParLangues();
		}
	}


	private function _getListeChampsParLangues() {
		self::getListeDenominationParLangues();
		self::getListeDescriptionParLangues();
		self::getListeAdresseParLangues();
		self::getListeTitreParLangues();
		self::getListeMessageParLangues();
		self::getListeIntituleLien1ParLangues();
        self::getListeIntituleLien2ParLangues();
        self::getListeIntituleLien3ParLangues();
	}

	/**
	 * Remplir la liste des provinces
	 */
	public function loadEntite() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite2->DataSource = $entiteGestion->getAllEntite(2,$lang,$this->entite1->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->entite2->DataBind();
	}

	/**
	 * Remplir la liste des communes
	 */
	public function loadEntite3() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite3->DataSource = $entiteGestion->getAllEntite(3,$lang,$this->entite2->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->entite3->DataBind();
	}

	/**
	 * @param $data
	 * récuperer repeater nom d'organisation
	 */
	public function getListeDenominationParLangues() {
		if(count($this->_dataDenomination) > 0) {
			$this->setListeDenominationParLangues($this->_dataDenomination);
		} else {
			//récuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['denominationLibelleLang'] = Prado::localize('DENOMINATION_ORGANISATION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['denomination'] = '';
				$data[$index]['langDenomination'] = $lan;
				$index++;
			}
			$this->setListeDenominationParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater nom d'organisation
	 */
	public function setListeDenominationParLangues($data) {
		$this->listeDenominationLangues->dataSource = $data;
		$this->listeDenominationLangues->dataBind();
		$index = 0;
		foreach ($this->listeDenominationLangues->getItems() as $item) {
			$item->denominationLibelleLang->Text = $data[$index]['denominationLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->denomination->Text = $data[$index]['denomination'];
			$item->langDenomination->Value = $data[$index]['langDenomination'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * récuperer repeater description d'organisation
	 */
	public function getListeDescriptionParLangues() {
		if(count($this->_dataDescription) > 0) {
			$this->setListeDescriptionParLangues($this->_dataDescription);
		} else {
			//récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['descriptionLibelleLang'] = Prado::localize('DESCRIPTION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['description'] = '';
				$data[$index]['langDescription'] = $lan;
				$index++;
			}
			$this->setListeDescriptionParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater description d'organisation
	 */
	public function setListeDescriptionParLangues($data) {
		$this->listeDescriptionLangues->dataSource = $data;
		$this->listeDescriptionLangues->dataBind();
		$index = 0;
		foreach ($this->listeDescriptionLangues->getItems() as $item) {
			$item->descriptionLibelleLang->Text = $data[$index]['descriptionLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->description->Text = $data[$index]['description'];
			$item->langDescription->Value = $data[$index]['langDescription'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * récuperer repeater l'adresse d'organisation
	 */
	public function getListeAdresseParLangues() {
		if(count($this->_dataAdresse) > 0) {
			$this->setListeAdresseParLangues($this->_dataAdresse);
		} else {
			//récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['adresseLibelleLang'] = Prado::localize('ADRESSE');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['adresse'] = '';
				$data[$index]['langAdresse'] = $lan;
				$index++;
			}
			$this->setListeAdresseParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater adresse d'organisation
	 */
	public function setListeAdresseParLangues($data) {
		$this->listeAdresseLangues->dataSource = $data;
		$this->listeAdresseLangues->dataBind();
		$index = 0;
		foreach ($this->listeAdresseLangues->getItems() as $item) {
			$item->adresseLibelleLang->Text = $data[$index]['adresseLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->adresse->Text = $data[$index]['adresse'];
			$item->langAdresse->Value = $data[$index]['langAdresse'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * récuperer repeater le titre de bienvenue d'organisation
	 */
	public function getListeTitreParLangues() {
		if(count($this->_dataTitre) > 0) {
			$this->setListeTitreParLangues($this->_dataTitre);
		} else {
			//récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['titreLibelleLang'] = Prado::localize('TITRE_BIENVENUE_ORGANISATION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['titre'] = '';
				$data[$index]['langTitre'] = $lan;
				$index++;
			}
			$this->setListeTitreParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater titre de bienvenue d'organisation
	 */
	public function setListeTitreParLangues($data) {
		$this->listeTitreLangues->dataSource = $data;
		$this->listeTitreLangues->dataBind();
		$index = 0;
		foreach ($this->listeTitreLangues->getItems() as $item) {
			$item->titreLibelleLang->Text = $data[$index]['titreLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->titre->Text = $data[$index]['titre'];
			$item->langTitre->Value = $data[$index]['langTitre'];
			$index++;
		}
	}



	/**
	 * @param $data
	 * récuperer repeater le message de bienvenue d'organisation
	 */
	public function getListeMessageParLangues() {
		if(count($this->_dataMessage) > 0) {
			$this->setListeMessageParLangues($this->_dataMessage);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['messageLibelleLang'] = Prado::localize('MESSAGE_BIENVENUE_ORGANISATION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['message'] = '';
				$data[$index]['langMessage'] = $lan;
				$index++;
			}
			$this->setListeMessageParLangues($data);
		}
	}

	/**
	 * @param $data
	 * récuperer repeater le message de bienvenue d'organisation
	 */
	public function getListeIntituleLien1ParLangues() {
		if(count($this->_dataIntituleLien1) > 0) {
			$this->setListeIntituleLien1ParLangues($this->_dataIntituleLien1);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['libelle'] = Prado::localize('INTITULE_LIEN1_FOOTER');
				$data[$index]['textLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['text'] = '';
				$data[$index]['lang'] = $lan;
				$index++;
			}
			$this->setListeIntituleLien1ParLangues($data);
		}
	}

	/**
	 * @param $data
	 * récuperer repeater le message de bienvenue d'organisation
	 */
	public function getListeIntituleLien2ParLangues() {
		if(count($this->_dataIntituleLien2) > 0) {
			$this->setListeIntituleLien2ParLangues($this->_dataIntituleLien2);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['libelle'] = Prado::localize('INTITULE_LIEN2_FOOTER');
				$data[$index]['textLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['text'] = '';
				$data[$index]['lang'] = $lan;
				$index++;
			}
			$this->setListeIntituleLien2ParLangues($data);
		}
	}

	/**
	 * @param $data
	 * récuperer repeater le message de bienvenue d'organisation
	 */
	public function getListeIntituleLien3ParLangues() {
		if(count($this->_dataIntituleLien3) > 0) {
			$this->setListeIntituleLien3ParLangues($this->_dataIntituleLien3);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['libelle'] = Prado::localize('INTITULE_LIEN3_FOOTER');
				$data[$index]['textLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['text'] = '';
				$data[$index]['lang'] = $lan;
				$index++;
			}
			$this->setListeIntituleLien3ParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater message de bienvenue d'organisation
	 */
	public function setListeMessageParLangues($data) {
		$this->listeMessageLangues->dataSource = $data;
		$this->listeMessageLangues->dataBind();
		$index = 0;
		foreach ($this->listeMessageLangues->getItems() as $item) {
			$item->messageLibelleLang->Text = $data[$index]['messageLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->message->Text = $data[$index]['message'];
			$item->langMessage->Value = $data[$index]['langMessage'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * remplir repeater lien1 du footer
	 */
	public function setListeIntituleLien1ParLangues($data) {
		$this->listeIntituleLien1Langues->dataSource = $data;
		$this->listeIntituleLien1Langues->dataBind();
		$index = 0;
		foreach ($this->listeIntituleLien1Langues->getItems() as $item) {
			$item->libelle->Text = $data[$index]['libelle'];
			$item->textLang->Text = $data[$index]['textLang'];
			$item->text->Text = $data[$index]['text'];
			$item->lang->Value = $data[$index]['lang'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * remplir repeater lien1 du footer
	 */
	public function setListeIntituleLien2ParLangues($data) {
		$this->listeIntituleLien2Langues->dataSource = $data;
		$this->listeIntituleLien2Langues->dataBind();
		$index = 0;
		foreach ($this->listeIntituleLien2Langues->getItems() as $item) {
			$item->libelle->Text = $data[$index]['libelle'];
			$item->textLang->Text = $data[$index]['textLang'];
			$item->text->Text = $data[$index]['text'];
			$item->lang->Value = $data[$index]['lang'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * remplir repeater lien1 du footer
	 */
	public function setListeIntituleLien3ParLangues($data) {
		$this->listeIntituleLien3Langues->dataSource = $data;
		$this->listeIntituleLien3Langues->dataBind();
		$index = 0;
		foreach ($this->listeIntituleLien3Langues->getItems() as $item) {
			$item->libelle->Text = $data[$index]['libelle'];
			$item->textLang->Text = $data[$index]['textLang'];
			$item->text->Text = $data[$index]['text'];
			$item->lang->Value = $data[$index]['lang'];
			$index++;
		}
	}

	/**
	 * enregistrer les informations d'organisation
	 */
	public function enregistrer() {

		if(isset($_GET["idOrganisation"])) {
			$tOrganisationQuery = new TOrganisationQuery();
			$tOrganisation = $tOrganisationQuery->getOrganisationById($_GET["idOrganisation"]);

			$tTraductionDenomination = $tOrganisation->getTTraductionRelatedByCodeDenominationOrganisation();
			$tTraductionDescription = $tOrganisation->getTTraductionRelatedByCodeDescriptionOrganisation();
			$tTraductionAdresse = $tOrganisation->getTTraductionRelatedByCodeAdresseOrganisation();
			$tTraductionTitre = $tOrganisation->getTTraductionRelatedByCodeTitreBienvenue();
			$tTraductionMessage = $tOrganisation->getTTraductionRelatedByCodeMessageBienvenue();
            $tTraductionLien1 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien1();
			$tTraductionLien2 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien2();
			$tTraductionLien3 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien3();
		}

		if(!($tOrganisation instanceof TOrganisation)) {
			$tOrganisation = new TOrganisation();

			$tTraductionDenomination = new TTraduction();
			$tTraductionDescription = new TTraduction();
			$tTraductionAdresse = new TTraduction();
			$tTraductionTitre = new TTraduction();
			$tTraductionMessage = new TTraduction();
			$tTraductionLien1 = new TTraduction();
			$tTraductionLien2 = new TTraduction();
			$tTraductionLien3 = new TTraduction();
		}

		//boucle
		foreach($this->listeDenominationLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionDenomination->getTTraductionLibelle($item->langDenomination->Value);
			$tTraductionLibelle->setLang($item->langDenomination->Value);
			$tTraductionLibelle->setLibelle($item->denomination->SafeText);
			$tTraductionDenomination->addTTraductionLibelle($tTraductionLibelle);
		}
		foreach($this->listeDescriptionLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionDescription->getTTraductionLibelle($item->langDescription->Value);
			$tTraductionLibelle->setLang($item->langDescription->Value);
			$tTraductionLibelle->setLibelle($item->description->SafeText);
			$tTraductionDescription->addTTraductionLibelle($tTraductionLibelle);
		}
		foreach($this->listeAdresseLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionAdresse->getTTraductionLibelle($item->langAdresse->Value);
			$tTraductionLibelle->setLang($item->langAdresse->Value);
			$tTraductionLibelle->setLibelle($item->adresse->SafeText);
			$tTraductionAdresse->addTTraductionLibelle($tTraductionLibelle);
		}
		foreach($this->listeTitreLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionTitre->getTTraductionLibelle($item->langTitre->Value);
			$tTraductionLibelle->setLang($item->langTitre->Value);
			$tTraductionLibelle->setLibelle($item->titre->SafeText);
			$tTraductionTitre->addTTraductionLibelle($tTraductionLibelle);
		}
		foreach($this->listeMessageLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionMessage->getTTraductionLibelle($item->langMessage->Value);
			$tTraductionLibelle->setLang($item->langMessage->Value);
			$tTraductionLibelle->setLibelle($item->message->SafeText);
			$tTraductionMessage->addTTraductionLibelle($tTraductionLibelle);
		}
        foreach($this->listeIntituleLien1Langues->getItems() as $item) {
			if( ! $tTraductionLien1 instanceof TTraduction ) {
				$tTraductionLien1 = new TTraduction();
			}
			$tTraductionLibelle = $tTraductionLien1->getTTraductionLibelle($item->lang->Value);
			$tTraductionLibelle->setLang($item->lang->Value);
			$tTraductionLibelle->setLibelle($item->text->SafeText);
			$tTraductionLien1->addTTraductionLibelle($tTraductionLibelle);
        }
        foreach($this->listeIntituleLien2Langues->getItems() as $item) {
			$tTraductionLien2 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien2();
			if( ! $tTraductionLien2 instanceof TTraduction ) {
				$tTraductionLien2 = new TTraduction();
			}
			$tTraductionLibelle = $tTraductionLien2->getTTraductionLibelle ( $item->lang->Value );
			$tTraductionLibelle->setLang ( $item->lang->Value );
			$tTraductionLibelle->setLibelle ( $item->text->SafeText );
			$tTraductionLien2->addTTraductionLibelle ( $tTraductionLibelle );
        }
        foreach($this->listeIntituleLien3Langues->getItems() as $item) {
			$tTraductionLien3 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien3();
			if( ! $tTraductionLien3 instanceof TTraduction ) {
				$tTraductionLien3 = new TTraduction();
			}
			$tTraductionLibelle = $tTraductionLien3->getTTraductionLibelle ( $item->lang->Value );
			$tTraductionLibelle->setLang ( $item->lang->Value );
			$tTraductionLibelle->setLibelle ( $item->text->SafeText );
			$tTraductionLien3->addTTraductionLibelle ( $tTraductionLibelle );
        }
		//fin
		$tOrganisation->setTTraductionRelatedByCodeDenominationOrganisation($tTraductionDenomination);
		$tOrganisation->setTTraductionRelatedByCodeDescriptionOrganisation($tTraductionDescription);
		$tOrganisation->setTTraductionRelatedByCodeAdresseOrganisation($tTraductionAdresse);
		$tOrganisation->setTTraductionRelatedByCodeTitreBienvenue($tTraductionTitre);
		$tOrganisation->setTTraductionRelatedByCodeMessageBienvenue($tTraductionMessage);
        $tOrganisation->setTTraductionRelatedByCodeLibelleLien1($tTraductionLien1);
        $tOrganisation->setTTraductionRelatedByCodeLibelleLien2($tTraductionLien2);
        $tOrganisation->setTTraductionRelatedByCodeLibelleLien3($tTraductionLien3);
        $tOrganisation->setUrlLien1($this->lien1->SafeText);
        $tOrganisation->setUrlLien2($this->lien2->SafeText);
		$tOrganisation->setUrlLien3($this->lien3->SafeText);
		$tOrganisation->setAcronyme($this->acronyme->SafeText);
		$tOrganisation->setNomDomaine($this->nomDomaine->SafeText);

		if($this->inputTelephone1->SafeText != null) {
			$tOrganisation->setTelephoneOrganisation($this->inputTelephone->SafeText." , ".$this->inputTelephone1->SafeText);
		}
		else {
			$tOrganisation->setTelephoneOrganisation($this->inputTelephone->SafeText);
		}
		$tOrganisation->setMailOrganisation($this->inputEmail->SafeText);
		$tOrganisation->setIdEntite($this->entite3->getSelectedValue());
		$tOrganisation->setCodePostal($this->inputCP->SafeText);

		$tOrganisation->setTypePrestation((int)(!$this->saisieLibre->checked));
		$tOrganisation->setRessource((int)(!$this->parNom->checked));

		$tOrganisation->save();
		$url = "index.php?page=administration.GestionOrganisations";
		$this->response->redirect($url);
	}

	/**
	 * @param $idEtablissement
	 * récuperer les informations d'organisation
	 */
	public function remplir($idOrganisation) {

		$tOrganisationQuery = new TOrganisationQuery();
		$tOrganisation = $tOrganisationQuery->getOrganisationById($idOrganisation);

		if ($tOrganisation instanceof TOrganisation){

			$tel = explode(" , ",$tOrganisation->getTelephoneOrganisation());

			$tEntiteQuery = new TEntiteQuery();
			$tEntite = $tEntiteQuery->getEntiteById($tOrganisation->getIdEntite());
			$tEntiteQuery = new TEntiteQuery();
			$tEntiteParent = $tEntiteQuery->getEntiteById($tEntite->getIdEntiteParent());
			$this->entite1->SelectedValue = $tEntiteParent->getIdEntiteParent();
			$this->loadEntite();
			$this->entite2->SelectedValue = $tEntite->getIdEntiteParent();
			$this->loadEntite3();
			$this->entite3->SelectedValue = $tOrganisation->getIdEntite();

			$this->inputTelephone->setText($tel[0]);
			$this->inputTelephone1->setText($tel[1]);
			$this->inputEmail->setText($tOrganisation->getMailOrganisation());
			$this->inputCP->setText($tOrganisation->getCodePostal());
				
			$this->saisieLibre->checked = ($tOrganisation->getTypePrestation()=="0");
			$this->refPrestation->checked = ($tOrganisation->getTypePrestation()=="1");

			$this->parNom->checked = ($tOrganisation->getRessource()=="0");
			$this->parCode->checked = ($tOrganisation->getRessource()=="1");

			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataDenomination[$index]['denomination'] = $tOrganisation->getDenominationTraduit($lan);
				$this->_dataDenomination[$index]['denominationLibelleLang'] = Prado::localize('DENOMINATION_ORGANISATION');
				$this->_dataDenomination[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataDenomination[$index]['langDenomination'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataDescription[$index]['description'] = $tOrganisation->getDescriptionTraduit($lan);
				$this->_dataDescription[$index]['descriptionLibelleLang'] = Prado::localize('DESCRIPTION');
				$this->_dataDescription[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataDescription[$index]['langDescription'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataAdresse[$index]['adresse'] = $tOrganisation->getAdresseTraduit($lan);
				$this->_dataAdresse[$index]['adresseLibelleLang'] = Prado::localize('ADRESSE');
				$this->_dataAdresse[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataAdresse[$index]['langAdresse'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataTitre[$index]['titreLibelleLang'] = Prado::localize('TITRE_BIENVENUE_ORGANISATION');
				$this->_dataTitre[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataTitre[$index]['titre'] = $tOrganisation->getTitreBienvenueTraduit($lan);
				$this->_dataTitre[$index]['langTitre'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataMessage[$index]['messageLibelleLang'] = Prado::localize('MESSAGE_BIENVENUE_ORGANISATION');
				$this->_dataMessage[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataMessage[$index]['message'] = $tOrganisation->getMessageBienvenueTraduit($lan);
				$this->_dataMessage[$index]['langMessage'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataIntituleLien1[$index]['libelle'] = Prado::localize('INTITULE_LIEN1_FOOTER');
				$this->_dataIntituleLien1[$index]['textLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataIntituleLien1[$index]['text'] = $tOrganisation->getIntituleLien1Traduit($lan);
				$this->_dataIntituleLien1[$index]['lang'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataIntituleLien2[$index]['libelle'] = Prado::localize('INTITULE_LIEN2_FOOTER');
				$this->_dataIntituleLien2[$index]['textLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataIntituleLien2[$index]['text'] = $tOrganisation->getIntituleLien2Traduit($lan);
				$this->_dataIntituleLien2[$index]['lang'] = $lan;
				$index++;
			}
			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataIntituleLien3[$index]['libelle'] = Prado::localize('INTITULE_LIEN3_FOOTER');
				$this->_dataIntituleLien3[$index]['textLang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataIntituleLien3[$index]['text'] = $tOrganisation->getIntituleLien3Traduit($lan);
				$this->_dataIntituleLien3[$index]['lang'] = $lan;
				$index++;
			}
            $this->lien1->Text = $tOrganisation->getUrlLien1();
			$this->lien2->Text = $tOrganisation->getUrlLien2();
			$this->lien3->Text = $tOrganisation->getUrlLien3();
			$this->acronyme->Text = $tOrganisation->getAcronyme();
			$this->nomDomaine->Text = $tOrganisation->getNomDomaine();
		}
	}

}