<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerPrestation extends AtexoPage {

	private $_dataLibellePrestation = null;
	private $_dataCommentaire = null;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{

		if(!Atexo_User_CurrentUser::hasHabilitation('GestionPrestation') || $_SESSION["typePrestation"] != Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {

			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
			
			$this->loadOrganisation();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
				$this->loadEtablissement();
			}

			if($adminEtab) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
				$this->loadEtablissement();
				if(is_numeric(Atexo_User_CurrentUser::getIdEtablissementGere())) {
					$this->listeEtablissement->SelectedValue=Atexo_User_CurrentUser::getIdEtablissementGere();
					$this->loadTypePrestation();
				}
			}

			if(isset($_GET["idPrestation"])) {
				$this->remplir($_GET["idPrestation"]);
			}

			self::getListeLibellePrestationParLangues($this->_dataLibellePrestation);
			self::getListeCommentaireParLangues($this->_dataCommentaire);
		}
	}

	public function checkRef() {
		$idOrganisation=$this->listeOrganisation->getSelectedValue();
		$tOrganisationQuery = new TOrganisationQuery();
		$tOrganisation = $tOrganisationQuery->getOrganisationById($idOrganisation);
		$typePrestation = $tOrganisation->getTypePrestation();
		if($typePrestation== Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			self::getListeLibellePrestationParLangues($this->_dataLibellePrestation);
			$this->panelRef->Visible=false;
			$this->panelSaisie->Visible=true;
			$this->inputPeriodicite->Enabled = true;
		}
		else {
			$this->panelSaisie->Visible=false;
			$this->panelRef->Visible=true;
			$this->loadRefPrestation();
		}
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}

	/**
	 * Remplir la liste des etablissements
	 */
	public function loadEtablissement() {
		$idOrganisation=$this->listeOrganisation->getSelectedValue() ;
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$etablissementGestion = new Atexo_Etablissement_Gestion();
		$this->listeEtablissement->DataSource = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,$idOrganisation,null,Prado::localize('SELECTIONNEZ'),true);
		$this->listeEtablissement->DataBind();
		$this->checkRef();
	}

	/**
	 * Remplir la liste des types-prestations
	 */
	public function loadTypePrestation(){
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$typePrestationGestion = new Atexo_TypePrestation_Gestion();
		$this->listeTypePrestation->DataSource = $typePrestationGestion->getTypePrestationByIdEtab($lang,$this->listeEtablissement->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->listeTypePrestation->DataBind();
	}

	/**
	 * Remplir la liste des refPrestations
	 */
	public function loadRefPrestation(){
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$RefPrestationGestion = new Atexo_RefPrestation_Gestion();
		$this->listeRefPrestation->DataSource = $RefPrestationGestion->getRefPrestationByIdOrganisation($lang,$this->listeOrganisation->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->listeRefPrestation->DataBind();
	}

	public function loadDureeRdv(){
		$refPrestationQuery = new TRefPrestationQuery();
		$refPrestation = $refPrestationQuery->getRefPrestationById($this->listeRefPrestation->SelectedValue);
		$this->inputPeriodicite->Text = $refPrestation->getDureeRdv();
	}

	/**
	 * @param $data
	 * récuperer repeater libelle de la prestation
	 */
	public function getListeLibellePrestationParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeLibellePrestationParLangues($data);
		} else {
			//récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['libellePrestationLibelleLang'] = Prado::localize('LIBELLE_PRESTATION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['libellePrestation'] = '';
				$data[$index]['langLibellePrestation'] = $lan;
				$index++;
			}
			$this->setListeLibellePrestationParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater libelle de la prestation
	 */
	public function setListeLibellePrestationParLangues($data) {
		$this->listeLibellePrestationLangues->dataSource = $data;
		$this->listeLibellePrestationLangues->dataBind();
		$index = 0;
		foreach ($this->listeLibellePrestationLangues->getItems() as $item) {
			$item->libellePrestationLibelleLang->Text = $data[$index]['libellePrestationLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->libellePrestation->Text = $data[$index]['libellePrestation'];
			$item->langLibellePrestation->Value = $data[$index]['langLibellePrestation'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * récuperer repeater commentaire de la prestation
	 */
	public function getListeCommentaireParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeCommentaireParLangues($data);
		} else {
			//récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['commentaireLibelleLang'] = Prado::localize('COMMENTAIRE');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['commentaire'] = '';
				$data[$index]['langCommentaire'] = $lan;
				$index++;
			}
			$this->setListeCommentaireParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater commentaire de la prestation
	 */
	public function setListeCommentaireParLangues($data) {
		$this->listeCommentaireLangues->dataSource = $data;
		$this->listeCommentaireLangues->dataBind();
		$index = 0;
		foreach ($this->listeCommentaireLangues->getItems() as $item) {
			$item->commentaireLibelleLang->Text = $data[$index]['commentaireLibelleLang'];
			$item->commentaire->Text = $data[$index]['commentaire'];
			$item->langCommentaire->Value = $data[$index]['langCommentaire'];
			$item->lang->Text = $data[$index]['lang'];
			$index++;
		}
	}

	/**
	 * @param $idPrestation
	 * récuperer les informations de la prestation
	 */
	public function remplir($idPrestation) {
		$langues= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		$tPrestationQuery = new TPrestationQuery();
		$tPrestation = $tPrestationQuery->getPrestationById($idPrestation);
		if ($tPrestation instanceof TPrestation){
			$tTypePrestation = $tPrestation->getTTypePrestation();
			$tEtablissement = $tTypePrestation->getTEtablissement();
			$tOrganisation = $tEtablissement->getTOrganisation();
			$this->listeOrganisation->SelectedValue = $tEtablissement->getIdOrganisation();
			$this->loadEtablissement();
			$this->listeRefPrestation->SelectedValue = $tPrestation->getIdRefPrestation();
			$this->loadRefPrestation();
			$this->listeEtablissement->SelectedValue = $tTypePrestation->getIdEtablissement();
			$this->loadTypePrestation();
			$this->listeTypePrestation->SelectedValue = $tPrestation->getIdTypePrestation();
			$this->inputDelaiMin->setText($tPrestation->getDelaiMin());
			$this->inputPeriodicite->setText($tPrestation->getPeriodicite());
			$this->inputNbrParticipant->setText($tPrestation->getNombreMaxParticipants());

			if($tPrestation->getVisioconference() == 1){
			    $this->ouiVisio->checked = true;
            }else{
                $this->nonVisio->checked = true;
            }
            if($tPrestation->getRdvGroupe() == 1){
                $this->ouiRdvGroupe->checked = true;
            }else{
                $this->nonRdvGroupe->checked = true;
            }
			if($tPrestation->getRdvSimilaire() == 1){
				$this->ouiRdv->checked = true;
			}
			else{
				$this->nonRdv->checked = true;
				$this->inputNbJour->Text = $tPrestation->getNbJourRdvSimilaire();
				$this->script->Text .= "<script>showDiv('divNbJour');</script>";
			}
			if($tPrestation->getRessourceVisible() == 1){
				$this->ouiRessourceVisible->checked = true;
				$this->script->Text .= "<script>showDiv('rdvObligatoire');</script>";

				$this->ouiRessource->checked = ($tPrestation->getRessourceObligatoire() == 1);
				$this->nonRessource->checked = ($tPrestation->getRessourceObligatoire() == 0);
			}
			else{
				$this->nonRessourceVisible->checked = true;
				$this->nonRessource->checked = true;
			}
			if($tPrestation->getReferentVisible() == 1){
				$this->ouiReferentVisible->checked = true;
			}
			else{
				$this->nonReferentVisible->checked = true;
			}
			$tParamForm = $tPrestation->getTParametreForm();
			if($tParamForm instanceof TParametreForm) {
				$this->remplirParamForm($tParamForm, $langues);
			}
			$index=0;
			$typePrestation = $tOrganisation->getTypePrestation();
			foreach($langues as $lan){
				$this->_dataLibellePrestation[ $index ][ 'libellePrestation' ] = $tPrestation->getLibellePrestationTraduit ( $lan, $typePrestation );
				$this->_dataLibellePrestation[ $index ][ 'libellePrestationLibelleLang' ] = Prado::localize ( 'LIBELLE_PRESTATION' );
				$this->_dataLibellePrestation[ $index ][ 'langLibellePrestation' ] = $lan;
				$this->_dataLibellePrestation[ $index ][ 'lang' ] = '(' . Prado::localize ( 'LANG_' . strtoupper ( $lan ) ) . ')';

				$this->_dataCommentaire[$index]['commentaire'] = $tPrestation->getCommentaireTraduit($lan);
				$this->_dataCommentaire[$index]['commentaireLibelleLang'] = Prado::localize('COMMENTAIRE');
				$this->_dataCommentaire[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataCommentaire[$index]['langCommentaire'] = $lan;
				$index++;
			}
			$pjs = $tPrestation->getTPiecePrestations();
			$i=0;
			foreach($pjs as $pj) {
				$dataPj[$i]["libelle"]=$pj->getTTraduction();
				$dataPj[$i]["idPiece"]=$pj->getIdPiece();
				$dataPj[$i]["idBlob"]=$pj->getIdBlobPiece();
				$dataPj[$i]["blob"]=$pj->getTblob();
				$dataPj[$i]["obligatoire"]=$pj->getObligatoire();
				$i++;
			}
			$this->listePj->DataSource = $dataPj;
			$this->listePj->DataBind();
			$i=0;
			foreach($this->listePj->getItems() as $item) {
				$item->listeChampsLangues->DataSource = $langues;
				$item->listeChampsLangues->DataBind();
				if($dataPj[$i]["idBlob"]>0) {
					$item->downloadPlan->Visible=true;
					$item->modifPlan->Visible=true;
					$item->planAcces->Style="display:none";
					$item->downloadPlan->Text = $dataPj[$i]["blob"]->getNomBlob();
					$item->downloadPlan->CommandParameter = $dataPj[$i]["idBlob"];
				}
				$item->idPiece->Value = $dataPj[$i]["idPiece"];
                if($dataPj[$i]["obligatoire"] == 1){
                    $item->ouiObligatoire->Checked = true;
                }else {
                    $item->nonObligatoire->Checked = true;
                }
				$index=0;
				$tTraductionLibelles = $dataPj[$i]["libelle"]->getTTraductionLibelles();
				foreach($item->listeChampsLangues->getItems() as $itemLang){
					$tTraductionLibelle = $tTraductionLibelles[$index];
					$itemLang->champsLibelleLang->Text = Prado::localize('LIBELLE');
					$itemLang->lang->Text = '('.Prado::localize('LANG_'.strtoupper($tTraductionLibelle->getLang())).')';
					$itemLang->champs->Text = $tTraductionLibelle->getLibelle();
					$itemLang->langChamps->Value = $tTraductionLibelle->getLang();
					$index++;
				}
				$i++;
			}
		}
	}

	public function remplirParamForm($tParamForm, $langues) {
		$this->ouiRaisonSocial->checked = ($tParamForm->getVisibleRaisonSocial() == 1);
		$this->script->Text .= ($tParamForm->getVisibleRaisonSocial() == 1)?"<script>showDiv('obligatoireRaisonSocial');</script>":"";
		$this->nonRaisonSocial->checked = ($tParamForm->getVisibleRaisonSocial() == 0);
		
		$this->ouiNom->checked = ($tParamForm->getVisibleNom() == 1);
		$this->script->Text .= ($tParamForm->getVisibleNom() == 1)?"<script>showDiv('obligatoireNom');</script>":"";
		$this->nonNom->checked = ($tParamForm->getVisibleNom() == 0);

		$this->ouiPrenom->checked = ($tParamForm->getVisiblePrenom() == 1);
		$this->script->Text .= ($tParamForm->getVisiblePrenom() == 1)?"<script>showDiv('obligatoirePrenom');</script>":"";
		$this->nonPrenom->checked = ($tParamForm->getVisiblePrenom() == 0);

		$this->ouiNaissance->checked = ($tParamForm->getVisibleDateNaissance() == 1);
		$this->script->Text .= ($tParamForm->getVisibleDateNaissance() == 1)?"<script>showDiv('obligatoireNaissance');</script>":"";
		$this->nonNaissance->checked = ($tParamForm->getVisibleDateNaissance() == 0);
			
		$this->ouiEmail->checked = ($tParamForm->getVisibleEmail() == 1);
		$this->script->Text .= ($tParamForm->getVisibleEmail() == 1)?"<script>showDiv('obligatoireEmail');</script>":"";
		$this->nonEmail->checked = ($tParamForm->getVisibleEmail() == 0);

		$this->ouiId->checked = ($tParamForm->getVisibleIdentifiant() == 1);
		$this->script->Text .= ($tParamForm->getVisibleIdentifiant() == 1)?"<script>showDiv('obligatoireIdentifiant');</script>":"";
		$this->nonId->checked = ($tParamForm->getVisibleIdentifiant() == 0);

		$this->ouiAdresse->checked = ($tParamForm->getVisibleAdresse() == 1);
		$this->script->Text .= ($tParamForm->getVisibleAdresse() == 1)?"<script>showDiv('obligatoireAdresse');</script>":"";
		$this->nonAdresse->checked = ($tParamForm->getVisibleAdresse() == 0);
		
		$this->ouiTelephone->checked = ($tParamForm->getVisibleTelephone() == 1);
		$this->script->Text .= ($tParamForm->getVisibleTelephone() == 1)?"<script>showDiv('obligatoireTelephone');</script>":"";
		$this->nonTelephone->checked = ($tParamForm->getVisibleTelephone() == 0);
		
		$this->ouiFax->checked = ($tParamForm->getVisibleFax() == 1);
		$this->script->Text .= ($tParamForm->getVisibleFax() == 1)?"<script>showDiv('obligatoireFax');</script>":"";
		$this->nonFax->checked = ($tParamForm->getVisibleFax() == 0);
		
		$this->ouiRaisonSocialObligatoire->checked = ($tParamForm->getObligatoireRaisonSocial() == 1);
		$this->nonRaisonSocialObligatoire->checked = ($tParamForm->getObligatoireRaisonSocial() == 0);
		
		$this->ouiNomObligatoire->checked = ($tParamForm->getObligatoireNom() == 1);
		$this->nonNomObligatoire->checked = ($tParamForm->getObligatoireNom() == 0);

		$this->ouiPrenomObligatoire->checked = ($tParamForm->getObligatoirePrenom() == 1);
		$this->nonPrenomObligatoire->checked = ($tParamForm->getObligatoirePrenom() == 0);

		$this->ouiNaissanceObligatoire->checked = ($tParamForm->getObligatoireDateNaissance() == 1);
		$this->nonNaissanceObligatoire->checked = ($tParamForm->getObligatoireDateNaissance() == 0);
			
		$this->ouiEmailObligatoire->checked = ($tParamForm->getObligatoireEmail() == 1);
		$this->nonEmailObligatoire->checked = ($tParamForm->getObligatoireEmail() == 0);

		$this->ouiIdObligatoire->checked = ($tParamForm->getObligatoireIdentifiant() == 1);
		$this->nonIdObligatoire->checked = ($tParamForm->getObligatoireIdentifiant() == 0);
		
		$this->ouiAdresseObligatoire->checked = ($tParamForm->getObligatoireAdresse() == 1);
		$this->nonAdresseObligatoire->checked = ($tParamForm->getObligatoireAdresse() == 0);

		$this->ouiTelephoneObligatoire->checked = ($tParamForm->getObligatoireTelephone() == 1);
		$this->nonTelephoneObligatoire->checked = ($tParamForm->getObligatoireTelephone() == 0);
		
		$this->ouiFaxObligatoire->checked = ($tParamForm->getObligatoireFax() == 1);
		$this->nonFaxObligatoire->checked = ($tParamForm->getObligatoireFax() == 0);

		$data=array();
		$i=0;
		if($tParamForm->getText1Actif()) {
			$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText1();
			$data[$i]["obligatoire"]=$tParamForm->getObligatoireText1();
			$i++;
		}
		if($tParamForm->getText2Actif()) {
			$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText2();
			$data[$i]["obligatoire"]=$tParamForm->getObligatoireText2();
			$i++;
		}
		if($tParamForm->getText3Actif()) {
			$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText3();
			$data[$i]["obligatoire"]=$tParamForm->getObligatoireText3();
		}
		$this->listeChamps->DataSource = $data;
		$this->listeChamps->DataBind();
		$i=0;
		foreach($this->listeChamps->getItems() as $item) {
			$item->ouiChamps->checked = ($data[$i]["obligatoire"]==1);
			$item->nonChamps->checked = ($data[$i]["obligatoire"]==0);
			$item->listeChampsLangues->DataSource = $langues;
			$item->listeChampsLangues->DataBind();
			$index=0;
			$tTraductionLibelles = $data[$i]["libelle"]->getTTraductionLibelles();
			foreach($item->listeChampsLangues->getItems() as $itemLang){
				$tTraductionLibelle = $tTraductionLibelles[$index];
				$itemLang->champsLibelleLang->Text = Prado::localize('LIBELLE');
				$itemLang->lang->Text = '('.Prado::localize('LANG_'.strtoupper($tTraductionLibelle->getLang())).')';
				$itemLang->champs->Text = $tTraductionLibelle->getLibelle();
				$itemLang->langChamps->Value = $tTraductionLibelle->getLang();
				$index++;
			}
			$i++;
		}
	}

	/**
	 * enregistrer les informations de la prestation
	 */
	public function enregistrer() {
        if($this->ouiRdvGroupe->Checked && ($this->inputNbrParticipant->SafeText == "" || $this->inputNbrParticipant->SafeText == "0") ){
            $this->erreurMessage->setText(Prado::localize('CHAMPS_NOMBRE_PARTICIPANTS'));
            $this->erreurMessage->setVisible('true');
            return;
        }
        if(isset($_GET["idPrestation"])) {
			$tPrestationQuery = new TPrestationQuery();
			$tPrestation = $tPrestationQuery->getPrestationById($_GET["idPrestation"]);

			$tTraductionLibellePrestation= $tPrestation->getTTraductionRelatedByCodeLibellePrestation();
			$tTraductionCommentaire = $tPrestation->getTTraductionRelatedByCodeCommentaire();

			if($tTraductionLibellePrestation==null) {
				$tTraductionLibellePrestation = new TTraduction();
			}
			if($tTraductionCommentaire==null) {
				$tTraductionCommentaire = new TTraduction();
			}
			$tParametreForm = $tPrestation->getTParametreForm();

			if(!$tParametreForm) {
				$tParametreForm = new TParametreForm();
			}
		}
		if(!($tPrestation instanceof TPrestation)) {
			$tPrestation = new TPrestation();
			$tParametreForm = new TParametreForm();
			$tTraductionLibellePrestation= new TTraduction();
			$tTraductionCommentaire = new TTraduction();
		}
		foreach($this->listeLibellePrestationLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionLibellePrestation->getTTraductionLibelle($item->langLibellePrestation->Value);
			$tTraductionLibelle->setLang($item->langLibellePrestation->Value);
			$tTraductionLibelle->setLibelle($item->libellePrestation->Text);
			$tTraductionLibellePrestation->addTTraductionLibelle($tTraductionLibelle);
		}
		foreach($this->listeCommentaireLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionCommentaire->getTTraductionLibelle($item->langCommentaire->Value);
			$tTraductionLibelle->setLang($item->langCommentaire->Value);
			$tTraductionLibelle->setLibelle($item->commentaire->Text);
			$tTraductionCommentaire->addTTraductionLibelle($tTraductionLibelle);
		}
		$idOrganisation=$this->listeOrganisation->getSelectedValue();
		$tOrganisationQuery = new TOrganisationQuery();
		$tOrganisation = $tOrganisationQuery->getOrganisationById($idOrganisation);
		$typePrestation = $tOrganisation->getTypePrestation();
		if($typePrestation==0) {
			$tPrestation->setTTraductionRelatedByCodeLibellePrestation($tTraductionLibellePrestation);
		}
		else {
			$tPrestation->setIdRefPrestation($this->listeRefPrestation->getSelectedValue());
		}
		$tPrestation->setTTraductionRelatedByCodeCommentaire($tTraductionCommentaire);
		$tPrestation->setIdTypePrestation($this->listeTypePrestation->getSelectedValue());
		$tPrestation->setDelaiMin($this->inputDelaiMin->SafeText);
        $tPrestation->setPeriodicite($this->inputPeriodicite->SafeText);

        if($this->ouiVisio->checked){
		    $tPrestation->setVisioconference('1');
        }else{
		    $tPrestation->setVisioconference('0');
        }
        if($this->ouiRdvGroupe->checked){
            $tPrestation->setRdvGroupe('1');
            $tPrestation->setNombreMaxParticipants($this->inputNbrParticipant->SafeText);
        }
        else{
            $tPrestation->setRdvGroupe('0');
            $tPrestation->setNombreMaxParticipants(null);
        }
		if($this->ouiRdv->checked){
			$tPrestation->setRdvSimilaire('1');
		}
		else{
			$tPrestation->setRdvSimilaire('0');
			$tPrestation->setNbJourRdvSimilaire($this->inputNbJour->SafeText);
		}
		if($this->ouiRessourceVisible->checked){
			$tPrestation->setRessourceVisible('1');
			$tPrestation->setRessourceObligatoire((int)$this->ouiRessource->checked);
		}
		else{
			$tPrestation->setRessourceVisible('0');
			$tPrestation->setRessourceObligatoire('0');
		}
		if($this->ouiReferentVisible->checked){
			$tPrestation->setReferentVisible('1');
		}
		else{
			$tPrestation->setReferentVisible('0');
		}

		$tPrestation->setRessourceObligatoire((int)$this->ouiRessource->checked);
		$tParametreForm = $this->enregistrerParamForm($tParametreForm);
		$tPrestation->setTParametreForm($tParametreForm);
		$tPrestation->save();
		
		$this->enregistrerPieceJointe($tPrestation->getIdPrestation());
		
		$this->response->redirect("index.php?page=administration.GestionPrestations&search");
	}
	
	public function enregistrerPieceJointe($idPrestation) {
		$idsPieceToDelete = $this->getViewState("idsPieceToDelete");
		$tPieceQuery = new TPiecePrestationQuery();
		if(is_array($idsPieceToDelete)) {
			foreach($idsPieceToDelete as $idPiece) {
				$piece = $tPieceQuery->getPieceById($idPiece);
				$tTraduction = $piece->getTTraduction();
				$piece->delete();
				$tTraduction->deleteAll();
			}
		}
		foreach ($this->listePj->getItems() as $item) {
			if($item->idPiece->Value>0) {
				$pj = $tPieceQuery->getPieceById($item->idPiece->Value);
				$tTraduction = $pj->getTTraduction();
			}
			else {
				$pj = new TPiecePrestation();
				$tTraduction = new TTraduction();
			}
						
			foreach ($item->listeChampsLangues->getItems() as $itemLang) {
				$tTraductionLibelle = $tTraduction->getTTraductionLibelle($itemLang->langChamps->Value);
				$tTraductionLibelle->setLang($itemLang->langChamps->Value);
				$tTraductionLibelle->setLibelle($itemLang->champs->SafeText);
				$tTraduction->addTTraductionLibelle($tTraductionLibelle);
				$pj->setTTraduction($tTraduction);
			}
			
			if($item->planAcces->HasFile) {
				$tBlob = $pj->getTBlob();
				
				if($tBlob==null) {
					$tBlob = new TBlob();
				}
				$tBlob->setNomBlob($item->planAcces->FileName);
				$pj->setTBlob($tBlob);
			}
			$pj->setIdPrestation($idPrestation);
			$pj->setObligatoire((int)$item->ouiObligatoire->Checked);
			$pj->save();
			
			if($item->planAcces->HasFile) {
				Atexo_Utils_Util::mvFile($item->planAcces->LocalName, Atexo_Config::getParameter("PATH_FILE"), $pj->getIdBlobPiece());
			}
		}
	}

	public function enregistrerParamForm($tParametreForm) {
		$i=1;
		$tTraductionChamps[0] = $tParametreForm->getTTraductionRelatedByCodeLibelleText1();
		$tTraductionChamps[1] = $tParametreForm->getTTraductionRelatedByCodeLibelleText2();
		$tTraductionChamps[2] = $tParametreForm->getTTraductionRelatedByCodeLibelleText3();
		foreach ($this->listeChamps->getItems() as $listes) {

			$fctActif = "setText".$i."Actif";

			$tParametreForm->$fctActif('1');

			$fctObligatoire = "setObligatoireText".$i;
			if($listes->ouiChamps->checked){
				$tParametreForm->$fctObligatoire('1');
			}
			else{
				$tParametreForm->$fctObligatoire('0');
			}
			
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				if(!isset($tTraductionChamps[$listes->ItemIndex])) {
					$tTraductionChamps[$listes->ItemIndex] = new TTraduction();
				}
				$tTraductionLibelle = $tTraductionChamps[$listes->ItemIndex]->getTTraductionLibelle($item->langChamps->Value);
				$tTraductionLibelle->setLang($item->langChamps->Value);
				$tTraductionLibelle->setLibelle($item->champs->SafeText);
				$tTraductionChamps[$listes->ItemIndex]->addTTraductionLibelle($tTraductionLibelle);
				$tTraductionChamps[$listes->ItemIndex]->save();
			}
			$i++;
		}
		for($j=$i;$j<=3;$j++) {
			$fctActif = "setText".$j."Actif";
			$tParametreForm->$fctActif('0');
		}

		$tParametreForm->setTTraductionRelatedByCodeLibelleText1($tTraductionChamps[0]);
		$tParametreForm->setTTraductionRelatedByCodeLibelleText2($tTraductionChamps[1]);
		$tParametreForm->setTTraductionRelatedByCodeLibelleText3($tTraductionChamps[2]);

		$tParametreForm->setVisibleNom((int)$this->ouiNom->checked);
		$tParametreForm->setVisiblePrenom((int)$this->ouiPrenom->checked);
		$tParametreForm->setVisibleDateNaissance((int)$this->ouiNaissance->checked);
		$tParametreForm->setVisibleEmail((int)$this->ouiEmail->checked);
		$tParametreForm->setVisibleIdentifiant((int)$this->ouiId->checked);
		$tParametreForm->setVisibleTelephone((int)$this->ouiTelephone->checked);
		$tParametreForm->setVisibleAdresse((int)$this->ouiAdresse->checked);
		$tParametreForm->setVisibleRaisonSocial((int)$this->ouiRaisonSocial->checked);
		$tParametreForm->setVisibleFax((int)$this->ouiFax->checked);
		
		$tParametreForm->setObligatoireNom((int)$this->ouiNomObligatoire->checked);
		$tParametreForm->setObligatoirePrenom((int)$this->ouiPrenomObligatoire->checked);
		$tParametreForm->setObligatoireDateNaissance((int)$this->ouiNaissanceObligatoire->checked);
		$tParametreForm->setObligatoireEmail((int)$this->ouiEmailObligatoire->checked);
		$tParametreForm->setObligatoireIdentifiant((int)$this->ouiIdObligatoire->checked);
		$tParametreForm->setObligatoireTelephone((int)$this->ouiTelephoneObligatoire->checked);
		$tParametreForm->setObligatoireAdresse((int)$this->ouiAdresseObligatoire->checked);
		$tParametreForm->setObligatoireRaisonSocial((int)$this->ouiRaisonSocialObligatoire->checked);
		$tParametreForm->setObligatoireFax((int)$this->ouiFaxObligatoire->checked);
		return $tParametreForm;
	}


	/**
	 * @param $nbreLigneAAjouter
	 * Récupérer les champs paramétrables
	 */
	public function getDataLigne($nbreLigneAAjouter=0) {
		$index = 0;
		$data = array();
		$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		foreach ($this->listeChamps->getItems() as $listes) {
			$data[$index]['langChamps'] = '';
			$dataChamps = array();
			$indexChamps = 0;
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataChamps[$langues[$indexChamps]]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$langues[$indexChamps]]['lang'] = '('.Prado::localize('LANG_'.strtoupper($langues[$indexChamps])).')';
				$dataChamps[$langues[$indexChamps]]['champs'] = $item->champs->SafeText;
				$dataChamps[$langues[$indexChamps]]['langChamps'] = $langues[$indexChamps];
				$indexChamps++;
			}
			$data[$index]['dataChamp'] = $dataChamps;
			$data[$index]['obligatoire'] = $listes->ouiChamps->Checked;
			$index++;
		}
		if($nbreLigneAAjouter>0) {
			if(count($data)==0) {
				$index = 0;

			}
			$dataChamps = array();
			$data[$index]['langChamps'] = "";
			foreach ($langues as $lan) {
				$dataChamps[$lan]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$lan]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$dataChamps[$lan]['champs'] = '';
				$dataChamps[$lan]['langChamps'] = $lan;
			}
			$data[$index]['dataChamp'] = $dataChamps;
		}

		return $data;

	}

	/**
	 * @param $nbreLigneAAjouter
	 * Ajouer un champ paramétrable
	 */
	public function ajouterChamps($sender, $param) {
		$nbreLigneAAjouter = 1;
		$data =  $this->getDataLigne($nbreLigneAAjouter);
		$this->remplirRepeaterChamps($data);
		if(count($data)>2) {
			$this->btnAjoutChamp->setStyle('display:none');
		}
		$this->listeChampsPanel->setStyle('display:block');
		$this->listeChampsPanel->render($param->NewWriter);
	}


	/**
	 *
	 * Supprimer un champ
	 */
	public function deleteLigneChamps($sender,$param)
	{
		$data = array();
		$itemIndex = $sender->CommandParameter;
		$dataChamps = $this->getDataLigne();
		unset($dataChamps[$itemIndex]);
		$data = array_values($dataChamps);
		$this->remplirRepeaterChamps($data);
			
		$this->btnAjoutChamp->setStyle('display:block');
		$this->listeChampsPanel->render($param->NewWriter);
	}

	/**
	 * @param $data
	 * Remplir liste des champs paramétrables
	 */
	public function remplirRepeaterChamps($data) {
		$this->listeChamps->dataSource = $data;
		$this->listeChamps->dataBind();
		$index = 0;
		foreach ($this->listeChamps->getItems() as $listes) {
			$dataChamps = $data[$index]['dataChamp'];
			$listes->listeChampsLangues->dataSource = $dataChamps;
			$listes->listeChampsLangues->dataBind();
			$indexChamps = 0;
			$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$listes->ouiChamps->checked = ($data[$index]["obligatoire"]);
			$listes->nonChamps->checked = !($data[$index]["obligatoire"]);

			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataLang = $dataChamps[$langues[$indexChamps]];
				$item->champsLibelleLang->Text = $dataLang['champsLibelleLang'];
				$item->champs->Text = $dataLang['champs'];
				$item->langChamps->value = $langues[$indexChamps];
				$item->lang->Text = $dataLang['lang'];
				$indexChamps++;
			}
			$index++;
		}
	}
	
	/**
	 * @param $nbreLigneAAjouter
	 * Récupérer les champs paramétrables
	 */
	public function getDataLignePj($nbreLigneAAjouter=0) {
		$index = 0;
		$data = array();
		$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		foreach ($this->listePj->getItems() as $listes) {
			$data[$index]['langChamps'] = '';
			$dataChamps = array();
			$indexChamps = 0;
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataChamps[$langues[$indexChamps]]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$langues[$indexChamps]]['lang'] = '('.Prado::localize('LANG_'.strtoupper($langues[$indexChamps])).')';
				$dataChamps[$langues[$indexChamps]]['champs'] = $item->champs->SafeText;
				$dataChamps[$langues[$indexChamps]]['langChamps'] = $langues[$indexChamps];
				$indexChamps++;
			}
			$data[$index]['dataChamp'] = $dataChamps;
			$data[$index]['idPiece'] = $listes->idPiece->Value;
            if($listes->ouiObligatoire->Checked){
                $data[$index]["obligatoire"] = 1;
            }else {
                $data[$index]["obligatoire"] = 0;
            }
			$index++;
		}
		if($nbreLigneAAjouter>0) {
			if(count($data)==0) {
				$index = 0;
			}
			$dataChamps = array();
			$data[$index]['langChamps'] = "";
			foreach ($langues as $lan) {
				$dataChamps[$lan]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$lan]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$dataChamps[$lan]['champs'] = '';
				$dataChamps[$lan]['langChamps'] = $lan;
			}
			$data[$index]['dataChamp'] = $dataChamps;
		}

		return $data;

	}

	/**
	 * @param $nbreLigneAAjouter
	 * Ajouer un pj
	 */
	public function ajouterPjs($sender, $param) {
		$nbreLigneAAjouter = 1;
		$data =  $this->getDataLignePj($nbreLigneAAjouter);
		$this->remplirRepeaterPj($data);
		$this->listePjPanel->render($param->NewWriter);
	}

	/**
	 *
	 * Supprimer un pj
	 */
	public function deleteLignePjs($sender,$param)
	{
		$data = array();
		$itemIndex = $sender->CommandParameter;
		$idPiece = $sender->Parent->idPiece->Value;
		$idsPieceToDelete = $this->getViewState("idsPieceToDelete");
		$idsPieceToDelete[] = $idPiece;
		$this->setViewState("idsPieceToDelete", $idsPieceToDelete);
		$dataChamps = $this->getDataLignePj();
		unset($dataChamps[$itemIndex]);
		$data = array_values($dataChamps);
		$this->remplirRepeaterPj($data);
			
		$this->listePjPanel->render($param->NewWriter);
	}

	/**
	 * @param $data
	 * Remplir liste des pj
	 */
	public function remplirRepeaterPj($data) {
		$this->listePj->dataSource = $data;
		$this->listePj->dataBind();
		$index = 0;
		foreach ($this->listePj->getItems() as $listes) {
			$dataChamps = $data[$index]['dataChamp'];
			$listes->listeChampsLangues->dataSource = $dataChamps;
			$listes->listeChampsLangues->dataBind();
			$listes->idPiece->Value = $data[$index]["idPiece"];
			$indexChamps = 0;
			$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataLang = $dataChamps[$langues[$indexChamps]];
				$item->champsLibelleLang->Text = $dataLang['champsLibelleLang'];
				$item->champs->Text = $dataLang['champs'];
				$item->langChamps->value = $langues[$indexChamps];
				$item->lang->Text = $dataLang['lang'];
				$indexChamps++;
			}
            if(is_null($data[$index]["obligatoire"]) || $data[$index]["obligatoire"] == 1){
                $listes->ouiObligatoire->Checked = true;
            }else {
                $listes->nonObligatoire->Checked = true;
            }
			$index++;
		}
	}
	
	/**
	 * télécharger le plan d'accès 
	 */
	public function downloadPieceJointe($sender) {
		$idFichier = $sender->CommandParameter;
		Atexo_DownloadFile::downloadFiles($idFichier);
	}
	

	/**
	 * modifier le plan d'accès
	 */
	public function modifPieceJointe($sender, $param) {
		$sender->Parent->Parent->downloadPlan->Visible=false;
		$sender->Parent->Parent->modifPlan->Visible=false;
		$sender->Parent->Parent->planAcces->Style="display:";
		
		$sender->Parent->Parent->panelPlanAcces->render($param->getNewWriter());
	}
}