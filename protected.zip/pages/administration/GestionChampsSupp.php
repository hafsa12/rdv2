<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionChampsSupp extends AtexoPage {

    private $_lang = "";
    /**
     * @var Atexo_RefPrestation_CriteriaVo
     */
    protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionRefPrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
        $this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
        if(!$this->isPostBack) {
            if(!isset($_GET["search"])) {
                unset($_SESSION["champsSupp"]["criteriaVoSearch"]);
                unset($_SESSION["champsSupp"]["sensTriArray"]);
                unset($_SESSION["champsSupp"]["sortByElement"]);
            }
            $this->init();
        }else{
            $this->_criteriaVo = $_SESSION["champsSupp"]["criteriaVoSearch"];
        }
		$this->paneldeleteFail->style="display:none";
		$this->paneldeleteOk->style="display:none";
	}

    protected function init() {
        $this->_criteriaVo = $_SESSION["champsSupp"]["criteriaVoSearch"];

        $adminOrg= Atexo_User_CurrentUser::isAdminOrg();
        $this->loadOrganisation();

        if(!$this->_criteriaVo) {

            $this->_criteriaVo = new Atexo_RefPrestation_CriteriaVo();

            if ( $adminOrg ) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
                $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
                $this->listeOrganisation->SelectedValue = $idOrganisation;
                $this->listeOrganisation->Enabled = false;
            }

            $this->_criteriaVo->setSortByElement ( "CODE_CHAMPS" );
            $_SESSION["champsSupp"]["sortByElement"] = "CODE_CHAMPS";
            $_SESSION["champsSupp"]["sensTriArray"] = array( "CODE_CHAMPS" => "ASC" );
        }
        else {
            if ( $adminOrg ) {
                $this->listeOrganisation->SelectedValue = $this->_criteriaVo->getIdOrganisation ();
                $this->listeOrganisation->Enabled = false;
            }
        }
		$this->_criteriaVo->setLang ( $this->_lang );

        if( isset( $_GET["pages"] ) ) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if( isset( $_GET["pageSize"] ) ) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listeChampsSupp->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif ( !$this->_criteriaVo->getPageSize() ) {
            $this->_criteriaVo->setPageSize(10);
        }

        $this->fillRepeaterWithDataForSearchResult ();
    }
	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($this->_lang, Prado::localize('ORGANISATION'));
		$this->listeOrganisation->DataBind();
	}

	/**
	 * Remplir repeater des établissements selon les critères de recherche
	 */
	public function fillRepeaterWithDataForSearchResult()
	{
		$tChampsSuppPeer = new TChampsSuppPeer();
		//Nombre des Prestations
		$nombreElement = $tChampsSuppPeer->getChampsSuppByCriteres($this->_criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->panelBottom->setVisible(true);
			$this->panelTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listeChampsSupp->setVirtualItemCount($nombreElement);
			$this->listeChampsSupp->setCurrentPageIndex(0);
			$this->populateData();
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
			$this->panelTop->setVisible(false);
			$this->panelBottom->setVisible(false);
			$this->listeChampsSupp->DataSource=array();
			$this->listeChampsSupp->DataBind();
			$this->nombreElement->Text="0";
		}
        $_SESSION["champsSupp"]["criteriaVoSearch"] = $this->_criteriaVo;
	}

	/**
	 * Peupler les données des prestations
	 */
	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");

        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listeChampsSupp->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listeChampsSupp->CurrentPageIndex = $numPage -1;

        $offset = $this->listeChampsSupp->CurrentPageIndex * $pageSize;
        $limit = $pageSize;
        $this->listeChampsSupp->PageSize = $limit;

        if ($offset + $limit > $nombreElement) {
            $limit = $nombreElement - $offset;
        }
        $this->_criteriaVo->setOffset($offset);
        $this->_criteriaVo->setLimit($limit);

		$data = TChampsSuppPeer::getChampsSuppByCriteres($this->_criteriaVo);
		$this->listeChampsSupp->DataSource=$data;
		$this->listeChampsSupp->DataBind();

		$pageSize = $this->listeChampsSupp->PageSize;

		$this->numPageBottom->Text = $numPage;
		$this->numPageTop->Text = $numPage;
		$this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
		$this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
		$this->nombrePageTop->Text = $nombrePages;
		$this->nombrePageBottom->Text = $nombrePages;
	}

	/**
	 * Rechercher Prestation par critères
	 */
	protected function suggestNames($sender,$param) {
        try {
            $this->_criteriaVo = new Atexo_RefPrestation_CriteriaVo();
            $this->_criteriaVo->setLang ( $this->_lang );

            if ( $this->listeOrganisation->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdOrganisation ( $this->listeOrganisation->getSelectedValue () );
            }
            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);
            unset($_GET["pageSize"]);
            unset($_GET["pages"]);

            $this->fillRepeaterWithDataForSearchResult ();
            $this->refPrestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function Trier($sender,$param)
	{
		try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["champsSupp"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $arraySensTri = $_SESSION["champsSupp"]["sensTriArray"] ? $_SESSION["champsSupp"]["sensTriArray"] : array ();
            $arraySensTri[ $champsOrderBy ] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $arraySensTri[ $champsOrderBy ] );
            $_SESSION["champsSupp"]["sensTriArray"] = $arraySensTri;

            $_SESSION["champsSupp"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
            $this->populateData ();
            $this->refPrestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
			$logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
			$logger->error($e->getMessage());
		}
	}

	public function pageChanged($sender,$param)
	{
		$urlParams = "&pages=".($param->NewPageIndex+1);
		if(isset($_GET["pageSize"])) {
			$urlParams .= "&pageSize=".$_GET["pageSize"];
		}
		$this->response->redirect("?page=administration.GestionChampsSupp&search".$urlParams);
	}

	public function goToPage($sender)
	{
		switch ($sender->ID) {
			case "DefaultButtonTop" :    $numPage=$this->numPageTop->Text;
				break;
			case "DefaultButtonBottom" : $numPage=$this->numPageBottom->Text;
				break;
		}
		$urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeChampsSupp->CurrentPageIndex+1, $this->nombrePageTop->Text);
		if(isset($_GET["pageSize"])) {
			$urlParams .= "&pageSize=".$_GET["pageSize"];
		}
		$this->response->redirect("?page=administration.GestionChampsSupp&search".$urlParams);
	}

	public function changePagerLenght($sender)
	{
		switch ($sender->ID) {
			case "nombreResultatAfficherBottom" :
				$pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
				break;
			case "nombreResultatAfficherTop" :
				$pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
				break;
		}
		$this->response->redirect("?page=administration.GestionChampsSupp&search&pages=1&pageSize=".$pageSize);
	}

	/**
	 * 
	 * Confirmer la suppression d'une organisation
	 */
	public function onConfirmSuppressionClick($sender,$param) {

		$idChampSupp = $this->idChampsSuppToDeleteHidden->Value;

		$tChampsSuppQuery = new TChampsSuppQuery();
		$tChampsSupp = $tChampsSuppQuery->getChampSuppById($idChampSupp);

		if($tChampsSupp instanceof TChampsSupp) {
			$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
			$connexion->beginTransaction();
			$tTraductionLibelle = $tChampsSupp->getTTraduction();
			$tChampsSupp->delete($connexion);
			$tTraductionLibelle->deleteAll($connexion);
			$connexion->commit();

			$this->paneldeleteFail->style="display:none";
			$this->paneldeleteOk->style="display:block";
		}

		//Remplir repeater Ref Prestation
		$this->fillRepeaterWithDataForSearchResult();
		$this->refPrestationPanel->render($param->NewWriter);
	}

	public function isTrierPar($champ) {
        $sortByElement = $_SESSION["champsSupp"]["sortByElement"];
        if($champ!=$sortByElement) {
            return "";
        }
        $arraySens = $_SESSION["champsSupp"]["sensTriArray"] ? $_SESSION["champsSupp"]["sensTriArray"] : array ();
        if($arraySens[$sortByElement]=="ASC") {
            return "tri-on tri-asc";
        }
        return "tri-on tri-desc";
	}
}
