<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionProfils extends AtexoPage {

    private $_lang;
    /**
     * @var Atexo_Profil_CriteriaVo
     */
    protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
         if(!Atexo_User_CurrentUser::hasHabilitation('GestionProfils')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
        $this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
        if(!$this->isPostBack) {
            if(!isset($_GET["search"])) {
                unset($_SESSION["profil"]["criteriaVoSearch"]);
                unset($_SESSION["profil"]["sensTri"]);
                unset($_SESSION["profil"]["sortByElement"]);
            }
            $this->init();
		}else{
            $this->_criteriaVo = $_SESSION["profil"]["criteriaVoSearch"];
        }
	}

    protected function init() {

        $this->_criteriaVo = $_SESSION["profil"]["criteriaVoSearch"];
        $adminOrg = Atexo_User_CurrentUser::isAdminOrg();

        $this->loadOrganisation();

        if(!$this->_criteriaVo) {

            $this->_criteriaVo = new Atexo_Profil_CriteriaVo();
            $idOrganisation = false;

            if($adminOrg) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
                $this->listeOrganisation->SelectedValue = $idOrganisation;
                $this->listeOrganisation->Enabled = false;
                $this->_criteriaVo->setIdTypeProfilGE(Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION"));
            }
            //Get All Profils
            $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
            $this->_criteriaVo->setSortByElement ( "LIBELLE_PROFIL" );
            $_SESSION["profil"]["sortByElement"] = "LIBELLE_PROFIL";
            $_SESSION["profil"]["sensTri"] = "ASC";
        }else{
            $idOrganisation = $this->_criteriaVo->getIdOrganisation ();
            $this->listeOrganisation->SelectedValue = $idOrganisation;
            if ( $adminOrg ) {
                $this->listeOrganisation->Enabled = false;
            }
        }
        $this->_criteriaVo->setLang ( $this->_lang );

        if(isset($_GET["pages"])) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if(isset($_GET["pageSize"])) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listeProfils->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif(!$this->_criteriaVo->getPageSize()) {
            $this->_criteriaVo->setPageSize(10);
        }
        $this->fillRepeaterWithDataForSearchResult();
    }
	public function fillRepeaterWithDataForSearchResult()
	{
		$tProfilPeer = new TProfilPeer();
		//Nombre des agents
        $nombreElement = $tProfilPeer->getProfilByCriteres($this->_criteriaVo, true);
		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
            $this->panelBottom->setVisible(true);
            $this->panelTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listeProfils->setVirtualItemCount($nombreElement);
			$this->listeProfils->setCurrentPageIndex(0);
			$this->populateData();
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
            $this->panelBottom->setVisible(false);
            $this->panelTop->setVisible(false);
            $this->listeProfils->DataSource=array();
            $this->listeProfils->DataBind();
            $this->nombreElement->Text="0";
		}
        $_SESSION["profil"]["criteriaVoSearch"] = $this->_criteriaVo;
	}

	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");
        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listeProfils->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listeProfils->CurrentPageIndex = $numPage -1;

        $offset = $this->listeProfils->CurrentPageIndex * $pageSize;
        $limit = $pageSize;
        $this->listeProfils->PageSize = $limit;

        if ($offset + $limit > $nombreElement) {
            $limit = $nombreElement - $offset;
        }
        $this->_criteriaVo->setOffset($offset);
        $this->_criteriaVo->setLimit($limit);

        $dataProfils = TProfilPeer::getProfilByCriteres($this->_criteriaVo);
		$this->listeProfils->DataSource=$dataProfils;
		$this->listeProfils->DataBind();

        $pageSize = $this->listeProfils->PageSize;

        $this->numPageBottom->Text = $numPage;
        $this->numPageTop->Text = $numPage;
        $this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
        $this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
        $this->nombrePageTop->Text = $nombrePages;
        $this->nombrePageBottom->Text = $nombrePages;
	}

    /**
     * Rechercher Profils par crit�res
     */
    protected function suggestNames( $sender, $param ) {
        try {
            $this->_criteriaVo = new Atexo_Profil_CriteriaVo();

            $token = $this->listeOrganisation->getSelectedValue ();
            // si admin org : ecraser par l'organisation de l'utilisateur
            $adminOrg = Atexo_User_CurrentUser::isAdminOrg();
            if($adminOrg) {
                $token = Atexo_User_CurrentUser::getIdOrganisationGere();
                $this->listeOrganisation->SelectedValue = $token;
                $this->listeOrganisation->Enabled = false;
                $this->_criteriaVo->setIdTypeProfilGE(Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION"));
            }
            $this->_criteriaVo->setLang ( $this->_lang );
            $this->_criteriaVo->setIdOrganisation ( $token );
            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);

            // tri
            $this->_criteriaVo->setSortByElement($_SESSION["profil"]["sortByElement"]);
            $this->_criteriaVo->setSensOrderBy($_SESSION["profil"]["sensTri"]);

            unset($_GET["pageSize"]);
            unset($_GET["pages"]);

            $this->fillRepeaterWithDataForSearchResult ();
            $this->profilPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
    }

	public function Trier($sender,$param)
	{
		try {
			$champsOrderBy = $sender->CommandParameter;

            $_SESSION["profil"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $_SESSION["profil"]["sensTri"] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $_SESSION["profil"]["sensTri"] );

            $_SESSION["profil"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
			$this->populateData();
			$this->profilPanel->render($param->getNewWriter());
		} catch(Exception $e) {
			$logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
			$logger->error($e->getMessage());
		}
	}

	public function pageChanged($sender,$param)
	{
		$urlParams = "&pages=".($param->NewPageIndex+1);
		if(isset($_GET["pageSize"])) {
			$urlParams .= "&pageSize=".$_GET["pageSize"];
		}
		$this->response->redirect("?page=administration.GestionProfils&search".$urlParams);
	}

	public function goToPage($sender)
	{
		switch ($sender->ID) {
			case "DefaultButtonTop" :    $numPage=$this->numPageTop->Text;
			break;
			case "DefaultButtonBottom" : $numPage=$this->numPageBottom->Text;
			break;
		}
        $urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeProfils->CurrentPageIndex+1, $this->nombrePageTop->Text);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
		$this->response->redirect("?page=administration.GestionProfils&search".$urlParams);
	}

	public function changePagerLenght($sender)
	{
		switch ($sender->ID) {
			case "nombreResultatAfficherBottom" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
			    break;
			case "nombreResultatAfficherTop" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
			    break;
		}
		$this->response->redirect("?page=administration.GestionProfils&search&pages=1&pageSize=".$pageSize);
	}

	public function onConfirmSuppressionClick($sender,$param) {
        try {
            $idProfil = $this->profilToDeleteHidden->Value;

            $tAgentQuery = new TAgentQuery();
            $countAgents = count($tAgentQuery->getAgentWithIdProfil($idProfil));
            if ( $countAgents == 0 ) {
                $tProfilQuery = new TProfilQuery();
                $tProfil = $tProfilQuery->getProfilById ( $idProfil );

                if ( $tProfil instanceof TProfil ) {

                    $connexion = Propel:: getConnection ( Atexo_Config::getParameter ( "DB_NAME" ) . Atexo_Config::getParameter ( "CONST_READ_ONLY" ) );
                    $connexion->beginTransaction ();
                    $tTraductionNom = $tProfil->getTTraduction ();

                    $tProfil->delete ( $connexion );
                    //Nom
                    $tTraductionNom->deleteAll ( $connexion );

                    $connexion->commit ();
                }

                $this->paneldeleteOk->style = "display:block";
                $this->paneldeleteFail->style = "display:none";
                //Remplir repeater Agents
                $this->populateData ();
            }
            else {
                $this->paneldeleteOk->style="display:none";
                $this->paneldeleteFail->style="display:block";
            }
            //Remplir repeater Profils
            $this->fillRepeaterWithDataForSearchResult();
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function getNomPrenomAgSuppress($idAgent) {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$agent = Atexo_Agent_Gestion::retrieveAgent($idAgent);
		if($agent) {
			return $agent->getNomPrenomUtilisateurTraduit($lang);
		}
	}
	
	public function isTrierPar($champ) {
        $sortByElement = $_SESSION["profil"]["sortByElement"];
        if($champ!=$sortByElement) {
            return "";
        }
        if( $_SESSION["profil"]["sensTri"] == "ASC" ) {
            return "tri-on tri-asc";
        }
        return "tri-on tri-desc";
	}
    /**
     * Remplir la liste des organisations
     */
    public function loadOrganisation() {
        $organisationGestion = new Atexo_Organisation_Gestion();
        $this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($this->_lang, Prado::localize('SELECTIONNEZ'));
        $this->listeOrganisation->DataBind();
        $this->listeOrganisation->setSelectedIndex(0);
    }
}