<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerTypePrestation extends AtexoPage {

	private $_dataLibelleType = null;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionTypePrstation') || $_SESSION["typePrestation"] != Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {
			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$adminEtab = Atexo_User_CurrentUser::isAdminEtab();

			$this->loadOrganisation();
			$this->listeOrganisation->SelectedIndex=0;

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
				$this->loadEtablissement();
			}

			if($adminEtab) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;

				$this->loadEtablissement();
			}

			//$this->loadOrganisation();
			//$this->loadEtablissement();

			if(isset($_GET["idTypePrestation"])) {
				$this->remplir($_GET["idTypePrestation"]);
			}

			self::getListeLibelleTypeParLangues($this->_dataLibelleType);
		}
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}

	/**
	 * Remplir la liste des établissement
	 */
	public function loadEtablissement() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$etablissementGestion = new Atexo_Etablissement_Gestion();
		$this->listeEtablissement->DataSource = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,$this->listeOrganisation->SelectedValue,null,Prado::localize('SELECTIONNEZ'),true);
		$this->listeEtablissement->DataBind();
		$this->checkRef();
	}

	/**
	 * @param $data
	 * récuperer repeater libelle du type-prestation
	 */
	public function getListeLibelleTypeParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeLibelleTypeParLangues($data);
		} else {
			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['libelleTypeLibelleLang'] = Prado::localize('LIBELLE_PRESTATION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['libelleType'] = '';
				$data[$index]['langLibelleType'] = $lan;
				$index++;
			}
			$this->setListeLibelleTypeParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater libelle du type-prestation
	 */
	public function setListeLibelleTypeParLangues($data) {
		$this->listeLibelleTypeLangues->dataSource = $data;
		$this->listeLibelleTypeLangues->dataBind();
		$index = 0;
		foreach ($this->listeLibelleTypeLangues->getItems() as $item) {
			$item->libelleTypeLibelleLang->Text = $data[$index]['libelleTypeLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->libelleType->Text = $data[$index]['libelleType'];
			$item->langLibelleType->Value = $data[$index]['langLibelleType'];
			$index++;
		}
	}

	/**
	 * @param $idPrestation
	 * récuperer les informations du type-prestation
	 */
	public function remplir($idTypePrestation) {

		$tTypePrestationQuery = new TTypePrestationQuery();
		$tTypePrestation = $tTypePrestationQuery->getTypePrestationById($idTypePrestation);

		if ($tTypePrestation instanceof TTypePrestation){

			$tEtablissement = $tTypePrestation->getTEtablissement();

			$this->listeOrganisation->SelectedValue = $tEtablissement->getIdOrganisation();

			$this->loadEtablissement();
			$this->listeEtablissement->SelectedValue = $tTypePrestation->getIdEtablissement();

			$this->loadRefTypePrestation();
			$this->listeRefTypePrestation->SelectedValue = $tTypePrestation->getIdRefTypePrestation();

			$this->visibleOui->checked = ($tTypePrestation->getVisibleCitoyen()=="1");
			$this->visibleNon->checked = ($tTypePrestation->getVisibleCitoyen()=="0");

			//recuperer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$index=0;
			foreach($langues[0] as $lan){
				$this->_dataLibelleType[$index]['libelleType'] = $tTypePrestation->getLibelleTypePrestationTraduit($lan);
				$this->_dataLibelleType[$index]['libelleTypeLibelleLang'] = Prado::localize('LIBELLE_PRESTATION');
				$this->_dataLibelleType[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$this->_dataLibelleType[$index]['langLibelleType'] = $lan;
				$index++;
			}
		}
	}

	/**
	 * enregistrer les informations du type-prestation
	 */
	public function enregistrer() {

		if(isset($_GET["idTypePrestation"])) {
			$tTypePrestationQuery = new TTypePrestationQuery();
			$tTypePrestation = $tTypePrestationQuery->getTypePrestationById($_GET["idTypePrestation"]);
			$tTraductionLibelleType = $tTypePrestation->getTTraduction();
		}

		if(!($tTypePrestation instanceof TTypePrestation)) {
			$tTypePrestation = new TTypePrestation();
			$tTraductionLibelleType = new TTraduction();
		}

		if($this->getViewState("refTypePrestation")==0) {
			//boucle
			foreach ( $this->listeLibelleTypeLangues->getItems () as $item ) {
				$tTraductionLibelle = $tTraductionLibelleType->getTTraductionLibelle ( $item->langLibelleType->Value );
				$tTraductionLibelle->setLang ( $item->langLibelleType->Value );
				$tTraductionLibelle->setLibelle ( $item->libelleType->Text );
				$tTraductionLibelleType->addTTraductionLibelle ( $tTraductionLibelle );
			}
			//fin
			$tTypePrestation->setTTraduction($tTraductionLibelleType);
		} else {
			$tTypePrestation->setIdRefTypePrestation($this->listeRefTypePrestation->getSelectedValue());
		}

		$tTypePrestation->setIdEtablissement($this->listeEtablissement->getSelectedValue());

		$tTypePrestation->setVisibleCitoyen((int)$this->visibleOui->checked);
		$tTypePrestation->save();

		$url = "index.php?page=administration.GestionTypesPrestations&search";
		$this->response->redirect($url);
	}

	public function checkRef() {
		$idOrganisation=$this->listeOrganisation->getSelectedValue();
		$tOrganisationQuery = new TOrganisationQuery();
		$tOrganisation = $tOrganisationQuery->getOrganisationById($idOrganisation);
		$typePrestation = $tOrganisation->getTypePrestation();
		$this->setViewState("refTypePrestation", $typePrestation);
		if($typePrestation==0) {
			self::getListeLibelleTypeParLangues($this->_dataLibelleType);
			$this->panelRef->Visible=false;
			$this->panelSaisie->Visible=true;
		}
		else {
			$this->panelSaisie->Visible=false;
			$this->panelRef->Visible=true;
			$this->loadRefTypePrestation();
		}
	}
	/**
	 * Remplir la liste des refPrestations
	 */
	public function loadRefTypePrestation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$RefPrestationGestion = new Atexo_RefPrestation_Gestion();
		$this->listeRefTypePrestation->DataSource = $RefPrestationGestion->getRefTypePrestationByIdOrganisation($lang,$this->listeOrganisation->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->listeRefTypePrestation->DataBind();
	}
}