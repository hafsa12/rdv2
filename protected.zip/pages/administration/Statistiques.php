<?php


class Statistiques extends AtexoPage {

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::isAdminSys()) {
			$this->response->redirect("?page=administration.AdministrationAccueil");
		}
		if(!$this->isPostBack){
			$this->setViewState("dateDebut", '');
			$this->setViewState("dateFin", '');
		}
		$this->loadOrganisation();
	}

	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('ORGANISATION'));
		$this->listeOrganisation->DataBind();
	}

	public function search(){
		$criteriaVo = new Atexo_RendezVous_CriteriaVo();
		if($this->listeOrganisation->SelectedValue){
			$criteriaVo->setIdOrganisationAttache($this->listeOrganisation->SelectedValue);
		}
		if($this->datedebut->SafeText){
			$criteriaVo->setDateDuCreation($this->datedebut->SafeText);
			$this->setViewState("dateDebut", $this->datedebut->SafeText);
		}
		if($this->datefin->SafeText){
			$criteriaVo->setDateAuCreation($this->datefin->SafeText);
			$this->setViewState("dateFin", $this->datefin->SafeText);
		}
		
		$this->statRdvRecu->drawStat($criteriaVo);
        $this->statRdvRecu->Visible=true;
	}
}