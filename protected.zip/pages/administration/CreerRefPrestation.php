<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerRefPrestation extends AtexoPage {

	private $_dataLibelleRef = null;
    private $_dataAideRef = null;
	protected $typeChamp = array();

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionRefPrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		$this->loadTypeChamps();
		if(!$this->isPostBack) {

			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();

			$this->loadOrganisation();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}

			if(isset($_GET["idRefPrestation"])) {
				$this->remplir($_GET["idRefPrestation"]);
			}

			self::getListeLibelleRefParLangues($this->_dataLibelleRef);
			self::getListeAideRefParLangues($this->_dataAideRef);
		}
	}

	public function loadTypeChamps() {

		$this->typeChamp = array(
			" " => Prado::localize('SELECTIONNEZ'),
			"TEXT" => Prado::localize('TEXT'),
			"NUMERIC" => Prado::localize('NUMERIC'),
			"LISTE" => Prado::localize('LISTE'),
			"MULTICHOIX" => Prado::localize('MULTICHOIX')
		);
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}

	/**
	 * @param $data
	 * récuperer repeater libelle du type-prestation
	 */
	public function getListeLibelleRefParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeLibelleRefParLangues($data);
		} else {
			//recupérer les langues
			$langues= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues as $lan){
				$data[$index]['libelleRefLibelleLang'] = Prado::localize('LIBELLE_REFERENTIEL_PRESTATION');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['libelleRef'] = '';
				$data[$index]['langLibelleRef'] = $lan;
				$index++;
			}
			$this->setListeLibelleRefParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater libelle du type-prestation
	 */
	public function setListeLibelleRefParLangues($data) {
		$this->listeLibelleRefLangues->dataSource = $data;
		$this->listeLibelleRefLangues->dataBind();
		$index = 0;
		foreach ($this->listeLibelleRefLangues->getItems() as $item) {
			$item->libelleRefLibelleLang->Text = $data[$index]['libelleRefLibelleLang'];
			$item->lang->Text = $data[$index]['lang'];
			$item->libelleRef->Text = $data[$index]['libelleRef'];
			$item->langLibelleRef->Value = $data[$index]['langLibelleRef'];
			$index++;
		}
	}


    public function getListeAideRefParLangues($data=null) {
        if(count($data) > 0) {
            $this->setListeAideRefParLangues($data);
        } else {
            //recupérer les langues
            $langues= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

            $data = array();
            $index=0;
            foreach($langues as $lan){
                $data[$index]['aideRefLibelleLang'] = Prado::localize('AIDE_REFERENTIEL_PRESTATION');
                $data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
                $data[$index]['aideRef'] = '';
                $data[$index]['langLibelleRef'] = $lan;
                $index++;
            }
            $this->setListeAideRefParLangues($data);
        }
    }

    /**
     * @param $data
     * remplir repeater libelle du type-prestation
     */
    public function setListeAideRefParLangues($data) {
        $this->listeAideRefLangues->dataSource = $data;
        $this->listeAideRefLangues->dataBind();
        $index = 0;
        foreach ($this->listeAideRefLangues->getItems() as $item) {
            $item->aideRefLibelleLang->Text = $data[$index]['aideRefLibelleLang'];
            $item->lang->Text = $data[$index]['lang'];
            $item->aideRef->Text = $data[$index]['aideRef'];
            $item->langLibelleRef->Value = $data[$index]['langLibelleRef'];
            $index++;
        }
    }
	/**
	 * enregistrer les informations de référentiel prestation
	 */
	public function enregistrer() {

		if(isset($_GET["idRefPrestation"])) {
			$tRefPrestationQuery = new TRefPrestationQuery();
			$tRefPrestation = $tRefPrestationQuery->getRefPrestationById($_GET["idRefPrestation"]);
			$tTraductionLibelleRef = $tRefPrestation->getTTraductionRelatedByCodeLibelle();
            $tTraductionAideRef = $tRefPrestation->getTTraductionRelatedByCodeAide();

            if(!isset($tTraductionLibelleRef)) {
                $tTraductionLibelleRef = new TTraduction();
            }
            if(!isset($tTraductionAideRef)) {
                $tTraductionAideRef = new TTraduction();
            }

			$tParametreForm = $tRefPrestation->getTParametreForm();

			if(!$tParametreForm) {
				$tParametreForm = new TParametreForm();
			}
		}

		if(!($tRefPrestation instanceof TRefPrestation)) {
			$tRefPrestation = new TRefPrestation();
			$tTraductionLibelleRef = new TTraduction();
            $tTraductionAideRef = new TTraduction();
			$tParametreForm = new TParametreForm();
		}

		//boucle
		foreach($this->listeLibelleRefLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionLibelleRef->getTTraductionLibelle($item->langLibelleRef->Value);
			$tTraductionLibelle->setLang($item->langLibelleRef->Value);
			$tTraductionLibelle->setLibelle($item->libelleRef->SafeText);
			$tTraductionLibelleRef->addTTraductionLibelle($tTraductionLibelle);
		}

        foreach($this->listeAideRefLangues->getItems() as $item) {
            $tTraductionAide = $tTraductionAideRef->getTTraductionLibelle($item->langLibelleRef->Value);
            $tTraductionAide->setLang($item->langLibelleRef->Value);
            $tTraductionAide->setLibelle($item->aideRef->SafeText);
            $tTraductionAideRef->addTTraductionLibelle($tTraductionAide);
        }
		//fin
		$tRefPrestation->setTTraductionRelatedByCodeLibelle($tTraductionLibelleRef);
        $tRefPrestation->setTTraductionRelatedByCodeAide($tTraductionAideRef);

		$tRefPrestation->setIdOrganisation($this->listeOrganisation->getSelectedValue());
		$tRefPrestation->setDureeRdv($this->inputDureeRdv->SafeText);

		$tParametreForm = $this->enregistrerParamForm($tParametreForm);
		$tRefPrestation->setTParametreForm($tParametreForm);

		$tRefPrestation->save();

		$url = "index.php?page=administration.GestionRefPrestation&search";
		$this->response->redirect($url);
	}

	public function enregistrerParamForm($tParametreForm) {
		$i=1;
		$tTraductionChamps[0] = $tParametreForm->getTTraductionRelatedByCodeLibelleText1();
		$tTraductionChamps[1] = $tParametreForm->getTTraductionRelatedByCodeLibelleText2();
		$tTraductionChamps[2] = $tParametreForm->getTTraductionRelatedByCodeLibelleText3();
		foreach ($this->listeChamps->getItems() as $listes) {

			$fctActif = "setText".$i."Actif";

			$tParametreForm->$fctActif('1');

			$fctObligatoire = "setObligatoireText".$i;
			if($listes->ouiChamps->checked){
				$tParametreForm->$fctObligatoire('1');
			}
			else{
				$tParametreForm->$fctObligatoire('0');
			}

			foreach ($listes->listeChampsLangues->getItems() as $item) {
				if(!isset($tTraductionChamps[$listes->ItemIndex])) {
					$tTraductionChamps[$listes->ItemIndex] = new TTraduction();
				}
				$tTraductionLibelle = $tTraductionChamps[$listes->ItemIndex]->getTTraductionLibelle($item->langChamps->Value);
				$tTraductionLibelle->setLang($item->langChamps->Value);
				$tTraductionLibelle->setLibelle($item->champs->SafeText);
				$tTraductionChamps[$listes->ItemIndex]->addTTraductionLibelle($tTraductionLibelle);
				$tTraductionChamps[$listes->ItemIndex]->save();
			}
			$fctType = "setText".$i."Type";
			$fctListe = "setText".$i."Liste";
			$tParametreForm->$fctType($listes->typeChamp->SelectedValue);
			if($listes->typeChamp->SelectedValue == "LISTE" || $listes->typeChamp->SelectedValue == "MULTICHOIX") {
				$valeurs = json_encode(array("fr"=>$listes->listeValuesFr->Value,"ar"=>$listes->listeValuesAr->Value));
				$tParametreForm->$fctListe($valeurs);
			}
			else {
				$tParametreForm->$fctListe(null);
			}
			$i++;
		}
		for($j=$i;$j<=3;$j++) {
			$fctActif = "setText".$j."Actif";
			$tParametreForm->$fctActif('0');
		}

		$tParametreForm->setTTraductionRelatedByCodeLibelleText1($tTraductionChamps[0]);
		$tParametreForm->setTTraductionRelatedByCodeLibelleText2($tTraductionChamps[1]);
		$tParametreForm->setTTraductionRelatedByCodeLibelleText3($tTraductionChamps[2]);

		return $tParametreForm;
	}

	/**
	 * @param $idRefPrestation
	 * récuperer les informations du refPrestation
	 */
	public function remplir($idRefPrestation) {
		$tRefPrestationQuery = new TRefPrestationQuery();
		$tRefPrestation = $tRefPrestationQuery->getRefPrestationById($idRefPrestation);

		if ($tRefPrestation instanceof TRefPrestation){

			$this->listeOrganisation->SelectedValue = $tRefPrestation->getIdOrganisation();
			$this->inputDureeRdv->Text = $tRefPrestation->getDureeRdv();
			//recupérer les langues
			$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$index=0;
            foreach($langues as $lan){
                $this->_dataLibelleRef[$index]['libelleRef'] = $tRefPrestation->getLibelleRefPrestationTraduit($lan);
                $this->_dataLibelleRef[$index]['libelleRefLibelleLang'] = Prado::localize('LIBELLE_REFERENTIEL_PRESTATION');
                $this->_dataLibelleRef[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
                $this->_dataLibelleRef[$index]['langLibelleRef'] = $lan;
                $index++;
            }
            $index=0;
            foreach($langues as $lan){
                $this->_dataAideRef[$index]['aideRef'] = $tRefPrestation->getAideRefPrestationTraduit($lan);
                $this->_dataAideRef[$index]['aideRefLibelleLang'] = Prado::localize('AIDE_REFERENTIEL_PRESTATION');
                $this->_dataAideRef[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
                $this->_dataAideRef[$index]['langLibelleRef'] = $lan;
                $index++;
            }
			if($tRefPrestation->getIdParametreForm()>0) {
				$tParamForm = $tRefPrestation->getTParametreForm();
				$data=array();
				$i=0;
				if($tParamForm->getText1Actif()) {
					$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText1();
					$data[$i]["obligatoire"]=$tParamForm->getObligatoireText1();
					$data[$i]["typeChamp"]=$tParamForm->getText1Type();
					$liste = json_decode($tParamForm->getText1Liste(), true);
					$data[$i]["listeValuesFr"]=$liste["fr"];
					$data[$i]["listeValuesAr"]=$liste["ar"];
					$i++;
				}
				if($tParamForm->getText2Actif()) {
					$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText2();
					$data[$i]["obligatoire"]=$tParamForm->getObligatoireText2();
					$data[$i]["typeChamp"]=$tParamForm->getText2Type();
					$liste = json_decode($tParamForm->getText2Liste(), true);
					$data[$i]["listeValuesFr"]=$liste["fr"];
					$data[$i]["listeValuesAr"]=$liste["ar"];
					$i++;
				}
				if($tParamForm->getText3Actif()) {
					$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText3();
					$data[$i]["obligatoire"]=$tParamForm->getObligatoireText3();
					$data[$i]["typeChamp"]=$tParamForm->getText3Type();
					$liste = json_decode($tParamForm->getText3Liste(), true);
					$data[$i]["listeValuesFr"]=$liste["fr"];
					$data[$i]["listeValuesAr"]=$liste["ar"];
				}
				$this->listeChamps->DataSource = $data;
				$this->listeChamps->DataBind();
				$i=0;
				foreach($this->listeChamps->getItems() as $item) {
					$item->ouiChamps->checked = ($data[$i]["obligatoire"]==1);
					$item->nonChamps->checked = ($data[$i]["obligatoire"]==0);
					$item->typeChamp->SelectedValue = $data[$i]["typeChamp"];
					$item->listeValuesFr->Value = $data[$i]["listeValuesFr"];
					$item->listeValuesAr->Value = $data[$i]["listeValuesAr"];
					$item->listeChampsLangues->DataSource = $langues;
					$item->listeChampsLangues->DataBind();
					$index=0;
					$tTraductionLibelles = $data[$i]["libelle"]->getTTraductionLibelles();
					foreach($item->listeChampsLangues->getItems() as $itemLang){
						$tTraductionLibelle = $tTraductionLibelles[$index];
						$itemLang->champsLibelleLang->Text = Prado::localize('LIBELLE');
						$itemLang->lang->Text = '('.Prado::localize('LANG_'.strtoupper($tTraductionLibelle->getLang())).')';
						$itemLang->champs->Text = $tTraductionLibelle->getLibelle();
						$itemLang->langChamps->Value = $tTraductionLibelle->getLang();
						$index++;
					}
					$i++;
				}
			}
		}
	}

	/**
	 * @param $nbreLigneAAjouter
	 * Récupérer les champs paramétrables
	 */
	public function getDataLigne($nbreLigneAAjouter=0) {
		$index = 0;
		$data = array();
		$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		foreach ($this->listeChamps->getItems() as $listes) {
			$data[$index]['langChamps'] = '';
			$dataChamps = array();
			$indexChamps = 0;
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataChamps[$langues[$indexChamps]]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$langues[$indexChamps]]['lang'] = '('.Prado::localize('LANG_'.strtoupper($langues[$indexChamps])).')';
				$dataChamps[$langues[$indexChamps]]['champs'] = $item->champs->SafeText;
				$dataChamps[$langues[$indexChamps]]['langChamps'] = $langues[$indexChamps];
				$indexChamps++;
			}
			$data[$index]['dataChamp'] = $dataChamps;
			$data[$index]['obligatoire'] = $listes->ouiChamps->Checked;
			$data[$index]['typeChamp'] = $listes->typeChamp->SelectedValue;
			$data[$index]['listeValuesFr'] = $listes->listeValuesFr->Value;
			$data[$index]['listeValuesAr'] = $listes->listeValuesAr->Value;
			$index++;
		}
		if($nbreLigneAAjouter>0) {
			if(count($data)==0) {
				$index = 0;

			}
			$dataChamps = array();
			$data[$index]['langChamps'] = "";
			foreach ($langues as $lan) {
				$dataChamps[$lan]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$lan]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$dataChamps[$lan]['champs'] = '';
				$dataChamps[$lan]['langChamps'] = $lan;
			}
			$data[$index]['dataChamp'] = $dataChamps;
		}

		return $data;

	}

	/**
	 * @param $nbreLigneAAjouter
	 * Ajouer un champ paramétrable
	 */
	public function ajouterChamps($sender, $param) {
		$nbreLigneAAjouter = 1;
		$data =  $this->getDataLigne($nbreLigneAAjouter);
		$this->remplirRepeaterChamps($data);
		if(count($data)>2) {
			$this->btnAjoutChamp->setStyle('display:none');
		}
		$this->listeChampsPanel->setStyle('display:block');
		$this->listeChampsPanel->render($param->NewWriter);
	}


	/**
	 *
	 * Supprimer un champ
	 */
	public function deleteLigneChamps($sender,$param)
	{
		$data = array();
		$itemIndex = $sender->CommandParameter;
		$dataChamps = $this->getDataLigne();
		unset($dataChamps[$itemIndex]);
		$data = array_values($dataChamps);
		$this->remplirRepeaterChamps($data);

		$this->btnAjoutChamp->setStyle('display:block');
		$this->listeChampsPanel->render($param->NewWriter);
	}

	/**
	 * @param $data
	 * Remplir liste des champs paramétrables
	 */
	public function remplirRepeaterChamps($data) {
		$this->listeChamps->dataSource = $data;
		$this->listeChamps->dataBind();
		$index = 0;
		foreach ($this->listeChamps->getItems() as $listes) {
			$dataChamps = $data[$index]['dataChamp'];
			$listes->listeChampsLangues->dataSource = $dataChamps;
			$listes->listeChampsLangues->dataBind();
			$indexChamps = 0;
			$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$listes->ouiChamps->checked = ($data[$index]["obligatoire"]);
			$listes->nonChamps->checked = !($data[$index]["obligatoire"]);
			$listes->typeChamp->SelectedValue = $data[$index]['typeChamp'];
			$listes->listeValuesFr->Value = $data[$index]['listeValuesFr'];
			$listes->listeValuesAr->Value = $data[$index]['listeValuesAr'];

			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataLang = $dataChamps[$langues[$indexChamps]];
				$item->champsLibelleLang->Text = $dataLang['champsLibelleLang'];
				$item->champs->Text = $dataLang['champs'];
				$item->langChamps->value = $langues[$indexChamps];
				$item->lang->Text = $dataLang['lang'];
				$indexChamps++;
			}
			$index++;
		}
	}
}
