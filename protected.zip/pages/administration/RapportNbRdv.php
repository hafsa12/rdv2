<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class RapportNbRdv extends AtexoPage {

	private $_lang = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('RapportNbrRdv')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack) {
			$idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
			if($idOrg>0) {
				$tOrganisationQuery = new TOrganisationQuery();
				$tOrganisation = $tOrganisationQuery->getOrganisationById($idOrg);
				$typePrestation = $tOrganisation->getTypePrestation();
			}
			else {
				$typePrestation = Atexo_Config::getParameter('PRESTATION_SAISIE_LIBRE');
			}
			$this->loadEntite1();
			$this->loadEntite2();
			$this->loadEntite3();
			$this->setViewState("typePrestation", $typePrestation);
		}
	}

	/**
	 * Remplir la liste des regions
	 */
	public function loadEntite1() {
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite1->DataSource = $entiteGestion->getAllEntite(1, $this->_lang, null, Prado::localize('ENTITE_1'));
		$this->entite1->DataBind();
	}

	/**
	 * Remplir la liste des provinces
	 */
	public function loadEntite2($sender = null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
		$this->entite2->DataBind();
		if($sender) {
			$this->loadEntite3();
		}
	}

	/**
	 * Remplir la liste des communes
	 */
	public function loadEntite3($sender = null) {
		$entiteGestion = new Atexo_Entite_Gestion();
		$idEntite = null;

		if($this->entite2->SelectedValue) {
			$idEntite = $this->entite2->SelectedValue;
		}elseif($this->entite1->SelectedValue){
			$idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
		}

		$this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
		$this->entite3->DataBind();
	}

	protected function getCriteria() {
		$dateDu=$this->datedebut->SafeText;
		$dateAu=$this->datefin->SafeText;
		$dateCreationDu=$this->datedebutCreation->SafeText;
		$dateCreationAu=$this->datefinCreation->SafeText;
		$criteriaVo = new Atexo_RendezVous_CriteriaVo();
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$criteriaVo->setLang($lang);
		$criteriaVo->setNonAnnule();

		if($dateDu!=null) {
			$criteriaVo->setDateDu($dateDu);
		}

		if($dateAu!=null) {
			$criteriaVo->setDateAu($dateAu);
		}

		if($dateCreationDu!=null) {
			$criteriaVo->setDateDuCreation($dateCreationDu);
		}
		if($dateCreationAu!=null) {
			$criteriaVo->setDateAuCreation($dateCreationAu);
		}

		if ( $this->entite1->getSelectedValue () > 0 ) {
			$criteriaVo->setIdEntite ( $this->entite1->getSelectedValue () );
		}
		if ( $this->entite2->getSelectedValue () > 0 ) {
			$criteriaVo->setIdEntite ( $this->entite2->getSelectedValue () );
		}
		if ( $this->entite3->getSelectedValue () > 0 ) {
			$criteriaVo->setIdEntite ( $this->entite3->getSelectedValue () );
		}

		$criteriaVo->setIdEtablissementAttache(Atexo_User_CurrentUser::getIdEtablissementGere());

		$idOrg = Atexo_User_CurrentUser::getIdOrganisationGere();
		if($idOrg>0) {
			$criteriaVo->setIdOrganisationAttache($idOrg);
		}

		return $criteriaVo;
	}

	public function genererExcel() {

		$criteriaVo = $this->getCriteria();
		$rdvPeer = new TRendezVousPeer();
		$dataMode = $rdvPeer->getNbRdvByMode($criteriaVo);
		$dataMois = $rdvPeer->getNbRdvByMois($criteriaVo);
		$dataAnnee = $rdvPeer->getNbRdvByAnnee($criteriaVo);
		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$dataRefTypePresta = $rdvPeer->getNbRdvByRefTypePrestation($criteriaVo);
			$dataRefPresta = $rdvPeer->getNbRdvByRefPrestation($criteriaVo);
		}
		$dataEtab = $rdvPeer->getNbRdvByEtab($criteriaVo);
		$dataEntite1 = $rdvPeer->getNbRdvByEntite1($criteriaVo);

		$objPHPExcel = new PHPExcel();

		$objWorksheet = $objPHPExcel->getActiveSheet();
		$this->getWorkSheet($objWorksheet,$dataMode,"PAR_MODE", Prado::localize("REPARTITION_MODE"),PHPExcel_Chart_DataSeries::TYPE_PIECHART, false, false, false);

		$i=0;
	/*	if(Atexo_User_CurrentUser::getIdEtablissementGere()=="" || count(explode(',',Atexo_User_CurrentUser::getIdEtablissementGere()))>1) {
			$objPHPExcel->createSheet();
			$objPHPExcel->setActiveSheetIndex($i);
			$objWorksheet = $objPHPExcel->getActiveSheet();
			$this->getWorkSheet($objWorksheet, $dataEtab, "PAR_ETABLISSEMENT", Prado::localize("REPARTITION_ETAB"), PHPExcel_Chart_DataSeries::TYPE_BARCHART, true);
			$i++;
		}

		$objPHPExcel->createSheet();
		$objPHPExcel->setActiveSheetIndex($i);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$this->getWorkSheet($objWorksheet,$dataMois,"PAR_MOIS", Prado::localize("REPARTITION_MOIS"),PHPExcel_Chart_DataSeries::TYPE_BARCHART, true, false, true, false);
		$i++;

		$objPHPExcel->createSheet();
		$objPHPExcel->setActiveSheetIndex($i);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$this->getWorkSheet($objWorksheet,$dataAnnee,"PAR_ANNEE", Prado::localize("REPARTITION_ANNEE"),PHPExcel_Chart_DataSeries::TYPE_BARCHART, true, false, true, false);
		$i++;
*/
		if($_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$objPHPExcel->createSheet();
			$objPHPExcel->setActiveSheetIndex($i);
			$objWorksheet = $objPHPExcel->getActiveSheet();
			$this->getWorkSheet($objWorksheet, $dataRefTypePresta, "PAR_TYPE_PRESTATION", Prado::localize("REPARTITION_TYPE_PRESTATION"), PHPExcel_Chart_DataSeries::TYPE_PIECHART);
			$i++;

			$objPHPExcel->createSheet();
			$objPHPExcel->setActiveSheetIndex($i);
			$objWorksheet = $objPHPExcel->getActiveSheet();
			$this->getWorkSheet($objWorksheet, $dataRefPresta, "PAR_PRESTATION", Prado::localize("REPARTITION_PRESTATION"), PHPExcel_Chart_DataSeries::TYPE_BARCHART);
		//	$i++;
		}

		if(Atexo_User_CurrentUser::isAdminOrg() && !Atexo_User_CurrentUser::getIdEtablissementAttache() && !$criteriaVo->getIdEntite()) {
		//	$objPHPExcel->createSheet();
		//	$objPHPExcel->setActiveSheetIndex($i);
		//	$objWorksheet = $objPHPExcel->getActiveSheet();
		//	$this->getWorkSheet($objWorksheet, $dataEntite1, "PAR_REGION", Prado::localize("REPARTITION_REGION"), PHPExcel_Chart_DataSeries::TYPE_BARCHART, true);
			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			$objWriter->setIncludeCharts(TRUE);
		}

		$this->getFileExcel($objPHPExcel);
	}

	public function genererExcelEtat() {

		$criteriaVo = $this->getCriteria();
		$rdvPeer = new TRendezVousPeer();
		$dataMode = $rdvPeer->getNbRdvByEtatAndMode($criteriaVo);
		$dataMois = $rdvPeer->getNbRdvByEtatAndMois($criteriaVo);
		$dataAnnee = $rdvPeer->getNbRdvByEtatAndAnnee($criteriaVo);
		$dataEtab = $rdvPeer->getNbRdvByEtatAndEtab($criteriaVo);
		$dataEntite1 = $rdvPeer->getNbRdvByEtatAndEntite1($criteriaVo);

		$objPHPExcel = new PHPExcel();

		$objWorksheet = $objPHPExcel->getActiveSheet();
		$this->getWorkSheet($objWorksheet,$dataMode,"PAR_ETAT", Prado::localize("REPARTITION_ETAT"),PHPExcel_Chart_DataSeries::TYPE_BARCHART, false, true, false);

		$i=1;
		$objPHPExcel->createSheet();
		$objPHPExcel->setActiveSheetIndex($i);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$this->getWorkSheet($objWorksheet,$dataEtab,"PAR_ETABLISSEMENT", Prado::localize("REPARTITION_ETAB"),PHPExcel_Chart_DataSeries::TYPE_BARCHART, false, true);
		$i++;

		$objPHPExcel->createSheet();
		$objPHPExcel->setActiveSheetIndex($i);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$this->getWorkSheet($objWorksheet,$dataMois,"PAR_MOIS", Prado::localize("REPARTITION_MOIS"),PHPExcel_Chart_DataSeries::TYPE_BARCHART, false, true, true, false);
		$i++;

		$objPHPExcel->createSheet();
		$objPHPExcel->setActiveSheetIndex($i);
		$objWorksheet = $objPHPExcel->getActiveSheet();
		$this->getWorkSheet($objWorksheet,$dataAnnee,"PAR_ANNEE", Prado::localize("REPARTITION_ANNEE"),PHPExcel_Chart_DataSeries::TYPE_BARCHART, false, true, true, false);
		$i++;

		if(Atexo_User_CurrentUser::isAdminOrg() && !Atexo_User_CurrentUser::getIdEtablissementAttache() && !$criteriaVo->getIdEntite()) {
//			$objPHPExcel->createSheet();
//			$objPHPExcel->setActiveSheetIndex($i);
//			$objWorksheet = $objPHPExcel->getActiveSheet();
//			$this->getWorkSheet($objWorksheet, $dataEntite1, "PAR_REGION", Prado::localize("REPARTITION_REGION"), PHPExcel_Chart_DataSeries::TYPE_BARCHART, false, true);

			$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			$objWriter->setIncludeCharts(TRUE);
		}

		$this->getFileExcel($objPHPExcel);
	}

	private function getWorkSheet(&$objWorksheet, $data, $name, $titreGraphe, $typeChart, $withMode=false, $withEtat=false, $withMaxMin=true, $withTri=true) {
		$max = 3;
		if($withMode) {
			$libelle2 = array(0 => array(" ", Prado::localize('WEB'),Prado::localize('PHONE'),Prado::localize('SUR_PLACE'),Prado::localize('APPLICATION_MOBILE'),Prado::localize('NOMBRE_TOTAL')));
		
		}
		elseif($withEtat) {
			$libelle2 = array(0 => array(" ", Prado::localize('EN_ATTENTE'),Prado::localize('CONFIRME'),Prado::localize('NON_HONORE_CITOYEN'),Prado::localize('ANNULE_CITOYEN'),Prado::localize('NON_HONORE_ETAB'),Prado::localize('ANNULE_ETAB'),Prado::localize('NOMBRE_TOTAL')));
			$max = 5;
		}
		else {
			$libelle2 = array(0 => array(" ", "Nombre"));
		}
		$i=1;
		foreach($data as $ligne) {
			$libelle2[$i][] = $ligne["LIBELLE"];
			if($withMode || $withEtat) {
				$total = 0;
				for($mode=0;$mode<=$max;$mode++) {
					if(isset($ligne["MODE"][$mode])) {
						$libelle2[$i][] = $ligne["MODE"][$mode]["NBR"];
						$total += $ligne["MODE"][$mode]["NBR"];
					}
					else {
						$libelle2[$i][] = "0";
					}
				}
				$libelle2[$i][count($libelle2[0])-1] += $total;
			}
			else {
				$libelle2[$i][] = $ligne["NBR"];
			}
			$i++;
		}
		if(($withMode || $withEtat) && $withTri) {
			$sorted = array();
			foreach ($libelle2 as $ligne) {
				$sorted[(int)$ligne[count($libelle2[0])-1]] = $ligne;
			}
			ksort ($sorted);
			$libelle2 = $sorted;
		}
		$style = array(
			'font' => array('bold' => true,),
			'alignment' => array('horizontal' => \PHPExcel_Style_Alignment::HORIZONTAL_CENTER,),
			'borders' => array(
				'allborders' => array(
					'style' => PHPExcel_Style_Border::BORDER_THIN
				)
			)
		);
		$objWorksheet->getStyle('b25:b25')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
		$objWorksheet->getStyle('b25:b'.(count($libelle2)+24))->applyFromArray($style);
		$objWorksheet->getStyle('a26:a'.(count($libelle2)+24))->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
		$objWorksheet->getStyle('a26:a'.(count($libelle2)+24))->applyFromArray($style);
		if($withMode || $withEtat) {
			$objWorksheet->getStyle('c25:c25')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->getStyle('c25:c'.(count($libelle2)+24))->applyFromArray($style);
			$objWorksheet->getStyle('d25:d25')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->getStyle('d25:d'.(count($libelle2)+24))->applyFromArray($style);
			$objWorksheet->getStyle('e25:e25')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->getStyle('e25:e'.(count($libelle2)+24))->applyFromArray($style);
			$objWorksheet->getStyle('f25:f25')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->getStyle('f25:f'.(count($libelle2)+24))->applyFromArray($style);
		}
		if($withEtat) {
			$objWorksheet->getStyle('g25:g25')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->getStyle('g25:g'.(count($libelle2)+24))->applyFromArray($style);
			$objWorksheet->getStyle('h25:h25')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->getStyle('h25:h'.(count($libelle2)+24))->applyFromArray($style);
		}

		for ($col = ord('a'); $col <= ord('h'); $col++)
		{
			$objWorksheet->getColumnDimension(chr($col))->setAutoSize(true);
		}

		$objWorksheet->setTitle($name);

		$objWorksheet->fromArray($libelle2, null, "A25");


		if($withMode) {
			$dataSeriesLabels2 = array(
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$B$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$C$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$D$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$E$25', NULL, 1),
			);

			$dataSeriesValues2 = array(
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$B$26:$B$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$C$26:$C$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$D$26:$D$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$E$26:$E$' . (count($libelle2)+24), NULL, count($libelle2)),
			);
			$plot = PHPExcel_Chart_DataSeries::GROUPING_STACKED;

			$startFormula = "F26";
			$finFormula  = "F".(count($libelle2)+24);
		}
		elseif($withEtat) {
			$dataSeriesLabels2 = array(
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$B$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$C$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$D$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$E$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$F$25', NULL, 1),
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$G$25', NULL, 1),
			);

			$dataSeriesValues2 = array(
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$B$26:$B$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$C$26:$C$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$D$26:$D$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$E$26:$E$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$F$26:$F$' . (count($libelle2)+24), NULL, count($libelle2)),
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$G$26:$G$' . (count($libelle2)+24), NULL, count($libelle2)),
			);
			$plot = PHPExcel_Chart_DataSeries::GROUPING_STACKED;

			$startFormula = "H26";
			$finFormula  = "H".(count($libelle2)+24);
		}
		else {
			$dataSeriesLabels2 = array(
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$B$25', NULL, 1),	//	2011
			);

			$dataSeriesValues2 = array(
				new PHPExcel_Chart_DataSeriesValues('Number', $name . '!$B$26:$B$' . (count($libelle2)+24), NULL, count($libelle2)),
			);
			$plot = NULL;

			$startFormula = "B26";
			$finFormula  = "B".(count($libelle2)+24);
		}

		$xAxisTickValues2 = array(
				new PHPExcel_Chart_DataSeriesValues('String', $name.'!$A$26:$A$'.(count($libelle2)+24), NULL, count($libelle2)),	//	Q1 to Q4
			);

//	Build the dataseries
		$series1 = new PHPExcel_Chart_DataSeries(
			$typeChart,				// plotType
			$plot,			                                        // plotGrouping (Pie charts don't have any grouping)
			range(0, count($dataSeriesValues2)-1),					// plotOrder
			$dataSeriesLabels2,										// plotLabel
			$xAxisTickValues2,										// plotCategory
			$dataSeriesValues2										// plotValues
		);
//	Set up a layout object for the Pie chart
		$layout1 = new PHPExcel_Chart_Layout();
		$layout1->setShowVal(FALSE);
		$layout1->setShowPercent(TRUE);
//	Set the series in the plot area
		$plotArea1 = new PHPExcel_Chart_PlotArea($layout1, array($series1));
//	Set the chart legend
		$legend1 = new PHPExcel_Chart_Legend(PHPExcel_Chart_Legend::POSITION_RIGHT, NULL, false);
		$title1 = new PHPExcel_Chart_Title($titreGraphe);
//	Create the chart
		$chart2 = new PHPExcel_Chart(
			'chart1',		// name
			$title1,		// title
			$legend1,		// legend
			$plotArea1,		// plotArea
			true,			// plotVisibleOnly
			0,				// displayBlanksAs
			NULL,			// xAxisLabel
			NULL			// yAxisLabel		- Pie charts don't have a Y-Axis
		);
//	Set the position where the chart should appear in the worksheet
		$fin = chr(max(69,min(90,64+count($libelle2)))).'20';
		$chart2->setTopLeftPosition('A1');
		$chart2->setBottomRightPosition($fin);

		if($withMaxMin) {
			$objWorksheet->getStyle('A21:B23')->applyFromArray($style);
			$objWorksheet->getStyle('A21:A21')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->setCellValue('A21', 'MIN');
			$objWorksheet->setCellValue('B21', '=MIN(' . $startFormula . ':' . $finFormula . ')');
			$objWorksheet->getStyle('A22:A22')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->setCellValue('A22', 'MAX');
			$objWorksheet->setCellValue('B22', '=MAX(' . $startFormula . ':' . $finFormula . ')');
			$objWorksheet->getStyle('A23:A23')->getFill()->setFillType(\PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setARGB('00eeeeee');
			$objWorksheet->setCellValue('A23', 'MOYENNE');
			$objWorksheet->setCellValue('B23', '=ROUND(AVERAGE(' . $startFormula . ':' . $finFormula . '),2)');
		}
		//	Add the chart to the worksheet
		$objWorksheet->addChart($chart2);
	}

	public function getFileExcel($objPHPExcel){
		// Save Excel 2007 file
		header('Content-Type: application/vnd.ms-excel');
		//header('Content-Disposition: attachment;filename="name_of_file.xls"');
		header('Content-Disposition: attachment;filename="export_'.date('Y_m_d').'.xlsx"');
		header('Cache-Control: max-age=0');
		$objPHPExcel->setActiveSheetIndex(0);
		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		$objWriter->setIncludeCharts(TRUE);

		$objWriter->save('php://output');exit;
	}

}
