<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class GestionRessources extends AtexoPage {

	private $_lang = "";
	/**
	 * @var Atexo_Agent_CriteriaVo
	 */
	protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionRessource')) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack) {
			if(!isset($_GET["search"])) {
				unset($_SESSION["ressources"]["criteriaVoSearch"]);
				unset($_SESSION["ressources"]["sensTri"]);
				unset($_SESSION["ressources"]["sortByElement"]);
			}
			$this->init();
		}else{
            $this->_criteriaVo = $_SESSION["ressources"]["criteriaVoSearch"];
        }
	}

	protected function init()
	{
        $this->_criteriaVo = $_SESSION["ressources"]["criteriaVoSearch"];
        
		$adminOrg = Atexo_User_CurrentUser::isAdminOrg ();
		$adminEtab = Atexo_User_CurrentUser::isAdminEtab () || Atexo_User_CurrentUser::isAdminOrgWithEtab();
		$this->remplirListeOrganisation ();

        if(!$this->_criteriaVo)
        {
            $this->loadEntite1();
            $this->loadEntite2();
            $this->loadEntite3();
            $this->loadDataEtablissement ();

            $this->_criteriaVo = new Atexo_Agent_CriteriaVo();

            if ( $adminOrg ) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
                $this->_criteriaVo->setIdOrganisationAttache ( $idOrganisation );
                $this->organisationRessource->SelectedValue = $idOrganisation;
                $this->organisationRessource->Enabled = false;
                $this->loadDataEtablissement();
                $this->etablissementRessource->SelectedIndex = 0;
                $this->_criteriaVo->setIdEtablissementAttache ( $this->etablissementRessource->getSelectedValue () );
            }
            if ( $adminEtab ) {
                $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache ();
                $this->_criteriaVo->setIdOrganisationAttache ( $idOrganisation );
                $this->organisationRessource->SelectedValue = $idOrganisation;
                $this->organisationRessource->Enabled = false;

                $this->loadDataEtablissement();
                //$idEtablissement = Atexo_User_CurrentUser::getIdEtablissementGere ();
                //$this->_criteriaVo->setIdEtablissementAttache ( $idEtablissement );
                //$this->etablissementRessource->setSelectedValue ( $idEtablissement );
                $this->etablissementRessource->SelectedIndex = 0;
                $this->_criteriaVo->setIdEtablissementAttache ( $this->etablissementRessource->getSelectedValue () );
            }
            $this->loadDataTypePrestation ();
            $this->loadDataPrestation ();
            $this->_criteriaVo->setSortByElement("NOM_UTILISATEUR");
            $this->_criteriaVo->setSensOrderBy("ASC");
            $this->_criteriaVo->setForRessource ( true );

            $_SESSION["ressources"]["sortByElement"] = "NOM_UTILISATEUR";
            $_SESSION["ressources"]["sensTri"] ="ASC";
        }
        else {

            $idOrganisation = $this->_criteriaVo->getIdOrganisationAttache();
            $idEtablissement = $this->_criteriaVo->getIdEtablissementAttache();
            $idTypePrestation = $this->_criteriaVo->getIdTypePrestation();
            $idPrestation = $this->_criteriaVo->getIdPrestation();
            $token = $this->_criteriaVo->getMotCle();
            if ( $adminOrg || $adminEtab ) {
                $this->organisationRessource->SelectedValue = $idOrganisation;
                $this->organisationRessource->Enabled = false;

            }
            $this->populateFiltres();
            //$this->loadDataEtablissement();
            if($idEtablissement) {
                $this->etablissementRessource->setSelectedValue ( $idEtablissement );
            }
            else {
                $this->etablissementRessource->SelectedIndex = 0;
            }
            $this->loadDataTypePrestation ();
            if( $idTypePrestation ) {
                $this->typePrestationRessource->setSelectedValue ( $idTypePrestation );
            }
            else {
                $this->typePrestationRessource->SelectedIndex = 0;
            }
            $this->loadDataPrestation ();
            if( $idPrestation ) {
                $this->prestationRessource->setSelectedValue ( $idPrestation );
            }
            else {
                $this->prestationRessource->SelectedIndex = 0;
            }
            $this->motsCles->Text = $token;
        }
        $this->_criteriaVo->setLang ( $this->_lang );

        if( isset( $_GET["pages"] ) ) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if( isset( $_GET["pageSize"] ) ) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listeRessources->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif ( !$this->_criteriaVo->getPageSize() ) {
            $this->_criteriaVo->setPageSize(10);
        }
		$this->fillRepeaterWithDataForSearchResult ( );
	}

	private function fillRepeaterWithDataForSearchResult()
	{

		$tAgentPeer = new TAgentPeer();
		//Nombre de ressources
		$nombreElement = $tAgentPeer->getRessourceByCriteres($this->_criteriaVo, true);
        if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
            $this->pagerPanelTop->setVisible(true);
            $this->pagerPanelBottom->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listeRessources->setVirtualItemCount($nombreElement);
			$this->listeRessources->setCurrentPageIndex(0);
			$this->populateData();
		} else {
            $this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
			$this->pagerPanelBottom->setVisible(false);
			$this->pagerPanelTop->setVisible(false);
			$this->listeRessources->DataSource=array();
			$this->listeRessources->DataBind();
			$this->nombreElement->Text="0";
		}
        $_SESSION["ressources"]["criteriaVoSearch"] = $this->_criteriaVo;
	}

	public function remplirListeOrganisation() {
		$organisations = new Atexo_Organisation_Gestion();
		$this->organisationRessource->DataSource = $organisations->getAllOrganisation($this->_lang, Prado::localize('ORGANISATION'));
		$this->organisationRessource->DataBind();
	}
	
	public function loadDataEtablissement($idEntite1 = null, $idsEntite2 = null) {
		$idOrganisation = $this->organisationRessource->getSelectedValue();
        if($idEntite1) {
            $entiteGestion = new Atexo_Entite_Gestion();
            $idsCommune = $entiteGestion->getAllIdChildEntite ($idEntite1);
        }
        if($idsEntite2) {
            $entiteGestion = new Atexo_Entite_Gestion();
            $idsCommune = $entiteGestion->getAllIdChildEntite ($idsEntite2);
        }
        if($this->entite3->getSelectedValue ()) {
            $idsCommune = $this->entite3->getSelectedValue ();
        }

		//Remplir liste Etablissement
		$etablissements = new Atexo_Etablissement_Gestion();
		$this->etablissementRessource->DataSource = $etablissements->getEtablissementByIdProvinceIdOrganisation($this->_lang, $idOrganisation, $idsCommune, /*Prado::localize('ETABLISSEMENT')*/false, true);
		$this->etablissementRessource->DataBind();
        $this->etablissementRessource->SetSelectedIndex(0);
        $this->loadTypePrestation(null,null);
	}

	public function loadEtablissement($sender, $param) {
		$this->loadDataEtablissement();
		$this->etablissementRessource->SelectedIndex=0;
        if($this->etablissementRessource->getSelectedValue()) {
            $this->_criteriaVo->setIdEtablissementAttache ( $this->etablissementRessource->getSelectedValue () );
        }else {
            $this->_criteriaVo->setIdEtablissementAttache ( -1 );
        }
		$this->loadTypePrestation($sender,$param);
		$this->etablissementRessource->render($param->NewWriter);
	}

    public function loadDataTypePrestation() {
        $idEtab = $this->etablissementRessource->getSelectedValue();
        //Remplir liste Type Prestation
        $typePrests = new Atexo_TypePrestation_Gestion();
        $this->typePrestationRessource->DataSource = $typePrests->getTypePrestationByIdEtab($this->_lang,$idEtab, Prado::localize('TYPE_PRESTATION'));
        $this->typePrestationRessource->DataBind();
    }

    public function loadDataPrestation() {
        $idTypePrestation = $this->typePrestationRessource->getSelectedValue();
        if(!$idTypePrestation) {
            $idTypePrestation = -1;
        }
        if(isset($_SESSION['idOrg'])) {
            $tOrganisation = TOrganisationQuery::create()->getOrganisationById($_SESSION['idOrg']);
        }
        $typePrestation = $tOrganisation instanceof TOrganisation ? $tOrganisation->getTypePrestation() : Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE");
        //Remplir liste Type Prestation
        $PrestationGestion = new Atexo_Prestation_Gestion();
        $this->prestationRessource->DataSource = $PrestationGestion->getPrestationByIdTypePrestation($this->_lang,$idTypePrestation, $typePrestation, Prado::localize('PRESTATION'));
        $this->prestationRessource->DataBind();
    }

    public function loadTypePrestation($sender,$param) {
        $this->loadDataTypePrestation();
        $this->loadDataPrestation();
        //$this->searchRessource($sender,$param);
    }

    public function loadPrestation($sender,$param) {
        $this->loadDataPrestation();
        //$this->searchRessource($sender,$param);
    }

	protected function searchRessource($sender,$param) {
        try {
            $token = $this->motsCles->SafeText;
            
            $this->_criteriaVo = new Atexo_Agent_CriteriaVo();
            $this->_criteriaVo->setLang ( $this->_lang );
            $this->_criteriaVo->setMotCle ( $token );
            $this->_criteriaVo->setForRessource ( true );

            if ( $this->entite1->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite1 ( $this->entite1->getSelectedValue () );
                $this->_criteriaVo->setIdEntite( $this->entite1->getSelectedValue () );
            }
            if ( $this->entite2->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite2 ( $this->entite2->getSelectedValue () );
                $this->_criteriaVo->setIdEntite( $this->entite2->getSelectedValue () );
            }
            if ( $this->entite3->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite3 ( $this->entite3->getSelectedValue () );
                $this->_criteriaVo->setIdEntite( $this->entite3->getSelectedValue () );
            }

            $this->_criteriaVo->setIdOrganisationAttache ( $this->organisationRessource->getSelectedValue () );
            $idEtablissement = $this->etablissementRessource->getSelectedValue () ? $this->etablissementRessource->getSelectedValue () : '-1';
            $this->_criteriaVo->setIdEtablissementAttache ( $idEtablissement );
            $this->_criteriaVo->setIdTypePrestation ( $this->typePrestationRessource->getSelectedValue () );
            $this->_criteriaVo->setIdPrestation ( $this->prestationRessource->getSelectedValue () );
            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);

            // tri
            $this->_criteriaVo->setSortByElement($_SESSION["ressources"]["sortByElement"]);
            $this->_criteriaVo->setSensOrderBy($_SESSION["ressources"]["sensTri"]);

            unset($_GET["pageSize"]);
            unset($_GET["pages"]);

            $this->fillRepeaterWithDataForSearchResult ();
            $this->ressourcesPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");
        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listeRessources->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listeRessources->CurrentPageIndex = $numPage -1;

		$offset = $this->listeRessources->CurrentPageIndex * $pageSize;
		$limit = $pageSize;
        $this->listeRessources->PageSize = $limit;

        if ($offset + $limit > $nombreElement) {
            $limit = $nombreElement - $offset;
        }
		$this->_criteriaVo->setOffset($offset);
		$this->_criteriaVo->setLimit($limit);

		$dataAgents = TAgentPeer::getRessourceByCriteres($this->_criteriaVo);
        
		$this->listeRessources->DataSource = $dataAgents;
		$this->listeRessources->DataBind();

        $this->numPageBottom->Text = $numPage;
        $this->numPageTop->Text = $numPage;
        $this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
        $this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
        $this->nombrePageTop->Text = $nombrePages;
        $this->nombrePageBottom->Text = $nombrePages;
	}

    protected function populateFiltres () {
        $this->loadEntite1();
        if($this->_criteriaVo->getEntite1()) {
            $this->entite1->setSelectedValue($this->_criteriaVo->getEntite1());
        }
        $this->loadEntite2();
        if($this->_criteriaVo->getEntite2()) {
            $this->entite2->setSelectedValue($this->_criteriaVo->getEntite2());
        }
        $this->loadEntite3();
        if($this->_criteriaVo->getEntite3()) {
            $this->entite3->setSelectedValue($this->_criteriaVo->getEntite3());
        }

        $this->loadDataEtablissement($this->entite1->getSelectedValue(), $this->entite2->getSelectedValue());
    }

	public function Trier($sender,$param)
	{
        try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["ressources"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $_SESSION["ressources"]["sensTri"] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $_SESSION["ressources"]["sensTri"] );

            $_SESSION["ressources"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
            $this->populateData();
            $this->ressourcesPanel->render($param->getNewWriter());
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function pageChanged($sender,$param)
	{
        $urlParams = "&pages=".($param->NewPageIndex+1);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionRessources&search".$urlParams);
	}

	public function goToPage($sender)
	{
        switch ($sender->ID) {
            case "DefaultButtonTop" :
                $numPage = $this->numPageTop->Text;
                break;
            case "DefaultButtonBottom" :
                $numPage = $this->numPageBottom->Text;
                break;
        }
        $urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeRessources->CurrentPageIndex+1, $this->nombrePageTop->Text);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionRessources&search".$urlParams);
	}

	public function changePagerLenght($sender)
	{
        switch ($sender->ID) {
            case "nombreResultatAfficherBottom" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
                break;
            case "nombreResultatAfficherTop" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
                break;
        }
        $this->response->redirect("?page=administration.GestionRessources&search&pages=1&pageSize=".$pageSize);
	}

	public function onConfirmSuppressionClick() {
		$tAgentQuery = new TAgentQuery();
		$idAgent = $this->agentToDeleteHidden->Value;
		$tAgent = $tAgentQuery->getAgentById($idAgent);

		if($tAgent instanceof TAgent) {
			$rdvs = $tAgent->getTRendezVoussRelatedByIdAgentRessource();
			if(count($rdvs)>0) {
				$this->paneldeleteFail->setStyle('display:Block');
			} else {
				$connexion = Propel :: getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
				$connexion->beginTransaction();
				
				$tTraductionNom = $tAgent->getTTraductionRelatedByCodeNomUtilisateur();
				$tTraductionPrenom = $tAgent->getTTraductionRelatedByCodePrenomUtilisateur();
				
				$tTAgendas = $tAgent->getTAgendas($connexion);
				foreach($tTAgendas as $tTAgenda){
					$tPeriodes = $tTAgenda->getTPeriodes($connexion);
					foreach($tPeriodes as $tPeriode){
						$tPeriode->delete($connexion);
					}
					$tTAgenda->delete($connexion);	
				}
				
				$tTPeriodeIndisponibilites = $tAgent->getTPeriodeIndisponibilites($connexion);
				foreach($tTPeriodeIndisponibilites as $tTPeriodeIndisponibilite){
					$tTPeriodeIndisponibilite->delete($connexion);
				}
				$tAgent->delete($connexion);
				$tTraductionNom->deleteAll($connexion);
				$tTraductionPrenom->deleteAll($connexion);
				
				$connexion->commit();

				$this->paneldeleteOk->setStyle('display:Block');
			}
		}

		//Remplir repeater Agents
		$this->fillRepeaterWithDataForSearchResult();
		//$this->ressourcesPanel->render($param->getNewWriter());
	}

    public function isTrierPar($champ) {
        $sortByElement = $_SESSION["ressources"]["sortByElement"];
        if($champ!=$sortByElement) {
            return "";
        }
        if($_SESSION["ressources"]["sensTri"]=="ASC") {
            return "tri-on tri-asc";
        }
        return "tri-on tri-desc";
    }

    /**
     * Remplir la liste des regions
     */
    public function loadEntite1() {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite1->DataSource = $entiteGestion->getAllEntite(1, $this->_lang, null, Prado::localize('ENTITE_1'));
        $this->entite1->DataBind();
    }

    /**
     * Remplir la liste des provinces
     */
    public function loadEntite2($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
        $this->entite2->DataBind();
        if($sender) {
            //$this->viderEntite3 ();
            $this->loadEntite3();
            $this->loadDataEtablissement($this->entite1->getSelectedValue());
        }
    }

    /**
     * Remplir la liste des communes
     */
    public function loadEntite3($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $idEntite = null;

        if($this->entite2->SelectedValue) {
            $idEntite = $this->entite2->SelectedValue;
        }elseif($this->entite1->SelectedValue){
            $idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
        }
        $this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
        $this->entite3->DataBind();
        if($sender) {
            $this->loadDataEtablissement ($this->entite1->getSelectedValue(), $this->entite2->getSelectedValue());
        }
    }

    /**
     * vider la liste des provinces
     */
    public function viderEntite2() {
        $this->_criteriaVo->setEntite2(false);
        $this->entite2->DataSource = array(Prado::localize('ENTITE_2'));
        $this->entite2->DataBind();
    }

    /**
     * vider la liste des communes
     */
    public function viderEntite3() {
        $this->_criteriaVo->setEntite3(false);
        $this->entite3->DataSource = array(Prado::localize('ENTITE_3'));
        $this->entite3->DataBind();
    }
}
