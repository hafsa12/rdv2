<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GestionPrestationsModeRef extends AtexoPage {

	private $_lang = "";
	/**
	 * @var Atexo_Prestation_CriteriaVo
	 */
	protected $_criteriaVo = "";

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionPrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(!$this->isPostBack) {
            if(!isset($_GET["search"])) {
                unset($_SESSION["PrestationModeRef"]["criteriaVoSearch"]);
                unset($_SESSION["PrestationModeRef"]["sensTri"]);
                unset($_SESSION["PrestationModeRef"]["sortByElement"]);
            }
            $this->init();
		}else{
            $this->_criteriaVo = $_SESSION["PrestationModeRef"]["criteriaVoSearch"];
        }
	}

	protected function init() {

		$this->_criteriaVo = $_SESSION["PrestationModeRef"]["criteriaVoSearch"];

		$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
		$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
		$this->loadOrganisation();
        //$this->loadEtablissement();
        $idOrganisation = null;
        $typePrestation = null;

		if(!$this->_criteriaVo) {
            $this->loadEntite1();
            $this->loadEntite2();
            $this->loadEntite3();

            $this->_criteriaVo = new Atexo_Prestation_CriteriaVo();

            $this->_criteriaVo->setPrestationModeRef(true);
            $this->_criteriaVo->setPrestationReferentiel($_SESSION["typePrestation"]);

            $this->_criteriaVo->setSortByElement("LIBELLE_COMPLET_ETABLISSEMENT");
            $this->_criteriaVo->setSensOrderBy("ASC");

            $_SESSION["PrestationModeRef"]["sortByElement"] = "LIBELLE_COMPLET_ETABLISSEMENT";
            $_SESSION["PrestationModeRef"]["sensTri"] =  "ASC";
		}
        else {
            $this->listeOrganisation->SelectedValue = $this->_criteriaVo->getIdOrganisation();

            $this->populateFiltres();

            if($adminOrg || $adminEtab) {
                $this->listeOrganisation->Enabled = false;
            }
        }

        if(isset($_GET["pages"])) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if(isset($_GET["pageSize"])) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listeEtablissements->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif(!$this->_criteriaVo->getPageSize()) {
            $this->_criteriaVo->setPageSize(10);
        }
		$this->search(null,null);
	}

		/*
         * Remplir la liste des organisations
         */
	public function loadOrganisation() {
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($this->_lang, Prado::localize('ORGANISATION'));
		$this->listeOrganisation->DataBind();
	}

	/*
	 * @param $criteriaVo
	 * Remplir repeater des établissements selon les critères de recherche 
	 */
	public function fillRepeaterWithDataForSearchResult()
	{
		$tPrestationPeer = new TPrestationPeer();
		//Nombre des Prestations
        $this->_criteriaVo->setIdEtablissement(null);
        $this->_criteriaEtablissement();
		$nombreElement = $tPrestationPeer->getPrestationParametrageByCriteres($this->_criteriaVo, true);

		if ($nombreElement>=1) {
			$this->nombreElement->Text=$nombreElement;
            $this->panelBottom->setVisible(true);
            $this->panelTop->setVisible(true);
			$this->PagerBottom->setVisible(true);
			$this->PagerTop->setVisible(true);
			$this->setViewState("nombreElement",$nombreElement);
			$this->listeEtablissements->setVirtualItemCount($nombreElement);
			$this->listeEtablissements->setCurrentPageIndex(0);
			$this->populateData();
		} else {
			$this->PagerBottom->setVisible(false);
			$this->PagerTop->setVisible(false);
            $this->panelBottom->setVisible(false);
            $this->panelTop->setVisible(false);
			$this->listeEtablissements->DataSource=array();
			$this->listeEtablissements->DataBind();
			$this->nombreElement->Text="0";
		}
        $_SESSION["PrestationModeRef"]["criteriaVoSearch"] = $this->_criteriaVo;
	}

	/**
	 * Peupler les données des prestations
	 */
	public function populateData()
	{
		$nombreElement = $this->getViewState("nombreElement");
        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listeEtablissements->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listeEtablissements->CurrentPageIndex = $numPage -1;

        $offset = $this->listeEtablissements->CurrentPageIndex * $pageSize;
		$limit = $pageSize;
        $this->listeEtablissements->PageSize = $limit;

		if ($offset + $limit > $nombreElement) {
			$limit = $nombreElement - $offset;
		}
		$this->_criteriaVo->setOffset($offset);
		$this->_criteriaVo->setLimit($limit);
        $this->_criteriaVo->setIdEtablissement(null);
        $this->_criteriaEtablissement();

        $dataEtabs = TPrestationPeer::getPrestationParametrageByCriteres($this->_criteriaVo, false, true);
        $idsEtab = $this->_recupIdsEtab($dataEtabs);
        $this->_criteriaVo->setIdEtablissement(implode(',', $idsEtab));

        $this->_criteriaVo->setOffset(false);
        $this->_criteriaVo->setLimit(false);

        $dataPrestation = TPrestationPeer::getPrestationParametrageByCriteres($this->_criteriaVo);

        $dataSource = $this->_getDataSource($dataPrestation);
		$this->listeEtablissements->DataSource = $dataSource;
		$this->listeEtablissements->DataBind();

        $pageSize = $this->listeEtablissements->PageSize;

        $this->numPageBottom->Text = $numPage;
        $this->numPageTop->Text = $numPage;
        $this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
        $this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
        $this->nombrePageTop->Text = $nombrePages;
        $this->nombrePageBottom->Text = $nombrePages;
	}

    protected function populateFiltres () {
        $this->loadEntite1();
        if($this->_criteriaVo->getEntite1()) {
            $this->entite1->setSelectedValue($this->_criteriaVo->getEntite1());
        }
        $this->loadEntite2();
        if($this->_criteriaVo->getEntite2()) {
            $this->entite2->setSelectedValue($this->_criteriaVo->getEntite2());
        }
        $this->loadEntite3();
        if($this->_criteriaVo->getEntite3()) {
            $this->entite3->setSelectedValue($this->_criteriaVo->getEntite3());
        }
    }

	/*
	 * Rechercher Prestation par critères 
	 */
	protected function search($sender,$param) {
        try {
            $this->_criteriaEtablissement();
            $this->_criteriaVo->setLang ( $this->_lang );

            if ( $this->listeOrganisation->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setIdOrganisation ( $this->listeOrganisation->getSelectedValue () );
            }

            $this->_criteriaVo->setIdEntite ( false );
            $this->_criteriaVo->setEntite1 ( false );
            $this->_criteriaVo->setEntite2 ( false );
            $this->_criteriaVo->setEntite3 ( false );

            if ( $this->entite1->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite1 ( $this->entite1->getSelectedValue () );
                $this->_criteriaVo->setIdEntite ( $this->entite1->getSelectedValue () );
            }

            if ( $this->entite2->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite2 ( $this->entite2->getSelectedValue () );
                $this->_criteriaVo->setIdEntite ( $this->entite2->getSelectedValue () );
            }

            if ( $this->entite3->getSelectedValue () > 0 ) {
                $this->_criteriaVo->setEntite3 ( $this->entite3->getSelectedValue () );
                $this->_criteriaVo->setIdEntite ( $this->entite3->getSelectedValue () );
            }

            if($sender) {
                $this->_criteriaVo->setPages(1);
                $this->_criteriaVo->setPageSize(10);
            }

            // tri
            $this->_criteriaVo->setSortByElement($_SESSION["PrestationModeRef"]["sortByElement"]);
            $this->_criteriaVo->setSensOrderBy($_SESSION["PrestationModeRef"]["sensTri"]);

            if($sender) {
                unset( $_GET[ "pageSize" ] );
                unset( $_GET[ "pages" ] );
            }

            $this->fillRepeaterWithDataForSearchResult ();
            if ($param) {
                $this->prestationPanel->render ( $param->getNewWriter () );
            }
        } catch(Exception $e) {echo $e->getMessage();
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function Trier($sender,$param)
	{
        try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["PrestationModeRef"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $_SESSION["PrestationModeRef"]["sensTri"] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $_SESSION["PrestationModeRef"]["sensTri"] );

            $_SESSION["PrestationModeRef"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
            $this->populateData ();
            $this->prestationPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
	}

	public function pageChanged($sender,$param)
	{
        $urlParams = "&pages=".($param->NewPageIndex+1);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionPrestationsModeRef&search".$urlParams);
	}

	public function goToPage($sender)
	{
        switch ($sender->ID) {
            case "DefaultButtonTop" :
                $numPage = $this->numPageTop->Text;
                break;
            case "DefaultButtonBottom" :
                $numPage = $this->numPageBottom->Text;
                break;
        }
        $urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeEtablissements->CurrentPageIndex+1, $this->nombrePageTop->Text);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=administration.GestionPrestationsModeRef&search".$urlParams);
	}

	public function changePagerLenght($sender)
	{
        switch ($sender->ID) {
            case "nombreResultatAfficherBottom" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
                break;
            case "nombreResultatAfficherTop" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
                break;
        }
        $this->response->redirect("?page=administration.GestionPrestationsModeRef&search&pages=1&pageSize=".$pageSize);
	}

	public function isTrierPar($champ) {
        $sortByElement = $_SESSION["PrestationModeRef"]["sortByElement"];
		if($champ!=$sortByElement) {
			return "";
		}
		if( $_SESSION["PrestationModeRef"]["sensTri"] == "ASC" ) {
			return "tri-on tri-asc";
		}
		return "tri-on tri-desc";
	}

    public function getLibelleRessourceObligatoire($visible, $enumeration) {
        if($visible) {
            return Atexo_Utils_Util::getLibelleEnumOuiNon($enumeration);
        }
        return Prado::localize("TRANS_CHAMP_VIDE");
    }

    /**
     * Remplir la liste des regions
     */
    public function loadEntite1() {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite1->DataSource = $entiteGestion->getAllEntite(1, $this->_lang, null, Prado::localize('ENTITE_1'));
        $this->entite1->DataBind();
    }

    /**
     * Remplir la liste des provinces
     */
    public function loadEntite2($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
        $this->entite2->DataBind();
        if($sender) {
            $this->loadEntite3();
        }
    }

    /**
     * Remplir la liste des communes
     */
    public function loadEntite3($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $idEntite = null;

        if($this->entite2->SelectedValue) {
            $idEntite = $this->entite2->SelectedValue;
        }elseif($this->entite1->SelectedValue){
            $idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
        }

        $this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
        $this->entite3->DataBind();
    }

    private function _getDataSource($data) {
        $result = array();
        // Referentiel Type Prestation
        $refTypePrestationPeer = new TRefTypePrestationPeer();

        $criteriaVo = new Atexo_RefPrestation_CriteriaVo();
        $criteriaVo->setIdOrganisation($this->listeOrganisation->getSelectedValue());
        $criteriaVo->setLang($this->_lang);

        $refTypePrestations = $refTypePrestationPeer->getRefTypePrestationByCriteres ( $criteriaVo );

        foreach ($data as $element) {
            $idEtablissement = $element["ID_ETABLISSEMENT"];
            if(null == $result[$idEtablissement]) {
                $result[$idEtablissement]["ID_ETABLISSEMENT"] = $idEtablissement;
                $result[$idEtablissement]["LIBELLE_COMPLET_ETABLISSEMENT"] = $element["LIBELLE_COMPLET_ETABLISSEMENT"];

                // initialisation des types prestation
                foreach ($refTypePrestations as $typePrestation) {
                    $result[ $idEtablissement ][ "typesPrestation" ][ $typePrestation[ "ID_REF_TYPE_PRESTATION" ] ] = array ( "LIBELLE_REFERENTIEL_TYPE_PRESTATION" => $typePrestation[ "LIBELLE_REFERENTIEL_TYPE_PRESTATION" ], "countPresta" => 0 );
                }
            }
            if($element["ID_REF_TYPE_PRESTATION"]>0) {
                $result[$idEtablissement]["typesPrestation"][$element["ID_REF_TYPE_PRESTATION"]]["countPresta"] += $element["NBRE_PRESTA"];
            }
        }
        return $result;
    }

    private function _recupIdsEtab ($data) {
        $res = array();
        foreach ($data as $element) {
            $res [$element["ID_ETABLISSEMENT"]] = $element["ID_ETABLISSEMENT"];
        }
        return $res;
    }

    private function _criteriaEtablissement() {

        $adminOrg = Atexo_User_CurrentUser::isAdminOrg();
        $adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();

        if($adminOrg) {
            $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere ();
            $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
            $this->listeOrganisation->SelectedValue = $idOrganisation;
            $this->listeOrganisation->Enabled = false;
        }
        if($adminEtab) {
            $idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache ();
            $this->_criteriaVo->setIdOrganisation ( $idOrganisation );
            $this->listeOrganisation->SelectedValue = $idOrganisation;
            $this->listeOrganisation->Enabled = false;

            $idsEtablissement = Atexo_User_CurrentUser::getIdEtablissementGere ();
            $this->_criteriaVo->setIdEtablissement ( $idsEtablissement );
        }
    }
}
