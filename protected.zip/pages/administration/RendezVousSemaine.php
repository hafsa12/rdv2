<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class RendezVousSemaine extends AtexoPage {

	public $entete=array();
	
	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!$this->isPostBack) {
			$lang = Atexo_User_CurrentUser::readFromSession("lang");
			$this->loadRessources();
			$criteria = new Atexo_RendezVous_CriteriaVo();
			$date = Atexo_Utils_Util::getDatesSemaine(date("d/m/Y"));
			$criteria->setIdEtablissementAttache(Atexo_User_CurrentUser::getIdEtablissementGere());
			$criteria->setDateDu($date['deb']);
			$criteria->setDateAu($date['deb']);
			$criteria->setLang($lang);
			$criteria->setSortByElement("DATE_RDV");
			$criteria->setSensOrderBy("ASC");
			$this->selectedDay->Text = $date['deb'];
			$this->setViewState("criteria",$criteria);
			$this->setRdvSemaine($date['deb'],$criteria);
		}
	}
	
	public function getNomDate($date) {
		
		$util = new Atexo_Utils_Util();
		list($jour,$mois,$annee) = explode("/",$date);
		
		for($i=1;$i<=7;$i++) {
			$this->entete[$date] = Prado::localize("DAY".$i)." ".$jour." ".Prado::localize("MONTH".((int)$mois));
			$date = $util->iso2frnDate($util->addJours($util->frnDate2iso($date),1));
			list($jour,$mois,$annee) = explode("/",$date);
		}
	}
	
	public function loadRessources() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$gestion = new Atexo_Agent_Gestion();
		$ressources = $gestion->getRessourceGere($lang,Prado::localize('NIVEAU3'));
		$this->listeRessources->DataSource = $ressources;
		$this->listeRessources->DataBind();
		$this->setViewState("ressources",$ressources);
	}
	
	public function suggestRdvs($sender,$param) {
		
		$criteria = $this->getViewState("criteria");
		$this->setRdvSemaine($this->selectedDay->SafeText,$criteria);
		$this->rdvSemainePanel->render($param->getNewWriter());
	}
	
	public function setRdvSemaine($date,$criteria) {
		if($this->listeRessources->SelectedValue>0) {
			$dataRessource[$this->listeRessources->SelectedValue] = $this->listeRessources->SelectedItem->Text;
		}
		else {
			$dataRessource = $this->getViewState("ressources");
		}
			
		$dates = Atexo_Utils_Util::getDatesSemaine($date);
		$this->getNomDate($dates['deb']);
		$criteria->setDateDu($dates['deb']);
		$criteria->setDateAu($dates['fin']);
		$this->setViewState("criteria",$criteria);
		$criteria->setGroupByDateMois(true);
		
		$tRdvPeer = new TRendezVousPeer();
		$rdvRessource=array();
		$i=0;
		foreach($dataRessource as $id=>$nom) {
			if($id>0) { 
				$criteria->setIdRessource($id);
				$data = $tRdvPeer->getRdvByCriteres($criteria);
				
				if(is_array($data)) {
					$dataRdv = $data;
				}
				else {
					$dataRdv = array();
				}
				$rdvRessource[$i]["RESSOURCE"] = $nom;
				$rdvRessource[$i]["RDV"] = $dataRdv;
				$i++;
			}
		}
		$this->listeRdvs->DataSource = $rdvRessource;
		$this->listeRdvs->DataBind();
	}
	

	public function getRdvs($data) {
		$rdvs=array();
		foreach(array_keys($this->entete) as $jour) {
			if(!is_array($data[$jour])) {
				$rdvs[$jour]['RDV']=array();
			}
			else {
				$rdvs[$jour]['RDV']=$data[$jour]['RDV'];
			}
			$rdvs[$jour]['JOUR_RDV']=$jour;
		}
		return $rdvs;
	}
	
	public function isAVenir($dateFrn) {
		return Atexo_Utils_Util::frnDate2iso($dateFrn)>=date("Y-m-d");
	}
}