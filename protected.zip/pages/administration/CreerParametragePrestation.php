<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerParametragePrestation extends AtexoPage {

	private $_dataCommentaire = null;
	private $_dataAide = null;

	public function onInit()
	{
		$this->Master->setCalledFrom("admin");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionParamPrestation') || $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE")) {
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		if(!$this->isPostBack) {

			$adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();
			
			$this->loadOrganisation();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}

			if($adminEtab) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
			}
			$this->loadRefTypePrestation();
			$this->loadRefPrestation();

			if(isset($_GET["idParamPrestation"])) {
				$this->remplir($_GET["idParamPrestation"]);
			}
			else {
				$this->prepareForm();
			}

			self::getListeCommentaireParLangues($this->_dataCommentaire);
			self::getListeAideParLangues($this->_dataAide);
		}
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}

	/**
	 * Remplir la liste des types-prestations
	 */
	public function loadRefTypePrestation(){
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$RefPrestationGestion = new Atexo_RefPrestation_Gestion();

		$this->listeRefTypePrestation->DataSource = $RefPrestationGestion->getRefTypePrestationByIdOrganisation($lang,$this->listeOrganisation->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->listeRefTypePrestation->DataBind ();
	}

	/**
	 * Remplir la liste des refPrestations
	 */
	public function loadRefPrestation(){
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$RefPrestationGestion = new Atexo_RefPrestation_Gestion();

		$this->listeRefPrestation->DataSource = $RefPrestationGestion->getRefPrestationByIdOrganisation($lang,$this->listeOrganisation->SelectedValue,Prado::localize('SELECTIONNEZ'));
		$this->listeRefPrestation->DataBind();
	}

	public function loadDureeRdv(){
		$refPrestationQuery = new TRefPrestationQuery();
		$refPrestation = $refPrestationQuery->getRefPrestationById($this->listeRefPrestation->SelectedValue);
		$this->inputPeriodicite->Text = $refPrestation->getDureeRdv();
	}

	/**
	 * @param $data
	 * récuperer repeater commentaire de la prestation
	 */
	public function getListeCommentaireParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeCommentaireParLangues($data);
		} else {
			//récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['commentaireLibelleLang'] = Prado::localize('COMMENTAIRE');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['commentaire'] = '';
				$data[$index]['langCommentaire'] = $lan;
				$index++;
			}
			$this->setListeCommentaireParLangues($data);
		}
	}

	/**
	 * @param $data
	 * récuperer repeater aide de la prestation
	 */
	public function getListeAideParLangues($data=null) {
		if(count($data) > 0) {
			$this->setListeAideParLangues($data);
		} else {
			//récupérer les langues
			$langues[]= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

			$data = array();
			$index=0;
			foreach($langues[0] as $lan){
				$data[$index]['aideLibelleLang'] = Prado::localize('AIDE');
				$data[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$data[$index]['aide'] = '';
				$data[$index]['langAide'] = $lan;
				$index++;
			}
			$this->setListeAideParLangues($data);
		}
	}

	/**
	 * @param $data
	 * remplir repeater commentaire de la prestation
	 */
	public function setListeCommentaireParLangues($data) {
		$this->listeCommentaireLangues->dataSource = $data;
		$this->listeCommentaireLangues->dataBind();
		$index = 0;
		foreach ($this->listeCommentaireLangues->getItems() as $item) {
			$item->commentaireLibelleLang->Text = $data[$index]['commentaireLibelleLang'];
			$item->commentaire->Text = $data[$index]['commentaire'];
			$item->langCommentaire->Value = $data[$index]['langCommentaire'];
			$item->lang->Text = $data[$index]['lang'];
			$index++;
		}
	}

	/**
	 * @param $data
	 * remplir repeater aide de la prestation
	 */
	public function setListeAideParLangues($data) {
		$this->listeAideLangues->dataSource = $data;
		$this->listeAideLangues->dataBind();
		$index = 0;
		foreach ($this->listeAideLangues->getItems() as $item) {
			$item->aideLibelleLang->Text = $data[$index]['aideLibelleLang'];
			$item->aide->Text = $data[$index]['aide'];
			$item->langAide->Value = $data[$index]['langAide'];
			$item->lang->Text = $data[$index]['lang'];
			$index++;
		}
	}

	public function prepareForm() {
		$this->inputDelaiMin->setText("0");
		$this->nonRdv->checked = true;
		$this->inputNbJour->Text = "1";
		$this->script->Text .= "<script>showDiv('divNbJour');</script>";

		$langues = array("fr","ar");
		$index=0;
		foreach($langues as $lang){
			$this->_dataCommentaire[$index]['commentaire'] = "";
			$this->_dataCommentaire[$index]['commentaireLibelleLang'] = Prado::localize('COMMENTAIRE');
			$this->_dataCommentaire[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lang)).')';
			$this->_dataCommentaire[$index]['langCommentaire'] = $lang;
			$index++;
		}
		$index=0;
		foreach($langues as $lang){
			$this->_dataAide[$index]['aide'] = "";
			$this->_dataAide[$index]['aideLibelleLang'] = Prado::localize('AIDE');
			$this->_dataAide[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lang)).')';
			$this->_dataAide[$index]['langAide'] = $lang;
			$index++;
		}

		$this->nonRessourceVisible->checked = true;
		$this->nonRessource->checked = true;
		$this->nonReferentVisible->checked = true;

		$this->nonRaisonSocial->checked = true;

		$this->ouiNom->checked = true;
		$this->script->Text .= "<script>showDiv('obligatoireNom');</script>";

		$this->ouiPrenom->checked = true;
		$this->script->Text .= "<script>showDiv('obligatoirePrenom');</script>";

		$this->ouiNaissance->checked = true;
		$this->script->Text .= "<script>showDiv('obligatoireNaissance');</script>";

		$this->ouiEmail->checked = true;
		$this->script->Text .= "<script>showDiv('obligatoireEmail');</script>";

		$this->ouiId->checked = true;
		$this->script->Text .= "<script>showDiv('obligatoireIdentifiant');</script>";

		$this->ouiAdresse->checked = true;
		$this->script->Text .= "<script>showDiv('obligatoireAdresse');</script>";

		$this->ouiTelephone->checked = true;
		$this->script->Text .= "<script>showDiv('obligatoireTelephone');</script>";

		$this->nonFax->checked = true;

		$this->nonRaisonSocialObligatoire->checked = true;

		$this->ouiNomObligatoire->checked = true;

		$this->ouiPrenomObligatoire->checked = true;

		$this->ouiNaissanceObligatoire->checked = true;

		$this->nonEmailObligatoire->checked = true;

		$this->nonIdObligatoire->checked = true;

		$this->ouiAdresseObligatoire->checked = true;

		$this->ouiTelephoneObligatoire->checked = true;

		$this->nonFaxObligatoire->checked = true;
	}

	/**
	 * @param $idPrestation
	 * récuperer les informations de la prestation
	 */
	public function remplir($idParamPrestation) {
		$langues= explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		$tParametragePrestationQuery = new TParametragePrestationQuery();
		$tParamPrestation = $tParametragePrestationQuery->getParametragePrestationById($idParamPrestation);
		if ($tParamPrestation instanceof TParametragePrestation){
			$tRefTypePrestation = $tParamPrestation->getTRefTypePrestation();
			$tOrganisation = $tParamPrestation->getTOrganisation();

			$this->loadRefPrestation();
			$this->loadRefTypePrestation();

			$this->listeOrganisation->SelectedValue = $tParamPrestation->getIdOrganisation();
			$this->listeRefPrestation->SelectedValue = $tParamPrestation->getIdRefPrestation();
			$this->listeRefTypePrestation->SelectedValue = $tParamPrestation->getIdRefTypePrestation();
			$this->inputDelaiMin->setText($tParamPrestation->getDelaiMin());
			$this->inputPeriodicite->setText($tParamPrestation->getPeriodicite());

			if($tParamPrestation->getRdvSimilaire() == 1){
				$this->ouiRdv->checked = true;
			}
			else{
				$this->nonRdv->checked = true;
				$this->inputNbJour->Text = $tParamPrestation->getNbJourRdvSimilaire();
				$this->script->Text .= "<script>showDiv('divNbJour');</script>";
			}
			if($tParamPrestation->getRessourceVisible() == 1){
				$this->ouiRessourceVisible->checked = true;
				$this->script->Text .= "<script>showDiv('rdvObligatoire');</script>";

				$this->ouiRessource->checked = ($tParamPrestation->getRessourceObligatoire() == 1);
				$this->nonRessource->checked = ($tParamPrestation->getRessourceObligatoire() == 0);
			}
			else{
				$this->nonRessourceVisible->checked = true;
				$this->nonRessource->checked = true;
			}
			if($tParamPrestation->getReferentVisible() == 1){
				$this->ouiReferentVisible->checked = true;
			}
			else{
				$this->nonReferentVisible->checked = true;
			}
			$tParamForm = $tParamPrestation->getTParametreForm();
			if($tParamForm instanceof TParametreForm) {
				$this->remplirParamForm($tParamForm, $langues);
			}
			$index=0;
			foreach($langues as $lang){
				$this->_dataCommentaire[$index]['commentaire'] = $tParamPrestation->getCommentaireTraduit($lang);
				$this->_dataCommentaire[$index]['commentaireLibelleLang'] = Prado::localize('COMMENTAIRE');
				$this->_dataCommentaire[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lang)).')';
				$this->_dataCommentaire[$index]['langCommentaire'] = $lang;
				$index++;
			}
			$index=0;
			foreach($langues as $lang){
				$this->_dataAide[$index]['aide'] = $tParamPrestation->getAideTraduit($lang);
				$this->_dataAide[$index]['aideLibelleLang'] = Prado::localize('AIDE');
				$this->_dataAide[$index]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lang)).')';
				$this->_dataAide[$index]['langAide'] = $lang;
				$index++;
			}
			$pjs = $tParamPrestation->getTPieceParamPrestas();
			$i=0;
			foreach($pjs as $pj) {
				$dataPj[$i]["libelle"]=$pj->getTTraduction();
				$dataPj[$i]["idPiece"]=$pj->getIdPieceParamPresta();
				$dataPj[$i]["idBlob"]=$pj->getIdBlobPiece();
				$dataPj[$i]["blob"]=$pj->getTblob();
				$dataPj[$i]["uploadCitoyen"]=$pj->getUpload();
				$dataPj[$i]["obligatoire"]=$pj->getObligatoire();
				$i++;
			}
			$this->listePj->DataSource = $dataPj;
			$this->listePj->DataBind();
			$i=0;
			foreach($this->listePj->getItems() as $item) {
				$item->listeChampsLangues->DataSource = $langues;
				$item->listeChampsLangues->DataBind();
				if($dataPj[$i]["idBlob"]>0) {
					$item->downloadPlan->Visible=true;
					$item->modifPlan->Visible=true;
					$item->planAcces->Style="display:none";
					$item->downloadPlan->Text = $dataPj[$i]["blob"]->getNomBlob();
					$item->downloadPlan->CommandParameter = $dataPj[$i]["idBlob"];
				}
				if($dataPj[$i]["uploadCitoyen"] == 1){
					$item->ouiUploadCitoyen->Checked = true;
				}elseif($dataPj[$i]["uploadCitoyen"] == 0){
					$item->nonUploadCitoyen->Checked = true;
				}elseif($dataPj[$i]["uploadCitoyen"] == 2){
                    $item->visioUploadCitoyen->Checked = true;
                }

                if($dataPj[$i]["obligatoire"] == 1){
                    $item->ouiObligatoire->Checked = true;
                }else {
                    $item->nonObligatoire->Checked = true;
                }

                $item->idPiece->Value = $dataPj[$i]["idPiece"];
				$index=0;
				$tTraductionLibelles = $dataPj[$i]["libelle"]->getTTraductionLibelles();
				foreach($item->listeChampsLangues->getItems() as $itemLang){
					$tTraductionLibelle = $tTraductionLibelles[$index];
					$itemLang->champsLibelleLang->Text = Prado::localize('LIBELLE');
					$itemLang->lang->Text = '('.Prado::localize('LANG_'.strtoupper($tTraductionLibelle->getLang())).')';
					$itemLang->champs->Text = $tTraductionLibelle->getLibelle();
					$itemLang->langChamps->Value = $tTraductionLibelle->getLang();
					$index++;
				}
				$i++;
			}
		}
	}

	public function remplirParamForm($tParamForm, $langues) {
		$this->ouiRaisonSocial->checked = ($tParamForm->getVisibleRaisonSocial() == 1);
		$this->script->Text .= ($tParamForm->getVisibleRaisonSocial() == 1)?"<script>showDiv('obligatoireRaisonSocial');</script>":"";
		$this->nonRaisonSocial->checked = ($tParamForm->getVisibleRaisonSocial() == 0);
		
		$this->ouiNom->checked = ($tParamForm->getVisibleNom() == 1);
		$this->script->Text .= ($tParamForm->getVisibleNom() == 1)?"<script>showDiv('obligatoireNom');</script>":"";
		$this->nonNom->checked = ($tParamForm->getVisibleNom() == 0);

		$this->ouiPrenom->checked = ($tParamForm->getVisiblePrenom() == 1);
		$this->script->Text .= ($tParamForm->getVisiblePrenom() == 1)?"<script>showDiv('obligatoirePrenom');</script>":"";
		$this->nonPrenom->checked = ($tParamForm->getVisiblePrenom() == 0);

		$this->ouiNaissance->checked = ($tParamForm->getVisibleDateNaissance() == 1);
		$this->script->Text .= ($tParamForm->getVisibleDateNaissance() == 1)?"<script>showDiv('obligatoireNaissance');</script>":"";
		$this->nonNaissance->checked = ($tParamForm->getVisibleDateNaissance() == 0);
			
		$this->ouiEmail->checked = ($tParamForm->getVisibleEmail() == 1);
		$this->script->Text .= ($tParamForm->getVisibleEmail() == 1)?"<script>showDiv('obligatoireEmail');</script>":"";
		$this->nonEmail->checked = ($tParamForm->getVisibleEmail() == 0);

		$this->ouiId->checked = ($tParamForm->getVisibleIdentifiant() == 1);
		$this->script->Text .= ($tParamForm->getVisibleIdentifiant() == 1)?"<script>showDiv('obligatoireIdentifiant');</script>":"";
		$this->nonId->checked = ($tParamForm->getVisibleIdentifiant() == 0);

		$this->ouiAdresse->checked = ($tParamForm->getVisibleAdresse() == 1);
		$this->script->Text .= ($tParamForm->getVisibleAdresse() == 1)?"<script>showDiv('obligatoireAdresse');</script>":"";
		$this->nonAdresse->checked = ($tParamForm->getVisibleAdresse() == 0);
		
		$this->ouiTelephone->checked = ($tParamForm->getVisibleTelephone() == 1);
		$this->script->Text .= ($tParamForm->getVisibleTelephone() == 1)?"<script>showDiv('obligatoireTelephone');</script>":"";
		$this->nonTelephone->checked = ($tParamForm->getVisibleTelephone() == 0);
		
		$this->ouiFax->checked = ($tParamForm->getVisibleFax() == 1);
		$this->script->Text .= ($tParamForm->getVisibleFax() == 1)?"<script>showDiv('obligatoireFax');</script>":"";
		$this->nonFax->checked = ($tParamForm->getVisibleFax() == 0);
		
		$this->ouiRaisonSocialObligatoire->checked = ($tParamForm->getObligatoireRaisonSocial() == 1);
		$this->nonRaisonSocialObligatoire->checked = ($tParamForm->getObligatoireRaisonSocial() == 0);
		
		$this->ouiNomObligatoire->checked = ($tParamForm->getObligatoireNom() == 1);
		$this->nonNomObligatoire->checked = ($tParamForm->getObligatoireNom() == 0);

		$this->ouiPrenomObligatoire->checked = ($tParamForm->getObligatoirePrenom() == 1);
		$this->nonPrenomObligatoire->checked = ($tParamForm->getObligatoirePrenom() == 0);

		$this->ouiNaissanceObligatoire->checked = ($tParamForm->getObligatoireDateNaissance() == 1);
		$this->nonNaissanceObligatoire->checked = ($tParamForm->getObligatoireDateNaissance() == 0);
			
		$this->ouiEmailObligatoire->checked = ($tParamForm->getObligatoireEmail() == 1);
		$this->nonEmailObligatoire->checked = ($tParamForm->getObligatoireEmail() == 0);

		$this->ouiIdObligatoire->checked = ($tParamForm->getObligatoireIdentifiant() == 1);
		$this->nonIdObligatoire->checked = ($tParamForm->getObligatoireIdentifiant() == 0);
		
		$this->ouiAdresseObligatoire->checked = ($tParamForm->getObligatoireAdresse() == 1);
		$this->nonAdresseObligatoire->checked = ($tParamForm->getObligatoireAdresse() == 0);

		$this->ouiTelephoneObligatoire->checked = ($tParamForm->getObligatoireTelephone() == 1);
		$this->nonTelephoneObligatoire->checked = ($tParamForm->getObligatoireTelephone() == 0);
		
		$this->ouiFaxObligatoire->checked = ($tParamForm->getObligatoireFax() == 1);
		$this->nonFaxObligatoire->checked = ($tParamForm->getObligatoireFax() == 0);

		$data=array();
		$i=0;
		if($tParamForm->getText1Actif()) {
			$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText1();
			$data[$i]["obligatoire"]=$tParamForm->getObligatoireText1();
			$i++;
		}
		if($tParamForm->getText2Actif()) {
			$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText2();
			$data[$i]["obligatoire"]=$tParamForm->getObligatoireText2();
			$i++;
		}
		if($tParamForm->getText3Actif()) {
			$data[$i]["libelle"]=$tParamForm->getTTraductionRelatedByCodeLibelleText3();
			$data[$i]["obligatoire"]=$tParamForm->getObligatoireText3();
		}
		$this->listeChamps->DataSource = $data;
		$this->listeChamps->DataBind();
		$i=0;
		foreach($this->listeChamps->getItems() as $item) {
			$item->ouiChamps->checked = ($data[$i]["obligatoire"]==1);
			$item->nonChamps->checked = ($data[$i]["obligatoire"]==0);
			$item->listeChampsLangues->DataSource = $langues;
			$item->listeChampsLangues->DataBind();
			$index=0;
			$tTraductionLibelles = $data[$i]["libelle"]->getTTraductionLibelles();
			foreach($item->listeChampsLangues->getItems() as $itemLang){
				$tTraductionLibelle = $tTraductionLibelles[$index];
				$itemLang->champsLibelleLang->Text = Prado::localize('LIBELLE');
				$itemLang->lang->Text = '('.Prado::localize('LANG_'.strtoupper($tTraductionLibelle->getLang())).')';
				$itemLang->champs->Text = $tTraductionLibelle->getLibelle();
				$itemLang->langChamps->Value = $tTraductionLibelle->getLang();
				$index++;
			}
			$i++;
		}
	}

	/**
	 * enregistrer les informations de la prestation
	 */
	public function enregistrer() {

		if(isset($_GET["idParamPrestation"])) {
			$tParametragePrestationQuery = new TParametragePrestationQuery();
			$tParametragePrestation = $tParametragePrestationQuery->getParametragePrestationById($_GET["idParamPrestation"]);

			$tTraductionCommentaire = $tParametragePrestation->getTTraductionRelatedByCodeCommentaire();
			$tParametreForm = $tParametragePrestation->getTParametreForm();

			if($tTraductionCommentaire==null) {
				$tTraductionCommentaire = new TTraduction();
			}

			$tTraductionAide = $tParametragePrestation->getTTraductionRelatedByCodeAide();

			if($tTraductionAide==null) {
				$tTraductionAide = new TTraduction();
			}
			if(!$tParametreForm) {
				$tParametreForm = new TParametreForm();
			}
		}
		if(!($tParametragePrestation instanceof TParametragePrestation)) {
			$tParametragePrestation = new TParametragePrestation();

			$tParametreForm = new TParametreForm();
			$tTraductionCommentaire = new TTraduction();
			$tTraductionAide = new TTraduction();

			$idOrganisation=$this->listeOrganisation->getSelectedValue();
			$tParametragePrestation->setIdOrganisation($idOrganisation);
		}
		foreach($this->listeCommentaireLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionCommentaire->getTTraductionLibelle($item->langCommentaire->Value);
			$tTraductionLibelle->setLang($item->langCommentaire->Value);
			$tTraductionLibelle->setLibelle($item->commentaire->Text);
			$tTraductionCommentaire->addTTraductionLibelle($tTraductionLibelle);
		}
		$tParametragePrestation->setTTraductionRelatedByCodeCommentaire($tTraductionCommentaire);

		foreach($this->listeAideLangues->getItems() as $item) {
			$tTraductionLibelle = $tTraductionAide->getTTraductionLibelle($item->langAide->Value);
			$tTraductionLibelle->setLang($item->langAide->Value);
			$tTraductionLibelle->setLibelle($item->aide->Text);
			$tTraductionAide->addTTraductionLibelle($tTraductionLibelle);
		}
		$tParametragePrestation->setTTraductionRelatedByCodeAide($tTraductionAide);

		$tParametragePrestation->setIdRefTypePrestation($this->listeRefTypePrestation->getSelectedValue());
		$tParametragePrestation->setIdRefPrestation($this->listeRefPrestation->getSelectedValue());

		$tParametragePrestation->setDelaiMin($this->inputDelaiMin->SafeText);
		$tParametragePrestation->setPeriodicite($this->inputPeriodicite->SafeText);

		if($this->ouiRdv->checked){
			$tParametragePrestation->setRdvSimilaire('1');
		}
		else{
			$tParametragePrestation->setRdvSimilaire('0');
			$tParametragePrestation->setNbJourRdvSimilaire($this->inputNbJour->SafeText);
		}
		if($this->ouiRessourceVisible->checked){
			$tParametragePrestation->setRessourceVisible('1');
			$tParametragePrestation->setRessourceObligatoire((int)$this->ouiRessource->checked);
		}
		else{
			$tParametragePrestation->setRessourceVisible('0');
			$tParametragePrestation->setRessourceObligatoire('0');
		}
		if($this->ouiReferentVisible->checked){
			$tParametragePrestation->setReferentVisible('1');
		}
		else{
			$tParametragePrestation->setReferentVisible('0');
		}

		$tParametreForm = $this->enregistrerParamForm($tParametreForm);
		$tParametragePrestation->setTParametreForm($tParametreForm);
		$tParametragePrestation->updatePrestations();
		$tParametragePrestation->save();
		
		$this->enregistrerPieceJointe($tParametragePrestation->getIdParametragePrestation());
		
		$this->response->redirect("index.php?page=administration.GestionParametragePrestations&search");
	}
	
	public function enregistrerPieceJointe($idParametragePrestation) {
		$idsPieceToDelete = $this->getViewState("idsPieceToDelete");
		$tPieceQuery = new TPieceParamPrestaQuery();
		if(is_array($idsPieceToDelete)) {
			foreach($idsPieceToDelete as $idPiece) {
				$piece = $tPieceQuery->getPieceById($idPiece);
				$tTraduction = $piece->getTTraduction();
				$piece->delete();
				$tTraduction->deleteAll();
			}
		}
		foreach ($this->listePj->getItems() as $item) {
			if($item->idPiece->Value>0) {
				$pj = $tPieceQuery->getPieceById($item->idPiece->Value);
				$tTraduction = $pj->getTTraduction();
			}
			else {
				$pj = new TPieceParamPresta();
				$tTraduction = new TTraduction();
			}
						
			foreach ($item->listeChampsLangues->getItems() as $itemLang) {
				$tTraductionLibelle = $tTraduction->getTTraductionLibelle($itemLang->langChamps->Value);
				$tTraductionLibelle->setLang($itemLang->langChamps->Value);
				$tTraductionLibelle->setLibelle($itemLang->champs->SafeText);
				$tTraduction->addTTraductionLibelle($tTraductionLibelle);
				$pj->setTTraduction($tTraduction);
			}
			
			if($item->planAcces->HasFile) {
				$tBlob = $pj->getTBlob();
				
				if($tBlob==null) {
					$tBlob = new TBlob();
				}
				$tBlob->setNomBlob($item->planAcces->FileName);
				$pj->setTBlob($tBlob);
			}
			$pj->setIdParametragePrestation($idParametragePrestation);
            if($item->nonUploadCitoyen->Checked){
                $pj->setUpload(0);
            }elseif($item->ouiUploadCitoyen->Checked){
                $pj->setUpload(1);
            }elseif($item->visioUploadCitoyen->Checked){
                $pj->setUpload(2);
            }
            $pj->setObligatoire((int)$item->ouiObligatoire->Checked);

            $pj->save();
			
			if($item->planAcces->HasFile) {
				Atexo_Utils_Util::mvFile($item->planAcces->LocalName, Atexo_Config::getParameter("PATH_FILE"), $pj->getIdBlobPiece());
			}
		}
	}

	public function enregistrerParamForm($tParametreForm) {
		$i=1;
		$tTraductionChamps[0] = $tParametreForm->getTTraductionRelatedByCodeLibelleText1();
		$tTraductionChamps[1] = $tParametreForm->getTTraductionRelatedByCodeLibelleText2();
		$tTraductionChamps[2] = $tParametreForm->getTTraductionRelatedByCodeLibelleText3();
		foreach ($this->listeChamps->getItems() as $listes) {

			$fctActif = "setText".$i."Actif";

			$tParametreForm->$fctActif('1');

			$fctObligatoire = "setObligatoireText".$i;
			if($listes->ouiChamps->checked){
				$tParametreForm->$fctObligatoire('1');
			}
			else{
				$tParametreForm->$fctObligatoire('0');
			}
			
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				if(!isset($tTraductionChamps[$listes->ItemIndex])) {
					$tTraductionChamps[$listes->ItemIndex] = new TTraduction();
				}
				$tTraductionLibelle = $tTraductionChamps[$listes->ItemIndex]->getTTraductionLibelle($item->langChamps->Value);
				$tTraductionLibelle->setLang($item->langChamps->Value);
				$tTraductionLibelle->setLibelle($item->champs->SafeText);
				$tTraductionChamps[$listes->ItemIndex]->addTTraductionLibelle($tTraductionLibelle);
				$tTraductionChamps[$listes->ItemIndex]->save();
			}
			$i++;
		}
		for($j=$i;$j<=3;$j++) {
			$fctActif = "setText".$j."Actif";
			$tParametreForm->$fctActif('0');
		}

		$tParametreForm->setTTraductionRelatedByCodeLibelleText1($tTraductionChamps[0]);
		$tParametreForm->setTTraductionRelatedByCodeLibelleText2($tTraductionChamps[1]);
		$tParametreForm->setTTraductionRelatedByCodeLibelleText3($tTraductionChamps[2]);

		$tParametreForm->setVisibleNom((int)$this->ouiNom->checked);
		$tParametreForm->setVisiblePrenom((int)$this->ouiPrenom->checked);
		$tParametreForm->setVisibleDateNaissance((int)$this->ouiNaissance->checked);
		$tParametreForm->setVisibleEmail((int)$this->ouiEmail->checked);
		$tParametreForm->setVisibleIdentifiant((int)$this->ouiId->checked);
		$tParametreForm->setVisibleTelephone((int)$this->ouiTelephone->checked);
		$tParametreForm->setVisibleAdresse((int)$this->ouiAdresse->checked);
		$tParametreForm->setVisibleRaisonSocial((int)$this->ouiRaisonSocial->checked);
		$tParametreForm->setVisibleFax((int)$this->ouiFax->checked);
		
		$tParametreForm->setObligatoireNom((int)$this->ouiNomObligatoire->checked);
		$tParametreForm->setObligatoirePrenom((int)$this->ouiPrenomObligatoire->checked);
		$tParametreForm->setObligatoireDateNaissance((int)$this->ouiNaissanceObligatoire->checked);
		$tParametreForm->setObligatoireEmail((int)$this->ouiEmailObligatoire->checked);
		$tParametreForm->setObligatoireIdentifiant((int)$this->ouiIdObligatoire->checked);
		$tParametreForm->setObligatoireTelephone((int)$this->ouiTelephoneObligatoire->checked);
		$tParametreForm->setObligatoireAdresse((int)$this->ouiAdresseObligatoire->checked);
		$tParametreForm->setObligatoireRaisonSocial((int)$this->ouiRaisonSocialObligatoire->checked);
		$tParametreForm->setObligatoireFax((int)$this->ouiFaxObligatoire->checked);
		return $tParametreForm;
	}


	/**
	 * @param $nbreLigneAAjouter
	 * Récupérer les champs paramétrables
	 */
	public function getDataLigne($nbreLigneAAjouter=0) {
		$index = 0;
		$data = array();
		$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		foreach ($this->listeChamps->getItems() as $listes) {
			$data[$index]['langChamps'] = '';
			$dataChamps = array();
			$indexChamps = 0;
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataChamps[$langues[$indexChamps]]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$langues[$indexChamps]]['lang'] = '('.Prado::localize('LANG_'.strtoupper($langues[$indexChamps])).')';
				$dataChamps[$langues[$indexChamps]]['champs'] = $item->champs->SafeText;
				$dataChamps[$langues[$indexChamps]]['langChamps'] = $langues[$indexChamps];
				$indexChamps++;
			}
			$data[$index]['dataChamp'] = $dataChamps;
			$data[$index]['obligatoire'] = $listes->ouiChamps->Checked;
			$index++;
		}
		if($nbreLigneAAjouter>0) {
			if(count($data)==0) {
				$index = 0;

			}
			$dataChamps = array();
			$data[$index]['langChamps'] = "";
			foreach ($langues as $lan) {
				$dataChamps[$lan]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$lan]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$dataChamps[$lan]['champs'] = '';
				$dataChamps[$lan]['langChamps'] = $lan;
			}
			$data[$index]['dataChamp'] = $dataChamps;
		}

		return $data;

	}

	/**
	 * @param $nbreLigneAAjouter
	 * Ajouer un champ paramétrable
	 */
	public function ajouterChamps($sender, $param) {
		$nbreLigneAAjouter = 1;
		$data =  $this->getDataLigne($nbreLigneAAjouter);
		$this->remplirRepeaterChamps($data);
		if(count($data)>2) {
			$this->btnAjoutChamp->setStyle('display:none');
		}
		$this->listeChampsPanel->setStyle('display:block');
		$this->listeChampsPanel->render($param->NewWriter);
	}


	/**
	 *
	 * Supprimer un champ
	 */
	public function deleteLigneChamps($sender,$param)
	{
		$data = array();
		$itemIndex = $sender->CommandParameter;
		$dataChamps = $this->getDataLigne();
		unset($dataChamps[$itemIndex]);
		$data = array_values($dataChamps);
		$this->remplirRepeaterChamps($data);
			
		$this->btnAjoutChamp->setStyle('display:block');
		$this->listeChampsPanel->render($param->NewWriter);
	}

	/**
	 * @param $data
	 * Remplir liste des champs paramétrables
	 */
	public function remplirRepeaterChamps($data) {
		$this->listeChamps->dataSource = $data;
		$this->listeChamps->dataBind();
		$index = 0;
		foreach ($this->listeChamps->getItems() as $listes) {
			$dataChamps = $data[$index]['dataChamp'];
			$listes->listeChampsLangues->dataSource = $dataChamps;
			$listes->listeChampsLangues->dataBind();
			$indexChamps = 0;
			$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
			$listes->ouiChamps->checked = ($data[$index]["obligatoire"]);
			$listes->nonChamps->checked = !($data[$index]["obligatoire"]);

			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataLang = $dataChamps[$langues[$indexChamps]];
				$item->champsLibelleLang->Text = $dataLang['champsLibelleLang'];
				$item->champs->Text = $dataLang['champs'];
				$item->langChamps->value = $langues[$indexChamps];
				$item->lang->Text = $dataLang['lang'];
				$indexChamps++;
			}
			$index++;
		}
	}
	
	/**
	 * @param $nbreLigneAAjouter
	 * Récupérer les champs paramétrables
	 */
	public function getDataLignePj($nbreLigneAAjouter=0) {
		$index = 0;
		$data = array();
		$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		foreach ($this->listePj->getItems() as $listes) {
			$data[$index]['langChamps'] = '';
			$dataChamps = array();
			$indexChamps = 0;
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataChamps[$langues[$indexChamps]]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$langues[$indexChamps]]['lang'] = '('.Prado::localize('LANG_'.strtoupper($langues[$indexChamps])).')';
				$dataChamps[$langues[$indexChamps]]['champs'] = $item->champs->SafeText;
				$dataChamps[$langues[$indexChamps]]['langChamps'] = $langues[$indexChamps];
				$indexChamps++;
			}
			$data[$index]['dataChamp'] = $dataChamps;
			$data[$index]['idPiece'] = $listes->idPiece->Value;
			if($listes->nonUploadCitoyen->Checked){
                $data[$index]['uploadCitoyen'] = 0;
            }elseif($listes->ouiUploadCitoyen->Checked){
                $data[$index]['uploadCitoyen'] = 1;
            }elseif($listes->visioUploadCitoyen->Checked){
                $data[$index]['uploadCitoyen'] = 2;
            }
            if($listes->ouiObligatoire->Checked){
                $data[$index]["obligatoire"] = 1;
            }else {
                $data[$index]["obligatoire"] = 0;
            }
			$index++;
		}
		if($nbreLigneAAjouter>0) {
			if(count($data)==0) {
				$index = 0;
			}
			$dataChamps = array();
			$data[$index]['langChamps'] = "";
			foreach ($langues as $lan) {
				$dataChamps[$lan]['champsLibelleLang'] = Prado::localize('LIBELLE');
				$dataChamps[$lan]['lang'] = '('.Prado::localize('LANG_'.strtoupper($lan)).')';
				$dataChamps[$lan]['champs'] = '';
				$dataChamps[$lan]['langChamps'] = $lan;
			}
			$data[$index]['dataChamp'] = $dataChamps;
		}

		return $data;

	}

	/**
	 * @param $nbreLigneAAjouter
	 * Ajouer un pj
	 */
	public function ajouterPjs($sender, $param) {
		$nbreLigneAAjouter = 1;
		$data =  $this->getDataLignePj($nbreLigneAAjouter);
		$this->remplirRepeaterPj($data);
		$this->listePjPanel->render($param->NewWriter);
	}

	/**
	 *
	 * Supprimer un pj
	 */
	public function deleteLignePjs($sender,$param)
	{
		$data = array();
		$itemIndex = $sender->CommandParameter;
		$idPiece = $sender->Parent->idPiece->Value;
		$idsPieceToDelete = $this->getViewState("idsPieceToDelete");
		$idsPieceToDelete[] = $idPiece;
		$this->setViewState("idsPieceToDelete", $idsPieceToDelete);
		$dataChamps = $this->getDataLignePj();
		unset($dataChamps[$itemIndex]);
		$data = array_values($dataChamps);
		$this->remplirRepeaterPj($data);
			
		$this->listePjPanel->render($param->NewWriter);
	}

	/**
	 * @param $data
	 * Remplir liste des pj
	 */
	public function remplirRepeaterPj($data) {
		$this->listePj->dataSource = $data;
		$this->listePj->dataBind();
		$index = 0;
        foreach ($this->listePj->getItems() as $listes) {
            $dataChamps = $data[$index]['dataChamp'];
            $listes->listeChampsLangues->dataSource = $dataChamps;
            $listes->listeChampsLangues->dataBind();
            $listes->idPiece->Value = $data[$index]["idPiece"];
            $indexChamps = 0;
            $langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));

            if($data[$index]["uploadCitoyen"] == 1){
                $listes->ouiUploadCitoyen->Checked = true;
            }elseif($data[$index]["uploadCitoyen"] == 0){
                $listes->nonUploadCitoyen->Checked = true;
            }elseif($data[$index]["uploadCitoyen"] == 2){
                $listes->visioUploadCitoyen->Checked = true;
            }
            if(is_null($data[$index]["obligatoire"]) || $data[$index]["obligatoire"] == 1){
                $listes->ouiObligatoire->Checked = true;
            }else {
                $listes->nonObligatoire->Checked = true;
            }
			foreach ($listes->listeChampsLangues->getItems() as $item) {
				$dataLang = $dataChamps[$langues[$indexChamps]];
				$item->champsLibelleLang->Text = $dataLang['champsLibelleLang'];
				$item->champs->Text = $dataLang['champs'];
				$item->langChamps->value = $langues[$indexChamps];
				$item->lang->Text = $dataLang['lang'];
				$indexChamps++;
			}
			$index++;
		}
	}
	
	/**
	 * télécharger le plan d'accès 
	 */
	public function downloadPieceJointe($sender) {
		$idFichier = $sender->CommandParameter;
		Atexo_DownloadFile::downloadFiles($idFichier);
	}
	

	/**
	 * modifier le plan d'accès
	 */
	public function modifPieceJointe($sender, $param) {
		$sender->Parent->Parent->downloadPlan->Visible=false;
		$sender->Parent->Parent->modifPlan->Visible=false;
		$sender->Parent->Parent->planAcces->Style="display:";
		
		$sender->Parent->Parent->panelPlanAcces->render($param->getNewWriter());
	}
}
