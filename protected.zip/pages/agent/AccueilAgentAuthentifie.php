<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class AccueilAgentAuthentifie extends AtexoPage {

	public function onInit()
	{
		$this->Master->setCalledFrom("agent");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		$tOrganisationQuery = new TOrganisationQuery();

		$tOrganisation = $tOrganisationQuery->getOrganisationById($this->User->getCurrentOrganism());
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$this->titreBienvenue->Text = $tOrganisation->getTitreBienvenueTraduit($lang);
		$this->msgBienvenue->Text = $tOrganisation->getMessageBienvenueTraduitHtml($lang);
	}
}