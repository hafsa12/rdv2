<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class AgentAccueil extends AtexoPage {

	public function onInit()
	{
		$this->Master->setCalledFrom("agent");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!$this->isPostBack) {
			
		}
	}

}