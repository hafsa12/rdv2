<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class CreerIndisponibilites extends AtexoPage {

	public function onInit()
	{
		$this->Master->setCalledFrom("ressource");
		Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
	}

	public function onLoad()
	{
		if(!Atexo_User_CurrentUser::hasHabilitation('GestionJoursIndisponibilites')) {
			$this->response->redirect("?page=ressource.AccueilRessourceAuthentifie");
		}
		if(!$this->isPostBack) {

		    $adminOrg = Atexo_User_CurrentUser::isAdminOrg();
			$adminEtab = Atexo_User_CurrentUser::isAdminEtab() || Atexo_User_CurrentUser::isAdminOrgWithEtab();

			if($adminOrg) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationGere();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
				$this->loadEtablissement();
			}

			if($adminEtab) {
				$idOrganisation = Atexo_User_CurrentUser::getIdOrganisationAttache();
				$this->listeOrganisation->SelectedValue=$idOrganisation;
				$this->listeOrganisation->Enabled=false;
				$this->loadEtablissement();
				if(is_numeric(Atexo_User_CurrentUser::getIdEtablissementGere())) {
					$this->listeEtablissement->SelectedValue=Atexo_User_CurrentUser::getIdEtablissementGere();
				}
			}
			else{

            }
			


			if(isset($_GET["idPeriodeIndisponibilite"])) {
				$this->remplir($_GET["idPeriodeIndisponibilite"]);
			}

		}
	}

	/**
	 * Remplir la liste des organisations
	 */
	public function loadOrganisation() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$organisationGestion = new Atexo_Organisation_Gestion();
		$this->listeOrganisation->DataSource = $organisationGestion->getAllOrganisation($lang, Prado::localize('SELECTIONNEZ'));
		$this->listeOrganisation->DataBind();
	}

	/**
	 * Remplir la liste des établissements
	 */
	public function loadEtablissement() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$etablissementGestion = new Atexo_Etablissement_Gestion();
		$this->listeEtablissement->DataSource = $etablissementGestion->getEtablissementByIdProvinceIdOrganisation($lang,$this->listeOrganisation->SelectedValue,null,Prado::localize('SELECTIONNEZ'),true);
		$this->listeEtablissement->DataBind();
	}

	
	/**
	 * Remplir la liste des ressources 
	 */
	public function loadRessource() {
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$ressourceGestion = new Atexo_Agent_Gestion();
		$this->listeRessource->DataSource = $ressourceGestion->getRessourceByIdAgent($lang,Atexo_User_CurrentUser::getIdAgent(),Prado::localize('SELECTIONNEZ'));
		$this->listeRessource->DataBind();
	}
	
	/**
	 * @param $idPeriodeIndisponibilite
	 * récuperer les informations d'une période d'indisponibilité
	 */
	public function remplir($idPeriodeIndisponibilite) {

		$tPeriodeIndisponibiliteQuery = new TPeriodeIndisponibiliteQuery();
		$tPeriodeIndisponibilite = $tPeriodeIndisponibiliteQuery->getPeriodeIndisponibiliteById($idPeriodeIndisponibilite);
		if ($tPeriodeIndisponibilite instanceof TPeriodeIndisponibilite) {
			
			$agendaGestion = new Atexo_Agenda_Gestion();
		    $agendas= $agendaGestion->getPrestationByIdAgent($tPeriodeIndisponibilite->getIdAgent());
			foreach($agendas as $agenda) {
			    $tPrestationQuery = new TPrestationQuery();
				$tPrestation = $tPrestationQuery->getPrestationById($agenda->getIdPrestation());
			}

			

			
			$dateDebut= explode(" ",$tPeriodeIndisponibilite->getDateDebut("d/m/Y H:i:s"));
			$dateFin= explode(" ",$tPeriodeIndisponibilite->getDateFin("d/m/Y H:i:s"));
			
			$this->datedebut->setText($dateDebut[0]);
			$this->timedebut->setText($dateDebut[1]);
			$this->datefin->setText($dateFin[0]);
			$this->timefin->setText($dateFin[1]);
		}
	}

	/**
	 * enregistrer les informations d'une période d'indisponibilité
	 */
	public function enregistrer() {

		$logger = Atexo_LoggerManager::getLogger("indisponibiliteLogInfo");
		$log = "Creation     : ";

		if(isset($_GET["idPeriodeIndisponibilite"])) {
			$log = "Modification : ";
			$tPeriodeIndisponibiliteQuery = new TPeriodeIndisponibiliteQuery();
			$tPeriodeIndisponibilite = $tPeriodeIndisponibiliteQuery->getPeriodeIndisponibiliteById($_GET["idPeriodeIndisponibilite"]);
		}

		if(!($tPeriodeIndisponibilite instanceof TPeriodeIndisponibilite)) {
			$log = "Creation     : ";
			$tPeriodeIndisponibilite = new TPeriodeIndisponibilite();
		}
		$log .= date("Y-m-d H:i:s"). " : ";
		$tPeriodeIndisponibilite->setIdAgent(Atexo_User_CurrentUser::getIdAgent());
		$tPeriodeIndisponibilite->setDateDebut(Atexo_Utils_Util :: frnDate2iso($this->datedebut->SafeText).' '.$this->timedebut->SafeText.":00");
		$tPeriodeIndisponibilite->setDateFin(Atexo_Utils_Util :: frnDate2iso($this->datefin->SafeText).' '.$this->timefin->SafeText.":59");

		$tPeriodeIndisponibilite->save();

		$log .= "Id : ".$tPeriodeIndisponibilite->getIdPeriodeIndisponibilite()
				." IdRessource : ".$tPeriodeIndisponibilite->getIdAgent()
				." Date debut : ".$tPeriodeIndisponibilite->getDateDebut("Y-m-d H:i:s")." Date fin : ".$tPeriodeIndisponibilite->getDateFin("Y-m-d H:i:s")
				." Id Ressource : ".Atexo_User_CurrentUser::getIdAgent();
		$logger->info($log);

		$url = "index.php?page=ressource.GestionIndisponibilites&search";
		$this->response->redirect($url);
	}
}