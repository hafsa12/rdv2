<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class GestionIndisponibilites extends AtexoPage {

    private $_lang = "";
    /**
     * @var Atexo_Agent_CriteriaVo
     */
    protected $_criteriaVo = "";

    public function onInit()
    {
        $this->Master->setCalledFrom("ressource");
        Atexo_Utils_Languages::setLanguageCatalogue($this->Master->getCalledFrom());
    }

    public function onLoad()
    {
        if(!Atexo_User_CurrentUser::hasHabilitation('GestionJoursIndisponibilites')) {
            $this->response->redirect("?page=ressource.AccueilRessourceAuthentifie");
        }
        $this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
        if(!$this->isPostBack) {
            if(!isset($_GET["search"])) {
                unset($_SESSION["indispo"]["criteriaVoSearch"]);
                unset($_SESSION["indispo"]["sensTri"]);
                unset($_SESSION["indispo"]["sortByElement"]);
            }
            $this->init();
        }
        else {
            $this->_criteriaVo = $_SESSION["indispo"]["criteriaVoSearch"];
        }
    }

    protected function init() {

        $this->_criteriaVo = $_SESSION["indispo"]["criteriaVoSearch"];


        if(!$this->_criteriaVo)
        {

            $this->_criteriaVo = new Atexo_Agent_CriteriaVo();

            $this->loadDataTypePrestation();
            $this->_criteriaVo->setForRessource(true);
            $this->_criteriaVo->setForIndisponibilite(true);
            $this->_criteriaVo->setSortByElement("PI.DATE_FIN");
            $this->_criteriaVo->setSensOrderBy("DESC");
            $_SESSION["indispo"]["sortByElement"] = "PI.DATE_FIN";
            $_SESSION["indispo"]["sensTri"] = "DESC";
        }
        else {
            $idEtablissement = $this->_criteriaVo->getIdEtablissementAttache();
            $idTypePrestation = $this->_criteriaVo->getIdTypePrestation();
            $idPrestation = $this->_criteriaVo->getIdPrestation();



            $this->loadDataTypePrestation ();
            if( $idTypePrestation ) {
                $this->typePrestationRessource->setSelectedValue ( $idTypePrestation );
            }
            else {
                $this->typePrestationRessource->SelectedIndex = 0;
            }
            $this->loadDataPrestation ();
            if( $idPrestation ) {
                $this->prestationRessource->setSelectedValue ( $idPrestation );
            }
            else {
                $this->prestationRessource->SelectedIndex = 0;
            }
        }
        $this->_criteriaVo->setLang($this->_lang);

        if( isset( $_GET["pages"] ) ) {
            $this->_criteriaVo->setPages($_GET["pages"]);
        }
        else {
            if(!$this->_criteriaVo->getPages()) {
                $this->_criteriaVo->setPages(1);
            }
        }

        if( isset( $_GET["pageSize"] ) ) {
            $ps = Atexo_Pagination_Controller::verifierPageSizePagination( $_GET["pageSize"] );
            $this->listeRessources->PageSize = $ps;
            $this->_criteriaVo->setPageSize( $ps );
        }
        elseif ( !$this->_criteriaVo->getPageSize() ) {
            $this->_criteriaVo->setPageSize(10);
        }
        $idAgent = Atexo_User_CurrentUser::getIdAgent();
        $this->_criteriaVo->setIdAgent($idAgent);
        $tAgentQuery = new TAgentQuery();
        $tAgent = $tAgentQuery->getAgentById($idAgent);
        $this->_criteriaVo->setIdEtablissementAttache($tAgent->getIdEtablissementAttache());
        $this->fillRepeaterWithDataForSearchResult();
    }
    /**
     * Remplir repeater des périodes d'indisponibilité selon les critères de recherche
     */
    public function fillRepeaterWithDataForSearchResult()
    {
        $tAgentPeer = new TAgentPeer();
        //Nombre des agents
        $nombreElement = $tAgentPeer->getRessourceByCriteres($this->_criteriaVo, true, null, $this->_criteriaVo->getIdAgent());
        if ($nombreElement>=1) {
            $this->nombreElement->Text=$nombreElement;
            $this->PagerBottom->setVisible(true);
            $this->PagerTop->setVisible(true);
            $this->pagerPanelTop->setVisible(true);
            $this->pagerPanelBottom->setVisible(true);
            $this->setViewState("nombreElement",$nombreElement);
            $this->listeRessources->setVirtualItemCount($nombreElement);
            $this->listeRessources->setCurrentPageIndex(0);
            $this->populateData();
        } else {
            $this->PagerBottom->setVisible(false);
            $this->PagerTop->setVisible(false);
            $this->pagerPanelBottom->setVisible(false);
            $this->pagerPanelTop->setVisible(false);
            $this->listeRessources->DataSource=array();
            $this->listeRessources->DataBind();
            $this->nombreElement->Text="0";
        }
        $_SESSION["indispo"]["criteriaVoSearch"] = $this->_criteriaVo;
    }


    /**
     * Remplir liste Organisation
     */
    public function remplirListeOrganisation() {
        $organisations = new Atexo_Organisation_Gestion();
        $this->organisationRessource->DataSource = $organisations->getAllOrganisation($this->_lang, Prado::localize('ORGANISATION'));
        $this->organisationRessource->DataBind();
    }


    /**
     * Remplir liste Etablissement
     */
    public function loadDataEtablissement($idEntite1 = null, $idsEntite2 = null) {
        $idOrganisation = $this->organisationRessource->getSelectedValue();
        if($idEntite1) {
            $entiteGestion = new Atexo_Entite_Gestion();
            $idsCommune = $entiteGestion->getAllIdChildEntite ($idEntite1);
        }
        if($idsEntite2) {
            $entiteGestion = new Atexo_Entite_Gestion();
            $idsCommune = $entiteGestion->getAllIdChildEntite ($idsEntite2);
        }
        if($this->entite3->getSelectedValue ()) {
            $idsCommune = $this->entite3->getSelectedValue ();
        }

        //Remplir liste Etablissement
        $etablissements = new Atexo_Etablissement_Gestion();
        $this->etablissementRessource->DataSource = $etablissements->getEtablissementByIdProvinceIdOrganisation($this->_lang, $idOrganisation, $idsCommune, /*Prado::localize('ETABLISSEMENT')*/false, true);
        $this->etablissementRessource->DataBind();
        $this->etablissementRessource->SetSelectedIndex(0);
    }

    public function loadEtablissement($sender, $param) {
        $this->loadDataEtablissement();
        $this->etablissementRessource->SelectedIndex=0;
        $this->_criteriaVo->setIdEtablissementAttache($this->etablissementRessource->getSelectedValue());
        $this->loadDataTypePrestation();
        $this->etablissementRessource->render($param->NewWriter);
    }

    /**
     * Remplir liste Type Prestation
     */
    public function loadDataTypePrestation($sender=null,$param=null) {
        //$idEtab = $this->etablissementRessource->getSelectedValue();
        $idAgent = Atexo_User_CurrentUser::getIdAgent();
        $tAgentQuery = new TAgentQuery();
        $tAgent = $tAgentQuery->getAgentById($idAgent);
        $idEtab = $tAgent->getIdEtablissementAttache();
        $typePrests = new Atexo_TypePrestation_Gestion();
        $this->typePrestationRessource->DataSource = $typePrests->getTypePrestationByIdEtab($this->_lang,$idEtab, Prado::localize('TYPE_PRESTATION'));
        $this->typePrestationRessource->DataBind();
        $this->loadDataPrestation();
    }

    public function loadDataPrestation() {
        $idTypePrestation = $this->typePrestationRessource->getSelectedValue();
        if(!$idTypePrestation) {
            $idTypePrestation = array();
            foreach($this->typePrestationRessource->Items as $item) {
                $idTypePrestation[] = $item->getValue();
            }
        }
        if(isset($_SESSION['idOrg'])) {
            $tOrganisation = TOrganisationQuery::create()->getOrganisationById($_SESSION['idOrg']);
        }
        $typePrestation = $tOrganisation instanceof TOrganisation ? $tOrganisation->getTypePrestation() : Atexo_Config::getParameter("PRESTATION_SAISIE_LIBRE");
        //Remplir liste Type Prestation
        $PrestationGestion = new Atexo_Prestation_Gestion();
        $this->prestationRessource->DataSource = $PrestationGestion->getPrestationByIdTypePrestation($this->_lang,$idTypePrestation, $typePrestation, Prado::localize('PRESTATION'));
        $this->prestationRessource->DataBind();
    }


    /**
     * Rechercher une ressource par mot-clé
     */
    protected function searchRessource($sender,$param) {
        try {
            $token = $this->motsCles->SafeText;
            $this->_criteriaVo = new Atexo_Agent_CriteriaVo();
            $this->_criteriaVo->setLang ( $this->_lang );
            $this->_criteriaVo->setForRessource ( true );
            $this->_criteriaVo->setForIndisponibilite ( true );
            $this->_criteriaVo->setMotCle ( $token );

            $this->_criteriaVo->setIdTypePrestation ( $this->typePrestationRessource->getSelectedValue () );
            $this->_criteriaVo->setIdPrestation ( $this->prestationRessource->getSelectedValue () );

            $this->_criteriaVo->setPages(1);
            $this->_criteriaVo->setPageSize(10);

            // tri
            $this->_criteriaVo->setSortByElement($_SESSION["indispo"]["sortByElement"]);
            $this->_criteriaVo->setSensOrderBy($_SESSION["indispo"]["sensTri"]);

            unset($_GET["pageSize"]);
            unset($_GET["pages"]);
            $idAgent = Atexo_User_CurrentUser::getIdAgent();
            $this->_criteriaVo->setIdAgent($idAgent);
            $tAgentQuery = new TAgentQuery();
            $tAgent = $tAgentQuery->getAgentById($idAgent);
            $this->_criteriaVo->setIdEtablissementAttache($tAgent->getIdEtablissementAttache());
            $this->_criteriaVo->setIdAgent($idAgent);
            $this->fillRepeaterWithDataForSearchResult ();
            $this->ressourcesPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
    }

    /**
     * Peupler les données des périodes d'indisponibilité
     */
    public function populateData()
    {
        $nombreElement = $this->getViewState("nombreElement");
        $pageSize = $this->_criteriaVo->getPageSize();
        $nombrePages = ceil($nombreElement / $pageSize);

        if(isset($_GET["pages"])) {
            $numPage = Atexo_Pagination_Controller::verifierPagePagination($_GET["pages"], $this->listeRessources->CurrentPageIndex+1, $nombrePages);
            $this->_criteriaVo->setPages($numPage);
        }elseif($this->_criteriaVo->getPages()){
            $numPage = $this->_criteriaVo->getPages();
        }
        $this->listeRessources->CurrentPageIndex = $numPage -1;

        $offset = $this->listeRessources->CurrentPageIndex * $pageSize;
        $limit = $pageSize;
        $this->listeRessources->PageSize = $limit;

        if ($offset + $limit > $nombreElement) {
            $limit = $nombreElement - $offset;
        }
        $this->_criteriaVo->setOffset($offset);
        $this->_criteriaVo->setLimit($limit);
        $dataAgents = TAgentPeer::getRessourceByCriteres($this->_criteriaVo, false, null, $this->_criteriaVo->getIdAgent());
        $this->listeRessources->DataSource=$dataAgents;
        $this->listeRessources->DataBind();

        $this->numPageBottom->Text = $numPage;
        $this->numPageTop->Text = $numPage;
        $this->nombreResultatAfficherTop->setSelectedValue( $pageSize );
        $this->nombreResultatAfficherBottom->setSelectedValue( $pageSize );
        $this->nombrePageTop->Text = $nombrePages;
        $this->nombrePageBottom->Text = $nombrePages;
    }



    /**
     * Trier les données
     */
    public function Trier($sender,$param)
    {
        try {
            $champsOrderBy = $sender->CommandParameter;

            $_SESSION["indispo"]["sortByElement"] = $champsOrderBy;
            $this->_criteriaVo->setSortByElement ( $champsOrderBy );

            $_SESSION["indispo"]["sensTri"] = ( $this->_criteriaVo->getSensOrderBy () == "ASC" ) ? "DESC" : "ASC";
            $this->_criteriaVo->setSensOrderBy ( $_SESSION["indispo"]["sensTri"] );

            $_SESSION["indispo"]["criteriaVoSearch"] = $this->_criteriaVo;
            unset($_GET["pages"]);
            $this->_criteriaVo->setPages(1);
            $this->populateData ();
            $this->ressourcesPanel->render ( $param->getNewWriter () );
        } catch(Exception $e) {
            $logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
            $logger->error($e->getMessage());
        }
    }

    public function pageChanged($sender,$param)
    {
        $urlParams = "&pages=".($param->NewPageIndex+1);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=ressource.GestionIndisponibilites&search".$urlParams);
    }

    public function goToPage($sender)
    {
        switch ($sender->ID) {
            case "DefaultButtonTop" :
                $numPage = $this->numPageTop->Text;
                break;
            case "DefaultButtonBottom" :
                $numPage = $this->numPageBottom->Text;
                break;
        }
        $urlParams = "&pages=" . Atexo_Pagination_Controller::verifierPagePagination($numPage, $this->listeRessources->CurrentPageIndex+1, $this->nombrePageTop->Text);
        if(isset($_GET["pageSize"])) {
            $urlParams .= "&pageSize=".$_GET["pageSize"];
        }
        $this->response->redirect("?page=ressource.GestionIndisponibilites&search".$urlParams);
    }

    public function changePagerLenght($sender)
    {
        switch ($sender->ID) {
            case "nombreResultatAfficherBottom" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherBottom->getSelectedValue());
                break;
            case "nombreResultatAfficherTop" :
                $pageSize = Atexo_Pagination_Controller::verifierPageSizePagination($this->nombreResultatAfficherTop->getSelectedValue());
                break;
        }
        $this->response->redirect("?page=ressource.GestionIndisponibilites&search&pages=1&pageSize=".$pageSize);
    }

    /**
     * Confirmer la suppression d'une période d'indisponibilité
     */
    public function onConfirmSuppressionClick() {
        $tPeriodeIndisponibiliteQuery = new TPeriodeIndisponibiliteQuery();
        $idPeriodeIndisp = $this->indisponibiliteToDeleteHidden->Value;
        $tPeriodeIndisponibilite = $tPeriodeIndisponibiliteQuery->getPeriodeIndisponibiliteById($idPeriodeIndisp);

        if($tPeriodeIndisponibilite instanceof TPeriodeIndisponibilite) {
            $tPeriodeIndisponibilite->delete();
            $this->paneldeleteOk->setStyle('display:Block');
        }

        //Remplir repeater Agents
        $this->fillRepeaterWithDataForSearchResult();
    }

    public function isTrierPar($champ) {
        $sortByElement = $_SESSION["indispo"]["sortByElement"];
        if($champ!=$sortByElement) {
            return "";
        }
        if($_SESSION["indispo"]["sensTri"]=="ASC") {
            return "tri-on tri-asc";
        }
        return "tri-on tri-desc";
    }

    /**
     * Remplir la liste des regions
     */
    public function loadEntite1() {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite1->DataSource = $entiteGestion->getAllEntite(1, $this->_lang, null, Prado::localize('ENTITE_1'));
        $this->entite1->DataBind();
    }

    /**
     * Remplir la liste des provinces
     */
    public function loadEntite2($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $this->entite2->DataSource = $entiteGestion->getAllEntite(2, $this->_lang, $this->entite1->SelectedValue, Prado::localize('ENTITE_2'));
        $this->entite2->DataBind();
        if($sender) {
            $this->loadEntite3();
            $this->loadDataEtablissement($this->entite1->getSelectedValue());
        }
    }

    /**
     * Remplir la liste des communes
     */
    public function loadEntite3($sender = null) {
        $entiteGestion = new Atexo_Entite_Gestion();
        $idEntite = null;

        if($this->entite2->SelectedValue) {
            $idEntite = $this->entite2->SelectedValue;
        }elseif($this->entite1->SelectedValue){
            $idEntite = $entiteGestion->getAllIdChildEntite($this->entite1->SelectedValue);
        }

        $this->entite3->DataSource = $entiteGestion->getAllEntite(3, $this->_lang, $idEntite, Prado::localize('ENTITE_3'));
        $this->entite3->DataBind();
        if($sender) {
            $this->loadDataEtablissement($this->entite1->getSelectedValue(), $this->entite2->getSelectedValue());
        }
    }

    public function goToPrendreRdv(){
        Atexo_User_CurrentUser::writeToSession('addUrlRedirectUrl','?'.$_SERVER['QUERY_STRING']);
        $this->response->redirect("page=ressource.PrendreRendezVousRessource");
    }
}
