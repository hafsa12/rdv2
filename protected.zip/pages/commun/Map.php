<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Map extends TPage{

    public $lat;
    public $long;
    public function onLoad()
    {
        if($_GET['lat'] == "" || $_GET['long'] == ""){
            echo "Problème de récupération des coordonnées";
            exit;
        }
        $this->lat = $_GET['lat'];
        $this->long = $_GET['long'];
    }

}