<?php
/**
 * description de la classe
 *
 * @author elalaoui youssef <youssef.elalaoui@atexo.com>
 * @copyright Atexo 2010
 * @version 0.0
 * @since Atexo.Forpro
 * @package atexo
 * @subpackage atexo
 */

class Auth extends AtexoPage {

 	public function onLoad()
    {
    	$returnUrl = $this->Application->getModule("auth")->ReturnUrl;
    	//echo $returnUrl;exit;
        if (isset($_GET["redirectOrg"])) {
			$idOrganisme = $_GET['idOrganisme'];
			$idReferent = $_GET['idReferent'];
			$ticket = sha1 ("ATEXO_TEST" . $idOrganisme . $idReferent);
			if ($ticket == $_GET['ticket']) {
				$compteVo = new Atexo_User_CompteVo();
		        $compteVo->setIdOrganisme(Atexo_User_CurrentUser::readFromSession("idOrganisme"));
				$compteVo->setIdReferent(Atexo_User_CurrentUser::readFromSession("idReferent"));
		        $compteVo->setType("agentOrganisme");
				Atexo_User_CurrentUser::deleteFromSession("idOrganisme");
				Atexo_User_CurrentUser::deleteFromSession("idReferent");
		        if($this->getApplication()->getModule("auth")->login($compteVo,null))
		        {
		        	$this->response->redirect("?page=organisme.Accueil");
		        	return;
		        }
	        }
        }
    	if (!$returnUrl)
        {
            $this->response->redirect("?page=citoyen.Accueil");
        } elseif (strstr($returnUrl, "page=agent.")) {
            // redirection vers la page d'autentification locale
            	$this->response->redirect("?page=agent.AgentAccueil&goto=".$returnUrl);
        }
    	elseif (strstr($returnUrl, "page=administration.")) {
            // redirection vers la page d'autentification locale
            	$this->response->redirect("?page=administration.AdministrationAccueil&goto=".$returnUrl);
        }
        //echo $returnUrl; exit;	
    }
}