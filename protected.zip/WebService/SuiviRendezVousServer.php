<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class SuiviRendezVousServer
{
	/**
	 * @param string $fluxXml requete
	 * @param string $lang la langue
	 * @return string $reponse contient la reponse
	 * @soapmethod
	 */

	public function getInfoRdv($fluxXml)
	{
		try {
			$id = '';
			$tabparam= array();
			$codeRep = '';
			$descE	= '';
			$dom = new DOMDocument;
			$dom->loadXML($fluxXml);
			$lang = $dom->getElementsByTagName('Langue');
			$lang = $lang->item(0)->firstChild->nodeValue;
			Atexo_User_CurrentUser::writeToSession("lang",$lang);
			$params = $dom->getElementsByTagName('Parametre');
			//file_put_contents("/tmp/xml.xml",$fluxXml);
			foreach ($params as $param) {
				$identifiants = $param->getElementsByTagName('Identifiant');
				foreach ($identifiants as $identifiant) {
					$identifiant = $identifiant->nodeValue;
					$valeurs = $param->getElementsByTagName('Valeur');
					foreach ($valeurs as $valeur) {
						if($identifiant == 'codeRdv'){
							$codeRdv = $valeur->nodeValue;
						}
						if($identifiant == 'email'){
							$email = $valeur->nodeValue;
						}
						if($identifiant == 'phone'){
							$phone = $valeur->nodeValue;
						}
					}
				}
			}
			if($codeRdv && ($email || $phone)){
				$rdv = Atexo_RendezVous_Gestion::retrieveRdvByCodeEmailTel($codeRdv,$email,$phone);
				if($rdv){
					$id = $codeRdv;
					$codeRep = '0';
					$tabparam = $this->remplirTabParam($lang,$id,$rdv);
				}else{
					$id = $codeRdv;
					$codeRep= '2';
					$descE	= Prado::localize("AUCUN_RENDEZ_VOUS_NE_CORRESPOND_A_VOS_CRITERES");
				}
			}else if(!$codeRdv){
				$codeRep= '1';
				$descE	= Prado::localize("MANQUE_CODE_RDV");
			}else{
				$id = $codeRdv;
				$codeRep= '1';
				$descE	= Prado::localize("EMAIL_OU_TELEPHONE_OBLIGATOIRE");
			}
			$xmlReponse = $this->creerXml($tabparam,$codeRep,$descE);
			return ($xmlReponse);
		}catch(Exception $e){
			$logger = Atexo_LoggerManager::getLogger("rdvLogErreur");
		    $logger->error($e->getMessage());
		}
	}

	/**
	 * @param $lang, $id, $rdv
	 * Remplir le tableau des paramétres
	 */
	public function remplirTabParam($lang,$id,$rdv)
	{

		$tabparam= array();

		$etab = $rdv->getTEtablissement();
		$tOrganisation = $etab->getTOrganisation();
		Atexo_Utils_Languages::setLanguageCatalogue("citoyen", $tOrganisation->getAcronyme());

		$tabparam[0]['TITRE'] = Prado::localize("NOM")." : ";
		$tabparam[0]['VALEUR']=$rdv->getTCitoyen()->getNom()." ".$rdv->getTCitoyen()->getPrenom();
		$tabparam[1]['TITRE'] = Prado::localize("DENOMINATION_ETABLISSEMENT")." : ";
		$tabparam[1]['VALEUR']=$etab->getDenominationEtablissementTraduit($lang);
		$tabparam[2]['TITRE'] = Prado::localize("ADRESSE")." : ";
		$tabparam[2]['VALEUR']=$etab->getAdresseEtablissementTraduit($lang);
		$tabparam[3]['TITRE'] = Prado::localize("TELEPHONE")." : ";
		$tabparam[3]['VALEUR']=$etab->getTelephoneRdv();
		$tabparam[4]['TITRE'] = Prado::localize("TYPE_PRESTATION")." : ";
		$tabparam[4]['VALEUR']=$rdv->getTPrestation()->getTTypePrestation()->getLibelleTypePrestationTraduit($lang);
		$tabparam[5]['TITRE'] = Prado::localize("PRESTATION")." : ";
		$tabparam[5]['VALEUR']=$rdv->getTPrestation()->getLibellePrestationTraduit($lang);
		if($rdv->getIdAgentRessource()!=null && $rdv->getIdAgentRessource()!="") {
			$tabparam[6]['TITRE'] = Prado::localize("NIVEAU3")." : ";
			$tAgentQuery = new TAgentQuery();
			$tAgent = $tAgentQuery->getAgentById($rdv->getIdAgentRessource());
			$tabparam[6]['VALEUR']=$tAgent->getNomPrenomUtilisateurTraduit($lang);
		}
		$tabparam[7]['TITRE'] = Prado::localize("HORAIRES")." : ";
		$tabparam[7]['VALEUR']=$rdv->getDateRdv("d/m/Y")." ".$rdv->getDateRdv("H:i");
		$tabparam[8]['TITRE'] = Prado::localize("COMMENTAIRE")." : ";
		$tabparam[8]['VALEUR']=$rdv->getTPrestation()->getCommentaireTraduit($lang);
		$tabparam[9]['TITRE'] = Prado::localize("ETAT_RDV")." : ";
		switch ($rdv->getEtatRdv()) {
				case Atexo_Config::getParameter('ETAT_EN_ATTENTE') : $tabparam[9]['VALEUR'] = Prado::localize('EN_ATTENTE');
																		break;
				case Atexo_Config::getParameter('ETAT_CONFIRME') : $tabparam[9]['VALEUR'] = Prado::localize('CONFIRME');
																		break;
                case Atexo_Config::getParameter('ETAT_NON_HONORE_ETAB') : $tabparam[9]['VALEUR'] = Prado::localize('NON_HONORE_ETAB');
                                                                          break;
                case Atexo_Config::getParameter('ETAT_NON_HONORE') : $tabparam[9]['VALEUR'] = Prado::localize('NON_HONORE_CITOYEN');
                                                                          break;
				case Atexo_Config::getParameter('ETAT_ANNULE_ETAB') : $tabparam[9]['VALEUR'] = Prado::localize('ANNULE_ETAB');
                                                                      break;
				case Atexo_Config::getParameter('ETAT_ANNULE') : $tabparam[9]['VALEUR'] = Prado::localize('ANNULE');
                                                                 $tabparam[10]['TITRE'] = Prado::localize("MOTIF_ANNULATION")." : ";
                                                                 $tabparam[10]['VALEUR']= $rdv->getMotifAnnulationRdv($lang);
                                                                 break;
		}
		$tabparam[11]['TITRE'] = Prado::localize("LE_CODE_DE_CONFIRMATION")." : ";
		$tabparam[11]['VALEUR']=$id;
		$tabparam[12]['TITRE'] = Prado::localize("POUR_PLUS_INFO")." : ";
		$tabparam[12]['VALEUR'] = " <a href='" . $tOrganisation->getPfUrl() . "?page=citoyen.GererRendezVous'>".Prado::localize("CLIQUER_ICI")."</a> ";
		return $tabparam ;
	}

	/**
	 * @param $tabparam, $codeRep, $descE
	 * Créer le fichier XML à partir du tableau des paramétres
	 */
	public function creerXml($tabparam,$codeRep,$descE)
	{
		$fichierXml = new DOMDocument('1.0', 'UTF-8');
		$reponse = $fichierXml->appendChild($fichierXml->createElement("Reponse"));
		$codeReponse = $reponse->appendChild($fichierXml->createElement("CodeReponse"));
		$codeReponse->appendChild($fichierXml->createTextNode($codeRep));
		$descErreur = $reponse->appendChild($fichierXml->createElement("DescriptionErreur"));
		$descErreur->appendChild($fichierXml->createTextNode($descE));
		$params = $reponse->appendChild($fichierXml->createElement("Messages"));
		foreach($tabparam as $parametre){
			$param = $fichierXml->createElement("Message");
			$param = $params->appendChild($param);
			$titre= $param->appendChild($fichierXml->createElement("Titre"));
			$titre->appendChild($fichierXml->createTextNode($parametre['TITRE']));
			$valeur = $param->appendChild($fichierXml->createElement("Valeur"));
			$valeur->appendChild($fichierXml->createTextNode($parametre['VALEUR']));
		}
		return $fichierXml->saveXML();
	}
}