<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class Popup extends TPage{

	public $cssLang="";

	public function onInit()
	{
		Atexo_Utils_Languages::setLanguageCatalogue('citoyen');
	}

	public function onLoad()
	{
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		if ($lang == "ar") {
			$this->cssLang = ".rtl";
		}
	}

	public function isCalled(){
		if(Atexo_CurrentUser::readFromSession('calledFrom') && 
		   Atexo_CurrentUser::readFromSession('calledFrom')!= 'public' && 
		   Atexo_CurrentUser::readFromSession('calledFrom')!= 'citoyen' && 
		   !$this->user->IsGuest) {
			return true;
		}
		else {
			return false;
		}
	}
}