<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class PopUpLayout extends TTemplateControl {

	private $_roles = array();

	public function onLoad()
	{
		$this->_roles=$this->User->getRoles();
	}
	public function onInit() {
		Atexo_Utils_Languages::setLanguageCatalogue('citoyen');
	}
	public function setCalledFrom($value)
	{
		$this->_calledFrom = $value;
	}

	public function isCalledFromAgent()
	{
		return $this->_calledFrom == "agent";
	}

	public function isCalledFromCompany()
	{
		return $this->_calledFrom == "citoyen";
	}
	public function getConnecteAgent()
	{
		$valeur=$this->_roles;
		if($valeur[1]=='Agent') {
			return true;
		}
		else {
			return false;
		}
	}
	public function getMenugaucheAgent()
	{
		$valeur=$this->_roles;
		if($valeur[1]=='Agent') {
		return true;
		}
		else { 
			return false;	
		}

	}
	public function getFooterAgent()
	{
		return true;
	}

	public function getConnecteAdmin()
	{
		$valeur=$this->_roles;
		if($valeur[1]=='Admin') {
		return true;
		}
		else {
			return false;	
		}

	}
	public function getMenugaucheAdmin()
	{
		$valeur=$this->_roles;
		if($valeur[1]=='Admin'){
		return true;
		}
		else {
			return false;	
		}
	}

	public function getConnecteEntreprise()
	{
		$valeur=$this->_roles;
		if($valeur[1]=='Entreprise'){
		return true;
		}
		else {
			return false;	
		}
	}

	public function getMenugaucheEntreprise()
	{
		$valeur=$this->_roles;
		if($valeur[1]=='Entreprise'){
		return true;
		}
		else {
			return false;	
		}
	}

	public function getFooterAdmin()
	{

	}
	public function includeJsLang($nameFile)
	{
		$lang = "";
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		if($lang != "") {
			return  $nameFile . "." . $lang.".js";
		}else {
			return  $nameFile . ".js";
		}
			
	}

}
