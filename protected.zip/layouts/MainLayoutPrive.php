<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class MainLayoutPrive extends TTemplateControl
{
	private $_roles = array();
	public $_calledFrom = "";
	private $calledPage = "";
	public $priseRdv=false;
	public $cssLang="";
	public $showPicker=true;

	public function setPrendreRdv($priseRdv) {
		$this->priseRdv = $priseRdv;
	}

	public function setShowPicker($showPicker) {
		$this->showPicker = $showPicker;
	}

	public function onLoad()
	{
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		if($lang=="ar") {
			$this->cssLang=".rtl";
		}
		// Gestion de l'internationalisation
		$langues = explode(",", Atexo_Config::getParameter("LANGUES_ACTIVES"));
		//$globalization = $this->getApplication()->Modules["globalization"];
		//$globalization->setTranslationCatalogue('');
		if ($this->_calledFrom == "agent" || $this->_calledFrom == "admin" || $this->_calledFrom == "ressource") {
			if (! isset($_GET['lang']) ) {//echo "**";exit;
				if (! (Atexo_User_CurrentUser::readFromSession("lang"))) {
					$langueEnSession = Atexo_Config::getParameter('LANGUE_PAR_DEFAUT_AGENT');
				} else {
					$langueEnSession = Atexo_User_CurrentUser::readFromSession("lang");
				}
			} else {
				$langueEnSession = $_GET['lang'];
			}

			if ( in_array($langueEnSession, $langues) || $langueEnSession == 'atx') {
				// Enregistrement en session
				Atexo_User_CurrentUser::writeToSession("lang", $langueEnSession);
				//Atexo_User_CurrentUser::writeToSession("catalogue", $globalization->getTranslationCatalogue());
				//$globalization->setTranslationCatalogue("messages." . $langueEnSession);
			} else {
				unset($_GET['lang']);
				$langueEnSession = Atexo_Config::getParameter('LANGUE_PAR_DEFAUT_AGENT');
				//$globalization->setTranslationCatalogue("messages." . $langueEnSession);
			}
		}
		if ($this->_calledFrom == "citoyen") {
			if (! isset($_GET['lang']) || ! in_array($_GET['lang'], $langues)) {
				{
					if (! (Atexo_User_CurrentUser::readFromSession("lang"))) {
						$langueEnSession = Atexo_Config::getParameter('LANGUE_PAR_DEFAUT_CITOYEN');
					} else {
						$langueEnSession = Atexo_User_CurrentUser::readFromSession("lang");
					}
				}
			} else {
				$langueEnSession = $_GET['lang'];
			}
			if ( in_array($langueEnSession, $langues) || $langueEnSession == 'atx') {
				// Enregistrement en session
				Atexo_User_CurrentUser::writeToSession("lang", $langueEnSession);
				//$globalization->setTranslationCatalogue("messages." . $langueEnSession);
				//Atexo_User_CurrentUser::writeToSession("catalogue", $globalization->getTranslationCatalogue());
			} else {
				unset($_GET['lang']);
				$langueEnSession = Atexo_Config::getParameter('LANGUE_PAR_DEFAUT_CITOYEN');
				//$globalization->setTranslationCatalogue("messages." . $langueEnSession);
			}
		}
//		$this->populateLiensFooter($langueEnSession);
	}

	public function setCalledFrom($value)
	{
		$this->_calledFrom = $value;
	}

	public function getCalledFrom()
	{
		return $this->_calledFrom;
	}

	public function isCalledFromAgent()
	{
		return $this->_calledFrom == "agent";
	}

	public function isCalledFromAdmin()
	{
		return $this->_calledFrom == "admin";
	}

	public function isCalledFromCitoyen()
	{
		return $this->_calledFrom == "citoyen";
	}

    public function isCalledFromRessource()
    {
        return $this->_calledFrom == "ressource";
    }

	public function getConnecteAgent()
	{
		$valeur = $this->_roles;
		if ($valeur[1] == 'Agent') {
			return true;
		}
		else {
			return false;
		}
	}

	public function getConnecteAdmin()
	{
		$valeur = $this->_roles;
		if ($valeur[1] == 'Admin') {
			return true;
		}
		else {
			return false;
		}

	}

	public function includeJsLang($nameFile)
	{
		$lang = "";
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		if($lang != "") {
			return  $nameFile . "." . $lang.".js";
		}else {
			return  $nameFile . ".js";
		}
			
	}

	public function setCalledPage ($param)
	{
		$this->calledPage = $param;
	}

	public function getCalledPage ()
	{
		return $this->calledPage ;
	}

	public function writeLanguage($sender,$param)
	{
		$langue = $param->CommandName;
		$keys = (array_keys($_GET));
		$values = (array_values($_GET));
		$urlParams = "?";
		$nbr = count($keys);
		for ($i=0; $i<$nbr; $i++) {
			if ($keys[$i] != "lang") {
				$urlParams .= $keys[$i] . "=" . $values[$i] . "&";
			}
		}
		$this->response->redirect($_SERVER['PHP_SELF'] . $urlParams . "lang=".$langue);
	}
//
//	protected function populateLiensFooter($lang)
//	{
//		if( $_SESSION["liensFooter"] ) {
//			$dataSource = $_SESSION["liensFooter"];
//		} elseif ( $_SESSION["idOrg"] ) {
//			$dataSource = array();
//			$tOrganisation = TOrganisationQuery::create()->getOrganisationById($_SESSION["idOrg"]);
//			if($tOrganisation instanceof TOrganisation){
//				$dataSource[$tOrganisation->getIdOrganisation()];
//
//				$tTraductionLien1 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien1();
//				$tTraductionLien2 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien2();
//				$tTraductionLien3 = $tOrganisation->getTTraductionRelatedByCodeLibelleLien3();
//
//				if($tTraductionLien1 instanceof TTraduction) {
//					$tTraductionLibelles = $tTraductionLien1->getTTraductionLibelles();
//					foreach($tTraductionLibelles as $tTraductionLibelle) {
//						if($tOrganisation->getUrlLien1 () && $tTraductionLibelle->getLibelle ()) {
//							$dataSource[ $tTraductionLibelle->getLang () ][ "lien1" ][ "url" ] = $tOrganisation->getUrlLien1 ();
//							$dataSource[ $tTraductionLibelle->getLang () ][ "lien1" ][ "libelle" ] = $tTraductionLibelle->getLibelle ();
//						}
//					}
//				}
//				if($tTraductionLien2 instanceof TTraduction) {
//					$tTraductionLibelles = $tTraductionLien2->getTTraductionLibelles();
//					foreach($tTraductionLibelles as $tTraductionLibelle) {
//						if($tOrganisation->getUrlLien2 () && $tTraductionLibelle->getLibelle ()) {
//							$dataSource[ $tTraductionLibelle->getLang () ][ "lien2" ][ "url" ] = $tOrganisation->getUrlLien2 ();
//							$dataSource[ $tTraductionLibelle->getLang () ][ "lien2" ][ "libelle" ] = $tTraductionLibelle->getLibelle ();
//						}
//					}
//				}
//				if($tTraductionLien3 instanceof TTraduction) {
//					$tTraductionLibelles = $tTraductionLien3->getTTraductionLibelles();
//					foreach($tTraductionLibelles as $tTraductionLibelle) {
//						if($tOrganisation->getUrlLien3 () && $tTraductionLibelle->getLibelle ()) {
//							$dataSource[ $tTraductionLibelle->getLang () ][ "lien3" ][ "url" ] = $tOrganisation->getUrlLien3 ();
//							$dataSource[ $tTraductionLibelle->getLang () ][ "lien3" ][ "libelle" ] = $tTraductionLibelle->getLibelle ();
//						}
//					}
//				}
//
//			}
//            $_SESSION["liensFooter"] = $dataSource;
//		}
//		$this->liensFooter->dataSource = $dataSource[$lang];
//		$this->liensFooter->dataBind();
//	}
}
