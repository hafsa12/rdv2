<?php echo '<' . '?xml version="1.0" encoding="ISO-8859-1"?' . '>'."\n";?>
<!-- Generation date : <?php echo date('d/m/Y H:i:s'); ?> -->
<?php
Atexo_Config::setParameterIfNotExists('PROJECT_NAME', 'atexo.rdv');
Atexo_Config::setParameterIfNotExists('PROPEL_PROJECT_NAME', 'RDV');
Atexo_Config::setParameterIfNotExists('PHP_LIB_PATH', '/usr/share/php');
Atexo_Config::setParameterIfNotExists('DB_ENCODING', 'utf8');
Atexo_Config::setParameterIfNotExists('HTTP_ENCODING', 'UTF-8');
Atexo_Config::setParameterIfNotExists('PROTOCOLE', 'http');
Atexo_Config::setParameterIfNotExists('PROPEL_FRAMEWORK_PATH', Atexo_Config::getParameter('PHP_LIB_PATH'). '/propel_1_6_9/runtime/lib');
Atexo_Config::addNameSpace('Application.var.mapping-propel.' . Atexo_Config::getParameter('PROPEL_PROJECT_NAME') . '.*');
Atexo_Config::addNameSpace('Application.var.mapping-propel.' . Atexo_Config::getParameter('PROPEL_PROJECT_NAME') . '.map.*');
Atexo_Config::addNameSpace('Application.var.mapping-propel.' . Atexo_Config::getParameter('PROPEL_PROJECT_NAME') . '.om.*');

Atexo_Config::setParameterIfNotExists('MODULE_TYPE_ETAB_62', '1');

// PATH
Atexo_Config::setParameterIfNotExists('BASE_ROOT_DIR', '/srv/data/'.Atexo_Config::getParameter('PROJECT_NAME'));
Atexo_Config::setParameterIfNotExists('HTTPD_USER', 'www-data');
Atexo_Config::setParameterIfNotExists('PRADO_FRAMEWORK_PATH', Atexo_Config::getParameter('PHP_LIB_PATH'). '/prado-3.2.1.r3258/framework');
Atexo_Config::setParameterIfNotExists('PRADO', 'pradolite'); // prado ou pradolite
Atexo_Config::setParameterIfNotExists('COMMON_TMP', Atexo_Config::getParameter('BASE_ROOT_DIR').'/tmp/');
Atexo_Config::setParameterIfNotExists('SESSION_FILES_PATH', '/var/lib/php5');

// LOGS
Atexo_Config::setParameterIfNotExists('LOG_FILE_PATH', Atexo_Config::getParameter('BASE_ROOT_DIR').'/logs');
Atexo_Config::setParameterIfNotExists('LOG_FILE_NAME', '/rdv_log');
Atexo_Config::setParameterIfNotExists('ID_ORGANISATION', '1');

?>

<application Mode="<?php echo Atexo_Config::getAppMode(); ?>">

<paths>
	<alias id="AtexoPdf" path="<?php echo Atexo_Config::getParameter('PHP_LIB_PATH'); ?>/atexo.pdf" />
	<alias id="AtexoLib" path="<?php echo Atexo_Config::getParameter('PHP_LIB_PATH'); ?>/atexo.php.libs" />
	<alias id="LogFilePath" path="<?php echo Atexo_Config::getParameter('LOG_FILE_PATH'); ?>" />
	<alias id="Log4Php" path="<?php echo Atexo_Config::getParameter('PHP_LIB_PATH'); ?>/log4php" />
	<alias id="PHPExcel" path="<?php echo Atexo_Config::getParameter('PHP_LIB_PATH'); ?>/PHPExcel" />
	<alias id="Ressources" path="../ressources/" />

	<using namespace="Application.pages.*" />
	<using namespace="Application.pages.commun.*" />
	<using namespace="Application.pages.commun.classes.*" />
	<using namespace="Application.controls.*" />
	<using namespace="Application.var.mapping-propel.*" />
	<using namespace="Application.library.Atexo.*" />
	<using namespace="Application.nusoap.*" />
	
	<using namespace="System.I18N.*" />
	<using namespace="System.Security.*" />
	<using namespace="System.Web.UI.ActiveControls.*"/>

	<using namespace="AtexoPdf.library.Atexo.*" />
	<using namespace="AtexoPdf.library.Atexo.PdfGenerator.*" />
	<using namespace="AtexoPdf.*" />
	<using namespace="AtexoPdf.client.*" />
	<using namespace="AtexoPdf.library.*" />
	<using namespace="Ressources.pages.*" />
	<using namespace="AtexoLib.Atexo.*" />
	<using namespace="Log4Php.*" />
	<using namespace="PHPExcel.*" />
		
<?php if (Atexo_Config::getNameSpacesCount()) : foreach (Atexo_Config::getNameSpaces() as $namespace) : ?>
	<using namespace="<?php echo $namespace; ?>"/>
<?php endforeach;
	endif;?>
</paths>

<modules>

	<module id="propel" class="AtexoLib.Atexo.XPropel" ConfigFile="protected/config/database/PropelConf.php" PropelPath="<?php echo Atexo_Config::getParameter('PROPEL_FRAMEWORK_PATH'); ?>"/>

	<module id="auth" class="TAuthManager" UserManager="users" LoginPage="commun.Auth" />

	<module id="users" class="Application.library.Atexo.User.Manager" PasswordMode="Clear" />
	
	<module id="globalization" class="TGlobalization" charset="utf-8">
		<translation type="XLIFF" source="Application.config.messages.*" marker="@@" autosave="false" cache="true" />
	</module>

	
	<module id="session" class="THttpSession" SessionName="atexoRdv" CookieMode="Allow" UseCustomStorage="false" AutoStart="false" GCProbability="1" UseTransparentSessionID="false"/>

</modules>

<services>
	<service id="page" class="TPageService" DefaultPage="commun.Auth">
		<pages MasterClass="Application.layouts.MainLayout" />
	</service>
	<service id="soap" class="System.Web.Services.TSoapService">
		<soap id="SuiviRendezVous" provider="Application.WebService.SuiviRendezVousServer"/>
	</service>
</services>

<parameters>
<?php

// BDD
Atexo_Config::setParameterIfNotExists('HOSTSPEC', 'localhost');
Atexo_Config::setParameterIfNotExists('HOSTSPEC_READ_ONLY', Atexo_Config::getParameter('HOSTSPEC'));
Atexo_Config::setParameterIfNotExists('USERNAME', 'root');
Atexo_Config::setParameterIfNotExists('PASSWORD', '');
Atexo_Config::setParameterIfNotExists('DB_NAME', 'RDV');
Atexo_Config::setParameterIfNotExists('DB_PREFIX', 'dev');
Atexo_Config::setParameterIfNotExists('DB_NAME_IN_UPPERCASE', '0');
Atexo_Config::setParameterIfNotExists('CONST_READ_WRITE', '');
Atexo_Config::setParameterIfNotExists('CONST_READ_ONLY', '_READ_ONLY');
Atexo_Config::setParameterIfNotExists('TIMEZONE', 'Africa/Casablanca');
Atexo_Config::setParameterIfNotExists('PATH_LOG_CONF', 'protected/config/log.xml');
// URL
Atexo_Config::setParameterIfNotExists('PF_URL', 'http://192.168.0.6/~boukataya/atexo.rdv/atexo.rdv/index.php?');

// I18N
Atexo_Config::setParameterIfNotExists('LANGUE_PAR_DEFAUT_ENTREPRISE', 'ar');

// Header mail
Atexo_Config::setParameterIfNotExists('PF_MAIL_FROM', 'nepasrepondre@entite.fr');


// Définition d'une sous-section pour les thémes d'un seul client
Atexo_Config::setParameterIfNotExists('THEMES_SECTION', '');
// Fichiers statiques à ne pas cacher (séparer par une virgule sans espace)
Atexo_Config::setParameterIfNotExists('THEMES_FILES_NOT_CACHED', '');
Atexo_Config::setParameterIfNotExists('CACHE_THEMES_JS', 'true'); // Met en cache les Javascript de themes
Atexo_Config::setParameterIfNotExists('CACHE_THEMES', 'true'); // Met en cache les fichiers de themes sauf ceux dans /js (voir CACHE_THEMES_JS pour les JS)

Atexo_Config::setParameterIfNotExists('PROPEL_GENERATOR_DIR', '/usr/local/propel/propel_generator');
Atexo_Config::setParameterIfNotExists('HEURE_DEBUT_JOUR', '00:00:00');
Atexo_Config::setParameterIfNotExists('HEURE_FIN_JOUR', '23:59:59');
Atexo_Config::setParameterIfNotExists('ETAT_EN_ATTENTE', '0');
Atexo_Config::setParameterIfNotExists('ETAT_CONFIRME', '1');
Atexo_Config::setParameterIfNotExists('ETAT_ANNULE', '2');
Atexo_Config::setParameterIfNotExists('ETAT_NON_HONORE', '3');
Atexo_Config::setParameterIfNotExists('ETAT_ANNULE_ETAB', '4');
Atexo_Config::setParameterIfNotExists('ETAT_NON_HONORE_ETAB', '5');
Atexo_Config::setParameterIfNotExists('TAILLE_CODE_RDV', '6');
Atexo_Config::setParameterIfNotExists('NB_MOIS_MAX_RDV', '24');

//Module
Atexo_Config::setParameterIfNotExists('MODULE_GOOGLE_MAP','1');

//Parm pays
Atexo_Config::setParameterIfNotExists('PARAM_PAYS','Maroc');

Atexo_Config::setParameterIfNotExists('MAX_TENTATIVES_MDP', '3');
Atexo_Config::setParameterIfNotExists('TAILLE_PASSWORD', '10');

// Header mail
Atexo_Config::setParameterIfNotExists('PF_MAIL_FROM', 'nepasrepondre@local-trust.com');
// Identification Plateforme
Atexo_Config::setParameterIfNotExists('PF_SHORT_NAME', 'RDV');
Atexo_Config::setParameterIfNotExists('PF_LONG_NAME' , "Portail de prise de rendez-vous");

// OPENSSL
Atexo_Config::setParameterIfNotExists('OPENSSL', '/usr/bin/openssl');

// Signature Mail
Atexo_Config::setParameterIfNotExists('SIGNATURE_MAIL', '0'); // Mettre a 1 pour activer la signature (AR reponse entreprise uniquement)
Atexo_Config::setParameterIfNotExists('SIGNATURE_MAIL_CHAINE', '0'); // Joindre la chaine
// Chaine de certification (AC Racine jusqu'a Emetteur du certificat smime)
Atexo_Config::setParameterIfNotExists('SIGNATURE_MAIL_CHAINE_CERTIFICAT', Atexo_Config::getParameter('BASE_ROOT_DIR') .'/common/ca/certs/' . 'nepasrepondre_marches-publics.gouv.fr.chaine.crt');
Atexo_Config::setParameterIfNotExists('SIGNATURE_MAIL_CERTIFICAT', Atexo_Config::getParameter('BASE_ROOT_DIR') .'/common/ca/certs/' . 's_mime.crt'); // Certificat utilise pour la signature des mails
Atexo_Config::setParameterIfNotExists('SIGNATURE_MAIL_CLE', Atexo_Config::getParameter('BASE_ROOT_DIR') .'/common/ca/keys/' . 's_mime_pkey.pem'); // Cle privee du certificat

//Langues actives
Atexo_Config::setParameterIfNotExists('LANGUES_ACTIVES', 'ar,fr');
Atexo_Config::setParameterIfNotExists('LANGUE_PAR_DEFAUT_AGENT', 'ar');
Atexo_Config::setParameterIfNotExists('LANGUE_PAR_DEFAUT_CITOYEN', 'ar');

//Les profils
Atexo_Config::setParameterIfNotExists('ID_PROFIL_ADMIN_SYSTEM', '1');
Atexo_Config::setParameterIfNotExists('ID_PROFIL_ADMIN_ORGANISATION', '2');
Atexo_Config::setParameterIfNotExists('ID_PROFIL_ADMIN_ETABLISSSEMENT', '3');
Atexo_Config::setParameterIfNotExists('ID_PROFIL_AGENT', '4');
Atexo_Config::setParameterIfNotExists('ID_PROFIL_AGENT_TO', '5');
Atexo_Config::setParameterIfNotExists('ID_PROFIL_AGENT_ACCUEIL', '6');
Atexo_Config::setParameterIfNotExists('MODE_AGENT_ADMIN', '3');
Atexo_Config::setParameterIfNotExists('MODE_AGENT_TELEOPERATEUR_SURPLACE', '2');
Atexo_Config::setParameterIfNotExists('MODE_AGENT_TELEOPERATEUR_TELEPHONE', '1');
Atexo_Config::setParameterIfNotExists('MODE_AGENT_INTERNET', '0');
Atexo_Config::setParameterIfNotExists('TYPE_INTERNET_DESKTOP', '1');
Atexo_Config::setParameterIfNotExists('TYPE_INTERNET_MOBILE', '2');
Atexo_Config::setParameterIfNotExists('TYPE_APPLI_MOBILE', '3');
Atexo_Config::setParameterIfNotExists('NOM_APPLI_MOBILE', 'ma.egov.sante.rdv');
Atexo_Config::setParameterIfNotExists('PATH_FILE',Atexo_Config::getParameter('BASE_ROOT_DIR').'/files/');

Atexo_Config::setParameterIfNotExists('PRESTATION_SAISIE_LIBRE', '0');
Atexo_Config::setParameterIfNotExists('PRESTATION_REFERENTIEL', '1');
Atexo_Config::setParameterIfNotExists('RDV_OU_ACTIVE', '0');
Atexo_Config::setParameterIfNotExists('HEURE_OUVERTURE_ETENDU', '08:00');
Atexo_Config::setParameterIfNotExists('HEURE_FERMETURE_ETENDU', '18:00');
Atexo_Config::setParameterIfNotExists('LOGO_RDV', '0');

Atexo_Config::setParameterIfNotExists('ENUM_OUI', '1');
Atexo_Config::setParameterIfNotExists('ENUM_NON', '0');


Atexo_Config::setParameterIfNotExists('CLE_SERVICE_GATEWAY', 'xyz');
Atexo_Config::setParameterIfNotExists('URI_WEB_SERVICE_AJOUTER_STATUT_GATEWAY',  'http://recette.gisr.gov.ma:10039/gtw_v4-web/StatutServiceTiersWS');
Atexo_Config::setParameterIfNotExists('URL_WSDL_AJOUTER_STATUT_GATEWAY',  'http://recette.gisr.gov.ma:10039/gtw_v4-web/StatutServiceTiersWS/StatutServiceTiersWS.wsdl');

Atexo_Config::setParameterIfNotExists('MODULE_SMS', '1');
//Atexo_Config::setParameterIfNotExists('LOGIN_SERVICE_SMS', 'tantaoui');
//Atexo_Config::setParameterIfNotExists('PASS_SERVICE_SMS', 'tan_2015');
Atexo_Config::setParameterIfNotExists('URL_SERVICE_SMS', 'http://10.7.7.61:9537/api/Account/SendSMSPost');
Atexo_Config::setParameterIfNotExists('CODE_CLIENT_SERVICE_SMS', 'rdv');

Atexo_Config::setParameterIfNotExists('DELAI_MAX_PRISE_RDV', '60');
Atexo_Config::setParameterIfNotExists('EMAIL_DELAI_MAX_PRISE_RDV', 'mawiidisante@gmail.com');

Atexo_Config::setParameterIfNotExists('DELAI_MARGE_1', '30');
Atexo_Config::setParameterIfNotExists('DELAI_MARGE_2', '60');
Atexo_Config::setParameterIfNotExists('DOMAIN_MEET', 'meet.jit.si');
Atexo_Config::setParameterIfNotExists('PARAMETRE_VISIO','1');
Atexo_Config::setParameterIfNotExists('SESSION_PRIVE','1');
Atexo_Config::setParameterIfNotExists('SESSION_INTERNE','2');
Atexo_Config::setParameterIfNotExists('SESSION_PUBLIQUE','3');
Atexo_Config::setParameterIfNotExists('RDV_GROUPE','1');
Atexo_Config::setParameterIfNotExists('RDV_INDIVIDUEL','0');

foreach (Atexo_Config::getParameters() as $key => $value) {
 echo " <parameter id=\"" . $key . "\" value=\"" . $value . "\" />\n";
}
?>


</parameters>

</application>
