<?php
return construct_array();
function construct_array()
{
	$DB = Atexo_Config::getParameter('DB_NAME');

	//recuperer du fichier de configuration le nom de la constante
	$const_read_write = Atexo_Config::getParameter('CONST_READ_WRITE');
	$const_read_only = Atexo_Config::getParameter('CONST_READ_ONLY');
	$encoding = Atexo_Config::getParameter('DB_ENCODING');

	//recuperation des adresse IP
	$hostspec_read_write = Atexo_Config::getParameter('HOSTSPEC'.$const_read_write);
	$hostspec_read_only = Atexo_Config::getParameter('HOSTSPEC'.$const_read_only);

	$username = Atexo_Config::getParameter('USERNAME');
	$password = Atexo_Config::getParameter('PASSWORD');
	//$inUppercase = Atexo_Config::getParameter('DB_NAME');
	if (Atexo_Config::getParameter('DB_PREFIX')) {
		$prefix = Atexo_Config::getParameter('DB_PREFIX') . '_';
	}
	else {
		$prefix = '';
	}
	try {
		$port = Atexo_Config::getParameter('DB_PORT');
		$hostspec_read_write=$hostspec_read_write.':'.$port;
		$hostspec_read_only=$hostspec_read_only.':'.$port;
	} catch (Exception $e) {
		$port=null;
	}
	$arraySettings = array();
	$arraySettings["charset"]["value"] = $encoding;
	$array_base['RDV'] = array('adapter'=>'mysql', 'connection'=>array('phptype'=>'mysql',
													'hostspec'=>$hostspec_read_write,	
													'database'=>$prefix.$DB,
													'user'=>$username,
													'password'=>$password,
													'dsn' => 'mysql:host='.$hostspec_read_write.';dbname='.$prefix.$DB, 
													'settings'=>$arraySettings)
							);
	$array_base[$DB.$const_read_write] = array('adapter'=>'mysql', 'connection'=>array('phptype'=>'mysql',
												'hostspec'=>$hostspec_read_write,	
												'database'=>$prefix.$DB,
												'user'=>$username,
												'password'=>$password,
												'dsn' => 'mysql:host='.$hostspec_read_write.';dbname='.$prefix.$DB, 
												'settings'=>$arraySettings)
							);
	$array_base[$DB.$const_read_only] =  array('adapter'=>'mysql', 'connection'=>array('phptype'=>'mysql',
												'hostspec'=>$hostspec_read_only,	
												'database'=>$prefix.$DB,
												'user'=>$username,
												'password'=>$password,
												'dsn' => 'mysql:host='.$hostspec_read_only.';dbname='.$prefix.$DB, 
												'settings'=>$arraySettings)
							);

	return array (

    'propel' =>
    array (
    'datasources' =>  $array_base,
    )
    );

}