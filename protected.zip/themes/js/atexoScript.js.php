function dropText(input) {
	input.value="";
	input.focus();
}
function annulerSelection() {
	window.document.getElementById("ctl0_CONTENU_PAGE_lblLat").value=0;
	window.document.getElementById("ctl0_CONTENU_PAGE_lblLong").value=0;
	window.close(); 
}
function setIdAdresse(id){
	window.document.getElementById("ctl0_CONTENU_PAGE_lbl").value=id;
}
function initialiser_map(init) {

	if(init) {
		if(window.document.getElementById("ctl0_CONTENU_PAGE_lblLat").value=='' && window.document.getElementById("ctl0_CONTENU_PAGE_lblLong").value=='')
	    {
	      switch(pays){
	      	case "France": lat=48.85;long=2.35;var latlng = new google.maps.LatLng(48.85, 2.35);break;
			case "Maroc" : lat=31.63;long=-8.00;var latlng = new google.maps.LatLng(31.63,-8.00);break;
			default : lat=31.63;long=-8.00;var latlng = new google.maps.LatLng(31.63,-8.00);break;
	      }
	      window.document.getElementById("ctl0_CONTENU_PAGE_lblLat").value=lat;
	      window.document.getElementById("ctl0_CONTENU_PAGE_lblLong").value=long;
	    }
    }
	//var ctaLayer = new google.maps.KmlLayer('<?php echo Atexo_Config::getParameter('PF_URL') ?>ressources/1317288692maroc.kml');
	var ctaLayer = new google.maps.KmlLayer('https://test-reclamations.local-trust.com/ressources/1317288692maroc.kml');
	var pays ="<?php echo Atexo_Config::getParameter('PARAM_PAYS') ?>";
	
	adr = window.document.getElementById("ctl0_CONTENU_PAGE_lbl").value;
	
	ville = window.document.getElementById("ctl0_CONTENU_PAGE_entite2");
	nomVille="";
	if(ville.selectedIndex!=null && ville.selectedIndex>0) {
		nomVille = ville.options[ville.selectedIndex].text;
	}
	var address =window.document.getElementById(adr).value+" "+nomVille+" "+pays;
	
	if(address =='')
	{
		address = pays;
	}
	var geocoder = new google.maps.Geocoder(); 
	    
	var options = {
		      zoom: 6,
              zoomControlOptions: { style: google.maps.ZoomControlStyle.SMALL },
              mapTypeControlOptions: {
			      mapTypeIds: ['satellite', 'no_poi'],
                  style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
			    }
        };
        
    var stylez = [
        {
          featureType: "administrative.country",
          elementType: "labels",
          stylers: [
            { visibility: "off" }
          ]
        },{
          featureType: "administrative.country",
          elementType: "geometry",
          stylers: [
            { visibility: "off" }
          ]
        }
        	      ];
    var noPOIMapType = new google.maps.StyledMapType(stylez, {name: "Plan"});
	var carte = new google.maps.Map(document.getElementById("carte"), options);
	carte.mapTypes.set('no_poi', noPOIMapType);
    carte.setMapTypeId('no_poi');
    carte.setTilt(45);
    
    var marker = new google.maps.Marker({
                    map: carte,
                    draggable:true,
                    title:'Déplacer ce marqueur sur le lieu de l\'établissement'
                    });
    
    google.maps.event.addListener(marker, 'dragend', function(event) {
             window.document.getElementById("ctl0_CONTENU_PAGE_lblLat").value  = event.latLng.lat();
             window.document.getElementById("ctl0_CONTENU_PAGE_lblLong").value = event.latLng.lng();
            });
	
	if(!init) {
		geocoder.geocode( { 'address': address}, function(results, status) {
			if (status == google.maps.GeocoderStatus.OK) {
			           
				lat = results[0].geometry.location.lat(); 
				lng = results[0].geometry.location.lng();
				          
				carte.setCenter(results[0].geometry.location);
				marker.setPosition(results[0].geometry.location);
				carte.setZoom(15);
				window.document.getElementById("ctl0_CONTENU_PAGE_lblLat").value = lat;
				window.document.getElementById("ctl0_CONTENU_PAGE_lblLong").value= lng;
			} else {
				var latlng = new google.maps.LatLng(window.document.getElementById("ctl0_CONTENU_PAGE_lblLat").value, window.document.getElementById("ctl0_CONTENU_PAGE_lblLong").value);
				carte.setCenter(latlng);
				marker.setPosition(latlng);
				carte.setZoom(15);
			}
		});
	}
	else {
		var latlng = new google.maps.LatLng(window.document.getElementById("ctl0_CONTENU_PAGE_lblLat").value, window.document.getElementById("ctl0_CONTENU_PAGE_lblLong").value);
		carte.setCenter(latlng);
		marker.setPosition(latlng);
		carte.setZoom(15);
	}
	
	if(pays =='Maroc')
    {
         google.maps.event.addListener(carte, 'maptypeid_changed', function(event) {
         var mapType = carte.getMapTypeId();
         if(mapType=="satellite"){
              if(carte.getZoom() <=5 ) {ctaLayer.setMap(carte); }
              }else{
                 ctaLayer.setMap(carte);
             }
         });
			<!--  // Forcer le zoom min à un seuil de 4 -->
		google.maps.event.addListener(carte, 'zoom_changed', function() {
           if(carte.getZoom() <=5 ) {ctaLayer.setMap(carte); }
		}); 
   }
}

function validationDropDownList (sender)
{
    var idDropList = sender.control.id;
    var list = document.getElementById(idDropList);

    if(list && list.options.length && list.selectedIndex != 0)
    {
        return true;
    }

    return false;
}

function CheckAll(sender, elemClass) {

	J('.'+elemClass).prop("checked", sender.checked);
}

function showAdressMap(idDiv,lat,long) {

	//var ctaLayer = new google.maps.KmlLayer('<?php echo Atexo_Config::getParameter('PF_URL') ?>ressources/1317288692maroc.kml');
	var ctaLayer = new google.maps.KmlLayer('https://test-reclamations.local-trust.com/ressources/1317288692maroc.kml');
	var pays ="<?php echo Atexo_Config::getParameter('PARAM_PAYS') ?>";
	
	var geocoder = new google.maps.Geocoder(); 
	    
	var options = {
		      zoom: 6,
              zoomControlOptions: { style: google.maps.ZoomControlStyle.SMALL },
              mapTypeControlOptions: {
			      mapTypeIds: ['satellite', 'no_poi'],
                  style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
			    }
        };
        
    var stylez = [
        {
          featureType: "administrative.country",
          elementType: "labels",
          stylers: [
            { visibility: "off" }
          ]
        },{
          featureType: "administrative.country",
          elementType: "geometry",
          stylers: [
            { visibility: "off" }
          ]
        }
        	      ];
    var noPOIMapType = new google.maps.StyledMapType(stylez, {name: "Plan"});
	var carte = new google.maps.Map(document.getElementById(idDiv), options);
	carte.mapTypes.set('no_poi', noPOIMapType);
    carte.setMapTypeId('no_poi');
    carte.setTilt(45);
    
    var marker = new google.maps.Marker({
                    map: carte,
                    draggable:false,
                    title:''
                    });
	
	var latlng = new google.maps.LatLng(lat,long);
	carte.setCenter(latlng);
	marker.setPosition(latlng);
	carte.setZoom(15);
	
	if(pays =='Maroc')
    {
         google.maps.event.addListener(carte, 'maptypeid_changed', function(event) {
         var mapType = carte.getMapTypeId();
         if(mapType=="satellite"){
              if(carte.getZoom() <=5 ) {ctaLayer.setMap(carte); }
              }else{
                 ctaLayer.setMap(carte);
             }
         });
			<!--  // Forcer le zoom min à un seuil de 4 -->
		google.maps.event.addListener(carte, 'zoom_changed', function() {
           if(carte.getZoom() <=5 ) {ctaLayer.setMap(carte); }
		}); 
   }
}
function showMap(iframeMap) {
	i=0;
	while((elem=document.getElementById('iframeMap'+i))!=null) {
		elem.style.display='none';
		i++;
	}
	map = document.getElementById(iframeMap);
	map.style.display='';
	
	document.getElementById('modalLocalisation').style.cssText="";
}
function hideMap() {
	document.getElementById('modalLocalisation').style.cssText="position: absolute; top: -9999px; left: -9999px";
}
function validationEmailOrTelephoneCitoyen(sender, param)
{
	var email = document.getElementById('ctl0_CONTENU_PAGE_gestionRdv_formCitoyen_email').value;
	var tel = document.getElementById('ctl0_CONTENU_PAGE_gestionRdv_formCitoyen_telephone').value;
	
	return validationEmailOrTelephone(email, tel);
}
function validationEmailOrTelephoneGestion(sender, param)
{
	var email = document.getElementById('ctl0_CONTENU_PAGE_gererRdv_email').value;
	var tel = document.getElementById('ctl0_CONTENU_PAGE_gererRdv_telephone').value;
	
	return validationEmailOrTelephone(email, tel);
	
}
function validationEmailOrTelephone(email, tel)
{
	if(trim(email)=='' && trim(tel)=='')
	{
		return false;
	}
	return true;
	
}
function trim (myString)
{
	return myString.replace(/^\s+/g,'').replace(/\s+$/g,'')
} 
function setIdUserToDelete(idAgent, nomAgent)
{
  J(".agentToDelete").each(function() {
 		var agentToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(agentToDeleteHidden).value=idAgent;
 });
 
 document.getElementById('nomUser').innerHTML=nomAgent;
}
function setIdOrganisationToDelete(idOrganisation, nomOrganisation)
{
  J(".organisationToDelete").each(function() {
 		var organisationToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(organisationToDeleteHidden).value=idOrganisation;
 });
 
 document.getElementById('denomination').innerHTML=nomOrganisation;
}
function setIdEtablissementToDelete(idEtablissement, nomEtablissement)
{
  J(".etablissementToDelete").each(function() {
 		var etablissementToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(etablissementToDeleteHidden).value=idEtablissement;
 });
 
 document.getElementById('denomination').innerHTML=nomEtablissement;
}
function setIdTypePrestationToDelete(idTypePrestation, nomTypePrestation)
{
  J(".typePrestationToDelete").each(function() {
 		var typePrestationToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(typePrestationToDeleteHidden).value=idTypePrestation;
 });
 
 document.getElementById('libelle').innerHTML=nomTypePrestation;
}
function setIdRefPrestationToDelete(idRefPrestation, nomRefPrestation)
{
  J(".refPrestationToDelete").each(function() {
 		var refPrestationToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(refPrestationToDeleteHidden).value=idRefPrestation;
 });
 
 document.getElementById('libelle').innerHTML=nomRefPrestation;
}
function setIdRefTypePrestationToDelete(idRefTypePrestation, nomRefTypePrestation)
{
  J(".refTypePrestationToDelete").each(function() {
 		var refTypePrestationToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(refTypePrestationToDeleteHidden).value=idRefTypePrestation;
 });

 document.getElementById('libelle').innerHTML=nomRefTypePrestation;
}

function setIdPrestationToDelete(idPrestation, nomPrestation)
{
  J(".prestationToDelete").each(function() {
 		var prestationToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(prestationToDeleteHidden).value=idPrestation;
 });
 
 document.getElementById('libelle').innerHTML=nomPrestation;
}
function setIdProfilToDelete(idProfil, nomProfil)
{
  J(".profilToDelete").each(function() {
 		var profilToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(profilToDeleteHidden).value=idProfil;
 });
 
 document.getElementById('nomProfil').innerHTML=nomProfil;
}
function setIdJourFerieToDelete(idJourFerie, nomJourFerie)
{
  J(".jourFerieToDelete").each(function() {
 		var jourFerieToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(jourFerieToDeleteHidden).value=idJourFerie;
 });
 
 document.getElementById('nomJour').innerHTML=nomJourFerie;
}
function setIdIndisponibiliteToDelete(idIndisponibilite, nomIndisponibilite)
{
  J(".indisponibiliteToDelete").each(function() {
 		var indisponibiliteToDeleteHidden = (J(this).attr("id"));
  		document.getElementById(indisponibiliteToDeleteHidden).value=idIndisponibilite;
 });
 
 document.getElementById('nomUser').innerHTML=nomIndisponibilite;
}
function viderRadioBtn() {
    J(".radioBtn input").each(function() {
        J(this).prop("checked", false);
     });
}
function setIdRendezVousToCancel(idRendezVous,nom,prenom,telephone,prestation,nomRessource,prenomRessource,date,heure)
{
  J(".rendezVousToCancel").each(function() {
 		var rendezVousToCancelHidden = (J(this).attr("id"));
  		document.getElementById(rendezVousToCancelHidden).value=idRendezVous;
 });
    J('#modalAnnulation').fadeIn().css('display', 'flex');
 viderRadioBtn();
 document.getElementById('nom').innerHTML=nom;
 document.getElementById('prenom').innerHTML=prenom;
 document.getElementById('prestation').innerHTML=prestation;

 blocSms = document.getElementById('blocEnvoiSMSRequerant');
 if(blocSms) {
 if(telephone!='') {
	blocSms.style = 'display:block';
 }
 else {
    blocSms.style = 'display:none';
 }
}
 document.getElementById('nomRessource').innerHTML=nomRessource;
 document.getElementById('prenomRessource').innerHTML=prenomRessource;
 document.getElementById('date').innerHTML=date;
 document.getElementById('heure').innerHTML=heure;

 v = ComparerDates(date, getDateNowFr());
 if( v != 1 ) {
	document.getElementById('divAvantDate').style = 'display:none';
	document.getElementById('divJourDate').style = 'display:block';
 } else {
	document.getElementById('divAvantDate').style = 'display:block';
	document.getElementById('divJourDate').style = 'display:none';
 }
}
function getDateNowFr() {
  function pad(s) { return (s < 10) ? '0' + s : s; }
  var d = new Date();
  return [pad(d.getDate()), pad(d.getMonth()+1), d.getFullYear()].join('/');
}
function spansAtLeastNCharacterSets( word, N)
{
	// Calcul les différents types de caractères du mot de passe
	// word : mot de passe, N : Nombre minimun de types de caractère différents pour retour à vrai 
		if (word == null)
			return false;
			
		var csets = new Array(false,false,false,false);
	
		ncs = 0;
		var listeNombre = "0123456789";
		var listeCaractereSpe = "&éê^'(-è_çà)=*ù!:;,?òì./§-+<>$£µ%{}âôîû@\|[]²ß~]°#¨"+'"';
	    for (i = 0; i < word.length; i++)
		{
		    c= word.charAt(i);
			if (listeNombre.indexOf(c)>=0)
			{
			// caractère numérique
				if (csets[0] == false)
				{
					csets[0] = true;
					ncs++;
					if (ncs >= N)
						return true;
				}
			}
			else if (listeCaractereSpe.indexOf(c)>=0)
			{
			// caractère spécial
				if (csets[1] == false)
				{
					csets[1] = true;
					ncs++;
					if (ncs >= N)
						return true;
				}
			}
			else if (c.toUpperCase() ==c)
			{
			// caractère en Majuscule
				if (!csets[2])
				{
					csets[2] = true;
					ncs++;
					if (ncs >= N)
						return true;
				}
				continue;
			}
			else if (c.toLowerCase() ==c)
			{
			// caractère en Minuscule
				if (!csets[3])
				{
					csets[3] = true;
					ncs++;
					if (ncs >= N)
						return true;
				}
			}
		}
		return false;
}
function verifierMdp(){
		if(document.getElementById('modifPassword').style.display=='none') {
            return true;
        } 
        if(document.getElementById('ctl0_CONTENU_PAGE_passwordUser')!=null) {
            var pwd = document.getElementById('ctl0_CONTENU_PAGE_passwordUser').value;
        } 
        if(pwd=="") {
        	return false;
        }
        if(pwd != 'xxxxxx'){
	        if(spansAtLeastNCharacterSets(pwd, 3) && pwd.length >= 8 ){
	            return true;
	        }
	        return false;   
        }
        return true;
}
function verifierConfirmMdp(){
		if(document.getElementById('modifPassword').style.display=='none') {
            return true;
        } 
        if(document.getElementById('ctl0_CONTENU_PAGE_passwordUser')!=null) {
            var pwd = document.getElementById('ctl0_CONTENU_PAGE_passwordUser').value;
        } 
        if(document.getElementById('ctl0_CONTENU_PAGE_confirmePassword')!=null) {
            var pwdConfirm = document.getElementById('ctl0_CONTENU_PAGE_confirmePassword').value;
        } 
        if(pwd!=pwdConfirm) {
        	return false;
        }
        
        return true;
}
function clickSavePrestation() {
	document.getElementById('ctl0_CONTENU_PAGE_prestationAssociee_btnEnregistrerPrestationAssociee').click();
}
function calculNbreRdv(input1, input2, input3) {
	var periodicite = document.getElementById('ctl0_CONTENU_PAGE_prestationAssociee_inputDureeRdv').value;
	var debut =  document.getElementById(input1).value;
	if(debut!=null) {
		var de = debut.split(':');
		if(de[0]!=null){
			if(de[0].indexOf(0)==0) {
				de[0] = de[0].substring(1);
			}
		}
		if(de[1]!=null) {
			if(de[1].indexOf(0)==0) {
				de[1] = de[1].substring(1);
			}
		}
	}
	var fin =  document.getElementById(input2).value;
	if(fin!=null) {
		var a = fin.split(':');
		if(a[0]!=null) {
			if(a[0].indexOf(0)==0) {
				a[0] = a[0].substring(1);
			}
		}
		if(a[1]!=null) {
			if(a[1].indexOf(0)==0) {
				a[1] = a[1].substring(1);
			}
		}
	}
	if(de[0]!=null && de[1]!=null && periodicite!=null && periodicite!='' && a[0]!=null && a[1]!=null) {
		document.getElementById(input3).innerHTML = parseInt(((parseInt(a[0])*60+parseInt(a[1]))-(parseInt(de[0])*60+parseInt(de[1])))/periodicite);
		document.getElementById(input3+"h").value = parseInt(((parseInt(a[0])*60+parseInt(a[1]))-(parseInt(de[0])*60+parseInt(de[1])))/periodicite);
	}
}
function recalculNbreRdv() {
	//Matin
	for(i=1;i<=7;i++) {
		calculNbreRdv('ctl0_CONTENU_PAGE_prestationAssociee_jour_0'+i+'_matin_horaire_debut', 'ctl0_CONTENU_PAGE_prestationAssociee_jour_0'+i+'_matin_horaire_fin', 'ctl0_CONTENU_PAGE_prestationAssociee_nbreRdvJour0'+i+'_matin');
	}
	//apres-midi
	for(i=1;i<=7;i++) {
		calculNbreRdv('ctl0_CONTENU_PAGE_prestationAssociee_jour_0'+i+'_apresmidi_horaire_debut', 'ctl0_CONTENU_PAGE_prestationAssociee_jour_0'+i+'_apresmidi_horaire_fin', 'ctl0_CONTENU_PAGE_prestationAssociee_nbreRdvJour0'+i+'_soir');
	}
}
function verifierDuree(sender,params) {
	 var idChamp = sender.control.id;
	 var idRadio = idChamp.replace('_debut','');
	 var idRadio = idRadio.replace('_fin','');
 
	if(document.getElementById(idRadio).checked) {
		if(document.getElementById(idChamp).value=='') {
			return false;
		}
		return true;
	}
	return true;
}
function checkDuplication(elem,index) {
	 var idInfo = document.getElementById('ctl0_CONTENU_PAGE_duplicationInfos');
	 var idTypePr = document.getElementById('ctl0_CONTENU_PAGE_duplicationTypePrestation');
	 var idPr = document.getElementById('ctl0_CONTENU_PAGE_duplicationPrestation');
	 var idRes = document.getElementById('ctl0_CONTENU_PAGE_duplicationRessource');
 	 
 	 if(elem.checked==false) {
 	 	if(index==0) {
 	 		idInfo.checked=false;
 	 		idTypePr.checked=false;
 	 		idPr.checked=false;
 	 		idRes.checked=false;
 	 	}
 	 	if(index==1) {
 	 		idTypePr.checked=false;
 	 		idPr.checked=false;
 	 		idRes.checked=false;
 	 	}
 	 	if(index==2) {
 	 		idPr.checked=false;
 	 		idRes.checked=false;
 	 	}
 	 	if(index==3) {
 	 		idRes.checked=false;
 	 	}
 	 }
 	 if(elem.checked==true) {
 	 	if(index==3) {
 	 		idInfo.checked=true;
 	 		idTypePr.checked=true;
 	 		idPr.checked=true;
 	 		idRes.checked=true;
 	 	}
 	 	if(index==2) {
 	 		idInfo.checked=true;
 	 		idTypePr.checked=true;
 	 		idPr.checked=true;
 	 	}
 	 	if(index==1) {
 	 		idInfo.checked=true;
 	 		idTypePr.checked=true;
 	 	}
 	 	if(index==0) {
 	 		idInfo.checked=true;
 	 	}
 	 }
}
function validateDuplication() {
	 var idInfo = document.getElementById('ctl0_CONTENU_PAGE_duplicationInfos');
	 var idTypePr = document.getElementById('ctl0_CONTENU_PAGE_duplicationTypePrestation');
	 var idPr = document.getElementById('ctl0_CONTENU_PAGE_duplicationPrestation');
	 var idRes = document.getElementById('ctl0_CONTENU_PAGE_duplicationRessource');
 	 
 	 if(idInfo.checked==false && idTypePr.checked==false && idPr.checked==false && idRes.checked==false) {
 	 	return false;
 	 }
 	 
 	 return true;
}
function validateDateTime(sender, parameter)
{
	//object = document.getElementById(parameter);
	if (parameter != null && parameter != "")
	{
		var regExp = new RegExp("\\b[0-9][0-9]\\/[0-9][0-9]\\/[0-9][0-9][0-9][0-9]");
		if(!(parameter.match(regExp)))
		{

			return false;
		}
		else
		{
			if(!isDate (parameter))
  			{
  				return false;
  			}
		}
	}
	return true;
}
function isValidDate(day,month,year){
    var date = new Date(year, (month - 1), day);
    var DateYear = date.getFullYear();
    var DateMonth = date.getMonth();
    var DateDay = date.getDate();
    if (DateYear == year && DateMonth == (month - 1) && DateDay == day) {
        return true;
    }
    else {
        return false;
    }
}
function IsNumeric(input)
{
    return (input - 0) == input && (input+'').replace(/^\s+|\s+$/g, "").length > 0;
}
function ComparerDates(LeParam1,LeParam2)
{
	// Compare 2 dates au format jj/mm/aaaa
	// Renvoye 0 si égalité, 1 si la première est supérieure, sinon 2

	/*var LeParam1 = Date.parse(LeParam1);
	var LeParam2 = Date.parse(LeParam2);

	if (LeParam1 == LeParam2){ 
		return 0;
	}

	if (LeParam1 > LeParam2){
		return 1;
	} else {
		return 2;
	}*/
	a1 = LeParam1.split('/');
	a2 = LeParam2.split('/');

	d1 = new Date(a1[2], a1[1]-1, a1[0]);

	d2 = new Date(a2[2], a2[1]-1, a2[0]);
	if(d1 > d2)
		return 1;
	else if(d1 < d2)
		return 2;
	else
		return 0;
}
function dateValidator(sender, param){
	 var idChamp = sender.control.id;
	 VAL = document.getElementById(idChamp).value;
	 if(VAL != '' && VAL != null) {
		 if(!IsNumeric(VAL.split('/')[0], 10) || !IsNumeric(VAL.split('/')[1], 10) || !IsNumeric(VAL.split('/')[2], 10)) {
		 	return false;
		 } else {
			 if (VAL != '' && !isValidDate(parseInt(VAL.split('/')[0], 10), parseInt(VAL.split('/')[1], 10), parseInt(VAL.split('/')[2], 10)))
			 {
			  	return false;
			 }else{
			  	return true;
			 }
		 }
	 }
	 return true;
}
function dateDebutFinComparator(sender, param) {
	var idChampDate1 = sender.control.id;
	var idChampDate2 = "";
	if (idChampDate1.indexOf('debut')>=0) {
		idChampDate2 = idChampDate1.replace('debut','fin');
		var res = ComparerDates(document.getElementById(idChampDate1).value, document.getElementById(idChampDate2).value);
		if(res==0 || res==2) {
			return true;
		} else {
			return false;
		}
	}
	if (idChampDate1.indexOf('fin')>=0) {
		idChampDate2 = idChampDate1.replace('fin','debut');
		var res = ComparerDates(document.getElementById(idChampDate2).value, document.getElementById(idChampDate1).value);
		if(res==0 || res==2) {
			return true;
		} else {
			return false;
		}
	}
	return true;
}
function dateHeureDebutFinComparator(sender,params)
{
	var idChamp = sender.control.id;
	if (idChamp.indexOf('debut')>=0) {
		var idChampDateDeb = idChamp.replace('timedebut','datedebut');
		var idChampDateFin = idChamp.replace('timedebut','datefin');
		
		var valueDateDeb = document.getElementById(idChampDateDeb).value;
		var valueDateFin = document.getElementById(idChampDateFin).value;
		
		if(valueDateDeb!=valueDateFin) {
			return true;
		}
		
		var idChamp2 = idChamp.replace('debut','fin');
		var value1 = document.getElementById(idChamp).value;
		var value2 = document.getElementById(idChamp2).value;
		if(value1!='' && value2!='') {
			return comparerHeure(value1, value2);
		}
	}
	if (idChamp.indexOf('fin')>=0) {
	
		var idChampDateDeb = idChamp.replace('timefin','datedebut');
		var idChampDateFin = idChamp.replace('timefin','datefin');
		
		var valueDateDeb = document.getElementById(idChampDateDeb).value;
		var valueDateFin = document.getElementById(idChampDateFin).value;
		
		if(valueDateDeb!=valueDateFin) {
			return true;
		}
		
		var idChamp2 = idChamp.replace('fin','debut');
		var value1 = document.getElementById(idChamp).value;
		var value2 = document.getElementById(idChamp2).value;
		if(value1!='' && value2!='') {
			return comparerHeure(value2, value1);
		}
	}
	return true;
}
function verifierNbreRdvSurSite(sender,params) {
	 var idChamp = sender.control.id;
	 var tab = idChamp.split('_');
	 if(tab[6]=="soir") {
	  	var idRadio = tab[0]+'_'+tab[1]+'_'+tab[2]+'_'+tab[3]+'_jour_'+tab[5]+'_apresmidi_horaire';
	 } else {
	 	var idRadio = tab[0]+'_'+tab[1]+'_'+tab[2]+'_'+tab[3]+'_jour_'+tab[5]+'_'+tab[6]+'_horaire';
	 }
	 var idNbrRdv = tab[0]+'_'+tab[1]+'_'+tab[2]+'_'+tab[3]+'_nbreRdvJour'+tab[5]+'_'+tab[6]+'h';
	 if(document.getElementById(idRadio)!=null) {
		if(document.getElementById(idRadio).checked && document.getElementById(idNbrRdv).value!='') {
			if(document.getElementById(idChamp).value=='') {
				return false;
			}
			if(parseInt(document.getElementById(idChamp).value) >= parseInt(document.getElementById(idNbrRdv).value)) {
				return false;
			}
			return true;
		}
	}
	return true;
}
function validerHeure(sender,params)
{
	 var idChamp = sender.control.id;
	 var idRadio = idChamp.replace('_debut','');
	 var idRadio = idRadio.replace('_fin','');
	 if(document.getElementById(idRadio).checked) {
		 var hhmm = document.getElementById(idChamp).value;
		 if(hhmm != '') {
			return verifierFormatHhMm(hhmm);
		 }
	} 
	return true;
}
function verifierFormatHhMm(hhmm)
{
	splithhmm = hhmm.split(":");
	if (splithhmm.length!=2) {
		return false;
	}
	if (isNaN(splithhmm[0])|| splithhmm[0]<0 || splithhmm[0]>23) {
		return false;
	}
	if (isNaN(splithhmm[1])|| splithhmm[1]<0 || splithhmm[1]>59) {
		return false;
	}
	return true;
}
function verifierHeureDebMatin(sender,params)
{
	var idChamp = sender.control.id;
	var idRadio = idChamp.replace('_debut','');
	var idRadio = idRadio.replace('_fin','');
	if(document.getElementById(idRadio).checked) {
	 	var hhmm = document.getElementById(idChamp).value;
		if(hhmm != '') {
		 	splithhmm = hhmm.split(":");
		 	if (splithhmm.length==2) {
		 		if (isNaN(splithhmm[0])|| splithhmm[0]>11) {
		 			return false;
		 		}
		 	}
		 }
	 }
	return true;
}
function verifierHeureDebSoir(sender,params)
{
	var idChamp = sender.control.id;
	var idRadio = idChamp.replace('_debut','');
	var idRadio = idRadio.replace('_fin','');
	if(document.getElementById(idRadio).checked) {
	 	var hhmm = document.getElementById(idChamp).value;
		if(hhmm != '') {
		 	splithhmm = hhmm.split(":");
		 	if (splithhmm.length==2) {
		 		if (isNaN(splithhmm[0])|| splithhmm[0]<12 || splithhmm[0]>23) {
		 			return false;
		 		}
		 	}
		 }
	 }
	return true;
}
function verifierHeureDebEtFin(sender,params)
{
	var idChamp = sender.control.id;
	if (idChamp.indexOf('_debut')>=0) {
		var idChamp2 = idChamp.replace('_debut','_fin');
		var value1 = document.getElementById(idChamp).value;
		var value2 = document.getElementById(idChamp2).value;
		if(value1!='' && value2!='') {
			return comparerHeure(value1, value2);
		}
	}
	if (idChamp.indexOf('_fin')>=0) {
		var idChamp2 = idChamp.replace('_fin','_debut');
		var value1 = document.getElementById(idChamp).value;
		var value2 = document.getElementById(idChamp2).value;
		if(value1!='' && value2!='') {
			return comparerHeure(value2, value1);
		}
	}
	return true;
}
function comparerHeure(heure1,heure2)
{
 	splithhmm1 = heure1.split(":");
 	splithhmm2 = heure2.split(":");
 	if (splithhmm1.length==2 && splithhmm2.length==2) {
 		if (isNaN(splithhmm1[0])|| isNaN(splithhmm2[0])|| parseInt(splithhmm1[0])>parseInt(splithhmm2[0])) {
 			return false;
 		}
 	}
	return true;
}
function showDiv(id)
{
	document.getElementById(id).style.display="";
}
function hideDiv(id)
{
	document.getElementById(id).style.display="none";
}
function checkButton(id,bt)
{
	document.getElementById(id).checked=true;
	document.getElementById(bt).click();
}
function clickBt(id)
{
	document.getElementById(id).click();
}
function setIdRendezVousToConfirm(idRendezVous,nom,prenom,prestation,nomRessource,prenomRessource,date,heure, rdvGroupe=null, participant=null)
{
  J(".rendezVousToConfirm").each(function() {
 		var rendezVousToConfirmHidden = (J(this).attr("id"));
  		document.getElementById(rendezVousToConfirmHidden).value=idRendezVous;
 });
    J('#modalConfirmation').fadeIn().css('display', 'flex');
 document.getElementById('nomC').innerHTML=nom;
 document.getElementById('prenomC').innerHTML=prenom;
 document.getElementById('prestationC').innerHTML=prestation;
 document.getElementById('nomRessourceC').innerHTML=nomRessource;
 document.getElementById('prenomRessourceC').innerHTML=prenomRessource;
 document.getElementById('dateC').innerHTML=date;
 document.getElementById('heureC').innerHTML=heure;
    if(rdvGroupe != null){
        J('.tohide').css('display',((rdvGroupe == '0')?'none':'table-row'));
        listeParticipant = JSON.parse(participant);
        if(listeParticipant.length>0){
            J('#message_liste_participant').css("display", "none");
            J('#confirmation_liste_participants').css("display", "block");
            J('#confirmation_liste_participants').empty();
            listeParticipant.forEach((participant)=>{
                J('#confirmation_liste_participants').append('<li><b>'+participant.nom+' '+participant.prenom+': </b> '+participant.email+'</li>');
            })
        }else {
            J('#message_liste_participant').css("display", "block");
            J('#confirmation_liste_participants').css("display", "none");
        }
    }
}
function setIdRendezVousToNonHonore(idRendezVous,nom,prenom,prestation,nomRessource,prenomRessource,date,heure)
{
J(".rendezVousToNonHonore").each(function() {
var rendezVousToNonHonoreHidden = (J(this).attr("id"));
document.getElementById(rendezVousToNonHonoreHidden).value=idRendezVous;
});

document.getElementById('nomN').innerHTML=nom;
document.getElementById('prenomN').innerHTML=prenom;
document.getElementById('prestationN').innerHTML=prestation;
document.getElementById('nomRessourceN').innerHTML=nomRessource;
document.getElementById('prenomRessourceN').innerHTML=prenomRessource;
document.getElementById('dateN').innerHTML=date;
document.getElementById('heureN').innerHTML=heure;
}
function verifierHeureFinMatinEtDebSoir(sender,params)
{
	var idChamp = sender.control.id;
	if (idChamp.indexOf('matin')>=0) {
		var coche1 = document.getElementById(idChamp.replace('_fin','')).checked;
		var coche2 = document.getElementById(idChamp.replace('matin','apresmidi').replace('_fin','')).checked;
		var idChamp2 = idChamp.replace('matin','apresmidi');
		idChamp2 = idChamp2.replace('_fin','_debut');
		var value1 = document.getElementById(idChamp).value;
		var value2 = document.getElementById(idChamp2).value;
		if(value1!='' && value2!='' && coche1 && coche2) {
			return comparerHeure(value1, value2);
		}
	}
	if (idChamp.indexOf('apresmidi')>=0) {
		var coche1 = document.getElementById(idChamp.replace('_fin','')).checked;
		var coche2 = document.getElementById(idChamp.replace('apresmidi','matin').replace('_fin','')).checked;
		var idChamp2 = idChamp.replace('apresmidi','matin');
		idChamp2 = idChamp2.replace('_debut','_fin');
		var value1 = document.getElementById(idChamp).value;
		var value2 = document.getElementById(idChamp2).value;
		if(value1!='' && value2!='' && coche1 && coche2) {
			return comparerHeure(value2, value1);
		}
	}
	return true;
}
function telOuEmailObligatoire(sender,params) {
	var idChamp = sender.control.id;
	var idChamp2 = idChamp.replace('Telephone','Email');
	if(document.getElementById(idChamp).checked && document.getElementById(idChamp2).checked) {
		return false;
	}
	return true;
}
function checkDisponibleRadio(idRadio)
{
	document.getElementById(idRadio).checked = true;
}
function redrawGraph(etab_pres) {
	etab = etab_pres.split("<br>");
	
	var myselect=document.getElementById("ctl0_CONTENU_PAGE_listeEtablissement");
	var prestation=document.getElementById("ctl0_CONTENU_PAGE_listeRefPrestation");
	if(prestation!=null) {
		prestation.value=0;
	}
	for (var i=0; i<myselect.options.length; i++){
	 if (myselect.options[i].text==etab[0]) {
	  myselect.options[i].selected=true;
	  break;
	 }
	}
	
	document.getElementById("ctl0_CONTENU_PAGE_btnSearch").click();
}
function changeGraph(indexMois) {
	
	var myselect=document.getElementById("ctl0_CONTENU_PAGE_frequence");
	myselect.value = 0;
	var dateDeb=document.getElementById("ctl0_CONTENU_PAGE_datedebut");
	var dateFin=document.getElementById("ctl0_CONTENU_PAGE_datefin");
	
	var elem = dateDeb.value.split('/');
	mois = parseInt(elem[1])+parseInt(indexMois);
	annee = parseInt(elem[2]);
	
	while(mois>12) {
		mois = mois-12;
		annee++;
	}
	
	if(mois<10) {
		mois = "0"+mois;
	}
	
	dateDeb.value = "01/"+mois+"/"+annee;
	dateFin.value = getNbJours(mois,annee)+"/"+mois+"/"+annee;
	
	document.getElementById("ctl0_CONTENU_PAGE_btnSearch").click();
}
function getNbJours(mois, annee){
	var dd = new Date(annee, mois, 0);
	return dd.getDate();
}
function validateDDLWithCondition(idRdvGroupe, idRechercheEtendu, idDDL) {
	choix1 = document.getElementById(idRdvGroupe);
	choix2 = document.getElementById(idRechercheEtendu);

	if( (choix1!=null && choix1.checked) || (choix2!=null && choix2.checked) ) {
		ressource = document.getElementById(idDDL);
		if(ressource.length>0 && ressource.selectedIndex==0) {
			return false;
		}
	}
	return true;
}
function popUp(url,width,height) {
	window.open(url, "_blank", "toolbar=yes, scrollbars=yes, resizable=yes, top=100, left=200, width="+width+", height="+height);
}

function checkRdvGroupe(rdvGroupeCheck, idNbrInput, typeSession){
    if(J(rdvGroupeCheck).is(":checked")){
        J('#'+idNbrInput).show();
        J('#'+typeSession).removeClass('hidetypesession');
    }
    else if(J(rdvGroupeCheck).is(":not(:checked)")){
        J('#'+idNbrInput).val("");
        J('#'+idNbrInput).hide();
        J('#'+typeSession).val("").trigger("chosen:updated");
        J('#'+typeSession).addClass('hidetypesession');
    }
}

function validateGPrestationTypeSession (sender, param)
{
    var idTypeSession = sender.control.id;
    var idcheckrdvgroupe = sender.control.getAttribute('idcheckrdvgroupe');
    var typeSession = J('#'+idTypeSession).val();
    if(J('#'+idcheckrdvgroupe).is(':checked') && jQuery.isEmptyObject(typeSession))
    {
        J([document.documentElement, document.body]).animate({
            scrollTop: J('#'+idcheckrdvgroupe).offset().top
        }, 100);
        return false;
    }else{
        return true;
    }
}

function validateGPrestationNombreParticipant (sender, param)
{
    var idNombreParticipant = sender.control.id;
    var idcheckrdvgroupe = sender.control.getAttribute('idcheckrdvgroupe');
    if(J('#'+idcheckrdvgroupe).is(':checked') && J('#'+idNombreParticipant).val() <= 0)
    {
        J([document.documentElement, document.body]).animate({
            scrollTop: J('#'+idcheckrdvgroupe).offset().top
        }, 100);
        return false;
    }else{
        return true;
    }
}
