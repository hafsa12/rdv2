<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class MenuRessource extends TTemplateControl
{

    public $_lang = "";

    public function onLoad() {
        $this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
        $idAgent = Atexo_User_CurrentUser::getIdAgentConnected();
        $agent = Atexo_Agent_Gestion::retrieveAgent($idAgent);
        if($agent) {
            $this->nomPrenomAgent->Text = $agent->getNomPrenomUtilisateurTraduit($this->_lang);
        }
    }

    public function Disconnect()
    {
            $this->getApplication()->getModule("auth")->logout();
            $this->response->redirect("?page=ressource.RessourceAccueil");
    }

    public function getLang() {
        return $this->_lang;
    }

    public function setLang($value) {
        return $this->_lang = $value ;
    }

    public function gererStructure() {
        if(!Atexo_User_CurrentUser::hasHabilitation('GestionOrganisation') && !Atexo_User_CurrentUser::hasHabilitation('GestionEtablissement')) {
            return false;
        }

        return true;
    }

    public function gererRoles() {
        if(!Atexo_User_CurrentUser::hasHabilitation('GestionProfils') && !Atexo_User_CurrentUser::hasHabilitation('GestionUtilisateurs')) {
            return false;
        }

        return true;
    }

    public function gererPrestations() {
        if(!Atexo_User_CurrentUser::hasHabilitation('GestionTypePrstation')
            && !Atexo_User_CurrentUser::hasHabilitation('GestionPrestation')
            && !Atexo_User_CurrentUser::hasHabilitation('GestionRessource')) {
            return false;
        }

        return true;
    }
    public function gererTypePrestations() {
        if( $_SESSION["typePrestation"] == Atexo_Config::getParameter("PRESTATION_REFERENTIEL") || !Atexo_User_CurrentUser::hasHabilitation('GestionTypePrstation')) {
            return false;
        }

        return true;
    }

    public function gererReferentiels() {
        if( $_SESSION["typePrestation"] != Atexo_Config::getParameter("PRESTATION_REFERENTIEL") ||
            (	!Atexo_User_CurrentUser::hasHabilitation('GestionRefPrestation')
                && !Atexo_User_CurrentUser::hasHabilitation('GestionRefTypePrestation')
                && !$this->gererParametragePrestation() )
        ) {
            return false;
        }

        return true;
    }

    public function gererRefTypePrestation() {
        if( $_SESSION["typePrestation"] != Atexo_Config::getParameter("PRESTATION_REFERENTIEL") ||
            !Atexo_User_CurrentUser::hasHabilitation('GestionRefTypePrestation')
        ) {
            return false;
        }

        return true;
    }

    public function gererRefPrestation() {
        if( $_SESSION["typePrestation"] != Atexo_Config::getParameter("PRESTATION_REFERENTIEL") ||
            !Atexo_User_CurrentUser::hasHabilitation('GestionRefPrestation')
        ) {
            return false;
        }

        return true;
    }

    public function gererAgendas() {
        if(!Atexo_User_CurrentUser::hasHabilitation('GestionJoursFeries') && !Atexo_User_CurrentUser::hasHabilitation('GestionJoursIndisponibilites')) {
            return false;
        }

        return true;
    }

    public function hasMenuAdmin() {
        return $this->gererStructure() || Atexo_User_CurrentUser::hasHabilitation('GestionOrganisation') || Atexo_User_CurrentUser::hasHabilitation('GestionEtablissement')
            || $this->gererRoles() || Atexo_User_CurrentUser::hasHabilitation('GestionProfils') || Atexo_User_CurrentUser::hasHabilitation('GestionUtilisateurs')
            || $this->gererPrestations() || Atexo_User_CurrentUser::hasHabilitation('GestionRefPrestation') || Atexo_User_CurrentUser::hasHabilitation('GestionTypePrstation')
            || Atexo_User_CurrentUser::hasHabilitation('GestionPrestation') || Atexo_User_CurrentUser::hasHabilitation('GestionRessource') || $this->gererAgendas()
            || Atexo_User_CurrentUser::hasHabilitation('GestionJoursFeries') || Atexo_User_CurrentUser::hasHabilitation('GestionJoursIndisponibilites');
    }
    protected function getUrlGestionPrestation () {
        return $_SESSION["typePrestation"]== Atexo_Config::getParameter("PRESTATION_REFERENTIEL")? "?page=administration.GestionPrestationsModeRef" : "?page=administration.GestionPrestations";
    }
    protected function gererParametragePrestation() {
        return Atexo_User_CurrentUser::hasHabilitation('GestionParamPrestation') && $_SESSION['typePrestation'] == Atexo_Config::getParameter("PRESTATION_REFERENTIEL");
    }
}
