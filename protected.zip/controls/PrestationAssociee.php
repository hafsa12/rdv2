<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class PrestationAssociee extends AtexoPage
{
	public $_forPrestation = true;
	public $_forHoraire = false;
	public $_editHoraire = false;
	public $_addHoraire = false;
	public $_idTypePrestation;
	public $_idPrestation;
	public $_idHoraire;

	public function setForPrestation($value) {
		$this->_forPrestation = $value;
	}
	public function getForPrestation() {
		return $this->_forPrestation;
	}
	public function setForHoraire($value) {
		$this->_forHoraire = $value;
	}
	public function getForHoraire() {
		return $this->_forHoraire;
	}
	public function setEditHoraire($value) {
		$this->_editHoraire = $value;
	}
	public function getEditHoraire() {
		return $this->_editHoraire;
	}
	public function setAddHoraire($value) {
		$this->_addHoraire = $value;
	}
	public function getAddHoraire() {
		return $this->_addHoraire;
	}
	public function setIdTypePrestation($value) {
		$this->_idTypePrestation = $value;
	}
	public function getIdTypePrestation() {
		return $this->_idTypePrestation;
	}
	public function setIdPrestation($value) {
		$this->_idPrestation = $value;
	}
	public function getIdPrestation() {
		return $this->_idPrestation;
	}

	public function setIdHoraire($value) {
		$this->_idHoraire = $value;
	}
	public function getIdHoraire() {
		return $this->_idHoraire;
	}

	public function getObjectToEdit($prestationAssociee=null) {
		if($this->getForHoraire()) {
			$this->titreModal->Text = Prado::localize('HORAIRES_TRAVAIL');
			$this->actionForm->Value = $this->getAddHoraire()."-".$this->getEditHoraire()."-".$this->getIdTypePrestation()."-".$this->getIdPrestation()."-".$this->getIdHoraire();
			$this->Page->loadTypePrestationForHoraire();
			$this->Page->loadPrestationForHoraire($this->getIdTypePrestation());
			$this->Page->loadPeriodiciteForHoraire($this->getIdPrestation());
		} else {
			$this->titreModal->Text = Prado::localize('PRESTATION_ASSOCIEE');
			$this->Page->loadTypePrestationRessource();
			$this->Page->loadPrestation();
		}
		$this->typePrestation->setSelectedValue($this->getIdTypePrestation());
		$this->prestation->setSelectedValue($this->getIdPrestation());
		if($this->getForHoraire()) {
			$this->typePrestation->setEnabled(false);
			$this->prestation->setEnabled(false);
			//$this->inputDureeRdv->setEnabled(false);
		}
		if($prestationAssociee !=null) {
			if($prestationAssociee->getPeriodicite()!='0') {
				$this->inputDureeRdv->Text = $prestationAssociee->getPeriodicite();
			}
			if($prestationAssociee->getDebutPeriode("d/m/Y")!="01/01/2000") {
				$this->inputAjoutHoraires_debut->Text = $prestationAssociee->getDebutPeriode("d/m/Y");
			}
			if($prestationAssociee->getfinPeriode("d/m/Y")!="01/01/2100") {
				$this->inputAjoutHoraires_fin->Text = $prestationAssociee->getfinPeriode("d/m/Y");
			}
			$this->remplirJour($prestationAssociee);
		}
		elseif($this->Page->getViewState("typePrestation")==Atexo_Config::getParameter("PRESTATION_REFERENTIEL")) {
			$tPrestaQ = new TPrestationQuery();
			$tPresta = $tPrestaQ->getPrestationById($this->getIdPrestation());
			$tTypePrestaQ = new TTypePrestationQuery();
			$tTypePresta = $tTypePrestaQ->getTypePrestationById($this->getIdTypePrestation());
			if($tPresta && $tPresta->getTRefPrestation() && $tTypePresta && $tTypePresta->getTRefTypePrestation()) {
				$tParametragePrestaQ = new TParametragePrestationQuery();
				$tParametragePresta = $tParametragePrestaQ->getParametrageByCriteres($tTypePresta->getIdRefTypePrestation(), $tPresta->getIdRefPrestation());
				$this->inputDureeRdv->Text = $tParametragePresta->getPeriodicite();
			}
		}
	}
	
	public function remplirJourLundi($prestationAssociee) {
		if($prestationAssociee->getLundiHeureDebut1()!=null && $prestationAssociee->getLundiHeureFin1()!=null) {
			$this->jour_01_matin_horaire->setChecked(true);
			$this->jour_01_matin_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getLundiHeureDebut1());
			$this->jour_01_matin_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getLundiHeureFin1());
			$this->nbreRdvJour01_matin->Text = $prestationAssociee->getLundiCapacite1();
			$this->nbreRdvJour01_matinh->Value = $prestationAssociee->getLundiCapacite1();
			$this->nbreRdvJour_01_matin_surSite->Text = $prestationAssociee->getLundiNbRdvSite1();
		} else {
			$this->jour_01_matin_indisponible->SetChecked(true);
		}
		if($prestationAssociee->getLundiHeureDebut2()!=null && $prestationAssociee->getLundiHeureFin2()!=null) {
			$this->jour_01_apresmidi_horaire->setChecked(true);
			$this->jour_01_apresmidi_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getLundiHeureDebut2());
			$this->jour_01_apresmidi_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getLundiHeureFin2());
			$this->nbreRdvJour01_soir->Text = $prestationAssociee->getLundiCapacite2();
			$this->nbreRdvJour01_soirh->Value = $prestationAssociee->getLundiCapacite2();
			$this->nbreRdvJour_01_soir_surSite->Text = $prestationAssociee->getLundiNbRdvSite2();
		} else {
			$this->jour_01_apresmidi_indisponible->SetChecked(true);
		}
	}
	public function remplirJourMardi($prestationAssociee) {
		if($prestationAssociee->getMardiHeureDebut1()!=null && $prestationAssociee->getMardiHeureFin1()!=null) {
			$this->jour_02_matin_horaire->setChecked(true);
			$this->jour_02_matin_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMardiHeureDebut1());
			$this->jour_02_matin_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMardiHeureFin1());
			$this->nbreRdvJour02_matin->Text = $prestationAssociee->getMardiCapacite1();
			$this->nbreRdvJour02_matinh->Value = $prestationAssociee->getMardiCapacite1();
			$this->nbreRdvJour_02_matin_surSite->Text = $prestationAssociee->getMardiNbRdvSite1();
		} else {
			$this->jour_02_matin_indisponible->SetChecked(true);
		}
		if($prestationAssociee->getMardiHeureDebut2()!=null && $prestationAssociee->getMardiHeureFin2()!=null) {
			$this->jour_02_apresmidi_horaire->setChecked(true);
			$this->jour_02_apresmidi_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMardiHeureDebut2());
			$this->jour_02_apresmidi_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMardiHeureFin2());
			$this->nbreRdvJour02_soir->Text = $prestationAssociee->getMardiCapacite2();
			$this->nbreRdvJour02_soirh->Value = $prestationAssociee->getMardiCapacite2();
			$this->nbreRdvJour_02_soir_surSite->Text = $prestationAssociee->getMardiNbRdvSite2();
		} else {
			$this->jour_02_apresmidi_indisponible->SetChecked(true);
		}
	}
	public function remplirJourMercredi($prestationAssociee) {
		if($prestationAssociee->getMercrediHeureDebut1()!='' && $prestationAssociee->getMercrediHeureFin1()!='') {
			$this->jour_03_matin_horaire->setChecked(true);
			$this->jour_03_matin_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMercrediHeureDebut1());
			$this->jour_03_matin_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMercrediHeureFin1());
			$this->nbreRdvJour03_matin->Text = $prestationAssociee->getMercrediCapacite1();
			$this->nbreRdvJour03_matinh->Value = $prestationAssociee->getMercrediCapacite1();
			$this->nbreRdvJour_03_matin_surSite->Text = $prestationAssociee->getMercrediNbRdvSite1();
		} else {
			$this->jour_03_matin_indisponible->SetChecked(true);
		}
		if($prestationAssociee->getMercrediHeureDebut2()!=null && $prestationAssociee->getMercrediHeureFin2()!=null) {
			$this->jour_03_apresmidi_horaire->setChecked(true);
			$this->jour_03_apresmidi_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMercrediHeureDebut2());
			$this->jour_03_apresmidi_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getMercrediHeureFin2());
			$this->nbreRdvJour03_soir->Text = $prestationAssociee->getMercrediCapacite2();
			$this->nbreRdvJour03_soirh->Value = $prestationAssociee->getMercrediCapacite2();
			$this->nbreRdvJour_03_soir_surSite->Text = $prestationAssociee->getMercrediNbRdvSite2();
		} else {
			$this->jour_03_apresmidi_indisponible->SetChecked(true);
		}
	}
	public function remplirJourJeudi($prestationAssociee) {
		if($prestationAssociee->getJeudiHeureDebut1()!=null && $prestationAssociee->getJeudiHeureFin1()!=null) {
			$this->jour_04_matin_horaire->setChecked(true);
			$this->jour_04_matin_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getJeudiHeureDebut1());
			$this->jour_04_matin_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getJeudiHeureFin1());
			$this->nbreRdvJour04_matin->Text = $prestationAssociee->getJeudiCapacite1();
			$this->nbreRdvJour04_matinh->Value = $prestationAssociee->getJeudiCapacite1();
			$this->nbreRdvJour_04_matin_surSite->Text = $prestationAssociee->getJeudiNbRdvSite1();
		} else {
			$this->jour_04_matin_indisponible->SetChecked(true);
		}
		if($prestationAssociee->getJeudiHeureDebut2()!=null && $prestationAssociee->getJeudiHeureFin2()!=null) {
			$this->jour_04_apresmidi_horaire->setChecked(true);
			$this->jour_04_apresmidi_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getJeudiHeureDebut2());
			$this->jour_04_apresmidi_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getJeudiHeureFin2());
			$this->nbreRdvJour04_soir->Text = $prestationAssociee->getJeudiCapacite2();
			$this->nbreRdvJour04_soirh->Value = $prestationAssociee->getJeudiCapacite2();
			$this->nbreRdvJour_04_soir_surSite->Text = $prestationAssociee->getJeudiNbRdvSite2();
		} else {
			$this->jour_04_apresmidi_indisponible->SetChecked(true);
		}
	}
	public function remplirJourVendredi($prestationAssociee) {
		if($prestationAssociee->getVendrediHeureDebut1()!=null && $prestationAssociee->getVendrediHeureFin1()!=null) {
			$this->jour_05_matin_horaire->setChecked(true);
			$this->jour_05_matin_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getVendrediHeureDebut1());
			$this->jour_05_matin_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getVendrediHeureFin1());
			$this->nbreRdvJour05_matin->Text = $prestationAssociee->getVendrediCapacite1();
			$this->nbreRdvJour05_matinh->Value = $prestationAssociee->getVendrediCapacite1();
			$this->nbreRdvJour_05_matin_surSite->Text = $prestationAssociee->getVendrediNbRdvSite1();
		} else {
			$this->jour_05_matin_indisponible->SetChecked(true);
		}
		if($prestationAssociee->getVendrediHeureDebut2()!=null && $prestationAssociee->getVendrediHeureFin2()!=null) {
			$this->jour_05_apresmidi_horaire->setChecked(true);
			$this->jour_05_apresmidi_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getVendrediHeureDebut2());
			$this->jour_05_apresmidi_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getVendrediHeureFin2());
			$this->nbreRdvJour05_soir->Text = $prestationAssociee->getVendrediCapacite2();
			$this->nbreRdvJour05_soirh->Value = $prestationAssociee->getVendrediCapacite2();
			$this->nbreRdvJour_05_soir_surSite->Text = $prestationAssociee->getVendrediNbRdvSite2();
		} else {
			$this->jour_05_apresmidi_indisponible->SetChecked(true);
		}
	}
	public function remplirJourSamedi($prestationAssociee) {
		if($prestationAssociee->getSamediHeureDebut1()!=null && $prestationAssociee->getSamediHeureFin1()!=null) {
			$this->jour_06_matin_horaire->setChecked(true);
			$this->jour_06_matin_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getSamediHeureDebut1());
			$this->jour_06_matin_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getSamediHeureFin1());
			$this->nbreRdvJour06_matin->Text = $prestationAssociee->getSamediCapacite1();
			$this->nbreRdvJour06_matinh->Value = $prestationAssociee->getSamediCapacite1();
			$this->nbreRdvJour_06_matin_surSite->Text = $prestationAssociee->getSamediNbRdvSite1();
		} else {
			$this->jour_06_matin_indisponible->SetChecked(true);
		}
		if($prestationAssociee->getSamediHeureDebut2()!=null && $prestationAssociee->getSamediHeureFin2()!=null) {
			$this->jour_06_apresmidi_horaire->setChecked(true);
			$this->jour_06_apresmidi_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getSamediHeureDebut2());
			$this->jour_06_apresmidi_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getSamediHeureFin2());
			$this->nbreRdvJour06_soir->Text = $prestationAssociee->getSamediCapacite2();
			$this->nbreRdvJour06_soirh->Value = $prestationAssociee->getSamediCapacite2();
			$this->nbreRdvJour_06_soir_surSite->Text = $prestationAssociee->getSamediNbRdvSite2();
		} else {
			$this->jour_06_apresmidi_indisponible->SetChecked(true);
		}
	}
	public function remplirJourDimanche($prestationAssociee) {
		if($prestationAssociee->getDimancheHeureDebut1()!=null && $prestationAssociee->getDimancheHeureFin1()!=null) {
			$this->jour_07_matin_horaire->setChecked(true);
			$this->jour_07_matin_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getDimancheHeureDebut1());
			$this->jour_07_matin_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getDimancheHeureFin1());
			$this->nbreRdvJour07_matin->Text = $prestationAssociee->getDimancheCapacite1();
			$this->nbreRdvJour07_matinh->Value = $prestationAssociee->getDimancheCapacite1();
			$this->nbreRdvJour_07_matin_surSite->Text = $prestationAssociee->getDimancheNbRdvSite1();
		} else {
			$this->jour_07_matin_indisponible->SetChecked(true);
		}
		if($prestationAssociee->getDimancheHeureDebut2()!=null && $prestationAssociee->getDimancheHeureFin2()!=null) {
			$this->jour_07_apresmidi_horaire->setChecked(true);
			$this->jour_07_apresmidi_horaire_debut->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getDimancheHeureDebut2());
			$this->jour_07_apresmidi_horaire_fin->Text = Atexo_Utils_Util :: getFormatHhMm($prestationAssociee->getDimancheHeureFin2());
			$this->nbreRdvJour07_soir->Text = $prestationAssociee->getDimancheCapacite2();
			$this->nbreRdvJour07_soirh->Value = $prestationAssociee->getDimancheCapacite2();
			$this->nbreRdvJour_07_soir_surSite->Text = $prestationAssociee->getDimancheNbRdvSite2();
		} else {
			$this->jour_07_apresmidi_indisponible->SetChecked(true);
		}
	}
	
	public function remplirJour($prestationAssociee) {
		$this->viderJour();
		$this->viderNbreJour();
		//Lundi
		$this->remplirJourLundi($prestationAssociee);
		//Mardi
		$this->remplirJourMardi($prestationAssociee);
		//Mercredi
		$this->remplirJourMercredi($prestationAssociee);
		//Jeudi
		$this->remplirJourJeudi($prestationAssociee);
		//Vendredi
		$this->remplirJourVendredi($prestationAssociee);
		//Samedi
		$this->remplirJourSamedi($prestationAssociee);
		//Dimanche
		$this->remplirJourDimanche($prestationAssociee);
	}

	public function SaveObject($sender,$param) {
		$prestationAssociee = new Atexo_Prestation_PrestationAssocieeVo();
		$prestationAssociees = $this->Page->getViewState("prestationAssociees");

		/*if($this->idPrestationAssociee->value != null) {
			$prestationAssociee = $prestationAssociees[$this->idPrestationAssociee->value];
		}*/
		//$prestationAssociee->setIdAgent($idAgent);
		$prestationAssociee->setIdTypePrestation($this->typePrestation->getSelectedValue());
		$prestationAssociee->setIdPrestation($this->prestation->getSelectedValue());
		$prestationAssociee->setDureeRdv($this->inputDureeRdv->getSafeText());
		$prestationAssociee->setPeriodicite($this->inputDureeRdv->getSafeText());
		if($this->inputAjoutHoraires_debut->getSafeText()!="") {
			$prestationAssociee->setDebutPeriode($this->inputAjoutHoraires_debut->getSafeText());
		}
		else {
			$prestationAssociee->setDebutPeriode("01/01/2000");
		}
		if($this->inputAjoutHoraires_fin->getSafeText()!="") {
			$prestationAssociee->setfinPeriode($this->inputAjoutHoraires_fin->getSafeText());
		}
		else {
			$prestationAssociee->setfinPeriode("01/01/2100");
		}
		
		$prestationAssociee = $this->setJourPrestation($prestationAssociee);
		
		$actions = explode("-",$this->actionForm->Value);
		if($actions[0]) {
			//Nouvel Horaire
			$prestationAssociees[$actions[3]]['horaires'][] = $prestationAssociee;
		}
		elseif($actions[1]) {//edit horaire
			//get horaire to edit
			$horaires = $prestationAssociees[$actions[3]]['horaires'];
			$horaires[$actions[4]] = $prestationAssociee;
			$prestationAssociees[$actions[3]]['horaires'][$actions[4]] = $prestationAssociee;
		} else {
			$horaires[] = $prestationAssociee;
			$prestationAssociees[$prestationAssociee->getIdPrestation()]['idTypePrestation'] = $prestationAssociee->getIdTypePrestation();
			$prestationAssociees[$prestationAssociee->getIdPrestation()]['idPrestation'] = $prestationAssociee->getIdPrestation();
			//$prestationAssociees[$prestationAssociee->getIdPrestation()]['periodicite'] = $prestationAssociee->getDureeRdv();
			$prestationAssociees[$prestationAssociee->getIdPrestation()]['horaires'] = $horaires;
		}
		$this->Page->nbrePrestationAttachees->Value = count($prestationAssociees);
		$this->Page->setViewState("prestationAssociees",$prestationAssociees);
		$this->viderFormulaire($sender,$param);
		$this->Page->remplirListePrestationAssociees($sender,$param);
	}
	
	public function setJourPrestation($prestationAssociee) {
		if($this->jour_01_matin_horaire->Checked) {
			$prestationAssociee->setLundiHeureDebut1($this->jour_01_matin_horaire_debut->getSafeText());
			$prestationAssociee->setLundiHeureFin1($this->jour_01_matin_horaire_fin->getSafeText());
			$prestationAssociee->setLundiCapacite1($this->getCapacite($this->jour_01_matin_horaire_debut->getSafeText(),$this->jour_01_matin_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setLundiNbRdvSite1($this->nbreRdvJour_01_matin_surSite->getSafeText());
		}
		if($this->jour_01_apresmidi_horaire->Checked) {
			$prestationAssociee->setLundiHeureDebut2($this->jour_01_apresmidi_horaire_debut->getSafeText());
			$prestationAssociee->setLundiHeureFin2($this->jour_01_apresmidi_horaire_fin->getSafeText());
			$prestationAssociee->setLundiCapacite2($this->getCapacite($this->jour_01_apresmidi_horaire_debut->getSafeText(),$this->jour_01_apresmidi_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setLundiNbRdvSite2($this->nbreRdvJour_01_soir_surSite->getSafeText());
		}
		if($this->jour_02_matin_horaire->Checked) {
			$prestationAssociee->setMardiHeureDebut1($this->jour_02_matin_horaire_debut->getSafeText());
			$prestationAssociee->setMardiHeureFin1($this->jour_02_matin_horaire_fin->getSafeText());
			$prestationAssociee->setMardiCapacite1($this->getCapacite($this->jour_02_matin_horaire_debut->getSafeText(),$this->jour_02_matin_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setMardiNbRdvSite1($this->nbreRdvJour_02_matin_surSite->getSafeText());

		}
		if($this->jour_02_apresmidi_horaire->Checked) {
			$prestationAssociee->setMardiHeureDebut2($this->jour_02_apresmidi_horaire_debut->getSafeText());
			$prestationAssociee->setMardiHeureFin2($this->jour_02_apresmidi_horaire_fin->getSafeText());
			$prestationAssociee->setMardiCapacite2($this->getCapacite($this->jour_02_apresmidi_horaire_debut->getSafeText(),$this->jour_02_apresmidi_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setMardiNbRdvSite2($this->nbreRdvJour_02_soir_surSite->getSafeText());
		}
		if($this->jour_03_matin_horaire->Checked) {
			$prestationAssociee->setMercrediHeureDebut1($this->jour_03_matin_horaire_debut->getSafeText());
			$prestationAssociee->setMercrediHeureFin1($this->jour_03_matin_horaire_fin->getSafeText());
			$prestationAssociee->setMercrediCapacite1($this->getCapacite($this->jour_03_matin_horaire_debut->getSafeText(),$this->jour_03_matin_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setMercrediNbRdvSite1($this->nbreRdvJour_03_matin_surSite->getSafeText());
		}
		if($this->jour_03_apresmidi_horaire->Checked) {
			$prestationAssociee->setMercrediHeureDebut2($this->jour_03_apresmidi_horaire_debut->getSafeText());
			$prestationAssociee->setMercrediHeureFin2($this->jour_03_apresmidi_horaire_fin->getSafeText());
			$prestationAssociee->setMercrediCapacite2($this->getCapacite($this->jour_03_apresmidi_horaire_debut->getSafeText(),$this->jour_03_apresmidi_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setMercrediNbRdvSite2($this->nbreRdvJour_03_soir_surSite->getSafeText());
		}
		if($this->jour_04_matin_horaire->Checked) {
			$prestationAssociee->setJeudiHeureDebut1($this->jour_04_matin_horaire_debut->getSafeText());
			$prestationAssociee->setJeudiHeureFin1($this->jour_04_matin_horaire_fin->getSafeText());
			$prestationAssociee->setJeudiCapacite1($this->getCapacite($this->jour_04_matin_horaire_debut->getSafeText(),$this->jour_04_matin_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setJeudiNbRdvSite1($this->nbreRdvJour_04_matin_surSite->getSafeText());
		}
		if($this->jour_04_apresmidi_horaire->Checked) {
			$prestationAssociee->setJeudiHeureDebut2($this->jour_04_apresmidi_horaire_debut->getSafeText());
			$prestationAssociee->setJeudiHeureFin2($this->jour_04_apresmidi_horaire_fin->getSafeText());
			$prestationAssociee->setJeudiCapacite2($this->getCapacite($this->jour_04_apresmidi_horaire_debut->getSafeText(),$this->jour_04_apresmidi_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setJeudiNbRdvSite2($this->nbreRdvJour_04_soir_surSite->getSafeText());
		}
		if($this->jour_05_matin_horaire->Checked) {
			$prestationAssociee->setVendrediHeureDebut1($this->jour_05_matin_horaire_debut->getSafeText());
			$prestationAssociee->setVendrediHeureFin1($this->jour_05_matin_horaire_fin->getSafeText());
			$prestationAssociee->setVendrediCapacite1($this->getCapacite($this->jour_05_matin_horaire_debut->getSafeText(),$this->jour_05_matin_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setVendrediNbRdvSite1($this->nbreRdvJour_05_matin_surSite->getSafeText());
		}
		if($this->jour_05_apresmidi_horaire->Checked) {
			$prestationAssociee->setVendrediHeureDebut2($this->jour_05_apresmidi_horaire_debut->getSafeText());
			$prestationAssociee->setVendrediHeureFin2($this->jour_05_apresmidi_horaire_fin->getSafeText());
			$prestationAssociee->setVendrediCapacite2($this->getCapacite($this->jour_05_apresmidi_horaire_debut->getSafeText(),$this->jour_05_apresmidi_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setVendrediNbRdvSite2($this->nbreRdvJour_05_soir_surSite->getSafeText());
		}
		if($this->jour_06_matin_horaire->Checked) {
			$prestationAssociee->setSamediHeureDebut1($this->jour_06_matin_horaire_debut->getSafeText());
			$prestationAssociee->setSamediHeureFin1($this->jour_06_matin_horaire_fin->getSafeText());
			$prestationAssociee->setSamediCapacite1($this->getCapacite($this->jour_06_matin_horaire_debut->getSafeText(),$this->jour_06_matin_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setSamediNbRdvSite1($this->nbreRdvJour_06_matin_surSite->getSafeText());
		}
		if($this->jour_06_apresmidi_horaire->Checked) {
			$prestationAssociee->setSamediHeureDebut2($this->jour_06_apresmidi_horaire_debut->getSafeText());
			$prestationAssociee->setSamediHeureFin2($this->jour_06_apresmidi_horaire_fin->getSafeText());
			$prestationAssociee->setSamediCapacite2($this->getCapacite($this->jour_06_apresmidi_horaire_debut->getSafeText(),$this->jour_06_apresmidi_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setSamediNbRdvSite2($this->nbreRdvJour_06_soir_surSite->getSafeText());
		}
		if($this->jour_07_matin_horaire->Checked) {
			$prestationAssociee->setDimancheHeureDebut1($this->jour_07_matin_horaire_debut->getSafeText());
			$prestationAssociee->setDimancheHeureFin1($this->jour_07_matin_horaire_fin->getSafeText());
			$prestationAssociee->setDimancheCapacite1($this->getCapacite($this->jour_07_matin_horaire_debut->getSafeText(),$this->jour_07_matin_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setDimancheNbRdvSite1($this->nbreRdvJour_07_matin_surSite->getSafeText());
		}
		if($this->jour_07_apresmidi_horaire->Checked) {
			$prestationAssociee->setDimancheHeureDebut2($this->jour_07_apresmidi_horaire_debut->getSafeText());
			$prestationAssociee->setDimancheHeureFin2($this->jour_07_apresmidi_horaire_fin->getSafeText());
			$prestationAssociee->setDimancheCapacite2($this->getCapacite($this->jour_07_apresmidi_horaire_debut->getSafeText(),$this->jour_07_apresmidi_horaire_fin->getSafeText(),$this->inputDureeRdv->getSafeText()));
			$prestationAssociee->setDimancheNbRdvSite2($this->nbreRdvJour_07_soir_surSite->getSafeText());
		}
		return $prestationAssociee;
	}

	public function viderFormulaire($sender,$param) {
		$this->titreModal->Text = Prado::localize('PRESTATION_ASSOCIEE');
		$this->Page->loadTypePrestationRessource();
		$this->prestation->DataSource = array();
		$this->prestation->DataBind();
		$this->typePrestation->setEnabled(true);
		$this->prestation->setEnabled(true);
		$this->inputDureeRdv->setEnabled(true);
		$this->inputAjoutHoraires_debut->Text = "";
		$this->inputAjoutHoraires_fin->Text = "";
		$this->inputDureeRdv->Text = "";
		$this->nbreRdvJour07_soir->Text = "";
		$this->nbreRdvJour07_soirh->Value = "";
		$this->idPrestationAssociee->value = "";
		$this->actionForm->Value = "";
		$this->viderJour();
		$this->viderNbreJour();
		$this->panelPrestsAssoc->render($param->getNewWriter());
	}
	
	public function viderJour() {
		$this->jour_01_matin_horaire->setChecked(false);
		$this->jour_01_matin_indisponible->setChecked(true);
		$this->jour_01_matin_horaire_debut->Text = "";
		$this->jour_01_matin_horaire_fin->Text = "";
		$this->nbreRdvJour01_matin->Text = "";
		$this->nbreRdvJour01_matinh->Value = "";
		$this->jour_01_apresmidi_horaire->setChecked(false);
		$this->jour_01_apresmidi_indisponible->setChecked(true);
		$this->jour_01_apresmidi_horaire_debut->Text = "";
		$this->jour_01_apresmidi_horaire_fin->Text = "";
		$this->nbreRdvJour01_soir->Text = "";
		$this->nbreRdvJour01_soirh->Value = "";
		$this->jour_02_matin_horaire->setChecked(false);
		$this->jour_02_matin_indisponible->setChecked(true);
		$this->jour_02_matin_horaire_debut->Text = "";
		$this->jour_02_matin_horaire_fin->Text = "";
		$this->nbreRdvJour02_matin->Text = "";
		$this->nbreRdvJour02_matinh->Value = "";
		$this->jour_02_apresmidi_horaire->setChecked(false);
		$this->jour_02_apresmidi_indisponible->setChecked(true);
		$this->jour_02_apresmidi_horaire_debut->Text = "";
		$this->jour_02_apresmidi_horaire_fin->Text = "";
		$this->nbreRdvJour02_soir->Text = "";
		$this->nbreRdvJour02_soirh->Value = "";
		$this->jour_03_matin_horaire->setChecked(false);
		$this->jour_03_matin_indisponible->setChecked(true);
		$this->jour_03_matin_horaire_debut->Text = "";
		$this->jour_03_matin_horaire_fin->Text = "";
		$this->nbreRdvJour03_matin->Text = "";
		$this->nbreRdvJour03_matinh->Value = "";
		$this->jour_03_apresmidi_horaire->setChecked(false);
		$this->jour_03_apresmidi_indisponible->setChecked(true);
		$this->jour_03_apresmidi_horaire_debut->Text = "";
		$this->jour_03_apresmidi_horaire_fin->Text = "";
		$this->nbreRdvJour03_soir->Text = "";
		$this->nbreRdvJour03_soirh->Value = "";
		$this->jour_04_matin_horaire->setChecked(false);
		$this->jour_04_matin_indisponible->setChecked(true);
		$this->jour_04_matin_horaire_debut->Text = "";
		$this->jour_04_matin_horaire_fin->Text = "";
		$this->nbreRdvJour04_matin->Text = "";
		$this->nbreRdvJour04_matinh->Value = "";
		$this->jour_04_apresmidi_horaire->setChecked(false);
		$this->jour_04_apresmidi_indisponible->setChecked(true);
		$this->jour_04_apresmidi_horaire_debut->Text = "";
		$this->jour_04_apresmidi_horaire_fin->Text = "";
		$this->nbreRdvJour04_soir->Text = "";
		$this->nbreRdvJour04_soirh->Value = "";
		$this->jour_05_matin_horaire->setChecked(false);
		$this->jour_05_matin_indisponible->setChecked(true);
		$this->jour_05_matin_horaire_debut->Text = "";
		$this->jour_05_matin_horaire_fin->Text = "";
		$this->nbreRdvJour05_matin->Text = "";
		$this->nbreRdvJour05_matinh->Value = "";
		$this->jour_05_apresmidi_horaire->setChecked(false);
		$this->jour_05_apresmidi_indisponible->setChecked(true);
		$this->jour_05_apresmidi_horaire_debut->Text = "";
		$this->jour_05_apresmidi_horaire_fin->Text = "";
		$this->nbreRdvJour05_soir->Text = "";
		$this->nbreRdvJour05_soirh->Value = "";
		$this->jour_06_matin_horaire->setChecked(false);
		$this->jour_06_matin_indisponible->setChecked(true);
		$this->jour_06_matin_horaire_debut->Text = "";
		$this->jour_06_matin_horaire_fin->Text = "";
		$this->nbreRdvJour06_matin->Text = "";
		$this->nbreRdvJour06_matinh->Value = "";
		$this->jour_06_apresmidi_horaire->setChecked(false);
		$this->jour_06_apresmidi_indisponible->setChecked(true);
		$this->jour_06_apresmidi_horaire_debut->Text = "";
		$this->jour_06_apresmidi_horaire_fin->Text = "";
		$this->nbreRdvJour06_soir->Text = "";
		$this->nbreRdvJour06_soirh->Value = "";
		$this->jour_07_matin_horaire->setChecked(false);
		$this->jour_07_matin_indisponible->setChecked(true);
		$this->jour_07_matin_horaire_debut->Text = "";
		$this->jour_07_matin_horaire_fin->Text = "";
		$this->nbreRdvJour07_matin->Text = "";
		$this->nbreRdvJour07_matinh->Value = "";
		$this->jour_07_apresmidi_horaire->setChecked(false);
		$this->jour_07_apresmidi_indisponible->setChecked(true);
		$this->jour_07_apresmidi_horaire_debut->Text = "";
		$this->jour_07_apresmidi_horaire_fin->Text = "";
	}
	
	public function viderNbreJour() {
		$this->nbreRdvJour_01_matin_surSite->Text = "";
		$this->nbreRdvJour_01_soir_surSite->Text = "";
		$this->nbreRdvJour_02_matin_surSite->Text = "";
		$this->nbreRdvJour_02_soir_surSite->Text = "";
		$this->nbreRdvJour_03_matin_surSite->Text = "";
		$this->nbreRdvJour_03_soir_surSite->Text = "";
		$this->nbreRdvJour_04_matin_surSite->Text = "";
		$this->nbreRdvJour_04_soir_surSite->Text = "";
		$this->nbreRdvJour_05_matin_surSite->Text = "";
		$this->nbreRdvJour_05_soir_surSite->Text = "";
		$this->nbreRdvJour_06_matin_surSite->Text = "";
		$this->nbreRdvJour_06_soir_surSite->Text = "";
		$this->nbreRdvJour_07_matin_surSite->Text = "";
		$this->nbreRdvJour_07_soir_surSite->Text = "";
	}

	private function getCapacite($heureDeb,$heureFin,$duree) {
		if($heureDeb=="" || $heureFin=="" || $duree==0) {
			return 0;
		}
		$capacite=0;
		while($heureFin>$heureDeb) {
			$capacite++;
			$heureDeb=Atexo_Utils_Util::addMinutes($heureDeb,$duree);
		}
		if($heureDeb>$heureFin) {
			$capacite--;
		}
		return $capacite;
	}
}
