<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
 class AtexoPage extends TPage
 {
    public function getPfUrl() {
        if( isset ( $_SESSION["pfUrl"] ) ) {
            return $_SESSION["pfUrl"];
        }
        $pfUrl = Atexo_Config::getParameter("PROTOCOLE") . "://" . $_SERVER['SERVER_NAME'] . "/";
        $_SESSION["pfUrl"] = $pfUrl;
        return $pfUrl;
    }
 }