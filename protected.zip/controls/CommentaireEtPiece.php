<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class CommentaireEtPiece extends AtexoPage
{
	public $lang;
	public function initialize($prestation) {
		$this->lang = Atexo_User_CurrentUser::readFromSession("lang");
		if($_SESSION['typePrestation'] == Atexo_Config::getParameter("PRESTATION_REFERENTIEL") && $prestation->getTParametragePrestation()) {
			$this->commentaire->Text = nl2br($prestation->getTParametragePrestation()->getCommentaireTraduit($this->lang));
		}

		if($_SESSION['typePrestation'] == Atexo_Config::getParameter("PRESTATION_REFERENTIEL") && $prestation->getTParametragePrestation()) {
			$data = $prestation->getTParametragePrestation()->getTPieceParamPrestas();
		}
		else {
			$data = $prestation->getTPiecePrestations();
		}
		
		$dataPj = array();
		foreach($data as $pj) {
			if($pj->getUpload()=='0'){
				$dataPj[]=$pj;
			}
		}

		$this->pjs->DataSource = $dataPj;
		$this->pjs->DataBind();
		
		if(count($dataPj)==0 && $this->commentaire->Text=="") {
			$this->panel->Visible = false;
		}
	}
	
	/**
	 * télécharger la pièce jointe 
	 */
	public function downloadPieceJointe($sender) {
		$idFichier = $sender->CommandParameter;
		Atexo_DownloadFile::downloadFiles($idFichier);
	}
}