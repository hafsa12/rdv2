<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class GererMesRendezVous extends AtexoPage {

	
    public $visibleRecapDetailsModal = true;
    public $visibleDetailsRdv = false;


    public function onLoad()
    {
    	if(!$this->Page->isPostBack) {
    		$this->panelConfirmation->Style="display:none";
    		$this->panelAnnulation->Style="display:none";
    	}
    }
    
    public function valider($sender,$param) {
    	$rdv = Atexo_RendezVous_Gestion::retrieveRdvByCodeEmailTel($this->codeRdv->SafeText,$this->email->SafeText,Atexo_Utils_Util::formatTel(strip_tags ($this->telephone->SafeText)));
    	
    	if($rdv) {
    		$this->setViewState("rdv",$rdv);
            $this->confirmationRdv->setViewState("rdv",$rdv);
    		$this->panelRecherche->Style="display:none";
    		$this->panelConfirmation->Style="display:";
    		$lang = Atexo_User_CurrentUser::readFromSession("lang");
    		$this->confirmationRdv->initialize($rdv->getTPrestation()->getTTypePrestation()->getLibelleTypePrestationTraduit($lang),
    			$rdv->getTPrestation()->getLibellePrestationTraduit($lang,Atexo_Config::getParameter ( 'PRESTATION_SAISIE_LIBRE' )),$rdv);
    		
    		$this->initModal($rdv->getTPrestation()->getTTypePrestation()->getLibelleTypePrestationTraduit($lang),
    			$rdv->getTPrestation()->getLibellePrestationTraduit($lang,Atexo_Config::getParameter ( 'PRESTATION_SAISIE_LIBRE' )),$rdv);
    		$this->confirmationRdv->hidePanelEmail();
    		$this->confirmationRdv->hidePanelConfirmation();
    		$this->confirmationRdv->hidePanelReservation();
    		$this->confirmationRdv->hidePanelBtn();
            $this->confirmationRdv->loadPjPanel($rdv);
            $this->confirmationRdv->panelExplication->Visible = false;
    		
    		if($rdv->getEtatRdv()!=Atexo_Config::getParameter("ETAT_EN_ATTENTE")) {
    			$this->panelAction->Style="display:none";
    		}
    		if(in_array($rdv->getEtatRdv(), array(Atexo_Config::getParameter("ETAT_ANNULE"), Atexo_Config::getParameter("ETAT_ANNULE_ETAB")))) {
    			$this->confirmationRdv->showPanelAnnulation();
    		}

    		if(!$rdv->getPartageRecap()){
                $this->btnImprimer->Visible = false;
				$this->refresh->Text='<script>setTimeout(function(){ J(\'.checkEtatRecap\').click(); }, 5000);</script>';
            }

    	} else {
    		$this->msgRdvInexistant->Visible = true;
    	}

    	//$this->panelRecherche->render($param->NewWriter);
    	//$this->panelConfirmation->render($param->NewWriter);
    }
    
	public function initModal($typePrestation,$prestation,$rdv) {
		
		$tEtabQuery = new TEtablissementQuery();
		$etab = $tEtabQuery->getEtablissementById($rdv->getIdEtablissement());
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$this->nomCitoyen->Text = $rdv->getTCitoyen()->getNom()." ".$rdv->getTCitoyen()->getPrenom();
		$this->identifiant->Text = $rdv->getTCitoyen()->getIdentifiant();
		$this->nomEtab->Text = $etab->getDenominationEtablissementTraduit($lang);
		$this->adresseEtab->Text = $etab->getAdresseEtablissementTraduit($lang);
		$this->telEtab->Text = $etab->getTelephoneRdv();
		$this->typePrestation->Text = $typePrestation;
		$this->prestation->Text = $prestation;
		$this->codeRdv->Text = $rdv->getCodeRdv();

        $visio = $rdv->getTPrestation()->getVisioconference();
        if($visio == 1){
            $this->visibleRecapDetailsModal = false;
        }
		
		if($rdv->getIdAgentRessource()!=null && $rdv->getIdAgentRessource()!="" && $rdv->getTPrestation()->getRessourceVisible()=="1") {
			$this->niveau3->Text = "<br>".Prado::localize("NIVEAU3")." : ";
			$tAgentQuery = new TAgentQuery();
			$tAgent = $tAgentQuery->getAgentById($rdv->getIdAgentRessource());

			if($_SESSION['typeRessource']) {
				$this->ressource->Text = $tAgent->getCodeUtilisateurTraduit($lang);
			}
			else {
				$this->ressource->Text = $tAgent->getNomPrenomUtilisateurTraduit($lang);
			}
		}
		
		$this->dateRdv->Text = Prado::localize('LE')." ".$rdv->getDateRdv("d/m/Y")." ".Prado::localize('A')." ".$rdv->getDateRdv("H:i");
	}
	
	public function annuler() {
		$rdv = $this->getViewState("rdv");
		$rdv->setEtatRdv(Atexo_Config::getParameter("ETAT_ANNULE"));
		$rdv->setDateAnnulation(date('Y-m-d'));
		$rdv->save();
		$this->panelRecherche->Style="display:none";
    	$this->panelConfirmation->Style="display:none";
    	$this->panelAnnulation->Style="display:";
	}

    public function imprimerRdv(){

        $lang = Atexo_User_CurrentUser::readFromSession("lang");
        $idOrg = Atexo_User_UserVo::getCurrentOrganism();
        $tTraductionLibelleQuery = new TTraductionLibelleQuery();
        $rdv = $this->getViewState('rdv');

        $etab = $rdv->getTEtablissement();
        $entite = $etab->getTEntite();
        $tOrganisation = $etab->getTOrganisation();
        $prestation = $rdv->getTPrestation();
        $typePrestation = $prestation->getTTypePrestation();

        $idRessource = $rdv->getIdAgentRessource();
        $ressource = TAgentPeer::retrieveByPk($idRessource);
        $codeRessource = '';
        if($ressource->getActif() != 0){
            $codeRessource = $ressource->getCodeUtilisateurTraduit($lang);
            if($codeRessource == ''){
                $codeRessource = $ressource->getNomPrenomUtilisateurTraduit($lang);
            }
        }



        $champSupp1 = $prestation->getIdChampsSupp1();
        $champSupp2 = $prestation->getIdChampsSupp2();

        $libelleChampSupp1 = $tTraductionLibelleQuery->getLibelle($champSupp1, $lang);
        $libelleChampSupp2 = $tTraductionLibelleQuery->getLibelle($champSupp2, $lang);

        $champSuppValue = $rdv->getChampSuppPresta();

        $champsSupp = json_decode($champSuppValue)->$lang;

        $libelleChampSupp1 = '';
        $champSupp1 = '';
        $libelleChampSupp2 = '';
        $champSupp2 = '';
        $libelleChampSupp3 = '';
        $champSupp3 = '';

        $champSupp1Exist = false;
        $champSupp2Exist = false;
        $champSupp3Exist = false;

        if(isset($champsSupp[0])){
            $arr = explode(' : ', $champsSupp[0]);
            $libelleChampSupp1 = $arr[0].' : ';
            $champSupp1 = $arr[1];
            $champSupp1Exist = true;
        }

        if(isset($champsSupp[1])){
            $arr = explode(' : ', $champsSupp[1]);
            $libelleChampSupp2 = $arr[0].' : ';
            $champSupp2 = $arr[1];
            $champSupp2Exist = true;
        }

        if(isset($champsSupp[2])){
            $arr = explode(' : ', $champsSupp[2]);
            $libelleChampSupp3 = $arr[0].' : ';
            $champSupp3 = $arr[1];
            $champSupp3Exist = true;
        }



        $path = "ressources/word/recap_rdv_". $idOrg . "_" . $lang . ".docx";
        $vendorpath = 'protected/library/vendors/vendor';
        require_once $vendorpath.'/autoload.php';
        if(!file_exists($path)){
            $path = "ressources/word/recap_rdv_" . $lang . ".docx";
        }

        $templateProcessor = new \PhpOffice\PhpWord\TemplateProcessor($path);
        $templateProcessor->setValue('etablissement', $etab->getDenominationEtablissementTraduit($lang));
        $templateProcessor->setValue('adresse', $etab->getAdresseEtablissementTraduit($lang));
        $templateProcessor->setValue('type_prestation', $typePrestation->getLibelleTypePrestationTraduit($lang));

        try {
            $templateProcessor->setValue('nom_citoyen', $rdv->getTCitoyen()->getNom());
            $templateProcessor->setValue('prenom_citoyen', $rdv->getTCitoyen()->getPrenom());
            $templateProcessor->setValue('identifiant', $rdv->getTCitoyen()->getIdentifiant());
            $templateProcessor->setValue('raison_social', $rdv->getTCitoyen()->getRaisonSocial());
        }
        catch(Exception $e) {

        }
        if($champSupp1Exist){
            $templateProcessor->setValue('prestation', $prestation->getLibellePrestationTraduit($lang).'</w:t><w:br/><w:t>');
        }else{
            $templateProcessor->setValue('prestation', $prestation->getLibellePrestationTraduit($lang));
        }

        $templateProcessor->setValue('libelle_champ_supp_1', $libelleChampSupp1);
        if($champSupp2Exist){
            $templateProcessor->setValue('champ_supp_1', $champSupp1.'</w:t><w:br/><w:t>');
        }else{
            $templateProcessor->setValue('champ_supp_1', $champSupp1);
        }

        $templateProcessor->setValue('libelle_champ_supp_2', $libelleChampSupp2);
        if($champSupp3Exist){
            $templateProcessor->setValue('champ_supp_2', $champSupp2.'</w:t><w:br/><w:t>');
        }else{
            $templateProcessor->setValue('champ_supp_2', $champSupp2);
        }

        $templateProcessor->setValue('libelle_champ_supp_3', $libelleChampSupp3);
        $templateProcessor->setValue('champ_supp_3', $champSupp3);


        $templateProcessor->setValue('code_ressource', $codeRessource);
        $templateProcessor->setValue('horaire', $rdv->getDateRdv("d/m/Y")." ".Prado::localize('A')." ".$rdv->getDateRdv("H:i"));

        $templateProcessor->setValue('libelle_etablissement', Prado::localize('ETABLISSEMENT').' : ');
        $templateProcessor->setValue('libelle_nature_rdv', Prado::localize('NIVEAU1').' : ');
        $templateProcessor->setValue('libelle_prestation', Prado::localize('NIVEAU2').' : ');
        $templateProcessor->setValue('libelle_entite', Prado::localize('NIVEAU3').' : ');



        $filename = 'recap_rdv_' . $rdv->getCodeRdv() . '.docx';

        header("Content-Type: application/vnd.openxmlformats-officedocument.wordprocessing‌​ml.document");// you should look for the real header that you need if it's not Word 2007!!!
        header('Content-Disposition: attachment; filename=' . $filename);

        $templateProcessor->saveAs("php://output");
        exit;
    }
	
	public function checkEtatRecap($sender, $param) {
		$rdv = $this->getViewState("rdv");
		$rdv->reload();

		$this->btnImprimer->Visible = $rdv->getPartageRecap()=='1';
		
		if(!$rdv->getPartageRecap()) {
			$this->refresh->Text='<script>setTimeout(function(){ J(\'.checkEtatRecap\').click(); }, 5000);</script>';
		}
		else {
			$this->refresh->Text='';
		}
	}

}