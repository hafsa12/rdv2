<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class AtexoInfoMessage extends TTemplateControl {

	protected $text;
	protected $visible=false;
	protected $divClass = "bloc message msg-info";

	public function setVisible($param)
	{
		if($param=="true"){
			$this->visible= true;
		}else{
			$this->visible= false;
		}
	}

	public function setText($param)
	{
		$this->text = $param;
	}
	
	public function cleanMessage() {
		$this->text = "";
		$this->visible = false;
	}

	public function remplirMessage($visible, $text) {

		$this->Visible=$visible;
		$this->Text= $text;
	}
	
	public function getClientId() 
	{
		return $this->divMessage->getClientId();
	}
}