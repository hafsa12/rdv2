<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class RdvJour extends AtexoPage {

	public $entete;

	public function initialize($date, $dataSource)
	{
		if(count($dataSource)>0) {
			$this->msgNoResult->Visible=false;
            $this->listeRdvs->Visible = true;
		}
		else {
			$this->msgNoResult->Visible=true;
			$this->listeRdvs->Visible = false;
		}
        $data = array();
        for($j = 8; $j < 19; $j++){
            if(isset($dataSource[$j])){
                $data[$j] = $dataSource[$j];
            }
            elseif (isset($dataSource["0".strval($j)])){
                $data["0".strval($j)] = $dataSource["0".strval($j)];
            }
            else{
                $heure = $j;
                if($j<=9){
                    $heure = "0".strval($j);
                }
                $data[$j] = array('HEURE' => $heure, 'RDV' => array());
            }
        }

        foreach($data as &$ligneHeure){
            if(!empty($ligneHeure['RDV'])){
                foreach($ligneHeure['RDV'] as &$rdv){
                    $minutesDeb = explode(':',$rdv['TIME_DEB_RDV'])[1];
                    $diff = abs(strtotime($rdv['TIME_DEB_RDV']) - strtotime($rdv['TIME_FIN_RDV']));
                    $mins = $diff/60;
                    $leapHours = floor(abs($mins-5)/60);
                    $rdv['TOP'] = min($minutesDeb*1.01666666667,40);
                    $rdv['HAUTEUR'] = max(23,$mins*1.35 + 2*$leapHours - 2);
                }
            }
        }
		$this->entete = self::getNomDate($date);
		$this->listeRdvs->setDataSource($data);
		$this->listeRdvs->DataBind();
	}
	
	public function getNomDate($date) {
		list($jour,$mois,$annee) = explode("/",$date);
		$util = new Atexo_Utils_Util();
		$w = $util->getCleDate($util->frnDate2iso($date));
		return Prado::localize("DAY".$w)." ".$jour." ".Prado::localize("MONTH".((int)$mois))." ".$annee;
	}
}