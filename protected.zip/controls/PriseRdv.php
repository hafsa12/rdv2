<?php 
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class PriseRdv extends AtexoPage
{
	public $jourIndisponible;
	public $heureAvant;
	public $defaultDate;
	public $maxDate;
	public $dateSelectionnee;
	public $isRechercheEtendu;
	public $countVide=0;
	protected $visibleRecapDetails = true;
	
    public function initialize($idPrestation,$idRessource,$isRecherche,$nbJours,$nbMois,$nbRdvGrp,$intervalJour,$isRechercheEtendu, $prestaForm) {
        $this->setViewState("idPrestation",$idPrestation);
    	$this->setViewState("idRessource",$idRessource);
    	$this->setViewState("isRechercheEtendu",$isRechercheEtendu);
    	
    	$this->isRechercheEtendu = $isRechercheEtendu;
    	
    	$this->remplirAgenda($isRecherche,$nbJours,$nbMois,$nbRdvGrp,$intervalJour);
    	$this->maxDate = Atexo_Utils_Util::addMois(date("Y-m-d"),Atexo_Config::getParameter("NB_MOIS_MAX_RDV"));

		$tPrestationQuery = new TPrestationQuery();
		$tPrestation = $tPrestationQuery->getPrestationById($idPrestation);
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
        if(!($tPrestation instanceof TPrestation)) {
            $this->Page->gestionRdv->gotoChoixPrestation();
            return;
        }
		$this->_initRecapitulatif ($tPrestation, $prestaForm, $lang);

		if($idRessource!=null && $idRessource!="") {
			if($tPrestation->getRessourceVisible()=="1" || Atexo_User_CurrentUser::isAdmin()) {
				$this->niveau3->Text = "<br>".Prado::localize("NIVEAU3")." : ";
				$tAgentQuery = new TAgentQuery();
				$tAgent = $tAgentQuery->getAgentById($idRessource);
				if($_SESSION['typeRessource']) {
					$this->ressource->Text = $tAgent->getCodeUtilisateurTraduit($lang);
				}
				else {
					$this->ressource->Text = $tAgent->getNomPrenomUtilisateurTraduit($lang);
				}
			}
		}
		else {
			$this->niveau3->Text = '';
			$this->ressource->Text = '';
		}
		if($this->Page->gestionRdv->unEtab->Value == 'true'){
			$this->visibleRecapDetails = false;
		}

    }

	private function _initRecapitulatif ($tPrestation, $prestaForm, $lang) {
		$idOrg = $this->User->getCurrentOrganism ();
		if ( $idOrg > 0 ) {
			$tOrganisationQuery = new TOrganisationQuery();
			$tOrganisation = $tOrganisationQuery->getOrganisationById ( $idOrg );
			$typePrestation = $tOrganisation->getTypePrestation ();
		} else {
			$typePrestation = Atexo_Config::getParameter ( 'PRESTATION_SAISIE_LIBRE' );
		}
        $tTypePrestation = $tPrestation->getTTypePrestation();
		$tEtabQuery = new TEtablissementQuery();
		if($tPrestation->getVisioconference() == 1){
            $this->visibleRecapDetails = false;
        }
        $etab = $tEtabQuery->getEtablissementById($tTypePrestation->getIdEtablissement());
        $this->nomEtab->Text = $etab->getDenominationEtablissementTraduit($lang);
        $this->adresseEtab->Text = $etab->getAdresseCompleteEtablissement($lang);
        $this->telEtab->Text = $etab->getTelephoneRdv();
		$this->typePrestation->Text = $tTypePrestation->getLibelleTypePrestationTraduit($lang, $typePrestation);
		$this->prestation->Text = $tPrestation->getLibellePrestationTraduit($lang, $typePrestation);
		$this->champsSupp->Text = implode("<br>",$prestaForm[$lang]);
	}
    
    public function remplirAgenda($isRecherche,$nbJours,$nbMois,$nbRdvGrp,$intervalJour) {
    	$idPrestation = $this->getViewState("idPrestation");
    	$idRessource = $this->getViewState("idRessource");
    	    	
    	$rdvGestion = new Atexo_RendezVous_Gestion();
    	$joursIndispoMois = $rdvGestion->getJourIndispoRdvMois($this->User->getCurrentOrganism(), $idPrestation, Atexo_User_CurrentUser::isConnected(), $idRessource);
    	$util = new Atexo_Utils_Util();

		if($nbJours>0) {
			$dateJour=date('Y-m-d');
			$dateJourPlusNbJours=$util->addJours($dateJour,$nbJours);

			while($dateJour<$dateJourPlusNbJours){
				$joursIndispoMois[$dateJour]=$dateJour;
				$dateJour = $util->addJours($dateJour,1);
			}
		}
	if($nbMois>0) {
			$dateJour=date('Y-m-d');
			$dateJourPlusNbMois=$util->addMois($dateJour,$nbMois);

			while($dateJour<$dateJourPlusNbMois){
				$joursIndispoMois[$dateJour]=$dateJour;
				$dateJour = $util->addJours($dateJour,1);
			}
		}
    	
    	foreach($joursIndispoMois as $jourIndispo) {
    		$this->jourIndisponible .= "'".$jourIndispo."',";
    	}
    	
    	$this->jourIndisponible[strlen($this->jourIndisponible)-1]=" ";    	
    	$dateDispo = date("Y-m-d");
    	if(!$this->isRechercheEtendu) {
		    while(in_array($dateDispo,$joursIndispoMois)){
	    		$dateDispo = $util->addJours($dateDispo,1);
	    	}
    	}
if($dateDispo>$util->addJours(date("Y-m-d"),365)) $this->defaultDate=date("Y-m-d");
else	$this->defaultDate = $dateDispo;

    	$this->dateSelectionnee = Atexo_Utils_Util::iso2frnDate($dateDispo);
    	$this->getHeureJour($dateDispo,$isRecherche,$nbRdvGrp,$intervalJour);
    }
    
    public function showHeure($sender,$param) {
		if(Atexo_Utils_Util::isDate($this->selectedDay->Value,'Y-m-d')) {
			$this->getHeureJour($this->selectedDay->Value, true);
		}
		else {
			$this->noResult->Style="display:";
			$this->Page->gestionRdv->noResult=true;

			$this->agendaHeure->DataSource = array();
			$this->agendaHeure->DataBind();
		}
	    $this->heures->render($param->NewWriter,true);
    }
    
    public function getHeureJour($dateIso,$isRecherche,$nbRdvGrp=null,$intervalJour=null) {
    	$this->isRechercheEtendu = $this->getViewState("isRechercheEtendu");
    	$this->dateSelectionnee = Atexo_Utils_Util::iso2frnDate($dateIso);
    	$idPrestation = $this->getViewState("idPrestation");
    	$idRessource = $this->getViewState("idRessource");
    	$this->setViewState("dateRdv",$dateIso);

		$rdvGestion = new Atexo_RendezVous_Gestion();

		if($intervalJour>0) {
			$rdvGroupe = array();
			$i=0;
			$noAgenda=false;
			while($i<$nbRdvGrp) {
				$maxInterval=1;
				if($i>0) {
					$dateIso = Atexo_Utils_Util::addJours($dateIso, $intervalJour);
				}
				$heureDispo = $rdvGestion->getHeureDisponibleJour($idPrestation, $dateIso, Atexo_User_CurrentUser::isConnected(), $idRessource);
				while(count($heureDispo)==0) {
					if($maxInterval<32) {
						$maxInterval++;
						$dateIso = Atexo_Utils_Util::addJours($dateIso,1);
						$heureDispo = $rdvGestion->getHeureDisponibleJour($idPrestation, $dateIso, Atexo_User_CurrentUser::isConnected(), $idRessource);
					}
					else {
						$noAgenda=true;
						break;
					}
				}
				if($noAgenda) {
					break;
				}
				foreach ($heureDispo as $heureOne) {
					$rdvGroupe[$i]["dateIso"] = $dateIso;
					$rdvGroupe[$i]["idRessource"] = $heureOne["idRessource"];
					$rdvGroupe[$i]["heureDebut"] = $heureOne["heureDebut"];
					$rdvGroupe[$i]["heureFin"] = $heureOne["heureFin"];
					$rdvGroupe[$i]["listeHeures"] = $heureDispo;
					break;
				}
				$i++;
			}
			$this->Page->gestionRdv->gotoCitoyenRdvGroupe($idPrestation,$rdvGroupe);
			return;
		}

		$heureDispo = $rdvGestion->getHeureDisponibleJour($idPrestation, $dateIso, Atexo_User_CurrentUser::isConnected(), $idRessource, $this->isRechercheEtendu);

	    $this->agendaHeure->DataSource = $heureDispo;
	    $this->agendaHeure->DataBind();

	    if(count($heureDispo)==0) {
	    	if($this->countVide<32) {
	    		$this->countVide++;
	    		$this->getHeureJour(Atexo_Utils_Util::addJours($dateIso,1),$isRecherche);
	    	}
	    	else {
		    	$this->noResult->Style="display:";
		    	$this->Page->gestionRdv->noResult=true;

	    	}
	    }
	    else {
	    	$this->noResult->Style="display:none";
	    	$this->scriptJs->Text = "<script>J('#datepicker').datepicker( \"setDate\",'".$dateIso."');</script>";
	    	if(!$isRecherche && !$this->isRechercheEtendu) {
	    		foreach($heureDispo as $heureOne) {
	    			$this->Page->gestionRdv->gotoCitoyen($idPrestation,$heureOne["idRessource"],$dateIso,$heureOne["heureDebut"],$heureOne["heureFin"]);
	    			return;
	    		}
	    	}
	    }
    }
    
    public function saveRdv($sender) {
    	$dateRdv = $this->getViewState("dateRdv");
    	$idPrestation = $this->getViewState("idPrestation");
    	list($heures,$idRessource) = explode("#",$sender->CommandParameter);
    	list($heureDeb,$heureFin) = explode("-",$heures);
    	$this->Page->gestionRdv->gotoCitoyen($idPrestation,$idRessource,$dateRdv,$heureDeb,$heureFin);
    }
    
    public function initHeure($heure) {
    	$this->heureAvant = substr($heure,0,2);
    }
}
