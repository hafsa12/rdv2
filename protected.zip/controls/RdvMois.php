<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */

class RdvMois extends AtexoPage {

	public $entete=array();
	public $displayRessource=true;

	public function onLoad($param)
    {

    }

    public function initialize($dateDeb,$dateFin, $dataSource, $displayRessource)
	{
		if(count($dataSource)>0) {
			$this->msgNoResult->Visible=false;
		}
		else {
			$this->msgNoResult->Visible=true;
		}


		$this->displayRessource = $displayRessource;
		
		self::getNomDate();
        $this->moisHidden->Value = prado::localize('MONTH'.ltrim(explode('/',$this->Page->selectedDay->Text)[1], '0'));
		$data = $this->prepareDataSource($dateDeb,$dateFin,$dataSource);
        $this->listeRdvs->setDataSource($data);
		$this->listeRdvs->DataBind();

	}
	
	public function getNomDate() {
		$this->entete=array();
		for($i=1;$i<=7;$i++) {
			$this->entete[] = Prado::localize("DAY".$i);
		}
	}
	
	public function prepareDataSource($dateDeb,$dateFin,$data) {
		
		if(count($data)==0) {
			return array();
		}
		$util = new Atexo_Utils_Util();
		
		$dateDeb = $util->frnDate2iso($dateDeb);
		$dateFin = $util->frnDate2iso($dateFin);
		$rdvs = array();
		$jour=1;
		$i=0;
		
		while($dateDeb<=$dateFin) {
			$dateDebFrn=$util->iso2frnDate($dateDeb);
			$rdvs[$i][$dateDebFrn]=$data[$dateDebFrn];
			$rdvs[$i][$dateDebFrn]["JOUR_RDV"]=substr($dateDebFrn,0,2);
			$dateDeb=$util->addJours($dateDeb, 1);
			$jour++;
			if($jour==8) {
				$jour=1;
				$i++;
			}
			
		}
		
		return $rdvs;
	}
}