<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2017
 * @version 0.0
 * @since Portail
 * @package atexo
 * @subpackage atexo
 */

class StatistiquesRdvRecuComp extends TTemplateControl {

	public $organismes;
	public $nbrRdvRecusParOrganisme;
	public $totalRdvParOrg;
	public $heightOrg;
	public $libelle_par;
	public $dateCreation;
	public $nbrRdvMoisAnnee;

	public function drawStat($criteriaVo) {
		$this->Page->setViewState("criteriaVo", $criteriaVo);
		$nb = 0;
		$nb += $this->getStatistiquesOrganismes($criteriaVo);
		$nb += $this->getStatistiquesEvolutionNbrRdv($criteriaVo);
		$this->panelMessage->Visible=false;
		if($nb == 0){
			$this->panelMessage->Visible=true;
		}
	}

	public function getStatistiquesOrganismes($criteriaVo){
		$tRendezVous = new TRendezVous();
		if($criteriaVo->getIdOrganisationAttache()){
			$data = $tRendezVous->getNbRdvRecuesParEtablissement($criteriaVo);
			$this->libelle_par = "ETABLISSEMENT";

		}else {
			$data = $tRendezVous->getNbRdvRecuesParOrganisation($criteriaVo);
			$this->libelle_par = "ORGANISME";
		}
		Atexo_User_CurrentUser::writeToSession("libelle_par",$this->libelle_par);
		Atexo_User_CurrentUser::writeToSession("dataParOrg",$data);
		$total = 0;
		if(count($data)>0){
			foreach($data as $org) {
				$this->organismes .= "'".$this->stringToJs($org["DENOMINATION"])."',";
				$this->nbrRdvRecusParOrganisme .= (int)$org["NBR_RDV"].',';
				$total += (int)$org["NBR_RDV"];
			}
			$this->totalRdvParOrg = $total;
			$this->organismeGraphe->Visible=true;
			$this->organismeGrapheChart->Visible=true;
			$this->heightOrg = count($data)* 30 ;
			return 1;
		}
		else{
			$this->organismeGraphe->Visible=false;
			$this->organismeGrapheChart->Visible=false;
			return 0;
		}
	}

	public function getStatistiquesEvolutionNbrRdv($criteriaVo){
		$tRendezVous = new TRendezVous();
		$data = $tRendezVous->getEvolRdvRecuesParMoisAnnee($criteriaVo);

		if(count($data)>0){
			$util = new Atexo_Utils_Util();
			$debInit = $deb = substr($util->frnDate2iso($criteriaVo->getDateDuCreation()),0,7);
			$fin = substr($util->frnDate2iso($criteriaVo->getDateAuCreation()),0,7);
			$deb = $debInit;

			$infos = array();
			while($deb<=$fin) {
				if(!isset($data[$deb])) {
					foreach($data['IDS'] as $id){
						if(!isset($infos[$id]['DATE'])){
							$infos[$id]['DATE'] = array();
						}
						if(!isset($infos[$id]['NBR_RDV'])){
							$infos[$id]['NBR_RDV'] = array();
						}
						$infos[$id]['DATE'][] = $deb;
						$infos[$id]['NBR_RDV'][] = 0;
					}
				}else{
					$ids = array();
					foreach ($data[$deb] as $key => $dataArray) {
						$id = $dataArray['ID'];
						
						$ids[] = $id;
						$infos[$id]['DENOMINATION'] = $dataArray['DENOMINATION'];
						if(!isset($infos[$id]['DATE'])){
							$infos[$id]['DATE'] = array();
						}
						if(!isset($infos[$id]['NBR_RDV'])){
							$infos[$id]['NBR_RDV'] = array();
						}
						$infos[$id]['NBR_RDV'][] = $dataArray['NBR_RDV'];
						$infos[$id]['DATE'][] = $dataArray['DATE'];
					}
					foreach($data['IDS'] as $id){
						if(!in_array($id,$ids)){
							if(!isset($infos[$id]['DATE'])){
								$infos[$id]['DATE'] = array();
							}
							if(!isset($infos[$id]['NBR_RDV'])){
								$infos[$id]['NBR_RDV'] = array();
							}
							$infos[$id]['DATE'][] = $deb;
							$infos[$id]['NBR_RDV'][] = 0;
						}
					}
				}
				$date = explode("-", $deb);
				$this->dateCreation .= "'".Prado::localize("MONTH" . ((int)$date[1])) . ' ' . $date[0]."',";
				$deb = $this->getMoisProchain($deb);
			}
			Atexo_User_CurrentUser::writeToSession("dataEvolution",$infos);
			$series = "";
			foreach ($infos as $key => $nbrRdvParMois) {
				$serie  = "{";
				$serie .= "name: '".addslashes($nbrRdvParMois['DENOMINATION'])."',";
				$serie .= "data: [".implode(",", $nbrRdvParMois['NBR_RDV'])."]";
				$serie .= "},";
				$series .= $serie;

			}
			
			$this->nbrRdvMoisAnnee = $series;
			
			$this->evolutionGraphe->Visible=true;
			$this->evolutionGrapheChart->Visible=true;
			return 1;
		}
		else{
			$this->evolutionGraphe->Visible=false;
			$this->evolutionGrapheChart->Visible=false;
			return 0;
		}
	}

	private function stringToJs($value) {
		return trim(preg_replace('/\s\s+/', ' ', addslashes($value)));
	}

	private function getMoisProchain($anneeMois) {
		$date = explode("-", $anneeMois);
		if($date[1]==12) {
			return ($date[0]+1)."-01";
		}
		return ($date[0])."-".str_pad(($date[1]+1),2,"0", STR_PAD_LEFT);
	}

	public function genererExcelParOrg($sender, $param)
	{
		$results = Atexo_User_CurrentUser::readFromSession("dataParOrg");
		$libelle_par = Atexo_User_CurrentUser::readFromSession("libelle_par");

		require_once 'Spreadsheet/Excel/Writer.php';
		// Creer le fichier
		$excel = new Spreadsheet_Excel_Writer();

		// Ajouter une feuille de calcul
		$sheet = &$excel->addWorksheet();
		$excel->setVersion(8);
		$sheet->setInputEncoding('utf-8');
		//Style des cellules du Titre
		$excel->setCustomColor(24, 204, 204, 255);
		$entete = &$excel->addFormat();
		$entete->setColor('black');
		$entete->setBold();
		$entete->setPattern(1);
		$entete->setFgColor(24);
		$entete->setAlign('center');
		$entete->setSize(12);
		//$entete->setBorder(1);
		$entete->setOutLine();
		$entete->setTextWrap();
		//$entete->setFontFamily('Courier');


		//Style des cellules d'entete
		$format = &$excel->addFormat();
		$format->setColor('#f1f1f1');
		$format->setBold(1);
		$format->setPattern(1);
		$format->setFgColor('gray');
		$format->setAlign('center');
		$format->setSize(10);
		$format->setBorder(1);
		$format->setOutLine();

		//Style des cellules
		$corps_format = &$excel->addFormat();
		$corps_format->setColor('black');
		$corps_format->setPattern(1);
		$corps_format->setFgColor(1);
		$corps_format->setSize(10);
		$corps_format->setBorder(1);
		$corps_format->setAlign('center');
		$corps_format->setTextWrap();
		$sheet->setColumn(0,0, 40);
		$sheet->setColumn(0,1, 40);

		$criteriaVo= $this->Page->getViewState("criteriaVo");
		//titre du tableau
		$sheet->write(0, 0,Atexo_Utils_Util::toPfEncoding(Prado :: localize('NBR_RDV_RECUE')), $entete);

		$col =0;
		
		if($criteriaVo->getIdOrganisationAttache()){
			$sheet->write(3,$col++, Atexo_Utils_Util::toPfEncoding(Prado :: localize('ETABLISSEMENT')), $format);

		}else {
			$sheet->write(3,$col++, Atexo_Utils_Util::toPfEncoding(Prado :: localize('ORGANISATION')), $format);
		}
		$sheet->write(3,$col++, Atexo_Utils_Util::toPfEncoding(Prado :: localize('NOMBRE_RDV')), $format);
		$util = new Atexo_Utils_Util();

		$i=4;

		foreach ($results as $rec) {
			$col = 0;
			$sheet->writeString($i,$col++, $util->toPfEncoding($rec['DENOMINATION']),$corps_format);
			$sheet->writeString($i,$col++, $util->toPfEncoding($rec['NBR_RDV']),$corps_format);
			$i++;
		}
		$excel->send(Prado :: localize('NBR_RDV_RECUES_PAR_'.$libelle_par).'.xls');
		$excel->close();
		exit;

	}


	public function genererExcelEvolution($sender, $param)
	{
		require_once 'Spreadsheet/Excel/Writer.php';
		$results = Atexo_User_CurrentUser::readFromSession("dataEvolution");
		// Creer le fichier
		$criteriaVo= $this->Page->getViewState("criteriaVo");
		if($criteriaVo->getIdOrganisationAttache()){
			$par = "ETABLISSEMENT";

		}else {
			$par = "ORGANISATION";
		}
		$excel = new Spreadsheet_Excel_Writer();

		// Ajouter une feuille de calcul
		$sheet = &$excel->addWorksheet();
		$excel->setVersion(8);
		$sheet->setInputEncoding('utf-8');
		//Style des cellules du Titre
		$excel->setCustomColor(24, 204, 204, 255);
		$entete = &$excel->addFormat();
		$entete->setColor('black');
		$entete->setBold();
		$entete->setPattern(1);
		$entete->setFgColor(24);
		$entete->setAlign('center');
		$entete->setSize(12);
		//$entete->setBorder(1);
		$entete->setOutLine();
		$entete->setTextWrap();
		//$entete->setFontFamily('Courier');

		//Style des cellules d'entete
		$format = &$excel->addFormat();
		$format->setColor('#f1f1f1');
		$format->setBold(1);
		$format->setPattern(1);
		$format->setFgColor('gray');
		$format->setAlign('center');
		$format->setSize(10);
		$format->setBorder(1);
		$format->setOutLine();

		//Style des cellules
		$corps_format = &$excel->addFormat();
		$corps_format->setColor('black');
		$corps_format->setPattern(1);
		$corps_format->setFgColor(1);
		$corps_format->setSize(10);
		$corps_format->setBorder(1);
		$corps_format->setAlign('center');
		$corps_format->setTextWrap();

		// nbr r�clamation par organisme
		$criteriaVo= $this->Page->getViewState("criteriaVo");
		//titre du tableau
		$sheet->write(0, 0,Atexo_Utils_Util::toPfEncoding(Prado :: localize('NOMBRE_RDV')), $entete);
		//entete du tableau
		$col =0;
		$sheet->write(3,$col++, Atexo_Utils_Util::toPfEncoding(Prado :: localize($par)), $format);
		
		$util = new Atexo_Utils_Util();
		//la largeur des cellules
		$sheet->setColumn(0,0, 60);
		$k=0;
		$debInit = $deb = substr($util->frnDate2iso($criteriaVo->getDateDuCreation()),0,7);
		$fin = substr($util->frnDate2iso($criteriaVo->getDateAuCreation()),0,7);
		while($deb<=$fin) {
			$date = explode("-",$deb);
			$libelleDateDeb = Prado::localize("MONTH".((int)$date[1])).' '.$date[0];

			$sheet->write(3,$col++, $libelleDateDeb, $format);
			$sheet->setColumn(0,$k++, 15);
			$deb = $this->getMoisProchain($deb);

		}

		$sheet->write(3,$col++, Atexo_Utils_Util::toPfEncoding(Prado :: localize('NOMBRE_TOTAL')), $format);


		// recuperer les resultats de la recherche
		$i=4;
		foreach ($results as $rec) {
			$j = 0;
			$col = 0;
			$sheet->writeString($i,$col++, Atexo_Utils_Util::toPfEncoding($rec['DENOMINATION']),$corps_format);
			$deb = $debInit;
			$total = 0;
			while($deb<=$fin) {
				$sheet->write($i,$col++, (int)$rec['NBR_RDV'][$j],$corps_format);
				$total+=(int)$rec['NBR_RDV'][$j];
				$deb = $this->getMoisProchain($deb);
				$j++;
			}
			$sheet->write($i,$col, $total,$corps_format);
			$i++;
		}

		$excel->send(Prado :: localize('EVOLUTION_NBR_RECUES_PAR_'.$par).'.xls');
		$excel->close();
		exit;
	}
}