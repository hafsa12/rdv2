<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class ConfirmationRdv extends AtexoPage
{
	protected $dateDebCalendar;
	protected $dateFinCalendar;
	protected $zoneCode;
	protected $visibleRecapDetails = true;

	private function initRdv($typePrestation,$prestation,$rdv) {

		$tEtabQuery = new TEtablissementQuery();
		$etab = $tEtabQuery->getEtablissementById($rdv->getIdEtablissement());
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		$this->nomCitoyen->Text = $rdv->getTCitoyen()->getNom()." ".$rdv->getTCitoyen()->getPrenom();
		$this->nomCompletCitoyen->Value = $rdv->getTCitoyen()->getNom()." ".$rdv->getTCitoyen()->getPrenom();
		$this->identifiant->Text = $rdv->getTCitoyen()->getIdentifiant();
		$this->raisonSocial->Text = $rdv->getTCitoyen()->getRaisonSocial();
		$this->nomEtab->Text = $etab->getDenominationEtablissementTraduit($lang);
		$this->adresseEtab->Text = $etab->getAdresseCompleteEtablissement($lang);
		$this->telEtab->Text = $etab->getTelephoneRdv();
		$this->planAcces->initialize($etab);
		$this->typePrestation->Text = $typePrestation;
		$this->prestation->Text = $prestation;
		$this->codeRdv->Text = $rdv->getCodeRdv();
		$this->titreModal->Text = $rdv->getTCitoyen()->getNom()." ".$rdv->getTCitoyen()->getPrenom()." - ".$rdv->getDateRdv("H:i")." - ".$rdv->getDateFinRdv("H:i");
		$code=$rdv->getCodeRdv();// ."#". $rdv->getIdCitoyen() ."#". $rdv->getIdAgentRessource();
        $this->codeRoom->Value =hash('sha256',$code );
        ////NUM#ID_CITOYEN#ID_RESSOURCE
		$prestaForm = json_decode($rdv->getChampSuppPresta(),true);
		if($prestaForm[$lang]) {
			$this->champsSupp->Text = "<br>" . implode("<br>", $prestaForm[$lang]);
		}
		else {
			$this->champsSupp->Text = "";
		}

		$this->commentaireEtPiece->initialize($rdv->getTPrestation());

		$tParamForm = $rdv->getTPrestation()->getTParametreForm();
		$this->panelIdentifiant->Visible = false;
		if($tParamForm->getVisibleIdentifiant()=="1" && $rdv->getTCitoyen()->getIdentifiant()!="") {
			$this->panelIdentifiant->Visible = true;
		}
		$this->panelRaisonSocial->Visible = false;
		if($tParamForm->getVisibleRaisonSocial()=="1" && $rdv->getTCitoyen()->getRaisonSocial()!="") {
			$this->panelRaisonSocial->Visible = true;
		}

		$this->champ1->Text = ($tParamForm->getText1Actif()=="1") ? $tParamForm->getLibelleTextTraduit(1,$lang)." : <strong>".$rdv->getTCitoyen()->getText1()."</strong><br>":"";
		$this->champ2->Text = ($tParamForm->getText2Actif()=="1") ? $tParamForm->getLibelleTextTraduit(2,$lang)." : <strong>".$rdv->getTCitoyen()->getText2()."</strong><br>":"";
		$this->champ3->Text = ($tParamForm->getText3Actif()=="1") ? $tParamForm->getLibelleTextTraduit(3,$lang)." : <strong>".$rdv->getTCitoyen()->getText3()."</strong><br>":"";

		if($rdv->getTCitoyen()->getMail()!="") {
			$this->email->Text = $rdv->getTCitoyen()->getMail();
		}
		else {
			$this->panelEmail->Visible=false;
		}

		if($rdv->getIdAgentRessource()!=null && $rdv->getIdAgentRessource()!="") {
			if($rdv->getTPrestation()->getRessourceVisible()=="1" || Atexo_User_CurrentUser::isAdmin()) {
				$this->niveau3->Text = "<br>".Prado::localize("NIVEAU3")." : ";
				$tAgentQuery = new TAgentQuery();
				$tAgent = $tAgentQuery->getAgentById($rdv->getIdAgentRessource());
				if($_SESSION['typeRessource']) {
					$this->ressource->Text = $tAgent->getCodeUtilisateurTraduit($lang);
				}
				else {
					$this->ressource->Text = $tAgent->getNomPrenomUtilisateurTraduit($lang);
				}
			}
		}
	}
	
	public function initialize($typePrestation,$prestation,$rdv) {
        $visio = $rdv->getTPrestation()->getVisioconference();
        if($visio == 0){
            $this->btnVideo->Visible = false;
            $this->panelExplication->Visible = false;
        }else{
            $this->visibleRecapDetails = false;
        }


        $dateRdv = $rdv->getDateRdv("Y-m-d H:i:s");
        $this->dateRdvHidden->Value = $dateRdv;
        $now = date("Y-m-d H:i:s");
		$this->initRdv($typePrestation,$prestation,$rdv);
		$this->dateRdv->Text = ucfirst(Atexo_Utils_Util::getNomDate($rdv->getDateRdv("Y-m-d")))." ".Prado::localize('A')." ".$rdv->getDateRdv("H:i");
		if(in_array($rdv->getEtatRdv(), array(Atexo_Config::getParameter("ETAT_ANNULE"), Atexo_Config::getParameter("ETAT_ANNULE_ETAB")))) {
			$lang = Atexo_User_CurrentUser::readFromSession("lang");
			$this->motifAnnulation->Text = $rdv->getMotifAnnulationRdv($lang);
		}
		$this->statut->Text = $rdv->getLibelleEtatRdv();
		$this->labelConfirmCode->Text = Prado::localize('VOTRE_CODE_DE_CONFIRMATION_EST_LE')." ";
		$this->dateDebCalendar = $rdv->getDateRdv("d-m-Y")." ".$rdv->getDateRdv("H:i").":00";
		$this->dateFinCalendar = $rdv->getDateRdv("d-m-Y")." ".$rdv->getDateFinRdv("H:i").":00";
		if(Atexo_Config::getParameter('TIMEZONE')=='Africa/Casablanca') {
			$this->zoneCode = 34;
		}
		else {
			$this->zoneCode = 42;
		}
		
		if(!Atexo_User_CurrentUser::isAgent()||!Atexo_User_CurrentUser::isAdmin()) {
			$this->hidePanelReservation();
		}
		if(Atexo_User_CurrentUser::isAdmin()) {
			$this->panelAjoutAgenda->Visible = false;
			$this->panelExplication->Visible = false;
			$this->planAcces->Visible = false;
		}
	}

	public function initializeGrp($typePrestation,$prestation,$rdvs) {

		$this->initRdv($typePrestation,$prestation,$rdvs[0]);
		$this->labelConfirmCode->Text = Prado::localize('VOTRE_CODE_DE_CONFIRMATION_PAR_DATE_EST_LE');
		$this->dateRdv->Text = $this->codeRdv->Text = "";
		foreach($rdvs as $rdv) {
			$this->dateRdv->Text .= "<br>".Prado::localize('LE')." ".strtolower(Atexo_Utils_Util::getNomDate($rdv->getDateRdv("Y-m-d")))." ".Prado::localize('A')." ".$rdv->getDateRdv("H:i");
			$this->codeRdv->Text .= "<br>".$rdv->getCodeRdv()." ".Prado::localize('POUR_LE')." ".strtolower(Atexo_Utils_Util::getNomDate($rdv->getDateRdv("Y-m-d")))." ".Prado::localize('A')." ".$rdv->getDateRdv("H:i");
		}

		$this->panelAjoutAgenda->Visible = false;
		$this->panelExplication->Visible = false;
		$this->planAcces->Visible = false;
	}
	
	public function hidePanelEmail() {
		$this->panelEmail->Visible=false;
	}
	
	public function hidePanelConfirmation() {
		$this->panelConfirmation->Visible=false;
	}
	
	public function hidePanelReservation() {
		$this->panelReservation->Visible=false;
	}
	
	public function hidePanelBtn() {
		$this->panelBtn->Visible=false;
	}
	
	public function showPanelAnnulation() {
		$this->panelAnnulation->Visible=true;
	}

	public function showPanelStatut() {
		$this->panelStatut->Visible=true;
	}

	public function hideRetour() {
		$this->btnRetour->Visible=false;
	}
	
	public function getRetour() {
		if(Atexo_User_CurrentUser::isAdmin()) {
    		return "?page=administration.GestionRendezVous";
    	}
    	if(Atexo_User_CurrentUser::isAgentTeleOperateur()) {
    		return "?page=agent.AccueilAgentAuthentifie";
    	}
    	
    	return '?page=citoyen.Accueil';
	}

	public function setVisibleRecapDetails($value){
	    $this->visibleRecapDetails = $value;
    }

    public function loadPjPanel($rdv){
        $lang = Atexo_User_CurrentUser::readFromSession("lang");
        if($rdv){
            $tPrestation = $rdv->getTPrestation();
            if($_SESSION['typePrestation'] == Atexo_Config::getParameter("PRESTATION_REFERENTIEL") && $tPrestation->getTParametragePrestation()) {
                $data = $tPrestation->getTParametragePrestation()->getTPieceParamPrestas();
            }
            else {
                $data = $tPrestation->getTPiecePrestations();
            }

            $dataPj = array();
            $i=0;
            $show = false;
            foreach($data as $pj) {
                if($pj->getUpload() == 2){
                    $dataPj[$i]["libelle"]=$pj->getLibelleTraduit($lang);
                    $dataPj[$i]["idBlobPiece"]=$pj->getIdBlobPiece();
                    $dataPj[$i]["uploadCitoyen"]=$pj->getUpload();
                    $i++;
                }
            }
            $today = date("Y-m-d");
            $date = explode(' ', $rdv->getDateRdv())[0];

            $tBlobRdvQ = new TBlobRdvQuery();
            $totalBlobsUploaded = $tBlobRdvQ->findByIdRendezVous($rdv->getIdRendezVous());
            if(count($totalBlobsUploaded) < $i && $date == $today){
                $show = true;
            }
            if($i>0 && $show){
                $this->panelPj->Visible = true;
                $this->btnSavePj->Visible = true;
            }
			
            $this->listePj->DataSource = $dataPj;
            $this->listePj->DataBind();
            $this->commentaireEtPiece->Visible = false;
        }

    }

    public function savePjs(){
        $rdv = $this->getViewState('rdv');
        $i=0;
        $numberOfPjs = count($this->listePj->getItems());
        try{
            foreach ($this->listePj->getItems() as $item) {
                if($item->pj->HasFile && $rdv) {
                    $tBlob = new TBlob();
                    $tBlob->setNomBlob($item->blobName->Text.".".end(explode(".", $item->pj->FileName)));
                    $tBlob->save();

                    $tBlobRdv = new TBlobRdv();
                    $tBlobRdv->setTBlob($tBlob);
                    $tBlobRdv->setTRendezVous($rdv);

                    $tBlobRdv->save();

                    Atexo_Utils_Util::mvFile($item->pj->LocalName, Atexo_Config::getParameter("PATH_FILE"), $tBlobRdv->getIdBlob());
                    $i++;
                }
            }
        }catch(Exception $e){
            echo $e->getMessage();
        }


        if($i == $numberOfPjs){
            $this->panelSauvegardePjs->Visible = true;
            $this->panelPj->Visible = false;
            $this->btnSavePj->Visible = false;
        }else{
            $this->panelErreurSauvegardePjs->Visible = true;
            $this->panelPj->Visible = true;
            $this->btnSavePj->Visible = true;
        }
        $this->commentaireEtPiece->Visible = false;
        $this->visibleRecapDetails = false;
        $this->panelAjoutAgenda->Visible = false;
    }

    public function downloadPieceJointe($sender) {
        $idFichier = $sender->CommandParameter;
        Atexo_DownloadFile::downloadFiles($idFichier);
    }

}
