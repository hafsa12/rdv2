<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
 
 class AtexoValidationSummary extends TTemplateControl
 {
    private $_validationGroup; 
    private $_idDivValidationSummary ='divValidationSummary';
    protected $classButtonValider ="btnValider";
    protected $classButtonEnCours ="btnEnCours";
    
    public function setValidationGroup($value)
    {
        $this->_validationGroup = $value;
        $this->ensureChildControls();
        $this->validationSummary->setValidationGroup($this->_validationGroup);
    }
    public function getValidationGroup()
    {
        return $this->_validationGroup;
    }
 	public function setIdDivValidationSummary($value)
    {
        $this->_idDivValidationSummary = $value;
    }
    public function getIdDivValidationSummary()
    {
        return $this->_idDivValidationSummary;
    }
    
    public function setClassButtonValider($classButtonValider)
    {
    	$this->classButtonValider = $classButtonValider;
    }
 	public function getClassButtonValider()
    {
    	return $this->classButtonValider;
    }
    
 	public function setClassButtonEnCours($classButtonEnCours)
    {
    	$this->classButtonEnCours = $classButtonEnCours;
    }
 	public function getClassButtonEnCours()
    {
    	return $this->classButtonEnCours;
    }
    
    public function onLoad()
 	{   
 		$this->validationSummary->setValidationGroup($this->_validationGroup);
 	}
 	
 }