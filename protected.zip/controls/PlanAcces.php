<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class PlanAcces extends AtexoPage
{
	public $latitude;
	public $longitude;
	public $idFichier=0;
	
    public function initialize($etab) {
    	$this->latitude = $etab->getLatitudeEtablissement();
		$this->longitude = $etab->getLongitudeEtablissement();
		$this->idFichier = $etab->getIdBlobPlan();
    }
    
	public function downloadPlanAcces($sender) {
		$idFichier = $sender->CommandParameter;
		Atexo_DownloadFile::downloadFiles($idFichier);
	}
}