<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class MenuAgent extends TTemplateControl
{
	public $_lang = "";

	public function onLoad() {

		$this->_lang = Atexo_User_CurrentUser::readFromSession("lang");
		$idAgent = Atexo_User_CurrentUser::getIdAgentConnected();
		$agent = Atexo_Agent_Gestion::retrieveAgent($idAgent);
		if($agent) {
			$this->nomPrenomAgent->Text = $agent->getNomPrenomUtilisateurTraduit($this->_lang);
		}
	}

	public function Disconnect()
	{
		if(strcmp(substr($_GET['page'], 0, 15), 'administration.') == 0)
		{
			$this->getApplication()->getModule("auth")->logout();
			$this->response->redirect("?page=administration.AdministrationAccueil");
		}
		else
		{
			$this->getApplication()->getModule("auth")->logout();
			$this->response->redirect("?page=agent.AgentAccueil");
		}

	}

	public function getLang() {
		return $this->_lang;
	}

	public function setLang($value) {
		return $this->_lang = $value ;
	}

}
