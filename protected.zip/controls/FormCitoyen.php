<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class FormCitoyen extends AtexoPage
{
	protected $visibleRecapDetails = true;
	public $lang;
	public $dataPj;

	public function initCitoyen() {
		$tabInfoCitoyen = Atexo_User_CurrentUser::readFromSession('infoRequerant');
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		if(is_array($tabInfoCitoyen) && count($tabInfoCitoyen)){

			$temp = "";
			if($lang == "ar"){
				$temp = "_ar";
			}

            $this->identifiant->text = $tabInfoCitoyen['identifiant'.$temp];
			$this->nom->text = $tabInfoCitoyen['nom'.$temp];
			$this->prenom->text = $tabInfoCitoyen['prenom'.$temp];
			$this->adresse->text = $tabInfoCitoyen['adresse'.$temp]."\n".$tabInfoCitoyen['adresse2'.$temp]."\n".$tabInfoCitoyen['code_postal']."\n".$tabInfoCitoyen['libelle_pays'.$temp]." - ".$tabInfoCitoyen['code_pays'];
			$this->email->text = $tabInfoCitoyen['email'];
			$this->telephone->text = $tabInfoCitoyen['telephone'];
			$this->raisonSocial->text = $tabInfoCitoyen['raison_sociale'.$temp];
			$this->fax->text = $tabInfoCitoyen['fax'];
			return $tabInfoCitoyen['modifiable'];
		}
		return true;
	}

	public function initialize($idEtab,$idPrestation,$idRessource,$typePrestation,$prestation,$dateRdv, $heureRdv,$heureFin, $prestaForm) {

		$this->repeaterRdvGroupe->DataSource = array();
		$this->repeaterRdvGroupe->DataBind();

		$tPrestationQuery = new TPrestationQuery();
		$tPrestation = $tPrestationQuery->getPrestationById($idPrestation);
		$lang = Atexo_User_CurrentUser::readFromSession("lang");
        if($tPrestation->getVisioconference() == 1){
            $this->visibleRecapDetails = false;
        }
		$this->_initRecapitulatif ($idEtab, $typePrestation, $prestation, $tPrestation, $prestaForm, $lang);

		if($idRessource!=null && $idRessource!="") {
			if($tPrestation->getRessourceVisible()=="1" || Atexo_User_CurrentUser::isAdmin()) {
				$this->niveau3->Text = "<br>".Prado::localize("NIVEAU3")." : ";
				$tAgentQuery = new TAgentQuery();
				$tAgent = $tAgentQuery->getAgentById($idRessource);
				if($_SESSION['typeRessource']) {
					$this->ressource->Text = $tAgent->getCodeUtilisateurTraduit($lang);
				}
				else {
					$this->ressource->Text = $tAgent->getNomPrenomUtilisateurTraduit($lang);
				}
			}
		}
		
		$this->dateRdv->Text = ucfirst(Atexo_Utils_Util::getNomDate($dateRdv))." ".Prado::localize('A')." ".$heureRdv;
		$this->setViewState("dateRdv",$dateRdv);
		$this->setViewState("heureRdv",$heureRdv);
		$this->setViewState("heureFin",$heureFin);
		$this->setViewState("idPrestation",$idPrestation);
		$this->setViewState("idRessource",$idRessource);
		$this->setViewState("idEtab",$idEtab);

		$modifiable = $this->initCitoyen();

		$this->initializeForm($idPrestation, ($modifiable == 'true'));
		if(Atexo_User_CurrentUser::isAdmin()) {
			$this->planAcces->Visible = false;
		}
		if($this->Page->gestionRdv->unEtab->Value == 'true'){
			$this->visibleRecapDetails = false;
		}
	}

	public function initializeGrp($idEtab,$idPrestation,$typePrestation,$prestation,$listeRdvGrp, $prestaForm) {

		$tPrestationQuery = new TPrestationQuery();
		$tPrestation = $tPrestationQuery->getPrestationById($idPrestation);
		$lang = Atexo_User_CurrentUser::readFromSession("lang");

		$this->_initRecapitulatif ($idEtab, $typePrestation, $prestation, $tPrestation, $prestaForm, $lang);

		if($listeRdvGrp[0]["idRessource"]!=null && $listeRdvGrp[0]["idRessource"]!="") {
			if($tPrestation->getRessourceVisible()=="1" || Atexo_User_CurrentUser::isAdmin()) {
				$this->niveau3->Text = "<br>".Prado::localize("NIVEAU3")." : ";
				$tAgentQuery = new TAgentQuery();
				$tAgent = $tAgentQuery->getAgentById($listeRdvGrp[0]["idRessource"]);
				if($_SESSION['typeRessource']) {
					$this->ressource->Text = $tAgent->getCodeUtilisateurTraduit($lang);
				}
				else {
					$this->ressource->Text = $tAgent->getNomPrenomUtilisateurTraduit($lang);
				}
			}
		}
		$this->dateRdv->Text = "";

		$this->repeaterRdvGroupe->DataSource = $listeRdvGrp;
		$this->repeaterRdvGroupe->DataBind();

		$this->setViewState("idPrestation",$idPrestation);
		$this->setViewState("idEtab",$idEtab);
		$this->setViewState("listeRdvGrp",$listeRdvGrp);

		$this->initCitoyen();

		$this->initializeForm($idPrestation);
		if(Atexo_User_CurrentUser::isAdmin()) {
			$this->planAcces->Visible = false;
		}
	}

	public function initializeForm($idPrestation, $modifiable = true) {
		$tParametreFormQuery = new TParametreFormQuery();
		$tParamForm = $tParametreFormQuery->getParametreFormByIdPrestation($idPrestation);

		$lang = Atexo_User_CurrentUser::readFromSession("lang");
		
		if($tParamForm instanceof TParametreForm) {
			
			$this->panelNom->Visible = ($tParamForm->getVisibleNom()=="1" && $modifiable);
			$this->panelPrenom->Visible = ($tParamForm->getVisiblePrenom()=="1" && $modifiable);
			$this->panelNaissance->Visible = ($tParamForm->getVisibleDateNaissance()=="1" && $modifiable);
			$this->panelIdentifiant->Visible = ($tParamForm->getVisibleIdentifiant()=="1" && $modifiable);
			$this->panelRaisonSocial->Visible = ($tParamForm->getVisibleRaisonSocial()=="1" && $modifiable);
			$this->panelAdresse->Visible = ($tParamForm->getVisibleAdresse()=="1" && $modifiable);
			$this->panelFax->Visible = ($tParamForm->getVisibleFax()=="1" && $modifiable);
			$this->panelTelephone->Visible = ($tParamForm->getVisibleTelephone()=="1" && $modifiable);
			$this->emailOrTelValidatorTel->Enabled = $this->panelTelephone->Visible;
			$this->panelEmail->Visible = ($tParamForm->getVisibleEmail()=="1" && $modifiable);
			$this->emailOrTelValidatorEmail->Enabled = $this->panelEmail->Visible;
			
			$this->nomValidator->Visible = ($tParamForm->getObligatoireNom()=="1");
			$this->prenomValidator->Visible = ($tParamForm->getObligatoirePrenom()=="1");
			$this->naissanceValidator->Visible = ($tParamForm->getObligatoireDateNaissance()=="1");
			$this->naissanceCompareValidator->Visible = ($tParamForm->getObligatoireDateNaissance()=="1");
			$this->identifiantValidator->Visible = ($tParamForm->getObligatoireIdentifiant()=="1");
			$this->raisonSocialValidator->Visible = ($tParamForm->getObligatoireRaisonSocial()=="1");
			$this->adresseValidator->Visible = ($tParamForm->getObligatoireAdresse()=="1");
			$this->faxValidator->Visible = ($tParamForm->getObligatoireFax()=="1");
			if($tParamForm->getObligatoireEmail()=="1"){
					 $this->labelEmail->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoireTelephone()=="1"){
					 $this->labelTelephone->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoireFax()=="1"){
					 $this->labelFax->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoireAdresse()=="1"){
					 $this->labelAdresse->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoireRaisonSocial()=="1"){
					 $this->labelRaisonSocial->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoireNom()=="1"){
					 $this->labelNom->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoirePrenom()=="1"){
					 $this->labelPrenom->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoireDateNaissance()=="1"){
					 $this->labelNaissance->Text .= '<i class="required">*</i>';
			}
			if($tParamForm->getObligatoireIdentifiant()=="1"){
					 $this->labelIdentifiant->Text .= '<i class="required">*</i>';
			}
			$this->emailValidator->Visible = ($tParamForm->getObligatoireEmail()=="1" && !$this->Page->Master->isCalledFromAdmin());
			$this->telephoneValidator->Visible = ($tParamForm->getObligatoireTelephone()=="1");// && !$this->Page->Master->isCalledFromAdmin());
			
			if($tParamForm->getObligatoireTelephone()=="1" || $tParamForm->getObligatoireEmail()=="1" || $this->Page->Master->isCalledFromAdmin()) {
				$this->emailOrTelValidatorEmail->Visible = false;
				$this->emailOrTelValidatorTel->Visible = false;
			}
			if($tParamForm->getText1Actif()=="1") {
			    if($modifiable){
                    $this->panelText1->Visible = true;
                }
				$this->labelText1->Text = $tParamForm->getLibelleTextTraduit(1,$lang);
				if($tParamForm->getObligatoireText1()=="1"){
					 $this->labelText1->Text .= ' <i class="required">*</i>';
				}
				$this->text1Validator->Visible = ($tParamForm->getObligatoireText1()=="1");
			}
			if($tParamForm->getText2Actif()=="1") {
                if($modifiable){
                    $this->panelText2->Visible = true;
                }
				$this->labelText2->Text = $tParamForm->getLibelleTextTraduit(2,$lang);
				if($tParamForm->getObligatoireText2()=="1"){
					 $this->labelText2->Text .= ' <i class="required">*</i>';
				}
				$this->text2Validator->Visible = ($tParamForm->getObligatoireText2()=="1");
			}
			if($tParamForm->getText3Actif()=="1") {
                if($modifiable){
                    $this->panelText3->Visible = true;
                }
				$this->labelText3->Text = $tParamForm->getLibelleTextTraduit(3,$lang);
				if($tParamForm->getObligatoireText3()=="1"){
					 $this->labelText3->Text .= ' <i class="required">*</i>';
				}
				$this->text3Validator->Visible = ($tParamForm->getObligatoireText3()=="1");
			}
		}
	}

	private function _initRecapitulatif ($idEtab, $typePrestation, $prestation, $tPrestation, $prestaForm, $lang) {
		$tEtabQuery = new TEtablissementQuery();
		$this->lang = Atexo_User_CurrentUser::readFromSession("lang");
		$etab = $tEtabQuery->getEtablissementById($idEtab);
		$this->nomEtab->Text = $etab->getDenominationEtablissementTraduit($lang);
		$this->adresseEtab->Text = $etab->getAdresseCompleteEtablissement($lang);
		$this->telEtab->Text = $etab->getTelephoneRdv();
		$this->planAcces->initialize($etab);
		$this->typePrestation->Text = $typePrestation;
		$this->prestation->Text = $prestation;
		$this->commentaireEtPiece->initialize($tPrestation);

		if($_SESSION['typePrestation'] == Atexo_Config::getParameter("PRESTATION_REFERENTIEL") && $tPrestation->getTParametragePrestation()) {
			$data = $tPrestation->getTParametragePrestation()->getTPieceParamPrestas();
		}
		else {
			$data = $tPrestation->getTPiecePrestations();
		}
		$dataPj = array();
		$i=0;
		foreach($data as $pj) {
			if($pj->getUpload() == 1){
				$dataPj[$i]["libelle"]=$pj->getLibelleTraduit($this->lang);
				$dataPj[$i]["idPiece"]=$pj->getIdPieceParamPresta();
				$dataPj[$i]["uploadCitoyen"]=$pj->getUpload();
				$i++;
			}
		}
		$this->dataPj = $dataPj;
		$this->listePj->DataSource = $dataPj;
		$this->listePj->DataBind();


		if($prestaForm[$lang]) {
			$this->champsSupp->Text = "<br>" . implode("<br>", $prestaForm[$lang]);
		}
		else {
			$this->champsSupp->Text = "";
		}
	}

	public function setRdv(TRendezVous $rdv) {
		$this->nom->Text = $rdv->getTCitoyen()->getNom();
		$this->prenom->Text = $rdv->getTCitoyen()->getPrenom();
		$this->naissance->Date = $rdv->getTCitoyen()->getDateNaissance("d/m/Y");
		$this->adresse->Text = $rdv->getTCitoyen()->getAdresse();
		$this->email->Text = $rdv->getTCitoyen()->getMail();
		$this->telephone->Text = $rdv->getTCitoyen()->getTelephone();
		$this->fax->Text = $rdv->getTCitoyen()->getFax();
		$this->identifiant->Text = $rdv->getTCitoyen()->getIdentifiant();
		$this->raisonSocial->Text = $rdv->getTCitoyen()->getRaisonSocial();
		$this->text1->Text = $rdv->getTCitoyen()->getText1();
		$this->text2->Text = $rdv->getTCitoyen()->getText2();
		$this->text3->Text = $rdv->getTCitoyen()->getText3();
	}

	public function getRdv() {

		$dateRdv = $this->getViewState("dateRdv");
		$heureDeb = $this->getViewState("heureRdv");
		$heureFin = $this->getViewState("heureFin");

		$heuresDeb = explode("-",$heureDeb);
		$heuresFin = explode("-",$heureFin);
		
		$heureDeb = $heuresDeb[0];
		$heureFin = $heuresFin[0];
		
		$idPrestation = $this->getViewState("idPrestation");
		$idEtab = $this->getViewState("idEtab");

		$citoyen = new TCitoyen();

		$citoyen->setRaisonSocial(strip_tags ($this->raisonSocial->SafeText));
		$citoyen->setNom(strip_tags(htmlspecialchars($this->nom->SafeText)));
		$citoyen->setPrenom(strip_tags (htmlspecialchars($this->prenom->SafeText)));
		$citoyen->setDateNaissance(Atexo_Utils_Util::frnDate2iso($this->naissance->Date));
		$citoyen->setAdresse(strip_tags ($this->adresse->SafeText));
		$citoyen->setMail(strip_tags ($this->email->SafeText));
		$citoyen->setTelephone(Atexo_Utils_Util::formatTel(strip_tags ($this->telephone->SafeText)));
		$citoyen->setFax(strip_tags ($this->fax->SafeText));
		$citoyen->setIdentifiant(strip_tags ($this->identifiant->SafeText));
		$citoyen->setText1(strip_tags ($this->text1->SafeText));
		$citoyen->setText2(strip_tags ($this->text2->SafeText));
		$citoyen->setText3(strip_tags ($this->text3->SafeText));

		$rdv = new TRendezVous();
		$rdv->setIdPrestation($idPrestation);
		$rdv->setIdEtablissement($idEtab);
		$rdv->setDateCreation(date("Y-m-d H:i:s"));
		$rdv->setDateRdv($dateRdv." ".$heureDeb.":00");
		$rdv->setDateFinRdv($dateRdv." ".$heureFin.":00");
		$rdv->setCodeRdv(Atexo_Utils_Util::random(Atexo_Config::getParameter("TAILLE_CODE_RDV")));

		if(Atexo_User_CurrentUser::isAdmin()) {
			if($this->priseTel->Checked) {
				$rdv->setModePriseRdv(Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_TELEPHONE"));
			}
			else {
				$rdv->setModePriseRdv(Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_SURPLACE"));
			}
			$rdv->setIdAgentAccueil(Atexo_User_CurrentUser::getIdAgent());
		}
		else {
			$mobile = new Mobile();
			
			if($mobile->isMobile() || $mobile->isTablet()) {
				if($mobile->isAppliMobile(Atexo_Config::getParameter("NOM_APPLI_MOBILE"))) {
					$rdv->setTypePriseRdv(Atexo_Config::getParameter("TYPE_APPLI_MOBILE"));
				}
				else {
					$rdv->setTypePriseRdv(Atexo_Config::getParameter("TYPE_INTERNET_MOBILE"));
				}
			}
			else {
				$rdv->setTypePriseRdv(Atexo_Config::getParameter("TYPE_INTERNET_DESKTOP"));
			}
		}
		/*elseif(Atexo_User_CurrentUser::isAgentTeleOperateur()) {
			if($this->priseTel->Checked) {
				$rdv->setModePriseRdv(Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_TELEPHONE"));
			}
			else {
				$rdv->setModePriseRdv(Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_SURPLACE"));
			}
			$rdv->setIdAgentTeleOperateur(Atexo_User_CurrentUser::getIdAgent());
		}*/

		$rdv->setTCitoyen($citoyen);
		return $rdv;
	}

	public function getRdvGrp() {

		$listeRdvGrp = $this->getViewState("listeRdvGrp");

		$idPrestation = $this->getViewState("idPrestation");
		$idEtab = $this->getViewState("idEtab");

		$citoyen = new TCitoyen();

		$citoyen->setRaisonSocial($this->raisonSocial->SafeText);
		$citoyen->setNom($this->nom->SafeText);
		$citoyen->setPrenom($this->prenom->SafeText);
		$citoyen->setDateNaissance(Atexo_Utils_Util::frnDate2iso($this->naissance->Date));
		$citoyen->setAdresse($this->adresse->SafeText);
		$citoyen->setMail($this->email->SafeText);
		$citoyen->setTelephone(Atexo_Utils_Util::formatTel($this->telephone->SafeText));
		$citoyen->setFax($this->fax->SafeText);
		$citoyen->setIdentifiant($this->identifiant->SafeText);
		$citoyen->setText1($this->text1->SafeText);
		$citoyen->setText2($this->text2->SafeText);
		$citoyen->setText3($this->text3->SafeText);
		$citoyen->save();

		$rdvs = array();
		$i=0;
		foreach($listeRdvGrp as $oneRdv) {

			$rdv = new TRendezVous();
			$rdv->setIdPrestation($idPrestation);
			$rdv->setIdEtablissement($idEtab);
			$rdv->setDateCreation(date("Y-m-d H:i:s"));
			$item = $this->repeaterRdvGroupe->Items[$i++];

			$rdv->setDateRdv($oneRdv["dateIso"] . " " . $item->listeHeures->getSelectedValue() . ":00");
			$fin = explode('-',$oneRdv['listeHeures'][$item->listeHeures->getSelectedValue()]["heureFin"]);

			$rdv->setDateFinRdv($oneRdv["dateIso"] . " " . $fin[0] . ":00");

			if ($this->priseTel->Checked) {
				$rdv->setModePriseRdv(Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_TELEPHONE"));
			} else {
				$rdv->setModePriseRdv(Atexo_Config::getParameter("MODE_AGENT_TELEOPERATEUR_SURPLACE"));
			}
			$rdv->setIdAgentAccueil(Atexo_User_CurrentUser::getIdAgent());

			$rdv->setTCitoyen($citoyen);
			$rdvs[] = $rdv;
		}
		return $rdvs;
	}
	
	protected function suggestNames($sender,$param) {
        // Get the token
        $token=$param->getToken();
        // Sender is the Suggestions repeater
        $tCitoyenPeer = new TCitoyenPeer();
        $sender->DataSource=$tCitoyenPeer->getCitoyenByMotsCle($token);
        $sender->dataBind();
    }
    
	public function suggestionSelected($sender,$param) {
		if(count($sender->Suggestions->DataKeys)>$param->selectedIndex) {
			$idCitoyen = $sender->Suggestions->DataKeys[$param->selectedIndex];
			$this->loadFromCitoyen($idCitoyen);
		}
		$this->panelFormCitoyen->render($param->getNewWriter());
	}
	
	public function loadFromCitoyen($idCitoyen) {
		$tCitoyenQuery = new TCitoyenQuery();
		$citoyen = $tCitoyenQuery->getCitoyenById($idCitoyen);
		
		$this->raisonSocial->Text = $citoyen->getRaisonSocial();
		$this->nom->Text = $citoyen->getNom();
		$this->prenom->Text = $citoyen->getPrenom();
		$this->naissance->Date = $citoyen->getDateNaissance("d/m/Y");
		$this->adresse->Text = $citoyen->getAdresse();
		$this->email->Text= $citoyen->getMail();
		$this->telephone->Text = $citoyen->getTelephone();
		$this->fax->Text = $citoyen->getFax();
		$this->identifiant->Text = $citoyen->getIdentifiant();
		/*$this->text1->Text = $citoyen->getText1();
		$this->text2->Text = $citoyen->getText2();
		$this->text3->Text = $citoyen->getText3();*/
	}
}
