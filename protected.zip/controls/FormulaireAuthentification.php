<?php
/**
 * description de la classe
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class FormulaireAuthentification extends TTemplateControl {

	public function onLoad()
	{
		if(!$this->Page->isPostBack) {
				
			if (Atexo_User_CurrentUser::isConnected())  {
				$this->getApplication()->getModule("auth")->logout();
				$this->response->redirect("?".$_SERVER['QUERY_STRING']);
			}
		}
	}

	/**
	 * fonction de verification d'authentification
	 * Enter description here ...
	 */
	public function VerifyAuthLogin()
	{
		$login = Atexo_Utils_Util::atexoHtmlEntities($this->identifiant->getText());
		$pwd = sha1(Atexo_Utils_Util::atexoHtmlEntities($this->password->getText()));
			
		$compteVo = new Atexo_User_CompteVo();
		$compteVo->setLogin($login);
		$compteVo->setPassword($pwd);
			
		if ($login && $pwd){
			if ($this->getApplication()->getModule("auth")->login($compteVo, null)) {
				$idAgent = Atexo_User_CurrentUser::getIdAgentConnected();
				$agent = Atexo_Agent_Gestion::retrieveAgent($idAgent);
				if($agent instanceof TAgent){
					/*if ($_GET['goto']){
						$this->response->redirect($this->getUrlGoto());
					}
					else {*/
						$this->redirectAgent($agent);
						return;
					//}
				}
				/*if ($_GET['goto']){
					$this->response->redirect($this->getUrlGoto());
					return;
				} else {*/
					$langueEnSession = Atexo_User_CurrentUser::readFromSession("lang");
					if ($langueEnSession == '' || !isset($langueEnSession) ) {
						Atexo_User_CurrentUser::writeToSession('lang', 'fr');
					//}
				}
			}
			else {
				$this->erreurMessage->remplirMessage(true, prado::localize('TEXT_COMPTE_ERRONNE'));
			}
		}
	}

	public function getUrlGoto() {
		$goto = urldecode($_GET['goto']);
		foreach($_GET as $param=>$value) {
			if($param!="page" && $param!="goto") {
				$goto .= "&".$param."=".$value;
			}
		}
		return $goto;
	}
	
	public function redirectAgent($agent) {
		if($this->isAdmin($agent) && $this->Page->Master->getCalledFrom()=="admin"){//Admin
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		elseif ($this->isAdmin($agent) && $this->Page->Master->getCalledFrom()=="agent"){//Agent
			$this->response->redirect("?page=administration.AccueilAdministrateurAuthentifie");
		}
		elseif ($this->isAdmin($agent) && $this->Page->Master->getCalledFrom()!="admin"){//Admin
			$this->response->redirect("?".$_SERVER['QUERY_STRING']);
		}
		elseif ($this->isAgent($agent) && $this->Page->Master->getCalledFrom()=="agent"){//Agent
			$this->response->redirect("?page=agent.AccueilAgentAuthentifie");
		}
        elseif ($this->isRessource($agent)/* && $this->Page->Master->getCalledFrom()=="ressource"*/){//Agent
            $this->response->redirect("?page=ressource.AccueilRessourceAuthentifie");
        }
		elseif ($this->isAgent($agent) && $this->Page->Master->getCalledFrom()!="agent"){//Agent
			$this->response->redirect("?".$_SERVER['QUERY_STRING']);
		}
		else {
			$this->response->redirect("?".$_SERVER['QUERY_STRING']);
		}
	}

	/**
	 * tester si un administrateur
	 * Enter description here ...
	 * @param unknown_type $user
	 */
	public function isAdmin($user) {
		if($user->getTProfil()->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_ADMIN_SYSTEM") 
			|| $user->getTProfil()->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ORGANISATION") 
			|| $user->getTProfil()->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_ADMIN_ETABLISSSEMENT") 
			|| $user->getTProfil()->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_AGENT")) {
			return true;
		} 
		return false;
	}

	/**
	 * tester si un agent
	 * Enter description here ...
	 * @param unknown_type $user
	 */
	public function isAgent($user) {
		if($user->getTProfil()->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_AGENT_TO") 
			|| $user->getTProfil()->getIdTypeProfil() == Atexo_Config::getParameter("ID_PROFIL_AGENT_ACCUEIL") ) {
			return true;
		} 
		return false;
	}
    public function isRessource($user) {
        if($user->getTProfil()->getIdTypeProfil() == 7 ) {
            return true;
        }
        return false;
    }
}
