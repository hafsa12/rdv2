<?php
/**
 * description de la calsse
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 0.0
 * @since Atexo.Rdv
 * @package atexo
 * @subpackage atexo
 */
class JitsiModal extends AtexoPage
{
public function onLoad($param)
{
    if(!$this->Page->Master->isCalledFromAdmin()) {
        $this->script->Text="<script>J('#sidePanelBtn').css({'display':'none'});</script>";
    }
}

}