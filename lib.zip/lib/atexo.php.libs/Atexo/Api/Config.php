<?php

/**
 * Gestion de la configuration.
 *
 * Cette classe permet d'accéder aux directives de configuration
 * n'importe ou dans le code ainsi que de gérer la génération du
 * fichier de configuration application.xml en tenant compte de
 * la configuration spécifique de l'application en cours.
 *
 * @author Guillaume Ponéon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage config
 */
class Api_Config
{

    // Chemin vers les fichiers de configuration (à partir de la racine du site)
    const CONFIG_MPE_FILE      = '/protected/config/application.xml.php';
    const CONFIG_SPE_FILE      = '/../config/application.php';
    const CONFIG_GEN_FILE      = '/protected/application.xml';
    const CONFIG_CACHE_DIR     = '/protected/var/cache';
    const CONFIG_CACHE_FILE    = '/config_application.php';

    // Modes de fonctionnement de Prado
    const APP_MODE_DEBUG       = 'Debug';
    const APP_MODE_NORMAL      = 'Normal';
    const APP_MODE_PERFORMANCE = 'Performance';

    // Valeurs de configuration variables
    private static $namespaces = array();
    private static $appMode    = self::APP_MODE_DEBUG;
    private static $parameters = array();

    /**
     * Contenu du fichier de configuration
     *
     * @var SimpleXMLElement
     */
    private static $application = null;

    /**
     * Initialise le fichier de configuration
     *
     * @todo accés direct au fichier XML, retrait du chargement des paramétres
     */
    private static function init($rootPath)
    {
        static $initialized = false;

        if ($initialized === false) {
            $configGenFile = $rootPath . self::CONFIG_GEN_FILE;
            if (file_exists($configGenFile)) {
                self::$application = simplexml_load_file($configGenFile);
                self::loadParameters($rootPath);
            }
            $initialized = true;
        }
    }
    
     /**
     * Vider tous les parametres
     */
    public static function resetParameters() {
        self::$parameters = null;
        self::$parameters = array();
    }
    

    /**
     * Chargement des paramétres de configuration.
     *
     * Chargement depuis le fichier application.xml avec mise en cache,
     * ou extraction des paramétres depuis le fichier de cache.
     *
     * @return boolean
     */
    private static function loadParameters($rootPath)
    {
        if (self::$application === null) {
            throw new Exception('You must initialize before loading parameters.');
        }
        $cacheDir = $rootPath . self::CONFIG_CACHE_DIR;
        if (!is_dir($cacheDir)) {
            if (!mkdir($cacheDir)) {
                trigger_error('Unable to create cache directory.', E_USER_NOTICE);
                return false;
            }
            chmod($cacheDir, 0777);
        }
        $cacheFile = $cacheDir . self::CONFIG_CACHE_FILE;
        if (file_exists($cacheFile)) {
            self::$parameters = unserialize(file_get_contents($cacheFile));
        } else {
            foreach (self::$application->parameters->parameter as $parameter) {
                self::$parameters[(string) $parameter['id']] = (string) $parameter['value'];
            }
            file_put_contents($cacheFile, serialize(self::$parameters));
        }
        return true;
    }

    /**
     * Génération du fichier de configuration application.xml à partir
     * des fichiers /config/application.php et /mpe/protected/config/application.xml.php
     *
     * @return boolean
     */
    public static function buildApplicationXmlFile($rootPath)
    {
        $speFile = $rootPath . self::CONFIG_SPE_FILE;
        $mpeFile = $rootPath . self::CONFIG_MPE_FILE;
        $genFile = $rootPath . self::CONFIG_GEN_FILE;

        if(is_file($speFile)) {
        $speFileSyntaxOk = (boolean) token_get_all(file_get_contents($speFile));
        if (!$speFileSyntaxOk) {
            throw new Exception($speFileSyntaxOk . ' file : syntax error.');
        }
        }
        $mpeFileSyntaxOk = (boolean) token_get_all(file_get_contents($mpeFile));
        if (!$mpeFileSyntaxOk) {
            throw new Exception($mpeFileSyntaxOk . ' file : syntax error.');
        }
        if(is_file($genFile)) {
        	unlink($genFile);
        }
        ob_start();
        if(is_file($speFile)){
        	include $speFile;        
        }
        include $mpeFile;
        $content = ob_get_clean();

        if (simplexml_load_string($content) === false) {
            throw new Exception('Application XML file syntax not correct.');
        }

        // Suppression du cache des paramétres
        $cacheFile = $rootPath . self::CONFIG_CACHE_DIR . self::CONFIG_CACHE_FILE;
        if (file_exists($cacheFile)) {
            unlink($cacheFile);
        }

        // Ecriture du fichier de configuration
        return (boolean) file_put_contents($genFile, $content);
    }

    // Accesseurs

    /**
     * Retourne la liste des espaces de noms
     *
     * Note : utilisable uniquement pour la génération du fichier de configuration !
     *
     * @return array
     */
    public static function getNameSpaces()
    {
        return self::$namespaces;
    }

    /**
     * Retourne le nombre d'espaces de noms
     *
     * Note : utilisable uniquement pour la génération du fichier de configuration !
     *
     * @return integer
     */
    public static function getNameSpacesCount()
    {
        return count(self::$namespaces);
    }

    /**
     * Ajoute un espace de nom pour le fichier de configuration
     *
     * Note : utilisable uniquement pour la génération du fichier de configuration !
     */
    public static function addNameSpace($nameSpace)
    {
        self::$namespaces[] = trim($nameSpace);
    }

    /**
     * Sélectionne le mode d'exécution de l'application (Pardo)
     *
     * Modes possibles en constantes de la présente classe.
     *
     * @param integer $mode
     */
    public static function setAppMode($mode)
    {
        $mode = (string) $mode;
        if (!($mode === self::APP_MODE_DEBUG || $mode === self::APP_MODE_NORMAL || $mode === self::APP_MODE_PERFORMANCE)) {
            throw new Exception('Bad application runtime mode');
        }
        self::$appMode = $mode;
    }

    /**
     * Retourne le mode d'exécution courant de l'application (debug, performance, ...)
     *
     * @return integer
     */
    public static function getAppMode()
    {
        return self::$appMode;
    }

    /**
     * Ajoute un paramétre au fichier de configuration si celui-ci n'existe pas déjà.
     *
     * Note : utilisable uniquement pour la génération du fichier de configuration !
     *
     * @param string $key
     * @param string $value
     */
    public static function setParameterIfNotExists($rootPath, $key, $value)
    {
        self::init($rootPath);
        if (!isset(self::$parameters[$key])) {
            self::setParameter($rootPath, $key, $value);
        }
    }

    /**
     * Ajoute ou modifie un paramétre au fichier de configuration
     *
     * Note : utilisable uniquement pour la génération du fichier de configuration !
     *
     * @param string $key
     * @param string $value
     */
    public static function setParameter($rootPath, $key, $value)
    {
        self::init($rootPath);
        if (!is_string($key)) {
            throw new Exception('Key type not allowed.');
        }
        if (!is_string($value) && !is_numeric($value)) {
            throw new Exception('Value type not allowed.');
        }
        self::$parameters[$key] = $value;
    }

    /**
     * Retourne un paramétre du fichier de configuration.
     *
     * Utilisable tout le temps.
     *
     * @param string $key
     * @return string
     */
    public static function getParameter($rootPath, $key)
    {
        self::init($rootPath);
        if (!is_string($key)) {
            throw new Exception('Key type not allowed.');
        }
        if (!isset(self::$parameters[$key])) {
            throw new Exception('Parameter not found : '.$key);
        }
        return self::$parameters[$key];
    }

    /**
     * Retrait d'un paramétre du fichier de configuration lors de sa génération.
     *
     * @param string $key
     */
    public static function removeParameter($rootPath, $key)
    {
        self::init($rootPath);
        if (!is_string($key)) {
            throw new Exception('Key type not allowed.');
        }
        if (isset(self::$parameters[$key])) {
            unset(self::$parameters[$key]);
        }
    }

    /**
     * Retourne la liste des paramétres du fichier de configuration.
     *
     * Utilisable tout le temps.
     *
     * @return array
     */
    public static function getParameters($rootPath)
    {
        self::init($rootPath);
        return self::$parameters;
    }
}
