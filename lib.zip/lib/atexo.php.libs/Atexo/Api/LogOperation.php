<?php
/**
 * Classe de log des operations arithmetiques
 * @author RHORBAL Anas <anas.rhorbal@atexo.com>
 * @copyright Atexo 2011
 * @version 1.0
 * @since SEM-1.0
 * @package atexo
 * @subpackage util
 */
class Api_LogOperation
{
	private $resultat=array();
    /**
     * ajoute une operation au niveau du log
     *
     * @param string $instruction l'instruction arithmetique
     * @param string $values doit avoir strictement get_defined_vars()
     * @param bool $printValueVariable doit avoir true/false false par defaut
     */
    public function addOperationLog($instruction,$values,$printValueVariable=false)
    {
        $instruction=str_replace("$","",str_replace(" ","",$instruction));
		$this->resultat[]=$instruction;
		
		$operators=array("+","-","*","/","(",")",">=","<=","=",">","<",";");
		$operation=str_replace($operators,"*",$instruction);
		
		$variables = explode("*",$operation);
		
		if($printValueVariable){
			$this->addVariableValue($variables,$values);
		}
		foreach($variables as $var){
			$instruction=str_replace($var,$values[$var],$instruction);
		}
		
		$this->resultat[]=$instruction;
    }
    
    private function addVariableValue($variables,$values)
    {
   		foreach($variables as $var){
			$this->resultat[]="$var = ".$values[$var];
		}
    }
    
    /**
     * ajoute une entree au niveau du log
     *
     * @param string $message le message a ajoute
     */
	public function addLog($message)
    {
    	$this->resultat[]=$message;
    }
    
    /**
     * retourne la chaine qui contient l'ensemble des operations
     *
     * @param string $seperator le separateur
     * @return string chaine qui contient l'ensemble des operations
     */
    public function getOperationLog($seperator="<br>")
    {
    	return implode($seperator,$this->resultat);
    }
}