<?php
/**
 * description de la classe
 *
 * @authorYoussef EL ALAOUI <youssef.elalaoui@atexo.com>
 * @copyright Atexo 2010
 * @version 0.0
 * @since Atexo.Api
 * @package atexo
 * @subpackage atexo
 */
class Api_XmlMapping
{
	public function toArray($xml) {
        $xml = simplexml_load_string($xml);
		$json = json_encode($xml);
		$array = json_decode($json,TRUE);

        return $array;
    }
    
	public function toXml($array,$root) {
		$xml = new SimpleXMLElement($root);
		
		$f = create_function('$f,$c,$a,$oldKey','
					foreach($a as $k=>$v){
						if(is_array($v)) {
							if(!is_numeric($k)){
								$hasIndex = false;
								foreach($v as $index=>$value) {
									if(is_numeric($index)){
										$hasIndex = true;
									}
									break;
								}
								if(!$hasIndex) {
									$ch=$c->addChild($k);
								}
								else {
									$ch=$c;
								}
							}
							else {
								$ch=$c->addChild($oldKey);
							}
							if(is_array($v["@attributes"])) {
								foreach($v["@attributes"] as $name=>$value) {
									$ch->addAttribute($name, $value);
								}
								unset($v["@attributes"]);
							}
							$f($f,$ch,$v,$k);
						}else {
							$c->addChild($k,$v);
						}
					}');
		
		$f($f,$xml,$array,"");
		
        return self::formatXmlString($xml->asXML());
    }
    
	public function formatXmlString($xml) {  
		$dom = new DomDocument;
		$dom->loadXML($xml);
		$dom->formatOutput = true;
		return $dom->saveXml();
	}
}