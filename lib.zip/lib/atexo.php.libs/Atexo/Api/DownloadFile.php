<?php

/**
 * Telechargement
 * @category Atexo
 * @package Atexo_DownloadFile
 */
class Api_DownloadFile {

	/**
	 * Permet de télécharger un fichier
	 *
	 * @param string $file_name le nom du fichier
	 * @param object $connection la connection
	 */
	public static function downloadFiles($pathFichier, $nomFichier)
	{
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private",false);
		if (strrchr($nomFichier, '.') == '.zip') {
			header("Content-Type: application/zip");	
		}
		else {
			header("Content-Type: application/octet-stream");	
		}
		$nomFichier = str_replace("\\", "", $nomFichier);
		header("Content-Disposition: attachment; filename=\"".$nomFichier."\";");
		header("Content-Transfer-Encoding: binary");
		echo file_get_contents($pathFichier);
		exit;
	}

	/**
	 * Donne le fichier en téléchargement
	 *
	 * @param string $nameFile Nom du fichier reçu par le client
	 * @param string $content Contenu du fichier à envoyer au client
	 */
	public static function downloadFileContent($nameFile, $content)
	{
		header('Pragma: ');
		header('Expires: ');
		header('Cache-control: ');
		header("Content-Disposition: attachment; filename=\"".$nameFile."\";");
		if (strrchr($nameFile, '.') == '.zip') {
			header("Content-Type: application/zip");	
		}
		else {
			header("Content-Type: application/octet-stream");	
		}
		header('Content-Tranfert-Encoding: binary');
		header('Content-Length: '.strlen($content));

		echo ($content);
		exit;
	}
}