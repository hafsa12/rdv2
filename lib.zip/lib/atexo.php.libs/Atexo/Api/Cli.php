<?php

/**
 * Scripts en ligne de commande
 * @category Atexo
 * @package Atexo_Cli
 */
class Api_Cli {

	private $nameProject;
	private $rootPath;
	private $applicationPath;
	private $cliPath;
	private $pfShortName;

	/**
	 * Affichage d'une erreur avec ou sans arrêt
	 *
	 * @param string $errorMessage
	 * @param boolean $displayHelp
	 * @param boolean $exit
	 */
	protected static function displayError($errorMessage, $displayHelp = false, $exit = true, $nameProject="", $rootPath="", $applicationPath="", $cliPath="", $pfShortName="")
	{
		echo 'Error : ' . $errorMessage . "\n";
		if ($displayHelp) {
			self::helpAction($nameProject, $rootPath, $applicationPath, $cliPath, $pfShortName);
		}
		if ($exit) {
			exit(1);
		}
	}

	/**
	 * Affichage d'un texte
	 *
	 * @param string $message
	 */
	protected static function display($message = null)
	{
		if ($message != null) {
			echo '-> ' . $message;
		}
		echo "\n";
	}

	/**
	 * Affiche le synopsys et l'aide.
	 */
	protected static function helpAction($nameProject, $rootPath, $applicationPath, $cliPath, $pfShortName)
	{
		if ($handle = opendir(realpath($cliPath))) {
			$commandLen = 0;
			while (false !== ($file = readdir($handle))) {
				if (substr($file, - 3) == 'php') {
					$className = substr($file, 0, - 4);
					$commandLen = max(strlen($className), $commandLen);
					$class = new ReflectionClass('Cli_' . $className);

					if (strpos($class->getDocComment(), '@subpackage Cron') !== false) {
						$crons[] = $className;
					}
					else {
						$classes[] = $className;
					}
					$comment[$className] = trim(str_replace(' *', '', preg_replace('/^[^a]+ \* ([^@]+)@?.*\*\/$/s', '\1', $class->getDocComment())));
				}
			}
			closedir($handle);
			$commandLen = $commandLen + 1;
			$spaces = '       ';
			for ($i = 0; $i < $commandLen; $i ++) {
				$spaces .= ' ';
			}

			if (is_file(realpath($applicationPath))) {
				echo " PF: " . $pfShortName . "\n";
				echo "  Path: " . $rootPath. "\n";
			}
			echo "  Synopsys : ".$nameProject." <command> [options]\n\n";
			echo "  Commands list :\n";
			foreach ($classes as $class) {
				$comment[$class] = str_replace("\n ", "\n$spaces", $comment[$class]);
				printf("    %' " . $commandLen . "s : %s\n", strtolower(substr($class,0,1)).substr($class,1), $comment[$class]);
			}
			echo "\n";
			echo "  Cron list :\n";
			foreach ($crons as $class) {
				$comment[$class] = str_replace("\n ", "\n$spaces", $comment[$class]);
				printf("    %' " . $commandLen . "s : %s\n", strtolower(substr($class,0,1)).substr($class,1), $comment[$class]);
			}
		}

		echo "\n";

		exit(1);
	}

	protected static function question($question, $defaultValue)
	{
		echo "$question [$defaultValue]: ";
		$value = trim(fgets(STDIN));
		if ($value == "") {
			$value = $defaultValue;
		}
		return $value;
	}

	protected static function cleanProject($rootPath, $nameProject, $httpdUser, $pfUrl, $semPath) {
		self::display("Creating default folders...");
		$folders = array('/assets' , '/protected/runtime' , '/protected/var/log' , '/protected/var/cache' , '/themes');
		foreach ($folders as $folder) {
			if (! is_dir($semPath . $folder)) {
				echo "Creation dossier " . $semPath . $folder . "\n";
				mkdir($semPath . $folder);
				echo "Affectation user " . $httpdUser . "  sur " . $semPath . $folder . "\n";
				shell_exec("chown -R " . $httpdUser . " {$semPath}{$folder}");
			}
		}
		shell_exec("chown " . $httpdUser . " {$semPath}/protected");
		shell_exec("chown -R " . $httpdUser . " {$semPath}/protected/runtime");
		shell_exec("chown " . $httpdUser . " {$semPath}/protected/config/messages/");

		self::display("Deleting cache files...");
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/themes/*');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/pages/*');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/var/cache/*');
		/*system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/config/messages/messages.fr.xml');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/config/messages/messages.en.xml');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/config/messages/messages.es.xml');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/config/messages/messages.it.xml');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/config/messages/messages.ar.xml');
		*/
		$filesMessages = scandir($rootPath . '/' . $nameProject . '/protected/config/messages');

        	foreach($filesMessages as $file) {
            	    if($file!="." && $file!=".." && strpos($file,'messages.default.')===false) {
                	system('rm -rf ' . $rootPath . '/' . $nameProject . '/protected/config/messages/'.$file);
        	    }
	        }
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/config/messages/en/');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/application.xml');
		system('rm -rf ' . $rootPath . '/'.$nameProject.'/protected/runtime/application.xml-*/sqlite.cache');

		//self::display("Deleting prado meta-files...");
		//$pradoAssets = $rootPath . '/'.$nameProject.'/assets/*';
		//system('rm -rf ' . $pradoAssets);
		//$pradoRuntime = $rootPath . '/'.$nameProject.'/protected/runtime/*';
		//system('rm -rf ' . $pradoRuntime);

		if (extension_loaded('apc') && ini_get('apc.enabled')) {
			self::display("Vidage du Cache APC.");
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $pfUrl .'?cleanAPC=clean');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_exec($ch);
		}

		self::display("Done ! " . $rootPath . " is clean.");
	}

	public static function checkSystem()
	{
		//version php
		if (version_compare(PHP_VERSION, '5.2.0', '>=')) {
			echo 'Version PHP OK : ' . PHP_VERSION . "\n";
		} else {
			echo 'Version PHP NOK : ' . PHP_VERSION . " (PHP 5.2 minimum !) \n";
		}

		// Extension PHP
		$installed_extensions = get_loaded_extensions();
		$needed_extensions = array('curl', 'mbstring', 'mysql', 'openssl', 'PDO', 'pdo_mysql', 'soap', 'gd', 'SimpleXML', 'SQLite', 'xml', 'zip', 'zlib', 'ctype', 'date', 'dom', 'iconv', 'libxml', 'pcre', 'session', 'SPL', 'tokenizer');
		foreach ($needed_extensions as $needed_extension) {
			if (in_array($needed_extension, $installed_extensions)) {
				echo "Module PHP $needed_extension OK \n";
			} else {
				echo "Module PHP $needed_extension NOK :-( \n";
			}
		}

		if (class_exists('Prado')) {
			echo "Version prado : ";
			$ver = PradoBase::getVersion();
			echo $ver;
			echo " ";
			if (version_compare($ver, '3.1.1', '>=')) {
				echo "OK \n";
			} else {
                " NOK :-( \n";
			}
		} else {
			echo "NOK (Prado non trouvé) \n";
		}

		echo "\n";
	}

	protected static function genPropelClasses($dbProjectName, $propelGeneratorDir, $rename=false)
	{
		$schemaFilePath =  $propelGeneratorDir. '/projects/' .$dbProjectName . '/schema.xml';
		system('cd '. $propelGeneratorDir . '; ./pear-propel-gen projects/'.$dbProjectName . ' reverse');
		Atexo_Mapping_PropelSchema::replaceCapsChars($schemaFilePath);
		if($rename)
		{
			//Atexo_Mapping_PropelSchema::addPhpName($schemaFilePath, "Common");
		}
		system('cd '. $propelGeneratorDir . '; ./pear-propel-gen projects/' .$dbProjectName. ' om');
	}

	protected static function copyPropelClasses($dbProjectName, $propelGeneratorDir, $dirClasseMapping, $withClasse=false)
	{
		$propelClassesDir = $propelGeneratorDir.'/projects/' . $dbProjectName . '/build/classes/'.$dbProjectName;

		if($withClasse) {
			system ('cp -f ' . $propelClassesDir . '/*.php ' . $dirClasseMapping.$dbProjectName.'/');
		}
		system ('cp -f ' . $propelClassesDir . '/om/*.php ' . $dirClasseMapping.$dbProjectName.'/om/');
		system ('cp -f ' . $propelClassesDir . '/map/*.php ' . $dirClasseMapping.$dbProjectName.'/map/');
	}

	protected static function updateDb($database, $host_spec, $user, $pass, $port, $prefix, $timeZone, $dbEncoding, $allQuery) {
		$apiDb = new Api_Db($database, $host_spec, $user, $pass, $port, $prefix, $timeZone, $dbEncoding);
		$link = $apiDb->getLink();
		 
		foreach ($allQuery as $query) {
			try {
				if (! $link->query($query)) {
					echo "ERROR when executing query : " . substr($query, 0, 77) . "...\n";
				}
				else {
					echo ".";
				}
			} catch (Exception $e) {    
				echo $e->getMessage() ."\n";
			}
		}
	}
	
	protected function cleanConfig() {
		if (file_exists('protected/var/cache/config_application.php')) {
            unlink('protected/var/cache/config_application.php');
        }
        if (file_exists('protected/application.xml')) {
            unlink('protected/application.xml');
        }
	}
	
	protected static function openSsl($mpePath, $root_dir) {
    	// OpenSSL
        echo "\nCopie des fichiers nécessaire à OpenSSL TS \n";
        $openssl_cnf = file_get_contents("$mpePath/ressources/openssl/openssl.cnf");
        $openssl_cnf = str_replace("###COMMON_DIR###", $root_dir, $openssl_cnf);
        file_put_contents("$root_dir/common/openssl.cnf", $openssl_cnf);
        file_put_contents("$root_dir/common/serial", "AEA3742F\n");
    }

    protected static function generationAc($mpePath, $root_dir, $pfName) {
    	// Generation AC
        echo "\nGénération CA...\n";
        shell_exec("bash '$mpePath/ressources/openssl/certificats.sh' -d $root_dir/common/ca -n \"" . $pfName . "\" ");
    }
    
	protected static function copieRootCa($root_dir) {
    	// copie du root_ca
        echo "Copie du root_ca dans le dossier trust et hash OpenSSL\n";
        shell_exec("cp $root_dir/common/ca/certs/root_ca.crt $root_dir/common/trust");
        shell_exec("cd $root_dir/common/trust && ./trust.sh");
    }
    
    protected static function chargementPrado($cfg_apache_user, $mpePath, $pathPrado) {
    	echo "\n----- CHARGEMENT DU CONTEXTE PRADO -----\n";
        require_once $pathPrado . '/prado.php';
        $application = new TShellApplication('protected/application.xml');
        try {
            $application->run();
        } catch (Exception $e) {
            echo "PB bdd";
            echo $e->getMessage();
        }
        shell_exec("chown -R $cfg_apache_user {$mpePath}/protected/runtime/*");
    }
    
	protected static function createFolder($mpePath, $cfg_apache_user, $root_dir) {
		// Creation des dossiers avec contenu auto généré dans le dossier du code de MPE
        $folders = array('/pages' , '/assets' , '/protected/runtime' , '/protected/var/log' , '/protected/var/cache' , '/themes');
        foreach ($folders as $folder) {
            if (! is_dir($mpePath . $folder)) {
                echo "Creation dossier " . $mpePath . $folder . "\n";
                mkdir($mpePath . $folder);
                echo "Affectation user $cfg_apache_user sur " . $mpePath . $folder . "\n";
                shell_exec("chown -R $cfg_apache_user {$mpePath}{$folder}");
            }
        }
        shell_exec("chown $cfg_apache_user {$mpePath}/protected");
        shell_exec("chown $cfg_apache_user {$mpePath}/protected/config/messages/");
        
		// Dossier /var
        echo "\nCréation de l arborescence du dossier de stockage des fichiers... \n";
        
        if (! is_dir($root_dir)) {
            echo "Création dossier " . $root_dir . "\n";
            shell_exec("mkdir -p \"$root_dir\"");
        }
        $folders = array('common' , 'logs' , 'tmp' , 'common/tmp' , 'common/files' , 'common/indexLucene' , 'common/indexLuceneEntreprise');
        foreach ($folders as $folder) {
            if (! is_dir($root_dir . $folder)) {
                echo "Creation dossier " . $root_dir . $folder . "\n";
                mkdir($root_dir . $folder);
            }
        }
    }
}
