<?php
/**
 * Contient des fonctions non dépendante du projet tel que la convertion des dates (iso -> fr) etc ...
 *
 * @author atexo
 * @copyright Atexo 2013
 * @version 1.0
 * @since atexo.rdv
 * @package
 * @subpackage
 */

class Api_Util
{
	/**
	 * Retourne un tableau associatif array[$source] = $target d'un fichier de libellé Xliff
	 * @param string $xliff_file Fichier XML Xliff de libellé
	 * @return array Tableau associatif des libellés
	 */
	public function XliffToArray($xliff_file) {
		$dom = new DOMDocument();
		$dom->load($xliff_file);
		$sourceElements = $dom->getElementsByTagName('source');
		$length = $sourceElements->length;
		$tmp = array();
		for($i=0; $i < $length; $i++) {
			$node = $sourceElements->item($i);
			if ($node->parentNode->lastChild->nodeName == "target") {
				$tmp[$node->firstChild->nodeValue] = $node->parentNode->lastChild->nodeValue;
			} else if ($node->nextSibling->nodeName == "target") {
				$tmp[$node->firstChild->nodeValue] = $node->nextSibling->nodeValue;
			} else if ($node->parentNode->lastChild->previousSibling->nodeName == "target") {
				$tmp[$node->firstChild->nodeValue] = $node->parentNode->lastChild->previousSibling->nodeValue;
			}
		}
		return $tmp;
	}
	
	public function isUTF8($str) {
		if ($str === mb_convert_encoding(mb_convert_encoding($str, "UTF-32", "UTF-8"), "UTF-8", "UTF-32")) {
			return true;
		} else {
			return false;
		}
	}

	/** convertit une date ISO en date française
	 * @param $_isoDate date au format yyyy-mm-dd
	 * @return date au format dd/mm/yyyy
	 */
	function iso2frnDate($_isoDate) {
		if (!$_isoDate || $_isoDate == '0000-00-00') {
			return;
		}
		if (strstr($_isoDate, '-')) {
			list ($y, $m, $d) = explode('-', $_isoDate);
			return "$d/$m/$y";
		}
		return $_isoDate;
	}

	/** convertit une date française en date ISO
	 * @param $_frnDate date au format dd/mm/yyyy
	 * @return date au format yyyy-mm-dd
	 */
	public function frnDate2iso($_frnDate) {
		$_frnDate=self::getValSansEspace($_frnDate);
		if (!$_frnDate) {
			return;
		}
		if (strstr($_frnDate, '/')) {
			list ($d, $m, $y) = explode('/', $_frnDate);
			return "$y-$m-$d";
		}
		return $_frnDate;
	}
	
	public function getValSansEspace($valeur)
	{
		return str_replace(' ', '', $valeur);
	}
	
	/**
	 * Générer une chaine de caractere unique et aléatoire
	 * @param $car la longeur de la chaine générée
	 */
	function randomMdp($car)
	{
			
		$s = "";
		$chaine1 = "abcdefghijklmnpqrstuvwxyz";
		$chaine2 = "0123456789";
		$chaine3 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$chaine4 = "!@#$*+";
		srand((double) microtime() * 1000000);
		for ($i = 0; $i < $car; $i++) {
			if ($i < 3) {
				$s.=$chaine1[rand() % strlen($chaine1)];
			}elseif ($i > 3 && $i < 6) {
				$s.=$chaine2[rand() % strlen($chaine2)];
			}elseif ($i > 6 && $i < 9) {
				$s.=$chaine3[rand() % strlen($chaine3)];
			}elseif ($i == 9) {
				$s.=$chaine4[rand() % strlen($chaine4)];
			}else {
				$s .= $chaine1[rand() % strlen($chaine1)];
			}
		}
		return $s;
	}

	/**
	 * Générer une chaine de caractère unique et aléatoire
	 * @param $car la longeur de la chaine générée
	 */
	function random($car)
	{
		$string = "";
		$chaine = "abcdefghijklmnpqrstuvwxyz0123456789";
		srand((double) microtime() * 1000000);
		for ($i = 0; $i < $car; $i++) {
			$string .= $chaine[rand() % strlen($chaine)];
		}
		return $string;
	}

	public function atexoHtmlEntities ($str)
	{
		return htmlspecialchars($str, ENT_NOQUOTES, Atexo_Config::getParameter('HTTP_ENCODING'));
	}

	public function stripWordsCharacters($string)
	{
		return str_replace(
		array("\x80", "\x82", "\x84", "\x85", "\x8C", "\x91", "\x92", "\x93", "\x94", "\x96", "\x97", "\x98", "\x9C", "&#9679;", "&#8209;", "&#61607;", "&#61664;", "&#8805;", "", "" ),
		array("\xA4", "\x27", "\x22", "..." , "OE",   "\x27", "\x27", "\x22", "\x22", "\x2D", "\x2D", "\x7E", "oe",   "\x2D",    "\x2D",    " -",       ":",		 "\x3E \x3D", "'", "-"),
		$string
		);
	}

	function newLineToBr($string)
	{
		return str_replace('\n\r', '<br />', $string);
	}

	public function isEntier($valeur) {
		return (preg_match("/^([0-9]+)$/", $valeur));
	}

	/**
	 *
	 * Affiche le format HH:MM
	 * @param unknown_type $heure
	 */
	public function getFormatHhMm($heure){
		$tab = explode(':', $heure);
		return $tab[0].":".$tab[1];
	}

	public function mvFile($file, $path, $name) {
		if(! is_dir ($path)) {
			mkdir($path);
		}
		move_uploaded_file($file, "$path/$name");
	}
	
	public function getAbsoluteUrl() {
        $protocol = ($_SERVER['HTTPS'] == 'on')?'https://':'http://';
        $folder = str_replace('/index.php5', '', $_SERVER['PHP_SELF']);
        $folder = str_replace('/index.php', '', $folder);
        return $protocol . $_SERVER['HTTP_HOST'] . $folder . '/';
    }
    
	public function getMontantArrondit($montant, $apresVirgule = 2) {

		if (empty ($montant))
			return "0.00";

		$montant = str_replace(',', '.', $montant);

		if(doubleval(abs($montant))<0.005)
			return "0.00";

		if (!self::isEntierRelatif($montant))
			return $montant;

		$montant = str_replace(',', '.', $montant);

		$montant = sprintf("%." . $apresVirgule . "f", $montant);

		return $montant;
	}
    
	public function getMontantArronditEspace($montant, $apresVirgule = 2, $avecVirgule = true)
   	{
		$montant = str_replace(' ', '', $montant);
		if (empty ($montant))
		{
			if($apresVirgule == 0) 
			{
				return "0";
			}else{
				return "0,00";
			}
		}
		
		if (!self::isEntierRelatif($montant))
			return $montant;
		
		$montant = str_replace(',', '.', $montant);
		
		$montant = str_replace('.', ',', sprintf("%." . $apresVirgule . "f", $montant));
		
		list($mon,$vir) = explode(',',$montant);
		
		$i = 0;
		$mon = strrev($mon);
		$montant = "";
		while($i<strlen($mon))
		{
			$montant = $mon[$i].$montant;
			if((($i+1)%3)==0)
				$montant = " ".$montant;
			$i++;
		}
		
		if($apresVirgule)
		{
			return trim($montant.','.$vir);
		}else{
			return trim($montant);
		}
	}
	
	public function isEntierRelatif($valeur) {
		return (preg_match("/^([+\-]?)[0-9]+([\.,]?[0-9]+)?$/", $valeur));
	}
	
	/**
	 * Sorts an array according to a specified column
	 * Params : array  $table
	 *          string $colname
	 **/
	function orderArrayByCol($table, $colname) {
	 	$tn = $ts = $temp_num = $temp_str = array();
	 	foreach ($table as $key => $row) {
		   	if(is_numeric(substr($row[$colname], 0, 1))) {
		    	$tn[$key] = $row[$colname];
		    	$temp_num[$key] = $row;
		    }
		    else {
		    	$ts[$key] = $row[$colname];
		    	$temp_str[$key] = $row;
		    }
	  	}
	 	unset($table);
	
		array_multisort($tn, SORT_DESC, SORT_NUMERIC, $temp_num); 
		array_multisort($ts, SORT_DESC, SORT_STRING, $temp_str);
		return array_merge($temp_num, $temp_str);
	}
}