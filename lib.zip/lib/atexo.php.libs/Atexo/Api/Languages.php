<?php
/**
 * Classe de manipulation des langues de la plate-forme
 * @author ZAKI Anas <anas.zaki@atexo.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage consultation
 */
class Api_Languages
{
	public  static function generateXliffByLanguage($language) {
		if (!is_file("protected/config/messages/messages.$language.xml")) {
			if (!is_file("../config/messages/messages.$language.xml")) {
				copy("protected/config/messages/messages.default.$language.xml", "protected/config/messages/messages.$language.xml");
			} else {
				$domv1 = Atexo_Utils_Util::XliffToArray("../config/messages/messages.$language.xml");
				$domv2 = Atexo_Utils_Util::XliffToArray("protected/config/messages/messages.default.$language.xml");
				$xml='<?xml version="1.0" encoding="utf-8"?>' . "\n";
				$xml.='<xliff version="1.0"><file datatype="plaintext" date="'.date("c").'" original="I18N Example IndexPage" source-language="'.strtoupper($language).'" target-language="'.strtoupper($language).'-'.strtoupper($language).'"><body>' . "\n";
				foreach ($domv1 as $k => $v) {
					$domv2[$k] = $v;
				}
				$row=0;
				foreach ($domv2 as $k => $v) {
					$row++;
					$se = array('>', '<');
					$re = array('&gt;', '&lt;');
					$v = str_replace($se, $re, $v);
					$xml .= "<trans-unit id=\"$row\"><source>$k</source><target>$v</target></trans-unit>\n";
				}
				$xml.="</body></file></xliff>";
				file_put_contents("protected/config/messages/messages.$language.xml", $xml);
			}
		}
	}

	/**
	 * retourne l'abréviation de la langue avec première lettre majuscule
	 * @param l'acronyme de la langue
	 */
	public function getLanguageAbbreviation($lang)
	{
		if($lang) {
			return ucfirst($lang);
		} else {
			return "";
		}
	}
}
