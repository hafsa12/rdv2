<?php

/**
 * Classe de chargement (bootstrapper) du framework prado.
 *
 * @author Guillaume Ponéon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage controller
 */
class Api_Prado
{
    /**
     * Chargement de Prado
     *
     * @return boolean
     */
    public static function run($rootPath, $pradoPath)
    {
        if (!self::checkWorkspace($rootPath)) {
            return false;
        }
        //   require_once 'prado/pradolite.php';
        require_once $pradoPath . '/prado.php';

        $application = new TApplication();
        $application->run();
        return true;
    }

    /**
     * Effectue des v�rifications sur l'espace de travail afin de voir s'il est compatible Prado
     *
     * @return boolean
     */
    private static function checkWorkspace($rootPath)
    {
        $basePath = $rootPath . '/';
        $assetsPath = $basePath . '/assets';
        $runtimePath = $basePath . '/protected/runtime';

        $retVal = true;
        if (!is_writable($assetsPath)) {
            trigger_error("Please make sure that the directory " . $assetsPath . " is writable by Web server process.");
            $retVal = false;
        }
        if (!is_writable($runtimePath)) {
            trigger_error("Please make sure that the directory " . $runtimePath . " is writable by Web server process.");
            $retVal = false;
        }
        return $retVal;
    }

   /**
     * Chargement de Prado en mode CLI
     *
     * @return boolean
     */
    public static function runCli($pradoPath, $configFile)
    {
        require_once $pradoPath . '/prado.php';
        $application = new TShellApplication($configFile);
        $application->run();
        return $application;
    }
}
