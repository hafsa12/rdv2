<?php

class Api_UrlProtector
{
    protected static $secret_key = 12;
    protected static $url_list_file = 'protected/var/urlListe/urlliste.txt';
    
    private static function generateUrlHash($url) {
        return md5($_SERVER["DOCUMENT_ROOT"] . $_SERVER["SERVER_NAME"] . $_SERVER["HTTP_COOKIE"] . $url . self::$secret_key);
    }
    
    private static function storeProtectedUrl($url) {
    	// désactivation URL Protector
    	return;
        /*$query = explode("&", $url);
        foreach ($query as $q) {
            list ($key, $value) = explode("=", $q);
            if ($key != 'page') $url .= '&' . $key;
            else $url .= $q;
        }
        $list = file(self::$url_list_file, FILE_IGNORE_NEW_LINES);
        if (array_search($url, $list) === FALSE) {
            file_put_contents(self::$url_list_file, $url . "\n", FILE_APPEND);
        }*/
    }
    
    public static function protectUrl($query_string) {
        self::storeProtectedUrl($query_string);
        return "$query_string&h=" . self::generateUrlHash($query_string);
    }
    
    public static function isUrlProtected($url) {
        $listing = array();
        $list = file(self::$url_list_file, FILE_IGNORE_NEW_LINES);
        foreach ($list as $line) {
            $page = '';
            $qs = array();
            $query = explode("&", $line);
            foreach ($query as $q) {
                list ($key, $value) = explode("=", $q);
                if ($key == 'page') {
                	$page = $value;
                }
                elseif ($key != 'h') {
	                $qs[] = $key;
                }
            }
            $listing[$page][] = $qs;
        }
        if (isset($listing[$url['page']])) {
            foreach ($listing[$url['page']] as $elt) {
                $all_ok = 1;
                foreach ($elt as $param) {
                    if (!isset($url[$param])) {
                    	$all_ok = 0;	
                    }
                }
                if ($all_ok == 1) {
                	return true;
                }
            }
        }
        return false;
    }
    
    public static function validateUrl($query_string) {
        foreach ($query_string as $q => $v) {
            if ($q != 'h') {
            	$url .= "&" . $q;
            	if($v != ''){
            		$url .= "=" . $v;
            	}
            }
        }
        if ($_GET['h'] != self::generateUrlHash(str_replace('&page', 'page', $url))) {
            echo "Ressource interdite";
            exit();
        }
    }
}
/*
if (isset($_GET) && count($_GET) > 1) {
    if (Atexo_Utils_UrlProtector::isUrlProtected($_GET)) {return Atexo_Utils_UrlProtector::validateUrl($_GET);}
}
*/
