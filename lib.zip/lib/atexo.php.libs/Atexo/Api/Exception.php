<?php

/**
 * Exception spécifique Atexo
 *
 * @author Guillaume Ponéon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage exception
 */
class Api_Exception extends Exception 
{
	const ER_ROW_IS_REFERENCED_1451 = 23000;
}
