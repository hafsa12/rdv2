<?php
/**
 * description de la classe
 *
 * @author izgua fatima ezzahra <fatima.izgua@atexo.com>
 * @copyright Atexo 2010
 * @version 0.0
 * @since Atexo.Forpro
 * @package atexo
 * @subpackage atexo
 */
class Api_Mail
{
    const MAIL_NOT_SENT = 0;
    const MAIL_SENT = 1;
    const MAIL_DESACTIVATED = 2;
    const MAIL_ERREUR = 3;
	/**
	 * 
	 * @param unknown_type $emmeteur
	 * @param unknown_type $recepteur
	 * @param unknown_type $message
	 */
	public function envoyerMail($emmeteur,$recepteur,$objet, $message, $isDoctype = false)
	{
	    $isMailSent = self::MAIL_NOT_SENT;
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		if($isDoctype)
		{
		    $headers .= 'Content-type: text/plain; charset=utf-8' . "\r\n";
        }else{
            $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
        }
		$headers .= "From: ".mb_encode_mimeheader (mb_convert_encoding($emmeteur,"UTF-8","AUTO"))."\r\n";
        mb_language("uni");
        //$objet = mb_encode_mimeheader(mb_convert_encoding($objet, "UTF-8","AUTO"));
        $message = mb_convert_encoding($message, "UTF-8","AUTO");

        if(!$recepteur)
        {
            return self::MAIL_DESACTIVATED;//2: case mail desactivated/no mail
        }else{
            $isMailSent = mail($recepteur, $objet, $message, $headers);
        }
		if($isMailSent)
		{
		    return self::MAIL_SENT;//true
		}else{
			return self::MAIL_ERREUR;//throw new Exception(Prado::localize('TRANS_ERREUR_ENVOI_MAIL'));
        }
	}
	
	public function EnvoyerEmailAvecFichierAttache($files,$_from, $_to, $_subject, $_body, $contentType)
	{
		$boundary = "-----=" . md5(uniqid(rand()));
		
		$_subject = self::encode_header($_subject);

		$header = "MIME-Version: 1.0\r\n";
		$header .= "Content-Type: multipart/mixed; boundary=\"$boundary\"\r\n";
		//$header .= "\r\n";
		$header .= "From: ".mb_encode_mimeheader (mb_convert_encoding($_from,"UTF-8","AUTO"))."\r\n";
		$msg = "MIME 1.0 multipart/mixed.\r\n";
		$msg .= "--$boundary\r\n";
		$msg .= "Content-Type: text/html; charset=\"utf-8\"\r\n";
		$msg .= "Content-Transfer-Encoding:8bit\r\n";
		$msg .= "\r\n";
		$msg .= $_body . "\r\n";
		$msg .= "\r\n";
			
		
		foreach($files as $file)
		{
			$attachment = $file['contentFile'];
			$attachment = chunk_split(base64_encode(utf8_decode($attachment)));
			$fileName = $file['nameFile'];
			
			$msg .= "--$boundary\r\n";
			$msg .= "Content-Type: ".$contentType."; name=\"$fileName\"\r\n";
			$msg .= "Content-Transfer-Encoding: base64\r\n";
			$msg .= "Content-Disposition: attachment; filename=\"$fileName\"\r\n";
			$msg .= "\r\n";
			$msg .= $attachment . "\r\n";
		}
		$msg .= "\r\n\r\n";
		$msg .= "--$boundary--\r\n";
		mail($_to, $_subject, $msg,$header);		   
	 }
	 
	public function encode_header($string, $encoding = 'UTF-8') {
		$string = str_replace(" ", "_", trim($string)) ;
		$string = str_replace("?", "=3F", str_replace("=\r\n", "", preg_replace('/([\x80-\xFF])/e', '"=" . strtoupper(dechex(ord("\1")))', $string)));
		$string = chunk_split($string, 85);
		$string = substr($string, 0, strlen($string)-2);
		$string = str_replace("\r\n", "?="."\n"." =?".$encoding."?Q?", $string) ;
		return '=?'.$encoding.'?Q?'.$string.'?=';
	} 
}