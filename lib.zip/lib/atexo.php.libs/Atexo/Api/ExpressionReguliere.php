<?php
/**
 * description de la classe
 *
 * @authorYoussef EL ALAOUI <youssef.elalaoui@atexo.com>
 * @copyright Atexo 2010
 * @version 0.0
 * @since Atexo.Forpro
 * @package atexo
 * @subpackage atexo
 */

class Api_ExpressionReguliere
{
	CONST EMAIL = "([ ])*[a-zA-Z0-9\_\-\.]+([a-zA-Z0-9\_\-\.]+)*\@[a-zA-Z0-9\_\-\.]+(\.[a-zA-Z0-9_]+)*\.[a-zA-Z]{2,4}([ ])*";
	CONST EMAIL_ = "/([ ])*[a-zA-Z0-9\_\-\.]+([a-zA-Z0-9\_\-\.]+)*\@[a-zA-Z0-9\_\-\.]+(\.[a-zA-Z0-9_]+)*\.[a-zA-Z]{2,4}([ ])*/";
	CONST TEL = "^0[1-9]([-. ]?[0-9]{2}){4}";
	CONST TEL_ = "/^0[1-9]([-. ]?[0-9]{2}){4}/";
	CONST NUMBER = "(-)?([0-9]|\s)*((,|\.)?([0-9]{1,2}))?";
	CONST NUMBER_PHP = "/^[\-+]?[1-9]+[0-9]*((\.?|\,?)[0-9]{1,2})?$/";
	CONST POSITIVENUMBER = "([0-9]|\s)*((,|\.)?([0-9]{1,2}))?";
	CONST POSITIVEINTEGER = "^([1-9])([0-9])*";
    CONST POSITIVEINTEGER_ = "/^([1-9])([0-9])*/";
    CONST NOM = "^[^0-9]+$";
    CONST NOM_ = "/^[^0-9]+$/";
    CONST ALPHANUMERIQUE = "[a-zA-Z0-9À-ÿ\-'\s]+([a-zA-Z0-9À-ÿ\-'\s]+)*";
	CONST ALPHANUMERIQUE1 = "[a-zA-Z0-9À-ÿ\-'\s%\"&\*/\.]+([a-zA-Z0-9À-ÿ\-'\s%\"&\*/\.]+)*";
    CONST DATE_ISO = "(^[0-9]{4}\-(((01|03|05|07|08|10|12)\-(0[1-9]|1[0-9]|2[0-9]|3[0-1]))|((04|06|09|11)\-(0[1-9]|1[0-9]|2[0-9]|30))|(02\-(0[1-9]|1[0-9]|2[0-9])))$)";
    //CONST DATE_ISO = "/^([0-9]{4})\-([0-9]{2})\-([0-9]{2})$/";
    CONST CODE_POSTAL = "/[0-9]{5}/ ";
    CONST ANNEE = "/[0-9]{4}/ ";
}