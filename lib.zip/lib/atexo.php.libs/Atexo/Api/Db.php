<?php

/**
 * Accès à la base de données
 *
 * Cf. les exemples d'accès à la base par Api_Db dans les tests unitaires.
 *
 * @author Guillaume Ponéon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage db
 */
class Api_Db
{
    /**
     * Instance de PDO
     *
     * @var PDO
     */
    private $link = null;
    private $database = null;
    private $user = null;
    private $pass = null;
    private $timeZone = null;
    private $initialized = array();
    private $dbEncoding = null;
    
   	public function Api_Db($database, $host_spec, $user, $pass, $port, $prefix, $timeZone, $dbEncoding) {
   		$port = "port=".$port.";";
   		$this->database = $database;
   		if ($prefix) {
            $prefix = $prefix . '_';
		}
		$this->dsn  = 'mysql:host=' . $host_spec . ';'.$port.'dbname=' .$prefix.$database;
   		$this->user = $user;
   		$this->pass = $pass;
   		
   		$this->timeZone = $timeZone;
   		$this->dbEncoding = $dbEncoding;
   		$this->init();
   	}

    /**
     * Retourne l'instance PDO de la base
     * Si le parametre read_only est egale a false, alors on a une connexion sur les bases dédiées en lecture/ecriture
     * Sinon, on a une connexion sur les bases dédiées à la lecture
     * @return PDO
     */
    public function getLink()
    {
        return $this->link;
    }

    public static function close()
    {
        $this->link = null;
        unset($this->initialized[$database]);
    }

    /**
     * Initialise le lien vers une base de données
     *
     * @param unknown_type $database
     * @return PDO
     */
    private function init()
    {
        if (!isset($initialized[$database])) {
            $this->initialized[$this->database] = true;
            
            $link = new PDO($this->dsn, $this->user, $this->pass);
            if ($link) {
                $link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $link->setAttribute(PDO::ATTR_CASE, PDO::CASE_NATURAL);
                if (version_compare(PHP_VERSION, '5.2.1', '<')) {
                    $link->setAttribute(PDO::ATTR_EMULATE_PREPARES, true);
                    $link->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, true);
                }
                if($this->timeZone !== 'Europe/Paris') {
                	$link->query("SET time_zone = '".$this->timeZone."';");
                }
                $link->query("SET NAMES ". $this->dbEncoding .";");
                return $link;
            }
            return false;
        }
        return $link;
    }
    /*
     * Retourne la chaine str, après avoir échappé tous les caractères qui doivent l'être, pour être utilisée dans une requête de base de données
     * @param: chaine à échapper
     * @return: chaine échappée
     */
    public function quote($chaine) {
        return addslashes($chaine);
    }

}
