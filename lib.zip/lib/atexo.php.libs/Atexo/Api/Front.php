<?php
/**
 * Contrôleur frontal de toute application mpe
 *
 * @author Guillaume Ponçon <guillaume.poncon@openstates.com>
 * @copyright Atexo 2008
 * @version 1.0
 * @since MPE-3.0
 * @package atexo
 * @subpackage controller
 * @todo mettre les fichiers statiques en cache sauf mode débogage
 */
class Api_Front
{
	public static function erreur404($file=null) {
		header("HTTP/1.0 404 Not Found");
		if($file==null) {
			echo "404 Not Found";
		}
		else {
			echo file_get_contents($file);
		}
		exit(1);
	}
	
	public static function cookieDesign() {
		$design = eregi_replace("[^-_[:alnum:]]", "", $_GET['design']);
		if ($design != "" && $design != "reset") {
			self::setCookie('design', $design);
		} else {
			self::unsetCookie('design');
		}
	} 
	
	public static function cookieSelectedOrg() {
		$selectedorg = eregi_replace("[^-_[:alnum:]]", "", $_GET['selectedorg']);
		if ($selectedorg != "" && $selectedorg != "reset") {
			self::setCookie('selectedorg', $selectedorg);
		} else {
			self::unsetCookie('selectedorg');
		}
	} 
	
	public static function setCookie($key,$value) {
		setcookie($key, $value);
		$_COOKIE[$key] = $value;
	}
	
	public static function unsetCookie($key) {
		unset($_COOKIE[$key]);
		setcookie($key, '', time() - 86400);
	}
	/**
	 * Retourne le chemin pour le theme
	 * Si un dossier organisme existe dans /themes alors on va chercher dans /themes/orga sinon /themes
	 * TODO : portal
	 */
	public static function getThemesPath($langChoisie, $rootPath)
	{
		$paramLang = false;
		if (self::hasThemeSpecifique($langChoisie)) {
			$paramLang =$langChoisie;
		}
		if ($paramLang !== false && file_exists($rootPath. '/themes/' . $paramLang)) {
			$sub = '/' . $paramLang;
			return "themes$sub";
		}
		
		else { 
			if (isset($_COOKIE['design'])) { 
				$sub = '/' . $_COOKIE['design'];
			}
			else {
				$sub = '';
			}
		}
		return "themes$sub";
	}

	/**
	 * Page PHP mise en cache
	 * TODO : gérer le multi-thèmes et la langue !
	 * @return integer
	 */
	public static function displayPhpFileContent($rootPath, $urlInterne, $projectName, $lang)
	{
		$urlRelative = $urlRelative2 = substr(self::getUrlRelative(), strlen('/pages/'));
		$lang_link = '';
		
		if(isset($lang) && strlen($lang) > 1 && strpos($urlRelative, ".".$lang) !== false) {
			$lang_link = '&' . 'lang=' . $lang;
			$urlRelative2 = str_replace(".$lang", '', $urlRelative);
		}
		$protocol = ($_SERVER['HTTPS'] == 'on')?'https://':'http://';
		$folder = str_replace('/index.php', '', $_SERVER['PHP_SELF']);
		if ($urlInterne != '') {
			$url = $urlInterne;
		} else {
			$url = $protocol . $_SERVER['HTTP_HOST'];
		}
		$ch = curl_init($url . $_SERVER['PHP_SELF'] . '?page=' . str_replace('.htm', '', $urlRelative2) . $lang_link);
		$fp = fopen($rootPath . '/'.$projectName.'/pages/' . $urlRelative, "w");
		curl_setopt($ch, CURLOPT_FILE, $fp);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
		curl_exec($ch);
		curl_close($ch);
		fclose($fp);
		$data = file_get_contents($rootPath . '/'.$projectName.'/pages/' . $urlRelative);
		//$data = str_replace('<head>',"<head>\n<base href=\"".$protocol . $_SERVER['HTTP_HOST'] . $folder . "/\">\n",$data);
		$data = str_replace('src="','src="' . $folder . '/', $data);
		$data = str_replace('href="','href="' . $folder . '/', $data);
		$data = str_replace('href="//','href="/', $data);
		$data = str_replace('action=/"','action="/' . $folder . '/', $data);
		file_put_contents($rootPath . '/'.$projectName.'/pages/' . $urlRelative, $data);
		header('Content-type: text/html');
		header('Content-Length: ' . strlen($data));
		header('Last-Modified: ' . gmdate('D, d M Y H:i:s', time()) . ' GMT', true, 200);
		header("HTTP/1.0 200 OK");
		header("Status: 200 OK");
		echo $data;
		return true;
	}

	/**
	 * Repère le type mime d'un fichier et affiche son contenu.
	 *
	 * @param string $content
	 * @param string $url
	 * @return boolean
	 */
	public static function displayStaticFile($content, $url, $fileName, $rootPath, $cacheThemeJs, $cacheTheme, $themeNotCached)
	{
		// tableau de types mimes
		static $mimeTypes = null;

		// Si le tableau n'est pas chargé
		if ($mimeTypes === null) {
			$mimeTypesFile = '/tmp/mpeMimes.ini';

			// Si le fichier tampon n'existe pas
			if (!file_exists($mimeTypesFile)) {

				// Construire le tableau de types mimes à partir des
				// types mimes du systême, sinon faire un tableau vide
				if (!file_exists('/etc/mime.types')) {
					$mimeTypes = array();
					file_put_contents($mimeTypesFile, ';; No data');
				} else {
					$tabTypes = file('/etc/mime.types');
					$data = ';; Mime types - generated ' . date('d.m.Y H:i:s') . "\n\n";
					foreach ($tabTypes as $line) {
						if ($line[0] == '#' || !trim($line)) {
							continue;
						}
						$line = preg_replace('/[ \t]+/', ' ', $line);
						$tabLine = explode(' ', $line);
						$mimeType = trim(array_shift($tabLine));
						if (count($tabLine)) {
							foreach ($tabLine as $extension) {
								$extension = trim($extension);
								if (!preg_match('/^[a-z0-9]{2,4}$/', $extension)) {
									continue;
								}
								$mimeTypes['.' . $extension] = $mimeType;
								$data .= '.' . $extension . ' = ' . $mimeType . "\n";
							}
						}
					}
					file_put_contents($mimeTypesFile, $data);
				}
			} else {
				$mimeTypes = parse_ini_file($mimeTypesFile, false);
			}
		}

		// récupération de l'extension du fichier à afficher
		$extension = strrchr($url, '.');

		// Mettre en cache les fichiers qui ne sont pas blacklistés
		if (($extension == '.js' && $cacheThemeJs == "true") || ($extension != ".js" && $cacheTheme == "true")){
			$doNotCacheFiles = explode(',', $themeNotCached);
			if (!in_array($url, $doNotCacheFiles)) {
				$paths = explode('/', substr(dirname($url), 1));
				$fullPath = $absolutePath = $rootPath . '/themes';
				foreach ($paths as $directory) {
					$fullPath .= '/' . $directory;
					if (!is_dir($fullPath)) {
						mkdir($fullPath, 0755, true);
					}
				}

				$absolutePath = $rootPath . '/themes' . $url;
				file_put_contents($absolutePath, $content);
			}
		}

		// Expédie le type mime détecté au navigateur
		if (isset($mimeTypes[$extension])) {
			header('Content-type: ' . $mimeTypes[$extension]);
		} else {
			switch (strtolower($extension)) {
				case '.css' :
					header('Content-type: text/css');
					break;
				case '.js' :
					header('Content-type: application/x-javascript');
					break;
				case '.jpeg' :
				case '.jpg' :
					header('Content-type: image/jpeg');
					break;
				case '.png' :
					header('Content-type: image/png');
					break;
				default :
					header('Content-type: image/gif');
			}
		}

		// Affichage du type mime
		if (getenv("HTTP_IF_MODIFIED_SINCE") == gmdate("D, d M Y H:i:s", filemtime($fileName)) . " GMT") {
			header("HTTP/1.0 304 Not Modified", true, 304);
			return true;
		}
		$expires = 7201;
		header('Content-Length: ' . strlen($content));
		header('Last-Modified: ' . gmdate('D, d M Y H:i:s', filemtime($fileName)) . ' GMT', true, 200);
		header("Expires: " . gmdate("D, d M Y H:i:s", time() + $expires) . " GMT");
		header("Cache-Control: max-age=$expires");
		header("Pragma: ");
		header("HTTP/1.0 200 OK");
		header("Status: 200 OK");
		echo $content;
		return true;
	}

	/**
	 * Retourne la version relative de la requête, à partir du répertoire d'installation de l'application MPE.
	 *
	 * @param boolean $withQueryString
	 * @return string
	 */
	public static function getUrlRelative($withQueryString = false)
	{
		static $url = null;
		static $urlWithoutQueryString = null;

		if ($url === null) {
			$url = substr($_SERVER['REQUEST_URI'], strpos($_SERVER['SCRIPT_NAME'], '/index.php'));
			$urlWithoutQueryString = preg_replace('/\?.*$/', '', $url);
		}
		if ($withQueryString) {
			return $url;
		}
		if ($urlWithoutQueryString == '/favicon.ico') {
			if (isset($_COOKIE['design']) && is_file("../themes/". $_COOKIE['design'] ."/images/favicon.ico")) {
				$urlWithoutQueryString = '/themes/'.$_COOKIE['design'].'/images/favicon.ico';
				header('Location: /themes/'.$_COOKIE['design'].'/images/favicon.ico');
				exit;
			} else if (is_file("../themes/portal/images/favicon.ico")) {
				if (is_writable('.')){copy("../themes/portal/images/favicon.ico", 'favicon.ico');}
				$urlWithoutQueryString = '/themes/images/favicon.ico';
				header('Location: /themes/images/favicon.ico');
				exit;
			}
			else {
				header("HTTP/1.0 404 Not Found");
				echo "404 Not Found";
				exit(1);
			}
		}
		return $urlWithoutQueryString;
	}

	/**
	 * Test si le fichier statique $filePath est semi-statique.
	 *
	 * Un fichier semi-statique est de type style.css.php et transformé en style.css après interprétation PHP.
	 *
	 * @param string $filePath
	 * @return boolean
	 */
	public static function isStaticPhpFile($filePath)
	{
		return file_exists(file_exists($filePath . '.php'));
	}

	public static function hasThemeSpecifique ($langue)
	{
		return false;
	}
}