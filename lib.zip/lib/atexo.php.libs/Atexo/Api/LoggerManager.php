<?php

/**
 * Classe de log
 * @category Atexo
 * @package Api
 */
class Api_LoggerManager {

	public static function getLogger($fileConfig, $name="")
    {
        Logger::configure($fileConfig);
		return Logger::getLogger($name);
    }
}