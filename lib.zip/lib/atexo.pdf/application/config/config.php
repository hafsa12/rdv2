<?php

define('ODT_PASSEPORT_JEB', './ressources/odt/PasseportRencontreCreation.odt');
define('CHEMIN_TEMPLATE_PDF', '/var/tmp/templates/');
define('CHEMIN_TEMP_PDF', '/var/tmp/');
define('CHEMIN_TEMP', '/tmp/');
