<?php

define('SERVEUR_INDEX', 'http://192.168.0.6/~jimil/atexo.pdf/serveur/index.php');

