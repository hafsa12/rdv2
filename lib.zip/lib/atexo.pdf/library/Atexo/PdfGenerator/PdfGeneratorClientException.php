<?php

class PdfGeneratorClientException extends Exception
{
	
}
