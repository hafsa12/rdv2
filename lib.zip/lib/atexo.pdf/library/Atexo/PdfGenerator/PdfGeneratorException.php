<?php

class PdfGeneratorException extends Exception
{
	
}
