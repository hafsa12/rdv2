<?php
require_once('PdfGenerator/PdfGeneratorClientException.php');
require_once('client/config/config.php');
class DocGeneratorClient
{
	public function genererDoc($odt)
	{  
		$postData = array();
		
		//simulates <input type="file" name="file_name"> 
		$postData[ 'odtFile'] = '@'.$odt;
		$postData[ 'extFile'] = 'doc';
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, SERVEUR_INDEX );
		curl_setopt($ch, CURLOPT_POST, 1 );
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$postResult = curl_exec($ch);
		
		
		if (curl_errno($ch)) {
			throw new PdfGeneratorClientException(curl_error($ch));
		}
		curl_close($ch);
		return  $postResult;
	}
}

