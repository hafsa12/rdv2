<?php

require_once('../serveur/config/config.php');
class PdfGenerator
{
	/**
	 * Enter description here...
	 *
	 * @param string $odt chemin du fichier ODT
	 * @param string $pdf chemin du fichier pdf g�n�r�
	 * 
	 * @return 0 si OK, != 0 sinon
	 */
	public function genererPdf($odt,$pdf)
	{
		
		if($odt && $pdf) {
			@exec(OO_PROGRAM_PATH.'/./python '. OO_PROGRAM_PATH.'/DocumentConverter.py '.$odt.' '.$pdf,$output,$return_value);
			return $return_value;
		}else {
		 	throw new PdfGeneratorException("Le chemin du fichier .odt ou .pdf est vide");
		}
	}
}

		