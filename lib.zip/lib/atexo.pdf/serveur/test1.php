<html>
<head></head>
<body> 
	<form name="form1" enctype="multipart/form-data" method="post" action="index.php"> 
		<input type="file" name="odtFile" id="odtFile" value=""/> <br><br><br>
		<input type="text" name="extFile"  /><br><br>
		<input type="submit" name="Envoyer" value="Envoyer" />		
	</form>
</body>
</html>
