<?php

define('OO_PROGRAM_PATH', '/opt/openoffice.org2.0/program');
define('TMP_PATH', '/tmp');
define('TMP_PASSEPORT_PATH', '/tmp/PasseportRencontreCreation.odt');
define('TMP_ODT_PATH', '/tmp/teste.odt');