<?php



/**
 * Skeleton subclass for representing a row from the 'T_CHAMPS_SUPP' table.
 *
 *
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 * @package    propel.generator.RDV
 */
class TChampsSupp extends BaseTChampsSupp
{
    public function getLibelleChampsSuppTraduit($lang){
        $tTraductionLibelleQuery = new TTraductionLibelleQuery();
        return $tTraductionLibelleQuery->getLibelle($this->getCodeLibelle(), $lang);
    }
}
