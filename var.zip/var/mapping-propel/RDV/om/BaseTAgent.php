<?php


/**
 * Base class that represents a row from the 'T_AGENT' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTAgent extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TAgentPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TAgentPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_agent field.
     * @var        int
     */
    protected $id_agent;

    /**
     * The value for the login field.
     * @var        string
     */
    protected $login;

    /**
     * The value for the mot_de_passe field.
     * @var        string
     */
    protected $mot_de_passe;

    /**
     * The value for the code_nom_utilisateur field.
     * @var        int
     */
    protected $code_nom_utilisateur;

    /**
     * The value for the code_prenom_utilisateur field.
     * @var        int
     */
    protected $code_prenom_utilisateur;

    /**
     * The value for the code_utilisateur field.
     * @var        int
     */
    protected $code_utilisateur;

    /**
     * The value for the email_utilisateur field.
     * @var        string
     */
    protected $email_utilisateur;

    /**
     * The value for the telephone_utilisateur field.
     * @var        string
     */
    protected $telephone_utilisateur;

    /**
     * The value for the id_etablissement_attache field.
     * @var        int
     */
    protected $id_etablissement_attache;

    /**
     * The value for the id_profil field.
     * @var        int
     */
    protected $id_profil;

    /**
     * The value for the id_organisation_attache field.
     * @var        int
     */
    protected $id_organisation_attache;

    /**
     * The value for the tentatives_mdp field.
     * @var        int
     */
    protected $tentatives_mdp;

    /**
     * The value for the id_prestation_attache field.
     * @var        int
     */
    protected $id_prestation_attache;

    /**
     * The value for the id_etablissement_gere field.
     * @var        int
     */
    protected $id_etablissement_gere;

    /**
     * The value for the id_organisation_gere field.
     * @var        int
     */
    protected $id_organisation_gere;

    /**
     * The value for the actif field.
     * Note: this column has a database default value of: 1
     * @var        int
     */
    protected $actif;

    /**
     * The value for the alerte field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $alerte;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeNomUtilisateur;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodePrenomUtilisateur;

    /**
     * @var        TEtablissement
     */
    protected $aTEtablissementRelatedByIdEtablissementAttache;

    /**
     * @var        TEtablissement
     */
    protected $aTEtablissementRelatedByIdEtablissementGere;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisationRelatedByIdOrganisationAttache;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisationRelatedByIdOrganisationGere;

    /**
     * @var        TPrestation
     */
    protected $aTPrestation;

    /**
     * @var        TProfil
     */
    protected $aTProfil;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeUtilisateur;

    /**
     * @var        PropelObjectCollection|TAgenda[] Collection to store aggregation of TAgenda objects.
     */
    protected $collTAgendas;
    protected $collTAgendasPartial;

    /**
     * @var        PropelObjectCollection|TAgentEtablissement[] Collection to store aggregation of TAgentEtablissement objects.
     */
    protected $collTAgentEtablissements;
    protected $collTAgentEtablissementsPartial;

    /**
     * @var        PropelObjectCollection|TAgentPrestation[] Collection to store aggregation of TAgentPrestation objects.
     */
    protected $collTAgentPrestations;
    protected $collTAgentPrestationsPartial;

    /**
     * @var        PropelObjectCollection|TPeriodeIndisponibilite[] Collection to store aggregation of TPeriodeIndisponibilite objects.
     */
    protected $collTPeriodeIndisponibilites;
    protected $collTPeriodeIndisponibilitesPartial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVoussRelatedByIdAgentAccueil;
    protected $collTRendezVoussRelatedByIdAgentAccueilPartial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVoussRelatedByIdAgentAnnulation;
    protected $collTRendezVoussRelatedByIdAgentAnnulationPartial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVoussRelatedByIdAgentConfirmation;
    protected $collTRendezVoussRelatedByIdAgentConfirmationPartial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVoussRelatedByIdAgentRessource;
    protected $collTRendezVoussRelatedByIdAgentRessourcePartial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVoussRelatedByIdAgentTeleoperateur;
    protected $collTRendezVoussRelatedByIdAgentTeleoperateurPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgendasScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentEtablissementsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentPrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPeriodeIndisponibilitesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->actif = 1;
        $this->alerte = '0';
    }

    /**
     * Initializes internal state of BaseTAgent object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_agent] column value.
     *
     * @return int
     */
    public function getIdAgent()
    {
        return $this->id_agent;
    }

    /**
     * Get the [login] column value.
     *
     * @return string
     */
    public function getLogin()
    {
        return $this->login;
    }

    /**
     * Get the [mot_de_passe] column value.
     *
     * @return string
     */
    public function getMotDePasse()
    {
        return $this->mot_de_passe;
    }

    /**
     * Get the [code_nom_utilisateur] column value.
     *
     * @return int
     */
    public function getCodeNomUtilisateur()
    {
        return $this->code_nom_utilisateur;
    }

    /**
     * Get the [code_prenom_utilisateur] column value.
     *
     * @return int
     */
    public function getCodePrenomUtilisateur()
    {
        return $this->code_prenom_utilisateur;
    }

    /**
     * Get the [code_utilisateur] column value.
     *
     * @return int
     */
    public function getCodeUtilisateur()
    {
        return $this->code_utilisateur;
    }

    /**
     * Get the [email_utilisateur] column value.
     *
     * @return string
     */
    public function getEmailUtilisateur()
    {
        return $this->email_utilisateur;
    }

    /**
     * Get the [telephone_utilisateur] column value.
     *
     * @return string
     */
    public function getTelephoneUtilisateur()
    {
        return $this->telephone_utilisateur;
    }

    /**
     * Get the [id_etablissement_attache] column value.
     *
     * @return int
     */
    public function getIdEtablissementAttache()
    {
        return $this->id_etablissement_attache;
    }

    /**
     * Get the [id_profil] column value.
     *
     * @return int
     */
    public function getIdProfil()
    {
        return $this->id_profil;
    }

    /**
     * Get the [id_organisation_attache] column value.
     *
     * @return int
     */
    public function getIdOrganisationAttache()
    {
        return $this->id_organisation_attache;
    }

    /**
     * Get the [tentatives_mdp] column value.
     *
     * @return int
     */
    public function getTentativesMdp()
    {
        return $this->tentatives_mdp;
    }

    /**
     * Get the [id_prestation_attache] column value.
     *
     * @return int
     */
    public function getIdPrestationAttache()
    {
        return $this->id_prestation_attache;
    }

    /**
     * Get the [id_etablissement_gere] column value.
     *
     * @return int
     */
    public function getIdEtablissementGere()
    {
        return $this->id_etablissement_gere;
    }

    /**
     * Get the [id_organisation_gere] column value.
     *
     * @return int
     */
    public function getIdOrganisationGere()
    {
        return $this->id_organisation_gere;
    }

    /**
     * Get the [actif] column value.
     *
     * @return int
     */
    public function getActif()
    {
        return $this->actif;
    }

    /**
     * Get the [alerte] column value.
     *
     * @return string
     */
    public function getAlerte()
    {
        return $this->alerte;
    }

    /**
     * Set the value of [id_agent] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setIdAgent($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_agent !== $v) {
            $this->id_agent = $v;
            $this->modifiedColumns[] = TAgentPeer::ID_AGENT;
        }


        return $this;
    } // setIdAgent()

    /**
     * Set the value of [login] column.
     *
     * @param string $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setLogin($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->login !== $v) {
            $this->login = $v;
            $this->modifiedColumns[] = TAgentPeer::LOGIN;
        }


        return $this;
    } // setLogin()

    /**
     * Set the value of [mot_de_passe] column.
     *
     * @param string $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setMotDePasse($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->mot_de_passe !== $v) {
            $this->mot_de_passe = $v;
            $this->modifiedColumns[] = TAgentPeer::MOT_DE_PASSE;
        }


        return $this;
    } // setMotDePasse()

    /**
     * Set the value of [code_nom_utilisateur] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setCodeNomUtilisateur($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_nom_utilisateur !== $v) {
            $this->code_nom_utilisateur = $v;
            $this->modifiedColumns[] = TAgentPeer::CODE_NOM_UTILISATEUR;
        }

        if ($this->aTTraductionRelatedByCodeNomUtilisateur !== null && $this->aTTraductionRelatedByCodeNomUtilisateur->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeNomUtilisateur = null;
        }


        return $this;
    } // setCodeNomUtilisateur()

    /**
     * Set the value of [code_prenom_utilisateur] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setCodePrenomUtilisateur($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_prenom_utilisateur !== $v) {
            $this->code_prenom_utilisateur = $v;
            $this->modifiedColumns[] = TAgentPeer::CODE_PRENOM_UTILISATEUR;
        }

        if ($this->aTTraductionRelatedByCodePrenomUtilisateur !== null && $this->aTTraductionRelatedByCodePrenomUtilisateur->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodePrenomUtilisateur = null;
        }


        return $this;
    } // setCodePrenomUtilisateur()

    /**
     * Set the value of [code_utilisateur] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setCodeUtilisateur($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_utilisateur !== $v) {
            $this->code_utilisateur = $v;
            $this->modifiedColumns[] = TAgentPeer::CODE_UTILISATEUR;
        }

        if ($this->aTTraductionRelatedByCodeUtilisateur !== null && $this->aTTraductionRelatedByCodeUtilisateur->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeUtilisateur = null;
        }


        return $this;
    } // setCodeUtilisateur()

    /**
     * Set the value of [email_utilisateur] column.
     *
     * @param string $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setEmailUtilisateur($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->email_utilisateur !== $v) {
            $this->email_utilisateur = $v;
            $this->modifiedColumns[] = TAgentPeer::EMAIL_UTILISATEUR;
        }


        return $this;
    } // setEmailUtilisateur()

    /**
     * Set the value of [telephone_utilisateur] column.
     *
     * @param string $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setTelephoneUtilisateur($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->telephone_utilisateur !== $v) {
            $this->telephone_utilisateur = $v;
            $this->modifiedColumns[] = TAgentPeer::TELEPHONE_UTILISATEUR;
        }


        return $this;
    } // setTelephoneUtilisateur()

    /**
     * Set the value of [id_etablissement_attache] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setIdEtablissementAttache($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_etablissement_attache !== $v) {
            $this->id_etablissement_attache = $v;
            $this->modifiedColumns[] = TAgentPeer::ID_ETABLISSEMENT_ATTACHE;
        }

        if ($this->aTEtablissementRelatedByIdEtablissementAttache !== null && $this->aTEtablissementRelatedByIdEtablissementAttache->getIdEtablissement() !== $v) {
            $this->aTEtablissementRelatedByIdEtablissementAttache = null;
        }


        return $this;
    } // setIdEtablissementAttache()

    /**
     * Set the value of [id_profil] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setIdProfil($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_profil !== $v) {
            $this->id_profil = $v;
            $this->modifiedColumns[] = TAgentPeer::ID_PROFIL;
        }

        if ($this->aTProfil !== null && $this->aTProfil->getIdProfil() !== $v) {
            $this->aTProfil = null;
        }


        return $this;
    } // setIdProfil()

    /**
     * Set the value of [id_organisation_attache] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setIdOrganisationAttache($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation_attache !== $v) {
            $this->id_organisation_attache = $v;
            $this->modifiedColumns[] = TAgentPeer::ID_ORGANISATION_ATTACHE;
        }

        if ($this->aTOrganisationRelatedByIdOrganisationAttache !== null && $this->aTOrganisationRelatedByIdOrganisationAttache->getIdOrganisation() !== $v) {
            $this->aTOrganisationRelatedByIdOrganisationAttache = null;
        }


        return $this;
    } // setIdOrganisationAttache()

    /**
     * Set the value of [tentatives_mdp] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setTentativesMdp($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->tentatives_mdp !== $v) {
            $this->tentatives_mdp = $v;
            $this->modifiedColumns[] = TAgentPeer::TENTATIVES_MDP;
        }


        return $this;
    } // setTentativesMdp()

    /**
     * Set the value of [id_prestation_attache] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setIdPrestationAttache($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_prestation_attache !== $v) {
            $this->id_prestation_attache = $v;
            $this->modifiedColumns[] = TAgentPeer::ID_PRESTATION_ATTACHE;
        }

        if ($this->aTPrestation !== null && $this->aTPrestation->getIdPrestation() !== $v) {
            $this->aTPrestation = null;
        }


        return $this;
    } // setIdPrestationAttache()

    /**
     * Set the value of [id_etablissement_gere] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setIdEtablissementGere($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_etablissement_gere !== $v) {
            $this->id_etablissement_gere = $v;
            $this->modifiedColumns[] = TAgentPeer::ID_ETABLISSEMENT_GERE;
        }

        if ($this->aTEtablissementRelatedByIdEtablissementGere !== null && $this->aTEtablissementRelatedByIdEtablissementGere->getIdEtablissement() !== $v) {
            $this->aTEtablissementRelatedByIdEtablissementGere = null;
        }


        return $this;
    } // setIdEtablissementGere()

    /**
     * Set the value of [id_organisation_gere] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setIdOrganisationGere($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation_gere !== $v) {
            $this->id_organisation_gere = $v;
            $this->modifiedColumns[] = TAgentPeer::ID_ORGANISATION_GERE;
        }

        if ($this->aTOrganisationRelatedByIdOrganisationGere !== null && $this->aTOrganisationRelatedByIdOrganisationGere->getIdOrganisation() !== $v) {
            $this->aTOrganisationRelatedByIdOrganisationGere = null;
        }


        return $this;
    } // setIdOrganisationGere()

    /**
     * Set the value of [actif] column.
     *
     * @param int $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setActif($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->actif !== $v) {
            $this->actif = $v;
            $this->modifiedColumns[] = TAgentPeer::ACTIF;
        }


        return $this;
    } // setActif()

    /**
     * Set the value of [alerte] column.
     *
     * @param string $v new value
     * @return TAgent The current object (for fluent API support)
     */
    public function setAlerte($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->alerte !== $v) {
            $this->alerte = $v;
            $this->modifiedColumns[] = TAgentPeer::ALERTE;
        }


        return $this;
    } // setAlerte()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->actif !== 1) {
                return false;
            }

            if ($this->alerte !== '0') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_agent = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->login = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->mot_de_passe = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->code_nom_utilisateur = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->code_prenom_utilisateur = ($row[$startcol + 4] !== null) ? (int) $row[$startcol + 4] : null;
            $this->code_utilisateur = ($row[$startcol + 5] !== null) ? (int) $row[$startcol + 5] : null;
            $this->email_utilisateur = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->telephone_utilisateur = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->id_etablissement_attache = ($row[$startcol + 8] !== null) ? (int) $row[$startcol + 8] : null;
            $this->id_profil = ($row[$startcol + 9] !== null) ? (int) $row[$startcol + 9] : null;
            $this->id_organisation_attache = ($row[$startcol + 10] !== null) ? (int) $row[$startcol + 10] : null;
            $this->tentatives_mdp = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->id_prestation_attache = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->id_etablissement_gere = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->id_organisation_gere = ($row[$startcol + 14] !== null) ? (int) $row[$startcol + 14] : null;
            $this->actif = ($row[$startcol + 15] !== null) ? (int) $row[$startcol + 15] : null;
            $this->alerte = ($row[$startcol + 16] !== null) ? (string) $row[$startcol + 16] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 17; // 17 = TAgentPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TAgent object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTTraductionRelatedByCodeNomUtilisateur !== null && $this->code_nom_utilisateur !== $this->aTTraductionRelatedByCodeNomUtilisateur->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeNomUtilisateur = null;
        }
        if ($this->aTTraductionRelatedByCodePrenomUtilisateur !== null && $this->code_prenom_utilisateur !== $this->aTTraductionRelatedByCodePrenomUtilisateur->getIdTraduction()) {
            $this->aTTraductionRelatedByCodePrenomUtilisateur = null;
        }
        if ($this->aTTraductionRelatedByCodeUtilisateur !== null && $this->code_utilisateur !== $this->aTTraductionRelatedByCodeUtilisateur->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeUtilisateur = null;
        }
        if ($this->aTEtablissementRelatedByIdEtablissementAttache !== null && $this->id_etablissement_attache !== $this->aTEtablissementRelatedByIdEtablissementAttache->getIdEtablissement()) {
            $this->aTEtablissementRelatedByIdEtablissementAttache = null;
        }
        if ($this->aTProfil !== null && $this->id_profil !== $this->aTProfil->getIdProfil()) {
            $this->aTProfil = null;
        }
        if ($this->aTOrganisationRelatedByIdOrganisationAttache !== null && $this->id_organisation_attache !== $this->aTOrganisationRelatedByIdOrganisationAttache->getIdOrganisation()) {
            $this->aTOrganisationRelatedByIdOrganisationAttache = null;
        }
        if ($this->aTPrestation !== null && $this->id_prestation_attache !== $this->aTPrestation->getIdPrestation()) {
            $this->aTPrestation = null;
        }
        if ($this->aTEtablissementRelatedByIdEtablissementGere !== null && $this->id_etablissement_gere !== $this->aTEtablissementRelatedByIdEtablissementGere->getIdEtablissement()) {
            $this->aTEtablissementRelatedByIdEtablissementGere = null;
        }
        if ($this->aTOrganisationRelatedByIdOrganisationGere !== null && $this->id_organisation_gere !== $this->aTOrganisationRelatedByIdOrganisationGere->getIdOrganisation()) {
            $this->aTOrganisationRelatedByIdOrganisationGere = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TAgentPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TAgentPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraductionRelatedByCodeNomUtilisateur = null;
            $this->aTTraductionRelatedByCodePrenomUtilisateur = null;
            $this->aTEtablissementRelatedByIdEtablissementAttache = null;
            $this->aTEtablissementRelatedByIdEtablissementGere = null;
            $this->aTOrganisationRelatedByIdOrganisationAttache = null;
            $this->aTOrganisationRelatedByIdOrganisationGere = null;
            $this->aTPrestation = null;
            $this->aTProfil = null;
            $this->aTTraductionRelatedByCodeUtilisateur = null;
            $this->collTAgendas = null;

            $this->collTAgentEtablissements = null;

            $this->collTAgentPrestations = null;

            $this->collTPeriodeIndisponibilites = null;

            $this->collTRendezVoussRelatedByIdAgentAccueil = null;

            $this->collTRendezVoussRelatedByIdAgentAnnulation = null;

            $this->collTRendezVoussRelatedByIdAgentConfirmation = null;

            $this->collTRendezVoussRelatedByIdAgentRessource = null;

            $this->collTRendezVoussRelatedByIdAgentTeleoperateur = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TAgentPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TAgentQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TAgentPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TAgentPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeNomUtilisateur !== null) {
                if ($this->aTTraductionRelatedByCodeNomUtilisateur->isModified() || $this->aTTraductionRelatedByCodeNomUtilisateur->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeNomUtilisateur->save($con);
                }
                $this->setTTraductionRelatedByCodeNomUtilisateur($this->aTTraductionRelatedByCodeNomUtilisateur);
            }

            if ($this->aTTraductionRelatedByCodePrenomUtilisateur !== null) {
                if ($this->aTTraductionRelatedByCodePrenomUtilisateur->isModified() || $this->aTTraductionRelatedByCodePrenomUtilisateur->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodePrenomUtilisateur->save($con);
                }
                $this->setTTraductionRelatedByCodePrenomUtilisateur($this->aTTraductionRelatedByCodePrenomUtilisateur);
            }

            if ($this->aTEtablissementRelatedByIdEtablissementAttache !== null) {
                if ($this->aTEtablissementRelatedByIdEtablissementAttache->isModified() || $this->aTEtablissementRelatedByIdEtablissementAttache->isNew()) {
                    $affectedRows += $this->aTEtablissementRelatedByIdEtablissementAttache->save($con);
                }
                $this->setTEtablissementRelatedByIdEtablissementAttache($this->aTEtablissementRelatedByIdEtablissementAttache);
            }

            if ($this->aTEtablissementRelatedByIdEtablissementGere !== null) {
                if ($this->aTEtablissementRelatedByIdEtablissementGere->isModified() || $this->aTEtablissementRelatedByIdEtablissementGere->isNew()) {
                    $affectedRows += $this->aTEtablissementRelatedByIdEtablissementGere->save($con);
                }
                $this->setTEtablissementRelatedByIdEtablissementGere($this->aTEtablissementRelatedByIdEtablissementGere);
            }

            if ($this->aTOrganisationRelatedByIdOrganisationAttache !== null) {
                if ($this->aTOrganisationRelatedByIdOrganisationAttache->isModified() || $this->aTOrganisationRelatedByIdOrganisationAttache->isNew()) {
                    $affectedRows += $this->aTOrganisationRelatedByIdOrganisationAttache->save($con);
                }
                $this->setTOrganisationRelatedByIdOrganisationAttache($this->aTOrganisationRelatedByIdOrganisationAttache);
            }

            if ($this->aTOrganisationRelatedByIdOrganisationGere !== null) {
                if ($this->aTOrganisationRelatedByIdOrganisationGere->isModified() || $this->aTOrganisationRelatedByIdOrganisationGere->isNew()) {
                    $affectedRows += $this->aTOrganisationRelatedByIdOrganisationGere->save($con);
                }
                $this->setTOrganisationRelatedByIdOrganisationGere($this->aTOrganisationRelatedByIdOrganisationGere);
            }

            if ($this->aTPrestation !== null) {
                if ($this->aTPrestation->isModified() || $this->aTPrestation->isNew()) {
                    $affectedRows += $this->aTPrestation->save($con);
                }
                $this->setTPrestation($this->aTPrestation);
            }

            if ($this->aTProfil !== null) {
                if ($this->aTProfil->isModified() || $this->aTProfil->isNew()) {
                    $affectedRows += $this->aTProfil->save($con);
                }
                $this->setTProfil($this->aTProfil);
            }

            if ($this->aTTraductionRelatedByCodeUtilisateur !== null) {
                if ($this->aTTraductionRelatedByCodeUtilisateur->isModified() || $this->aTTraductionRelatedByCodeUtilisateur->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeUtilisateur->save($con);
                }
                $this->setTTraductionRelatedByCodeUtilisateur($this->aTTraductionRelatedByCodeUtilisateur);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tAgendasScheduledForDeletion !== null) {
                if (!$this->tAgendasScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgendasScheduledForDeletion as $tAgenda) {
                        // need to save related object because we set the relation to null
                        $tAgenda->save($con);
                    }
                    $this->tAgendasScheduledForDeletion = null;
                }
            }

            if ($this->collTAgendas !== null) {
                foreach ($this->collTAgendas as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentEtablissementsScheduledForDeletion !== null) {
                if (!$this->tAgentEtablissementsScheduledForDeletion->isEmpty()) {
                    TAgentEtablissementQuery::create()
                        ->filterByPrimaryKeys($this->tAgentEtablissementsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tAgentEtablissementsScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentEtablissements !== null) {
                foreach ($this->collTAgentEtablissements as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentPrestationsScheduledForDeletion !== null) {
                if (!$this->tAgentPrestationsScheduledForDeletion->isEmpty()) {
                    TAgentPrestationQuery::create()
                        ->filterByPrimaryKeys($this->tAgentPrestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tAgentPrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentPrestations !== null) {
                foreach ($this->collTAgentPrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPeriodeIndisponibilitesScheduledForDeletion !== null) {
                if (!$this->tPeriodeIndisponibilitesScheduledForDeletion->isEmpty()) {
                    TPeriodeIndisponibiliteQuery::create()
                        ->filterByPrimaryKeys($this->tPeriodeIndisponibilitesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tPeriodeIndisponibilitesScheduledForDeletion = null;
                }
            }

            if ($this->collTPeriodeIndisponibilites !== null) {
                foreach ($this->collTPeriodeIndisponibilites as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion !== null) {
                if (!$this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion->isEmpty()) {
                    foreach ($this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion as $tRendezVousRelatedByIdAgentAccueil) {
                        // need to save related object because we set the relation to null
                        $tRendezVousRelatedByIdAgentAccueil->save($con);
                    }
                    $this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVoussRelatedByIdAgentAccueil !== null) {
                foreach ($this->collTRendezVoussRelatedByIdAgentAccueil as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion !== null) {
                if (!$this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion->isEmpty()) {
                    foreach ($this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion as $tRendezVousRelatedByIdAgentAnnulation) {
                        // need to save related object because we set the relation to null
                        $tRendezVousRelatedByIdAgentAnnulation->save($con);
                    }
                    $this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVoussRelatedByIdAgentAnnulation !== null) {
                foreach ($this->collTRendezVoussRelatedByIdAgentAnnulation as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion !== null) {
                if (!$this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion->isEmpty()) {
                    foreach ($this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion as $tRendezVousRelatedByIdAgentConfirmation) {
                        // need to save related object because we set the relation to null
                        $tRendezVousRelatedByIdAgentConfirmation->save($con);
                    }
                    $this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVoussRelatedByIdAgentConfirmation !== null) {
                foreach ($this->collTRendezVoussRelatedByIdAgentConfirmation as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion !== null) {
                if (!$this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion->isEmpty()) {
                    foreach ($this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion as $tRendezVousRelatedByIdAgentRessource) {
                        // need to save related object because we set the relation to null
                        $tRendezVousRelatedByIdAgentRessource->save($con);
                    }
                    $this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVoussRelatedByIdAgentRessource !== null) {
                foreach ($this->collTRendezVoussRelatedByIdAgentRessource as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion !== null) {
                if (!$this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion->isEmpty()) {
                    foreach ($this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion as $tRendezVousRelatedByIdAgentTeleoperateur) {
                        // need to save related object because we set the relation to null
                        $tRendezVousRelatedByIdAgentTeleoperateur->save($con);
                    }
                    $this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVoussRelatedByIdAgentTeleoperateur !== null) {
                foreach ($this->collTRendezVoussRelatedByIdAgentTeleoperateur as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TAgentPeer::ID_AGENT;
        if (null !== $this->id_agent) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TAgentPeer::ID_AGENT . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TAgentPeer::ID_AGENT)) {
            $modifiedColumns[':p' . $index++]  = '`ID_AGENT`';
        }
        if ($this->isColumnModified(TAgentPeer::LOGIN)) {
            $modifiedColumns[':p' . $index++]  = '`LOGIN`';
        }
        if ($this->isColumnModified(TAgentPeer::MOT_DE_PASSE)) {
            $modifiedColumns[':p' . $index++]  = '`MOT_DE_PASSE`';
        }
        if ($this->isColumnModified(TAgentPeer::CODE_NOM_UTILISATEUR)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_NOM_UTILISATEUR`';
        }
        if ($this->isColumnModified(TAgentPeer::CODE_PRENOM_UTILISATEUR)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_PRENOM_UTILISATEUR`';
        }
        if ($this->isColumnModified(TAgentPeer::CODE_UTILISATEUR)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_UTILISATEUR`';
        }
        if ($this->isColumnModified(TAgentPeer::EMAIL_UTILISATEUR)) {
            $modifiedColumns[':p' . $index++]  = '`EMAIL_UTILISATEUR`';
        }
        if ($this->isColumnModified(TAgentPeer::TELEPHONE_UTILISATEUR)) {
            $modifiedColumns[':p' . $index++]  = '`TELEPHONE_UTILISATEUR`';
        }
        if ($this->isColumnModified(TAgentPeer::ID_ETABLISSEMENT_ATTACHE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ETABLISSEMENT_ATTACHE`';
        }
        if ($this->isColumnModified(TAgentPeer::ID_PROFIL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PROFIL`';
        }
        if ($this->isColumnModified(TAgentPeer::ID_ORGANISATION_ATTACHE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION_ATTACHE`';
        }
        if ($this->isColumnModified(TAgentPeer::TENTATIVES_MDP)) {
            $modifiedColumns[':p' . $index++]  = '`TENTATIVES_MDP`';
        }
        if ($this->isColumnModified(TAgentPeer::ID_PRESTATION_ATTACHE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PRESTATION_ATTACHE`';
        }
        if ($this->isColumnModified(TAgentPeer::ID_ETABLISSEMENT_GERE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ETABLISSEMENT_GERE`';
        }
        if ($this->isColumnModified(TAgentPeer::ID_ORGANISATION_GERE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION_GERE`';
        }
        if ($this->isColumnModified(TAgentPeer::ACTIF)) {
            $modifiedColumns[':p' . $index++]  = '`ACTIF`';
        }
        if ($this->isColumnModified(TAgentPeer::ALERTE)) {
            $modifiedColumns[':p' . $index++]  = '`ALERTE`';
        }

        $sql = sprintf(
            'INSERT INTO `T_AGENT` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_AGENT`':
                        $stmt->bindValue($identifier, $this->id_agent, PDO::PARAM_INT);
                        break;
                    case '`LOGIN`':
                        $stmt->bindValue($identifier, $this->login, PDO::PARAM_STR);
                        break;
                    case '`MOT_DE_PASSE`':
                        $stmt->bindValue($identifier, $this->mot_de_passe, PDO::PARAM_STR);
                        break;
                    case '`CODE_NOM_UTILISATEUR`':
                        $stmt->bindValue($identifier, $this->code_nom_utilisateur, PDO::PARAM_INT);
                        break;
                    case '`CODE_PRENOM_UTILISATEUR`':
                        $stmt->bindValue($identifier, $this->code_prenom_utilisateur, PDO::PARAM_INT);
                        break;
                    case '`CODE_UTILISATEUR`':
                        $stmt->bindValue($identifier, $this->code_utilisateur, PDO::PARAM_INT);
                        break;
                    case '`EMAIL_UTILISATEUR`':
                        $stmt->bindValue($identifier, $this->email_utilisateur, PDO::PARAM_STR);
                        break;
                    case '`TELEPHONE_UTILISATEUR`':
                        $stmt->bindValue($identifier, $this->telephone_utilisateur, PDO::PARAM_STR);
                        break;
                    case '`ID_ETABLISSEMENT_ATTACHE`':
                        $stmt->bindValue($identifier, $this->id_etablissement_attache, PDO::PARAM_INT);
                        break;
                    case '`ID_PROFIL`':
                        $stmt->bindValue($identifier, $this->id_profil, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION_ATTACHE`':
                        $stmt->bindValue($identifier, $this->id_organisation_attache, PDO::PARAM_INT);
                        break;
                    case '`TENTATIVES_MDP`':
                        $stmt->bindValue($identifier, $this->tentatives_mdp, PDO::PARAM_INT);
                        break;
                    case '`ID_PRESTATION_ATTACHE`':
                        $stmt->bindValue($identifier, $this->id_prestation_attache, PDO::PARAM_INT);
                        break;
                    case '`ID_ETABLISSEMENT_GERE`':
                        $stmt->bindValue($identifier, $this->id_etablissement_gere, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION_GERE`':
                        $stmt->bindValue($identifier, $this->id_organisation_gere, PDO::PARAM_INT);
                        break;
                    case '`ACTIF`':
                        $stmt->bindValue($identifier, $this->actif, PDO::PARAM_INT);
                        break;
                    case '`ALERTE`':
                        $stmt->bindValue($identifier, $this->alerte, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdAgent($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeNomUtilisateur !== null) {
                if (!$this->aTTraductionRelatedByCodeNomUtilisateur->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeNomUtilisateur->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodePrenomUtilisateur !== null) {
                if (!$this->aTTraductionRelatedByCodePrenomUtilisateur->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodePrenomUtilisateur->getValidationFailures());
                }
            }

            if ($this->aTEtablissementRelatedByIdEtablissementAttache !== null) {
                if (!$this->aTEtablissementRelatedByIdEtablissementAttache->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTEtablissementRelatedByIdEtablissementAttache->getValidationFailures());
                }
            }

            if ($this->aTEtablissementRelatedByIdEtablissementGere !== null) {
                if (!$this->aTEtablissementRelatedByIdEtablissementGere->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTEtablissementRelatedByIdEtablissementGere->getValidationFailures());
                }
            }

            if ($this->aTOrganisationRelatedByIdOrganisationAttache !== null) {
                if (!$this->aTOrganisationRelatedByIdOrganisationAttache->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisationRelatedByIdOrganisationAttache->getValidationFailures());
                }
            }

            if ($this->aTOrganisationRelatedByIdOrganisationGere !== null) {
                if (!$this->aTOrganisationRelatedByIdOrganisationGere->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisationRelatedByIdOrganisationGere->getValidationFailures());
                }
            }

            if ($this->aTPrestation !== null) {
                if (!$this->aTPrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTPrestation->getValidationFailures());
                }
            }

            if ($this->aTProfil !== null) {
                if (!$this->aTProfil->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTProfil->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeUtilisateur !== null) {
                if (!$this->aTTraductionRelatedByCodeUtilisateur->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeUtilisateur->getValidationFailures());
                }
            }


            if (($retval = TAgentPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTAgendas !== null) {
                    foreach ($this->collTAgendas as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgentEtablissements !== null) {
                    foreach ($this->collTAgentEtablissements as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgentPrestations !== null) {
                    foreach ($this->collTAgentPrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPeriodeIndisponibilites !== null) {
                    foreach ($this->collTPeriodeIndisponibilites as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVoussRelatedByIdAgentAccueil !== null) {
                    foreach ($this->collTRendezVoussRelatedByIdAgentAccueil as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVoussRelatedByIdAgentAnnulation !== null) {
                    foreach ($this->collTRendezVoussRelatedByIdAgentAnnulation as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVoussRelatedByIdAgentConfirmation !== null) {
                    foreach ($this->collTRendezVoussRelatedByIdAgentConfirmation as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVoussRelatedByIdAgentRessource !== null) {
                    foreach ($this->collTRendezVoussRelatedByIdAgentRessource as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVoussRelatedByIdAgentTeleoperateur !== null) {
                    foreach ($this->collTRendezVoussRelatedByIdAgentTeleoperateur as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TAgentPeer::DATABASE_NAME);

        if ($this->isColumnModified(TAgentPeer::ID_AGENT)) $criteria->add(TAgentPeer::ID_AGENT, $this->id_agent);
        if ($this->isColumnModified(TAgentPeer::LOGIN)) $criteria->add(TAgentPeer::LOGIN, $this->login);
        if ($this->isColumnModified(TAgentPeer::MOT_DE_PASSE)) $criteria->add(TAgentPeer::MOT_DE_PASSE, $this->mot_de_passe);
        if ($this->isColumnModified(TAgentPeer::CODE_NOM_UTILISATEUR)) $criteria->add(TAgentPeer::CODE_NOM_UTILISATEUR, $this->code_nom_utilisateur);
        if ($this->isColumnModified(TAgentPeer::CODE_PRENOM_UTILISATEUR)) $criteria->add(TAgentPeer::CODE_PRENOM_UTILISATEUR, $this->code_prenom_utilisateur);
        if ($this->isColumnModified(TAgentPeer::CODE_UTILISATEUR)) $criteria->add(TAgentPeer::CODE_UTILISATEUR, $this->code_utilisateur);
        if ($this->isColumnModified(TAgentPeer::EMAIL_UTILISATEUR)) $criteria->add(TAgentPeer::EMAIL_UTILISATEUR, $this->email_utilisateur);
        if ($this->isColumnModified(TAgentPeer::TELEPHONE_UTILISATEUR)) $criteria->add(TAgentPeer::TELEPHONE_UTILISATEUR, $this->telephone_utilisateur);
        if ($this->isColumnModified(TAgentPeer::ID_ETABLISSEMENT_ATTACHE)) $criteria->add(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $this->id_etablissement_attache);
        if ($this->isColumnModified(TAgentPeer::ID_PROFIL)) $criteria->add(TAgentPeer::ID_PROFIL, $this->id_profil);
        if ($this->isColumnModified(TAgentPeer::ID_ORGANISATION_ATTACHE)) $criteria->add(TAgentPeer::ID_ORGANISATION_ATTACHE, $this->id_organisation_attache);
        if ($this->isColumnModified(TAgentPeer::TENTATIVES_MDP)) $criteria->add(TAgentPeer::TENTATIVES_MDP, $this->tentatives_mdp);
        if ($this->isColumnModified(TAgentPeer::ID_PRESTATION_ATTACHE)) $criteria->add(TAgentPeer::ID_PRESTATION_ATTACHE, $this->id_prestation_attache);
        if ($this->isColumnModified(TAgentPeer::ID_ETABLISSEMENT_GERE)) $criteria->add(TAgentPeer::ID_ETABLISSEMENT_GERE, $this->id_etablissement_gere);
        if ($this->isColumnModified(TAgentPeer::ID_ORGANISATION_GERE)) $criteria->add(TAgentPeer::ID_ORGANISATION_GERE, $this->id_organisation_gere);
        if ($this->isColumnModified(TAgentPeer::ACTIF)) $criteria->add(TAgentPeer::ACTIF, $this->actif);
        if ($this->isColumnModified(TAgentPeer::ALERTE)) $criteria->add(TAgentPeer::ALERTE, $this->alerte);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TAgentPeer::DATABASE_NAME);
        $criteria->add(TAgentPeer::ID_AGENT, $this->id_agent);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdAgent();
    }

    /**
     * Generic method to set the primary key (id_agent column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdAgent($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdAgent();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TAgent (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setLogin($this->getLogin());
        $copyObj->setMotDePasse($this->getMotDePasse());
        $copyObj->setCodeNomUtilisateur($this->getCodeNomUtilisateur());
        $copyObj->setCodePrenomUtilisateur($this->getCodePrenomUtilisateur());
        $copyObj->setCodeUtilisateur($this->getCodeUtilisateur());
        $copyObj->setEmailUtilisateur($this->getEmailUtilisateur());
        $copyObj->setTelephoneUtilisateur($this->getTelephoneUtilisateur());
        $copyObj->setIdEtablissementAttache($this->getIdEtablissementAttache());
        $copyObj->setIdProfil($this->getIdProfil());
        $copyObj->setIdOrganisationAttache($this->getIdOrganisationAttache());
        $copyObj->setTentativesMdp($this->getTentativesMdp());
        $copyObj->setIdPrestationAttache($this->getIdPrestationAttache());
        $copyObj->setIdEtablissementGere($this->getIdEtablissementGere());
        $copyObj->setIdOrganisationGere($this->getIdOrganisationGere());
        $copyObj->setActif($this->getActif());
        $copyObj->setAlerte($this->getAlerte());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTAgendas() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgenda($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgentEtablissements() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentEtablissement($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgentPrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentPrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPeriodeIndisponibilites() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPeriodeIndisponibilite($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVoussRelatedByIdAgentAccueil() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVousRelatedByIdAgentAccueil($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVoussRelatedByIdAgentAnnulation() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVousRelatedByIdAgentAnnulation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVoussRelatedByIdAgentConfirmation() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVousRelatedByIdAgentConfirmation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVoussRelatedByIdAgentRessource() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVousRelatedByIdAgentRessource($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVoussRelatedByIdAgentTeleoperateur() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVousRelatedByIdAgentTeleoperateur($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdAgent(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TAgent Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TAgentPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TAgentPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeNomUtilisateur(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeNomUtilisateur(NULL);
        } else {
            $this->setCodeNomUtilisateur($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeNomUtilisateur = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgentRelatedByCodeNomUtilisateur($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeNomUtilisateur(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeNomUtilisateur === null && ($this->code_nom_utilisateur !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeNomUtilisateur = TTraductionQuery::create()->findPk($this->code_nom_utilisateur, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeNomUtilisateur->addTAgentsRelatedByCodeNomUtilisateur($this);
             */
        }

        return $this->aTTraductionRelatedByCodeNomUtilisateur;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodePrenomUtilisateur(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodePrenomUtilisateur(NULL);
        } else {
            $this->setCodePrenomUtilisateur($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodePrenomUtilisateur = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgentRelatedByCodePrenomUtilisateur($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodePrenomUtilisateur(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodePrenomUtilisateur === null && ($this->code_prenom_utilisateur !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodePrenomUtilisateur = TTraductionQuery::create()->findPk($this->code_prenom_utilisateur, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodePrenomUtilisateur->addTAgentsRelatedByCodePrenomUtilisateur($this);
             */
        }

        return $this->aTTraductionRelatedByCodePrenomUtilisateur;
    }

    /**
     * Declares an association between this object and a TEtablissement object.
     *
     * @param             TEtablissement $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTEtablissementRelatedByIdEtablissementAttache(TEtablissement $v = null)
    {
        if ($v === null) {
            $this->setIdEtablissementAttache(NULL);
        } else {
            $this->setIdEtablissementAttache($v->getIdEtablissement());
        }

        $this->aTEtablissementRelatedByIdEtablissementAttache = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TEtablissement object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgentRelatedByIdEtablissementAttache($this);
        }


        return $this;
    }


    /**
     * Get the associated TEtablissement object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TEtablissement The associated TEtablissement object.
     * @throws PropelException
     */
    public function getTEtablissementRelatedByIdEtablissementAttache(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTEtablissementRelatedByIdEtablissementAttache === null && ($this->id_etablissement_attache !== null) && $doQuery) {
            $this->aTEtablissementRelatedByIdEtablissementAttache = TEtablissementQuery::create()->findPk($this->id_etablissement_attache, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTEtablissementRelatedByIdEtablissementAttache->addTAgentsRelatedByIdEtablissementAttache($this);
             */
        }

        return $this->aTEtablissementRelatedByIdEtablissementAttache;
    }

    /**
     * Declares an association between this object and a TEtablissement object.
     *
     * @param             TEtablissement $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTEtablissementRelatedByIdEtablissementGere(TEtablissement $v = null)
    {
        if ($v === null) {
            $this->setIdEtablissementGere(NULL);
        } else {
            $this->setIdEtablissementGere($v->getIdEtablissement());
        }

        $this->aTEtablissementRelatedByIdEtablissementGere = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TEtablissement object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgentRelatedByIdEtablissementGere($this);
        }


        return $this;
    }


    /**
     * Get the associated TEtablissement object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TEtablissement The associated TEtablissement object.
     * @throws PropelException
     */
    public function getTEtablissementRelatedByIdEtablissementGere(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTEtablissementRelatedByIdEtablissementGere === null && ($this->id_etablissement_gere !== null) && $doQuery) {
            $this->aTEtablissementRelatedByIdEtablissementGere = TEtablissementQuery::create()->findPk($this->id_etablissement_gere, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTEtablissementRelatedByIdEtablissementGere->addTAgentsRelatedByIdEtablissementGere($this);
             */
        }

        return $this->aTEtablissementRelatedByIdEtablissementGere;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisationRelatedByIdOrganisationAttache(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisationAttache(NULL);
        } else {
            $this->setIdOrganisationAttache($v->getIdOrganisation());
        }

        $this->aTOrganisationRelatedByIdOrganisationAttache = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgentRelatedByIdOrganisationAttache($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisationRelatedByIdOrganisationAttache(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisationRelatedByIdOrganisationAttache === null && ($this->id_organisation_attache !== null) && $doQuery) {
            $this->aTOrganisationRelatedByIdOrganisationAttache = TOrganisationQuery::create()->findPk($this->id_organisation_attache, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisationRelatedByIdOrganisationAttache->addTAgentsRelatedByIdOrganisationAttache($this);
             */
        }

        return $this->aTOrganisationRelatedByIdOrganisationAttache;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisationRelatedByIdOrganisationGere(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisationGere(NULL);
        } else {
            $this->setIdOrganisationGere($v->getIdOrganisation());
        }

        $this->aTOrganisationRelatedByIdOrganisationGere = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgentRelatedByIdOrganisationGere($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisationRelatedByIdOrganisationGere(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisationRelatedByIdOrganisationGere === null && ($this->id_organisation_gere !== null) && $doQuery) {
            $this->aTOrganisationRelatedByIdOrganisationGere = TOrganisationQuery::create()->findPk($this->id_organisation_gere, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisationRelatedByIdOrganisationGere->addTAgentsRelatedByIdOrganisationGere($this);
             */
        }

        return $this->aTOrganisationRelatedByIdOrganisationGere;
    }

    /**
     * Declares an association between this object and a TPrestation object.
     *
     * @param             TPrestation $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTPrestation(TPrestation $v = null)
    {
        if ($v === null) {
            $this->setIdPrestationAttache(NULL);
        } else {
            $this->setIdPrestationAttache($v->getIdPrestation());
        }

        $this->aTPrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TPrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgent($this);
        }


        return $this;
    }


    /**
     * Get the associated TPrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TPrestation The associated TPrestation object.
     * @throws PropelException
     */
    public function getTPrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTPrestation === null && ($this->id_prestation_attache !== null) && $doQuery) {
            $this->aTPrestation = TPrestationQuery::create()->findPk($this->id_prestation_attache, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTPrestation->addTAgents($this);
             */
        }

        return $this->aTPrestation;
    }

    /**
     * Declares an association between this object and a TProfil object.
     *
     * @param             TProfil $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTProfil(TProfil $v = null)
    {
        if ($v === null) {
            $this->setIdProfil(NULL);
        } else {
            $this->setIdProfil($v->getIdProfil());
        }

        $this->aTProfil = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TProfil object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgent($this);
        }


        return $this;
    }


    /**
     * Get the associated TProfil object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TProfil The associated TProfil object.
     * @throws PropelException
     */
    public function getTProfil(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTProfil === null && ($this->id_profil !== null) && $doQuery) {
            $this->aTProfil = TProfilQuery::create()->findPk($this->id_profil, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTProfil->addTAgents($this);
             */
        }

        return $this->aTProfil;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TAgent The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeUtilisateur(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeUtilisateur(NULL);
        } else {
            $this->setCodeUtilisateur($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeUtilisateur = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTAgentRelatedByCodeUtilisateur($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeUtilisateur(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeUtilisateur === null && ($this->code_utilisateur !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeUtilisateur = TTraductionQuery::create()->findPk($this->code_utilisateur, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeUtilisateur->addTAgentsRelatedByCodeUtilisateur($this);
             */
        }

        return $this->aTTraductionRelatedByCodeUtilisateur;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TAgenda' == $relationName) {
            $this->initTAgendas();
        }
        if ('TAgentEtablissement' == $relationName) {
            $this->initTAgentEtablissements();
        }
        if ('TAgentPrestation' == $relationName) {
            $this->initTAgentPrestations();
        }
        if ('TPeriodeIndisponibilite' == $relationName) {
            $this->initTPeriodeIndisponibilites();
        }
        if ('TRendezVousRelatedByIdAgentAccueil' == $relationName) {
            $this->initTRendezVoussRelatedByIdAgentAccueil();
        }
        if ('TRendezVousRelatedByIdAgentAnnulation' == $relationName) {
            $this->initTRendezVoussRelatedByIdAgentAnnulation();
        }
        if ('TRendezVousRelatedByIdAgentConfirmation' == $relationName) {
            $this->initTRendezVoussRelatedByIdAgentConfirmation();
        }
        if ('TRendezVousRelatedByIdAgentRessource' == $relationName) {
            $this->initTRendezVoussRelatedByIdAgentRessource();
        }
        if ('TRendezVousRelatedByIdAgentTeleoperateur' == $relationName) {
            $this->initTRendezVoussRelatedByIdAgentTeleoperateur();
        }
    }

    /**
     * Clears out the collTAgendas collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTAgendas()
     */
    public function clearTAgendas()
    {
        $this->collTAgendas = null; // important to set this to null since that means it is uninitialized
        $this->collTAgendasPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgendas collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgendas($v = true)
    {
        $this->collTAgendasPartial = $v;
    }

    /**
     * Initializes the collTAgendas collection.
     *
     * By default this just sets the collTAgendas collection to an empty array (like clearcollTAgendas());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgendas($overrideExisting = true)
    {
        if (null !== $this->collTAgendas && !$overrideExisting) {
            return;
        }
        $this->collTAgendas = new PropelObjectCollection();
        $this->collTAgendas->setModel('TAgenda');
    }

    /**
     * Gets an array of TAgenda objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgenda[] List of TAgenda objects
     * @throws PropelException
     */
    public function getTAgendas($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgendasPartial && !$this->isNew();
        if (null === $this->collTAgendas || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgendas) {
                // return empty collection
                $this->initTAgendas();
            } else {
                $collTAgendas = TAgendaQuery::create(null, $criteria)
                    ->filterByTAgent($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgendasPartial && count($collTAgendas)) {
                      $this->initTAgendas(false);

                      foreach($collTAgendas as $obj) {
                        if (false == $this->collTAgendas->contains($obj)) {
                          $this->collTAgendas->append($obj);
                        }
                      }

                      $this->collTAgendasPartial = true;
                    }

                    $collTAgendas->getInternalIterator()->rewind();
                    return $collTAgendas;
                }

                if($partial && $this->collTAgendas) {
                    foreach($this->collTAgendas as $obj) {
                        if($obj->isNew()) {
                            $collTAgendas[] = $obj;
                        }
                    }
                }

                $this->collTAgendas = $collTAgendas;
                $this->collTAgendasPartial = false;
            }
        }

        return $this->collTAgendas;
    }

    /**
     * Sets a collection of TAgenda objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgendas A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTAgendas(PropelCollection $tAgendas, PropelPDO $con = null)
    {
        $tAgendasToDelete = $this->getTAgendas(new Criteria(), $con)->diff($tAgendas);

        $this->tAgendasScheduledForDeletion = unserialize(serialize($tAgendasToDelete));

        foreach ($tAgendasToDelete as $tAgendaRemoved) {
            $tAgendaRemoved->setTAgent(null);
        }

        $this->collTAgendas = null;
        foreach ($tAgendas as $tAgenda) {
            $this->addTAgenda($tAgenda);
        }

        $this->collTAgendas = $tAgendas;
        $this->collTAgendasPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgenda objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgenda objects.
     * @throws PropelException
     */
    public function countTAgendas(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgendasPartial && !$this->isNew();
        if (null === $this->collTAgendas || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgendas) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgendas());
            }
            $query = TAgendaQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgent($this)
                ->count($con);
        }

        return count($this->collTAgendas);
    }

    /**
     * Method called to associate a TAgenda object to this object
     * through the TAgenda foreign key attribute.
     *
     * @param    TAgenda $l TAgenda
     * @return TAgent The current object (for fluent API support)
     */
    public function addTAgenda(TAgenda $l)
    {
        if ($this->collTAgendas === null) {
            $this->initTAgendas();
            $this->collTAgendasPartial = true;
        }
        if (!in_array($l, $this->collTAgendas->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgenda($l);
        }

        return $this;
    }

    /**
     * @param	TAgenda $tAgenda The tAgenda object to add.
     */
    protected function doAddTAgenda($tAgenda)
    {
        $this->collTAgendas[]= $tAgenda;
        $tAgenda->setTAgent($this);
    }

    /**
     * @param	TAgenda $tAgenda The tAgenda object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTAgenda($tAgenda)
    {
        if ($this->getTAgendas()->contains($tAgenda)) {
            $this->collTAgendas->remove($this->collTAgendas->search($tAgenda));
            if (null === $this->tAgendasScheduledForDeletion) {
                $this->tAgendasScheduledForDeletion = clone $this->collTAgendas;
                $this->tAgendasScheduledForDeletion->clear();
            }
            $this->tAgendasScheduledForDeletion[]= $tAgenda;
            $tAgenda->setTAgent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TAgendas from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgenda[] List of TAgenda objects
     */
    public function getTAgendasJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgendaQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgendas($query, $con);
    }

    /**
     * Clears out the collTAgentEtablissements collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTAgentEtablissements()
     */
    public function clearTAgentEtablissements()
    {
        $this->collTAgentEtablissements = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentEtablissementsPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentEtablissements collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentEtablissements($v = true)
    {
        $this->collTAgentEtablissementsPartial = $v;
    }

    /**
     * Initializes the collTAgentEtablissements collection.
     *
     * By default this just sets the collTAgentEtablissements collection to an empty array (like clearcollTAgentEtablissements());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentEtablissements($overrideExisting = true)
    {
        if (null !== $this->collTAgentEtablissements && !$overrideExisting) {
            return;
        }
        $this->collTAgentEtablissements = new PropelObjectCollection();
        $this->collTAgentEtablissements->setModel('TAgentEtablissement');
    }

    /**
     * Gets an array of TAgentEtablissement objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgentEtablissement[] List of TAgentEtablissement objects
     * @throws PropelException
     */
    public function getTAgentEtablissements($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentEtablissementsPartial && !$this->isNew();
        if (null === $this->collTAgentEtablissements || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentEtablissements) {
                // return empty collection
                $this->initTAgentEtablissements();
            } else {
                $collTAgentEtablissements = TAgentEtablissementQuery::create(null, $criteria)
                    ->filterByTAgent($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentEtablissementsPartial && count($collTAgentEtablissements)) {
                      $this->initTAgentEtablissements(false);

                      foreach($collTAgentEtablissements as $obj) {
                        if (false == $this->collTAgentEtablissements->contains($obj)) {
                          $this->collTAgentEtablissements->append($obj);
                        }
                      }

                      $this->collTAgentEtablissementsPartial = true;
                    }

                    $collTAgentEtablissements->getInternalIterator()->rewind();
                    return $collTAgentEtablissements;
                }

                if($partial && $this->collTAgentEtablissements) {
                    foreach($this->collTAgentEtablissements as $obj) {
                        if($obj->isNew()) {
                            $collTAgentEtablissements[] = $obj;
                        }
                    }
                }

                $this->collTAgentEtablissements = $collTAgentEtablissements;
                $this->collTAgentEtablissementsPartial = false;
            }
        }

        return $this->collTAgentEtablissements;
    }

    /**
     * Sets a collection of TAgentEtablissement objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentEtablissements A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTAgentEtablissements(PropelCollection $tAgentEtablissements, PropelPDO $con = null)
    {
        $tAgentEtablissementsToDelete = $this->getTAgentEtablissements(new Criteria(), $con)->diff($tAgentEtablissements);

        $this->tAgentEtablissementsScheduledForDeletion = unserialize(serialize($tAgentEtablissementsToDelete));

        foreach ($tAgentEtablissementsToDelete as $tAgentEtablissementRemoved) {
            $tAgentEtablissementRemoved->setTAgent(null);
        }

        $this->collTAgentEtablissements = null;
        foreach ($tAgentEtablissements as $tAgentEtablissement) {
            $this->addTAgentEtablissement($tAgentEtablissement);
        }

        $this->collTAgentEtablissements = $tAgentEtablissements;
        $this->collTAgentEtablissementsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgentEtablissement objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgentEtablissement objects.
     * @throws PropelException
     */
    public function countTAgentEtablissements(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentEtablissementsPartial && !$this->isNew();
        if (null === $this->collTAgentEtablissements || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentEtablissements) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentEtablissements());
            }
            $query = TAgentEtablissementQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgent($this)
                ->count($con);
        }

        return count($this->collTAgentEtablissements);
    }

    /**
     * Method called to associate a TAgentEtablissement object to this object
     * through the TAgentEtablissement foreign key attribute.
     *
     * @param    TAgentEtablissement $l TAgentEtablissement
     * @return TAgent The current object (for fluent API support)
     */
    public function addTAgentEtablissement(TAgentEtablissement $l)
    {
        if ($this->collTAgentEtablissements === null) {
            $this->initTAgentEtablissements();
            $this->collTAgentEtablissementsPartial = true;
        }
        if (!in_array($l, $this->collTAgentEtablissements->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentEtablissement($l);
        }

        return $this;
    }

    /**
     * @param	TAgentEtablissement $tAgentEtablissement The tAgentEtablissement object to add.
     */
    protected function doAddTAgentEtablissement($tAgentEtablissement)
    {
        $this->collTAgentEtablissements[]= $tAgentEtablissement;
        $tAgentEtablissement->setTAgent($this);
    }

    /**
     * @param	TAgentEtablissement $tAgentEtablissement The tAgentEtablissement object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTAgentEtablissement($tAgentEtablissement)
    {
        if ($this->getTAgentEtablissements()->contains($tAgentEtablissement)) {
            $this->collTAgentEtablissements->remove($this->collTAgentEtablissements->search($tAgentEtablissement));
            if (null === $this->tAgentEtablissementsScheduledForDeletion) {
                $this->tAgentEtablissementsScheduledForDeletion = clone $this->collTAgentEtablissements;
                $this->tAgentEtablissementsScheduledForDeletion->clear();
            }
            $this->tAgentEtablissementsScheduledForDeletion[]= clone $tAgentEtablissement;
            $tAgentEtablissement->setTAgent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TAgentEtablissements from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgentEtablissement[] List of TAgentEtablissement objects
     */
    public function getTAgentEtablissementsJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentEtablissementQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTAgentEtablissements($query, $con);
    }

    /**
     * Clears out the collTAgentPrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTAgentPrestations()
     */
    public function clearTAgentPrestations()
    {
        $this->collTAgentPrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentPrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentPrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentPrestations($v = true)
    {
        $this->collTAgentPrestationsPartial = $v;
    }

    /**
     * Initializes the collTAgentPrestations collection.
     *
     * By default this just sets the collTAgentPrestations collection to an empty array (like clearcollTAgentPrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentPrestations($overrideExisting = true)
    {
        if (null !== $this->collTAgentPrestations && !$overrideExisting) {
            return;
        }
        $this->collTAgentPrestations = new PropelObjectCollection();
        $this->collTAgentPrestations->setModel('TAgentPrestation');
    }

    /**
     * Gets an array of TAgentPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgentPrestation[] List of TAgentPrestation objects
     * @throws PropelException
     */
    public function getTAgentPrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentPrestationsPartial && !$this->isNew();
        if (null === $this->collTAgentPrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentPrestations) {
                // return empty collection
                $this->initTAgentPrestations();
            } else {
                $collTAgentPrestations = TAgentPrestationQuery::create(null, $criteria)
                    ->filterByTAgent($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentPrestationsPartial && count($collTAgentPrestations)) {
                      $this->initTAgentPrestations(false);

                      foreach($collTAgentPrestations as $obj) {
                        if (false == $this->collTAgentPrestations->contains($obj)) {
                          $this->collTAgentPrestations->append($obj);
                        }
                      }

                      $this->collTAgentPrestationsPartial = true;
                    }

                    $collTAgentPrestations->getInternalIterator()->rewind();
                    return $collTAgentPrestations;
                }

                if($partial && $this->collTAgentPrestations) {
                    foreach($this->collTAgentPrestations as $obj) {
                        if($obj->isNew()) {
                            $collTAgentPrestations[] = $obj;
                        }
                    }
                }

                $this->collTAgentPrestations = $collTAgentPrestations;
                $this->collTAgentPrestationsPartial = false;
            }
        }

        return $this->collTAgentPrestations;
    }

    /**
     * Sets a collection of TAgentPrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentPrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTAgentPrestations(PropelCollection $tAgentPrestations, PropelPDO $con = null)
    {
        $tAgentPrestationsToDelete = $this->getTAgentPrestations(new Criteria(), $con)->diff($tAgentPrestations);

        $this->tAgentPrestationsScheduledForDeletion = unserialize(serialize($tAgentPrestationsToDelete));

        foreach ($tAgentPrestationsToDelete as $tAgentPrestationRemoved) {
            $tAgentPrestationRemoved->setTAgent(null);
        }

        $this->collTAgentPrestations = null;
        foreach ($tAgentPrestations as $tAgentPrestation) {
            $this->addTAgentPrestation($tAgentPrestation);
        }

        $this->collTAgentPrestations = $tAgentPrestations;
        $this->collTAgentPrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgentPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgentPrestation objects.
     * @throws PropelException
     */
    public function countTAgentPrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentPrestationsPartial && !$this->isNew();
        if (null === $this->collTAgentPrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentPrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentPrestations());
            }
            $query = TAgentPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgent($this)
                ->count($con);
        }

        return count($this->collTAgentPrestations);
    }

    /**
     * Method called to associate a TAgentPrestation object to this object
     * through the TAgentPrestation foreign key attribute.
     *
     * @param    TAgentPrestation $l TAgentPrestation
     * @return TAgent The current object (for fluent API support)
     */
    public function addTAgentPrestation(TAgentPrestation $l)
    {
        if ($this->collTAgentPrestations === null) {
            $this->initTAgentPrestations();
            $this->collTAgentPrestationsPartial = true;
        }
        if (!in_array($l, $this->collTAgentPrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentPrestation($l);
        }

        return $this;
    }

    /**
     * @param	TAgentPrestation $tAgentPrestation The tAgentPrestation object to add.
     */
    protected function doAddTAgentPrestation($tAgentPrestation)
    {
        $this->collTAgentPrestations[]= $tAgentPrestation;
        $tAgentPrestation->setTAgent($this);
    }

    /**
     * @param	TAgentPrestation $tAgentPrestation The tAgentPrestation object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTAgentPrestation($tAgentPrestation)
    {
        if ($this->getTAgentPrestations()->contains($tAgentPrestation)) {
            $this->collTAgentPrestations->remove($this->collTAgentPrestations->search($tAgentPrestation));
            if (null === $this->tAgentPrestationsScheduledForDeletion) {
                $this->tAgentPrestationsScheduledForDeletion = clone $this->collTAgentPrestations;
                $this->tAgentPrestationsScheduledForDeletion->clear();
            }
            $this->tAgentPrestationsScheduledForDeletion[]= clone $tAgentPrestation;
            $tAgentPrestation->setTAgent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TAgentPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgentPrestation[] List of TAgentPrestation objects
     */
    public function getTAgentPrestationsJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentPrestationQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgentPrestations($query, $con);
    }

    /**
     * Clears out the collTPeriodeIndisponibilites collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTPeriodeIndisponibilites()
     */
    public function clearTPeriodeIndisponibilites()
    {
        $this->collTPeriodeIndisponibilites = null; // important to set this to null since that means it is uninitialized
        $this->collTPeriodeIndisponibilitesPartial = null;

        return $this;
    }

    /**
     * reset is the collTPeriodeIndisponibilites collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPeriodeIndisponibilites($v = true)
    {
        $this->collTPeriodeIndisponibilitesPartial = $v;
    }

    /**
     * Initializes the collTPeriodeIndisponibilites collection.
     *
     * By default this just sets the collTPeriodeIndisponibilites collection to an empty array (like clearcollTPeriodeIndisponibilites());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPeriodeIndisponibilites($overrideExisting = true)
    {
        if (null !== $this->collTPeriodeIndisponibilites && !$overrideExisting) {
            return;
        }
        $this->collTPeriodeIndisponibilites = new PropelObjectCollection();
        $this->collTPeriodeIndisponibilites->setModel('TPeriodeIndisponibilite');
    }

    /**
     * Gets an array of TPeriodeIndisponibilite objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPeriodeIndisponibilite[] List of TPeriodeIndisponibilite objects
     * @throws PropelException
     */
    public function getTPeriodeIndisponibilites($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPeriodeIndisponibilitesPartial && !$this->isNew();
        if (null === $this->collTPeriodeIndisponibilites || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPeriodeIndisponibilites) {
                // return empty collection
                $this->initTPeriodeIndisponibilites();
            } else {
                $collTPeriodeIndisponibilites = TPeriodeIndisponibiliteQuery::create(null, $criteria)
                    ->filterByTAgent($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPeriodeIndisponibilitesPartial && count($collTPeriodeIndisponibilites)) {
                      $this->initTPeriodeIndisponibilites(false);

                      foreach($collTPeriodeIndisponibilites as $obj) {
                        if (false == $this->collTPeriodeIndisponibilites->contains($obj)) {
                          $this->collTPeriodeIndisponibilites->append($obj);
                        }
                      }

                      $this->collTPeriodeIndisponibilitesPartial = true;
                    }

                    $collTPeriodeIndisponibilites->getInternalIterator()->rewind();
                    return $collTPeriodeIndisponibilites;
                }

                if($partial && $this->collTPeriodeIndisponibilites) {
                    foreach($this->collTPeriodeIndisponibilites as $obj) {
                        if($obj->isNew()) {
                            $collTPeriodeIndisponibilites[] = $obj;
                        }
                    }
                }

                $this->collTPeriodeIndisponibilites = $collTPeriodeIndisponibilites;
                $this->collTPeriodeIndisponibilitesPartial = false;
            }
        }

        return $this->collTPeriodeIndisponibilites;
    }

    /**
     * Sets a collection of TPeriodeIndisponibilite objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPeriodeIndisponibilites A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTPeriodeIndisponibilites(PropelCollection $tPeriodeIndisponibilites, PropelPDO $con = null)
    {
        $tPeriodeIndisponibilitesToDelete = $this->getTPeriodeIndisponibilites(new Criteria(), $con)->diff($tPeriodeIndisponibilites);

        $this->tPeriodeIndisponibilitesScheduledForDeletion = unserialize(serialize($tPeriodeIndisponibilitesToDelete));

        foreach ($tPeriodeIndisponibilitesToDelete as $tPeriodeIndisponibiliteRemoved) {
            $tPeriodeIndisponibiliteRemoved->setTAgent(null);
        }

        $this->collTPeriodeIndisponibilites = null;
        foreach ($tPeriodeIndisponibilites as $tPeriodeIndisponibilite) {
            $this->addTPeriodeIndisponibilite($tPeriodeIndisponibilite);
        }

        $this->collTPeriodeIndisponibilites = $tPeriodeIndisponibilites;
        $this->collTPeriodeIndisponibilitesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPeriodeIndisponibilite objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPeriodeIndisponibilite objects.
     * @throws PropelException
     */
    public function countTPeriodeIndisponibilites(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPeriodeIndisponibilitesPartial && !$this->isNew();
        if (null === $this->collTPeriodeIndisponibilites || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPeriodeIndisponibilites) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPeriodeIndisponibilites());
            }
            $query = TPeriodeIndisponibiliteQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgent($this)
                ->count($con);
        }

        return count($this->collTPeriodeIndisponibilites);
    }

    /**
     * Method called to associate a TPeriodeIndisponibilite object to this object
     * through the TPeriodeIndisponibilite foreign key attribute.
     *
     * @param    TPeriodeIndisponibilite $l TPeriodeIndisponibilite
     * @return TAgent The current object (for fluent API support)
     */
    public function addTPeriodeIndisponibilite(TPeriodeIndisponibilite $l)
    {
        if ($this->collTPeriodeIndisponibilites === null) {
            $this->initTPeriodeIndisponibilites();
            $this->collTPeriodeIndisponibilitesPartial = true;
        }
        if (!in_array($l, $this->collTPeriodeIndisponibilites->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPeriodeIndisponibilite($l);
        }

        return $this;
    }

    /**
     * @param	TPeriodeIndisponibilite $tPeriodeIndisponibilite The tPeriodeIndisponibilite object to add.
     */
    protected function doAddTPeriodeIndisponibilite($tPeriodeIndisponibilite)
    {
        $this->collTPeriodeIndisponibilites[]= $tPeriodeIndisponibilite;
        $tPeriodeIndisponibilite->setTAgent($this);
    }

    /**
     * @param	TPeriodeIndisponibilite $tPeriodeIndisponibilite The tPeriodeIndisponibilite object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTPeriodeIndisponibilite($tPeriodeIndisponibilite)
    {
        if ($this->getTPeriodeIndisponibilites()->contains($tPeriodeIndisponibilite)) {
            $this->collTPeriodeIndisponibilites->remove($this->collTPeriodeIndisponibilites->search($tPeriodeIndisponibilite));
            if (null === $this->tPeriodeIndisponibilitesScheduledForDeletion) {
                $this->tPeriodeIndisponibilitesScheduledForDeletion = clone $this->collTPeriodeIndisponibilites;
                $this->tPeriodeIndisponibilitesScheduledForDeletion->clear();
            }
            $this->tPeriodeIndisponibilitesScheduledForDeletion[]= clone $tPeriodeIndisponibilite;
            $tPeriodeIndisponibilite->setTAgent(null);
        }

        return $this;
    }

    /**
     * Clears out the collTRendezVoussRelatedByIdAgentAccueil collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTRendezVoussRelatedByIdAgentAccueil()
     */
    public function clearTRendezVoussRelatedByIdAgentAccueil()
    {
        $this->collTRendezVoussRelatedByIdAgentAccueil = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussRelatedByIdAgentAccueilPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVoussRelatedByIdAgentAccueil collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVoussRelatedByIdAgentAccueil($v = true)
    {
        $this->collTRendezVoussRelatedByIdAgentAccueilPartial = $v;
    }

    /**
     * Initializes the collTRendezVoussRelatedByIdAgentAccueil collection.
     *
     * By default this just sets the collTRendezVoussRelatedByIdAgentAccueil collection to an empty array (like clearcollTRendezVoussRelatedByIdAgentAccueil());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVoussRelatedByIdAgentAccueil($overrideExisting = true)
    {
        if (null !== $this->collTRendezVoussRelatedByIdAgentAccueil && !$overrideExisting) {
            return;
        }
        $this->collTRendezVoussRelatedByIdAgentAccueil = new PropelObjectCollection();
        $this->collTRendezVoussRelatedByIdAgentAccueil->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVoussRelatedByIdAgentAccueil($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentAccueilPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentAccueil || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentAccueil) {
                // return empty collection
                $this->initTRendezVoussRelatedByIdAgentAccueil();
            } else {
                $collTRendezVoussRelatedByIdAgentAccueil = TRendezVousQuery::create(null, $criteria)
                    ->filterByTAgentRelatedByIdAgentAccueil($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussRelatedByIdAgentAccueilPartial && count($collTRendezVoussRelatedByIdAgentAccueil)) {
                      $this->initTRendezVoussRelatedByIdAgentAccueil(false);

                      foreach($collTRendezVoussRelatedByIdAgentAccueil as $obj) {
                        if (false == $this->collTRendezVoussRelatedByIdAgentAccueil->contains($obj)) {
                          $this->collTRendezVoussRelatedByIdAgentAccueil->append($obj);
                        }
                      }

                      $this->collTRendezVoussRelatedByIdAgentAccueilPartial = true;
                    }

                    $collTRendezVoussRelatedByIdAgentAccueil->getInternalIterator()->rewind();
                    return $collTRendezVoussRelatedByIdAgentAccueil;
                }

                if($partial && $this->collTRendezVoussRelatedByIdAgentAccueil) {
                    foreach($this->collTRendezVoussRelatedByIdAgentAccueil as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVoussRelatedByIdAgentAccueil[] = $obj;
                        }
                    }
                }

                $this->collTRendezVoussRelatedByIdAgentAccueil = $collTRendezVoussRelatedByIdAgentAccueil;
                $this->collTRendezVoussRelatedByIdAgentAccueilPartial = false;
            }
        }

        return $this->collTRendezVoussRelatedByIdAgentAccueil;
    }

    /**
     * Sets a collection of TRendezVousRelatedByIdAgentAccueil objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVoussRelatedByIdAgentAccueil A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTRendezVoussRelatedByIdAgentAccueil(PropelCollection $tRendezVoussRelatedByIdAgentAccueil, PropelPDO $con = null)
    {
        $tRendezVoussRelatedByIdAgentAccueilToDelete = $this->getTRendezVoussRelatedByIdAgentAccueil(new Criteria(), $con)->diff($tRendezVoussRelatedByIdAgentAccueil);

        $this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion = unserialize(serialize($tRendezVoussRelatedByIdAgentAccueilToDelete));

        foreach ($tRendezVoussRelatedByIdAgentAccueilToDelete as $tRendezVousRelatedByIdAgentAccueilRemoved) {
            $tRendezVousRelatedByIdAgentAccueilRemoved->setTAgentRelatedByIdAgentAccueil(null);
        }

        $this->collTRendezVoussRelatedByIdAgentAccueil = null;
        foreach ($tRendezVoussRelatedByIdAgentAccueil as $tRendezVousRelatedByIdAgentAccueil) {
            $this->addTRendezVousRelatedByIdAgentAccueil($tRendezVousRelatedByIdAgentAccueil);
        }

        $this->collTRendezVoussRelatedByIdAgentAccueil = $tRendezVoussRelatedByIdAgentAccueil;
        $this->collTRendezVoussRelatedByIdAgentAccueilPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVoussRelatedByIdAgentAccueil(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentAccueilPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentAccueil || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentAccueil) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVoussRelatedByIdAgentAccueil());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgentRelatedByIdAgentAccueil($this)
                ->count($con);
        }

        return count($this->collTRendezVoussRelatedByIdAgentAccueil);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TAgent The current object (for fluent API support)
     */
    public function addTRendezVousRelatedByIdAgentAccueil(TRendezVous $l)
    {
        if ($this->collTRendezVoussRelatedByIdAgentAccueil === null) {
            $this->initTRendezVoussRelatedByIdAgentAccueil();
            $this->collTRendezVoussRelatedByIdAgentAccueilPartial = true;
        }
        if (!in_array($l, $this->collTRendezVoussRelatedByIdAgentAccueil->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVousRelatedByIdAgentAccueil($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVousRelatedByIdAgentAccueil $tRendezVousRelatedByIdAgentAccueil The tRendezVousRelatedByIdAgentAccueil object to add.
     */
    protected function doAddTRendezVousRelatedByIdAgentAccueil($tRendezVousRelatedByIdAgentAccueil)
    {
        $this->collTRendezVoussRelatedByIdAgentAccueil[]= $tRendezVousRelatedByIdAgentAccueil;
        $tRendezVousRelatedByIdAgentAccueil->setTAgentRelatedByIdAgentAccueil($this);
    }

    /**
     * @param	TRendezVousRelatedByIdAgentAccueil $tRendezVousRelatedByIdAgentAccueil The tRendezVousRelatedByIdAgentAccueil object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTRendezVousRelatedByIdAgentAccueil($tRendezVousRelatedByIdAgentAccueil)
    {
        if ($this->getTRendezVoussRelatedByIdAgentAccueil()->contains($tRendezVousRelatedByIdAgentAccueil)) {
            $this->collTRendezVoussRelatedByIdAgentAccueil->remove($this->collTRendezVoussRelatedByIdAgentAccueil->search($tRendezVousRelatedByIdAgentAccueil));
            if (null === $this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion) {
                $this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion = clone $this->collTRendezVoussRelatedByIdAgentAccueil;
                $this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion->clear();
            }
            $this->tRendezVoussRelatedByIdAgentAccueilScheduledForDeletion[]= $tRendezVousRelatedByIdAgentAccueil;
            $tRendezVousRelatedByIdAgentAccueil->setTAgentRelatedByIdAgentAccueil(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAccueil from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAccueilJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAccueil($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAccueil from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAccueilJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAccueil($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAccueil from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAccueilJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAccueil($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAccueil from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAccueilJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAccueil($query, $con);
    }

    /**
     * Clears out the collTRendezVoussRelatedByIdAgentAnnulation collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTRendezVoussRelatedByIdAgentAnnulation()
     */
    public function clearTRendezVoussRelatedByIdAgentAnnulation()
    {
        $this->collTRendezVoussRelatedByIdAgentAnnulation = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussRelatedByIdAgentAnnulationPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVoussRelatedByIdAgentAnnulation collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVoussRelatedByIdAgentAnnulation($v = true)
    {
        $this->collTRendezVoussRelatedByIdAgentAnnulationPartial = $v;
    }

    /**
     * Initializes the collTRendezVoussRelatedByIdAgentAnnulation collection.
     *
     * By default this just sets the collTRendezVoussRelatedByIdAgentAnnulation collection to an empty array (like clearcollTRendezVoussRelatedByIdAgentAnnulation());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVoussRelatedByIdAgentAnnulation($overrideExisting = true)
    {
        if (null !== $this->collTRendezVoussRelatedByIdAgentAnnulation && !$overrideExisting) {
            return;
        }
        $this->collTRendezVoussRelatedByIdAgentAnnulation = new PropelObjectCollection();
        $this->collTRendezVoussRelatedByIdAgentAnnulation->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVoussRelatedByIdAgentAnnulation($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentAnnulationPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentAnnulation || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentAnnulation) {
                // return empty collection
                $this->initTRendezVoussRelatedByIdAgentAnnulation();
            } else {
                $collTRendezVoussRelatedByIdAgentAnnulation = TRendezVousQuery::create(null, $criteria)
                    ->filterByTAgentRelatedByIdAgentAnnulation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussRelatedByIdAgentAnnulationPartial && count($collTRendezVoussRelatedByIdAgentAnnulation)) {
                      $this->initTRendezVoussRelatedByIdAgentAnnulation(false);

                      foreach($collTRendezVoussRelatedByIdAgentAnnulation as $obj) {
                        if (false == $this->collTRendezVoussRelatedByIdAgentAnnulation->contains($obj)) {
                          $this->collTRendezVoussRelatedByIdAgentAnnulation->append($obj);
                        }
                      }

                      $this->collTRendezVoussRelatedByIdAgentAnnulationPartial = true;
                    }

                    $collTRendezVoussRelatedByIdAgentAnnulation->getInternalIterator()->rewind();
                    return $collTRendezVoussRelatedByIdAgentAnnulation;
                }

                if($partial && $this->collTRendezVoussRelatedByIdAgentAnnulation) {
                    foreach($this->collTRendezVoussRelatedByIdAgentAnnulation as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVoussRelatedByIdAgentAnnulation[] = $obj;
                        }
                    }
                }

                $this->collTRendezVoussRelatedByIdAgentAnnulation = $collTRendezVoussRelatedByIdAgentAnnulation;
                $this->collTRendezVoussRelatedByIdAgentAnnulationPartial = false;
            }
        }

        return $this->collTRendezVoussRelatedByIdAgentAnnulation;
    }

    /**
     * Sets a collection of TRendezVousRelatedByIdAgentAnnulation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVoussRelatedByIdAgentAnnulation A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTRendezVoussRelatedByIdAgentAnnulation(PropelCollection $tRendezVoussRelatedByIdAgentAnnulation, PropelPDO $con = null)
    {
        $tRendezVoussRelatedByIdAgentAnnulationToDelete = $this->getTRendezVoussRelatedByIdAgentAnnulation(new Criteria(), $con)->diff($tRendezVoussRelatedByIdAgentAnnulation);

        $this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion = unserialize(serialize($tRendezVoussRelatedByIdAgentAnnulationToDelete));

        foreach ($tRendezVoussRelatedByIdAgentAnnulationToDelete as $tRendezVousRelatedByIdAgentAnnulationRemoved) {
            $tRendezVousRelatedByIdAgentAnnulationRemoved->setTAgentRelatedByIdAgentAnnulation(null);
        }

        $this->collTRendezVoussRelatedByIdAgentAnnulation = null;
        foreach ($tRendezVoussRelatedByIdAgentAnnulation as $tRendezVousRelatedByIdAgentAnnulation) {
            $this->addTRendezVousRelatedByIdAgentAnnulation($tRendezVousRelatedByIdAgentAnnulation);
        }

        $this->collTRendezVoussRelatedByIdAgentAnnulation = $tRendezVoussRelatedByIdAgentAnnulation;
        $this->collTRendezVoussRelatedByIdAgentAnnulationPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVoussRelatedByIdAgentAnnulation(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentAnnulationPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentAnnulation || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentAnnulation) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVoussRelatedByIdAgentAnnulation());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgentRelatedByIdAgentAnnulation($this)
                ->count($con);
        }

        return count($this->collTRendezVoussRelatedByIdAgentAnnulation);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TAgent The current object (for fluent API support)
     */
    public function addTRendezVousRelatedByIdAgentAnnulation(TRendezVous $l)
    {
        if ($this->collTRendezVoussRelatedByIdAgentAnnulation === null) {
            $this->initTRendezVoussRelatedByIdAgentAnnulation();
            $this->collTRendezVoussRelatedByIdAgentAnnulationPartial = true;
        }
        if (!in_array($l, $this->collTRendezVoussRelatedByIdAgentAnnulation->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVousRelatedByIdAgentAnnulation($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVousRelatedByIdAgentAnnulation $tRendezVousRelatedByIdAgentAnnulation The tRendezVousRelatedByIdAgentAnnulation object to add.
     */
    protected function doAddTRendezVousRelatedByIdAgentAnnulation($tRendezVousRelatedByIdAgentAnnulation)
    {
        $this->collTRendezVoussRelatedByIdAgentAnnulation[]= $tRendezVousRelatedByIdAgentAnnulation;
        $tRendezVousRelatedByIdAgentAnnulation->setTAgentRelatedByIdAgentAnnulation($this);
    }

    /**
     * @param	TRendezVousRelatedByIdAgentAnnulation $tRendezVousRelatedByIdAgentAnnulation The tRendezVousRelatedByIdAgentAnnulation object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTRendezVousRelatedByIdAgentAnnulation($tRendezVousRelatedByIdAgentAnnulation)
    {
        if ($this->getTRendezVoussRelatedByIdAgentAnnulation()->contains($tRendezVousRelatedByIdAgentAnnulation)) {
            $this->collTRendezVoussRelatedByIdAgentAnnulation->remove($this->collTRendezVoussRelatedByIdAgentAnnulation->search($tRendezVousRelatedByIdAgentAnnulation));
            if (null === $this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion) {
                $this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion = clone $this->collTRendezVoussRelatedByIdAgentAnnulation;
                $this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion->clear();
            }
            $this->tRendezVoussRelatedByIdAgentAnnulationScheduledForDeletion[]= $tRendezVousRelatedByIdAgentAnnulation;
            $tRendezVousRelatedByIdAgentAnnulation->setTAgentRelatedByIdAgentAnnulation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAnnulation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAnnulationJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAnnulation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAnnulation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAnnulationJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAnnulation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAnnulation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAnnulationJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAnnulation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentAnnulation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentAnnulationJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentAnnulation($query, $con);
    }

    /**
     * Clears out the collTRendezVoussRelatedByIdAgentConfirmation collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTRendezVoussRelatedByIdAgentConfirmation()
     */
    public function clearTRendezVoussRelatedByIdAgentConfirmation()
    {
        $this->collTRendezVoussRelatedByIdAgentConfirmation = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussRelatedByIdAgentConfirmationPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVoussRelatedByIdAgentConfirmation collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVoussRelatedByIdAgentConfirmation($v = true)
    {
        $this->collTRendezVoussRelatedByIdAgentConfirmationPartial = $v;
    }

    /**
     * Initializes the collTRendezVoussRelatedByIdAgentConfirmation collection.
     *
     * By default this just sets the collTRendezVoussRelatedByIdAgentConfirmation collection to an empty array (like clearcollTRendezVoussRelatedByIdAgentConfirmation());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVoussRelatedByIdAgentConfirmation($overrideExisting = true)
    {
        if (null !== $this->collTRendezVoussRelatedByIdAgentConfirmation && !$overrideExisting) {
            return;
        }
        $this->collTRendezVoussRelatedByIdAgentConfirmation = new PropelObjectCollection();
        $this->collTRendezVoussRelatedByIdAgentConfirmation->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVoussRelatedByIdAgentConfirmation($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentConfirmationPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentConfirmation || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentConfirmation) {
                // return empty collection
                $this->initTRendezVoussRelatedByIdAgentConfirmation();
            } else {
                $collTRendezVoussRelatedByIdAgentConfirmation = TRendezVousQuery::create(null, $criteria)
                    ->filterByTAgentRelatedByIdAgentConfirmation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussRelatedByIdAgentConfirmationPartial && count($collTRendezVoussRelatedByIdAgentConfirmation)) {
                      $this->initTRendezVoussRelatedByIdAgentConfirmation(false);

                      foreach($collTRendezVoussRelatedByIdAgentConfirmation as $obj) {
                        if (false == $this->collTRendezVoussRelatedByIdAgentConfirmation->contains($obj)) {
                          $this->collTRendezVoussRelatedByIdAgentConfirmation->append($obj);
                        }
                      }

                      $this->collTRendezVoussRelatedByIdAgentConfirmationPartial = true;
                    }

                    $collTRendezVoussRelatedByIdAgentConfirmation->getInternalIterator()->rewind();
                    return $collTRendezVoussRelatedByIdAgentConfirmation;
                }

                if($partial && $this->collTRendezVoussRelatedByIdAgentConfirmation) {
                    foreach($this->collTRendezVoussRelatedByIdAgentConfirmation as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVoussRelatedByIdAgentConfirmation[] = $obj;
                        }
                    }
                }

                $this->collTRendezVoussRelatedByIdAgentConfirmation = $collTRendezVoussRelatedByIdAgentConfirmation;
                $this->collTRendezVoussRelatedByIdAgentConfirmationPartial = false;
            }
        }

        return $this->collTRendezVoussRelatedByIdAgentConfirmation;
    }

    /**
     * Sets a collection of TRendezVousRelatedByIdAgentConfirmation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVoussRelatedByIdAgentConfirmation A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTRendezVoussRelatedByIdAgentConfirmation(PropelCollection $tRendezVoussRelatedByIdAgentConfirmation, PropelPDO $con = null)
    {
        $tRendezVoussRelatedByIdAgentConfirmationToDelete = $this->getTRendezVoussRelatedByIdAgentConfirmation(new Criteria(), $con)->diff($tRendezVoussRelatedByIdAgentConfirmation);

        $this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion = unserialize(serialize($tRendezVoussRelatedByIdAgentConfirmationToDelete));

        foreach ($tRendezVoussRelatedByIdAgentConfirmationToDelete as $tRendezVousRelatedByIdAgentConfirmationRemoved) {
            $tRendezVousRelatedByIdAgentConfirmationRemoved->setTAgentRelatedByIdAgentConfirmation(null);
        }

        $this->collTRendezVoussRelatedByIdAgentConfirmation = null;
        foreach ($tRendezVoussRelatedByIdAgentConfirmation as $tRendezVousRelatedByIdAgentConfirmation) {
            $this->addTRendezVousRelatedByIdAgentConfirmation($tRendezVousRelatedByIdAgentConfirmation);
        }

        $this->collTRendezVoussRelatedByIdAgentConfirmation = $tRendezVoussRelatedByIdAgentConfirmation;
        $this->collTRendezVoussRelatedByIdAgentConfirmationPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVoussRelatedByIdAgentConfirmation(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentConfirmationPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentConfirmation || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentConfirmation) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVoussRelatedByIdAgentConfirmation());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgentRelatedByIdAgentConfirmation($this)
                ->count($con);
        }

        return count($this->collTRendezVoussRelatedByIdAgentConfirmation);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TAgent The current object (for fluent API support)
     */
    public function addTRendezVousRelatedByIdAgentConfirmation(TRendezVous $l)
    {
        if ($this->collTRendezVoussRelatedByIdAgentConfirmation === null) {
            $this->initTRendezVoussRelatedByIdAgentConfirmation();
            $this->collTRendezVoussRelatedByIdAgentConfirmationPartial = true;
        }
        if (!in_array($l, $this->collTRendezVoussRelatedByIdAgentConfirmation->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVousRelatedByIdAgentConfirmation($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVousRelatedByIdAgentConfirmation $tRendezVousRelatedByIdAgentConfirmation The tRendezVousRelatedByIdAgentConfirmation object to add.
     */
    protected function doAddTRendezVousRelatedByIdAgentConfirmation($tRendezVousRelatedByIdAgentConfirmation)
    {
        $this->collTRendezVoussRelatedByIdAgentConfirmation[]= $tRendezVousRelatedByIdAgentConfirmation;
        $tRendezVousRelatedByIdAgentConfirmation->setTAgentRelatedByIdAgentConfirmation($this);
    }

    /**
     * @param	TRendezVousRelatedByIdAgentConfirmation $tRendezVousRelatedByIdAgentConfirmation The tRendezVousRelatedByIdAgentConfirmation object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTRendezVousRelatedByIdAgentConfirmation($tRendezVousRelatedByIdAgentConfirmation)
    {
        if ($this->getTRendezVoussRelatedByIdAgentConfirmation()->contains($tRendezVousRelatedByIdAgentConfirmation)) {
            $this->collTRendezVoussRelatedByIdAgentConfirmation->remove($this->collTRendezVoussRelatedByIdAgentConfirmation->search($tRendezVousRelatedByIdAgentConfirmation));
            if (null === $this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion) {
                $this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion = clone $this->collTRendezVoussRelatedByIdAgentConfirmation;
                $this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion->clear();
            }
            $this->tRendezVoussRelatedByIdAgentConfirmationScheduledForDeletion[]= $tRendezVousRelatedByIdAgentConfirmation;
            $tRendezVousRelatedByIdAgentConfirmation->setTAgentRelatedByIdAgentConfirmation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentConfirmation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentConfirmationJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentConfirmation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentConfirmation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentConfirmationJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentConfirmation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentConfirmation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentConfirmationJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentConfirmation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentConfirmation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentConfirmationJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentConfirmation($query, $con);
    }

    /**
     * Clears out the collTRendezVoussRelatedByIdAgentRessource collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTRendezVoussRelatedByIdAgentRessource()
     */
    public function clearTRendezVoussRelatedByIdAgentRessource()
    {
        $this->collTRendezVoussRelatedByIdAgentRessource = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussRelatedByIdAgentRessourcePartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVoussRelatedByIdAgentRessource collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVoussRelatedByIdAgentRessource($v = true)
    {
        $this->collTRendezVoussRelatedByIdAgentRessourcePartial = $v;
    }

    /**
     * Initializes the collTRendezVoussRelatedByIdAgentRessource collection.
     *
     * By default this just sets the collTRendezVoussRelatedByIdAgentRessource collection to an empty array (like clearcollTRendezVoussRelatedByIdAgentRessource());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVoussRelatedByIdAgentRessource($overrideExisting = true)
    {
        if (null !== $this->collTRendezVoussRelatedByIdAgentRessource && !$overrideExisting) {
            return;
        }
        $this->collTRendezVoussRelatedByIdAgentRessource = new PropelObjectCollection();
        $this->collTRendezVoussRelatedByIdAgentRessource->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVoussRelatedByIdAgentRessource($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentRessourcePartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentRessource || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentRessource) {
                // return empty collection
                $this->initTRendezVoussRelatedByIdAgentRessource();
            } else {
                $collTRendezVoussRelatedByIdAgentRessource = TRendezVousQuery::create(null, $criteria)
                    ->filterByTAgentRelatedByIdAgentRessource($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussRelatedByIdAgentRessourcePartial && count($collTRendezVoussRelatedByIdAgentRessource)) {
                      $this->initTRendezVoussRelatedByIdAgentRessource(false);

                      foreach($collTRendezVoussRelatedByIdAgentRessource as $obj) {
                        if (false == $this->collTRendezVoussRelatedByIdAgentRessource->contains($obj)) {
                          $this->collTRendezVoussRelatedByIdAgentRessource->append($obj);
                        }
                      }

                      $this->collTRendezVoussRelatedByIdAgentRessourcePartial = true;
                    }

                    $collTRendezVoussRelatedByIdAgentRessource->getInternalIterator()->rewind();
                    return $collTRendezVoussRelatedByIdAgentRessource;
                }

                if($partial && $this->collTRendezVoussRelatedByIdAgentRessource) {
                    foreach($this->collTRendezVoussRelatedByIdAgentRessource as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVoussRelatedByIdAgentRessource[] = $obj;
                        }
                    }
                }

                $this->collTRendezVoussRelatedByIdAgentRessource = $collTRendezVoussRelatedByIdAgentRessource;
                $this->collTRendezVoussRelatedByIdAgentRessourcePartial = false;
            }
        }

        return $this->collTRendezVoussRelatedByIdAgentRessource;
    }

    /**
     * Sets a collection of TRendezVousRelatedByIdAgentRessource objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVoussRelatedByIdAgentRessource A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTRendezVoussRelatedByIdAgentRessource(PropelCollection $tRendezVoussRelatedByIdAgentRessource, PropelPDO $con = null)
    {
        $tRendezVoussRelatedByIdAgentRessourceToDelete = $this->getTRendezVoussRelatedByIdAgentRessource(new Criteria(), $con)->diff($tRendezVoussRelatedByIdAgentRessource);

        $this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion = unserialize(serialize($tRendezVoussRelatedByIdAgentRessourceToDelete));

        foreach ($tRendezVoussRelatedByIdAgentRessourceToDelete as $tRendezVousRelatedByIdAgentRessourceRemoved) {
            $tRendezVousRelatedByIdAgentRessourceRemoved->setTAgentRelatedByIdAgentRessource(null);
        }

        $this->collTRendezVoussRelatedByIdAgentRessource = null;
        foreach ($tRendezVoussRelatedByIdAgentRessource as $tRendezVousRelatedByIdAgentRessource) {
            $this->addTRendezVousRelatedByIdAgentRessource($tRendezVousRelatedByIdAgentRessource);
        }

        $this->collTRendezVoussRelatedByIdAgentRessource = $tRendezVoussRelatedByIdAgentRessource;
        $this->collTRendezVoussRelatedByIdAgentRessourcePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVoussRelatedByIdAgentRessource(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentRessourcePartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentRessource || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentRessource) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVoussRelatedByIdAgentRessource());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgentRelatedByIdAgentRessource($this)
                ->count($con);
        }

        return count($this->collTRendezVoussRelatedByIdAgentRessource);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TAgent The current object (for fluent API support)
     */
    public function addTRendezVousRelatedByIdAgentRessource(TRendezVous $l)
    {
        if ($this->collTRendezVoussRelatedByIdAgentRessource === null) {
            $this->initTRendezVoussRelatedByIdAgentRessource();
            $this->collTRendezVoussRelatedByIdAgentRessourcePartial = true;
        }
        if (!in_array($l, $this->collTRendezVoussRelatedByIdAgentRessource->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVousRelatedByIdAgentRessource($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVousRelatedByIdAgentRessource $tRendezVousRelatedByIdAgentRessource The tRendezVousRelatedByIdAgentRessource object to add.
     */
    protected function doAddTRendezVousRelatedByIdAgentRessource($tRendezVousRelatedByIdAgentRessource)
    {
        $this->collTRendezVoussRelatedByIdAgentRessource[]= $tRendezVousRelatedByIdAgentRessource;
        $tRendezVousRelatedByIdAgentRessource->setTAgentRelatedByIdAgentRessource($this);
    }

    /**
     * @param	TRendezVousRelatedByIdAgentRessource $tRendezVousRelatedByIdAgentRessource The tRendezVousRelatedByIdAgentRessource object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTRendezVousRelatedByIdAgentRessource($tRendezVousRelatedByIdAgentRessource)
    {
        if ($this->getTRendezVoussRelatedByIdAgentRessource()->contains($tRendezVousRelatedByIdAgentRessource)) {
            $this->collTRendezVoussRelatedByIdAgentRessource->remove($this->collTRendezVoussRelatedByIdAgentRessource->search($tRendezVousRelatedByIdAgentRessource));
            if (null === $this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion) {
                $this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion = clone $this->collTRendezVoussRelatedByIdAgentRessource;
                $this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion->clear();
            }
            $this->tRendezVoussRelatedByIdAgentRessourceScheduledForDeletion[]= $tRendezVousRelatedByIdAgentRessource;
            $tRendezVousRelatedByIdAgentRessource->setTAgentRelatedByIdAgentRessource(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentRessource from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentRessourceJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentRessource($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentRessource from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentRessourceJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentRessource($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentRessource from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentRessourceJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentRessource($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentRessource from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentRessourceJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentRessource($query, $con);
    }

    /**
     * Clears out the collTRendezVoussRelatedByIdAgentTeleoperateur collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TAgent The current object (for fluent API support)
     * @see        addTRendezVoussRelatedByIdAgentTeleoperateur()
     */
    public function clearTRendezVoussRelatedByIdAgentTeleoperateur()
    {
        $this->collTRendezVoussRelatedByIdAgentTeleoperateur = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVoussRelatedByIdAgentTeleoperateur collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVoussRelatedByIdAgentTeleoperateur($v = true)
    {
        $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial = $v;
    }

    /**
     * Initializes the collTRendezVoussRelatedByIdAgentTeleoperateur collection.
     *
     * By default this just sets the collTRendezVoussRelatedByIdAgentTeleoperateur collection to an empty array (like clearcollTRendezVoussRelatedByIdAgentTeleoperateur());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVoussRelatedByIdAgentTeleoperateur($overrideExisting = true)
    {
        if (null !== $this->collTRendezVoussRelatedByIdAgentTeleoperateur && !$overrideExisting) {
            return;
        }
        $this->collTRendezVoussRelatedByIdAgentTeleoperateur = new PropelObjectCollection();
        $this->collTRendezVoussRelatedByIdAgentTeleoperateur->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TAgent is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVoussRelatedByIdAgentTeleoperateur($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentTeleoperateur || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentTeleoperateur) {
                // return empty collection
                $this->initTRendezVoussRelatedByIdAgentTeleoperateur();
            } else {
                $collTRendezVoussRelatedByIdAgentTeleoperateur = TRendezVousQuery::create(null, $criteria)
                    ->filterByTAgentRelatedByIdAgentTeleoperateur($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial && count($collTRendezVoussRelatedByIdAgentTeleoperateur)) {
                      $this->initTRendezVoussRelatedByIdAgentTeleoperateur(false);

                      foreach($collTRendezVoussRelatedByIdAgentTeleoperateur as $obj) {
                        if (false == $this->collTRendezVoussRelatedByIdAgentTeleoperateur->contains($obj)) {
                          $this->collTRendezVoussRelatedByIdAgentTeleoperateur->append($obj);
                        }
                      }

                      $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial = true;
                    }

                    $collTRendezVoussRelatedByIdAgentTeleoperateur->getInternalIterator()->rewind();
                    return $collTRendezVoussRelatedByIdAgentTeleoperateur;
                }

                if($partial && $this->collTRendezVoussRelatedByIdAgentTeleoperateur) {
                    foreach($this->collTRendezVoussRelatedByIdAgentTeleoperateur as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVoussRelatedByIdAgentTeleoperateur[] = $obj;
                        }
                    }
                }

                $this->collTRendezVoussRelatedByIdAgentTeleoperateur = $collTRendezVoussRelatedByIdAgentTeleoperateur;
                $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial = false;
            }
        }

        return $this->collTRendezVoussRelatedByIdAgentTeleoperateur;
    }

    /**
     * Sets a collection of TRendezVousRelatedByIdAgentTeleoperateur objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVoussRelatedByIdAgentTeleoperateur A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TAgent The current object (for fluent API support)
     */
    public function setTRendezVoussRelatedByIdAgentTeleoperateur(PropelCollection $tRendezVoussRelatedByIdAgentTeleoperateur, PropelPDO $con = null)
    {
        $tRendezVoussRelatedByIdAgentTeleoperateurToDelete = $this->getTRendezVoussRelatedByIdAgentTeleoperateur(new Criteria(), $con)->diff($tRendezVoussRelatedByIdAgentTeleoperateur);

        $this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion = unserialize(serialize($tRendezVoussRelatedByIdAgentTeleoperateurToDelete));

        foreach ($tRendezVoussRelatedByIdAgentTeleoperateurToDelete as $tRendezVousRelatedByIdAgentTeleoperateurRemoved) {
            $tRendezVousRelatedByIdAgentTeleoperateurRemoved->setTAgentRelatedByIdAgentTeleoperateur(null);
        }

        $this->collTRendezVoussRelatedByIdAgentTeleoperateur = null;
        foreach ($tRendezVoussRelatedByIdAgentTeleoperateur as $tRendezVousRelatedByIdAgentTeleoperateur) {
            $this->addTRendezVousRelatedByIdAgentTeleoperateur($tRendezVousRelatedByIdAgentTeleoperateur);
        }

        $this->collTRendezVoussRelatedByIdAgentTeleoperateur = $tRendezVoussRelatedByIdAgentTeleoperateur;
        $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVoussRelatedByIdAgentTeleoperateur(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial && !$this->isNew();
        if (null === $this->collTRendezVoussRelatedByIdAgentTeleoperateur || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVoussRelatedByIdAgentTeleoperateur) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVoussRelatedByIdAgentTeleoperateur());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTAgentRelatedByIdAgentTeleoperateur($this)
                ->count($con);
        }

        return count($this->collTRendezVoussRelatedByIdAgentTeleoperateur);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TAgent The current object (for fluent API support)
     */
    public function addTRendezVousRelatedByIdAgentTeleoperateur(TRendezVous $l)
    {
        if ($this->collTRendezVoussRelatedByIdAgentTeleoperateur === null) {
            $this->initTRendezVoussRelatedByIdAgentTeleoperateur();
            $this->collTRendezVoussRelatedByIdAgentTeleoperateurPartial = true;
        }
        if (!in_array($l, $this->collTRendezVoussRelatedByIdAgentTeleoperateur->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVousRelatedByIdAgentTeleoperateur($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVousRelatedByIdAgentTeleoperateur $tRendezVousRelatedByIdAgentTeleoperateur The tRendezVousRelatedByIdAgentTeleoperateur object to add.
     */
    protected function doAddTRendezVousRelatedByIdAgentTeleoperateur($tRendezVousRelatedByIdAgentTeleoperateur)
    {
        $this->collTRendezVoussRelatedByIdAgentTeleoperateur[]= $tRendezVousRelatedByIdAgentTeleoperateur;
        $tRendezVousRelatedByIdAgentTeleoperateur->setTAgentRelatedByIdAgentTeleoperateur($this);
    }

    /**
     * @param	TRendezVousRelatedByIdAgentTeleoperateur $tRendezVousRelatedByIdAgentTeleoperateur The tRendezVousRelatedByIdAgentTeleoperateur object to remove.
     * @return TAgent The current object (for fluent API support)
     */
    public function removeTRendezVousRelatedByIdAgentTeleoperateur($tRendezVousRelatedByIdAgentTeleoperateur)
    {
        if ($this->getTRendezVoussRelatedByIdAgentTeleoperateur()->contains($tRendezVousRelatedByIdAgentTeleoperateur)) {
            $this->collTRendezVoussRelatedByIdAgentTeleoperateur->remove($this->collTRendezVoussRelatedByIdAgentTeleoperateur->search($tRendezVousRelatedByIdAgentTeleoperateur));
            if (null === $this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion) {
                $this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion = clone $this->collTRendezVoussRelatedByIdAgentTeleoperateur;
                $this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion->clear();
            }
            $this->tRendezVoussRelatedByIdAgentTeleoperateurScheduledForDeletion[]= $tRendezVousRelatedByIdAgentTeleoperateur;
            $tRendezVousRelatedByIdAgentTeleoperateur->setTAgentRelatedByIdAgentTeleoperateur(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentTeleoperateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentTeleoperateurJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentTeleoperateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentTeleoperateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentTeleoperateurJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentTeleoperateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentTeleoperateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentTeleoperateurJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentTeleoperateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TAgent is new, it will return
     * an empty collection; or if this TAgent has previously
     * been saved, it will retrieve related TRendezVoussRelatedByIdAgentTeleoperateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TAgent.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussRelatedByIdAgentTeleoperateurJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVoussRelatedByIdAgentTeleoperateur($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_agent = null;
        $this->login = null;
        $this->mot_de_passe = null;
        $this->code_nom_utilisateur = null;
        $this->code_prenom_utilisateur = null;
        $this->code_utilisateur = null;
        $this->email_utilisateur = null;
        $this->telephone_utilisateur = null;
        $this->id_etablissement_attache = null;
        $this->id_profil = null;
        $this->id_organisation_attache = null;
        $this->tentatives_mdp = null;
        $this->id_prestation_attache = null;
        $this->id_etablissement_gere = null;
        $this->id_organisation_gere = null;
        $this->actif = null;
        $this->alerte = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTAgendas) {
                foreach ($this->collTAgendas as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgentEtablissements) {
                foreach ($this->collTAgentEtablissements as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgentPrestations) {
                foreach ($this->collTAgentPrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPeriodeIndisponibilites) {
                foreach ($this->collTPeriodeIndisponibilites as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVoussRelatedByIdAgentAccueil) {
                foreach ($this->collTRendezVoussRelatedByIdAgentAccueil as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVoussRelatedByIdAgentAnnulation) {
                foreach ($this->collTRendezVoussRelatedByIdAgentAnnulation as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVoussRelatedByIdAgentConfirmation) {
                foreach ($this->collTRendezVoussRelatedByIdAgentConfirmation as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVoussRelatedByIdAgentRessource) {
                foreach ($this->collTRendezVoussRelatedByIdAgentRessource as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVoussRelatedByIdAgentTeleoperateur) {
                foreach ($this->collTRendezVoussRelatedByIdAgentTeleoperateur as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraductionRelatedByCodeNomUtilisateur instanceof Persistent) {
              $this->aTTraductionRelatedByCodeNomUtilisateur->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodePrenomUtilisateur instanceof Persistent) {
              $this->aTTraductionRelatedByCodePrenomUtilisateur->clearAllReferences($deep);
            }
            if ($this->aTEtablissementRelatedByIdEtablissementAttache instanceof Persistent) {
              $this->aTEtablissementRelatedByIdEtablissementAttache->clearAllReferences($deep);
            }
            if ($this->aTEtablissementRelatedByIdEtablissementGere instanceof Persistent) {
              $this->aTEtablissementRelatedByIdEtablissementGere->clearAllReferences($deep);
            }
            if ($this->aTOrganisationRelatedByIdOrganisationAttache instanceof Persistent) {
              $this->aTOrganisationRelatedByIdOrganisationAttache->clearAllReferences($deep);
            }
            if ($this->aTOrganisationRelatedByIdOrganisationGere instanceof Persistent) {
              $this->aTOrganisationRelatedByIdOrganisationGere->clearAllReferences($deep);
            }
            if ($this->aTPrestation instanceof Persistent) {
              $this->aTPrestation->clearAllReferences($deep);
            }
            if ($this->aTProfil instanceof Persistent) {
              $this->aTProfil->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeUtilisateur instanceof Persistent) {
              $this->aTTraductionRelatedByCodeUtilisateur->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTAgendas instanceof PropelCollection) {
            $this->collTAgendas->clearIterator();
        }
        $this->collTAgendas = null;
        if ($this->collTAgentEtablissements instanceof PropelCollection) {
            $this->collTAgentEtablissements->clearIterator();
        }
        $this->collTAgentEtablissements = null;
        if ($this->collTAgentPrestations instanceof PropelCollection) {
            $this->collTAgentPrestations->clearIterator();
        }
        $this->collTAgentPrestations = null;
        if ($this->collTPeriodeIndisponibilites instanceof PropelCollection) {
            $this->collTPeriodeIndisponibilites->clearIterator();
        }
        $this->collTPeriodeIndisponibilites = null;
        if ($this->collTRendezVoussRelatedByIdAgentAccueil instanceof PropelCollection) {
            $this->collTRendezVoussRelatedByIdAgentAccueil->clearIterator();
        }
        $this->collTRendezVoussRelatedByIdAgentAccueil = null;
        if ($this->collTRendezVoussRelatedByIdAgentAnnulation instanceof PropelCollection) {
            $this->collTRendezVoussRelatedByIdAgentAnnulation->clearIterator();
        }
        $this->collTRendezVoussRelatedByIdAgentAnnulation = null;
        if ($this->collTRendezVoussRelatedByIdAgentConfirmation instanceof PropelCollection) {
            $this->collTRendezVoussRelatedByIdAgentConfirmation->clearIterator();
        }
        $this->collTRendezVoussRelatedByIdAgentConfirmation = null;
        if ($this->collTRendezVoussRelatedByIdAgentRessource instanceof PropelCollection) {
            $this->collTRendezVoussRelatedByIdAgentRessource->clearIterator();
        }
        $this->collTRendezVoussRelatedByIdAgentRessource = null;
        if ($this->collTRendezVoussRelatedByIdAgentTeleoperateur instanceof PropelCollection) {
            $this->collTRendezVoussRelatedByIdAgentTeleoperateur->clearIterator();
        }
        $this->collTRendezVoussRelatedByIdAgentTeleoperateur = null;
        $this->aTTraductionRelatedByCodeNomUtilisateur = null;
        $this->aTTraductionRelatedByCodePrenomUtilisateur = null;
        $this->aTEtablissementRelatedByIdEtablissementAttache = null;
        $this->aTEtablissementRelatedByIdEtablissementGere = null;
        $this->aTOrganisationRelatedByIdOrganisationAttache = null;
        $this->aTOrganisationRelatedByIdOrganisationGere = null;
        $this->aTPrestation = null;
        $this->aTProfil = null;
        $this->aTTraductionRelatedByCodeUtilisateur = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TAgentPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
