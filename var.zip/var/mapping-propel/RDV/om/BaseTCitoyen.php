<?php


/**
 * Base class that represents a row from the 'T_CITOYEN' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTCitoyen extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TCitoyenPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TCitoyenPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_citoyen field.
     * @var        int
     */
    protected $id_citoyen;

    /**
     * The value for the raison_social field.
     * @var        string
     */
    protected $raison_social;

    /**
     * The value for the nom field.
     * @var        string
     */
    protected $nom;

    /**
     * The value for the prenom field.
     * @var        string
     */
    protected $prenom;

    /**
     * The value for the date_naissance field.
     * @var        string
     */
    protected $date_naissance;

    /**
     * The value for the identifiant field.
     * @var        string
     */
    protected $identifiant;

    /**
     * The value for the adresse field.
     * @var        string
     */
    protected $adresse;

    /**
     * The value for the mail field.
     * @var        string
     */
    protected $mail;

    /**
     * The value for the telephone field.
     * @var        string
     */
    protected $telephone;

    /**
     * The value for the fax field.
     * @var        string
     */
    protected $fax;

    /**
     * The value for the text_1 field.
     * @var        string
     */
    protected $text_1;

    /**
     * The value for the id_ref_1 field.
     * @var        int
     */
    protected $id_ref_1;

    /**
     * The value for the text_2 field.
     * @var        string
     */
    protected $text_2;

    /**
     * The value for the id_ref_2 field.
     * @var        int
     */
    protected $id_ref_2;

    /**
     * The value for the text_3 field.
     * @var        string
     */
    protected $text_3;

    /**
     * The value for the id_ref_3 field.
     * @var        int
     */
    protected $id_ref_3;

    /**
     * @var        TValeurReferentiel
     */
    protected $aTValeurReferentielRelatedByIdRef1;

    /**
     * @var        TValeurReferentiel
     */
    protected $aTValeurReferentielRelatedByIdRef2;

    /**
     * @var        TValeurReferentiel
     */
    protected $aTValeurReferentielRelatedByIdRef3;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVouss;
    protected $collTRendezVoussPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussScheduledForDeletion = null;

    /**
     * Get the [id_citoyen] column value.
     *
     * @return int
     */
    public function getIdCitoyen()
    {
        return $this->id_citoyen;
    }

    /**
     * Get the [raison_social] column value.
     *
     * @return string
     */
    public function getRaisonSocial()
    {
        return $this->raison_social;
    }

    /**
     * Get the [nom] column value.
     *
     * @return string
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Get the [prenom] column value.
     *
     * @return string
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Get the [optionally formatted] temporal [date_naissance] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateNaissance($format = '%x')
    {
        if ($this->date_naissance === null) {
            return null;
        }

        if ($this->date_naissance === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_naissance);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_naissance, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [identifiant] column value.
     *
     * @return string
     */
    public function getIdentifiant()
    {
        return $this->identifiant;
    }

    /**
     * Get the [adresse] column value.
     *
     * @return string
     */
    public function getAdresse()
    {
        return $this->adresse;
    }

    /**
     * Get the [mail] column value.
     *
     * @return string
     */
    public function getMail()
    {
        return $this->mail;
    }

    /**
     * Get the [telephone] column value.
     *
     * @return string
     */
    public function getTelephone()
    {
        return $this->telephone;
    }

    /**
     * Get the [fax] column value.
     *
     * @return string
     */
    public function getFax()
    {
        return $this->fax;
    }

    /**
     * Get the [text_1] column value.
     *
     * @return string
     */
    public function getText1()
    {
        return $this->text_1;
    }

    /**
     * Get the [id_ref_1] column value.
     *
     * @return int
     */
    public function getIdRef1()
    {
        return $this->id_ref_1;
    }

    /**
     * Get the [text_2] column value.
     *
     * @return string
     */
    public function getText2()
    {
        return $this->text_2;
    }

    /**
     * Get the [id_ref_2] column value.
     *
     * @return int
     */
    public function getIdRef2()
    {
        return $this->id_ref_2;
    }

    /**
     * Get the [text_3] column value.
     *
     * @return string
     */
    public function getText3()
    {
        return $this->text_3;
    }

    /**
     * Get the [id_ref_3] column value.
     *
     * @return int
     */
    public function getIdRef3()
    {
        return $this->id_ref_3;
    }

    /**
     * Set the value of [id_citoyen] column.
     *
     * @param int $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setIdCitoyen($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_citoyen !== $v) {
            $this->id_citoyen = $v;
            $this->modifiedColumns[] = TCitoyenPeer::ID_CITOYEN;
        }


        return $this;
    } // setIdCitoyen()

    /**
     * Set the value of [raison_social] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setRaisonSocial($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->raison_social !== $v) {
            $this->raison_social = $v;
            $this->modifiedColumns[] = TCitoyenPeer::RAISON_SOCIAL;
        }


        return $this;
    } // setRaisonSocial()

    /**
     * Set the value of [nom] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setNom($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->nom !== $v) {
            $this->nom = $v;
            $this->modifiedColumns[] = TCitoyenPeer::NOM;
        }


        return $this;
    } // setNom()

    /**
     * Set the value of [prenom] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setPrenom($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->prenom !== $v) {
            $this->prenom = $v;
            $this->modifiedColumns[] = TCitoyenPeer::PRENOM;
        }


        return $this;
    } // setPrenom()

    /**
     * Sets the value of [date_naissance] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setDateNaissance($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_naissance !== null || $dt !== null) {
            $currentDateAsString = ($this->date_naissance !== null && $tmpDt = new DateTime($this->date_naissance)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_naissance = $newDateAsString;
                $this->modifiedColumns[] = TCitoyenPeer::DATE_NAISSANCE;
            }
        } // if either are not null


        return $this;
    } // setDateNaissance()

    /**
     * Set the value of [identifiant] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setIdentifiant($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->identifiant !== $v) {
            $this->identifiant = $v;
            $this->modifiedColumns[] = TCitoyenPeer::IDENTIFIANT;
        }


        return $this;
    } // setIdentifiant()

    /**
     * Set the value of [adresse] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setAdresse($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->adresse !== $v) {
            $this->adresse = $v;
            $this->modifiedColumns[] = TCitoyenPeer::ADRESSE;
        }


        return $this;
    } // setAdresse()

    /**
     * Set the value of [mail] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setMail($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->mail !== $v) {
            $this->mail = $v;
            $this->modifiedColumns[] = TCitoyenPeer::MAIL;
        }


        return $this;
    } // setMail()

    /**
     * Set the value of [telephone] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setTelephone($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->telephone !== $v) {
            $this->telephone = $v;
            $this->modifiedColumns[] = TCitoyenPeer::TELEPHONE;
        }


        return $this;
    } // setTelephone()

    /**
     * Set the value of [fax] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setFax($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->fax !== $v) {
            $this->fax = $v;
            $this->modifiedColumns[] = TCitoyenPeer::FAX;
        }


        return $this;
    } // setFax()

    /**
     * Set the value of [text_1] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setText1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_1 !== $v) {
            $this->text_1 = $v;
            $this->modifiedColumns[] = TCitoyenPeer::TEXT_1;
        }


        return $this;
    } // setText1()

    /**
     * Set the value of [id_ref_1] column.
     *
     * @param int $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setIdRef1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_1 !== $v) {
            $this->id_ref_1 = $v;
            $this->modifiedColumns[] = TCitoyenPeer::ID_REF_1;
        }

        if ($this->aTValeurReferentielRelatedByIdRef1 !== null && $this->aTValeurReferentielRelatedByIdRef1->getIdValeurReferentiel() !== $v) {
            $this->aTValeurReferentielRelatedByIdRef1 = null;
        }


        return $this;
    } // setIdRef1()

    /**
     * Set the value of [text_2] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setText2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_2 !== $v) {
            $this->text_2 = $v;
            $this->modifiedColumns[] = TCitoyenPeer::TEXT_2;
        }


        return $this;
    } // setText2()

    /**
     * Set the value of [id_ref_2] column.
     *
     * @param int $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setIdRef2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_2 !== $v) {
            $this->id_ref_2 = $v;
            $this->modifiedColumns[] = TCitoyenPeer::ID_REF_2;
        }

        if ($this->aTValeurReferentielRelatedByIdRef2 !== null && $this->aTValeurReferentielRelatedByIdRef2->getIdValeurReferentiel() !== $v) {
            $this->aTValeurReferentielRelatedByIdRef2 = null;
        }


        return $this;
    } // setIdRef2()

    /**
     * Set the value of [text_3] column.
     *
     * @param string $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setText3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_3 !== $v) {
            $this->text_3 = $v;
            $this->modifiedColumns[] = TCitoyenPeer::TEXT_3;
        }


        return $this;
    } // setText3()

    /**
     * Set the value of [id_ref_3] column.
     *
     * @param int $v new value
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setIdRef3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_3 !== $v) {
            $this->id_ref_3 = $v;
            $this->modifiedColumns[] = TCitoyenPeer::ID_REF_3;
        }

        if ($this->aTValeurReferentielRelatedByIdRef3 !== null && $this->aTValeurReferentielRelatedByIdRef3->getIdValeurReferentiel() !== $v) {
            $this->aTValeurReferentielRelatedByIdRef3 = null;
        }


        return $this;
    } // setIdRef3()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_citoyen = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->raison_social = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->nom = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->prenom = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->date_naissance = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->identifiant = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->adresse = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->mail = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->telephone = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->fax = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->text_1 = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->id_ref_1 = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->text_2 = ($row[$startcol + 12] !== null) ? (string) $row[$startcol + 12] : null;
            $this->id_ref_2 = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->text_3 = ($row[$startcol + 14] !== null) ? (string) $row[$startcol + 14] : null;
            $this->id_ref_3 = ($row[$startcol + 15] !== null) ? (int) $row[$startcol + 15] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 16; // 16 = TCitoyenPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TCitoyen object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTValeurReferentielRelatedByIdRef1 !== null && $this->id_ref_1 !== $this->aTValeurReferentielRelatedByIdRef1->getIdValeurReferentiel()) {
            $this->aTValeurReferentielRelatedByIdRef1 = null;
        }
        if ($this->aTValeurReferentielRelatedByIdRef2 !== null && $this->id_ref_2 !== $this->aTValeurReferentielRelatedByIdRef2->getIdValeurReferentiel()) {
            $this->aTValeurReferentielRelatedByIdRef2 = null;
        }
        if ($this->aTValeurReferentielRelatedByIdRef3 !== null && $this->id_ref_3 !== $this->aTValeurReferentielRelatedByIdRef3->getIdValeurReferentiel()) {
            $this->aTValeurReferentielRelatedByIdRef3 = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TCitoyenPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTValeurReferentielRelatedByIdRef1 = null;
            $this->aTValeurReferentielRelatedByIdRef2 = null;
            $this->aTValeurReferentielRelatedByIdRef3 = null;
            $this->collTRendezVouss = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TCitoyenQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TCitoyenPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTValeurReferentielRelatedByIdRef1 !== null) {
                if ($this->aTValeurReferentielRelatedByIdRef1->isModified() || $this->aTValeurReferentielRelatedByIdRef1->isNew()) {
                    $affectedRows += $this->aTValeurReferentielRelatedByIdRef1->save($con);
                }
                $this->setTValeurReferentielRelatedByIdRef1($this->aTValeurReferentielRelatedByIdRef1);
            }

            if ($this->aTValeurReferentielRelatedByIdRef2 !== null) {
                if ($this->aTValeurReferentielRelatedByIdRef2->isModified() || $this->aTValeurReferentielRelatedByIdRef2->isNew()) {
                    $affectedRows += $this->aTValeurReferentielRelatedByIdRef2->save($con);
                }
                $this->setTValeurReferentielRelatedByIdRef2($this->aTValeurReferentielRelatedByIdRef2);
            }

            if ($this->aTValeurReferentielRelatedByIdRef3 !== null) {
                if ($this->aTValeurReferentielRelatedByIdRef3->isModified() || $this->aTValeurReferentielRelatedByIdRef3->isNew()) {
                    $affectedRows += $this->aTValeurReferentielRelatedByIdRef3->save($con);
                }
                $this->setTValeurReferentielRelatedByIdRef3($this->aTValeurReferentielRelatedByIdRef3);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tRendezVoussScheduledForDeletion !== null) {
                if (!$this->tRendezVoussScheduledForDeletion->isEmpty()) {
                    TRendezVousQuery::create()
                        ->filterByPrimaryKeys($this->tRendezVoussScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tRendezVoussScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVouss !== null) {
                foreach ($this->collTRendezVouss as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TCitoyenPeer::ID_CITOYEN;
        if (null !== $this->id_citoyen) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TCitoyenPeer::ID_CITOYEN . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TCitoyenPeer::ID_CITOYEN)) {
            $modifiedColumns[':p' . $index++]  = '`ID_CITOYEN`';
        }
        if ($this->isColumnModified(TCitoyenPeer::RAISON_SOCIAL)) {
            $modifiedColumns[':p' . $index++]  = '`RAISON_SOCIAL`';
        }
        if ($this->isColumnModified(TCitoyenPeer::NOM)) {
            $modifiedColumns[':p' . $index++]  = '`NOM`';
        }
        if ($this->isColumnModified(TCitoyenPeer::PRENOM)) {
            $modifiedColumns[':p' . $index++]  = '`PRENOM`';
        }
        if ($this->isColumnModified(TCitoyenPeer::DATE_NAISSANCE)) {
            $modifiedColumns[':p' . $index++]  = '`DATE_NAISSANCE`';
        }
        if ($this->isColumnModified(TCitoyenPeer::IDENTIFIANT)) {
            $modifiedColumns[':p' . $index++]  = '`IDENTIFIANT`';
        }
        if ($this->isColumnModified(TCitoyenPeer::ADRESSE)) {
            $modifiedColumns[':p' . $index++]  = '`ADRESSE`';
        }
        if ($this->isColumnModified(TCitoyenPeer::MAIL)) {
            $modifiedColumns[':p' . $index++]  = '`MAIL`';
        }
        if ($this->isColumnModified(TCitoyenPeer::TELEPHONE)) {
            $modifiedColumns[':p' . $index++]  = '`TELEPHONE`';
        }
        if ($this->isColumnModified(TCitoyenPeer::FAX)) {
            $modifiedColumns[':p' . $index++]  = '`FAX`';
        }
        if ($this->isColumnModified(TCitoyenPeer::TEXT_1)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_1`';
        }
        if ($this->isColumnModified(TCitoyenPeer::ID_REF_1)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_1`';
        }
        if ($this->isColumnModified(TCitoyenPeer::TEXT_2)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_2`';
        }
        if ($this->isColumnModified(TCitoyenPeer::ID_REF_2)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_2`';
        }
        if ($this->isColumnModified(TCitoyenPeer::TEXT_3)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_3`';
        }
        if ($this->isColumnModified(TCitoyenPeer::ID_REF_3)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_3`';
        }

        $sql = sprintf(
            'INSERT INTO `T_CITOYEN` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_CITOYEN`':
                        $stmt->bindValue($identifier, $this->id_citoyen, PDO::PARAM_INT);
                        break;
                    case '`RAISON_SOCIAL`':
                        $stmt->bindValue($identifier, $this->raison_social, PDO::PARAM_STR);
                        break;
                    case '`NOM`':
                        $stmt->bindValue($identifier, $this->nom, PDO::PARAM_STR);
                        break;
                    case '`PRENOM`':
                        $stmt->bindValue($identifier, $this->prenom, PDO::PARAM_STR);
                        break;
                    case '`DATE_NAISSANCE`':
                        $stmt->bindValue($identifier, $this->date_naissance, PDO::PARAM_STR);
                        break;
                    case '`IDENTIFIANT`':
                        $stmt->bindValue($identifier, $this->identifiant, PDO::PARAM_STR);
                        break;
                    case '`ADRESSE`':
                        $stmt->bindValue($identifier, $this->adresse, PDO::PARAM_STR);
                        break;
                    case '`MAIL`':
                        $stmt->bindValue($identifier, $this->mail, PDO::PARAM_STR);
                        break;
                    case '`TELEPHONE`':
                        $stmt->bindValue($identifier, $this->telephone, PDO::PARAM_STR);
                        break;
                    case '`FAX`':
                        $stmt->bindValue($identifier, $this->fax, PDO::PARAM_STR);
                        break;
                    case '`TEXT_1`':
                        $stmt->bindValue($identifier, $this->text_1, PDO::PARAM_STR);
                        break;
                    case '`ID_REF_1`':
                        $stmt->bindValue($identifier, $this->id_ref_1, PDO::PARAM_INT);
                        break;
                    case '`TEXT_2`':
                        $stmt->bindValue($identifier, $this->text_2, PDO::PARAM_STR);
                        break;
                    case '`ID_REF_2`':
                        $stmt->bindValue($identifier, $this->id_ref_2, PDO::PARAM_INT);
                        break;
                    case '`TEXT_3`':
                        $stmt->bindValue($identifier, $this->text_3, PDO::PARAM_STR);
                        break;
                    case '`ID_REF_3`':
                        $stmt->bindValue($identifier, $this->id_ref_3, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdCitoyen($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTValeurReferentielRelatedByIdRef1 !== null) {
                if (!$this->aTValeurReferentielRelatedByIdRef1->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTValeurReferentielRelatedByIdRef1->getValidationFailures());
                }
            }

            if ($this->aTValeurReferentielRelatedByIdRef2 !== null) {
                if (!$this->aTValeurReferentielRelatedByIdRef2->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTValeurReferentielRelatedByIdRef2->getValidationFailures());
                }
            }

            if ($this->aTValeurReferentielRelatedByIdRef3 !== null) {
                if (!$this->aTValeurReferentielRelatedByIdRef3->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTValeurReferentielRelatedByIdRef3->getValidationFailures());
                }
            }


            if (($retval = TCitoyenPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTRendezVouss !== null) {
                    foreach ($this->collTRendezVouss as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TCitoyenPeer::DATABASE_NAME);

        if ($this->isColumnModified(TCitoyenPeer::ID_CITOYEN)) $criteria->add(TCitoyenPeer::ID_CITOYEN, $this->id_citoyen);
        if ($this->isColumnModified(TCitoyenPeer::RAISON_SOCIAL)) $criteria->add(TCitoyenPeer::RAISON_SOCIAL, $this->raison_social);
        if ($this->isColumnModified(TCitoyenPeer::NOM)) $criteria->add(TCitoyenPeer::NOM, $this->nom);
        if ($this->isColumnModified(TCitoyenPeer::PRENOM)) $criteria->add(TCitoyenPeer::PRENOM, $this->prenom);
        if ($this->isColumnModified(TCitoyenPeer::DATE_NAISSANCE)) $criteria->add(TCitoyenPeer::DATE_NAISSANCE, $this->date_naissance);
        if ($this->isColumnModified(TCitoyenPeer::IDENTIFIANT)) $criteria->add(TCitoyenPeer::IDENTIFIANT, $this->identifiant);
        if ($this->isColumnModified(TCitoyenPeer::ADRESSE)) $criteria->add(TCitoyenPeer::ADRESSE, $this->adresse);
        if ($this->isColumnModified(TCitoyenPeer::MAIL)) $criteria->add(TCitoyenPeer::MAIL, $this->mail);
        if ($this->isColumnModified(TCitoyenPeer::TELEPHONE)) $criteria->add(TCitoyenPeer::TELEPHONE, $this->telephone);
        if ($this->isColumnModified(TCitoyenPeer::FAX)) $criteria->add(TCitoyenPeer::FAX, $this->fax);
        if ($this->isColumnModified(TCitoyenPeer::TEXT_1)) $criteria->add(TCitoyenPeer::TEXT_1, $this->text_1);
        if ($this->isColumnModified(TCitoyenPeer::ID_REF_1)) $criteria->add(TCitoyenPeer::ID_REF_1, $this->id_ref_1);
        if ($this->isColumnModified(TCitoyenPeer::TEXT_2)) $criteria->add(TCitoyenPeer::TEXT_2, $this->text_2);
        if ($this->isColumnModified(TCitoyenPeer::ID_REF_2)) $criteria->add(TCitoyenPeer::ID_REF_2, $this->id_ref_2);
        if ($this->isColumnModified(TCitoyenPeer::TEXT_3)) $criteria->add(TCitoyenPeer::TEXT_3, $this->text_3);
        if ($this->isColumnModified(TCitoyenPeer::ID_REF_3)) $criteria->add(TCitoyenPeer::ID_REF_3, $this->id_ref_3);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TCitoyenPeer::DATABASE_NAME);
        $criteria->add(TCitoyenPeer::ID_CITOYEN, $this->id_citoyen);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdCitoyen();
    }

    /**
     * Generic method to set the primary key (id_citoyen column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdCitoyen($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdCitoyen();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TCitoyen (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setRaisonSocial($this->getRaisonSocial());
        $copyObj->setNom($this->getNom());
        $copyObj->setPrenom($this->getPrenom());
        $copyObj->setDateNaissance($this->getDateNaissance());
        $copyObj->setIdentifiant($this->getIdentifiant());
        $copyObj->setAdresse($this->getAdresse());
        $copyObj->setMail($this->getMail());
        $copyObj->setTelephone($this->getTelephone());
        $copyObj->setFax($this->getFax());
        $copyObj->setText1($this->getText1());
        $copyObj->setIdRef1($this->getIdRef1());
        $copyObj->setText2($this->getText2());
        $copyObj->setIdRef2($this->getIdRef2());
        $copyObj->setText3($this->getText3());
        $copyObj->setIdRef3($this->getIdRef3());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTRendezVouss() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVous($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdCitoyen(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TCitoyen Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TCitoyenPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TCitoyenPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TValeurReferentiel object.
     *
     * @param             TValeurReferentiel $v
     * @return TCitoyen The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTValeurReferentielRelatedByIdRef1(TValeurReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdRef1(NULL);
        } else {
            $this->setIdRef1($v->getIdValeurReferentiel());
        }

        $this->aTValeurReferentielRelatedByIdRef1 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TValeurReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTCitoyenRelatedByIdRef1($this);
        }


        return $this;
    }


    /**
     * Get the associated TValeurReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TValeurReferentiel The associated TValeurReferentiel object.
     * @throws PropelException
     */
    public function getTValeurReferentielRelatedByIdRef1(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTValeurReferentielRelatedByIdRef1 === null && ($this->id_ref_1 !== null) && $doQuery) {
            $this->aTValeurReferentielRelatedByIdRef1 = TValeurReferentielQuery::create()->findPk($this->id_ref_1, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTValeurReferentielRelatedByIdRef1->addTCitoyensRelatedByIdRef1($this);
             */
        }

        return $this->aTValeurReferentielRelatedByIdRef1;
    }

    /**
     * Declares an association between this object and a TValeurReferentiel object.
     *
     * @param             TValeurReferentiel $v
     * @return TCitoyen The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTValeurReferentielRelatedByIdRef2(TValeurReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdRef2(NULL);
        } else {
            $this->setIdRef2($v->getIdValeurReferentiel());
        }

        $this->aTValeurReferentielRelatedByIdRef2 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TValeurReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTCitoyenRelatedByIdRef2($this);
        }


        return $this;
    }


    /**
     * Get the associated TValeurReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TValeurReferentiel The associated TValeurReferentiel object.
     * @throws PropelException
     */
    public function getTValeurReferentielRelatedByIdRef2(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTValeurReferentielRelatedByIdRef2 === null && ($this->id_ref_2 !== null) && $doQuery) {
            $this->aTValeurReferentielRelatedByIdRef2 = TValeurReferentielQuery::create()->findPk($this->id_ref_2, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTValeurReferentielRelatedByIdRef2->addTCitoyensRelatedByIdRef2($this);
             */
        }

        return $this->aTValeurReferentielRelatedByIdRef2;
    }

    /**
     * Declares an association between this object and a TValeurReferentiel object.
     *
     * @param             TValeurReferentiel $v
     * @return TCitoyen The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTValeurReferentielRelatedByIdRef3(TValeurReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdRef3(NULL);
        } else {
            $this->setIdRef3($v->getIdValeurReferentiel());
        }

        $this->aTValeurReferentielRelatedByIdRef3 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TValeurReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTCitoyenRelatedByIdRef3($this);
        }


        return $this;
    }


    /**
     * Get the associated TValeurReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TValeurReferentiel The associated TValeurReferentiel object.
     * @throws PropelException
     */
    public function getTValeurReferentielRelatedByIdRef3(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTValeurReferentielRelatedByIdRef3 === null && ($this->id_ref_3 !== null) && $doQuery) {
            $this->aTValeurReferentielRelatedByIdRef3 = TValeurReferentielQuery::create()->findPk($this->id_ref_3, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTValeurReferentielRelatedByIdRef3->addTCitoyensRelatedByIdRef3($this);
             */
        }

        return $this->aTValeurReferentielRelatedByIdRef3;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TRendezVous' == $relationName) {
            $this->initTRendezVouss();
        }
    }

    /**
     * Clears out the collTRendezVouss collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TCitoyen The current object (for fluent API support)
     * @see        addTRendezVouss()
     */
    public function clearTRendezVouss()
    {
        $this->collTRendezVouss = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVouss collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVouss($v = true)
    {
        $this->collTRendezVoussPartial = $v;
    }

    /**
     * Initializes the collTRendezVouss collection.
     *
     * By default this just sets the collTRendezVouss collection to an empty array (like clearcollTRendezVouss());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVouss($overrideExisting = true)
    {
        if (null !== $this->collTRendezVouss && !$overrideExisting) {
            return;
        }
        $this->collTRendezVouss = new PropelObjectCollection();
        $this->collTRendezVouss->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TCitoyen is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVouss($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                // return empty collection
                $this->initTRendezVouss();
            } else {
                $collTRendezVouss = TRendezVousQuery::create(null, $criteria)
                    ->filterByTCitoyen($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussPartial && count($collTRendezVouss)) {
                      $this->initTRendezVouss(false);

                      foreach($collTRendezVouss as $obj) {
                        if (false == $this->collTRendezVouss->contains($obj)) {
                          $this->collTRendezVouss->append($obj);
                        }
                      }

                      $this->collTRendezVoussPartial = true;
                    }

                    $collTRendezVouss->getInternalIterator()->rewind();
                    return $collTRendezVouss;
                }

                if($partial && $this->collTRendezVouss) {
                    foreach($this->collTRendezVouss as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVouss[] = $obj;
                        }
                    }
                }

                $this->collTRendezVouss = $collTRendezVouss;
                $this->collTRendezVoussPartial = false;
            }
        }

        return $this->collTRendezVouss;
    }

    /**
     * Sets a collection of TRendezVous objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVouss A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TCitoyen The current object (for fluent API support)
     */
    public function setTRendezVouss(PropelCollection $tRendezVouss, PropelPDO $con = null)
    {
        $tRendezVoussToDelete = $this->getTRendezVouss(new Criteria(), $con)->diff($tRendezVouss);

        $this->tRendezVoussScheduledForDeletion = unserialize(serialize($tRendezVoussToDelete));

        foreach ($tRendezVoussToDelete as $tRendezVousRemoved) {
            $tRendezVousRemoved->setTCitoyen(null);
        }

        $this->collTRendezVouss = null;
        foreach ($tRendezVouss as $tRendezVous) {
            $this->addTRendezVous($tRendezVous);
        }

        $this->collTRendezVouss = $tRendezVouss;
        $this->collTRendezVoussPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVouss(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVouss());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTCitoyen($this)
                ->count($con);
        }

        return count($this->collTRendezVouss);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TCitoyen The current object (for fluent API support)
     */
    public function addTRendezVous(TRendezVous $l)
    {
        if ($this->collTRendezVouss === null) {
            $this->initTRendezVouss();
            $this->collTRendezVoussPartial = true;
        }
        if (!in_array($l, $this->collTRendezVouss->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVous($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to add.
     */
    protected function doAddTRendezVous($tRendezVous)
    {
        $this->collTRendezVouss[]= $tRendezVous;
        $tRendezVous->setTCitoyen($this);
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to remove.
     * @return TCitoyen The current object (for fluent API support)
     */
    public function removeTRendezVous($tRendezVous)
    {
        if ($this->getTRendezVouss()->contains($tRendezVous)) {
            $this->collTRendezVouss->remove($this->collTRendezVouss->search($tRendezVous));
            if (null === $this->tRendezVoussScheduledForDeletion) {
                $this->tRendezVoussScheduledForDeletion = clone $this->collTRendezVouss;
                $this->tRendezVoussScheduledForDeletion->clear();
            }
            $this->tRendezVoussScheduledForDeletion[]= clone $tRendezVous;
            $tRendezVous->setTCitoyen(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAccueil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAccueil', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAnnulation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAnnulation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentConfirmation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentConfirmation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentRessource($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentRessource', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentTeleoperateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentTeleoperateur', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TCitoyen is new, it will return
     * an empty collection; or if this TCitoyen has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TCitoyen.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_citoyen = null;
        $this->raison_social = null;
        $this->nom = null;
        $this->prenom = null;
        $this->date_naissance = null;
        $this->identifiant = null;
        $this->adresse = null;
        $this->mail = null;
        $this->telephone = null;
        $this->fax = null;
        $this->text_1 = null;
        $this->id_ref_1 = null;
        $this->text_2 = null;
        $this->id_ref_2 = null;
        $this->text_3 = null;
        $this->id_ref_3 = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTRendezVouss) {
                foreach ($this->collTRendezVouss as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTValeurReferentielRelatedByIdRef1 instanceof Persistent) {
              $this->aTValeurReferentielRelatedByIdRef1->clearAllReferences($deep);
            }
            if ($this->aTValeurReferentielRelatedByIdRef2 instanceof Persistent) {
              $this->aTValeurReferentielRelatedByIdRef2->clearAllReferences($deep);
            }
            if ($this->aTValeurReferentielRelatedByIdRef3 instanceof Persistent) {
              $this->aTValeurReferentielRelatedByIdRef3->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTRendezVouss instanceof PropelCollection) {
            $this->collTRendezVouss->clearIterator();
        }
        $this->collTRendezVouss = null;
        $this->aTValeurReferentielRelatedByIdRef1 = null;
        $this->aTValeurReferentielRelatedByIdRef2 = null;
        $this->aTValeurReferentielRelatedByIdRef3 = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TCitoyenPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
