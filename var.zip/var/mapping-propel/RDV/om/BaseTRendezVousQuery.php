<?php


/**
 * Base class that represents a query for the 'T_RENDEZ_VOUS' table.
 *
 *
 *
 * @method TRendezVousQuery orderByIdRendezVous($order = Criteria::ASC) Order by the ID_RENDEZ_VOUS column
 * @method TRendezVousQuery orderByDateCreation($order = Criteria::ASC) Order by the DATE_CREATION column
 * @method TRendezVousQuery orderByDateConfirmation($order = Criteria::ASC) Order by the DATE_CONFIRMATION column
 * @method TRendezVousQuery orderByDateAnnulation($order = Criteria::ASC) Order by the DATE_ANNULATION column
 * @method TRendezVousQuery orderByMotifAnnulation($order = Criteria::ASC) Order by the MOTIF_ANNULATION column
 * @method TRendezVousQuery orderByDateRdv($order = Criteria::ASC) Order by the DATE_RDV column
 * @method TRendezVousQuery orderByDateFinRdv($order = Criteria::ASC) Order by the DATE_FIN_RDV column
 * @method TRendezVousQuery orderByCodeRdv($order = Criteria::ASC) Order by the CODE_RDV column
 * @method TRendezVousQuery orderByEtatRdv($order = Criteria::ASC) Order by the ETAT_RDV column
 * @method TRendezVousQuery orderByModePriseRdv($order = Criteria::ASC) Order by the MODE_PRISE_RDV column
 * @method TRendezVousQuery orderByTypePriseRdv($order = Criteria::ASC) Order by the TYPE_PRISE_RDV column
 * @method TRendezVousQuery orderByIdCitoyen($order = Criteria::ASC) Order by the ID_CITOYEN column
 * @method TRendezVousQuery orderByIdAgentAccueil($order = Criteria::ASC) Order by the ID_AGENT_ACCUEIL column
 * @method TRendezVousQuery orderByIdEtablissement($order = Criteria::ASC) Order by the ID_ETABLISSEMENT column
 * @method TRendezVousQuery orderByIdPrestation($order = Criteria::ASC) Order by the ID_PRESTATION column
 * @method TRendezVousQuery orderByIdAgentRessource($order = Criteria::ASC) Order by the ID_AGENT_RESSOURCE column
 * @method TRendezVousQuery orderByIdAgentTeleoperateur($order = Criteria::ASC) Order by the ID_AGENT_TELEOPERATEUR column
 * @method TRendezVousQuery orderByIdAgentConfirmation($order = Criteria::ASC) Order by the ID_AGENT_CONFIRMATION column
 * @method TRendezVousQuery orderByIdAgentAnnulation($order = Criteria::ASC) Order by the ID_AGENT_ANNULATION column
 * @method TRendezVousQuery orderByIdReferent($order = Criteria::ASC) Order by the ID_REFERENT column
 * @method TRendezVousQuery orderByTagGateway($order = Criteria::ASC) Order by the TAG_GATEWAY column
 * @method TRendezVousQuery orderByIdUtilisateur($order = Criteria::ASC) Order by the ID_UTILISATEUR column
 * @method TRendezVousQuery orderByEtatAcquittement($order = Criteria::ASC) Order by the ETAT_ACQUITTEMENT column
 * @method TRendezVousQuery orderByDateAcquittement($order = Criteria::ASC) Order by the DATE_ACQUITTEMENT column
 * @method TRendezVousQuery orderByChampSuppPresta($order = Criteria::ASC) Order by the CHAMP_SUPP_PRESTA column
 * @method TRendezVousQuery orderByIdChefRessource($order = Criteria::ASC) Order by the ID_CHEF_RESSOURCE column
 * @method TRendezVousQuery orderByPartageRecap($order = Criteria::ASC) Order by the PARTAGE_RECAP column
 * @method TRendezVousQuery orderByNatureSession($order = Criteria::ASC) Order by the NATURE_SESSION column
 * @method TRendezVousQuery orderByLieuRdv($order = Criteria::ASC) Order by the LIEU_RDV column
 * @method TRendezVousQuery orderByLienRdv($order = Criteria::ASC) Order by the LIEN_RDV column
 * @method TRendezVousQuery orderByNombreParticipant($order = Criteria::ASC) Order by the NOMBRE_PARTICIPANT column
 * @method TRendezVousQuery orderByCommentaire($order = Criteria::ASC) Order by the COMMENTAIRE column
 * @method TRendezVousQuery orderByIdValeurReferentiel($order = Criteria::ASC) Order by the ID_VALEUR_REFERENTIEL column
 *
 * @method TRendezVousQuery groupByIdRendezVous() Group by the ID_RENDEZ_VOUS column
 * @method TRendezVousQuery groupByDateCreation() Group by the DATE_CREATION column
 * @method TRendezVousQuery groupByDateConfirmation() Group by the DATE_CONFIRMATION column
 * @method TRendezVousQuery groupByDateAnnulation() Group by the DATE_ANNULATION column
 * @method TRendezVousQuery groupByMotifAnnulation() Group by the MOTIF_ANNULATION column
 * @method TRendezVousQuery groupByDateRdv() Group by the DATE_RDV column
 * @method TRendezVousQuery groupByDateFinRdv() Group by the DATE_FIN_RDV column
 * @method TRendezVousQuery groupByCodeRdv() Group by the CODE_RDV column
 * @method TRendezVousQuery groupByEtatRdv() Group by the ETAT_RDV column
 * @method TRendezVousQuery groupByModePriseRdv() Group by the MODE_PRISE_RDV column
 * @method TRendezVousQuery groupByTypePriseRdv() Group by the TYPE_PRISE_RDV column
 * @method TRendezVousQuery groupByIdCitoyen() Group by the ID_CITOYEN column
 * @method TRendezVousQuery groupByIdAgentAccueil() Group by the ID_AGENT_ACCUEIL column
 * @method TRendezVousQuery groupByIdEtablissement() Group by the ID_ETABLISSEMENT column
 * @method TRendezVousQuery groupByIdPrestation() Group by the ID_PRESTATION column
 * @method TRendezVousQuery groupByIdAgentRessource() Group by the ID_AGENT_RESSOURCE column
 * @method TRendezVousQuery groupByIdAgentTeleoperateur() Group by the ID_AGENT_TELEOPERATEUR column
 * @method TRendezVousQuery groupByIdAgentConfirmation() Group by the ID_AGENT_CONFIRMATION column
 * @method TRendezVousQuery groupByIdAgentAnnulation() Group by the ID_AGENT_ANNULATION column
 * @method TRendezVousQuery groupByIdReferent() Group by the ID_REFERENT column
 * @method TRendezVousQuery groupByTagGateway() Group by the TAG_GATEWAY column
 * @method TRendezVousQuery groupByIdUtilisateur() Group by the ID_UTILISATEUR column
 * @method TRendezVousQuery groupByEtatAcquittement() Group by the ETAT_ACQUITTEMENT column
 * @method TRendezVousQuery groupByDateAcquittement() Group by the DATE_ACQUITTEMENT column
 * @method TRendezVousQuery groupByChampSuppPresta() Group by the CHAMP_SUPP_PRESTA column
 * @method TRendezVousQuery groupByIdChefRessource() Group by the ID_CHEF_RESSOURCE column
 * @method TRendezVousQuery groupByPartageRecap() Group by the PARTAGE_RECAP column
 * @method TRendezVousQuery groupByNatureSession() Group by the NATURE_SESSION column
 * @method TRendezVousQuery groupByLieuRdv() Group by the LIEU_RDV column
 * @method TRendezVousQuery groupByLienRdv() Group by the LIEN_RDV column
 * @method TRendezVousQuery groupByNombreParticipant() Group by the NOMBRE_PARTICIPANT column
 * @method TRendezVousQuery groupByCommentaire() Group by the COMMENTAIRE column
 * @method TRendezVousQuery groupByIdValeurReferentiel() Group by the ID_VALEUR_REFERENTIEL column
 *
 * @method TRendezVousQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TRendezVousQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TRendezVousQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TRendezVousQuery leftJoinTCitoyen($relationAlias = null) Adds a LEFT JOIN clause to the query using the TCitoyen relation
 * @method TRendezVousQuery rightJoinTCitoyen($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TCitoyen relation
 * @method TRendezVousQuery innerJoinTCitoyen($relationAlias = null) Adds a INNER JOIN clause to the query using the TCitoyen relation
 *
 * @method TRendezVousQuery leftJoinTAgentRelatedByIdAgentAccueil($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdAgentAccueil relation
 * @method TRendezVousQuery rightJoinTAgentRelatedByIdAgentAccueil($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdAgentAccueil relation
 * @method TRendezVousQuery innerJoinTAgentRelatedByIdAgentAccueil($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdAgentAccueil relation
 *
 * @method TRendezVousQuery leftJoinTAgentRelatedByIdAgentAnnulation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdAgentAnnulation relation
 * @method TRendezVousQuery rightJoinTAgentRelatedByIdAgentAnnulation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdAgentAnnulation relation
 * @method TRendezVousQuery innerJoinTAgentRelatedByIdAgentAnnulation($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdAgentAnnulation relation
 *
 * @method TRendezVousQuery leftJoinTAgentRelatedByIdAgentConfirmation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdAgentConfirmation relation
 * @method TRendezVousQuery rightJoinTAgentRelatedByIdAgentConfirmation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdAgentConfirmation relation
 * @method TRendezVousQuery innerJoinTAgentRelatedByIdAgentConfirmation($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdAgentConfirmation relation
 *
 * @method TRendezVousQuery leftJoinTAgentRelatedByIdAgentRessource($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdAgentRessource relation
 * @method TRendezVousQuery rightJoinTAgentRelatedByIdAgentRessource($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdAgentRessource relation
 * @method TRendezVousQuery innerJoinTAgentRelatedByIdAgentRessource($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdAgentRessource relation
 *
 * @method TRendezVousQuery leftJoinTAgentRelatedByIdAgentTeleoperateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdAgentTeleoperateur relation
 * @method TRendezVousQuery rightJoinTAgentRelatedByIdAgentTeleoperateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdAgentTeleoperateur relation
 * @method TRendezVousQuery innerJoinTAgentRelatedByIdAgentTeleoperateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdAgentTeleoperateur relation
 *
 * @method TRendezVousQuery leftJoinTValeurReferentiel($relationAlias = null) Adds a LEFT JOIN clause to the query using the TValeurReferentiel relation
 * @method TRendezVousQuery rightJoinTValeurReferentiel($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TValeurReferentiel relation
 * @method TRendezVousQuery innerJoinTValeurReferentiel($relationAlias = null) Adds a INNER JOIN clause to the query using the TValeurReferentiel relation
 *
 * @method TRendezVousQuery leftJoinTEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissement relation
 * @method TRendezVousQuery rightJoinTEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissement relation
 * @method TRendezVousQuery innerJoinTEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissement relation
 *
 * @method TRendezVousQuery leftJoinTPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestation relation
 * @method TRendezVousQuery rightJoinTPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestation relation
 * @method TRendezVousQuery innerJoinTPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestation relation
 *
 * @method TRendezVousQuery leftJoinTReferent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferent relation
 * @method TRendezVousQuery rightJoinTReferent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferent relation
 * @method TRendezVousQuery innerJoinTReferent($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferent relation
 *
 * @method TRendezVousQuery leftJoinTBlobRdv($relationAlias = null) Adds a LEFT JOIN clause to the query using the TBlobRdv relation
 * @method TRendezVousQuery rightJoinTBlobRdv($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TBlobRdv relation
 * @method TRendezVousQuery innerJoinTBlobRdv($relationAlias = null) Adds a INNER JOIN clause to the query using the TBlobRdv relation
 *
 * @method TRendezVousQuery leftJoinTParticipant($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParticipant relation
 * @method TRendezVousQuery rightJoinTParticipant($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParticipant relation
 * @method TRendezVousQuery innerJoinTParticipant($relationAlias = null) Adds a INNER JOIN clause to the query using the TParticipant relation
 *
 * @method TRendezVous findOne(PropelPDO $con = null) Return the first TRendezVous matching the query
 * @method TRendezVous findOneOrCreate(PropelPDO $con = null) Return the first TRendezVous matching the query, or a new TRendezVous object populated from the query conditions when no match is found
 *
 * @method TRendezVous findOneByDateCreation(string $DATE_CREATION) Return the first TRendezVous filtered by the DATE_CREATION column
 * @method TRendezVous findOneByDateConfirmation(string $DATE_CONFIRMATION) Return the first TRendezVous filtered by the DATE_CONFIRMATION column
 * @method TRendezVous findOneByDateAnnulation(string $DATE_ANNULATION) Return the first TRendezVous filtered by the DATE_ANNULATION column
 * @method TRendezVous findOneByMotifAnnulation(string $MOTIF_ANNULATION) Return the first TRendezVous filtered by the MOTIF_ANNULATION column
 * @method TRendezVous findOneByDateRdv(string $DATE_RDV) Return the first TRendezVous filtered by the DATE_RDV column
 * @method TRendezVous findOneByDateFinRdv(string $DATE_FIN_RDV) Return the first TRendezVous filtered by the DATE_FIN_RDV column
 * @method TRendezVous findOneByCodeRdv(string $CODE_RDV) Return the first TRendezVous filtered by the CODE_RDV column
 * @method TRendezVous findOneByEtatRdv(string $ETAT_RDV) Return the first TRendezVous filtered by the ETAT_RDV column
 * @method TRendezVous findOneByModePriseRdv(string $MODE_PRISE_RDV) Return the first TRendezVous filtered by the MODE_PRISE_RDV column
 * @method TRendezVous findOneByTypePriseRdv(string $TYPE_PRISE_RDV) Return the first TRendezVous filtered by the TYPE_PRISE_RDV column
 * @method TRendezVous findOneByIdCitoyen(int $ID_CITOYEN) Return the first TRendezVous filtered by the ID_CITOYEN column
 * @method TRendezVous findOneByIdAgentAccueil(int $ID_AGENT_ACCUEIL) Return the first TRendezVous filtered by the ID_AGENT_ACCUEIL column
 * @method TRendezVous findOneByIdEtablissement(int $ID_ETABLISSEMENT) Return the first TRendezVous filtered by the ID_ETABLISSEMENT column
 * @method TRendezVous findOneByIdPrestation(int $ID_PRESTATION) Return the first TRendezVous filtered by the ID_PRESTATION column
 * @method TRendezVous findOneByIdAgentRessource(int $ID_AGENT_RESSOURCE) Return the first TRendezVous filtered by the ID_AGENT_RESSOURCE column
 * @method TRendezVous findOneByIdAgentTeleoperateur(int $ID_AGENT_TELEOPERATEUR) Return the first TRendezVous filtered by the ID_AGENT_TELEOPERATEUR column
 * @method TRendezVous findOneByIdAgentConfirmation(int $ID_AGENT_CONFIRMATION) Return the first TRendezVous filtered by the ID_AGENT_CONFIRMATION column
 * @method TRendezVous findOneByIdAgentAnnulation(int $ID_AGENT_ANNULATION) Return the first TRendezVous filtered by the ID_AGENT_ANNULATION column
 * @method TRendezVous findOneByIdReferent(int $ID_REFERENT) Return the first TRendezVous filtered by the ID_REFERENT column
 * @method TRendezVous findOneByTagGateway(string $TAG_GATEWAY) Return the first TRendezVous filtered by the TAG_GATEWAY column
 * @method TRendezVous findOneByIdUtilisateur(string $ID_UTILISATEUR) Return the first TRendezVous filtered by the ID_UTILISATEUR column
 * @method TRendezVous findOneByEtatAcquittement(int $ETAT_ACQUITTEMENT) Return the first TRendezVous filtered by the ETAT_ACQUITTEMENT column
 * @method TRendezVous findOneByDateAcquittement(string $DATE_ACQUITTEMENT) Return the first TRendezVous filtered by the DATE_ACQUITTEMENT column
 * @method TRendezVous findOneByChampSuppPresta(string $CHAMP_SUPP_PRESTA) Return the first TRendezVous filtered by the CHAMP_SUPP_PRESTA column
 * @method TRendezVous findOneByIdChefRessource(int $ID_CHEF_RESSOURCE) Return the first TRendezVous filtered by the ID_CHEF_RESSOURCE column
 * @method TRendezVous findOneByPartageRecap(string $PARTAGE_RECAP) Return the first TRendezVous filtered by the PARTAGE_RECAP column
 * @method TRendezVous findOneByNatureSession(string $NATURE_SESSION) Return the first TRendezVous filtered by the NATURE_SESSION column
 * @method TRendezVous findOneByLieuRdv(string $LIEU_RDV) Return the first TRendezVous filtered by the LIEU_RDV column
 * @method TRendezVous findOneByLienRdv(string $LIEN_RDV) Return the first TRendezVous filtered by the LIEN_RDV column
 * @method TRendezVous findOneByNombreParticipant(int $NOMBRE_PARTICIPANT) Return the first TRendezVous filtered by the NOMBRE_PARTICIPANT column
 * @method TRendezVous findOneByCommentaire(string $COMMENTAIRE) Return the first TRendezVous filtered by the COMMENTAIRE column
 * @method TRendezVous findOneByIdValeurReferentiel(int $ID_VALEUR_REFERENTIEL) Return the first TRendezVous filtered by the ID_VALEUR_REFERENTIEL column
 *
 * @method array findByIdRendezVous(int $ID_RENDEZ_VOUS) Return TRendezVous objects filtered by the ID_RENDEZ_VOUS column
 * @method array findByDateCreation(string $DATE_CREATION) Return TRendezVous objects filtered by the DATE_CREATION column
 * @method array findByDateConfirmation(string $DATE_CONFIRMATION) Return TRendezVous objects filtered by the DATE_CONFIRMATION column
 * @method array findByDateAnnulation(string $DATE_ANNULATION) Return TRendezVous objects filtered by the DATE_ANNULATION column
 * @method array findByMotifAnnulation(string $MOTIF_ANNULATION) Return TRendezVous objects filtered by the MOTIF_ANNULATION column
 * @method array findByDateRdv(string $DATE_RDV) Return TRendezVous objects filtered by the DATE_RDV column
 * @method array findByDateFinRdv(string $DATE_FIN_RDV) Return TRendezVous objects filtered by the DATE_FIN_RDV column
 * @method array findByCodeRdv(string $CODE_RDV) Return TRendezVous objects filtered by the CODE_RDV column
 * @method array findByEtatRdv(string $ETAT_RDV) Return TRendezVous objects filtered by the ETAT_RDV column
 * @method array findByModePriseRdv(string $MODE_PRISE_RDV) Return TRendezVous objects filtered by the MODE_PRISE_RDV column
 * @method array findByTypePriseRdv(string $TYPE_PRISE_RDV) Return TRendezVous objects filtered by the TYPE_PRISE_RDV column
 * @method array findByIdCitoyen(int $ID_CITOYEN) Return TRendezVous objects filtered by the ID_CITOYEN column
 * @method array findByIdAgentAccueil(int $ID_AGENT_ACCUEIL) Return TRendezVous objects filtered by the ID_AGENT_ACCUEIL column
 * @method array findByIdEtablissement(int $ID_ETABLISSEMENT) Return TRendezVous objects filtered by the ID_ETABLISSEMENT column
 * @method array findByIdPrestation(int $ID_PRESTATION) Return TRendezVous objects filtered by the ID_PRESTATION column
 * @method array findByIdAgentRessource(int $ID_AGENT_RESSOURCE) Return TRendezVous objects filtered by the ID_AGENT_RESSOURCE column
 * @method array findByIdAgentTeleoperateur(int $ID_AGENT_TELEOPERATEUR) Return TRendezVous objects filtered by the ID_AGENT_TELEOPERATEUR column
 * @method array findByIdAgentConfirmation(int $ID_AGENT_CONFIRMATION) Return TRendezVous objects filtered by the ID_AGENT_CONFIRMATION column
 * @method array findByIdAgentAnnulation(int $ID_AGENT_ANNULATION) Return TRendezVous objects filtered by the ID_AGENT_ANNULATION column
 * @method array findByIdReferent(int $ID_REFERENT) Return TRendezVous objects filtered by the ID_REFERENT column
 * @method array findByTagGateway(string $TAG_GATEWAY) Return TRendezVous objects filtered by the TAG_GATEWAY column
 * @method array findByIdUtilisateur(string $ID_UTILISATEUR) Return TRendezVous objects filtered by the ID_UTILISATEUR column
 * @method array findByEtatAcquittement(int $ETAT_ACQUITTEMENT) Return TRendezVous objects filtered by the ETAT_ACQUITTEMENT column
 * @method array findByDateAcquittement(string $DATE_ACQUITTEMENT) Return TRendezVous objects filtered by the DATE_ACQUITTEMENT column
 * @method array findByChampSuppPresta(string $CHAMP_SUPP_PRESTA) Return TRendezVous objects filtered by the CHAMP_SUPP_PRESTA column
 * @method array findByIdChefRessource(int $ID_CHEF_RESSOURCE) Return TRendezVous objects filtered by the ID_CHEF_RESSOURCE column
 * @method array findByPartageRecap(string $PARTAGE_RECAP) Return TRendezVous objects filtered by the PARTAGE_RECAP column
 * @method array findByNatureSession(string $NATURE_SESSION) Return TRendezVous objects filtered by the NATURE_SESSION column
 * @method array findByLieuRdv(string $LIEU_RDV) Return TRendezVous objects filtered by the LIEU_RDV column
 * @method array findByLienRdv(string $LIEN_RDV) Return TRendezVous objects filtered by the LIEN_RDV column
 * @method array findByNombreParticipant(int $NOMBRE_PARTICIPANT) Return TRendezVous objects filtered by the NOMBRE_PARTICIPANT column
 * @method array findByCommentaire(string $COMMENTAIRE) Return TRendezVous objects filtered by the COMMENTAIRE column
 * @method array findByIdValeurReferentiel(int $ID_VALEUR_REFERENTIEL) Return TRendezVous objects filtered by the ID_VALEUR_REFERENTIEL column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTRendezVousQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTRendezVousQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TRendezVous', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TRendezVousQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TRendezVousQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TRendezVousQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TRendezVousQuery) {
            return $criteria;
        }
        $query = new TRendezVousQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TRendezVous|TRendezVous[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TRendezVousPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TRendezVous A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdRendezVous($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TRendezVous A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_RENDEZ_VOUS`, `DATE_CREATION`, `DATE_CONFIRMATION`, `DATE_ANNULATION`, `MOTIF_ANNULATION`, `DATE_RDV`, `DATE_FIN_RDV`, `CODE_RDV`, `ETAT_RDV`, `MODE_PRISE_RDV`, `TYPE_PRISE_RDV`, `ID_CITOYEN`, `ID_AGENT_ACCUEIL`, `ID_ETABLISSEMENT`, `ID_PRESTATION`, `ID_AGENT_RESSOURCE`, `ID_AGENT_TELEOPERATEUR`, `ID_AGENT_CONFIRMATION`, `ID_AGENT_ANNULATION`, `ID_REFERENT`, `TAG_GATEWAY`, `ID_UTILISATEUR`, `ETAT_ACQUITTEMENT`, `DATE_ACQUITTEMENT`, `CHAMP_SUPP_PRESTA`, `ID_CHEF_RESSOURCE`, `PARTAGE_RECAP`, `NATURE_SESSION`, `LIEU_RDV`, `LIEN_RDV`, `NOMBRE_PARTICIPANT`, `COMMENTAIRE`, `ID_VALEUR_REFERENTIEL` FROM `T_RENDEZ_VOUS` WHERE `ID_RENDEZ_VOUS` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TRendezVous();
            $obj->hydrate($row);
            TRendezVousPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TRendezVous|TRendezVous[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TRendezVous[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_RENDEZ_VOUS column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRendezVous(1234); // WHERE ID_RENDEZ_VOUS = 1234
     * $query->filterByIdRendezVous(array(12, 34)); // WHERE ID_RENDEZ_VOUS IN (12, 34)
     * $query->filterByIdRendezVous(array('min' => 12)); // WHERE ID_RENDEZ_VOUS >= 12
     * $query->filterByIdRendezVous(array('max' => 12)); // WHERE ID_RENDEZ_VOUS <= 12
     * </code>
     *
     * @param     mixed $idRendezVous The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdRendezVous($idRendezVous = null, $comparison = null)
    {
        if (is_array($idRendezVous)) {
            $useMinMax = false;
            if (isset($idRendezVous['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $idRendezVous['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRendezVous['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $idRendezVous['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $idRendezVous, $comparison);
    }

    /**
     * Filter the query on the DATE_CREATION column
     *
     * Example usage:
     * <code>
     * $query->filterByDateCreation('2011-03-14'); // WHERE DATE_CREATION = '2011-03-14'
     * $query->filterByDateCreation('now'); // WHERE DATE_CREATION = '2011-03-14'
     * $query->filterByDateCreation(array('max' => 'yesterday')); // WHERE DATE_CREATION > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateCreation The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByDateCreation($dateCreation = null, $comparison = null)
    {
        if (is_array($dateCreation)) {
            $useMinMax = false;
            if (isset($dateCreation['min'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_CREATION, $dateCreation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateCreation['max'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_CREATION, $dateCreation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::DATE_CREATION, $dateCreation, $comparison);
    }

    /**
     * Filter the query on the DATE_CONFIRMATION column
     *
     * Example usage:
     * <code>
     * $query->filterByDateConfirmation('2011-03-14'); // WHERE DATE_CONFIRMATION = '2011-03-14'
     * $query->filterByDateConfirmation('now'); // WHERE DATE_CONFIRMATION = '2011-03-14'
     * $query->filterByDateConfirmation(array('max' => 'yesterday')); // WHERE DATE_CONFIRMATION > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateConfirmation The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByDateConfirmation($dateConfirmation = null, $comparison = null)
    {
        if (is_array($dateConfirmation)) {
            $useMinMax = false;
            if (isset($dateConfirmation['min'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_CONFIRMATION, $dateConfirmation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateConfirmation['max'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_CONFIRMATION, $dateConfirmation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::DATE_CONFIRMATION, $dateConfirmation, $comparison);
    }

    /**
     * Filter the query on the DATE_ANNULATION column
     *
     * Example usage:
     * <code>
     * $query->filterByDateAnnulation('2011-03-14'); // WHERE DATE_ANNULATION = '2011-03-14'
     * $query->filterByDateAnnulation('now'); // WHERE DATE_ANNULATION = '2011-03-14'
     * $query->filterByDateAnnulation(array('max' => 'yesterday')); // WHERE DATE_ANNULATION > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateAnnulation The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByDateAnnulation($dateAnnulation = null, $comparison = null)
    {
        if (is_array($dateAnnulation)) {
            $useMinMax = false;
            if (isset($dateAnnulation['min'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_ANNULATION, $dateAnnulation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateAnnulation['max'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_ANNULATION, $dateAnnulation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::DATE_ANNULATION, $dateAnnulation, $comparison);
    }

    /**
     * Filter the query on the MOTIF_ANNULATION column
     *
     * Example usage:
     * <code>
     * $query->filterByMotifAnnulation('fooValue');   // WHERE MOTIF_ANNULATION = 'fooValue'
     * $query->filterByMotifAnnulation('%fooValue%'); // WHERE MOTIF_ANNULATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $motifAnnulation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByMotifAnnulation($motifAnnulation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($motifAnnulation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $motifAnnulation)) {
                $motifAnnulation = str_replace('*', '%', $motifAnnulation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::MOTIF_ANNULATION, $motifAnnulation, $comparison);
    }

    /**
     * Filter the query on the DATE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByDateRdv('2011-03-14'); // WHERE DATE_RDV = '2011-03-14'
     * $query->filterByDateRdv('now'); // WHERE DATE_RDV = '2011-03-14'
     * $query->filterByDateRdv(array('max' => 'yesterday')); // WHERE DATE_RDV > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateRdv The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByDateRdv($dateRdv = null, $comparison = null)
    {
        if (is_array($dateRdv)) {
            $useMinMax = false;
            if (isset($dateRdv['min'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_RDV, $dateRdv['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateRdv['max'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_RDV, $dateRdv['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::DATE_RDV, $dateRdv, $comparison);
    }

    /**
     * Filter the query on the DATE_FIN_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByDateFinRdv('2011-03-14'); // WHERE DATE_FIN_RDV = '2011-03-14'
     * $query->filterByDateFinRdv('now'); // WHERE DATE_FIN_RDV = '2011-03-14'
     * $query->filterByDateFinRdv(array('max' => 'yesterday')); // WHERE DATE_FIN_RDV > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateFinRdv The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByDateFinRdv($dateFinRdv = null, $comparison = null)
    {
        if (is_array($dateFinRdv)) {
            $useMinMax = false;
            if (isset($dateFinRdv['min'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_FIN_RDV, $dateFinRdv['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateFinRdv['max'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_FIN_RDV, $dateFinRdv['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::DATE_FIN_RDV, $dateFinRdv, $comparison);
    }

    /**
     * Filter the query on the CODE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeRdv('fooValue');   // WHERE CODE_RDV = 'fooValue'
     * $query->filterByCodeRdv('%fooValue%'); // WHERE CODE_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $codeRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByCodeRdv($codeRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($codeRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $codeRdv)) {
                $codeRdv = str_replace('*', '%', $codeRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::CODE_RDV, $codeRdv, $comparison);
    }

    /**
     * Filter the query on the ETAT_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByEtatRdv('fooValue');   // WHERE ETAT_RDV = 'fooValue'
     * $query->filterByEtatRdv('%fooValue%'); // WHERE ETAT_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $etatRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByEtatRdv($etatRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($etatRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $etatRdv)) {
                $etatRdv = str_replace('*', '%', $etatRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ETAT_RDV, $etatRdv, $comparison);
    }

    /**
     * Filter the query on the MODE_PRISE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByModePriseRdv('fooValue');   // WHERE MODE_PRISE_RDV = 'fooValue'
     * $query->filterByModePriseRdv('%fooValue%'); // WHERE MODE_PRISE_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modePriseRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByModePriseRdv($modePriseRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modePriseRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modePriseRdv)) {
                $modePriseRdv = str_replace('*', '%', $modePriseRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::MODE_PRISE_RDV, $modePriseRdv, $comparison);
    }

    /**
     * Filter the query on the TYPE_PRISE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByTypePriseRdv('fooValue');   // WHERE TYPE_PRISE_RDV = 'fooValue'
     * $query->filterByTypePriseRdv('%fooValue%'); // WHERE TYPE_PRISE_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $typePriseRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByTypePriseRdv($typePriseRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($typePriseRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $typePriseRdv)) {
                $typePriseRdv = str_replace('*', '%', $typePriseRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::TYPE_PRISE_RDV, $typePriseRdv, $comparison);
    }

    /**
     * Filter the query on the ID_CITOYEN column
     *
     * Example usage:
     * <code>
     * $query->filterByIdCitoyen(1234); // WHERE ID_CITOYEN = 1234
     * $query->filterByIdCitoyen(array(12, 34)); // WHERE ID_CITOYEN IN (12, 34)
     * $query->filterByIdCitoyen(array('min' => 12)); // WHERE ID_CITOYEN >= 12
     * $query->filterByIdCitoyen(array('max' => 12)); // WHERE ID_CITOYEN <= 12
     * </code>
     *
     * @see       filterByTCitoyen()
     *
     * @param     mixed $idCitoyen The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdCitoyen($idCitoyen = null, $comparison = null)
    {
        if (is_array($idCitoyen)) {
            $useMinMax = false;
            if (isset($idCitoyen['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_CITOYEN, $idCitoyen['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idCitoyen['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_CITOYEN, $idCitoyen['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_CITOYEN, $idCitoyen, $comparison);
    }

    /**
     * Filter the query on the ID_AGENT_ACCUEIL column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgentAccueil(1234); // WHERE ID_AGENT_ACCUEIL = 1234
     * $query->filterByIdAgentAccueil(array(12, 34)); // WHERE ID_AGENT_ACCUEIL IN (12, 34)
     * $query->filterByIdAgentAccueil(array('min' => 12)); // WHERE ID_AGENT_ACCUEIL >= 12
     * $query->filterByIdAgentAccueil(array('max' => 12)); // WHERE ID_AGENT_ACCUEIL <= 12
     * </code>
     *
     * @see       filterByTAgentRelatedByIdAgentAccueil()
     *
     * @param     mixed $idAgentAccueil The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdAgentAccueil($idAgentAccueil = null, $comparison = null)
    {
        if (is_array($idAgentAccueil)) {
            $useMinMax = false;
            if (isset($idAgentAccueil['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_ACCUEIL, $idAgentAccueil['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgentAccueil['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_ACCUEIL, $idAgentAccueil['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_AGENT_ACCUEIL, $idAgentAccueil, $comparison);
    }

    /**
     * Filter the query on the ID_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEtablissement(1234); // WHERE ID_ETABLISSEMENT = 1234
     * $query->filterByIdEtablissement(array(12, 34)); // WHERE ID_ETABLISSEMENT IN (12, 34)
     * $query->filterByIdEtablissement(array('min' => 12)); // WHERE ID_ETABLISSEMENT >= 12
     * $query->filterByIdEtablissement(array('max' => 12)); // WHERE ID_ETABLISSEMENT <= 12
     * </code>
     *
     * @see       filterByTEtablissement()
     *
     * @param     mixed $idEtablissement The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdEtablissement($idEtablissement = null, $comparison = null)
    {
        if (is_array($idEtablissement)) {
            $useMinMax = false;
            if (isset($idEtablissement['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_ETABLISSEMENT, $idEtablissement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEtablissement['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_ETABLISSEMENT, $idEtablissement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_ETABLISSEMENT, $idEtablissement, $comparison);
    }

    /**
     * Filter the query on the ID_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPrestation(1234); // WHERE ID_PRESTATION = 1234
     * $query->filterByIdPrestation(array(12, 34)); // WHERE ID_PRESTATION IN (12, 34)
     * $query->filterByIdPrestation(array('min' => 12)); // WHERE ID_PRESTATION >= 12
     * $query->filterByIdPrestation(array('max' => 12)); // WHERE ID_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTPrestation()
     *
     * @param     mixed $idPrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdPrestation($idPrestation = null, $comparison = null)
    {
        if (is_array($idPrestation)) {
            $useMinMax = false;
            if (isset($idPrestation['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_PRESTATION, $idPrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPrestation['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_PRESTATION, $idPrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_PRESTATION, $idPrestation, $comparison);
    }

    /**
     * Filter the query on the ID_AGENT_RESSOURCE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgentRessource(1234); // WHERE ID_AGENT_RESSOURCE = 1234
     * $query->filterByIdAgentRessource(array(12, 34)); // WHERE ID_AGENT_RESSOURCE IN (12, 34)
     * $query->filterByIdAgentRessource(array('min' => 12)); // WHERE ID_AGENT_RESSOURCE >= 12
     * $query->filterByIdAgentRessource(array('max' => 12)); // WHERE ID_AGENT_RESSOURCE <= 12
     * </code>
     *
     * @see       filterByTAgentRelatedByIdAgentRessource()
     *
     * @param     mixed $idAgentRessource The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdAgentRessource($idAgentRessource = null, $comparison = null)
    {
        if (is_array($idAgentRessource)) {
            $useMinMax = false;
            if (isset($idAgentRessource['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_RESSOURCE, $idAgentRessource['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgentRessource['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_RESSOURCE, $idAgentRessource['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_AGENT_RESSOURCE, $idAgentRessource, $comparison);
    }

    /**
     * Filter the query on the ID_AGENT_TELEOPERATEUR column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgentTeleoperateur(1234); // WHERE ID_AGENT_TELEOPERATEUR = 1234
     * $query->filterByIdAgentTeleoperateur(array(12, 34)); // WHERE ID_AGENT_TELEOPERATEUR IN (12, 34)
     * $query->filterByIdAgentTeleoperateur(array('min' => 12)); // WHERE ID_AGENT_TELEOPERATEUR >= 12
     * $query->filterByIdAgentTeleoperateur(array('max' => 12)); // WHERE ID_AGENT_TELEOPERATEUR <= 12
     * </code>
     *
     * @see       filterByTAgentRelatedByIdAgentTeleoperateur()
     *
     * @param     mixed $idAgentTeleoperateur The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdAgentTeleoperateur($idAgentTeleoperateur = null, $comparison = null)
    {
        if (is_array($idAgentTeleoperateur)) {
            $useMinMax = false;
            if (isset($idAgentTeleoperateur['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, $idAgentTeleoperateur['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgentTeleoperateur['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, $idAgentTeleoperateur['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, $idAgentTeleoperateur, $comparison);
    }

    /**
     * Filter the query on the ID_AGENT_CONFIRMATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgentConfirmation(1234); // WHERE ID_AGENT_CONFIRMATION = 1234
     * $query->filterByIdAgentConfirmation(array(12, 34)); // WHERE ID_AGENT_CONFIRMATION IN (12, 34)
     * $query->filterByIdAgentConfirmation(array('min' => 12)); // WHERE ID_AGENT_CONFIRMATION >= 12
     * $query->filterByIdAgentConfirmation(array('max' => 12)); // WHERE ID_AGENT_CONFIRMATION <= 12
     * </code>
     *
     * @see       filterByTAgentRelatedByIdAgentConfirmation()
     *
     * @param     mixed $idAgentConfirmation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdAgentConfirmation($idAgentConfirmation = null, $comparison = null)
    {
        if (is_array($idAgentConfirmation)) {
            $useMinMax = false;
            if (isset($idAgentConfirmation['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_CONFIRMATION, $idAgentConfirmation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgentConfirmation['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_CONFIRMATION, $idAgentConfirmation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_AGENT_CONFIRMATION, $idAgentConfirmation, $comparison);
    }

    /**
     * Filter the query on the ID_AGENT_ANNULATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgentAnnulation(1234); // WHERE ID_AGENT_ANNULATION = 1234
     * $query->filterByIdAgentAnnulation(array(12, 34)); // WHERE ID_AGENT_ANNULATION IN (12, 34)
     * $query->filterByIdAgentAnnulation(array('min' => 12)); // WHERE ID_AGENT_ANNULATION >= 12
     * $query->filterByIdAgentAnnulation(array('max' => 12)); // WHERE ID_AGENT_ANNULATION <= 12
     * </code>
     *
     * @see       filterByTAgentRelatedByIdAgentAnnulation()
     *
     * @param     mixed $idAgentAnnulation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdAgentAnnulation($idAgentAnnulation = null, $comparison = null)
    {
        if (is_array($idAgentAnnulation)) {
            $useMinMax = false;
            if (isset($idAgentAnnulation['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_ANNULATION, $idAgentAnnulation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgentAnnulation['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_AGENT_ANNULATION, $idAgentAnnulation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_AGENT_ANNULATION, $idAgentAnnulation, $comparison);
    }

    /**
     * Filter the query on the ID_REFERENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdReferent(1234); // WHERE ID_REFERENT = 1234
     * $query->filterByIdReferent(array(12, 34)); // WHERE ID_REFERENT IN (12, 34)
     * $query->filterByIdReferent(array('min' => 12)); // WHERE ID_REFERENT >= 12
     * $query->filterByIdReferent(array('max' => 12)); // WHERE ID_REFERENT <= 12
     * </code>
     *
     * @see       filterByTReferent()
     *
     * @param     mixed $idReferent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdReferent($idReferent = null, $comparison = null)
    {
        if (is_array($idReferent)) {
            $useMinMax = false;
            if (isset($idReferent['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_REFERENT, $idReferent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idReferent['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_REFERENT, $idReferent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_REFERENT, $idReferent, $comparison);
    }

    /**
     * Filter the query on the TAG_GATEWAY column
     *
     * Example usage:
     * <code>
     * $query->filterByTagGateway('fooValue');   // WHERE TAG_GATEWAY = 'fooValue'
     * $query->filterByTagGateway('%fooValue%'); // WHERE TAG_GATEWAY LIKE '%fooValue%'
     * </code>
     *
     * @param     string $tagGateway The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByTagGateway($tagGateway = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($tagGateway)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $tagGateway)) {
                $tagGateway = str_replace('*', '%', $tagGateway);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::TAG_GATEWAY, $tagGateway, $comparison);
    }

    /**
     * Filter the query on the ID_UTILISATEUR column
     *
     * Example usage:
     * <code>
     * $query->filterByIdUtilisateur('fooValue');   // WHERE ID_UTILISATEUR = 'fooValue'
     * $query->filterByIdUtilisateur('%fooValue%'); // WHERE ID_UTILISATEUR LIKE '%fooValue%'
     * </code>
     *
     * @param     string $idUtilisateur The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdUtilisateur($idUtilisateur = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($idUtilisateur)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $idUtilisateur)) {
                $idUtilisateur = str_replace('*', '%', $idUtilisateur);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_UTILISATEUR, $idUtilisateur, $comparison);
    }

    /**
     * Filter the query on the ETAT_ACQUITTEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByEtatAcquittement(1234); // WHERE ETAT_ACQUITTEMENT = 1234
     * $query->filterByEtatAcquittement(array(12, 34)); // WHERE ETAT_ACQUITTEMENT IN (12, 34)
     * $query->filterByEtatAcquittement(array('min' => 12)); // WHERE ETAT_ACQUITTEMENT >= 12
     * $query->filterByEtatAcquittement(array('max' => 12)); // WHERE ETAT_ACQUITTEMENT <= 12
     * </code>
     *
     * @param     mixed $etatAcquittement The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByEtatAcquittement($etatAcquittement = null, $comparison = null)
    {
        if (is_array($etatAcquittement)) {
            $useMinMax = false;
            if (isset($etatAcquittement['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ETAT_ACQUITTEMENT, $etatAcquittement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($etatAcquittement['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ETAT_ACQUITTEMENT, $etatAcquittement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ETAT_ACQUITTEMENT, $etatAcquittement, $comparison);
    }

    /**
     * Filter the query on the DATE_ACQUITTEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByDateAcquittement('2011-03-14'); // WHERE DATE_ACQUITTEMENT = '2011-03-14'
     * $query->filterByDateAcquittement('now'); // WHERE DATE_ACQUITTEMENT = '2011-03-14'
     * $query->filterByDateAcquittement(array('max' => 'yesterday')); // WHERE DATE_ACQUITTEMENT > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateAcquittement The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByDateAcquittement($dateAcquittement = null, $comparison = null)
    {
        if (is_array($dateAcquittement)) {
            $useMinMax = false;
            if (isset($dateAcquittement['min'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_ACQUITTEMENT, $dateAcquittement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateAcquittement['max'])) {
                $this->addUsingAlias(TRendezVousPeer::DATE_ACQUITTEMENT, $dateAcquittement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::DATE_ACQUITTEMENT, $dateAcquittement, $comparison);
    }

    /**
     * Filter the query on the CHAMP_SUPP_PRESTA column
     *
     * Example usage:
     * <code>
     * $query->filterByChampSuppPresta('fooValue');   // WHERE CHAMP_SUPP_PRESTA = 'fooValue'
     * $query->filterByChampSuppPresta('%fooValue%'); // WHERE CHAMP_SUPP_PRESTA LIKE '%fooValue%'
     * </code>
     *
     * @param     string $champSuppPresta The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByChampSuppPresta($champSuppPresta = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($champSuppPresta)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $champSuppPresta)) {
                $champSuppPresta = str_replace('*', '%', $champSuppPresta);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::CHAMP_SUPP_PRESTA, $champSuppPresta, $comparison);
    }

    /**
     * Filter the query on the ID_CHEF_RESSOURCE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdChefRessource(1234); // WHERE ID_CHEF_RESSOURCE = 1234
     * $query->filterByIdChefRessource(array(12, 34)); // WHERE ID_CHEF_RESSOURCE IN (12, 34)
     * $query->filterByIdChefRessource(array('min' => 12)); // WHERE ID_CHEF_RESSOURCE >= 12
     * $query->filterByIdChefRessource(array('max' => 12)); // WHERE ID_CHEF_RESSOURCE <= 12
     * </code>
     *
     * @param     mixed $idChefRessource The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdChefRessource($idChefRessource = null, $comparison = null)
    {
        if (is_array($idChefRessource)) {
            $useMinMax = false;
            if (isset($idChefRessource['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_CHEF_RESSOURCE, $idChefRessource['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idChefRessource['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_CHEF_RESSOURCE, $idChefRessource['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_CHEF_RESSOURCE, $idChefRessource, $comparison);
    }

    /**
     * Filter the query on the PARTAGE_RECAP column
     *
     * Example usage:
     * <code>
     * $query->filterByPartageRecap('fooValue');   // WHERE PARTAGE_RECAP = 'fooValue'
     * $query->filterByPartageRecap('%fooValue%'); // WHERE PARTAGE_RECAP LIKE '%fooValue%'
     * </code>
     *
     * @param     string $partageRecap The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByPartageRecap($partageRecap = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($partageRecap)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $partageRecap)) {
                $partageRecap = str_replace('*', '%', $partageRecap);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::PARTAGE_RECAP, $partageRecap, $comparison);
    }

    /**
     * Filter the query on the NATURE_SESSION column
     *
     * Example usage:
     * <code>
     * $query->filterByNatureSession('fooValue');   // WHERE NATURE_SESSION = 'fooValue'
     * $query->filterByNatureSession('%fooValue%'); // WHERE NATURE_SESSION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $natureSession The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByNatureSession($natureSession = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($natureSession)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $natureSession)) {
                $natureSession = str_replace('*', '%', $natureSession);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::NATURE_SESSION, $natureSession, $comparison);
    }

    /**
     * Filter the query on the LIEU_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByLieuRdv('fooValue');   // WHERE LIEU_RDV = 'fooValue'
     * $query->filterByLieuRdv('%fooValue%'); // WHERE LIEU_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $lieuRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByLieuRdv($lieuRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($lieuRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $lieuRdv)) {
                $lieuRdv = str_replace('*', '%', $lieuRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::LIEU_RDV, $lieuRdv, $comparison);
    }

    /**
     * Filter the query on the LIEN_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByLienRdv('fooValue');   // WHERE LIEN_RDV = 'fooValue'
     * $query->filterByLienRdv('%fooValue%'); // WHERE LIEN_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $lienRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByLienRdv($lienRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($lienRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $lienRdv)) {
                $lienRdv = str_replace('*', '%', $lienRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::LIEN_RDV, $lienRdv, $comparison);
    }

    /**
     * Filter the query on the NOMBRE_PARTICIPANT column
     *
     * Example usage:
     * <code>
     * $query->filterByNombreParticipant(1234); // WHERE NOMBRE_PARTICIPANT = 1234
     * $query->filterByNombreParticipant(array(12, 34)); // WHERE NOMBRE_PARTICIPANT IN (12, 34)
     * $query->filterByNombreParticipant(array('min' => 12)); // WHERE NOMBRE_PARTICIPANT >= 12
     * $query->filterByNombreParticipant(array('max' => 12)); // WHERE NOMBRE_PARTICIPANT <= 12
     * </code>
     *
     * @param     mixed $nombreParticipant The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByNombreParticipant($nombreParticipant = null, $comparison = null)
    {
        if (is_array($nombreParticipant)) {
            $useMinMax = false;
            if (isset($nombreParticipant['min'])) {
                $this->addUsingAlias(TRendezVousPeer::NOMBRE_PARTICIPANT, $nombreParticipant['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($nombreParticipant['max'])) {
                $this->addUsingAlias(TRendezVousPeer::NOMBRE_PARTICIPANT, $nombreParticipant['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::NOMBRE_PARTICIPANT, $nombreParticipant, $comparison);
    }

    /**
     * Filter the query on the COMMENTAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByCommentaire('fooValue');   // WHERE COMMENTAIRE = 'fooValue'
     * $query->filterByCommentaire('%fooValue%'); // WHERE COMMENTAIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $commentaire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByCommentaire($commentaire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($commentaire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $commentaire)) {
                $commentaire = str_replace('*', '%', $commentaire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::COMMENTAIRE, $commentaire, $comparison);
    }

    /**
     * Filter the query on the ID_VALEUR_REFERENTIEL column
     *
     * Example usage:
     * <code>
     * $query->filterByIdValeurReferentiel(1234); // WHERE ID_VALEUR_REFERENTIEL = 1234
     * $query->filterByIdValeurReferentiel(array(12, 34)); // WHERE ID_VALEUR_REFERENTIEL IN (12, 34)
     * $query->filterByIdValeurReferentiel(array('min' => 12)); // WHERE ID_VALEUR_REFERENTIEL >= 12
     * $query->filterByIdValeurReferentiel(array('max' => 12)); // WHERE ID_VALEUR_REFERENTIEL <= 12
     * </code>
     *
     * @see       filterByTValeurReferentiel()
     *
     * @param     mixed $idValeurReferentiel The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function filterByIdValeurReferentiel($idValeurReferentiel = null, $comparison = null)
    {
        if (is_array($idValeurReferentiel)) {
            $useMinMax = false;
            if (isset($idValeurReferentiel['min'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_VALEUR_REFERENTIEL, $idValeurReferentiel['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idValeurReferentiel['max'])) {
                $this->addUsingAlias(TRendezVousPeer::ID_VALEUR_REFERENTIEL, $idValeurReferentiel['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRendezVousPeer::ID_VALEUR_REFERENTIEL, $idValeurReferentiel, $comparison);
    }

    /**
     * Filter the query by a related TCitoyen object
     *
     * @param   TCitoyen|PropelObjectCollection $tCitoyen The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTCitoyen($tCitoyen, $comparison = null)
    {
        if ($tCitoyen instanceof TCitoyen) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_CITOYEN, $tCitoyen->getIdCitoyen(), $comparison);
        } elseif ($tCitoyen instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_CITOYEN, $tCitoyen->toKeyValue('PrimaryKey', 'IdCitoyen'), $comparison);
        } else {
            throw new PropelException('filterByTCitoyen() only accepts arguments of type TCitoyen or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TCitoyen relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTCitoyen($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TCitoyen');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TCitoyen');
        }

        return $this;
    }

    /**
     * Use the TCitoyen relation TCitoyen object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TCitoyenQuery A secondary query class using the current class as primary query
     */
    public function useTCitoyenQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTCitoyen($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TCitoyen', 'TCitoyenQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdAgentAccueil($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_ACCUEIL, $tAgent->getIdAgent(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_ACCUEIL, $tAgent->toKeyValue('PrimaryKey', 'IdAgent'), $comparison);
        } else {
            throw new PropelException('filterByTAgentRelatedByIdAgentAccueil() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdAgentAccueil relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdAgentAccueil($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdAgentAccueil');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdAgentAccueil');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdAgentAccueil relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdAgentAccueilQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdAgentAccueil($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdAgentAccueil', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdAgentAnnulation($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_ANNULATION, $tAgent->getIdAgent(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_ANNULATION, $tAgent->toKeyValue('PrimaryKey', 'IdAgent'), $comparison);
        } else {
            throw new PropelException('filterByTAgentRelatedByIdAgentAnnulation() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdAgentAnnulation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdAgentAnnulation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdAgentAnnulation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdAgentAnnulation');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdAgentAnnulation relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdAgentAnnulationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdAgentAnnulation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdAgentAnnulation', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdAgentConfirmation($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_CONFIRMATION, $tAgent->getIdAgent(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_CONFIRMATION, $tAgent->toKeyValue('PrimaryKey', 'IdAgent'), $comparison);
        } else {
            throw new PropelException('filterByTAgentRelatedByIdAgentConfirmation() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdAgentConfirmation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdAgentConfirmation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdAgentConfirmation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdAgentConfirmation');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdAgentConfirmation relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdAgentConfirmationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdAgentConfirmation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdAgentConfirmation', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdAgentRessource($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_RESSOURCE, $tAgent->getIdAgent(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_RESSOURCE, $tAgent->toKeyValue('PrimaryKey', 'IdAgent'), $comparison);
        } else {
            throw new PropelException('filterByTAgentRelatedByIdAgentRessource() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdAgentRessource relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdAgentRessource($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdAgentRessource');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdAgentRessource');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdAgentRessource relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdAgentRessourceQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdAgentRessource($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdAgentRessource', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdAgentTeleoperateur($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, $tAgent->getIdAgent(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, $tAgent->toKeyValue('PrimaryKey', 'IdAgent'), $comparison);
        } else {
            throw new PropelException('filterByTAgentRelatedByIdAgentTeleoperateur() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdAgentTeleoperateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdAgentTeleoperateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdAgentTeleoperateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdAgentTeleoperateur');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdAgentTeleoperateur relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdAgentTeleoperateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdAgentTeleoperateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdAgentTeleoperateur', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TValeurReferentiel object
     *
     * @param   TValeurReferentiel|PropelObjectCollection $tValeurReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTValeurReferentiel($tValeurReferentiel, $comparison = null)
    {
        if ($tValeurReferentiel instanceof TValeurReferentiel) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_VALEUR_REFERENTIEL, $tValeurReferentiel->getIdValeurReferentiel(), $comparison);
        } elseif ($tValeurReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_VALEUR_REFERENTIEL, $tValeurReferentiel->toKeyValue('PrimaryKey', 'IdValeurReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTValeurReferentiel() only accepts arguments of type TValeurReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TValeurReferentiel relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTValeurReferentiel($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TValeurReferentiel');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TValeurReferentiel');
        }

        return $this;
    }

    /**
     * Use the TValeurReferentiel relation TValeurReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TValeurReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTValeurReferentielQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTValeurReferentiel($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TValeurReferentiel', 'TValeurReferentielQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissement($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_ETABLISSEMENT, $tEtablissement->getIdEtablissement(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_ETABLISSEMENT, $tEtablissement->toKeyValue('PrimaryKey', 'IdEtablissement'), $comparison);
        } else {
            throw new PropelException('filterByTEtablissement() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTEtablissement($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissement');
        }

        return $this;
    }

    /**
     * Use the TEtablissement relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissement', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_PRESTATION, $tPrestation->getIdPrestation(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_PRESTATION, $tPrestation->toKeyValue('PrimaryKey', 'IdPrestation'), $comparison);
        } else {
            throw new PropelException('filterByTPrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTPrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestation', 'TPrestationQuery');
    }

    /**
     * Filter the query by a related TReferent object
     *
     * @param   TReferent|PropelObjectCollection $tReferent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferent($tReferent, $comparison = null)
    {
        if ($tReferent instanceof TReferent) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_REFERENT, $tReferent->getIdReferent(), $comparison);
        } elseif ($tReferent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRendezVousPeer::ID_REFERENT, $tReferent->toKeyValue('PrimaryKey', 'IdReferent'), $comparison);
        } else {
            throw new PropelException('filterByTReferent() only accepts arguments of type TReferent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTReferent($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferent');
        }

        return $this;
    }

    /**
     * Use the TReferent relation TReferent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentQuery A secondary query class using the current class as primary query
     */
    public function useTReferentQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTReferent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferent', 'TReferentQuery');
    }

    /**
     * Filter the query by a related TBlobRdv object
     *
     * @param   TBlobRdv|PropelObjectCollection $tBlobRdv  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTBlobRdv($tBlobRdv, $comparison = null)
    {
        if ($tBlobRdv instanceof TBlobRdv) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $tBlobRdv->getIdRendezVous(), $comparison);
        } elseif ($tBlobRdv instanceof PropelObjectCollection) {
            return $this
                ->useTBlobRdvQuery()
                ->filterByPrimaryKeys($tBlobRdv->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTBlobRdv() only accepts arguments of type TBlobRdv or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TBlobRdv relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTBlobRdv($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TBlobRdv');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TBlobRdv');
        }

        return $this;
    }

    /**
     * Use the TBlobRdv relation TBlobRdv object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TBlobRdvQuery A secondary query class using the current class as primary query
     */
    public function useTBlobRdvQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTBlobRdv($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TBlobRdv', 'TBlobRdvQuery');
    }

    /**
     * Filter the query by a related TParticipant object
     *
     * @param   TParticipant|PropelObjectCollection $tParticipant  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRendezVousQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParticipant($tParticipant, $comparison = null)
    {
        if ($tParticipant instanceof TParticipant) {
            return $this
                ->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $tParticipant->getIdRendezVous(), $comparison);
        } elseif ($tParticipant instanceof PropelObjectCollection) {
            return $this
                ->useTParticipantQuery()
                ->filterByPrimaryKeys($tParticipant->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParticipant() only accepts arguments of type TParticipant or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParticipant relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function joinTParticipant($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParticipant');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParticipant');
        }

        return $this;
    }

    /**
     * Use the TParticipant relation TParticipant object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParticipantQuery A secondary query class using the current class as primary query
     */
    public function useTParticipantQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTParticipant($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParticipant', 'TParticipantQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TRendezVous $tRendezVous Object to remove from the list of results
     *
     * @return TRendezVousQuery The current query, for fluid interface
     */
    public function prune($tRendezVous = null)
    {
        if ($tRendezVous) {
            $this->addUsingAlias(TRendezVousPeer::ID_RENDEZ_VOUS, $tRendezVous->getIdRendezVous(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
