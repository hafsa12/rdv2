<?php


/**
 * Base static class for performing query and update operations on the 'T_RENDEZ_VOUS' table.
 *
 *
 *
 * @package propel.generator.RDV.om
 */
abstract class BaseTRendezVousPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'RDV';

    /** the table name for this class */
    const TABLE_NAME = 'T_RENDEZ_VOUS';

    /** the related Propel class for this table */
    const OM_CLASS = 'TRendezVous';

    /** the related TableMap class for this table */
    const TM_CLASS = 'TRendezVousTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 33;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 33;

    /** the column name for the ID_RENDEZ_VOUS field */
    const ID_RENDEZ_VOUS = 'T_RENDEZ_VOUS.ID_RENDEZ_VOUS';

    /** the column name for the DATE_CREATION field */
    const DATE_CREATION = 'T_RENDEZ_VOUS.DATE_CREATION';

    /** the column name for the DATE_CONFIRMATION field */
    const DATE_CONFIRMATION = 'T_RENDEZ_VOUS.DATE_CONFIRMATION';

    /** the column name for the DATE_ANNULATION field */
    const DATE_ANNULATION = 'T_RENDEZ_VOUS.DATE_ANNULATION';

    /** the column name for the MOTIF_ANNULATION field */
    const MOTIF_ANNULATION = 'T_RENDEZ_VOUS.MOTIF_ANNULATION';

    /** the column name for the DATE_RDV field */
    const DATE_RDV = 'T_RENDEZ_VOUS.DATE_RDV';

    /** the column name for the DATE_FIN_RDV field */
    const DATE_FIN_RDV = 'T_RENDEZ_VOUS.DATE_FIN_RDV';

    /** the column name for the CODE_RDV field */
    const CODE_RDV = 'T_RENDEZ_VOUS.CODE_RDV';

    /** the column name for the ETAT_RDV field */
    const ETAT_RDV = 'T_RENDEZ_VOUS.ETAT_RDV';

    /** the column name for the MODE_PRISE_RDV field */
    const MODE_PRISE_RDV = 'T_RENDEZ_VOUS.MODE_PRISE_RDV';

    /** the column name for the TYPE_PRISE_RDV field */
    const TYPE_PRISE_RDV = 'T_RENDEZ_VOUS.TYPE_PRISE_RDV';

    /** the column name for the ID_CITOYEN field */
    const ID_CITOYEN = 'T_RENDEZ_VOUS.ID_CITOYEN';

    /** the column name for the ID_AGENT_ACCUEIL field */
    const ID_AGENT_ACCUEIL = 'T_RENDEZ_VOUS.ID_AGENT_ACCUEIL';

    /** the column name for the ID_ETABLISSEMENT field */
    const ID_ETABLISSEMENT = 'T_RENDEZ_VOUS.ID_ETABLISSEMENT';

    /** the column name for the ID_PRESTATION field */
    const ID_PRESTATION = 'T_RENDEZ_VOUS.ID_PRESTATION';

    /** the column name for the ID_AGENT_RESSOURCE field */
    const ID_AGENT_RESSOURCE = 'T_RENDEZ_VOUS.ID_AGENT_RESSOURCE';

    /** the column name for the ID_AGENT_TELEOPERATEUR field */
    const ID_AGENT_TELEOPERATEUR = 'T_RENDEZ_VOUS.ID_AGENT_TELEOPERATEUR';

    /** the column name for the ID_AGENT_CONFIRMATION field */
    const ID_AGENT_CONFIRMATION = 'T_RENDEZ_VOUS.ID_AGENT_CONFIRMATION';

    /** the column name for the ID_AGENT_ANNULATION field */
    const ID_AGENT_ANNULATION = 'T_RENDEZ_VOUS.ID_AGENT_ANNULATION';

    /** the column name for the ID_REFERENT field */
    const ID_REFERENT = 'T_RENDEZ_VOUS.ID_REFERENT';

    /** the column name for the TAG_GATEWAY field */
    const TAG_GATEWAY = 'T_RENDEZ_VOUS.TAG_GATEWAY';

    /** the column name for the ID_UTILISATEUR field */
    const ID_UTILISATEUR = 'T_RENDEZ_VOUS.ID_UTILISATEUR';

    /** the column name for the ETAT_ACQUITTEMENT field */
    const ETAT_ACQUITTEMENT = 'T_RENDEZ_VOUS.ETAT_ACQUITTEMENT';

    /** the column name for the DATE_ACQUITTEMENT field */
    const DATE_ACQUITTEMENT = 'T_RENDEZ_VOUS.DATE_ACQUITTEMENT';

    /** the column name for the CHAMP_SUPP_PRESTA field */
    const CHAMP_SUPP_PRESTA = 'T_RENDEZ_VOUS.CHAMP_SUPP_PRESTA';

    /** the column name for the ID_CHEF_RESSOURCE field */
    const ID_CHEF_RESSOURCE = 'T_RENDEZ_VOUS.ID_CHEF_RESSOURCE';

    /** the column name for the PARTAGE_RECAP field */
    const PARTAGE_RECAP = 'T_RENDEZ_VOUS.PARTAGE_RECAP';

    /** the column name for the NATURE_SESSION field */
    const NATURE_SESSION = 'T_RENDEZ_VOUS.NATURE_SESSION';

    /** the column name for the LIEU_RDV field */
    const LIEU_RDV = 'T_RENDEZ_VOUS.LIEU_RDV';

    /** the column name for the LIEN_RDV field */
    const LIEN_RDV = 'T_RENDEZ_VOUS.LIEN_RDV';

    /** the column name for the NOMBRE_PARTICIPANT field */
    const NOMBRE_PARTICIPANT = 'T_RENDEZ_VOUS.NOMBRE_PARTICIPANT';

    /** the column name for the COMMENTAIRE field */
    const COMMENTAIRE = 'T_RENDEZ_VOUS.COMMENTAIRE';

    /** the column name for the ID_VALEUR_REFERENTIEL field */
    const ID_VALEUR_REFERENTIEL = 'T_RENDEZ_VOUS.ID_VALEUR_REFERENTIEL';

    /** The enumerated values for the ETAT_RDV field */
    const ETAT_RDV_0 = '0';
    const ETAT_RDV_1 = '1';
    const ETAT_RDV_2 = '2';
    const ETAT_RDV_3 = '3';
    const ETAT_RDV_4 = '4';
    const ETAT_RDV_5 = '5';

    /** The enumerated values for the MODE_PRISE_RDV field */
    const MODE_PRISE_RDV_0 = '0';
    const MODE_PRISE_RDV_1 = '1';
    const MODE_PRISE_RDV_2 = '2';
    const MODE_PRISE_RDV_3 = '3';

    /** The enumerated values for the TYPE_PRISE_RDV field */
    const TYPE_PRISE_RDV_0 = '0';
    const TYPE_PRISE_RDV_1 = '1';
    const TYPE_PRISE_RDV_2 = '2';
    const TYPE_PRISE_RDV_3 = '3';

    /** The enumerated values for the TAG_GATEWAY field */
    const TAG_GATEWAY_0 = '0';
    const TAG_GATEWAY_1 = '1';

    /** The enumerated values for the PARTAGE_RECAP field */
    const PARTAGE_RECAP_0 = '0';
    const PARTAGE_RECAP_1 = '1';

    /** The enumerated values for the NATURE_SESSION field */
    const NATURE_SESSION_1 = '1';
    const NATURE_SESSION_2 = '2';
    const NATURE_SESSION_3 = '3';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identiy map to hold any loaded instances of TRendezVous objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array TRendezVous[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. TRendezVousPeer::$fieldNames[TRendezVousPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('IdRendezVous', 'DateCreation', 'DateConfirmation', 'DateAnnulation', 'MotifAnnulation', 'DateRdv', 'DateFinRdv', 'CodeRdv', 'EtatRdv', 'ModePriseRdv', 'TypePriseRdv', 'IdCitoyen', 'IdAgentAccueil', 'IdEtablissement', 'IdPrestation', 'IdAgentRessource', 'IdAgentTeleoperateur', 'IdAgentConfirmation', 'IdAgentAnnulation', 'IdReferent', 'TagGateway', 'IdUtilisateur', 'EtatAcquittement', 'DateAcquittement', 'ChampSuppPresta', 'IdChefRessource', 'PartageRecap', 'NatureSession', 'LieuRdv', 'LienRdv', 'NombreParticipant', 'Commentaire', 'IdValeurReferentiel', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idRendezVous', 'dateCreation', 'dateConfirmation', 'dateAnnulation', 'motifAnnulation', 'dateRdv', 'dateFinRdv', 'codeRdv', 'etatRdv', 'modePriseRdv', 'typePriseRdv', 'idCitoyen', 'idAgentAccueil', 'idEtablissement', 'idPrestation', 'idAgentRessource', 'idAgentTeleoperateur', 'idAgentConfirmation', 'idAgentAnnulation', 'idReferent', 'tagGateway', 'idUtilisateur', 'etatAcquittement', 'dateAcquittement', 'champSuppPresta', 'idChefRessource', 'partageRecap', 'natureSession', 'lieuRdv', 'lienRdv', 'nombreParticipant', 'commentaire', 'idValeurReferentiel', ),
        BasePeer::TYPE_COLNAME => array (TRendezVousPeer::ID_RENDEZ_VOUS, TRendezVousPeer::DATE_CREATION, TRendezVousPeer::DATE_CONFIRMATION, TRendezVousPeer::DATE_ANNULATION, TRendezVousPeer::MOTIF_ANNULATION, TRendezVousPeer::DATE_RDV, TRendezVousPeer::DATE_FIN_RDV, TRendezVousPeer::CODE_RDV, TRendezVousPeer::ETAT_RDV, TRendezVousPeer::MODE_PRISE_RDV, TRendezVousPeer::TYPE_PRISE_RDV, TRendezVousPeer::ID_CITOYEN, TRendezVousPeer::ID_AGENT_ACCUEIL, TRendezVousPeer::ID_ETABLISSEMENT, TRendezVousPeer::ID_PRESTATION, TRendezVousPeer::ID_AGENT_RESSOURCE, TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TRendezVousPeer::ID_AGENT_CONFIRMATION, TRendezVousPeer::ID_AGENT_ANNULATION, TRendezVousPeer::ID_REFERENT, TRendezVousPeer::TAG_GATEWAY, TRendezVousPeer::ID_UTILISATEUR, TRendezVousPeer::ETAT_ACQUITTEMENT, TRendezVousPeer::DATE_ACQUITTEMENT, TRendezVousPeer::CHAMP_SUPP_PRESTA, TRendezVousPeer::ID_CHEF_RESSOURCE, TRendezVousPeer::PARTAGE_RECAP, TRendezVousPeer::NATURE_SESSION, TRendezVousPeer::LIEU_RDV, TRendezVousPeer::LIEN_RDV, TRendezVousPeer::NOMBRE_PARTICIPANT, TRendezVousPeer::COMMENTAIRE, TRendezVousPeer::ID_VALEUR_REFERENTIEL, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_RENDEZ_VOUS', 'DATE_CREATION', 'DATE_CONFIRMATION', 'DATE_ANNULATION', 'MOTIF_ANNULATION', 'DATE_RDV', 'DATE_FIN_RDV', 'CODE_RDV', 'ETAT_RDV', 'MODE_PRISE_RDV', 'TYPE_PRISE_RDV', 'ID_CITOYEN', 'ID_AGENT_ACCUEIL', 'ID_ETABLISSEMENT', 'ID_PRESTATION', 'ID_AGENT_RESSOURCE', 'ID_AGENT_TELEOPERATEUR', 'ID_AGENT_CONFIRMATION', 'ID_AGENT_ANNULATION', 'ID_REFERENT', 'TAG_GATEWAY', 'ID_UTILISATEUR', 'ETAT_ACQUITTEMENT', 'DATE_ACQUITTEMENT', 'CHAMP_SUPP_PRESTA', 'ID_CHEF_RESSOURCE', 'PARTAGE_RECAP', 'NATURE_SESSION', 'LIEU_RDV', 'LIEN_RDV', 'NOMBRE_PARTICIPANT', 'COMMENTAIRE', 'ID_VALEUR_REFERENTIEL', ),
        BasePeer::TYPE_FIELDNAME => array ('ID_RENDEZ_VOUS', 'DATE_CREATION', 'DATE_CONFIRMATION', 'DATE_ANNULATION', 'MOTIF_ANNULATION', 'DATE_RDV', 'DATE_FIN_RDV', 'CODE_RDV', 'ETAT_RDV', 'MODE_PRISE_RDV', 'TYPE_PRISE_RDV', 'ID_CITOYEN', 'ID_AGENT_ACCUEIL', 'ID_ETABLISSEMENT', 'ID_PRESTATION', 'ID_AGENT_RESSOURCE', 'ID_AGENT_TELEOPERATEUR', 'ID_AGENT_CONFIRMATION', 'ID_AGENT_ANNULATION', 'ID_REFERENT', 'TAG_GATEWAY', 'ID_UTILISATEUR', 'ETAT_ACQUITTEMENT', 'DATE_ACQUITTEMENT', 'CHAMP_SUPP_PRESTA', 'ID_CHEF_RESSOURCE', 'PARTAGE_RECAP', 'NATURE_SESSION', 'LIEU_RDV', 'LIEN_RDV', 'NOMBRE_PARTICIPANT', 'COMMENTAIRE', 'ID_VALEUR_REFERENTIEL', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. TRendezVousPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('IdRendezVous' => 0, 'DateCreation' => 1, 'DateConfirmation' => 2, 'DateAnnulation' => 3, 'MotifAnnulation' => 4, 'DateRdv' => 5, 'DateFinRdv' => 6, 'CodeRdv' => 7, 'EtatRdv' => 8, 'ModePriseRdv' => 9, 'TypePriseRdv' => 10, 'IdCitoyen' => 11, 'IdAgentAccueil' => 12, 'IdEtablissement' => 13, 'IdPrestation' => 14, 'IdAgentRessource' => 15, 'IdAgentTeleoperateur' => 16, 'IdAgentConfirmation' => 17, 'IdAgentAnnulation' => 18, 'IdReferent' => 19, 'TagGateway' => 20, 'IdUtilisateur' => 21, 'EtatAcquittement' => 22, 'DateAcquittement' => 23, 'ChampSuppPresta' => 24, 'IdChefRessource' => 25, 'PartageRecap' => 26, 'NatureSession' => 27, 'LieuRdv' => 28, 'LienRdv' => 29, 'NombreParticipant' => 30, 'Commentaire' => 31, 'IdValeurReferentiel' => 32, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idRendezVous' => 0, 'dateCreation' => 1, 'dateConfirmation' => 2, 'dateAnnulation' => 3, 'motifAnnulation' => 4, 'dateRdv' => 5, 'dateFinRdv' => 6, 'codeRdv' => 7, 'etatRdv' => 8, 'modePriseRdv' => 9, 'typePriseRdv' => 10, 'idCitoyen' => 11, 'idAgentAccueil' => 12, 'idEtablissement' => 13, 'idPrestation' => 14, 'idAgentRessource' => 15, 'idAgentTeleoperateur' => 16, 'idAgentConfirmation' => 17, 'idAgentAnnulation' => 18, 'idReferent' => 19, 'tagGateway' => 20, 'idUtilisateur' => 21, 'etatAcquittement' => 22, 'dateAcquittement' => 23, 'champSuppPresta' => 24, 'idChefRessource' => 25, 'partageRecap' => 26, 'natureSession' => 27, 'lieuRdv' => 28, 'lienRdv' => 29, 'nombreParticipant' => 30, 'commentaire' => 31, 'idValeurReferentiel' => 32, ),
        BasePeer::TYPE_COLNAME => array (TRendezVousPeer::ID_RENDEZ_VOUS => 0, TRendezVousPeer::DATE_CREATION => 1, TRendezVousPeer::DATE_CONFIRMATION => 2, TRendezVousPeer::DATE_ANNULATION => 3, TRendezVousPeer::MOTIF_ANNULATION => 4, TRendezVousPeer::DATE_RDV => 5, TRendezVousPeer::DATE_FIN_RDV => 6, TRendezVousPeer::CODE_RDV => 7, TRendezVousPeer::ETAT_RDV => 8, TRendezVousPeer::MODE_PRISE_RDV => 9, TRendezVousPeer::TYPE_PRISE_RDV => 10, TRendezVousPeer::ID_CITOYEN => 11, TRendezVousPeer::ID_AGENT_ACCUEIL => 12, TRendezVousPeer::ID_ETABLISSEMENT => 13, TRendezVousPeer::ID_PRESTATION => 14, TRendezVousPeer::ID_AGENT_RESSOURCE => 15, TRendezVousPeer::ID_AGENT_TELEOPERATEUR => 16, TRendezVousPeer::ID_AGENT_CONFIRMATION => 17, TRendezVousPeer::ID_AGENT_ANNULATION => 18, TRendezVousPeer::ID_REFERENT => 19, TRendezVousPeer::TAG_GATEWAY => 20, TRendezVousPeer::ID_UTILISATEUR => 21, TRendezVousPeer::ETAT_ACQUITTEMENT => 22, TRendezVousPeer::DATE_ACQUITTEMENT => 23, TRendezVousPeer::CHAMP_SUPP_PRESTA => 24, TRendezVousPeer::ID_CHEF_RESSOURCE => 25, TRendezVousPeer::PARTAGE_RECAP => 26, TRendezVousPeer::NATURE_SESSION => 27, TRendezVousPeer::LIEU_RDV => 28, TRendezVousPeer::LIEN_RDV => 29, TRendezVousPeer::NOMBRE_PARTICIPANT => 30, TRendezVousPeer::COMMENTAIRE => 31, TRendezVousPeer::ID_VALEUR_REFERENTIEL => 32, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_RENDEZ_VOUS' => 0, 'DATE_CREATION' => 1, 'DATE_CONFIRMATION' => 2, 'DATE_ANNULATION' => 3, 'MOTIF_ANNULATION' => 4, 'DATE_RDV' => 5, 'DATE_FIN_RDV' => 6, 'CODE_RDV' => 7, 'ETAT_RDV' => 8, 'MODE_PRISE_RDV' => 9, 'TYPE_PRISE_RDV' => 10, 'ID_CITOYEN' => 11, 'ID_AGENT_ACCUEIL' => 12, 'ID_ETABLISSEMENT' => 13, 'ID_PRESTATION' => 14, 'ID_AGENT_RESSOURCE' => 15, 'ID_AGENT_TELEOPERATEUR' => 16, 'ID_AGENT_CONFIRMATION' => 17, 'ID_AGENT_ANNULATION' => 18, 'ID_REFERENT' => 19, 'TAG_GATEWAY' => 20, 'ID_UTILISATEUR' => 21, 'ETAT_ACQUITTEMENT' => 22, 'DATE_ACQUITTEMENT' => 23, 'CHAMP_SUPP_PRESTA' => 24, 'ID_CHEF_RESSOURCE' => 25, 'PARTAGE_RECAP' => 26, 'NATURE_SESSION' => 27, 'LIEU_RDV' => 28, 'LIEN_RDV' => 29, 'NOMBRE_PARTICIPANT' => 30, 'COMMENTAIRE' => 31, 'ID_VALEUR_REFERENTIEL' => 32, ),
        BasePeer::TYPE_FIELDNAME => array ('ID_RENDEZ_VOUS' => 0, 'DATE_CREATION' => 1, 'DATE_CONFIRMATION' => 2, 'DATE_ANNULATION' => 3, 'MOTIF_ANNULATION' => 4, 'DATE_RDV' => 5, 'DATE_FIN_RDV' => 6, 'CODE_RDV' => 7, 'ETAT_RDV' => 8, 'MODE_PRISE_RDV' => 9, 'TYPE_PRISE_RDV' => 10, 'ID_CITOYEN' => 11, 'ID_AGENT_ACCUEIL' => 12, 'ID_ETABLISSEMENT' => 13, 'ID_PRESTATION' => 14, 'ID_AGENT_RESSOURCE' => 15, 'ID_AGENT_TELEOPERATEUR' => 16, 'ID_AGENT_CONFIRMATION' => 17, 'ID_AGENT_ANNULATION' => 18, 'ID_REFERENT' => 19, 'TAG_GATEWAY' => 20, 'ID_UTILISATEUR' => 21, 'ETAT_ACQUITTEMENT' => 22, 'DATE_ACQUITTEMENT' => 23, 'CHAMP_SUPP_PRESTA' => 24, 'ID_CHEF_RESSOURCE' => 25, 'PARTAGE_RECAP' => 26, 'NATURE_SESSION' => 27, 'LIEU_RDV' => 28, 'LIEN_RDV' => 29, 'NOMBRE_PARTICIPANT' => 30, 'COMMENTAIRE' => 31, 'ID_VALEUR_REFERENTIEL' => 32, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, )
    );

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
        TRendezVousPeer::ETAT_RDV => array(
            TRendezVousPeer::ETAT_RDV_0,
            TRendezVousPeer::ETAT_RDV_1,
            TRendezVousPeer::ETAT_RDV_2,
            TRendezVousPeer::ETAT_RDV_3,
            TRendezVousPeer::ETAT_RDV_4,
            TRendezVousPeer::ETAT_RDV_5,
        ),
        TRendezVousPeer::MODE_PRISE_RDV => array(
            TRendezVousPeer::MODE_PRISE_RDV_0,
            TRendezVousPeer::MODE_PRISE_RDV_1,
            TRendezVousPeer::MODE_PRISE_RDV_2,
            TRendezVousPeer::MODE_PRISE_RDV_3,
        ),
        TRendezVousPeer::TYPE_PRISE_RDV => array(
            TRendezVousPeer::TYPE_PRISE_RDV_0,
            TRendezVousPeer::TYPE_PRISE_RDV_1,
            TRendezVousPeer::TYPE_PRISE_RDV_2,
            TRendezVousPeer::TYPE_PRISE_RDV_3,
        ),
        TRendezVousPeer::TAG_GATEWAY => array(
            TRendezVousPeer::TAG_GATEWAY_0,
            TRendezVousPeer::TAG_GATEWAY_1,
        ),
        TRendezVousPeer::PARTAGE_RECAP => array(
            TRendezVousPeer::PARTAGE_RECAP_0,
            TRendezVousPeer::PARTAGE_RECAP_1,
        ),
        TRendezVousPeer::NATURE_SESSION => array(
            TRendezVousPeer::NATURE_SESSION_1,
            TRendezVousPeer::NATURE_SESSION_2,
            TRendezVousPeer::NATURE_SESSION_3,
        ),
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = TRendezVousPeer::getFieldNames($toType);
        $key = isset(TRendezVousPeer::$fieldKeys[$fromType][$name]) ? TRendezVousPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(TRendezVousPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, TRendezVousPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return TRendezVousPeer::$fieldNames[$type];
    }

    /**
     * Gets the list of values for all ENUM columns
     * @return array
     */
    public static function getValueSets()
    {
      return TRendezVousPeer::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM column
     *
     * @param string $colname The ENUM column name.
     *
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = TRendezVousPeer::getValueSets();

        if (!isset($valueSets[$colname])) {
            throw new PropelException(sprintf('Column "%s" has no ValueSet.', $colname));
        }

        return $valueSets[$colname];
    }

    /**
     * Gets the SQL value for the ENUM column value
     *
     * @param string $colname ENUM column name.
     * @param string $enumVal ENUM value.
     *
     * @return int            SQL value
     */
    public static function getSqlValueForEnum($colname, $enumVal)
    {
        $values = TRendezVousPeer::getValueSet($colname);
        if (!in_array($enumVal, $values)) {
            throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $colname));
        }
        return array_search($enumVal, $values);
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. TRendezVousPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(TRendezVousPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(TRendezVousPeer::ID_RENDEZ_VOUS);
            $criteria->addSelectColumn(TRendezVousPeer::DATE_CREATION);
            $criteria->addSelectColumn(TRendezVousPeer::DATE_CONFIRMATION);
            $criteria->addSelectColumn(TRendezVousPeer::DATE_ANNULATION);
            $criteria->addSelectColumn(TRendezVousPeer::MOTIF_ANNULATION);
            $criteria->addSelectColumn(TRendezVousPeer::DATE_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::DATE_FIN_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::CODE_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::ETAT_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::MODE_PRISE_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::TYPE_PRISE_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::ID_CITOYEN);
            $criteria->addSelectColumn(TRendezVousPeer::ID_AGENT_ACCUEIL);
            $criteria->addSelectColumn(TRendezVousPeer::ID_ETABLISSEMENT);
            $criteria->addSelectColumn(TRendezVousPeer::ID_PRESTATION);
            $criteria->addSelectColumn(TRendezVousPeer::ID_AGENT_RESSOURCE);
            $criteria->addSelectColumn(TRendezVousPeer::ID_AGENT_TELEOPERATEUR);
            $criteria->addSelectColumn(TRendezVousPeer::ID_AGENT_CONFIRMATION);
            $criteria->addSelectColumn(TRendezVousPeer::ID_AGENT_ANNULATION);
            $criteria->addSelectColumn(TRendezVousPeer::ID_REFERENT);
            $criteria->addSelectColumn(TRendezVousPeer::TAG_GATEWAY);
            $criteria->addSelectColumn(TRendezVousPeer::ID_UTILISATEUR);
            $criteria->addSelectColumn(TRendezVousPeer::ETAT_ACQUITTEMENT);
            $criteria->addSelectColumn(TRendezVousPeer::DATE_ACQUITTEMENT);
            $criteria->addSelectColumn(TRendezVousPeer::CHAMP_SUPP_PRESTA);
            $criteria->addSelectColumn(TRendezVousPeer::ID_CHEF_RESSOURCE);
            $criteria->addSelectColumn(TRendezVousPeer::PARTAGE_RECAP);
            $criteria->addSelectColumn(TRendezVousPeer::NATURE_SESSION);
            $criteria->addSelectColumn(TRendezVousPeer::LIEU_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::LIEN_RDV);
            $criteria->addSelectColumn(TRendezVousPeer::NOMBRE_PARTICIPANT);
            $criteria->addSelectColumn(TRendezVousPeer::COMMENTAIRE);
            $criteria->addSelectColumn(TRendezVousPeer::ID_VALEUR_REFERENTIEL);
        } else {
            $criteria->addSelectColumn($alias . '.ID_RENDEZ_VOUS');
            $criteria->addSelectColumn($alias . '.DATE_CREATION');
            $criteria->addSelectColumn($alias . '.DATE_CONFIRMATION');
            $criteria->addSelectColumn($alias . '.DATE_ANNULATION');
            $criteria->addSelectColumn($alias . '.MOTIF_ANNULATION');
            $criteria->addSelectColumn($alias . '.DATE_RDV');
            $criteria->addSelectColumn($alias . '.DATE_FIN_RDV');
            $criteria->addSelectColumn($alias . '.CODE_RDV');
            $criteria->addSelectColumn($alias . '.ETAT_RDV');
            $criteria->addSelectColumn($alias . '.MODE_PRISE_RDV');
            $criteria->addSelectColumn($alias . '.TYPE_PRISE_RDV');
            $criteria->addSelectColumn($alias . '.ID_CITOYEN');
            $criteria->addSelectColumn($alias . '.ID_AGENT_ACCUEIL');
            $criteria->addSelectColumn($alias . '.ID_ETABLISSEMENT');
            $criteria->addSelectColumn($alias . '.ID_PRESTATION');
            $criteria->addSelectColumn($alias . '.ID_AGENT_RESSOURCE');
            $criteria->addSelectColumn($alias . '.ID_AGENT_TELEOPERATEUR');
            $criteria->addSelectColumn($alias . '.ID_AGENT_CONFIRMATION');
            $criteria->addSelectColumn($alias . '.ID_AGENT_ANNULATION');
            $criteria->addSelectColumn($alias . '.ID_REFERENT');
            $criteria->addSelectColumn($alias . '.TAG_GATEWAY');
            $criteria->addSelectColumn($alias . '.ID_UTILISATEUR');
            $criteria->addSelectColumn($alias . '.ETAT_ACQUITTEMENT');
            $criteria->addSelectColumn($alias . '.DATE_ACQUITTEMENT');
            $criteria->addSelectColumn($alias . '.CHAMP_SUPP_PRESTA');
            $criteria->addSelectColumn($alias . '.ID_CHEF_RESSOURCE');
            $criteria->addSelectColumn($alias . '.PARTAGE_RECAP');
            $criteria->addSelectColumn($alias . '.NATURE_SESSION');
            $criteria->addSelectColumn($alias . '.LIEU_RDV');
            $criteria->addSelectColumn($alias . '.LIEN_RDV');
            $criteria->addSelectColumn($alias . '.NOMBRE_PARTICIPANT');
            $criteria->addSelectColumn($alias . '.COMMENTAIRE');
            $criteria->addSelectColumn($alias . '.ID_VALEUR_REFERENTIEL');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return                 TRendezVous
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = TRendezVousPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return TRendezVousPeer::populateObjects(TRendezVousPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            TRendezVousPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param      TRendezVous $obj A TRendezVous object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getIdRendezVous();
            } // if key === null
            TRendezVousPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A TRendezVous object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof TRendezVous) {
                $key = (string) $value->getIdRendezVous();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or TRendezVous object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(TRendezVousPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return   TRendezVous Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(TRendezVousPeer::$instances[$key])) {
                return TRendezVousPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references)
      {
        foreach (TRendezVousPeer::$instances as $instance)
        {
          $instance->clearAllReferences(true);
        }
      }
        TRendezVousPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to T_RENDEZ_VOUS
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = TRendezVousPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = TRendezVousPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                TRendezVousPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (TRendezVous object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = TRendezVousPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = TRendezVousPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = TRendezVousPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            TRendezVousPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related TCitoyen table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTCitoyen(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentAccueil table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTAgentRelatedByIdAgentAccueil(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentAnnulation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTAgentRelatedByIdAgentAnnulation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentConfirmation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTAgentRelatedByIdAgentConfirmation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentRessource table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTAgentRelatedByIdAgentRessource(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentTeleoperateur table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTAgentRelatedByIdAgentTeleoperateur(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentiel table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTValeurReferentiel(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TEtablissement table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTEtablissement(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TPrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTPrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferent table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTReferent(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TCitoyen objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTCitoyen(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TCitoyenPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TAgent objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTAgentRelatedByIdAgentAccueil(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TAgentPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TAgentPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TAgentPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TAgentPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TAgent)
                $obj2->addTRendezVousRelatedByIdAgentAccueil($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TAgent objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTAgentRelatedByIdAgentAnnulation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TAgentPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TAgentPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TAgentPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TAgentPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TAgent)
                $obj2->addTRendezVousRelatedByIdAgentAnnulation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TAgent objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTAgentRelatedByIdAgentConfirmation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TAgentPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TAgentPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TAgentPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TAgentPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TAgent)
                $obj2->addTRendezVousRelatedByIdAgentConfirmation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TAgent objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTAgentRelatedByIdAgentRessource(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TAgentPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TAgentPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TAgentPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TAgentPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TAgent)
                $obj2->addTRendezVousRelatedByIdAgentRessource($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TAgent objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTAgentRelatedByIdAgentTeleoperateur(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TAgentPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TAgentPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TAgentPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TAgentPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TAgent)
                $obj2->addTRendezVousRelatedByIdAgentTeleoperateur($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TValeurReferentiel objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTValeurReferentiel(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TValeurReferentielPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TValeurReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TValeurReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TValeurReferentiel)
                $obj2->addTRendezVous($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TEtablissement objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTEtablissement(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TEtablissementPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TEtablissementPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TEtablissementPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TEtablissementPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TEtablissement)
                $obj2->addTRendezVous($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TPrestation objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTPrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TPrestationPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TPrestationPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TPrestationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TPrestationPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TPrestation)
                $obj2->addTRendezVous($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with their TReferent objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTReferent(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol = TRendezVousPeer::NUM_HYDRATE_COLUMNS;
        TReferentPeer::addSelectColumns($criteria);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TReferentPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TReferentPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TReferentPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TRendezVous) to $obj2 (TReferent)
                $obj2->addTRendezVous($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined TCitoyen rows

            $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);
            } // if joined row not null

            // Add objects for joined TAgent rows

            $key3 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = TAgentPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = TAgentPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TAgentPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TAgent)
                $obj3->addTRendezVousRelatedByIdAgentAccueil($obj1);
            } // if joined row not null

            // Add objects for joined TAgent rows

            $key4 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = TAgentPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = TAgentPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TAgentPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TAgent)
                $obj4->addTRendezVousRelatedByIdAgentAnnulation($obj1);
            } // if joined row not null

            // Add objects for joined TAgent rows

            $key5 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol5);
            if ($key5 !== null) {
                $obj5 = TAgentPeer::getInstanceFromPool($key5);
                if (!$obj5) {

                    $cls = TAgentPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TAgentPeer::addInstanceToPool($obj5, $key5);
                } // if obj5 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TAgent)
                $obj5->addTRendezVousRelatedByIdAgentConfirmation($obj1);
            } // if joined row not null

            // Add objects for joined TAgent rows

            $key6 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
            if ($key6 !== null) {
                $obj6 = TAgentPeer::getInstanceFromPool($key6);
                if (!$obj6) {

                    $cls = TAgentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TAgentPeer::addInstanceToPool($obj6, $key6);
                } // if obj6 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TAgent)
                $obj6->addTRendezVousRelatedByIdAgentRessource($obj1);
            } // if joined row not null

            // Add objects for joined TAgent rows

            $key7 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol7);
            if ($key7 !== null) {
                $obj7 = TAgentPeer::getInstanceFromPool($key7);
                if (!$obj7) {

                    $cls = TAgentPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TAgentPeer::addInstanceToPool($obj7, $key7);
                } // if obj7 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj7 (TAgent)
                $obj7->addTRendezVousRelatedByIdAgentTeleoperateur($obj1);
            } // if joined row not null

            // Add objects for joined TValeurReferentiel rows

            $key8 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol8);
            if ($key8 !== null) {
                $obj8 = TValeurReferentielPeer::getInstanceFromPool($key8);
                if (!$obj8) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TValeurReferentielPeer::addInstanceToPool($obj8, $key8);
                } // if obj8 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj8 (TValeurReferentiel)
                $obj8->addTRendezVous($obj1);
            } // if joined row not null

            // Add objects for joined TEtablissement rows

            $key9 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol9);
            if ($key9 !== null) {
                $obj9 = TEtablissementPeer::getInstanceFromPool($key9);
                if (!$obj9) {

                    $cls = TEtablissementPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TEtablissementPeer::addInstanceToPool($obj9, $key9);
                } // if obj9 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj9 (TEtablissement)
                $obj9->addTRendezVous($obj1);
            } // if joined row not null

            // Add objects for joined TPrestation rows

            $key10 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol10);
            if ($key10 !== null) {
                $obj10 = TPrestationPeer::getInstanceFromPool($key10);
                if (!$obj10) {

                    $cls = TPrestationPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TPrestationPeer::addInstanceToPool($obj10, $key10);
                } // if obj10 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj10 (TPrestation)
                $obj10->addTRendezVous($obj1);
            } // if joined row not null

            // Add objects for joined TReferent rows

            $key11 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol11);
            if ($key11 !== null) {
                $obj11 = TReferentPeer::getInstanceFromPool($key11);
                if (!$obj11) {

                    $cls = TReferentPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    TReferentPeer::addInstanceToPool($obj11, $key11);
                } // if obj11 loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj11 (TReferent)
                $obj11->addTRendezVous($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TCitoyen table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTCitoyen(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentAccueil table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTAgentRelatedByIdAgentAccueil(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentAnnulation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTAgentRelatedByIdAgentAnnulation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentConfirmation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTAgentRelatedByIdAgentConfirmation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentRessource table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTAgentRelatedByIdAgentRessource(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TAgentRelatedByIdAgentTeleoperateur table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTAgentRelatedByIdAgentTeleoperateur(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentiel table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTValeurReferentiel(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TEtablissement table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTEtablissement(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TPrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTPrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferent table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTReferent(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TRendezVousPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TCitoyen.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTCitoyen(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TAgent rows

                $key2 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TAgentPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TAgentPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TAgentPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TAgent)
                $obj2->addTRendezVousRelatedByIdAgentAccueil($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key3 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TAgentPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TAgentPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TAgentPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TAgent)
                $obj3->addTRendezVousRelatedByIdAgentAnnulation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key4 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TAgentPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TAgentPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TAgentPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TAgent)
                $obj4->addTRendezVousRelatedByIdAgentConfirmation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key5 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TAgentPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TAgentPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TAgentPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TAgent)
                $obj5->addTRendezVousRelatedByIdAgentRessource($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key6 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TAgentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TAgentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TAgentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TAgent)
                $obj6->addTRendezVousRelatedByIdAgentTeleoperateur($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key7 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TValeurReferentielPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TValeurReferentielPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj7 (TValeurReferentiel)
                $obj7->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key8 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TEtablissementPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TEtablissementPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj8 (TEtablissement)
                $obj8->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key9 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TPrestationPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TPrestationPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj9 (TPrestation)
                $obj9->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key10 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = TReferentPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = TReferentPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TReferentPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj10 (TReferent)
                $obj10->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TAgentRelatedByIdAgentAccueil.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTAgentRelatedByIdAgentAccueil(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key3 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TValeurReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TValeurReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TValeurReferentiel)
                $obj3->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key4 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TEtablissementPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TEtablissementPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TEtablissement)
                $obj4->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key5 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TPrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TPrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TPrestation)
                $obj5->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key6 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TReferentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TReferentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TReferentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TReferent)
                $obj6->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TAgentRelatedByIdAgentAnnulation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTAgentRelatedByIdAgentAnnulation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key3 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TValeurReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TValeurReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TValeurReferentiel)
                $obj3->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key4 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TEtablissementPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TEtablissementPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TEtablissement)
                $obj4->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key5 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TPrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TPrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TPrestation)
                $obj5->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key6 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TReferentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TReferentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TReferentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TReferent)
                $obj6->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TAgentRelatedByIdAgentConfirmation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTAgentRelatedByIdAgentConfirmation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key3 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TValeurReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TValeurReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TValeurReferentiel)
                $obj3->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key4 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TEtablissementPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TEtablissementPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TEtablissement)
                $obj4->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key5 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TPrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TPrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TPrestation)
                $obj5->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key6 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TReferentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TReferentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TReferentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TReferent)
                $obj6->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TAgentRelatedByIdAgentRessource.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTAgentRelatedByIdAgentRessource(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key3 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TValeurReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TValeurReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TValeurReferentiel)
                $obj3->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key4 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TEtablissementPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TEtablissementPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TEtablissement)
                $obj4->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key5 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TPrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TPrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TPrestation)
                $obj5->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key6 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TReferentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TReferentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TReferentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TReferent)
                $obj6->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TAgentRelatedByIdAgentTeleoperateur.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTAgentRelatedByIdAgentTeleoperateur(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key3 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TValeurReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TValeurReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TValeurReferentiel)
                $obj3->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key4 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TEtablissementPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TEtablissementPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TEtablissement)
                $obj4->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key5 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TPrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TPrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TPrestation)
                $obj5->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key6 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TReferentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TReferentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TReferentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TReferent)
                $obj6->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TValeurReferentiel.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTValeurReferentiel(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key3 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TAgentPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TAgentPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TAgentPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TAgent)
                $obj3->addTRendezVousRelatedByIdAgentAccueil($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key4 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TAgentPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TAgentPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TAgentPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TAgent)
                $obj4->addTRendezVousRelatedByIdAgentAnnulation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key5 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TAgentPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TAgentPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TAgentPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TAgent)
                $obj5->addTRendezVousRelatedByIdAgentConfirmation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key6 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TAgentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TAgentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TAgentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TAgent)
                $obj6->addTRendezVousRelatedByIdAgentRessource($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key7 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TAgentPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TAgentPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TAgentPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj7 (TAgent)
                $obj7->addTRendezVousRelatedByIdAgentTeleoperateur($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key8 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TEtablissementPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TEtablissementPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj8 (TEtablissement)
                $obj8->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key9 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TPrestationPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TPrestationPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj9 (TPrestation)
                $obj9->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key10 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = TReferentPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = TReferentPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TReferentPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj10 (TReferent)
                $obj10->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TEtablissement.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTEtablissement(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key3 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TAgentPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TAgentPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TAgentPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TAgent)
                $obj3->addTRendezVousRelatedByIdAgentAccueil($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key4 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TAgentPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TAgentPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TAgentPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TAgent)
                $obj4->addTRendezVousRelatedByIdAgentAnnulation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key5 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TAgentPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TAgentPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TAgentPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TAgent)
                $obj5->addTRendezVousRelatedByIdAgentConfirmation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key6 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TAgentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TAgentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TAgentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TAgent)
                $obj6->addTRendezVousRelatedByIdAgentRessource($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key7 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TAgentPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TAgentPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TAgentPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj7 (TAgent)
                $obj7->addTRendezVousRelatedByIdAgentTeleoperateur($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key8 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TValeurReferentielPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TValeurReferentielPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj8 (TValeurReferentiel)
                $obj8->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key9 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TPrestationPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TPrestationPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj9 (TPrestation)
                $obj9->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key10 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = TReferentPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = TReferentPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TReferentPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj10 (TReferent)
                $obj10->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TPrestation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTPrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TReferentPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TReferentPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_REFERENT, TReferentPeer::ID_REFERENT, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key3 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TAgentPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TAgentPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TAgentPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TAgent)
                $obj3->addTRendezVousRelatedByIdAgentAccueil($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key4 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TAgentPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TAgentPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TAgentPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TAgent)
                $obj4->addTRendezVousRelatedByIdAgentAnnulation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key5 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TAgentPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TAgentPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TAgentPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TAgent)
                $obj5->addTRendezVousRelatedByIdAgentConfirmation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key6 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TAgentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TAgentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TAgentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TAgent)
                $obj6->addTRendezVousRelatedByIdAgentRessource($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key7 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TAgentPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TAgentPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TAgentPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj7 (TAgent)
                $obj7->addTRendezVousRelatedByIdAgentTeleoperateur($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key8 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TValeurReferentielPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TValeurReferentielPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj8 (TValeurReferentiel)
                $obj8->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key9 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TEtablissementPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TEtablissementPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj9 (TEtablissement)
                $obj9->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TReferent rows

                $key10 = TReferentPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = TReferentPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = TReferentPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TReferentPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj10 (TReferent)
                $obj10->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TRendezVous objects pre-filled with all related objects except TReferent.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TRendezVous objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTReferent(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);
        }

        TRendezVousPeer::addSelectColumns($criteria);
        $startcol2 = TRendezVousPeer::NUM_HYDRATE_COLUMNS;

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TAgentPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TAgentPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TEtablissementPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TEtablissementPeer::NUM_HYDRATE_COLUMNS;

        TPrestationPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TPrestationPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TRendezVousPeer::ID_CITOYEN, TCitoyenPeer::ID_CITOYEN, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ACCUEIL, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_ANNULATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_CONFIRMATION, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_RESSOURCE, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, TAgentPeer::ID_AGENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_VALEUR_REFERENTIEL, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_ETABLISSEMENT, TEtablissementPeer::ID_ETABLISSEMENT, $join_behavior);

        $criteria->addJoin(TRendezVousPeer::ID_PRESTATION, TPrestationPeer::ID_PRESTATION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TRendezVousPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TRendezVousPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TRendezVousPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TRendezVousPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TCitoyen rows

                $key2 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TCitoyenPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TCitoyenPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TCitoyenPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj2 (TCitoyen)
                $obj2->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key3 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TAgentPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TAgentPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TAgentPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj3 (TAgent)
                $obj3->addTRendezVousRelatedByIdAgentAccueil($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key4 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TAgentPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TAgentPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TAgentPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj4 (TAgent)
                $obj4->addTRendezVousRelatedByIdAgentAnnulation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key5 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TAgentPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TAgentPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TAgentPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj5 (TAgent)
                $obj5->addTRendezVousRelatedByIdAgentConfirmation($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key6 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TAgentPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TAgentPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TAgentPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj6 (TAgent)
                $obj6->addTRendezVousRelatedByIdAgentRessource($obj1);

            } // if joined row is not null

                // Add objects for joined TAgent rows

                $key7 = TAgentPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TAgentPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TAgentPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TAgentPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj7 (TAgent)
                $obj7->addTRendezVousRelatedByIdAgentTeleoperateur($obj1);

            } // if joined row is not null

                // Add objects for joined TValeurReferentiel rows

                $key8 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TValeurReferentielPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TValeurReferentielPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TValeurReferentielPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj8 (TValeurReferentiel)
                $obj8->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TEtablissement rows

                $key9 = TEtablissementPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TEtablissementPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TEtablissementPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TEtablissementPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj9 (TEtablissement)
                $obj9->addTRendezVous($obj1);

            } // if joined row is not null

                // Add objects for joined TPrestation rows

                $key10 = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = TPrestationPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = TPrestationPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TPrestationPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (TRendezVous) to the collection in $obj10 (TPrestation)
                $obj10->addTRendezVous($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(TRendezVousPeer::DATABASE_NAME)->getTable(TRendezVousPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseTRendezVousPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseTRendezVousPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new TRendezVousTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return TRendezVousPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a TRendezVous or Criteria object.
     *
     * @param      mixed $values Criteria or TRendezVous object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from TRendezVous object
        }

        if ($criteria->containsKey(TRendezVousPeer::ID_RENDEZ_VOUS) && $criteria->keyContainsValue(TRendezVousPeer::ID_RENDEZ_VOUS) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.TRendezVousPeer::ID_RENDEZ_VOUS.')');
        }


        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a TRendezVous or Criteria object.
     *
     * @param      mixed $values Criteria or TRendezVous object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(TRendezVousPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(TRendezVousPeer::ID_RENDEZ_VOUS);
            $value = $criteria->remove(TRendezVousPeer::ID_RENDEZ_VOUS);
            if ($value) {
                $selectCriteria->add(TRendezVousPeer::ID_RENDEZ_VOUS, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(TRendezVousPeer::TABLE_NAME);
            }

        } else { // $values is TRendezVous object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the T_RENDEZ_VOUS table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(TRendezVousPeer::TABLE_NAME, $con, TRendezVousPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            TRendezVousPeer::clearInstancePool();
            TRendezVousPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a TRendezVous or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or TRendezVous object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            TRendezVousPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof TRendezVous) { // it's a model object
            // invalidate the cache for this single object
            TRendezVousPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(TRendezVousPeer::DATABASE_NAME);
            $criteria->add(TRendezVousPeer::ID_RENDEZ_VOUS, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                TRendezVousPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(TRendezVousPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            TRendezVousPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given TRendezVous object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param      TRendezVous $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(TRendezVousPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(TRendezVousPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(TRendezVousPeer::DATABASE_NAME, TRendezVousPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param      int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return TRendezVous
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = TRendezVousPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(TRendezVousPeer::DATABASE_NAME);
        $criteria->add(TRendezVousPeer::ID_RENDEZ_VOUS, $pk);

        $v = TRendezVousPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return TRendezVous[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(TRendezVousPeer::DATABASE_NAME);
            $criteria->add(TRendezVousPeer::ID_RENDEZ_VOUS, $pks, Criteria::IN);
            $objs = TRendezVousPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseTRendezVousPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseTRendezVousPeer::buildTableMap();

