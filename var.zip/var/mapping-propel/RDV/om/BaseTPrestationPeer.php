<?php


/**
 * Base static class for performing query and update operations on the 'T_PRESTATION' table.
 *
 *
 *
 * @package propel.generator.RDV.om
 */
abstract class BaseTPrestationPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'RDV';

    /** the table name for this class */
    const TABLE_NAME = 'T_PRESTATION';

    /** the related Propel class for this table */
    const OM_CLASS = 'TPrestation';

    /** the related TableMap class for this table */
    const TM_CLASS = 'TPrestationTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 21;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 21;

    /** the column name for the ID_PRESTATION field */
    const ID_PRESTATION = 'T_PRESTATION.ID_PRESTATION';

    /** the column name for the ID_REF_PRESTATION field */
    const ID_REF_PRESTATION = 'T_PRESTATION.ID_REF_PRESTATION';

    /** the column name for the CODE_LIBELLE_PRESTATION field */
    const CODE_LIBELLE_PRESTATION = 'T_PRESTATION.CODE_LIBELLE_PRESTATION';

    /** the column name for the ID_TYPE_PRESTATION field */
    const ID_TYPE_PRESTATION = 'T_PRESTATION.ID_TYPE_PRESTATION';

    /** the column name for the RDV_SIMILAIRE field */
    const RDV_SIMILAIRE = 'T_PRESTATION.RDV_SIMILAIRE';

    /** the column name for the NB_JOUR_RDV_SIMILAIRE field */
    const NB_JOUR_RDV_SIMILAIRE = 'T_PRESTATION.NB_JOUR_RDV_SIMILAIRE';

    /** the column name for the DELAI_MIN field */
    const DELAI_MIN = 'T_PRESTATION.DELAI_MIN';

    /** the column name for the PERIODICITE field */
    const PERIODICITE = 'T_PRESTATION.PERIODICITE';

    /** the column name for the RESSOURCE_VISIBLE field */
    const RESSOURCE_VISIBLE = 'T_PRESTATION.RESSOURCE_VISIBLE';

    /** the column name for the RESSOURCE_OBLIGATOIRE field */
    const RESSOURCE_OBLIGATOIRE = 'T_PRESTATION.RESSOURCE_OBLIGATOIRE';

    /** the column name for the ID_PARAMETRE_FORM field */
    const ID_PARAMETRE_FORM = 'T_PRESTATION.ID_PARAMETRE_FORM';

    /** the column name for the CODE_COMMENTAIRE field */
    const CODE_COMMENTAIRE = 'T_PRESTATION.CODE_COMMENTAIRE';

    /** the column name for the REFERENT_VISIBLE field */
    const REFERENT_VISIBLE = 'T_PRESTATION.REFERENT_VISIBLE';

    /** the column name for the ID_PARAMETRAGE_PRESTATION field */
    const ID_PARAMETRAGE_PRESTATION = 'T_PRESTATION.ID_PARAMETRAGE_PRESTATION';

    /** the column name for the ID_CHAMPS_SUPP_1 field */
    const ID_CHAMPS_SUPP_1 = 'T_PRESTATION.ID_CHAMPS_SUPP_1';

    /** the column name for the ID_CHAMPS_SUPP_2 field */
    const ID_CHAMPS_SUPP_2 = 'T_PRESTATION.ID_CHAMPS_SUPP_2';

    /** the column name for the ID_CHAMPS_SUPP_3 field */
    const ID_CHAMPS_SUPP_3 = 'T_PRESTATION.ID_CHAMPS_SUPP_3';

    /** the column name for the VISIOCONFERENCE field */
    const VISIOCONFERENCE = 'T_PRESTATION.VISIOCONFERENCE';

    /** the column name for the RDV_GROUPE field */
    const RDV_GROUPE = 'T_PRESTATION.RDV_GROUPE';

    /** the column name for the NOMBRE_MAX_PARTICIPANTS field */
    const NOMBRE_MAX_PARTICIPANTS = 'T_PRESTATION.NOMBRE_MAX_PARTICIPANTS';

    /** the column name for the TYPE_SESSION field */
    const TYPE_SESSION = 'T_PRESTATION.TYPE_SESSION';

    /** The enumerated values for the RDV_SIMILAIRE field */
    const RDV_SIMILAIRE_0 = '0';
    const RDV_SIMILAIRE_1 = '1';

    /** The enumerated values for the RESSOURCE_VISIBLE field */
    const RESSOURCE_VISIBLE_0 = '0';
    const RESSOURCE_VISIBLE_1 = '1';

    /** The enumerated values for the RESSOURCE_OBLIGATOIRE field */
    const RESSOURCE_OBLIGATOIRE_0 = '0';
    const RESSOURCE_OBLIGATOIRE_1 = '1';

    /** The enumerated values for the REFERENT_VISIBLE field */
    const REFERENT_VISIBLE_0 = '0';
    const REFERENT_VISIBLE_1 = '1';

    /** The enumerated values for the VISIOCONFERENCE field */
    const VISIOCONFERENCE_0 = '0';
    const VISIOCONFERENCE_1 = '1';

    /** The enumerated values for the RDV_GROUPE field */
    const RDV_GROUPE_0 = '0';
    const RDV_GROUPE_1 = '1';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identiy map to hold any loaded instances of TPrestation objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array TPrestation[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. TPrestationPeer::$fieldNames[TPrestationPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('IdPrestation', 'IdRefPrestation', 'CodeLibellePrestation', 'IdTypePrestation', 'RdvSimilaire', 'NbJourRdvSimilaire', 'DelaiMin', 'Periodicite', 'RessourceVisible', 'RessourceObligatoire', 'IdParametreForm', 'CodeCommentaire', 'ReferentVisible', 'IdParametragePrestation', 'IdChampsSupp1', 'IdChampsSupp2', 'IdChampsSupp3', 'Visioconference', 'RdvGroupe', 'NombreMaxParticipants', 'TypeSession', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idPrestation', 'idRefPrestation', 'codeLibellePrestation', 'idTypePrestation', 'rdvSimilaire', 'nbJourRdvSimilaire', 'delaiMin', 'periodicite', 'ressourceVisible', 'ressourceObligatoire', 'idParametreForm', 'codeCommentaire', 'referentVisible', 'idParametragePrestation', 'idChampsSupp1', 'idChampsSupp2', 'idChampsSupp3', 'visioconference', 'rdvGroupe', 'nombreMaxParticipants', 'typeSession', ),
        BasePeer::TYPE_COLNAME => array (TPrestationPeer::ID_PRESTATION, TPrestationPeer::ID_REF_PRESTATION, TPrestationPeer::CODE_LIBELLE_PRESTATION, TPrestationPeer::ID_TYPE_PRESTATION, TPrestationPeer::RDV_SIMILAIRE, TPrestationPeer::NB_JOUR_RDV_SIMILAIRE, TPrestationPeer::DELAI_MIN, TPrestationPeer::PERIODICITE, TPrestationPeer::RESSOURCE_VISIBLE, TPrestationPeer::RESSOURCE_OBLIGATOIRE, TPrestationPeer::ID_PARAMETRE_FORM, TPrestationPeer::CODE_COMMENTAIRE, TPrestationPeer::REFERENT_VISIBLE, TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TPrestationPeer::ID_CHAMPS_SUPP_1, TPrestationPeer::ID_CHAMPS_SUPP_2, TPrestationPeer::ID_CHAMPS_SUPP_3, TPrestationPeer::VISIOCONFERENCE, TPrestationPeer::RDV_GROUPE, TPrestationPeer::NOMBRE_MAX_PARTICIPANTS, TPrestationPeer::TYPE_SESSION, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_PRESTATION', 'ID_REF_PRESTATION', 'CODE_LIBELLE_PRESTATION', 'ID_TYPE_PRESTATION', 'RDV_SIMILAIRE', 'NB_JOUR_RDV_SIMILAIRE', 'DELAI_MIN', 'PERIODICITE', 'RESSOURCE_VISIBLE', 'RESSOURCE_OBLIGATOIRE', 'ID_PARAMETRE_FORM', 'CODE_COMMENTAIRE', 'REFERENT_VISIBLE', 'ID_PARAMETRAGE_PRESTATION', 'ID_CHAMPS_SUPP_1', 'ID_CHAMPS_SUPP_2', 'ID_CHAMPS_SUPP_3', 'VISIOCONFERENCE', 'RDV_GROUPE', 'NOMBRE_MAX_PARTICIPANTS', 'TYPE_SESSION', ),
        BasePeer::TYPE_FIELDNAME => array ('ID_PRESTATION', 'ID_REF_PRESTATION', 'CODE_LIBELLE_PRESTATION', 'ID_TYPE_PRESTATION', 'RDV_SIMILAIRE', 'NB_JOUR_RDV_SIMILAIRE', 'DELAI_MIN', 'PERIODICITE', 'RESSOURCE_VISIBLE', 'RESSOURCE_OBLIGATOIRE', 'ID_PARAMETRE_FORM', 'CODE_COMMENTAIRE', 'REFERENT_VISIBLE', 'ID_PARAMETRAGE_PRESTATION', 'ID_CHAMPS_SUPP_1', 'ID_CHAMPS_SUPP_2', 'ID_CHAMPS_SUPP_3', 'VISIOCONFERENCE', 'RDV_GROUPE', 'NOMBRE_MAX_PARTICIPANTS', 'TYPE_SESSION', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. TPrestationPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('IdPrestation' => 0, 'IdRefPrestation' => 1, 'CodeLibellePrestation' => 2, 'IdTypePrestation' => 3, 'RdvSimilaire' => 4, 'NbJourRdvSimilaire' => 5, 'DelaiMin' => 6, 'Periodicite' => 7, 'RessourceVisible' => 8, 'RessourceObligatoire' => 9, 'IdParametreForm' => 10, 'CodeCommentaire' => 11, 'ReferentVisible' => 12, 'IdParametragePrestation' => 13, 'IdChampsSupp1' => 14, 'IdChampsSupp2' => 15, 'IdChampsSupp3' => 16, 'Visioconference' => 17, 'RdvGroupe' => 18, 'NombreMaxParticipants' => 19, 'TypeSession' => 20, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idPrestation' => 0, 'idRefPrestation' => 1, 'codeLibellePrestation' => 2, 'idTypePrestation' => 3, 'rdvSimilaire' => 4, 'nbJourRdvSimilaire' => 5, 'delaiMin' => 6, 'periodicite' => 7, 'ressourceVisible' => 8, 'ressourceObligatoire' => 9, 'idParametreForm' => 10, 'codeCommentaire' => 11, 'referentVisible' => 12, 'idParametragePrestation' => 13, 'idChampsSupp1' => 14, 'idChampsSupp2' => 15, 'idChampsSupp3' => 16, 'visioconference' => 17, 'rdvGroupe' => 18, 'nombreMaxParticipants' => 19, 'typeSession' => 20, ),
        BasePeer::TYPE_COLNAME => array (TPrestationPeer::ID_PRESTATION => 0, TPrestationPeer::ID_REF_PRESTATION => 1, TPrestationPeer::CODE_LIBELLE_PRESTATION => 2, TPrestationPeer::ID_TYPE_PRESTATION => 3, TPrestationPeer::RDV_SIMILAIRE => 4, TPrestationPeer::NB_JOUR_RDV_SIMILAIRE => 5, TPrestationPeer::DELAI_MIN => 6, TPrestationPeer::PERIODICITE => 7, TPrestationPeer::RESSOURCE_VISIBLE => 8, TPrestationPeer::RESSOURCE_OBLIGATOIRE => 9, TPrestationPeer::ID_PARAMETRE_FORM => 10, TPrestationPeer::CODE_COMMENTAIRE => 11, TPrestationPeer::REFERENT_VISIBLE => 12, TPrestationPeer::ID_PARAMETRAGE_PRESTATION => 13, TPrestationPeer::ID_CHAMPS_SUPP_1 => 14, TPrestationPeer::ID_CHAMPS_SUPP_2 => 15, TPrestationPeer::ID_CHAMPS_SUPP_3 => 16, TPrestationPeer::VISIOCONFERENCE => 17, TPrestationPeer::RDV_GROUPE => 18, TPrestationPeer::NOMBRE_MAX_PARTICIPANTS => 19, TPrestationPeer::TYPE_SESSION => 20, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_PRESTATION' => 0, 'ID_REF_PRESTATION' => 1, 'CODE_LIBELLE_PRESTATION' => 2, 'ID_TYPE_PRESTATION' => 3, 'RDV_SIMILAIRE' => 4, 'NB_JOUR_RDV_SIMILAIRE' => 5, 'DELAI_MIN' => 6, 'PERIODICITE' => 7, 'RESSOURCE_VISIBLE' => 8, 'RESSOURCE_OBLIGATOIRE' => 9, 'ID_PARAMETRE_FORM' => 10, 'CODE_COMMENTAIRE' => 11, 'REFERENT_VISIBLE' => 12, 'ID_PARAMETRAGE_PRESTATION' => 13, 'ID_CHAMPS_SUPP_1' => 14, 'ID_CHAMPS_SUPP_2' => 15, 'ID_CHAMPS_SUPP_3' => 16, 'VISIOCONFERENCE' => 17, 'RDV_GROUPE' => 18, 'NOMBRE_MAX_PARTICIPANTS' => 19, 'TYPE_SESSION' => 20, ),
        BasePeer::TYPE_FIELDNAME => array ('ID_PRESTATION' => 0, 'ID_REF_PRESTATION' => 1, 'CODE_LIBELLE_PRESTATION' => 2, 'ID_TYPE_PRESTATION' => 3, 'RDV_SIMILAIRE' => 4, 'NB_JOUR_RDV_SIMILAIRE' => 5, 'DELAI_MIN' => 6, 'PERIODICITE' => 7, 'RESSOURCE_VISIBLE' => 8, 'RESSOURCE_OBLIGATOIRE' => 9, 'ID_PARAMETRE_FORM' => 10, 'CODE_COMMENTAIRE' => 11, 'REFERENT_VISIBLE' => 12, 'ID_PARAMETRAGE_PRESTATION' => 13, 'ID_CHAMPS_SUPP_1' => 14, 'ID_CHAMPS_SUPP_2' => 15, 'ID_CHAMPS_SUPP_3' => 16, 'VISIOCONFERENCE' => 17, 'RDV_GROUPE' => 18, 'NOMBRE_MAX_PARTICIPANTS' => 19, 'TYPE_SESSION' => 20, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, )
    );

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
        TPrestationPeer::RDV_SIMILAIRE => array(
            TPrestationPeer::RDV_SIMILAIRE_0,
            TPrestationPeer::RDV_SIMILAIRE_1,
        ),
        TPrestationPeer::RESSOURCE_VISIBLE => array(
            TPrestationPeer::RESSOURCE_VISIBLE_0,
            TPrestationPeer::RESSOURCE_VISIBLE_1,
        ),
        TPrestationPeer::RESSOURCE_OBLIGATOIRE => array(
            TPrestationPeer::RESSOURCE_OBLIGATOIRE_0,
            TPrestationPeer::RESSOURCE_OBLIGATOIRE_1,
        ),
        TPrestationPeer::REFERENT_VISIBLE => array(
            TPrestationPeer::REFERENT_VISIBLE_0,
            TPrestationPeer::REFERENT_VISIBLE_1,
        ),
        TPrestationPeer::VISIOCONFERENCE => array(
            TPrestationPeer::VISIOCONFERENCE_0,
            TPrestationPeer::VISIOCONFERENCE_1,
        ),
        TPrestationPeer::RDV_GROUPE => array(
            TPrestationPeer::RDV_GROUPE_0,
            TPrestationPeer::RDV_GROUPE_1,
        ),
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = TPrestationPeer::getFieldNames($toType);
        $key = isset(TPrestationPeer::$fieldKeys[$fromType][$name]) ? TPrestationPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(TPrestationPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, TPrestationPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return TPrestationPeer::$fieldNames[$type];
    }

    /**
     * Gets the list of values for all ENUM columns
     * @return array
     */
    public static function getValueSets()
    {
      return TPrestationPeer::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM column
     *
     * @param string $colname The ENUM column name.
     *
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = TPrestationPeer::getValueSets();

        if (!isset($valueSets[$colname])) {
            throw new PropelException(sprintf('Column "%s" has no ValueSet.', $colname));
        }

        return $valueSets[$colname];
    }

    /**
     * Gets the SQL value for the ENUM column value
     *
     * @param string $colname ENUM column name.
     * @param string $enumVal ENUM value.
     *
     * @return int            SQL value
     */
    public static function getSqlValueForEnum($colname, $enumVal)
    {
        $values = TPrestationPeer::getValueSet($colname);
        if (!in_array($enumVal, $values)) {
            throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $colname));
        }
        return array_search($enumVal, $values);
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. TPrestationPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(TPrestationPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(TPrestationPeer::ID_PRESTATION);
            $criteria->addSelectColumn(TPrestationPeer::ID_REF_PRESTATION);
            $criteria->addSelectColumn(TPrestationPeer::CODE_LIBELLE_PRESTATION);
            $criteria->addSelectColumn(TPrestationPeer::ID_TYPE_PRESTATION);
            $criteria->addSelectColumn(TPrestationPeer::RDV_SIMILAIRE);
            $criteria->addSelectColumn(TPrestationPeer::NB_JOUR_RDV_SIMILAIRE);
            $criteria->addSelectColumn(TPrestationPeer::DELAI_MIN);
            $criteria->addSelectColumn(TPrestationPeer::PERIODICITE);
            $criteria->addSelectColumn(TPrestationPeer::RESSOURCE_VISIBLE);
            $criteria->addSelectColumn(TPrestationPeer::RESSOURCE_OBLIGATOIRE);
            $criteria->addSelectColumn(TPrestationPeer::ID_PARAMETRE_FORM);
            $criteria->addSelectColumn(TPrestationPeer::CODE_COMMENTAIRE);
            $criteria->addSelectColumn(TPrestationPeer::REFERENT_VISIBLE);
            $criteria->addSelectColumn(TPrestationPeer::ID_PARAMETRAGE_PRESTATION);
            $criteria->addSelectColumn(TPrestationPeer::ID_CHAMPS_SUPP_1);
            $criteria->addSelectColumn(TPrestationPeer::ID_CHAMPS_SUPP_2);
            $criteria->addSelectColumn(TPrestationPeer::ID_CHAMPS_SUPP_3);
            $criteria->addSelectColumn(TPrestationPeer::VISIOCONFERENCE);
            $criteria->addSelectColumn(TPrestationPeer::RDV_GROUPE);
            $criteria->addSelectColumn(TPrestationPeer::NOMBRE_MAX_PARTICIPANTS);
            $criteria->addSelectColumn(TPrestationPeer::TYPE_SESSION);
        } else {
            $criteria->addSelectColumn($alias . '.ID_PRESTATION');
            $criteria->addSelectColumn($alias . '.ID_REF_PRESTATION');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_PRESTATION');
            $criteria->addSelectColumn($alias . '.ID_TYPE_PRESTATION');
            $criteria->addSelectColumn($alias . '.RDV_SIMILAIRE');
            $criteria->addSelectColumn($alias . '.NB_JOUR_RDV_SIMILAIRE');
            $criteria->addSelectColumn($alias . '.DELAI_MIN');
            $criteria->addSelectColumn($alias . '.PERIODICITE');
            $criteria->addSelectColumn($alias . '.RESSOURCE_VISIBLE');
            $criteria->addSelectColumn($alias . '.RESSOURCE_OBLIGATOIRE');
            $criteria->addSelectColumn($alias . '.ID_PARAMETRE_FORM');
            $criteria->addSelectColumn($alias . '.CODE_COMMENTAIRE');
            $criteria->addSelectColumn($alias . '.REFERENT_VISIBLE');
            $criteria->addSelectColumn($alias . '.ID_PARAMETRAGE_PRESTATION');
            $criteria->addSelectColumn($alias . '.ID_CHAMPS_SUPP_1');
            $criteria->addSelectColumn($alias . '.ID_CHAMPS_SUPP_2');
            $criteria->addSelectColumn($alias . '.ID_CHAMPS_SUPP_3');
            $criteria->addSelectColumn($alias . '.VISIOCONFERENCE');
            $criteria->addSelectColumn($alias . '.RDV_GROUPE');
            $criteria->addSelectColumn($alias . '.NOMBRE_MAX_PARTICIPANTS');
            $criteria->addSelectColumn($alias . '.TYPE_SESSION');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return                 TPrestation
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = TPrestationPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return TPrestationPeer::populateObjects(TPrestationPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            TPrestationPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param      TPrestation $obj A TPrestation object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getIdPrestation();
            } // if key === null
            TPrestationPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A TPrestation object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof TPrestation) {
                $key = (string) $value->getIdPrestation();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or TPrestation object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(TPrestationPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return   TPrestation Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(TPrestationPeer::$instances[$key])) {
                return TPrestationPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references)
      {
        foreach (TPrestationPeer::$instances as $instance)
        {
          $instance->clearAllReferences(true);
        }
      }
        TPrestationPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to T_PRESTATION
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = TPrestationPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = TPrestationPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                TPrestationPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (TPrestation object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = TPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = TPrestationPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + TPrestationPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = TPrestationPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            TPrestationPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeCommentaire table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeCommentaire(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibellePrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibellePrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TParametragePrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTParametragePrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TParametreForm table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTParametreForm(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TRefPrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTRefPrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTypePrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTypePrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TChampsSuppRelatedByIdChampsSupp1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTChampsSuppRelatedByIdChampsSupp1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TChampsSuppRelatedByIdChampsSupp2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTChampsSuppRelatedByIdChampsSupp2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TChampsSuppRelatedByIdChampsSupp3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTChampsSuppRelatedByIdChampsSupp3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeCommentaire(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibellePrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TParametragePrestation objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTParametragePrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TParametragePrestationPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TParametragePrestationPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TParametragePrestationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TParametragePrestationPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TParametragePrestation)
                $obj2->addTPrestation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TParametreForm objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTParametreForm(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TParametreFormPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TParametreFormPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TParametreFormPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TParametreFormPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TParametreForm)
                $obj2->addTPrestation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TRefPrestation objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTRefPrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TRefPrestationPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TRefPrestationPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TRefPrestationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TRefPrestationPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TRefPrestation)
                $obj2->addTPrestation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TTypePrestation objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTypePrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TTypePrestationPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTypePrestationPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTypePrestationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTypePrestationPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TTypePrestation)
                $obj2->addTPrestation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TChampsSupp objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTChampsSuppRelatedByIdChampsSupp1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TChampsSuppPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TChampsSuppPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TChampsSuppPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TChampsSuppPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TChampsSupp)
                $obj2->addTPrestationRelatedByIdChampsSupp1($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TChampsSupp objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTChampsSuppRelatedByIdChampsSupp2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TChampsSuppPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TChampsSuppPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TChampsSuppPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TChampsSuppPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TChampsSupp)
                $obj2->addTPrestationRelatedByIdChampsSupp2($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with their TChampsSupp objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTChampsSuppRelatedByIdChampsSupp3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol = TPrestationPeer::NUM_HYDRATE_COLUMNS;
        TChampsSuppPeer::addSelectColumns($criteria);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TChampsSuppPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TChampsSuppPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TChampsSuppPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TPrestation) to $obj2 (TChampsSupp)
                $obj2->addTPrestationRelatedByIdChampsSupp3($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined TTraduction rows

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);
            } // if joined row not null

            // Add objects for joined TParametragePrestation rows

            $key4 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = TParametragePrestationPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = TParametragePrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametragePrestationPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametragePrestation)
                $obj4->addTPrestation($obj1);
            } // if joined row not null

            // Add objects for joined TParametreForm rows

            $key5 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol5);
            if ($key5 !== null) {
                $obj5 = TParametreFormPeer::getInstanceFromPool($key5);
                if (!$obj5) {

                    $cls = TParametreFormPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TParametreFormPeer::addInstanceToPool($obj5, $key5);
                } // if obj5 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TParametreForm)
                $obj5->addTPrestation($obj1);
            } // if joined row not null

            // Add objects for joined TRefPrestation rows

            $key6 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
            if ($key6 !== null) {
                $obj6 = TRefPrestationPeer::getInstanceFromPool($key6);
                if (!$obj6) {

                    $cls = TRefPrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TRefPrestationPeer::addInstanceToPool($obj6, $key6);
                } // if obj6 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TRefPrestation)
                $obj6->addTPrestation($obj1);
            } // if joined row not null

            // Add objects for joined TTypePrestation rows

            $key7 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol7);
            if ($key7 !== null) {
                $obj7 = TTypePrestationPeer::getInstanceFromPool($key7);
                if (!$obj7) {

                    $cls = TTypePrestationPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTypePrestationPeer::addInstanceToPool($obj7, $key7);
                } // if obj7 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TTypePrestation)
                $obj7->addTPrestation($obj1);
            } // if joined row not null

            // Add objects for joined TChampsSupp rows

            $key8 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol8);
            if ($key8 !== null) {
                $obj8 = TChampsSuppPeer::getInstanceFromPool($key8);
                if (!$obj8) {

                    $cls = TChampsSuppPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TChampsSuppPeer::addInstanceToPool($obj8, $key8);
                } // if obj8 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj8 (TChampsSupp)
                $obj8->addTPrestationRelatedByIdChampsSupp1($obj1);
            } // if joined row not null

            // Add objects for joined TChampsSupp rows

            $key9 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol9);
            if ($key9 !== null) {
                $obj9 = TChampsSuppPeer::getInstanceFromPool($key9);
                if (!$obj9) {

                    $cls = TChampsSuppPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TChampsSuppPeer::addInstanceToPool($obj9, $key9);
                } // if obj9 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj9 (TChampsSupp)
                $obj9->addTPrestationRelatedByIdChampsSupp2($obj1);
            } // if joined row not null

            // Add objects for joined TChampsSupp rows

            $key10 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol10);
            if ($key10 !== null) {
                $obj10 = TChampsSuppPeer::getInstanceFromPool($key10);
                if (!$obj10) {

                    $cls = TChampsSuppPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TChampsSuppPeer::addInstanceToPool($obj10, $key10);
                } // if obj10 loaded

                // Add the $obj1 (TPrestation) to the collection in $obj10 (TChampsSupp)
                $obj10->addTPrestationRelatedByIdChampsSupp3($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeCommentaire table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeCommentaire(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibellePrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibellePrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TParametragePrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTParametragePrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TParametreForm table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTParametreForm(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TRefPrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTRefPrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTypePrestation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTypePrestation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TChampsSuppRelatedByIdChampsSupp1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTChampsSuppRelatedByIdChampsSupp1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TChampsSuppRelatedByIdChampsSupp2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTChampsSuppRelatedByIdChampsSupp2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TChampsSuppRelatedByIdChampsSupp3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTChampsSuppRelatedByIdChampsSupp3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TPrestationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TTraductionRelatedByCodeCommentaire.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeCommentaire(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TParametragePrestation rows

                $key2 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TParametragePrestationPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TParametragePrestationPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TParametragePrestation)
                $obj2->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TParametreForm)
                $obj3->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key4 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TRefPrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TRefPrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TRefPrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key5 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TTypePrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTypePrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TTypePrestation)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key6 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TChampsSuppPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TChampsSuppPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TChampsSupp)
                $obj6->addTPrestationRelatedByIdChampsSupp1($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key7 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TChampsSuppPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TChampsSuppPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TChampsSupp)
                $obj7->addTPrestationRelatedByIdChampsSupp2($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key8 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TChampsSuppPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TChampsSuppPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj8 (TChampsSupp)
                $obj8->addTPrestationRelatedByIdChampsSupp3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TTraductionRelatedByCodeLibellePrestation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibellePrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TParametragePrestation rows

                $key2 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TParametragePrestationPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TParametragePrestationPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TParametragePrestation)
                $obj2->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TParametreForm)
                $obj3->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key4 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TRefPrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TRefPrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TRefPrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key5 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TTypePrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTypePrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TTypePrestation)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key6 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TChampsSuppPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TChampsSuppPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TChampsSupp)
                $obj6->addTPrestationRelatedByIdChampsSupp1($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key7 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TChampsSuppPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TChampsSuppPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TChampsSupp)
                $obj7->addTPrestationRelatedByIdChampsSupp2($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key8 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TChampsSuppPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TChampsSuppPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj8 (TChampsSupp)
                $obj8->addTPrestationRelatedByIdChampsSupp3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TParametragePrestation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTParametragePrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key4 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TParametreFormPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametreFormPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametreForm)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key5 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TRefPrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TRefPrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TRefPrestation)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key6 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTypePrestationPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTypePrestationPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TTypePrestation)
                $obj6->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key7 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TChampsSuppPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TChampsSuppPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TChampsSupp)
                $obj7->addTPrestationRelatedByIdChampsSupp1($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key8 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TChampsSuppPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TChampsSuppPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj8 (TChampsSupp)
                $obj8->addTPrestationRelatedByIdChampsSupp2($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key9 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TChampsSuppPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TChampsSuppPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj9 (TChampsSupp)
                $obj9->addTPrestationRelatedByIdChampsSupp3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TParametreForm.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTParametreForm(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametragePrestation rows

                $key4 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TParametragePrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametragePrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametragePrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key5 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TRefPrestationPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TRefPrestationPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TRefPrestation)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key6 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTypePrestationPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTypePrestationPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TTypePrestation)
                $obj6->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key7 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TChampsSuppPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TChampsSuppPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TChampsSupp)
                $obj7->addTPrestationRelatedByIdChampsSupp1($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key8 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TChampsSuppPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TChampsSuppPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj8 (TChampsSupp)
                $obj8->addTPrestationRelatedByIdChampsSupp2($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key9 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TChampsSuppPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TChampsSuppPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj9 (TChampsSupp)
                $obj9->addTPrestationRelatedByIdChampsSupp3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TRefPrestation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTRefPrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametragePrestation rows

                $key4 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TParametragePrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametragePrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametragePrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key5 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TParametreFormPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TParametreFormPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TParametreForm)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key6 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTypePrestationPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTypePrestationPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TTypePrestation)
                $obj6->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key7 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TChampsSuppPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TChampsSuppPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TChampsSupp)
                $obj7->addTPrestationRelatedByIdChampsSupp1($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key8 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TChampsSuppPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TChampsSuppPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj8 (TChampsSupp)
                $obj8->addTPrestationRelatedByIdChampsSupp2($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key9 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TChampsSuppPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TChampsSuppPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj9 (TChampsSupp)
                $obj9->addTPrestationRelatedByIdChampsSupp3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TTypePrestation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTypePrestation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        TChampsSuppPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TChampsSuppPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_1, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_2, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_CHAMPS_SUPP_3, TChampsSuppPeer::ID_CHAMPS_SUPP, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametragePrestation rows

                $key4 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TParametragePrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametragePrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametragePrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key5 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TParametreFormPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TParametreFormPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TParametreForm)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key6 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TRefPrestationPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TRefPrestationPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TRefPrestation)
                $obj6->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key7 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TChampsSuppPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TChampsSuppPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TChampsSupp)
                $obj7->addTPrestationRelatedByIdChampsSupp1($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key8 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TChampsSuppPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TChampsSuppPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj8 (TChampsSupp)
                $obj8->addTPrestationRelatedByIdChampsSupp2($obj1);

            } // if joined row is not null

                // Add objects for joined TChampsSupp rows

                $key9 = TChampsSuppPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TChampsSuppPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TChampsSuppPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TChampsSuppPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj9 (TChampsSupp)
                $obj9->addTPrestationRelatedByIdChampsSupp3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TChampsSuppRelatedByIdChampsSupp1.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTChampsSuppRelatedByIdChampsSupp1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametragePrestation rows

                $key4 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TParametragePrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametragePrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametragePrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key5 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TParametreFormPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TParametreFormPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TParametreForm)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key6 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TRefPrestationPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TRefPrestationPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TRefPrestation)
                $obj6->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key7 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTypePrestationPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTypePrestationPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TTypePrestation)
                $obj7->addTPrestation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TChampsSuppRelatedByIdChampsSupp2.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTChampsSuppRelatedByIdChampsSupp2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametragePrestation rows

                $key4 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TParametragePrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametragePrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametragePrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key5 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TParametreFormPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TParametreFormPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TParametreForm)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key6 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TRefPrestationPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TRefPrestationPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TRefPrestation)
                $obj6->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key7 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTypePrestationPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTypePrestationPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TTypePrestation)
                $obj7->addTPrestation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TPrestation objects pre-filled with all related objects except TChampsSuppRelatedByIdChampsSupp3.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TPrestation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTChampsSuppRelatedByIdChampsSupp3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TPrestationPeer::DATABASE_NAME);
        }

        TPrestationPeer::addSelectColumns($criteria);
        $startcol2 = TPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametragePrestationPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TParametragePrestationPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TRefPrestationPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TRefPrestationPeer::NUM_HYDRATE_COLUMNS;

        TTypePrestationPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTypePrestationPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TPrestationPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::CODE_LIBELLE_PRESTATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_REF_PRESTATION, TRefPrestationPeer::ID_REF_PRESTATION, $join_behavior);

        $criteria->addJoin(TPrestationPeer::ID_TYPE_PRESTATION, TTypePrestationPeer::ID_TYPE_PRESTATION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TPrestationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TPrestationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TPrestationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TPrestationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj2 (TTraduction)
                $obj2->addTPrestationRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj3 (TTraduction)
                $obj3->addTPrestationRelatedByCodeLibellePrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametragePrestation rows

                $key4 = TParametragePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TParametragePrestationPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TParametragePrestationPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TParametragePrestationPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj4 (TParametragePrestation)
                $obj4->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key5 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TParametreFormPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TParametreFormPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj5 (TParametreForm)
                $obj5->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TRefPrestation rows

                $key6 = TRefPrestationPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TRefPrestationPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TRefPrestationPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TRefPrestationPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj6 (TRefPrestation)
                $obj6->addTPrestation($obj1);

            } // if joined row is not null

                // Add objects for joined TTypePrestation rows

                $key7 = TTypePrestationPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTypePrestationPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTypePrestationPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTypePrestationPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TPrestation) to the collection in $obj7 (TTypePrestation)
                $obj7->addTPrestation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(TPrestationPeer::DATABASE_NAME)->getTable(TPrestationPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseTPrestationPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseTPrestationPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new TPrestationTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return TPrestationPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a TPrestation or Criteria object.
     *
     * @param      mixed $values Criteria or TPrestation object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from TPrestation object
        }

        if ($criteria->containsKey(TPrestationPeer::ID_PRESTATION) && $criteria->keyContainsValue(TPrestationPeer::ID_PRESTATION) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.TPrestationPeer::ID_PRESTATION.')');
        }


        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a TPrestation or Criteria object.
     *
     * @param      mixed $values Criteria or TPrestation object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(TPrestationPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(TPrestationPeer::ID_PRESTATION);
            $value = $criteria->remove(TPrestationPeer::ID_PRESTATION);
            if ($value) {
                $selectCriteria->add(TPrestationPeer::ID_PRESTATION, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(TPrestationPeer::TABLE_NAME);
            }

        } else { // $values is TPrestation object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the T_PRESTATION table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(TPrestationPeer::TABLE_NAME, $con, TPrestationPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            TPrestationPeer::clearInstancePool();
            TPrestationPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a TPrestation or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or TPrestation object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            TPrestationPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof TPrestation) { // it's a model object
            // invalidate the cache for this single object
            TPrestationPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(TPrestationPeer::DATABASE_NAME);
            $criteria->add(TPrestationPeer::ID_PRESTATION, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                TPrestationPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(TPrestationPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            TPrestationPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given TPrestation object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param      TPrestation $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(TPrestationPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(TPrestationPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(TPrestationPeer::DATABASE_NAME, TPrestationPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param      int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return TPrestation
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = TPrestationPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(TPrestationPeer::DATABASE_NAME);
        $criteria->add(TPrestationPeer::ID_PRESTATION, $pk);

        $v = TPrestationPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return TPrestation[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(TPrestationPeer::DATABASE_NAME);
            $criteria->add(TPrestationPeer::ID_PRESTATION, $pks, Criteria::IN);
            $objs = TPrestationPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseTPrestationPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseTPrestationPeer::buildTableMap();

