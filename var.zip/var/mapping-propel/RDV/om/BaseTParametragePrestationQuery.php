<?php


/**
 * Base class that represents a query for the 'T_PARAMETRAGE_PRESTATION' table.
 *
 *
 *
 * @method TParametragePrestationQuery orderByIdParametragePrestation($order = Criteria::ASC) Order by the ID_PARAMETRAGE_PRESTATION column
 * @method TParametragePrestationQuery orderByIdOrganisation($order = Criteria::ASC) Order by the ID_ORGANISATION column
 * @method TParametragePrestationQuery orderByIdRefTypePrestation($order = Criteria::ASC) Order by the ID_REF_TYPE_PRESTATION column
 * @method TParametragePrestationQuery orderByIdRefPrestation($order = Criteria::ASC) Order by the ID_REF_PRESTATION column
 * @method TParametragePrestationQuery orderByRdvSimilaire($order = Criteria::ASC) Order by the RDV_SIMILAIRE column
 * @method TParametragePrestationQuery orderByNbJourRdvSimilaire($order = Criteria::ASC) Order by the NB_JOUR_RDV_SIMILAIRE column
 * @method TParametragePrestationQuery orderByDelaiMin($order = Criteria::ASC) Order by the DELAI_MIN column
 * @method TParametragePrestationQuery orderByPeriodicite($order = Criteria::ASC) Order by the PERIODICITE column
 * @method TParametragePrestationQuery orderByRessourceVisible($order = Criteria::ASC) Order by the RESSOURCE_VISIBLE column
 * @method TParametragePrestationQuery orderByRessourceObligatoire($order = Criteria::ASC) Order by the RESSOURCE_OBLIGATOIRE column
 * @method TParametragePrestationQuery orderByIdParametreForm($order = Criteria::ASC) Order by the ID_PARAMETRE_FORM column
 * @method TParametragePrestationQuery orderByCodeCommentaire($order = Criteria::ASC) Order by the CODE_COMMENTAIRE column
 * @method TParametragePrestationQuery orderByReferentVisible($order = Criteria::ASC) Order by the REFERENT_VISIBLE column
 * @method TParametragePrestationQuery orderByCodeAide($order = Criteria::ASC) Order by the CODE_AIDE column
 *
 * @method TParametragePrestationQuery groupByIdParametragePrestation() Group by the ID_PARAMETRAGE_PRESTATION column
 * @method TParametragePrestationQuery groupByIdOrganisation() Group by the ID_ORGANISATION column
 * @method TParametragePrestationQuery groupByIdRefTypePrestation() Group by the ID_REF_TYPE_PRESTATION column
 * @method TParametragePrestationQuery groupByIdRefPrestation() Group by the ID_REF_PRESTATION column
 * @method TParametragePrestationQuery groupByRdvSimilaire() Group by the RDV_SIMILAIRE column
 * @method TParametragePrestationQuery groupByNbJourRdvSimilaire() Group by the NB_JOUR_RDV_SIMILAIRE column
 * @method TParametragePrestationQuery groupByDelaiMin() Group by the DELAI_MIN column
 * @method TParametragePrestationQuery groupByPeriodicite() Group by the PERIODICITE column
 * @method TParametragePrestationQuery groupByRessourceVisible() Group by the RESSOURCE_VISIBLE column
 * @method TParametragePrestationQuery groupByRessourceObligatoire() Group by the RESSOURCE_OBLIGATOIRE column
 * @method TParametragePrestationQuery groupByIdParametreForm() Group by the ID_PARAMETRE_FORM column
 * @method TParametragePrestationQuery groupByCodeCommentaire() Group by the CODE_COMMENTAIRE column
 * @method TParametragePrestationQuery groupByReferentVisible() Group by the REFERENT_VISIBLE column
 * @method TParametragePrestationQuery groupByCodeAide() Group by the CODE_AIDE column
 *
 * @method TParametragePrestationQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TParametragePrestationQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TParametragePrestationQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TParametragePrestationQuery leftJoinTTraductionRelatedByCodeAide($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeAide relation
 * @method TParametragePrestationQuery rightJoinTTraductionRelatedByCodeAide($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeAide relation
 * @method TParametragePrestationQuery innerJoinTTraductionRelatedByCodeAide($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeAide relation
 *
 * @method TParametragePrestationQuery leftJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 * @method TParametragePrestationQuery rightJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 * @method TParametragePrestationQuery innerJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 *
 * @method TParametragePrestationQuery leftJoinTOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisation relation
 * @method TParametragePrestationQuery rightJoinTOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisation relation
 * @method TParametragePrestationQuery innerJoinTOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisation relation
 *
 * @method TParametragePrestationQuery leftJoinTParametreForm($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreForm relation
 * @method TParametragePrestationQuery rightJoinTParametreForm($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreForm relation
 * @method TParametragePrestationQuery innerJoinTParametreForm($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreForm relation
 *
 * @method TParametragePrestationQuery leftJoinTRefPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefPrestation relation
 * @method TParametragePrestationQuery rightJoinTRefPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefPrestation relation
 * @method TParametragePrestationQuery innerJoinTRefPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefPrestation relation
 *
 * @method TParametragePrestationQuery leftJoinTRefTypePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefTypePrestation relation
 * @method TParametragePrestationQuery rightJoinTRefTypePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefTypePrestation relation
 * @method TParametragePrestationQuery innerJoinTRefTypePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefTypePrestation relation
 *
 * @method TParametragePrestationQuery leftJoinTPieceParamPresta($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPieceParamPresta relation
 * @method TParametragePrestationQuery rightJoinTPieceParamPresta($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPieceParamPresta relation
 * @method TParametragePrestationQuery innerJoinTPieceParamPresta($relationAlias = null) Adds a INNER JOIN clause to the query using the TPieceParamPresta relation
 *
 * @method TParametragePrestationQuery leftJoinTPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestation relation
 * @method TParametragePrestationQuery rightJoinTPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestation relation
 * @method TParametragePrestationQuery innerJoinTPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestation relation
 *
 * @method TParametragePrestation findOne(PropelPDO $con = null) Return the first TParametragePrestation matching the query
 * @method TParametragePrestation findOneOrCreate(PropelPDO $con = null) Return the first TParametragePrestation matching the query, or a new TParametragePrestation object populated from the query conditions when no match is found
 *
 * @method TParametragePrestation findOneByIdOrganisation(int $ID_ORGANISATION) Return the first TParametragePrestation filtered by the ID_ORGANISATION column
 * @method TParametragePrestation findOneByIdRefTypePrestation(int $ID_REF_TYPE_PRESTATION) Return the first TParametragePrestation filtered by the ID_REF_TYPE_PRESTATION column
 * @method TParametragePrestation findOneByIdRefPrestation(int $ID_REF_PRESTATION) Return the first TParametragePrestation filtered by the ID_REF_PRESTATION column
 * @method TParametragePrestation findOneByRdvSimilaire(string $RDV_SIMILAIRE) Return the first TParametragePrestation filtered by the RDV_SIMILAIRE column
 * @method TParametragePrestation findOneByNbJourRdvSimilaire(int $NB_JOUR_RDV_SIMILAIRE) Return the first TParametragePrestation filtered by the NB_JOUR_RDV_SIMILAIRE column
 * @method TParametragePrestation findOneByDelaiMin(int $DELAI_MIN) Return the first TParametragePrestation filtered by the DELAI_MIN column
 * @method TParametragePrestation findOneByPeriodicite(int $PERIODICITE) Return the first TParametragePrestation filtered by the PERIODICITE column
 * @method TParametragePrestation findOneByRessourceVisible(string $RESSOURCE_VISIBLE) Return the first TParametragePrestation filtered by the RESSOURCE_VISIBLE column
 * @method TParametragePrestation findOneByRessourceObligatoire(string $RESSOURCE_OBLIGATOIRE) Return the first TParametragePrestation filtered by the RESSOURCE_OBLIGATOIRE column
 * @method TParametragePrestation findOneByIdParametreForm(int $ID_PARAMETRE_FORM) Return the first TParametragePrestation filtered by the ID_PARAMETRE_FORM column
 * @method TParametragePrestation findOneByCodeCommentaire(int $CODE_COMMENTAIRE) Return the first TParametragePrestation filtered by the CODE_COMMENTAIRE column
 * @method TParametragePrestation findOneByReferentVisible(string $REFERENT_VISIBLE) Return the first TParametragePrestation filtered by the REFERENT_VISIBLE column
 * @method TParametragePrestation findOneByCodeAide(int $CODE_AIDE) Return the first TParametragePrestation filtered by the CODE_AIDE column
 *
 * @method array findByIdParametragePrestation(int $ID_PARAMETRAGE_PRESTATION) Return TParametragePrestation objects filtered by the ID_PARAMETRAGE_PRESTATION column
 * @method array findByIdOrganisation(int $ID_ORGANISATION) Return TParametragePrestation objects filtered by the ID_ORGANISATION column
 * @method array findByIdRefTypePrestation(int $ID_REF_TYPE_PRESTATION) Return TParametragePrestation objects filtered by the ID_REF_TYPE_PRESTATION column
 * @method array findByIdRefPrestation(int $ID_REF_PRESTATION) Return TParametragePrestation objects filtered by the ID_REF_PRESTATION column
 * @method array findByRdvSimilaire(string $RDV_SIMILAIRE) Return TParametragePrestation objects filtered by the RDV_SIMILAIRE column
 * @method array findByNbJourRdvSimilaire(int $NB_JOUR_RDV_SIMILAIRE) Return TParametragePrestation objects filtered by the NB_JOUR_RDV_SIMILAIRE column
 * @method array findByDelaiMin(int $DELAI_MIN) Return TParametragePrestation objects filtered by the DELAI_MIN column
 * @method array findByPeriodicite(int $PERIODICITE) Return TParametragePrestation objects filtered by the PERIODICITE column
 * @method array findByRessourceVisible(string $RESSOURCE_VISIBLE) Return TParametragePrestation objects filtered by the RESSOURCE_VISIBLE column
 * @method array findByRessourceObligatoire(string $RESSOURCE_OBLIGATOIRE) Return TParametragePrestation objects filtered by the RESSOURCE_OBLIGATOIRE column
 * @method array findByIdParametreForm(int $ID_PARAMETRE_FORM) Return TParametragePrestation objects filtered by the ID_PARAMETRE_FORM column
 * @method array findByCodeCommentaire(int $CODE_COMMENTAIRE) Return TParametragePrestation objects filtered by the CODE_COMMENTAIRE column
 * @method array findByReferentVisible(string $REFERENT_VISIBLE) Return TParametragePrestation objects filtered by the REFERENT_VISIBLE column
 * @method array findByCodeAide(int $CODE_AIDE) Return TParametragePrestation objects filtered by the CODE_AIDE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTParametragePrestationQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTParametragePrestationQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TParametragePrestation', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TParametragePrestationQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TParametragePrestationQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TParametragePrestationQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TParametragePrestationQuery) {
            return $criteria;
        }
        $query = new TParametragePrestationQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TParametragePrestation|TParametragePrestation[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TParametragePrestationPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TParametragePrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TParametragePrestation A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdParametragePrestation($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TParametragePrestation A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PARAMETRAGE_PRESTATION`, `ID_ORGANISATION`, `ID_REF_TYPE_PRESTATION`, `ID_REF_PRESTATION`, `RDV_SIMILAIRE`, `NB_JOUR_RDV_SIMILAIRE`, `DELAI_MIN`, `PERIODICITE`, `RESSOURCE_VISIBLE`, `RESSOURCE_OBLIGATOIRE`, `ID_PARAMETRE_FORM`, `CODE_COMMENTAIRE`, `REFERENT_VISIBLE`, `CODE_AIDE` FROM `T_PARAMETRAGE_PRESTATION` WHERE `ID_PARAMETRAGE_PRESTATION` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TParametragePrestation();
            $obj->hydrate($row);
            TParametragePrestationPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TParametragePrestation|TParametragePrestation[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TParametragePrestation[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PARAMETRAGE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametragePrestation(1234); // WHERE ID_PARAMETRAGE_PRESTATION = 1234
     * $query->filterByIdParametragePrestation(array(12, 34)); // WHERE ID_PARAMETRAGE_PRESTATION IN (12, 34)
     * $query->filterByIdParametragePrestation(array('min' => 12)); // WHERE ID_PARAMETRAGE_PRESTATION >= 12
     * $query->filterByIdParametragePrestation(array('max' => 12)); // WHERE ID_PARAMETRAGE_PRESTATION <= 12
     * </code>
     *
     * @param     mixed $idParametragePrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByIdParametragePrestation($idParametragePrestation = null, $comparison = null)
    {
        if (is_array($idParametragePrestation)) {
            $useMinMax = false;
            if (isset($idParametragePrestation['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $idParametragePrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametragePrestation['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $idParametragePrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $idParametragePrestation, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisation(1234); // WHERE ID_ORGANISATION = 1234
     * $query->filterByIdOrganisation(array(12, 34)); // WHERE ID_ORGANISATION IN (12, 34)
     * $query->filterByIdOrganisation(array('min' => 12)); // WHERE ID_ORGANISATION >= 12
     * $query->filterByIdOrganisation(array('max' => 12)); // WHERE ID_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTOrganisation()
     *
     * @param     mixed $idOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByIdOrganisation($idOrganisation = null, $comparison = null)
    {
        if (is_array($idOrganisation)) {
            $useMinMax = false;
            if (isset($idOrganisation['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_ORGANISATION, $idOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisation['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_ORGANISATION, $idOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::ID_ORGANISATION, $idOrganisation, $comparison);
    }

    /**
     * Filter the query on the ID_REF_TYPE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRefTypePrestation(1234); // WHERE ID_REF_TYPE_PRESTATION = 1234
     * $query->filterByIdRefTypePrestation(array(12, 34)); // WHERE ID_REF_TYPE_PRESTATION IN (12, 34)
     * $query->filterByIdRefTypePrestation(array('min' => 12)); // WHERE ID_REF_TYPE_PRESTATION >= 12
     * $query->filterByIdRefTypePrestation(array('max' => 12)); // WHERE ID_REF_TYPE_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTRefTypePrestation()
     *
     * @param     mixed $idRefTypePrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByIdRefTypePrestation($idRefTypePrestation = null, $comparison = null)
    {
        if (is_array($idRefTypePrestation)) {
            $useMinMax = false;
            if (isset($idRefTypePrestation['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, $idRefTypePrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRefTypePrestation['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, $idRefTypePrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, $idRefTypePrestation, $comparison);
    }

    /**
     * Filter the query on the ID_REF_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRefPrestation(1234); // WHERE ID_REF_PRESTATION = 1234
     * $query->filterByIdRefPrestation(array(12, 34)); // WHERE ID_REF_PRESTATION IN (12, 34)
     * $query->filterByIdRefPrestation(array('min' => 12)); // WHERE ID_REF_PRESTATION >= 12
     * $query->filterByIdRefPrestation(array('max' => 12)); // WHERE ID_REF_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTRefPrestation()
     *
     * @param     mixed $idRefPrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByIdRefPrestation($idRefPrestation = null, $comparison = null)
    {
        if (is_array($idRefPrestation)) {
            $useMinMax = false;
            if (isset($idRefPrestation['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_REF_PRESTATION, $idRefPrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRefPrestation['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_REF_PRESTATION, $idRefPrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::ID_REF_PRESTATION, $idRefPrestation, $comparison);
    }

    /**
     * Filter the query on the RDV_SIMILAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByRdvSimilaire('fooValue');   // WHERE RDV_SIMILAIRE = 'fooValue'
     * $query->filterByRdvSimilaire('%fooValue%'); // WHERE RDV_SIMILAIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rdvSimilaire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByRdvSimilaire($rdvSimilaire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rdvSimilaire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rdvSimilaire)) {
                $rdvSimilaire = str_replace('*', '%', $rdvSimilaire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::RDV_SIMILAIRE, $rdvSimilaire, $comparison);
    }

    /**
     * Filter the query on the NB_JOUR_RDV_SIMILAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByNbJourRdvSimilaire(1234); // WHERE NB_JOUR_RDV_SIMILAIRE = 1234
     * $query->filterByNbJourRdvSimilaire(array(12, 34)); // WHERE NB_JOUR_RDV_SIMILAIRE IN (12, 34)
     * $query->filterByNbJourRdvSimilaire(array('min' => 12)); // WHERE NB_JOUR_RDV_SIMILAIRE >= 12
     * $query->filterByNbJourRdvSimilaire(array('max' => 12)); // WHERE NB_JOUR_RDV_SIMILAIRE <= 12
     * </code>
     *
     * @param     mixed $nbJourRdvSimilaire The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByNbJourRdvSimilaire($nbJourRdvSimilaire = null, $comparison = null)
    {
        if (is_array($nbJourRdvSimilaire)) {
            $useMinMax = false;
            if (isset($nbJourRdvSimilaire['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($nbJourRdvSimilaire['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire, $comparison);
    }

    /**
     * Filter the query on the DELAI_MIN column
     *
     * Example usage:
     * <code>
     * $query->filterByDelaiMin(1234); // WHERE DELAI_MIN = 1234
     * $query->filterByDelaiMin(array(12, 34)); // WHERE DELAI_MIN IN (12, 34)
     * $query->filterByDelaiMin(array('min' => 12)); // WHERE DELAI_MIN >= 12
     * $query->filterByDelaiMin(array('max' => 12)); // WHERE DELAI_MIN <= 12
     * </code>
     *
     * @param     mixed $delaiMin The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByDelaiMin($delaiMin = null, $comparison = null)
    {
        if (is_array($delaiMin)) {
            $useMinMax = false;
            if (isset($delaiMin['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::DELAI_MIN, $delaiMin['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($delaiMin['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::DELAI_MIN, $delaiMin['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::DELAI_MIN, $delaiMin, $comparison);
    }

    /**
     * Filter the query on the PERIODICITE column
     *
     * Example usage:
     * <code>
     * $query->filterByPeriodicite(1234); // WHERE PERIODICITE = 1234
     * $query->filterByPeriodicite(array(12, 34)); // WHERE PERIODICITE IN (12, 34)
     * $query->filterByPeriodicite(array('min' => 12)); // WHERE PERIODICITE >= 12
     * $query->filterByPeriodicite(array('max' => 12)); // WHERE PERIODICITE <= 12
     * </code>
     *
     * @param     mixed $periodicite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByPeriodicite($periodicite = null, $comparison = null)
    {
        if (is_array($periodicite)) {
            $useMinMax = false;
            if (isset($periodicite['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::PERIODICITE, $periodicite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($periodicite['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::PERIODICITE, $periodicite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::PERIODICITE, $periodicite, $comparison);
    }

    /**
     * Filter the query on the RESSOURCE_VISIBLE column
     *
     * Example usage:
     * <code>
     * $query->filterByRessourceVisible('fooValue');   // WHERE RESSOURCE_VISIBLE = 'fooValue'
     * $query->filterByRessourceVisible('%fooValue%'); // WHERE RESSOURCE_VISIBLE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ressourceVisible The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByRessourceVisible($ressourceVisible = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ressourceVisible)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ressourceVisible)) {
                $ressourceVisible = str_replace('*', '%', $ressourceVisible);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::RESSOURCE_VISIBLE, $ressourceVisible, $comparison);
    }

    /**
     * Filter the query on the RESSOURCE_OBLIGATOIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByRessourceObligatoire('fooValue');   // WHERE RESSOURCE_OBLIGATOIRE = 'fooValue'
     * $query->filterByRessourceObligatoire('%fooValue%'); // WHERE RESSOURCE_OBLIGATOIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ressourceObligatoire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByRessourceObligatoire($ressourceObligatoire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ressourceObligatoire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ressourceObligatoire)) {
                $ressourceObligatoire = str_replace('*', '%', $ressourceObligatoire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::RESSOURCE_OBLIGATOIRE, $ressourceObligatoire, $comparison);
    }

    /**
     * Filter the query on the ID_PARAMETRE_FORM column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametreForm(1234); // WHERE ID_PARAMETRE_FORM = 1234
     * $query->filterByIdParametreForm(array(12, 34)); // WHERE ID_PARAMETRE_FORM IN (12, 34)
     * $query->filterByIdParametreForm(array('min' => 12)); // WHERE ID_PARAMETRE_FORM >= 12
     * $query->filterByIdParametreForm(array('max' => 12)); // WHERE ID_PARAMETRE_FORM <= 12
     * </code>
     *
     * @see       filterByTParametreForm()
     *
     * @param     mixed $idParametreForm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByIdParametreForm($idParametreForm = null, $comparison = null)
    {
        if (is_array($idParametreForm)) {
            $useMinMax = false;
            if (isset($idParametreForm['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRE_FORM, $idParametreForm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametreForm['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRE_FORM, $idParametreForm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRE_FORM, $idParametreForm, $comparison);
    }

    /**
     * Filter the query on the CODE_COMMENTAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeCommentaire(1234); // WHERE CODE_COMMENTAIRE = 1234
     * $query->filterByCodeCommentaire(array(12, 34)); // WHERE CODE_COMMENTAIRE IN (12, 34)
     * $query->filterByCodeCommentaire(array('min' => 12)); // WHERE CODE_COMMENTAIRE >= 12
     * $query->filterByCodeCommentaire(array('max' => 12)); // WHERE CODE_COMMENTAIRE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeCommentaire()
     *
     * @param     mixed $codeCommentaire The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByCodeCommentaire($codeCommentaire = null, $comparison = null)
    {
        if (is_array($codeCommentaire)) {
            $useMinMax = false;
            if (isset($codeCommentaire['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::CODE_COMMENTAIRE, $codeCommentaire['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeCommentaire['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::CODE_COMMENTAIRE, $codeCommentaire['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::CODE_COMMENTAIRE, $codeCommentaire, $comparison);
    }

    /**
     * Filter the query on the REFERENT_VISIBLE column
     *
     * Example usage:
     * <code>
     * $query->filterByReferentVisible('fooValue');   // WHERE REFERENT_VISIBLE = 'fooValue'
     * $query->filterByReferentVisible('%fooValue%'); // WHERE REFERENT_VISIBLE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $referentVisible The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByReferentVisible($referentVisible = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($referentVisible)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $referentVisible)) {
                $referentVisible = str_replace('*', '%', $referentVisible);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::REFERENT_VISIBLE, $referentVisible, $comparison);
    }

    /**
     * Filter the query on the CODE_AIDE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeAide(1234); // WHERE CODE_AIDE = 1234
     * $query->filterByCodeAide(array(12, 34)); // WHERE CODE_AIDE IN (12, 34)
     * $query->filterByCodeAide(array('min' => 12)); // WHERE CODE_AIDE >= 12
     * $query->filterByCodeAide(array('max' => 12)); // WHERE CODE_AIDE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeAide()
     *
     * @param     mixed $codeAide The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function filterByCodeAide($codeAide = null, $comparison = null)
    {
        if (is_array($codeAide)) {
            $useMinMax = false;
            if (isset($codeAide['min'])) {
                $this->addUsingAlias(TParametragePrestationPeer::CODE_AIDE, $codeAide['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeAide['max'])) {
                $this->addUsingAlias(TParametragePrestationPeer::CODE_AIDE, $codeAide['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametragePrestationPeer::CODE_AIDE, $codeAide, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeAide($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::CODE_AIDE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametragePrestationPeer::CODE_AIDE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeAide() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeAide relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeAide($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeAide');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeAide');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeAide relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeAideQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeAide($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeAide', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeCommentaire($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::CODE_COMMENTAIRE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametragePrestationPeer::CODE_COMMENTAIRE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeCommentaire() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeCommentaire($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeCommentaire');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeCommentaire');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeCommentaire relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeCommentaireQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeCommentaire($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeCommentaire', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_ORGANISATION, $tOrganisation->getIdOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_ORGANISATION, $tOrganisation->toKeyValue('PrimaryKey', 'IdOrganisation'), $comparison);
        } else {
            throw new PropelException('filterByTOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTOrganisation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreForm($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRE_FORM, $tParametreForm->getIdParametreForm(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRE_FORM, $tParametreForm->toKeyValue('PrimaryKey', 'IdParametreForm'), $comparison);
        } else {
            throw new PropelException('filterByTParametreForm() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreForm relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTParametreForm($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreForm');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreForm');
        }

        return $this;
    }

    /**
     * Use the TParametreForm relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreForm($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreForm', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TRefPrestation object
     *
     * @param   TRefPrestation|PropelObjectCollection $tRefPrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefPrestation($tRefPrestation, $comparison = null)
    {
        if ($tRefPrestation instanceof TRefPrestation) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_REF_PRESTATION, $tRefPrestation->getIdRefPrestation(), $comparison);
        } elseif ($tRefPrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_REF_PRESTATION, $tRefPrestation->toKeyValue('PrimaryKey', 'IdRefPrestation'), $comparison);
        } else {
            throw new PropelException('filterByTRefPrestation() only accepts arguments of type TRefPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTRefPrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefPrestation');
        }

        return $this;
    }

    /**
     * Use the TRefPrestation relation TRefPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefPrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRefPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefPrestation', 'TRefPrestationQuery');
    }

    /**
     * Filter the query by a related TRefTypePrestation object
     *
     * @param   TRefTypePrestation|PropelObjectCollection $tRefTypePrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefTypePrestation($tRefTypePrestation, $comparison = null)
    {
        if ($tRefTypePrestation instanceof TRefTypePrestation) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, $tRefTypePrestation->getIdRefTypePrestation(), $comparison);
        } elseif ($tRefTypePrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, $tRefTypePrestation->toKeyValue('PrimaryKey', 'IdRefTypePrestation'), $comparison);
        } else {
            throw new PropelException('filterByTRefTypePrestation() only accepts arguments of type TRefTypePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefTypePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTRefTypePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefTypePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefTypePrestation');
        }

        return $this;
    }

    /**
     * Use the TRefTypePrestation relation TRefTypePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefTypePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefTypePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRefTypePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefTypePrestation', 'TRefTypePrestationQuery');
    }

    /**
     * Filter the query by a related TPieceParamPresta object
     *
     * @param   TPieceParamPresta|PropelObjectCollection $tPieceParamPresta  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPieceParamPresta($tPieceParamPresta, $comparison = null)
    {
        if ($tPieceParamPresta instanceof TPieceParamPresta) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $tPieceParamPresta->getIdParametragePrestation(), $comparison);
        } elseif ($tPieceParamPresta instanceof PropelObjectCollection) {
            return $this
                ->useTPieceParamPrestaQuery()
                ->filterByPrimaryKeys($tPieceParamPresta->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPieceParamPresta() only accepts arguments of type TPieceParamPresta or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPieceParamPresta relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTPieceParamPresta($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPieceParamPresta');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPieceParamPresta');
        }

        return $this;
    }

    /**
     * Use the TPieceParamPresta relation TPieceParamPresta object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPieceParamPrestaQuery A secondary query class using the current class as primary query
     */
    public function useTPieceParamPrestaQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPieceParamPresta($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPieceParamPresta', 'TPieceParamPrestaQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametragePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $tPrestation->getIdParametragePrestation(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTPrestationQuery()
                ->filterByPrimaryKeys($tPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function joinTPrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestation', 'TPrestationQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TParametragePrestation $tParametragePrestation Object to remove from the list of results
     *
     * @return TParametragePrestationQuery The current query, for fluid interface
     */
    public function prune($tParametragePrestation = null)
    {
        if ($tParametragePrestation) {
            $this->addUsingAlias(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $tParametragePrestation->getIdParametragePrestation(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
