<?php


/**
 * Base class that represents a query for the 'T_PARTICIPANT' table.
 *
 *
 *
 * @method TParticipantQuery orderByIdParticipant($order = Criteria::ASC) Order by the ID_PARTICIPANT column
 * @method TParticipantQuery orderByNom($order = Criteria::ASC) Order by the NOM column
 * @method TParticipantQuery orderByPrenom($order = Criteria::ASC) Order by the PRENOM column
 * @method TParticipantQuery orderByEmail($order = Criteria::ASC) Order by the EMAIL column
 * @method TParticipantQuery orderByOrganisation($order = Criteria::ASC) Order by the ORGANISATION column
 * @method TParticipantQuery orderByIdRendezVous($order = Criteria::ASC) Order by the ID_RENDEZ_VOUS column
 *
 * @method TParticipantQuery groupByIdParticipant() Group by the ID_PARTICIPANT column
 * @method TParticipantQuery groupByNom() Group by the NOM column
 * @method TParticipantQuery groupByPrenom() Group by the PRENOM column
 * @method TParticipantQuery groupByEmail() Group by the EMAIL column
 * @method TParticipantQuery groupByOrganisation() Group by the ORGANISATION column
 * @method TParticipantQuery groupByIdRendezVous() Group by the ID_RENDEZ_VOUS column
 *
 * @method TParticipantQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TParticipantQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TParticipantQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TParticipantQuery leftJoinTRendezVous($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVous relation
 * @method TParticipantQuery rightJoinTRendezVous($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVous relation
 * @method TParticipantQuery innerJoinTRendezVous($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVous relation
 *
 * @method TParticipant findOne(PropelPDO $con = null) Return the first TParticipant matching the query
 * @method TParticipant findOneOrCreate(PropelPDO $con = null) Return the first TParticipant matching the query, or a new TParticipant object populated from the query conditions when no match is found
 *
 * @method TParticipant findOneByNom(string $NOM) Return the first TParticipant filtered by the NOM column
 * @method TParticipant findOneByPrenom(string $PRENOM) Return the first TParticipant filtered by the PRENOM column
 * @method TParticipant findOneByEmail(string $EMAIL) Return the first TParticipant filtered by the EMAIL column
 * @method TParticipant findOneByOrganisation(string $ORGANISATION) Return the first TParticipant filtered by the ORGANISATION column
 * @method TParticipant findOneByIdRendezVous(int $ID_RENDEZ_VOUS) Return the first TParticipant filtered by the ID_RENDEZ_VOUS column
 *
 * @method array findByIdParticipant(int $ID_PARTICIPANT) Return TParticipant objects filtered by the ID_PARTICIPANT column
 * @method array findByNom(string $NOM) Return TParticipant objects filtered by the NOM column
 * @method array findByPrenom(string $PRENOM) Return TParticipant objects filtered by the PRENOM column
 * @method array findByEmail(string $EMAIL) Return TParticipant objects filtered by the EMAIL column
 * @method array findByOrganisation(string $ORGANISATION) Return TParticipant objects filtered by the ORGANISATION column
 * @method array findByIdRendezVous(int $ID_RENDEZ_VOUS) Return TParticipant objects filtered by the ID_RENDEZ_VOUS column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTParticipantQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTParticipantQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TParticipant', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TParticipantQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TParticipantQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TParticipantQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TParticipantQuery) {
            return $criteria;
        }
        $query = new TParticipantQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TParticipant|TParticipant[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TParticipantPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TParticipantPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TParticipant A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdParticipant($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TParticipant A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PARTICIPANT`, `NOM`, `PRENOM`, `EMAIL`, `ORGANISATION`, `ID_RENDEZ_VOUS` FROM `T_PARTICIPANT` WHERE `ID_PARTICIPANT` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TParticipant();
            $obj->hydrate($row);
            TParticipantPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TParticipant|TParticipant[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TParticipant[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TParticipantPeer::ID_PARTICIPANT, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TParticipantPeer::ID_PARTICIPANT, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PARTICIPANT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParticipant(1234); // WHERE ID_PARTICIPANT = 1234
     * $query->filterByIdParticipant(array(12, 34)); // WHERE ID_PARTICIPANT IN (12, 34)
     * $query->filterByIdParticipant(array('min' => 12)); // WHERE ID_PARTICIPANT >= 12
     * $query->filterByIdParticipant(array('max' => 12)); // WHERE ID_PARTICIPANT <= 12
     * </code>
     *
     * @param     mixed $idParticipant The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByIdParticipant($idParticipant = null, $comparison = null)
    {
        if (is_array($idParticipant)) {
            $useMinMax = false;
            if (isset($idParticipant['min'])) {
                $this->addUsingAlias(TParticipantPeer::ID_PARTICIPANT, $idParticipant['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParticipant['max'])) {
                $this->addUsingAlias(TParticipantPeer::ID_PARTICIPANT, $idParticipant['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParticipantPeer::ID_PARTICIPANT, $idParticipant, $comparison);
    }

    /**
     * Filter the query on the NOM column
     *
     * Example usage:
     * <code>
     * $query->filterByNom('fooValue');   // WHERE NOM = 'fooValue'
     * $query->filterByNom('%fooValue%'); // WHERE NOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $nom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByNom($nom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($nom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $nom)) {
                $nom = str_replace('*', '%', $nom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParticipantPeer::NOM, $nom, $comparison);
    }

    /**
     * Filter the query on the PRENOM column
     *
     * Example usage:
     * <code>
     * $query->filterByPrenom('fooValue');   // WHERE PRENOM = 'fooValue'
     * $query->filterByPrenom('%fooValue%'); // WHERE PRENOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $prenom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByPrenom($prenom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($prenom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $prenom)) {
                $prenom = str_replace('*', '%', $prenom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParticipantPeer::PRENOM, $prenom, $comparison);
    }

    /**
     * Filter the query on the EMAIL column
     *
     * Example usage:
     * <code>
     * $query->filterByEmail('fooValue');   // WHERE EMAIL = 'fooValue'
     * $query->filterByEmail('%fooValue%'); // WHERE EMAIL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $email The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByEmail($email = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($email)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $email)) {
                $email = str_replace('*', '%', $email);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParticipantPeer::EMAIL, $email, $comparison);
    }

    /**
     * Filter the query on the ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByOrganisation('fooValue');   // WHERE ORGANISATION = 'fooValue'
     * $query->filterByOrganisation('%fooValue%'); // WHERE ORGANISATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $organisation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByOrganisation($organisation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($organisation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $organisation)) {
                $organisation = str_replace('*', '%', $organisation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParticipantPeer::ORGANISATION, $organisation, $comparison);
    }

    /**
     * Filter the query on the ID_RENDEZ_VOUS column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRendezVous(1234); // WHERE ID_RENDEZ_VOUS = 1234
     * $query->filterByIdRendezVous(array(12, 34)); // WHERE ID_RENDEZ_VOUS IN (12, 34)
     * $query->filterByIdRendezVous(array('min' => 12)); // WHERE ID_RENDEZ_VOUS >= 12
     * $query->filterByIdRendezVous(array('max' => 12)); // WHERE ID_RENDEZ_VOUS <= 12
     * </code>
     *
     * @see       filterByTRendezVous()
     *
     * @param     mixed $idRendezVous The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function filterByIdRendezVous($idRendezVous = null, $comparison = null)
    {
        if (is_array($idRendezVous)) {
            $useMinMax = false;
            if (isset($idRendezVous['min'])) {
                $this->addUsingAlias(TParticipantPeer::ID_RENDEZ_VOUS, $idRendezVous['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRendezVous['max'])) {
                $this->addUsingAlias(TParticipantPeer::ID_RENDEZ_VOUS, $idRendezVous['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParticipantPeer::ID_RENDEZ_VOUS, $idRendezVous, $comparison);
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParticipantQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVous($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TParticipantPeer::ID_RENDEZ_VOUS, $tRendezVous->getIdRendezVous(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParticipantPeer::ID_RENDEZ_VOUS, $tRendezVous->toKeyValue('PrimaryKey', 'IdRendezVous'), $comparison);
        } else {
            throw new PropelException('filterByTRendezVous() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVous relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function joinTRendezVous($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVous');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVous');
        }

        return $this;
    }

    /**
     * Use the TRendezVous relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRendezVous($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVous', 'TRendezVousQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TParticipant $tParticipant Object to remove from the list of results
     *
     * @return TParticipantQuery The current query, for fluid interface
     */
    public function prune($tParticipant = null)
    {
        if ($tParticipant) {
            $this->addUsingAlias(TParticipantPeer::ID_PARTICIPANT, $tParticipant->getIdParticipant(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
