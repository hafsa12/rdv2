<?php


/**
 * Base class that represents a query for the 'T_ETABLISSEMENT' table.
 *
 *
 *
 * @method TEtablissementQuery orderByIdEtablissement($order = Criteria::ASC) Order by the ID_ETABLISSEMENT column
 * @method TEtablissementQuery orderByActive($order = Criteria::ASC) Order by the ACTIVE column
 * @method TEtablissementQuery orderByCodeDenominationEtablissement($order = Criteria::ASC) Order by the CODE_DENOMINATION_ETABLISSEMENT column
 * @method TEtablissementQuery orderByCodeAdresseEtablissement($order = Criteria::ASC) Order by the CODE_ADRESSE_ETABLISSEMENT column
 * @method TEtablissementQuery orderByCodePostal($order = Criteria::ASC) Order by the CODE_POSTAL column
 * @method TEtablissementQuery orderByTelephoneEtablissement($order = Criteria::ASC) Order by the TELEPHONE_ETABLISSEMENT column
 * @method TEtablissementQuery orderByMailEtablissement($order = Criteria::ASC) Order by the MAIL_ETABLISSEMENT column
 * @method TEtablissementQuery orderByCodeDescriptionEtablissement($order = Criteria::ASC) Order by the CODE_DESCRIPTION_ETABLISSEMENT column
 * @method TEtablissementQuery orderByLatitudeEtablissement($order = Criteria::ASC) Order by the LATITUDE_ETABLISSEMENT column
 * @method TEtablissementQuery orderByLongitudeEtablissement($order = Criteria::ASC) Order by the LONGITUDE_ETABLISSEMENT column
 * @method TEtablissementQuery orderByIdEntite($order = Criteria::ASC) Order by the ID_ENTITE column
 * @method TEtablissementQuery orderByIdOrganisation($order = Criteria::ASC) Order by the ID_ORGANISATION column
 * @method TEtablissementQuery orderByIdBlobPlan($order = Criteria::ASC) Order by the ID_BLOB_PLAN column
 * @method TEtablissementQuery orderByIdTypeEtab($order = Criteria::ASC) Order by the ID_TYPE_ETAB column
 *
 * @method TEtablissementQuery groupByIdEtablissement() Group by the ID_ETABLISSEMENT column
 * @method TEtablissementQuery groupByActive() Group by the ACTIVE column
 * @method TEtablissementQuery groupByCodeDenominationEtablissement() Group by the CODE_DENOMINATION_ETABLISSEMENT column
 * @method TEtablissementQuery groupByCodeAdresseEtablissement() Group by the CODE_ADRESSE_ETABLISSEMENT column
 * @method TEtablissementQuery groupByCodePostal() Group by the CODE_POSTAL column
 * @method TEtablissementQuery groupByTelephoneEtablissement() Group by the TELEPHONE_ETABLISSEMENT column
 * @method TEtablissementQuery groupByMailEtablissement() Group by the MAIL_ETABLISSEMENT column
 * @method TEtablissementQuery groupByCodeDescriptionEtablissement() Group by the CODE_DESCRIPTION_ETABLISSEMENT column
 * @method TEtablissementQuery groupByLatitudeEtablissement() Group by the LATITUDE_ETABLISSEMENT column
 * @method TEtablissementQuery groupByLongitudeEtablissement() Group by the LONGITUDE_ETABLISSEMENT column
 * @method TEtablissementQuery groupByIdEntite() Group by the ID_ENTITE column
 * @method TEtablissementQuery groupByIdOrganisation() Group by the ID_ORGANISATION column
 * @method TEtablissementQuery groupByIdBlobPlan() Group by the ID_BLOB_PLAN column
 * @method TEtablissementQuery groupByIdTypeEtab() Group by the ID_TYPE_ETAB column
 *
 * @method TEtablissementQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TEtablissementQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TEtablissementQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TEtablissementQuery leftJoinTTypeEtab($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTypeEtab relation
 * @method TEtablissementQuery rightJoinTTypeEtab($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTypeEtab relation
 * @method TEtablissementQuery innerJoinTTypeEtab($relationAlias = null) Adds a INNER JOIN clause to the query using the TTypeEtab relation
 *
 * @method TEtablissementQuery leftJoinTTraductionRelatedByCodeAdresseEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeAdresseEtablissement relation
 * @method TEtablissementQuery rightJoinTTraductionRelatedByCodeAdresseEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeAdresseEtablissement relation
 * @method TEtablissementQuery innerJoinTTraductionRelatedByCodeAdresseEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeAdresseEtablissement relation
 *
 * @method TEtablissementQuery leftJoinTTraductionRelatedByCodeDenominationEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeDenominationEtablissement relation
 * @method TEtablissementQuery rightJoinTTraductionRelatedByCodeDenominationEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeDenominationEtablissement relation
 * @method TEtablissementQuery innerJoinTTraductionRelatedByCodeDenominationEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeDenominationEtablissement relation
 *
 * @method TEtablissementQuery leftJoinTTraductionRelatedByCodeDescriptionEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeDescriptionEtablissement relation
 * @method TEtablissementQuery rightJoinTTraductionRelatedByCodeDescriptionEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeDescriptionEtablissement relation
 * @method TEtablissementQuery innerJoinTTraductionRelatedByCodeDescriptionEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeDescriptionEtablissement relation
 *
 * @method TEtablissementQuery leftJoinTBlob($relationAlias = null) Adds a LEFT JOIN clause to the query using the TBlob relation
 * @method TEtablissementQuery rightJoinTBlob($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TBlob relation
 * @method TEtablissementQuery innerJoinTBlob($relationAlias = null) Adds a INNER JOIN clause to the query using the TBlob relation
 *
 * @method TEtablissementQuery leftJoinTEntite($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEntite relation
 * @method TEtablissementQuery rightJoinTEntite($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEntite relation
 * @method TEtablissementQuery innerJoinTEntite($relationAlias = null) Adds a INNER JOIN clause to the query using the TEntite relation
 *
 * @method TEtablissementQuery leftJoinTOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisation relation
 * @method TEtablissementQuery rightJoinTOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisation relation
 * @method TEtablissementQuery innerJoinTOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisation relation
 *
 * @method TEtablissementQuery leftJoinTAgentRelatedByIdEtablissementAttache($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdEtablissementAttache relation
 * @method TEtablissementQuery rightJoinTAgentRelatedByIdEtablissementAttache($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdEtablissementAttache relation
 * @method TEtablissementQuery innerJoinTAgentRelatedByIdEtablissementAttache($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdEtablissementAttache relation
 *
 * @method TEtablissementQuery leftJoinTAgentRelatedByIdEtablissementGere($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdEtablissementGere relation
 * @method TEtablissementQuery rightJoinTAgentRelatedByIdEtablissementGere($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdEtablissementGere relation
 * @method TEtablissementQuery innerJoinTAgentRelatedByIdEtablissementGere($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdEtablissementGere relation
 *
 * @method TEtablissementQuery leftJoinTAgentEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentEtablissement relation
 * @method TEtablissementQuery rightJoinTAgentEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentEtablissement relation
 * @method TEtablissementQuery innerJoinTAgentEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentEtablissement relation
 *
 * @method TEtablissementQuery leftJoinTRendezVous($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVous relation
 * @method TEtablissementQuery rightJoinTRendezVous($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVous relation
 * @method TEtablissementQuery innerJoinTRendezVous($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVous relation
 *
 * @method TEtablissementQuery leftJoinTTypePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTypePrestation relation
 * @method TEtablissementQuery rightJoinTTypePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTypePrestation relation
 * @method TEtablissementQuery innerJoinTTypePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TTypePrestation relation
 *
 * @method TEtablissement findOne(PropelPDO $con = null) Return the first TEtablissement matching the query
 * @method TEtablissement findOneOrCreate(PropelPDO $con = null) Return the first TEtablissement matching the query, or a new TEtablissement object populated from the query conditions when no match is found
 *
 * @method TEtablissement findOneByActive(string $ACTIVE) Return the first TEtablissement filtered by the ACTIVE column
 * @method TEtablissement findOneByCodeDenominationEtablissement(int $CODE_DENOMINATION_ETABLISSEMENT) Return the first TEtablissement filtered by the CODE_DENOMINATION_ETABLISSEMENT column
 * @method TEtablissement findOneByCodeAdresseEtablissement(int $CODE_ADRESSE_ETABLISSEMENT) Return the first TEtablissement filtered by the CODE_ADRESSE_ETABLISSEMENT column
 * @method TEtablissement findOneByCodePostal(string $CODE_POSTAL) Return the first TEtablissement filtered by the CODE_POSTAL column
 * @method TEtablissement findOneByTelephoneEtablissement(string $TELEPHONE_ETABLISSEMENT) Return the first TEtablissement filtered by the TELEPHONE_ETABLISSEMENT column
 * @method TEtablissement findOneByMailEtablissement(string $MAIL_ETABLISSEMENT) Return the first TEtablissement filtered by the MAIL_ETABLISSEMENT column
 * @method TEtablissement findOneByCodeDescriptionEtablissement(int $CODE_DESCRIPTION_ETABLISSEMENT) Return the first TEtablissement filtered by the CODE_DESCRIPTION_ETABLISSEMENT column
 * @method TEtablissement findOneByLatitudeEtablissement(string $LATITUDE_ETABLISSEMENT) Return the first TEtablissement filtered by the LATITUDE_ETABLISSEMENT column
 * @method TEtablissement findOneByLongitudeEtablissement(string $LONGITUDE_ETABLISSEMENT) Return the first TEtablissement filtered by the LONGITUDE_ETABLISSEMENT column
 * @method TEtablissement findOneByIdEntite(int $ID_ENTITE) Return the first TEtablissement filtered by the ID_ENTITE column
 * @method TEtablissement findOneByIdOrganisation(int $ID_ORGANISATION) Return the first TEtablissement filtered by the ID_ORGANISATION column
 * @method TEtablissement findOneByIdBlobPlan(int $ID_BLOB_PLAN) Return the first TEtablissement filtered by the ID_BLOB_PLAN column
 * @method TEtablissement findOneByIdTypeEtab(int $ID_TYPE_ETAB) Return the first TEtablissement filtered by the ID_TYPE_ETAB column
 *
 * @method array findByIdEtablissement(int $ID_ETABLISSEMENT) Return TEtablissement objects filtered by the ID_ETABLISSEMENT column
 * @method array findByActive(string $ACTIVE) Return TEtablissement objects filtered by the ACTIVE column
 * @method array findByCodeDenominationEtablissement(int $CODE_DENOMINATION_ETABLISSEMENT) Return TEtablissement objects filtered by the CODE_DENOMINATION_ETABLISSEMENT column
 * @method array findByCodeAdresseEtablissement(int $CODE_ADRESSE_ETABLISSEMENT) Return TEtablissement objects filtered by the CODE_ADRESSE_ETABLISSEMENT column
 * @method array findByCodePostal(string $CODE_POSTAL) Return TEtablissement objects filtered by the CODE_POSTAL column
 * @method array findByTelephoneEtablissement(string $TELEPHONE_ETABLISSEMENT) Return TEtablissement objects filtered by the TELEPHONE_ETABLISSEMENT column
 * @method array findByMailEtablissement(string $MAIL_ETABLISSEMENT) Return TEtablissement objects filtered by the MAIL_ETABLISSEMENT column
 * @method array findByCodeDescriptionEtablissement(int $CODE_DESCRIPTION_ETABLISSEMENT) Return TEtablissement objects filtered by the CODE_DESCRIPTION_ETABLISSEMENT column
 * @method array findByLatitudeEtablissement(string $LATITUDE_ETABLISSEMENT) Return TEtablissement objects filtered by the LATITUDE_ETABLISSEMENT column
 * @method array findByLongitudeEtablissement(string $LONGITUDE_ETABLISSEMENT) Return TEtablissement objects filtered by the LONGITUDE_ETABLISSEMENT column
 * @method array findByIdEntite(int $ID_ENTITE) Return TEtablissement objects filtered by the ID_ENTITE column
 * @method array findByIdOrganisation(int $ID_ORGANISATION) Return TEtablissement objects filtered by the ID_ORGANISATION column
 * @method array findByIdBlobPlan(int $ID_BLOB_PLAN) Return TEtablissement objects filtered by the ID_BLOB_PLAN column
 * @method array findByIdTypeEtab(int $ID_TYPE_ETAB) Return TEtablissement objects filtered by the ID_TYPE_ETAB column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTEtablissementQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTEtablissementQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TEtablissement', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TEtablissementQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TEtablissementQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TEtablissementQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TEtablissementQuery) {
            return $criteria;
        }
        $query = new TEtablissementQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TEtablissement|TEtablissement[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TEtablissementPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TEtablissementPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TEtablissement A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdEtablissement($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TEtablissement A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_ETABLISSEMENT`, `ACTIVE`, `CODE_DENOMINATION_ETABLISSEMENT`, `CODE_ADRESSE_ETABLISSEMENT`, `CODE_POSTAL`, `TELEPHONE_ETABLISSEMENT`, `MAIL_ETABLISSEMENT`, `CODE_DESCRIPTION_ETABLISSEMENT`, `LATITUDE_ETABLISSEMENT`, `LONGITUDE_ETABLISSEMENT`, `ID_ENTITE`, `ID_ORGANISATION`, `ID_BLOB_PLAN`, `ID_TYPE_ETAB` FROM `T_ETABLISSEMENT` WHERE `ID_ETABLISSEMENT` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TEtablissement();
            $obj->hydrate($row);
            TEtablissementPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TEtablissement|TEtablissement[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TEtablissement[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEtablissement(1234); // WHERE ID_ETABLISSEMENT = 1234
     * $query->filterByIdEtablissement(array(12, 34)); // WHERE ID_ETABLISSEMENT IN (12, 34)
     * $query->filterByIdEtablissement(array('min' => 12)); // WHERE ID_ETABLISSEMENT >= 12
     * $query->filterByIdEtablissement(array('max' => 12)); // WHERE ID_ETABLISSEMENT <= 12
     * </code>
     *
     * @param     mixed $idEtablissement The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByIdEtablissement($idEtablissement = null, $comparison = null)
    {
        if (is_array($idEtablissement)) {
            $useMinMax = false;
            if (isset($idEtablissement['min'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $idEtablissement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEtablissement['max'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $idEtablissement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $idEtablissement, $comparison);
    }

    /**
     * Filter the query on the ACTIVE column
     *
     * Example usage:
     * <code>
     * $query->filterByActive('fooValue');   // WHERE ACTIVE = 'fooValue'
     * $query->filterByActive('%fooValue%'); // WHERE ACTIVE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $active The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByActive($active = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($active)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $active)) {
                $active = str_replace('*', '%', $active);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::ACTIVE, $active, $comparison);
    }

    /**
     * Filter the query on the CODE_DENOMINATION_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeDenominationEtablissement(1234); // WHERE CODE_DENOMINATION_ETABLISSEMENT = 1234
     * $query->filterByCodeDenominationEtablissement(array(12, 34)); // WHERE CODE_DENOMINATION_ETABLISSEMENT IN (12, 34)
     * $query->filterByCodeDenominationEtablissement(array('min' => 12)); // WHERE CODE_DENOMINATION_ETABLISSEMENT >= 12
     * $query->filterByCodeDenominationEtablissement(array('max' => 12)); // WHERE CODE_DENOMINATION_ETABLISSEMENT <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeDenominationEtablissement()
     *
     * @param     mixed $codeDenominationEtablissement The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByCodeDenominationEtablissement($codeDenominationEtablissement = null, $comparison = null)
    {
        if (is_array($codeDenominationEtablissement)) {
            $useMinMax = false;
            if (isset($codeDenominationEtablissement['min'])) {
                $this->addUsingAlias(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT, $codeDenominationEtablissement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeDenominationEtablissement['max'])) {
                $this->addUsingAlias(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT, $codeDenominationEtablissement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT, $codeDenominationEtablissement, $comparison);
    }

    /**
     * Filter the query on the CODE_ADRESSE_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeAdresseEtablissement(1234); // WHERE CODE_ADRESSE_ETABLISSEMENT = 1234
     * $query->filterByCodeAdresseEtablissement(array(12, 34)); // WHERE CODE_ADRESSE_ETABLISSEMENT IN (12, 34)
     * $query->filterByCodeAdresseEtablissement(array('min' => 12)); // WHERE CODE_ADRESSE_ETABLISSEMENT >= 12
     * $query->filterByCodeAdresseEtablissement(array('max' => 12)); // WHERE CODE_ADRESSE_ETABLISSEMENT <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeAdresseEtablissement()
     *
     * @param     mixed $codeAdresseEtablissement The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByCodeAdresseEtablissement($codeAdresseEtablissement = null, $comparison = null)
    {
        if (is_array($codeAdresseEtablissement)) {
            $useMinMax = false;
            if (isset($codeAdresseEtablissement['min'])) {
                $this->addUsingAlias(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT, $codeAdresseEtablissement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeAdresseEtablissement['max'])) {
                $this->addUsingAlias(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT, $codeAdresseEtablissement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT, $codeAdresseEtablissement, $comparison);
    }

    /**
     * Filter the query on the CODE_POSTAL column
     *
     * Example usage:
     * <code>
     * $query->filterByCodePostal('fooValue');   // WHERE CODE_POSTAL = 'fooValue'
     * $query->filterByCodePostal('%fooValue%'); // WHERE CODE_POSTAL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $codePostal The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByCodePostal($codePostal = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($codePostal)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $codePostal)) {
                $codePostal = str_replace('*', '%', $codePostal);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::CODE_POSTAL, $codePostal, $comparison);
    }

    /**
     * Filter the query on the TELEPHONE_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByTelephoneEtablissement('fooValue');   // WHERE TELEPHONE_ETABLISSEMENT = 'fooValue'
     * $query->filterByTelephoneEtablissement('%fooValue%'); // WHERE TELEPHONE_ETABLISSEMENT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $telephoneEtablissement The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByTelephoneEtablissement($telephoneEtablissement = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($telephoneEtablissement)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $telephoneEtablissement)) {
                $telephoneEtablissement = str_replace('*', '%', $telephoneEtablissement);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::TELEPHONE_ETABLISSEMENT, $telephoneEtablissement, $comparison);
    }

    /**
     * Filter the query on the MAIL_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByMailEtablissement('fooValue');   // WHERE MAIL_ETABLISSEMENT = 'fooValue'
     * $query->filterByMailEtablissement('%fooValue%'); // WHERE MAIL_ETABLISSEMENT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mailEtablissement The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByMailEtablissement($mailEtablissement = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mailEtablissement)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mailEtablissement)) {
                $mailEtablissement = str_replace('*', '%', $mailEtablissement);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::MAIL_ETABLISSEMENT, $mailEtablissement, $comparison);
    }

    /**
     * Filter the query on the CODE_DESCRIPTION_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeDescriptionEtablissement(1234); // WHERE CODE_DESCRIPTION_ETABLISSEMENT = 1234
     * $query->filterByCodeDescriptionEtablissement(array(12, 34)); // WHERE CODE_DESCRIPTION_ETABLISSEMENT IN (12, 34)
     * $query->filterByCodeDescriptionEtablissement(array('min' => 12)); // WHERE CODE_DESCRIPTION_ETABLISSEMENT >= 12
     * $query->filterByCodeDescriptionEtablissement(array('max' => 12)); // WHERE CODE_DESCRIPTION_ETABLISSEMENT <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeDescriptionEtablissement()
     *
     * @param     mixed $codeDescriptionEtablissement The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByCodeDescriptionEtablissement($codeDescriptionEtablissement = null, $comparison = null)
    {
        if (is_array($codeDescriptionEtablissement)) {
            $useMinMax = false;
            if (isset($codeDescriptionEtablissement['min'])) {
                $this->addUsingAlias(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT, $codeDescriptionEtablissement['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeDescriptionEtablissement['max'])) {
                $this->addUsingAlias(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT, $codeDescriptionEtablissement['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT, $codeDescriptionEtablissement, $comparison);
    }

    /**
     * Filter the query on the LATITUDE_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByLatitudeEtablissement('fooValue');   // WHERE LATITUDE_ETABLISSEMENT = 'fooValue'
     * $query->filterByLatitudeEtablissement('%fooValue%'); // WHERE LATITUDE_ETABLISSEMENT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $latitudeEtablissement The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByLatitudeEtablissement($latitudeEtablissement = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($latitudeEtablissement)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $latitudeEtablissement)) {
                $latitudeEtablissement = str_replace('*', '%', $latitudeEtablissement);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::LATITUDE_ETABLISSEMENT, $latitudeEtablissement, $comparison);
    }

    /**
     * Filter the query on the LONGITUDE_ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByLongitudeEtablissement('fooValue');   // WHERE LONGITUDE_ETABLISSEMENT = 'fooValue'
     * $query->filterByLongitudeEtablissement('%fooValue%'); // WHERE LONGITUDE_ETABLISSEMENT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $longitudeEtablissement The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByLongitudeEtablissement($longitudeEtablissement = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($longitudeEtablissement)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $longitudeEtablissement)) {
                $longitudeEtablissement = str_replace('*', '%', $longitudeEtablissement);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::LONGITUDE_ETABLISSEMENT, $longitudeEtablissement, $comparison);
    }

    /**
     * Filter the query on the ID_ENTITE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEntite(1234); // WHERE ID_ENTITE = 1234
     * $query->filterByIdEntite(array(12, 34)); // WHERE ID_ENTITE IN (12, 34)
     * $query->filterByIdEntite(array('min' => 12)); // WHERE ID_ENTITE >= 12
     * $query->filterByIdEntite(array('max' => 12)); // WHERE ID_ENTITE <= 12
     * </code>
     *
     * @see       filterByTEntite()
     *
     * @param     mixed $idEntite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByIdEntite($idEntite = null, $comparison = null)
    {
        if (is_array($idEntite)) {
            $useMinMax = false;
            if (isset($idEntite['min'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_ENTITE, $idEntite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEntite['max'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_ENTITE, $idEntite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::ID_ENTITE, $idEntite, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisation(1234); // WHERE ID_ORGANISATION = 1234
     * $query->filterByIdOrganisation(array(12, 34)); // WHERE ID_ORGANISATION IN (12, 34)
     * $query->filterByIdOrganisation(array('min' => 12)); // WHERE ID_ORGANISATION >= 12
     * $query->filterByIdOrganisation(array('max' => 12)); // WHERE ID_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTOrganisation()
     *
     * @param     mixed $idOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByIdOrganisation($idOrganisation = null, $comparison = null)
    {
        if (is_array($idOrganisation)) {
            $useMinMax = false;
            if (isset($idOrganisation['min'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_ORGANISATION, $idOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisation['max'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_ORGANISATION, $idOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::ID_ORGANISATION, $idOrganisation, $comparison);
    }

    /**
     * Filter the query on the ID_BLOB_PLAN column
     *
     * Example usage:
     * <code>
     * $query->filterByIdBlobPlan(1234); // WHERE ID_BLOB_PLAN = 1234
     * $query->filterByIdBlobPlan(array(12, 34)); // WHERE ID_BLOB_PLAN IN (12, 34)
     * $query->filterByIdBlobPlan(array('min' => 12)); // WHERE ID_BLOB_PLAN >= 12
     * $query->filterByIdBlobPlan(array('max' => 12)); // WHERE ID_BLOB_PLAN <= 12
     * </code>
     *
     * @see       filterByTBlob()
     *
     * @param     mixed $idBlobPlan The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByIdBlobPlan($idBlobPlan = null, $comparison = null)
    {
        if (is_array($idBlobPlan)) {
            $useMinMax = false;
            if (isset($idBlobPlan['min'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_BLOB_PLAN, $idBlobPlan['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idBlobPlan['max'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_BLOB_PLAN, $idBlobPlan['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::ID_BLOB_PLAN, $idBlobPlan, $comparison);
    }

    /**
     * Filter the query on the ID_TYPE_ETAB column
     *
     * Example usage:
     * <code>
     * $query->filterByIdTypeEtab(1234); // WHERE ID_TYPE_ETAB = 1234
     * $query->filterByIdTypeEtab(array(12, 34)); // WHERE ID_TYPE_ETAB IN (12, 34)
     * $query->filterByIdTypeEtab(array('min' => 12)); // WHERE ID_TYPE_ETAB >= 12
     * $query->filterByIdTypeEtab(array('max' => 12)); // WHERE ID_TYPE_ETAB <= 12
     * </code>
     *
     * @see       filterByTTypeEtab()
     *
     * @param     mixed $idTypeEtab The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function filterByIdTypeEtab($idTypeEtab = null, $comparison = null)
    {
        if (is_array($idTypeEtab)) {
            $useMinMax = false;
            if (isset($idTypeEtab['min'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_TYPE_ETAB, $idTypeEtab['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idTypeEtab['max'])) {
                $this->addUsingAlias(TEtablissementPeer::ID_TYPE_ETAB, $idTypeEtab['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEtablissementPeer::ID_TYPE_ETAB, $idTypeEtab, $comparison);
    }

    /**
     * Filter the query by a related TTypeEtab object
     *
     * @param   TTypeEtab|PropelObjectCollection $tTypeEtab The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTypeEtab($tTypeEtab, $comparison = null)
    {
        if ($tTypeEtab instanceof TTypeEtab) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_TYPE_ETAB, $tTypeEtab->getIdTypeEtab(), $comparison);
        } elseif ($tTypeEtab instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEtablissementPeer::ID_TYPE_ETAB, $tTypeEtab->toKeyValue('PrimaryKey', 'IdTypeEtab'), $comparison);
        } else {
            throw new PropelException('filterByTTypeEtab() only accepts arguments of type TTypeEtab or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTypeEtab relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTTypeEtab($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTypeEtab');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTypeEtab');
        }

        return $this;
    }

    /**
     * Use the TTypeEtab relation TTypeEtab object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTypeEtabQuery A secondary query class using the current class as primary query
     */
    public function useTTypeEtabQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTypeEtab($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTypeEtab', 'TTypeEtabQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeAdresseEtablissement($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeAdresseEtablissement() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeAdresseEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeAdresseEtablissement($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeAdresseEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeAdresseEtablissement');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeAdresseEtablissement relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeAdresseEtablissementQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeAdresseEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeAdresseEtablissement', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeDenominationEtablissement($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeDenominationEtablissement() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeDenominationEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeDenominationEtablissement($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeDenominationEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeDenominationEtablissement');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeDenominationEtablissement relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeDenominationEtablissementQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeDenominationEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeDenominationEtablissement', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeDescriptionEtablissement($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeDescriptionEtablissement() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeDescriptionEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeDescriptionEtablissement($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeDescriptionEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeDescriptionEtablissement');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeDescriptionEtablissement relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeDescriptionEtablissementQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeDescriptionEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeDescriptionEtablissement', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TBlob object
     *
     * @param   TBlob|PropelObjectCollection $tBlob The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTBlob($tBlob, $comparison = null)
    {
        if ($tBlob instanceof TBlob) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_BLOB_PLAN, $tBlob->getIdBlob(), $comparison);
        } elseif ($tBlob instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEtablissementPeer::ID_BLOB_PLAN, $tBlob->toKeyValue('PrimaryKey', 'IdBlob'), $comparison);
        } else {
            throw new PropelException('filterByTBlob() only accepts arguments of type TBlob or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TBlob relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTBlob($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TBlob');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TBlob');
        }

        return $this;
    }

    /**
     * Use the TBlob relation TBlob object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TBlobQuery A secondary query class using the current class as primary query
     */
    public function useTBlobQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTBlob($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TBlob', 'TBlobQuery');
    }

    /**
     * Filter the query by a related TEntite object
     *
     * @param   TEntite|PropelObjectCollection $tEntite The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEntite($tEntite, $comparison = null)
    {
        if ($tEntite instanceof TEntite) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ENTITE, $tEntite->getIdEntite(), $comparison);
        } elseif ($tEntite instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ENTITE, $tEntite->toKeyValue('PrimaryKey', 'IdEntite'), $comparison);
        } else {
            throw new PropelException('filterByTEntite() only accepts arguments of type TEntite or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEntite relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTEntite($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEntite');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEntite');
        }

        return $this;
    }

    /**
     * Use the TEntite relation TEntite object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEntiteQuery A secondary query class using the current class as primary query
     */
    public function useTEntiteQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEntite($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEntite', 'TEntiteQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ORGANISATION, $tOrganisation->getIdOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ORGANISATION, $tOrganisation->toKeyValue('PrimaryKey', 'IdOrganisation'), $comparison);
        } else {
            throw new PropelException('filterByTOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTOrganisation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdEtablissementAttache($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $tAgent->getIdEtablissementAttache(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentRelatedByIdEtablissementAttacheQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentRelatedByIdEtablissementAttache() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdEtablissementAttache relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdEtablissementAttache($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdEtablissementAttache');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdEtablissementAttache');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdEtablissementAttache relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdEtablissementAttacheQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdEtablissementAttache($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdEtablissementAttache', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdEtablissementGere($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $tAgent->getIdEtablissementGere(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentRelatedByIdEtablissementGereQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentRelatedByIdEtablissementGere() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdEtablissementGere relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdEtablissementGere($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdEtablissementGere');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdEtablissementGere');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdEtablissementGere relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdEtablissementGereQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdEtablissementGere($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdEtablissementGere', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgentEtablissement object
     *
     * @param   TAgentEtablissement|PropelObjectCollection $tAgentEtablissement  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentEtablissement($tAgentEtablissement, $comparison = null)
    {
        if ($tAgentEtablissement instanceof TAgentEtablissement) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $tAgentEtablissement->getIdEtablissement(), $comparison);
        } elseif ($tAgentEtablissement instanceof PropelObjectCollection) {
            return $this
                ->useTAgentEtablissementQuery()
                ->filterByPrimaryKeys($tAgentEtablissement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentEtablissement() only accepts arguments of type TAgentEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTAgentEtablissement($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentEtablissement');
        }

        return $this;
    }

    /**
     * Use the TAgentEtablissement relation TAgentEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTAgentEtablissementQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTAgentEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentEtablissement', 'TAgentEtablissementQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVous($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $tRendezVous->getIdEtablissement(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVous() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVous relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTRendezVous($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVous');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVous');
        }

        return $this;
    }

    /**
     * Use the TRendezVous relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRendezVous($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVous', 'TRendezVousQuery');
    }

    /**
     * Filter the query by a related TTypePrestation object
     *
     * @param   TTypePrestation|PropelObjectCollection $tTypePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEtablissementQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTypePrestation($tTypePrestation, $comparison = null)
    {
        if ($tTypePrestation instanceof TTypePrestation) {
            return $this
                ->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $tTypePrestation->getIdEtablissement(), $comparison);
        } elseif ($tTypePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTTypePrestationQuery()
                ->filterByPrimaryKeys($tTypePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTTypePrestation() only accepts arguments of type TTypePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTypePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function joinTTypePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTypePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTypePrestation');
        }

        return $this;
    }

    /**
     * Use the TTypePrestation relation TTypePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTypePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTTypePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTypePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTypePrestation', 'TTypePrestationQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TEtablissement $tEtablissement Object to remove from the list of results
     *
     * @return TEtablissementQuery The current query, for fluid interface
     */
    public function prune($tEtablissement = null)
    {
        if ($tEtablissement) {
            $this->addUsingAlias(TEtablissementPeer::ID_ETABLISSEMENT, $tEtablissement->getIdEtablissement(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
