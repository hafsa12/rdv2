<?php


/**
 * Base class that represents a query for the 'T_AGENDA' table.
 *
 *
 *
 * @method TAgendaQuery orderByIdAgenda($order = Criteria::ASC) Order by the ID_AGENDA column
 * @method TAgendaQuery orderByMaxMoisPriseRdv($order = Criteria::ASC) Order by the MAX_MOIS_PRISE_RDV column
 * @method TAgendaQuery orderByIdAgent($order = Criteria::ASC) Order by the ID_AGENT column
 * @method TAgendaQuery orderByIdPrestation($order = Criteria::ASC) Order by the ID_PRESTATION column
 *
 * @method TAgendaQuery groupByIdAgenda() Group by the ID_AGENDA column
 * @method TAgendaQuery groupByMaxMoisPriseRdv() Group by the MAX_MOIS_PRISE_RDV column
 * @method TAgendaQuery groupByIdAgent() Group by the ID_AGENT column
 * @method TAgendaQuery groupByIdPrestation() Group by the ID_PRESTATION column
 *
 * @method TAgendaQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TAgendaQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TAgendaQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TAgendaQuery leftJoinTAgent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgent relation
 * @method TAgendaQuery rightJoinTAgent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgent relation
 * @method TAgendaQuery innerJoinTAgent($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgent relation
 *
 * @method TAgendaQuery leftJoinTPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestation relation
 * @method TAgendaQuery rightJoinTPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestation relation
 * @method TAgendaQuery innerJoinTPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestation relation
 *
 * @method TAgendaQuery leftJoinTPeriode($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPeriode relation
 * @method TAgendaQuery rightJoinTPeriode($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPeriode relation
 * @method TAgendaQuery innerJoinTPeriode($relationAlias = null) Adds a INNER JOIN clause to the query using the TPeriode relation
 *
 * @method TAgenda findOne(PropelPDO $con = null) Return the first TAgenda matching the query
 * @method TAgenda findOneOrCreate(PropelPDO $con = null) Return the first TAgenda matching the query, or a new TAgenda object populated from the query conditions when no match is found
 *
 * @method TAgenda findOneByMaxMoisPriseRdv(int $MAX_MOIS_PRISE_RDV) Return the first TAgenda filtered by the MAX_MOIS_PRISE_RDV column
 * @method TAgenda findOneByIdAgent(int $ID_AGENT) Return the first TAgenda filtered by the ID_AGENT column
 * @method TAgenda findOneByIdPrestation(int $ID_PRESTATION) Return the first TAgenda filtered by the ID_PRESTATION column
 *
 * @method array findByIdAgenda(int $ID_AGENDA) Return TAgenda objects filtered by the ID_AGENDA column
 * @method array findByMaxMoisPriseRdv(int $MAX_MOIS_PRISE_RDV) Return TAgenda objects filtered by the MAX_MOIS_PRISE_RDV column
 * @method array findByIdAgent(int $ID_AGENT) Return TAgenda objects filtered by the ID_AGENT column
 * @method array findByIdPrestation(int $ID_PRESTATION) Return TAgenda objects filtered by the ID_PRESTATION column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTAgendaQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTAgendaQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TAgenda', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TAgendaQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TAgendaQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TAgendaQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TAgendaQuery) {
            return $criteria;
        }
        $query = new TAgendaQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TAgenda|TAgenda[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TAgendaPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TAgendaPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TAgenda A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdAgenda($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TAgenda A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_AGENDA`, `MAX_MOIS_PRISE_RDV`, `ID_AGENT`, `ID_PRESTATION` FROM `T_AGENDA` WHERE `ID_AGENDA` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TAgenda();
            $obj->hydrate($row);
            TAgendaPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TAgenda|TAgenda[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TAgenda[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TAgendaPeer::ID_AGENDA, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TAgendaPeer::ID_AGENDA, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_AGENDA column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgenda(1234); // WHERE ID_AGENDA = 1234
     * $query->filterByIdAgenda(array(12, 34)); // WHERE ID_AGENDA IN (12, 34)
     * $query->filterByIdAgenda(array('min' => 12)); // WHERE ID_AGENDA >= 12
     * $query->filterByIdAgenda(array('max' => 12)); // WHERE ID_AGENDA <= 12
     * </code>
     *
     * @param     mixed $idAgenda The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function filterByIdAgenda($idAgenda = null, $comparison = null)
    {
        if (is_array($idAgenda)) {
            $useMinMax = false;
            if (isset($idAgenda['min'])) {
                $this->addUsingAlias(TAgendaPeer::ID_AGENDA, $idAgenda['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgenda['max'])) {
                $this->addUsingAlias(TAgendaPeer::ID_AGENDA, $idAgenda['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgendaPeer::ID_AGENDA, $idAgenda, $comparison);
    }

    /**
     * Filter the query on the MAX_MOIS_PRISE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByMaxMoisPriseRdv(1234); // WHERE MAX_MOIS_PRISE_RDV = 1234
     * $query->filterByMaxMoisPriseRdv(array(12, 34)); // WHERE MAX_MOIS_PRISE_RDV IN (12, 34)
     * $query->filterByMaxMoisPriseRdv(array('min' => 12)); // WHERE MAX_MOIS_PRISE_RDV >= 12
     * $query->filterByMaxMoisPriseRdv(array('max' => 12)); // WHERE MAX_MOIS_PRISE_RDV <= 12
     * </code>
     *
     * @param     mixed $maxMoisPriseRdv The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function filterByMaxMoisPriseRdv($maxMoisPriseRdv = null, $comparison = null)
    {
        if (is_array($maxMoisPriseRdv)) {
            $useMinMax = false;
            if (isset($maxMoisPriseRdv['min'])) {
                $this->addUsingAlias(TAgendaPeer::MAX_MOIS_PRISE_RDV, $maxMoisPriseRdv['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($maxMoisPriseRdv['max'])) {
                $this->addUsingAlias(TAgendaPeer::MAX_MOIS_PRISE_RDV, $maxMoisPriseRdv['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgendaPeer::MAX_MOIS_PRISE_RDV, $maxMoisPriseRdv, $comparison);
    }

    /**
     * Filter the query on the ID_AGENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgent(1234); // WHERE ID_AGENT = 1234
     * $query->filterByIdAgent(array(12, 34)); // WHERE ID_AGENT IN (12, 34)
     * $query->filterByIdAgent(array('min' => 12)); // WHERE ID_AGENT >= 12
     * $query->filterByIdAgent(array('max' => 12)); // WHERE ID_AGENT <= 12
     * </code>
     *
     * @see       filterByTAgent()
     *
     * @param     mixed $idAgent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function filterByIdAgent($idAgent = null, $comparison = null)
    {
        if (is_array($idAgent)) {
            $useMinMax = false;
            if (isset($idAgent['min'])) {
                $this->addUsingAlias(TAgendaPeer::ID_AGENT, $idAgent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgent['max'])) {
                $this->addUsingAlias(TAgendaPeer::ID_AGENT, $idAgent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgendaPeer::ID_AGENT, $idAgent, $comparison);
    }

    /**
     * Filter the query on the ID_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPrestation(1234); // WHERE ID_PRESTATION = 1234
     * $query->filterByIdPrestation(array(12, 34)); // WHERE ID_PRESTATION IN (12, 34)
     * $query->filterByIdPrestation(array('min' => 12)); // WHERE ID_PRESTATION >= 12
     * $query->filterByIdPrestation(array('max' => 12)); // WHERE ID_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTPrestation()
     *
     * @param     mixed $idPrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function filterByIdPrestation($idPrestation = null, $comparison = null)
    {
        if (is_array($idPrestation)) {
            $useMinMax = false;
            if (isset($idPrestation['min'])) {
                $this->addUsingAlias(TAgendaPeer::ID_PRESTATION, $idPrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPrestation['max'])) {
                $this->addUsingAlias(TAgendaPeer::ID_PRESTATION, $idPrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgendaPeer::ID_PRESTATION, $idPrestation, $comparison);
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgendaQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgent($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TAgendaPeer::ID_AGENT, $tAgent->getIdAgent(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgendaPeer::ID_AGENT, $tAgent->toKeyValue('PrimaryKey', 'IdAgent'), $comparison);
        } else {
            throw new PropelException('filterByTAgent() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function joinTAgent($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgent');
        }

        return $this;
    }

    /**
     * Use the TAgent relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgent', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgendaQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TAgendaPeer::ID_PRESTATION, $tPrestation->getIdPrestation(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgendaPeer::ID_PRESTATION, $tPrestation->toKeyValue('PrimaryKey', 'IdPrestation'), $comparison);
        } else {
            throw new PropelException('filterByTPrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function joinTPrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestation', 'TPrestationQuery');
    }

    /**
     * Filter the query by a related TPeriode object
     *
     * @param   TPeriode|PropelObjectCollection $tPeriode  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgendaQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPeriode($tPeriode, $comparison = null)
    {
        if ($tPeriode instanceof TPeriode) {
            return $this
                ->addUsingAlias(TAgendaPeer::ID_AGENDA, $tPeriode->getIdAgenda(), $comparison);
        } elseif ($tPeriode instanceof PropelObjectCollection) {
            return $this
                ->useTPeriodeQuery()
                ->filterByPrimaryKeys($tPeriode->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPeriode() only accepts arguments of type TPeriode or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPeriode relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function joinTPeriode($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPeriode');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPeriode');
        }

        return $this;
    }

    /**
     * Use the TPeriode relation TPeriode object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPeriodeQuery A secondary query class using the current class as primary query
     */
    public function useTPeriodeQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPeriode($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPeriode', 'TPeriodeQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TAgenda $tAgenda Object to remove from the list of results
     *
     * @return TAgendaQuery The current query, for fluid interface
     */
    public function prune($tAgenda = null)
    {
        if ($tAgenda) {
            $this->addUsingAlias(TAgendaPeer::ID_AGENDA, $tAgenda->getIdAgenda(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
