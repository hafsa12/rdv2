<?php


/**
 * Base class that represents a query for the 'T_PROFIL' table.
 *
 *
 *
 * @method TProfilQuery orderByIdProfil($order = Criteria::ASC) Order by the ID_PROFIL column
 * @method TProfilQuery orderByIdOrganisation($order = Criteria::ASC) Order by the ID_ORGANISATION column
 * @method TProfilQuery orderByCodeLibelleProfil($order = Criteria::ASC) Order by the CODE_LIBELLE_PROFIL column
 * @method TProfilQuery orderByIdTypeProfil($order = Criteria::ASC) Order by the ID_TYPE_PROFIL column
 * @method TProfilQuery orderByOrganisation($order = Criteria::ASC) Order by the ORGANISATION column
 * @method TProfilQuery orderByEtablissement($order = Criteria::ASC) Order by the ETABLISSEMENT column
 * @method TProfilQuery orderByReferentielTypePrestation($order = Criteria::ASC) Order by the REFERENTIEL_TYPE_PRESTATION column
 * @method TProfilQuery orderByParametragePrestation($order = Criteria::ASC) Order by the PARAMETRAGE_PRESTATION column
 * @method TProfilQuery orderByNiveau1($order = Criteria::ASC) Order by the NIVEAU_1 column
 * @method TProfilQuery orderByNiveau2($order = Criteria::ASC) Order by the NIVEAU_2 column
 * @method TProfilQuery orderByNiveau3($order = Criteria::ASC) Order by the NIVEAU_3 column
 * @method TProfilQuery orderByJoursFeries($order = Criteria::ASC) Order by the JOURS_FERIES column
 * @method TProfilQuery orderByAgenda($order = Criteria::ASC) Order by the AGENDA column
 * @method TProfilQuery orderByJoursIndisponibilites($order = Criteria::ASC) Order by the JOURS_INDISPONIBILITES column
 * @method TProfilQuery orderByUtilisateurs($order = Criteria::ASC) Order by the UTILISATEURS column
 * @method TProfilQuery orderByProfils($order = Criteria::ASC) Order by the PROFILS column
 * @method TProfilQuery orderByGestionsDesRendezVous($order = Criteria::ASC) Order by the GESTIONS_DES_RENDEZ_VOUS column
 * @method TProfilQuery orderByRapportNbrRdv($order = Criteria::ASC) Order by the RAPPORT_NBR_RDV column
 * @method TProfilQuery orderByRapportDelaiObtention($order = Criteria::ASC) Order by the RAPPORT_DELAI_OBTENTION column
 * @method TProfilQuery orderByRapportActivite($order = Criteria::ASC) Order by the RAPPORT_ACTIVITE column
 * @method TProfilQuery orderByPerformanceGlobale($order = Criteria::ASC) Order by the PERFORMANCE_GLOBALE column
 * @method TProfilQuery orderByReferentielPrestation($order = Criteria::ASC) Order by the REFERENTIEL_PRESTATION column
 * @method TProfilQuery orderByRechercheEtendueRdv($order = Criteria::ASC) Order by the RECHERCHE_ETENDUE_RDV column
 * @method TProfilQuery orderByAlertRapportHebdo($order = Criteria::ASC) Order by the ALERT_RAPPORT_HEBDO column
 * @method TProfilQuery orderByAlertRapportMens($order = Criteria::ASC) Order by the ALERT_RAPPORT_MENS column
 * @method TProfilQuery orderByModifDureeRdv($order = Criteria::ASC) Order by the MODIF_DUREE_RDV column
 * @method TProfilQuery orderByAffectationRdv($order = Criteria::ASC) Order by the AFFECTATION_RDV column
 * @method TProfilQuery orderByAnnulationRdv($order = Criteria::ASC) Order by the ANNULATION_RDV column
 *
 * @method TProfilQuery groupByIdProfil() Group by the ID_PROFIL column
 * @method TProfilQuery groupByIdOrganisation() Group by the ID_ORGANISATION column
 * @method TProfilQuery groupByCodeLibelleProfil() Group by the CODE_LIBELLE_PROFIL column
 * @method TProfilQuery groupByIdTypeProfil() Group by the ID_TYPE_PROFIL column
 * @method TProfilQuery groupByOrganisation() Group by the ORGANISATION column
 * @method TProfilQuery groupByEtablissement() Group by the ETABLISSEMENT column
 * @method TProfilQuery groupByReferentielTypePrestation() Group by the REFERENTIEL_TYPE_PRESTATION column
 * @method TProfilQuery groupByParametragePrestation() Group by the PARAMETRAGE_PRESTATION column
 * @method TProfilQuery groupByNiveau1() Group by the NIVEAU_1 column
 * @method TProfilQuery groupByNiveau2() Group by the NIVEAU_2 column
 * @method TProfilQuery groupByNiveau3() Group by the NIVEAU_3 column
 * @method TProfilQuery groupByJoursFeries() Group by the JOURS_FERIES column
 * @method TProfilQuery groupByAgenda() Group by the AGENDA column
 * @method TProfilQuery groupByJoursIndisponibilites() Group by the JOURS_INDISPONIBILITES column
 * @method TProfilQuery groupByUtilisateurs() Group by the UTILISATEURS column
 * @method TProfilQuery groupByProfils() Group by the PROFILS column
 * @method TProfilQuery groupByGestionsDesRendezVous() Group by the GESTIONS_DES_RENDEZ_VOUS column
 * @method TProfilQuery groupByRapportNbrRdv() Group by the RAPPORT_NBR_RDV column
 * @method TProfilQuery groupByRapportDelaiObtention() Group by the RAPPORT_DELAI_OBTENTION column
 * @method TProfilQuery groupByRapportActivite() Group by the RAPPORT_ACTIVITE column
 * @method TProfilQuery groupByPerformanceGlobale() Group by the PERFORMANCE_GLOBALE column
 * @method TProfilQuery groupByReferentielPrestation() Group by the REFERENTIEL_PRESTATION column
 * @method TProfilQuery groupByRechercheEtendueRdv() Group by the RECHERCHE_ETENDUE_RDV column
 * @method TProfilQuery groupByAlertRapportHebdo() Group by the ALERT_RAPPORT_HEBDO column
 * @method TProfilQuery groupByAlertRapportMens() Group by the ALERT_RAPPORT_MENS column
 * @method TProfilQuery groupByModifDureeRdv() Group by the MODIF_DUREE_RDV column
 * @method TProfilQuery groupByAffectationRdv() Group by the AFFECTATION_RDV column
 * @method TProfilQuery groupByAnnulationRdv() Group by the ANNULATION_RDV column
 *
 * @method TProfilQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TProfilQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TProfilQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TProfilQuery leftJoinTTraduction($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraduction relation
 * @method TProfilQuery rightJoinTTraduction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraduction relation
 * @method TProfilQuery innerJoinTTraduction($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraduction relation
 *
 * @method TProfilQuery leftJoinTOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisation relation
 * @method TProfilQuery rightJoinTOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisation relation
 * @method TProfilQuery innerJoinTOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisation relation
 *
 * @method TProfilQuery leftJoinTTypeProfil($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTypeProfil relation
 * @method TProfilQuery rightJoinTTypeProfil($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTypeProfil relation
 * @method TProfilQuery innerJoinTTypeProfil($relationAlias = null) Adds a INNER JOIN clause to the query using the TTypeProfil relation
 *
 * @method TProfilQuery leftJoinTAgent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgent relation
 * @method TProfilQuery rightJoinTAgent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgent relation
 * @method TProfilQuery innerJoinTAgent($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgent relation
 *
 * @method TProfil findOne(PropelPDO $con = null) Return the first TProfil matching the query
 * @method TProfil findOneOrCreate(PropelPDO $con = null) Return the first TProfil matching the query, or a new TProfil object populated from the query conditions when no match is found
 *
 * @method TProfil findOneByIdOrganisation(int $ID_ORGANISATION) Return the first TProfil filtered by the ID_ORGANISATION column
 * @method TProfil findOneByCodeLibelleProfil(int $CODE_LIBELLE_PROFIL) Return the first TProfil filtered by the CODE_LIBELLE_PROFIL column
 * @method TProfil findOneByIdTypeProfil(int $ID_TYPE_PROFIL) Return the first TProfil filtered by the ID_TYPE_PROFIL column
 * @method TProfil findOneByOrganisation(string $ORGANISATION) Return the first TProfil filtered by the ORGANISATION column
 * @method TProfil findOneByEtablissement(string $ETABLISSEMENT) Return the first TProfil filtered by the ETABLISSEMENT column
 * @method TProfil findOneByReferentielTypePrestation(string $REFERENTIEL_TYPE_PRESTATION) Return the first TProfil filtered by the REFERENTIEL_TYPE_PRESTATION column
 * @method TProfil findOneByParametragePrestation(string $PARAMETRAGE_PRESTATION) Return the first TProfil filtered by the PARAMETRAGE_PRESTATION column
 * @method TProfil findOneByNiveau1(string $NIVEAU_1) Return the first TProfil filtered by the NIVEAU_1 column
 * @method TProfil findOneByNiveau2(string $NIVEAU_2) Return the first TProfil filtered by the NIVEAU_2 column
 * @method TProfil findOneByNiveau3(string $NIVEAU_3) Return the first TProfil filtered by the NIVEAU_3 column
 * @method TProfil findOneByJoursFeries(string $JOURS_FERIES) Return the first TProfil filtered by the JOURS_FERIES column
 * @method TProfil findOneByAgenda(string $AGENDA) Return the first TProfil filtered by the AGENDA column
 * @method TProfil findOneByJoursIndisponibilites(string $JOURS_INDISPONIBILITES) Return the first TProfil filtered by the JOURS_INDISPONIBILITES column
 * @method TProfil findOneByUtilisateurs(string $UTILISATEURS) Return the first TProfil filtered by the UTILISATEURS column
 * @method TProfil findOneByProfils(string $PROFILS) Return the first TProfil filtered by the PROFILS column
 * @method TProfil findOneByGestionsDesRendezVous(string $GESTIONS_DES_RENDEZ_VOUS) Return the first TProfil filtered by the GESTIONS_DES_RENDEZ_VOUS column
 * @method TProfil findOneByRapportNbrRdv(string $RAPPORT_NBR_RDV) Return the first TProfil filtered by the RAPPORT_NBR_RDV column
 * @method TProfil findOneByRapportDelaiObtention(string $RAPPORT_DELAI_OBTENTION) Return the first TProfil filtered by the RAPPORT_DELAI_OBTENTION column
 * @method TProfil findOneByRapportActivite(string $RAPPORT_ACTIVITE) Return the first TProfil filtered by the RAPPORT_ACTIVITE column
 * @method TProfil findOneByPerformanceGlobale(string $PERFORMANCE_GLOBALE) Return the first TProfil filtered by the PERFORMANCE_GLOBALE column
 * @method TProfil findOneByReferentielPrestation(string $REFERENTIEL_PRESTATION) Return the first TProfil filtered by the REFERENTIEL_PRESTATION column
 * @method TProfil findOneByRechercheEtendueRdv(string $RECHERCHE_ETENDUE_RDV) Return the first TProfil filtered by the RECHERCHE_ETENDUE_RDV column
 * @method TProfil findOneByAlertRapportHebdo(string $ALERT_RAPPORT_HEBDO) Return the first TProfil filtered by the ALERT_RAPPORT_HEBDO column
 * @method TProfil findOneByAlertRapportMens(string $ALERT_RAPPORT_MENS) Return the first TProfil filtered by the ALERT_RAPPORT_MENS column
 * @method TProfil findOneByModifDureeRdv(string $MODIF_DUREE_RDV) Return the first TProfil filtered by the MODIF_DUREE_RDV column
 * @method TProfil findOneByAffectationRdv(string $AFFECTATION_RDV) Return the first TProfil filtered by the AFFECTATION_RDV column
 * @method TProfil findOneByAnnulationRdv(string $ANNULATION_RDV) Return the first TProfil filtered by the ANNULATION_RDV column
 *
 * @method array findByIdProfil(int $ID_PROFIL) Return TProfil objects filtered by the ID_PROFIL column
 * @method array findByIdOrganisation(int $ID_ORGANISATION) Return TProfil objects filtered by the ID_ORGANISATION column
 * @method array findByCodeLibelleProfil(int $CODE_LIBELLE_PROFIL) Return TProfil objects filtered by the CODE_LIBELLE_PROFIL column
 * @method array findByIdTypeProfil(int $ID_TYPE_PROFIL) Return TProfil objects filtered by the ID_TYPE_PROFIL column
 * @method array findByOrganisation(string $ORGANISATION) Return TProfil objects filtered by the ORGANISATION column
 * @method array findByEtablissement(string $ETABLISSEMENT) Return TProfil objects filtered by the ETABLISSEMENT column
 * @method array findByReferentielTypePrestation(string $REFERENTIEL_TYPE_PRESTATION) Return TProfil objects filtered by the REFERENTIEL_TYPE_PRESTATION column
 * @method array findByParametragePrestation(string $PARAMETRAGE_PRESTATION) Return TProfil objects filtered by the PARAMETRAGE_PRESTATION column
 * @method array findByNiveau1(string $NIVEAU_1) Return TProfil objects filtered by the NIVEAU_1 column
 * @method array findByNiveau2(string $NIVEAU_2) Return TProfil objects filtered by the NIVEAU_2 column
 * @method array findByNiveau3(string $NIVEAU_3) Return TProfil objects filtered by the NIVEAU_3 column
 * @method array findByJoursFeries(string $JOURS_FERIES) Return TProfil objects filtered by the JOURS_FERIES column
 * @method array findByAgenda(string $AGENDA) Return TProfil objects filtered by the AGENDA column
 * @method array findByJoursIndisponibilites(string $JOURS_INDISPONIBILITES) Return TProfil objects filtered by the JOURS_INDISPONIBILITES column
 * @method array findByUtilisateurs(string $UTILISATEURS) Return TProfil objects filtered by the UTILISATEURS column
 * @method array findByProfils(string $PROFILS) Return TProfil objects filtered by the PROFILS column
 * @method array findByGestionsDesRendezVous(string $GESTIONS_DES_RENDEZ_VOUS) Return TProfil objects filtered by the GESTIONS_DES_RENDEZ_VOUS column
 * @method array findByRapportNbrRdv(string $RAPPORT_NBR_RDV) Return TProfil objects filtered by the RAPPORT_NBR_RDV column
 * @method array findByRapportDelaiObtention(string $RAPPORT_DELAI_OBTENTION) Return TProfil objects filtered by the RAPPORT_DELAI_OBTENTION column
 * @method array findByRapportActivite(string $RAPPORT_ACTIVITE) Return TProfil objects filtered by the RAPPORT_ACTIVITE column
 * @method array findByPerformanceGlobale(string $PERFORMANCE_GLOBALE) Return TProfil objects filtered by the PERFORMANCE_GLOBALE column
 * @method array findByReferentielPrestation(string $REFERENTIEL_PRESTATION) Return TProfil objects filtered by the REFERENTIEL_PRESTATION column
 * @method array findByRechercheEtendueRdv(string $RECHERCHE_ETENDUE_RDV) Return TProfil objects filtered by the RECHERCHE_ETENDUE_RDV column
 * @method array findByAlertRapportHebdo(string $ALERT_RAPPORT_HEBDO) Return TProfil objects filtered by the ALERT_RAPPORT_HEBDO column
 * @method array findByAlertRapportMens(string $ALERT_RAPPORT_MENS) Return TProfil objects filtered by the ALERT_RAPPORT_MENS column
 * @method array findByModifDureeRdv(string $MODIF_DUREE_RDV) Return TProfil objects filtered by the MODIF_DUREE_RDV column
 * @method array findByAffectationRdv(string $AFFECTATION_RDV) Return TProfil objects filtered by the AFFECTATION_RDV column
 * @method array findByAnnulationRdv(string $ANNULATION_RDV) Return TProfil objects filtered by the ANNULATION_RDV column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTProfilQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTProfilQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TProfil', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TProfilQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TProfilQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TProfilQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TProfilQuery) {
            return $criteria;
        }
        $query = new TProfilQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TProfil|TProfil[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TProfilPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TProfil A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdProfil($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TProfil A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PROFIL`, `ID_ORGANISATION`, `CODE_LIBELLE_PROFIL`, `ID_TYPE_PROFIL`, `ORGANISATION`, `ETABLISSEMENT`, `REFERENTIEL_TYPE_PRESTATION`, `PARAMETRAGE_PRESTATION`, `NIVEAU_1`, `NIVEAU_2`, `NIVEAU_3`, `JOURS_FERIES`, `AGENDA`, `JOURS_INDISPONIBILITES`, `UTILISATEURS`, `PROFILS`, `GESTIONS_DES_RENDEZ_VOUS`, `RAPPORT_NBR_RDV`, `RAPPORT_DELAI_OBTENTION`, `RAPPORT_ACTIVITE`, `PERFORMANCE_GLOBALE`, `REFERENTIEL_PRESTATION`, `RECHERCHE_ETENDUE_RDV`, `ALERT_RAPPORT_HEBDO`, `ALERT_RAPPORT_MENS`, `MODIF_DUREE_RDV`, `AFFECTATION_RDV`, `ANNULATION_RDV` FROM `T_PROFIL` WHERE `ID_PROFIL` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TProfil();
            $obj->hydrate($row);
            TProfilPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TProfil|TProfil[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TProfil[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TProfilPeer::ID_PROFIL, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TProfilPeer::ID_PROFIL, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PROFIL column
     *
     * Example usage:
     * <code>
     * $query->filterByIdProfil(1234); // WHERE ID_PROFIL = 1234
     * $query->filterByIdProfil(array(12, 34)); // WHERE ID_PROFIL IN (12, 34)
     * $query->filterByIdProfil(array('min' => 12)); // WHERE ID_PROFIL >= 12
     * $query->filterByIdProfil(array('max' => 12)); // WHERE ID_PROFIL <= 12
     * </code>
     *
     * @param     mixed $idProfil The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByIdProfil($idProfil = null, $comparison = null)
    {
        if (is_array($idProfil)) {
            $useMinMax = false;
            if (isset($idProfil['min'])) {
                $this->addUsingAlias(TProfilPeer::ID_PROFIL, $idProfil['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idProfil['max'])) {
                $this->addUsingAlias(TProfilPeer::ID_PROFIL, $idProfil['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ID_PROFIL, $idProfil, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisation(1234); // WHERE ID_ORGANISATION = 1234
     * $query->filterByIdOrganisation(array(12, 34)); // WHERE ID_ORGANISATION IN (12, 34)
     * $query->filterByIdOrganisation(array('min' => 12)); // WHERE ID_ORGANISATION >= 12
     * $query->filterByIdOrganisation(array('max' => 12)); // WHERE ID_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTOrganisation()
     *
     * @param     mixed $idOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByIdOrganisation($idOrganisation = null, $comparison = null)
    {
        if (is_array($idOrganisation)) {
            $useMinMax = false;
            if (isset($idOrganisation['min'])) {
                $this->addUsingAlias(TProfilPeer::ID_ORGANISATION, $idOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisation['max'])) {
                $this->addUsingAlias(TProfilPeer::ID_ORGANISATION, $idOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ID_ORGANISATION, $idOrganisation, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_PROFIL column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleProfil(1234); // WHERE CODE_LIBELLE_PROFIL = 1234
     * $query->filterByCodeLibelleProfil(array(12, 34)); // WHERE CODE_LIBELLE_PROFIL IN (12, 34)
     * $query->filterByCodeLibelleProfil(array('min' => 12)); // WHERE CODE_LIBELLE_PROFIL >= 12
     * $query->filterByCodeLibelleProfil(array('max' => 12)); // WHERE CODE_LIBELLE_PROFIL <= 12
     * </code>
     *
     * @see       filterByTTraduction()
     *
     * @param     mixed $codeLibelleProfil The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleProfil($codeLibelleProfil = null, $comparison = null)
    {
        if (is_array($codeLibelleProfil)) {
            $useMinMax = false;
            if (isset($codeLibelleProfil['min'])) {
                $this->addUsingAlias(TProfilPeer::CODE_LIBELLE_PROFIL, $codeLibelleProfil['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleProfil['max'])) {
                $this->addUsingAlias(TProfilPeer::CODE_LIBELLE_PROFIL, $codeLibelleProfil['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TProfilPeer::CODE_LIBELLE_PROFIL, $codeLibelleProfil, $comparison);
    }

    /**
     * Filter the query on the ID_TYPE_PROFIL column
     *
     * Example usage:
     * <code>
     * $query->filterByIdTypeProfil(1234); // WHERE ID_TYPE_PROFIL = 1234
     * $query->filterByIdTypeProfil(array(12, 34)); // WHERE ID_TYPE_PROFIL IN (12, 34)
     * $query->filterByIdTypeProfil(array('min' => 12)); // WHERE ID_TYPE_PROFIL >= 12
     * $query->filterByIdTypeProfil(array('max' => 12)); // WHERE ID_TYPE_PROFIL <= 12
     * </code>
     *
     * @see       filterByTTypeProfil()
     *
     * @param     mixed $idTypeProfil The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByIdTypeProfil($idTypeProfil = null, $comparison = null)
    {
        if (is_array($idTypeProfil)) {
            $useMinMax = false;
            if (isset($idTypeProfil['min'])) {
                $this->addUsingAlias(TProfilPeer::ID_TYPE_PROFIL, $idTypeProfil['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idTypeProfil['max'])) {
                $this->addUsingAlias(TProfilPeer::ID_TYPE_PROFIL, $idTypeProfil['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ID_TYPE_PROFIL, $idTypeProfil, $comparison);
    }

    /**
     * Filter the query on the ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByOrganisation('fooValue');   // WHERE ORGANISATION = 'fooValue'
     * $query->filterByOrganisation('%fooValue%'); // WHERE ORGANISATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $organisation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByOrganisation($organisation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($organisation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $organisation)) {
                $organisation = str_replace('*', '%', $organisation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ORGANISATION, $organisation, $comparison);
    }

    /**
     * Filter the query on the ETABLISSEMENT column
     *
     * Example usage:
     * <code>
     * $query->filterByEtablissement('fooValue');   // WHERE ETABLISSEMENT = 'fooValue'
     * $query->filterByEtablissement('%fooValue%'); // WHERE ETABLISSEMENT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $etablissement The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByEtablissement($etablissement = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($etablissement)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $etablissement)) {
                $etablissement = str_replace('*', '%', $etablissement);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ETABLISSEMENT, $etablissement, $comparison);
    }

    /**
     * Filter the query on the REFERENTIEL_TYPE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByReferentielTypePrestation('fooValue');   // WHERE REFERENTIEL_TYPE_PRESTATION = 'fooValue'
     * $query->filterByReferentielTypePrestation('%fooValue%'); // WHERE REFERENTIEL_TYPE_PRESTATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $referentielTypePrestation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByReferentielTypePrestation($referentielTypePrestation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($referentielTypePrestation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $referentielTypePrestation)) {
                $referentielTypePrestation = str_replace('*', '%', $referentielTypePrestation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::REFERENTIEL_TYPE_PRESTATION, $referentielTypePrestation, $comparison);
    }

    /**
     * Filter the query on the PARAMETRAGE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByParametragePrestation('fooValue');   // WHERE PARAMETRAGE_PRESTATION = 'fooValue'
     * $query->filterByParametragePrestation('%fooValue%'); // WHERE PARAMETRAGE_PRESTATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $parametragePrestation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByParametragePrestation($parametragePrestation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($parametragePrestation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $parametragePrestation)) {
                $parametragePrestation = str_replace('*', '%', $parametragePrestation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::PARAMETRAGE_PRESTATION, $parametragePrestation, $comparison);
    }

    /**
     * Filter the query on the NIVEAU_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByNiveau1('fooValue');   // WHERE NIVEAU_1 = 'fooValue'
     * $query->filterByNiveau1('%fooValue%'); // WHERE NIVEAU_1 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $niveau1 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByNiveau1($niveau1 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($niveau1)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $niveau1)) {
                $niveau1 = str_replace('*', '%', $niveau1);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::NIVEAU_1, $niveau1, $comparison);
    }

    /**
     * Filter the query on the NIVEAU_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByNiveau2('fooValue');   // WHERE NIVEAU_2 = 'fooValue'
     * $query->filterByNiveau2('%fooValue%'); // WHERE NIVEAU_2 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $niveau2 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByNiveau2($niveau2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($niveau2)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $niveau2)) {
                $niveau2 = str_replace('*', '%', $niveau2);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::NIVEAU_2, $niveau2, $comparison);
    }

    /**
     * Filter the query on the NIVEAU_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByNiveau3('fooValue');   // WHERE NIVEAU_3 = 'fooValue'
     * $query->filterByNiveau3('%fooValue%'); // WHERE NIVEAU_3 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $niveau3 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByNiveau3($niveau3 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($niveau3)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $niveau3)) {
                $niveau3 = str_replace('*', '%', $niveau3);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::NIVEAU_3, $niveau3, $comparison);
    }

    /**
     * Filter the query on the JOURS_FERIES column
     *
     * Example usage:
     * <code>
     * $query->filterByJoursFeries('fooValue');   // WHERE JOURS_FERIES = 'fooValue'
     * $query->filterByJoursFeries('%fooValue%'); // WHERE JOURS_FERIES LIKE '%fooValue%'
     * </code>
     *
     * @param     string $joursFeries The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByJoursFeries($joursFeries = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($joursFeries)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $joursFeries)) {
                $joursFeries = str_replace('*', '%', $joursFeries);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::JOURS_FERIES, $joursFeries, $comparison);
    }

    /**
     * Filter the query on the AGENDA column
     *
     * Example usage:
     * <code>
     * $query->filterByAgenda('fooValue');   // WHERE AGENDA = 'fooValue'
     * $query->filterByAgenda('%fooValue%'); // WHERE AGENDA LIKE '%fooValue%'
     * </code>
     *
     * @param     string $agenda The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByAgenda($agenda = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($agenda)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $agenda)) {
                $agenda = str_replace('*', '%', $agenda);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::AGENDA, $agenda, $comparison);
    }

    /**
     * Filter the query on the JOURS_INDISPONIBILITES column
     *
     * Example usage:
     * <code>
     * $query->filterByJoursIndisponibilites('fooValue');   // WHERE JOURS_INDISPONIBILITES = 'fooValue'
     * $query->filterByJoursIndisponibilites('%fooValue%'); // WHERE JOURS_INDISPONIBILITES LIKE '%fooValue%'
     * </code>
     *
     * @param     string $joursIndisponibilites The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByJoursIndisponibilites($joursIndisponibilites = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($joursIndisponibilites)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $joursIndisponibilites)) {
                $joursIndisponibilites = str_replace('*', '%', $joursIndisponibilites);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::JOURS_INDISPONIBILITES, $joursIndisponibilites, $comparison);
    }

    /**
     * Filter the query on the UTILISATEURS column
     *
     * Example usage:
     * <code>
     * $query->filterByUtilisateurs('fooValue');   // WHERE UTILISATEURS = 'fooValue'
     * $query->filterByUtilisateurs('%fooValue%'); // WHERE UTILISATEURS LIKE '%fooValue%'
     * </code>
     *
     * @param     string $utilisateurs The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByUtilisateurs($utilisateurs = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($utilisateurs)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $utilisateurs)) {
                $utilisateurs = str_replace('*', '%', $utilisateurs);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::UTILISATEURS, $utilisateurs, $comparison);
    }

    /**
     * Filter the query on the PROFILS column
     *
     * Example usage:
     * <code>
     * $query->filterByProfils('fooValue');   // WHERE PROFILS = 'fooValue'
     * $query->filterByProfils('%fooValue%'); // WHERE PROFILS LIKE '%fooValue%'
     * </code>
     *
     * @param     string $profils The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByProfils($profils = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($profils)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $profils)) {
                $profils = str_replace('*', '%', $profils);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::PROFILS, $profils, $comparison);
    }

    /**
     * Filter the query on the GESTIONS_DES_RENDEZ_VOUS column
     *
     * Example usage:
     * <code>
     * $query->filterByGestionsDesRendezVous('fooValue');   // WHERE GESTIONS_DES_RENDEZ_VOUS = 'fooValue'
     * $query->filterByGestionsDesRendezVous('%fooValue%'); // WHERE GESTIONS_DES_RENDEZ_VOUS LIKE '%fooValue%'
     * </code>
     *
     * @param     string $gestionsDesRendezVous The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByGestionsDesRendezVous($gestionsDesRendezVous = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($gestionsDesRendezVous)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $gestionsDesRendezVous)) {
                $gestionsDesRendezVous = str_replace('*', '%', $gestionsDesRendezVous);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::GESTIONS_DES_RENDEZ_VOUS, $gestionsDesRendezVous, $comparison);
    }

    /**
     * Filter the query on the RAPPORT_NBR_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByRapportNbrRdv('fooValue');   // WHERE RAPPORT_NBR_RDV = 'fooValue'
     * $query->filterByRapportNbrRdv('%fooValue%'); // WHERE RAPPORT_NBR_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rapportNbrRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByRapportNbrRdv($rapportNbrRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rapportNbrRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rapportNbrRdv)) {
                $rapportNbrRdv = str_replace('*', '%', $rapportNbrRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::RAPPORT_NBR_RDV, $rapportNbrRdv, $comparison);
    }

    /**
     * Filter the query on the RAPPORT_DELAI_OBTENTION column
     *
     * Example usage:
     * <code>
     * $query->filterByRapportDelaiObtention('fooValue');   // WHERE RAPPORT_DELAI_OBTENTION = 'fooValue'
     * $query->filterByRapportDelaiObtention('%fooValue%'); // WHERE RAPPORT_DELAI_OBTENTION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rapportDelaiObtention The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByRapportDelaiObtention($rapportDelaiObtention = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rapportDelaiObtention)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rapportDelaiObtention)) {
                $rapportDelaiObtention = str_replace('*', '%', $rapportDelaiObtention);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::RAPPORT_DELAI_OBTENTION, $rapportDelaiObtention, $comparison);
    }

    /**
     * Filter the query on the RAPPORT_ACTIVITE column
     *
     * Example usage:
     * <code>
     * $query->filterByRapportActivite('fooValue');   // WHERE RAPPORT_ACTIVITE = 'fooValue'
     * $query->filterByRapportActivite('%fooValue%'); // WHERE RAPPORT_ACTIVITE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rapportActivite The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByRapportActivite($rapportActivite = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rapportActivite)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rapportActivite)) {
                $rapportActivite = str_replace('*', '%', $rapportActivite);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::RAPPORT_ACTIVITE, $rapportActivite, $comparison);
    }

    /**
     * Filter the query on the PERFORMANCE_GLOBALE column
     *
     * Example usage:
     * <code>
     * $query->filterByPerformanceGlobale('fooValue');   // WHERE PERFORMANCE_GLOBALE = 'fooValue'
     * $query->filterByPerformanceGlobale('%fooValue%'); // WHERE PERFORMANCE_GLOBALE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $performanceGlobale The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByPerformanceGlobale($performanceGlobale = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($performanceGlobale)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $performanceGlobale)) {
                $performanceGlobale = str_replace('*', '%', $performanceGlobale);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::PERFORMANCE_GLOBALE, $performanceGlobale, $comparison);
    }

    /**
     * Filter the query on the REFERENTIEL_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByReferentielPrestation('fooValue');   // WHERE REFERENTIEL_PRESTATION = 'fooValue'
     * $query->filterByReferentielPrestation('%fooValue%'); // WHERE REFERENTIEL_PRESTATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $referentielPrestation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByReferentielPrestation($referentielPrestation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($referentielPrestation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $referentielPrestation)) {
                $referentielPrestation = str_replace('*', '%', $referentielPrestation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::REFERENTIEL_PRESTATION, $referentielPrestation, $comparison);
    }

    /**
     * Filter the query on the RECHERCHE_ETENDUE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByRechercheEtendueRdv('fooValue');   // WHERE RECHERCHE_ETENDUE_RDV = 'fooValue'
     * $query->filterByRechercheEtendueRdv('%fooValue%'); // WHERE RECHERCHE_ETENDUE_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rechercheEtendueRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByRechercheEtendueRdv($rechercheEtendueRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rechercheEtendueRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rechercheEtendueRdv)) {
                $rechercheEtendueRdv = str_replace('*', '%', $rechercheEtendueRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::RECHERCHE_ETENDUE_RDV, $rechercheEtendueRdv, $comparison);
    }

    /**
     * Filter the query on the ALERT_RAPPORT_HEBDO column
     *
     * Example usage:
     * <code>
     * $query->filterByAlertRapportHebdo('fooValue');   // WHERE ALERT_RAPPORT_HEBDO = 'fooValue'
     * $query->filterByAlertRapportHebdo('%fooValue%'); // WHERE ALERT_RAPPORT_HEBDO LIKE '%fooValue%'
     * </code>
     *
     * @param     string $alertRapportHebdo The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByAlertRapportHebdo($alertRapportHebdo = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($alertRapportHebdo)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $alertRapportHebdo)) {
                $alertRapportHebdo = str_replace('*', '%', $alertRapportHebdo);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ALERT_RAPPORT_HEBDO, $alertRapportHebdo, $comparison);
    }

    /**
     * Filter the query on the ALERT_RAPPORT_MENS column
     *
     * Example usage:
     * <code>
     * $query->filterByAlertRapportMens('fooValue');   // WHERE ALERT_RAPPORT_MENS = 'fooValue'
     * $query->filterByAlertRapportMens('%fooValue%'); // WHERE ALERT_RAPPORT_MENS LIKE '%fooValue%'
     * </code>
     *
     * @param     string $alertRapportMens The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByAlertRapportMens($alertRapportMens = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($alertRapportMens)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $alertRapportMens)) {
                $alertRapportMens = str_replace('*', '%', $alertRapportMens);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ALERT_RAPPORT_MENS, $alertRapportMens, $comparison);
    }

    /**
     * Filter the query on the MODIF_DUREE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByModifDureeRdv('fooValue');   // WHERE MODIF_DUREE_RDV = 'fooValue'
     * $query->filterByModifDureeRdv('%fooValue%'); // WHERE MODIF_DUREE_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $modifDureeRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByModifDureeRdv($modifDureeRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($modifDureeRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $modifDureeRdv)) {
                $modifDureeRdv = str_replace('*', '%', $modifDureeRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::MODIF_DUREE_RDV, $modifDureeRdv, $comparison);
    }

    /**
     * Filter the query on the AFFECTATION_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByAffectationRdv('fooValue');   // WHERE AFFECTATION_RDV = 'fooValue'
     * $query->filterByAffectationRdv('%fooValue%'); // WHERE AFFECTATION_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $affectationRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByAffectationRdv($affectationRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($affectationRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $affectationRdv)) {
                $affectationRdv = str_replace('*', '%', $affectationRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::AFFECTATION_RDV, $affectationRdv, $comparison);
    }

    /**
     * Filter the query on the ANNULATION_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByAnnulationRdv('fooValue');   // WHERE ANNULATION_RDV = 'fooValue'
     * $query->filterByAnnulationRdv('%fooValue%'); // WHERE ANNULATION_RDV LIKE '%fooValue%'
     * </code>
     *
     * @param     string $annulationRdv The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function filterByAnnulationRdv($annulationRdv = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($annulationRdv)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $annulationRdv)) {
                $annulationRdv = str_replace('*', '%', $annulationRdv);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TProfilPeer::ANNULATION_RDV, $annulationRdv, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TProfilQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraduction($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TProfilPeer::CODE_LIBELLE_PROFIL, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TProfilPeer::CODE_LIBELLE_PROFIL, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraduction() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraduction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function joinTTraduction($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraduction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraduction');
        }

        return $this;
    }

    /**
     * Use the TTraduction relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraduction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraduction', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TProfilQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TProfilPeer::ID_ORGANISATION, $tOrganisation->getIdOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TProfilPeer::ID_ORGANISATION, $tOrganisation->toKeyValue('PrimaryKey', 'IdOrganisation'), $comparison);
        } else {
            throw new PropelException('filterByTOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function joinTOrganisation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TTypeProfil object
     *
     * @param   TTypeProfil|PropelObjectCollection $tTypeProfil The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TProfilQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTypeProfil($tTypeProfil, $comparison = null)
    {
        if ($tTypeProfil instanceof TTypeProfil) {
            return $this
                ->addUsingAlias(TProfilPeer::ID_TYPE_PROFIL, $tTypeProfil->getIdTypeProfil(), $comparison);
        } elseif ($tTypeProfil instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TProfilPeer::ID_TYPE_PROFIL, $tTypeProfil->toKeyValue('PrimaryKey', 'IdTypeProfil'), $comparison);
        } else {
            throw new PropelException('filterByTTypeProfil() only accepts arguments of type TTypeProfil or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTypeProfil relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function joinTTypeProfil($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTypeProfil');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTypeProfil');
        }

        return $this;
    }

    /**
     * Use the TTypeProfil relation TTypeProfil object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTypeProfilQuery A secondary query class using the current class as primary query
     */
    public function useTTypeProfilQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTypeProfil($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTypeProfil', 'TTypeProfilQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TProfilQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgent($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TProfilPeer::ID_PROFIL, $tAgent->getIdProfil(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgent() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function joinTAgent($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgent');
        }

        return $this;
    }

    /**
     * Use the TAgent relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgent', 'TAgentQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TProfil $tProfil Object to remove from the list of results
     *
     * @return TProfilQuery The current query, for fluid interface
     */
    public function prune($tProfil = null)
    {
        if ($tProfil) {
            $this->addUsingAlias(TProfilPeer::ID_PROFIL, $tProfil->getIdProfil(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
