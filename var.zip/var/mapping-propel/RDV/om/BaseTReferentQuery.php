<?php


/**
 * Base class that represents a query for the 'T_REFERENT' table.
 *
 *
 *
 * @method TReferentQuery orderByIdReferent($order = Criteria::ASC) Order by the ID_REFERENT column
 * @method TReferentQuery orderByIdEntite($order = Criteria::ASC) Order by the ID_ENTITE column
 * @method TReferentQuery orderByCodeNomReferent($order = Criteria::ASC) Order by the CODE_NOM_REFERENT column
 * @method TReferentQuery orderByCodePrenomReferent($order = Criteria::ASC) Order by the CODE_PRENOM_REFERENT column
 *
 * @method TReferentQuery groupByIdReferent() Group by the ID_REFERENT column
 * @method TReferentQuery groupByIdEntite() Group by the ID_ENTITE column
 * @method TReferentQuery groupByCodeNomReferent() Group by the CODE_NOM_REFERENT column
 * @method TReferentQuery groupByCodePrenomReferent() Group by the CODE_PRENOM_REFERENT column
 *
 * @method TReferentQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TReferentQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TReferentQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TReferentQuery leftJoinTTraductionRelatedByCodeNomReferent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeNomReferent relation
 * @method TReferentQuery rightJoinTTraductionRelatedByCodeNomReferent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeNomReferent relation
 * @method TReferentQuery innerJoinTTraductionRelatedByCodeNomReferent($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeNomReferent relation
 *
 * @method TReferentQuery leftJoinTTraductionRelatedByCodePrenomReferent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodePrenomReferent relation
 * @method TReferentQuery rightJoinTTraductionRelatedByCodePrenomReferent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodePrenomReferent relation
 * @method TReferentQuery innerJoinTTraductionRelatedByCodePrenomReferent($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodePrenomReferent relation
 *
 * @method TReferentQuery leftJoinTEntite($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEntite relation
 * @method TReferentQuery rightJoinTEntite($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEntite relation
 * @method TReferentQuery innerJoinTEntite($relationAlias = null) Adds a INNER JOIN clause to the query using the TEntite relation
 *
 * @method TReferentQuery leftJoinTRendezVous($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVous relation
 * @method TReferentQuery rightJoinTRendezVous($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVous relation
 * @method TReferentQuery innerJoinTRendezVous($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVous relation
 *
 * @method TReferent findOne(PropelPDO $con = null) Return the first TReferent matching the query
 * @method TReferent findOneOrCreate(PropelPDO $con = null) Return the first TReferent matching the query, or a new TReferent object populated from the query conditions when no match is found
 *
 * @method TReferent findOneByIdEntite(int $ID_ENTITE) Return the first TReferent filtered by the ID_ENTITE column
 * @method TReferent findOneByCodeNomReferent(int $CODE_NOM_REFERENT) Return the first TReferent filtered by the CODE_NOM_REFERENT column
 * @method TReferent findOneByCodePrenomReferent(int $CODE_PRENOM_REFERENT) Return the first TReferent filtered by the CODE_PRENOM_REFERENT column
 *
 * @method array findByIdReferent(int $ID_REFERENT) Return TReferent objects filtered by the ID_REFERENT column
 * @method array findByIdEntite(int $ID_ENTITE) Return TReferent objects filtered by the ID_ENTITE column
 * @method array findByCodeNomReferent(int $CODE_NOM_REFERENT) Return TReferent objects filtered by the CODE_NOM_REFERENT column
 * @method array findByCodePrenomReferent(int $CODE_PRENOM_REFERENT) Return TReferent objects filtered by the CODE_PRENOM_REFERENT column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTReferentQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTReferentQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TReferent', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TReferentQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TReferentQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TReferentQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TReferentQuery) {
            return $criteria;
        }
        $query = new TReferentQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TReferent|TReferent[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TReferentPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TReferentPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TReferent A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdReferent($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TReferent A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_REFERENT`, `ID_ENTITE`, `CODE_NOM_REFERENT`, `CODE_PRENOM_REFERENT` FROM `T_REFERENT` WHERE `ID_REFERENT` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TReferent();
            $obj->hydrate($row);
            TReferentPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TReferent|TReferent[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TReferent[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TReferentPeer::ID_REFERENT, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TReferentPeer::ID_REFERENT, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_REFERENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdReferent(1234); // WHERE ID_REFERENT = 1234
     * $query->filterByIdReferent(array(12, 34)); // WHERE ID_REFERENT IN (12, 34)
     * $query->filterByIdReferent(array('min' => 12)); // WHERE ID_REFERENT >= 12
     * $query->filterByIdReferent(array('max' => 12)); // WHERE ID_REFERENT <= 12
     * </code>
     *
     * @param     mixed $idReferent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function filterByIdReferent($idReferent = null, $comparison = null)
    {
        if (is_array($idReferent)) {
            $useMinMax = false;
            if (isset($idReferent['min'])) {
                $this->addUsingAlias(TReferentPeer::ID_REFERENT, $idReferent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idReferent['max'])) {
                $this->addUsingAlias(TReferentPeer::ID_REFERENT, $idReferent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TReferentPeer::ID_REFERENT, $idReferent, $comparison);
    }

    /**
     * Filter the query on the ID_ENTITE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEntite(1234); // WHERE ID_ENTITE = 1234
     * $query->filterByIdEntite(array(12, 34)); // WHERE ID_ENTITE IN (12, 34)
     * $query->filterByIdEntite(array('min' => 12)); // WHERE ID_ENTITE >= 12
     * $query->filterByIdEntite(array('max' => 12)); // WHERE ID_ENTITE <= 12
     * </code>
     *
     * @see       filterByTEntite()
     *
     * @param     mixed $idEntite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function filterByIdEntite($idEntite = null, $comparison = null)
    {
        if (is_array($idEntite)) {
            $useMinMax = false;
            if (isset($idEntite['min'])) {
                $this->addUsingAlias(TReferentPeer::ID_ENTITE, $idEntite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEntite['max'])) {
                $this->addUsingAlias(TReferentPeer::ID_ENTITE, $idEntite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TReferentPeer::ID_ENTITE, $idEntite, $comparison);
    }

    /**
     * Filter the query on the CODE_NOM_REFERENT column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeNomReferent(1234); // WHERE CODE_NOM_REFERENT = 1234
     * $query->filterByCodeNomReferent(array(12, 34)); // WHERE CODE_NOM_REFERENT IN (12, 34)
     * $query->filterByCodeNomReferent(array('min' => 12)); // WHERE CODE_NOM_REFERENT >= 12
     * $query->filterByCodeNomReferent(array('max' => 12)); // WHERE CODE_NOM_REFERENT <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeNomReferent()
     *
     * @param     mixed $codeNomReferent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function filterByCodeNomReferent($codeNomReferent = null, $comparison = null)
    {
        if (is_array($codeNomReferent)) {
            $useMinMax = false;
            if (isset($codeNomReferent['min'])) {
                $this->addUsingAlias(TReferentPeer::CODE_NOM_REFERENT, $codeNomReferent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeNomReferent['max'])) {
                $this->addUsingAlias(TReferentPeer::CODE_NOM_REFERENT, $codeNomReferent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TReferentPeer::CODE_NOM_REFERENT, $codeNomReferent, $comparison);
    }

    /**
     * Filter the query on the CODE_PRENOM_REFERENT column
     *
     * Example usage:
     * <code>
     * $query->filterByCodePrenomReferent(1234); // WHERE CODE_PRENOM_REFERENT = 1234
     * $query->filterByCodePrenomReferent(array(12, 34)); // WHERE CODE_PRENOM_REFERENT IN (12, 34)
     * $query->filterByCodePrenomReferent(array('min' => 12)); // WHERE CODE_PRENOM_REFERENT >= 12
     * $query->filterByCodePrenomReferent(array('max' => 12)); // WHERE CODE_PRENOM_REFERENT <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodePrenomReferent()
     *
     * @param     mixed $codePrenomReferent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function filterByCodePrenomReferent($codePrenomReferent = null, $comparison = null)
    {
        if (is_array($codePrenomReferent)) {
            $useMinMax = false;
            if (isset($codePrenomReferent['min'])) {
                $this->addUsingAlias(TReferentPeer::CODE_PRENOM_REFERENT, $codePrenomReferent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codePrenomReferent['max'])) {
                $this->addUsingAlias(TReferentPeer::CODE_PRENOM_REFERENT, $codePrenomReferent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TReferentPeer::CODE_PRENOM_REFERENT, $codePrenomReferent, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TReferentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeNomReferent($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TReferentPeer::CODE_NOM_REFERENT, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TReferentPeer::CODE_NOM_REFERENT, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeNomReferent() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeNomReferent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeNomReferent($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeNomReferent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeNomReferent');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeNomReferent relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeNomReferentQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeNomReferent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeNomReferent', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TReferentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodePrenomReferent($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TReferentPeer::CODE_PRENOM_REFERENT, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TReferentPeer::CODE_PRENOM_REFERENT, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodePrenomReferent() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodePrenomReferent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodePrenomReferent($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodePrenomReferent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodePrenomReferent');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodePrenomReferent relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodePrenomReferentQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodePrenomReferent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodePrenomReferent', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TEntite object
     *
     * @param   TEntite|PropelObjectCollection $tEntite The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TReferentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEntite($tEntite, $comparison = null)
    {
        if ($tEntite instanceof TEntite) {
            return $this
                ->addUsingAlias(TReferentPeer::ID_ENTITE, $tEntite->getIdEntite(), $comparison);
        } elseif ($tEntite instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TReferentPeer::ID_ENTITE, $tEntite->toKeyValue('PrimaryKey', 'IdEntite'), $comparison);
        } else {
            throw new PropelException('filterByTEntite() only accepts arguments of type TEntite or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEntite relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function joinTEntite($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEntite');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEntite');
        }

        return $this;
    }

    /**
     * Use the TEntite relation TEntite object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEntiteQuery A secondary query class using the current class as primary query
     */
    public function useTEntiteQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTEntite($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEntite', 'TEntiteQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TReferentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVous($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TReferentPeer::ID_REFERENT, $tRendezVous->getIdReferent(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVous() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVous relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function joinTRendezVous($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVous');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVous');
        }

        return $this;
    }

    /**
     * Use the TRendezVous relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRendezVous($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVous', 'TRendezVousQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TReferent $tReferent Object to remove from the list of results
     *
     * @return TReferentQuery The current query, for fluid interface
     */
    public function prune($tReferent = null)
    {
        if ($tReferent) {
            $this->addUsingAlias(TReferentPeer::ID_REFERENT, $tReferent->getIdReferent(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
