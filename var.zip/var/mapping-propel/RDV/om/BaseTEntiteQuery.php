<?php


/**
 * Base class that represents a query for the 'T_ENTITE' table.
 *
 *
 *
 * @method TEntiteQuery orderByIdEntite($order = Criteria::ASC) Order by the ID_ENTITE column
 * @method TEntiteQuery orderByIdEntiteParent($order = Criteria::ASC) Order by the ID_ENTITE_PARENT column
 * @method TEntiteQuery orderByCodeLibelle($order = Criteria::ASC) Order by the CODE_LIBELLE column
 * @method TEntiteQuery orderByNiveau($order = Criteria::ASC) Order by the NIVEAU column
 *
 * @method TEntiteQuery groupByIdEntite() Group by the ID_ENTITE column
 * @method TEntiteQuery groupByIdEntiteParent() Group by the ID_ENTITE_PARENT column
 * @method TEntiteQuery groupByCodeLibelle() Group by the CODE_LIBELLE column
 * @method TEntiteQuery groupByNiveau() Group by the NIVEAU column
 *
 * @method TEntiteQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TEntiteQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TEntiteQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TEntiteQuery leftJoinTTraduction($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraduction relation
 * @method TEntiteQuery rightJoinTTraduction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraduction relation
 * @method TEntiteQuery innerJoinTTraduction($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraduction relation
 *
 * @method TEntiteQuery leftJoinTEntiteRelatedByIdEntiteParent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEntiteRelatedByIdEntiteParent relation
 * @method TEntiteQuery rightJoinTEntiteRelatedByIdEntiteParent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEntiteRelatedByIdEntiteParent relation
 * @method TEntiteQuery innerJoinTEntiteRelatedByIdEntiteParent($relationAlias = null) Adds a INNER JOIN clause to the query using the TEntiteRelatedByIdEntiteParent relation
 *
 * @method TEntiteQuery leftJoinTEntiteRelatedByIdEntite($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEntiteRelatedByIdEntite relation
 * @method TEntiteQuery rightJoinTEntiteRelatedByIdEntite($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEntiteRelatedByIdEntite relation
 * @method TEntiteQuery innerJoinTEntiteRelatedByIdEntite($relationAlias = null) Adds a INNER JOIN clause to the query using the TEntiteRelatedByIdEntite relation
 *
 * @method TEntiteQuery leftJoinTEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissement relation
 * @method TEntiteQuery rightJoinTEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissement relation
 * @method TEntiteQuery innerJoinTEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissement relation
 *
 * @method TEntiteQuery leftJoinTOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisation relation
 * @method TEntiteQuery rightJoinTOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisation relation
 * @method TEntiteQuery innerJoinTOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisation relation
 *
 * @method TEntiteQuery leftJoinTReferent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferent relation
 * @method TEntiteQuery rightJoinTReferent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferent relation
 * @method TEntiteQuery innerJoinTReferent($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferent relation
 *
 * @method TEntite findOne(PropelPDO $con = null) Return the first TEntite matching the query
 * @method TEntite findOneOrCreate(PropelPDO $con = null) Return the first TEntite matching the query, or a new TEntite object populated from the query conditions when no match is found
 *
 * @method TEntite findOneByIdEntiteParent(int $ID_ENTITE_PARENT) Return the first TEntite filtered by the ID_ENTITE_PARENT column
 * @method TEntite findOneByCodeLibelle(int $CODE_LIBELLE) Return the first TEntite filtered by the CODE_LIBELLE column
 * @method TEntite findOneByNiveau(int $NIVEAU) Return the first TEntite filtered by the NIVEAU column
 *
 * @method array findByIdEntite(int $ID_ENTITE) Return TEntite objects filtered by the ID_ENTITE column
 * @method array findByIdEntiteParent(int $ID_ENTITE_PARENT) Return TEntite objects filtered by the ID_ENTITE_PARENT column
 * @method array findByCodeLibelle(int $CODE_LIBELLE) Return TEntite objects filtered by the CODE_LIBELLE column
 * @method array findByNiveau(int $NIVEAU) Return TEntite objects filtered by the NIVEAU column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTEntiteQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTEntiteQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TEntite', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TEntiteQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TEntiteQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TEntiteQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TEntiteQuery) {
            return $criteria;
        }
        $query = new TEntiteQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TEntite|TEntite[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TEntitePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TEntitePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TEntite A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdEntite($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TEntite A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_ENTITE`, `ID_ENTITE_PARENT`, `CODE_LIBELLE`, `NIVEAU` FROM `T_ENTITE` WHERE `ID_ENTITE` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TEntite();
            $obj->hydrate($row);
            TEntitePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TEntite|TEntite[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TEntite[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TEntitePeer::ID_ENTITE, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TEntitePeer::ID_ENTITE, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_ENTITE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEntite(1234); // WHERE ID_ENTITE = 1234
     * $query->filterByIdEntite(array(12, 34)); // WHERE ID_ENTITE IN (12, 34)
     * $query->filterByIdEntite(array('min' => 12)); // WHERE ID_ENTITE >= 12
     * $query->filterByIdEntite(array('max' => 12)); // WHERE ID_ENTITE <= 12
     * </code>
     *
     * @param     mixed $idEntite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function filterByIdEntite($idEntite = null, $comparison = null)
    {
        if (is_array($idEntite)) {
            $useMinMax = false;
            if (isset($idEntite['min'])) {
                $this->addUsingAlias(TEntitePeer::ID_ENTITE, $idEntite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEntite['max'])) {
                $this->addUsingAlias(TEntitePeer::ID_ENTITE, $idEntite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEntitePeer::ID_ENTITE, $idEntite, $comparison);
    }

    /**
     * Filter the query on the ID_ENTITE_PARENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEntiteParent(1234); // WHERE ID_ENTITE_PARENT = 1234
     * $query->filterByIdEntiteParent(array(12, 34)); // WHERE ID_ENTITE_PARENT IN (12, 34)
     * $query->filterByIdEntiteParent(array('min' => 12)); // WHERE ID_ENTITE_PARENT >= 12
     * $query->filterByIdEntiteParent(array('max' => 12)); // WHERE ID_ENTITE_PARENT <= 12
     * </code>
     *
     * @see       filterByTEntiteRelatedByIdEntiteParent()
     *
     * @param     mixed $idEntiteParent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function filterByIdEntiteParent($idEntiteParent = null, $comparison = null)
    {
        if (is_array($idEntiteParent)) {
            $useMinMax = false;
            if (isset($idEntiteParent['min'])) {
                $this->addUsingAlias(TEntitePeer::ID_ENTITE_PARENT, $idEntiteParent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEntiteParent['max'])) {
                $this->addUsingAlias(TEntitePeer::ID_ENTITE_PARENT, $idEntiteParent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEntitePeer::ID_ENTITE_PARENT, $idEntiteParent, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelle(1234); // WHERE CODE_LIBELLE = 1234
     * $query->filterByCodeLibelle(array(12, 34)); // WHERE CODE_LIBELLE IN (12, 34)
     * $query->filterByCodeLibelle(array('min' => 12)); // WHERE CODE_LIBELLE >= 12
     * $query->filterByCodeLibelle(array('max' => 12)); // WHERE CODE_LIBELLE <= 12
     * </code>
     *
     * @see       filterByTTraduction()
     *
     * @param     mixed $codeLibelle The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function filterByCodeLibelle($codeLibelle = null, $comparison = null)
    {
        if (is_array($codeLibelle)) {
            $useMinMax = false;
            if (isset($codeLibelle['min'])) {
                $this->addUsingAlias(TEntitePeer::CODE_LIBELLE, $codeLibelle['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelle['max'])) {
                $this->addUsingAlias(TEntitePeer::CODE_LIBELLE, $codeLibelle['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEntitePeer::CODE_LIBELLE, $codeLibelle, $comparison);
    }

    /**
     * Filter the query on the NIVEAU column
     *
     * Example usage:
     * <code>
     * $query->filterByNiveau(1234); // WHERE NIVEAU = 1234
     * $query->filterByNiveau(array(12, 34)); // WHERE NIVEAU IN (12, 34)
     * $query->filterByNiveau(array('min' => 12)); // WHERE NIVEAU >= 12
     * $query->filterByNiveau(array('max' => 12)); // WHERE NIVEAU <= 12
     * </code>
     *
     * @param     mixed $niveau The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function filterByNiveau($niveau = null, $comparison = null)
    {
        if (is_array($niveau)) {
            $useMinMax = false;
            if (isset($niveau['min'])) {
                $this->addUsingAlias(TEntitePeer::NIVEAU, $niveau['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($niveau['max'])) {
                $this->addUsingAlias(TEntitePeer::NIVEAU, $niveau['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TEntitePeer::NIVEAU, $niveau, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEntiteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraduction($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TEntitePeer::CODE_LIBELLE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEntitePeer::CODE_LIBELLE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraduction() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraduction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function joinTTraduction($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraduction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraduction');
        }

        return $this;
    }

    /**
     * Use the TTraduction relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraduction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraduction', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TEntite object
     *
     * @param   TEntite|PropelObjectCollection $tEntite The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEntiteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEntiteRelatedByIdEntiteParent($tEntite, $comparison = null)
    {
        if ($tEntite instanceof TEntite) {
            return $this
                ->addUsingAlias(TEntitePeer::ID_ENTITE_PARENT, $tEntite->getIdEntite(), $comparison);
        } elseif ($tEntite instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TEntitePeer::ID_ENTITE_PARENT, $tEntite->toKeyValue('PrimaryKey', 'IdEntite'), $comparison);
        } else {
            throw new PropelException('filterByTEntiteRelatedByIdEntiteParent() only accepts arguments of type TEntite or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEntiteRelatedByIdEntiteParent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function joinTEntiteRelatedByIdEntiteParent($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEntiteRelatedByIdEntiteParent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEntiteRelatedByIdEntiteParent');
        }

        return $this;
    }

    /**
     * Use the TEntiteRelatedByIdEntiteParent relation TEntite object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEntiteQuery A secondary query class using the current class as primary query
     */
    public function useTEntiteRelatedByIdEntiteParentQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEntiteRelatedByIdEntiteParent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEntiteRelatedByIdEntiteParent', 'TEntiteQuery');
    }

    /**
     * Filter the query by a related TEntite object
     *
     * @param   TEntite|PropelObjectCollection $tEntite  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEntiteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEntiteRelatedByIdEntite($tEntite, $comparison = null)
    {
        if ($tEntite instanceof TEntite) {
            return $this
                ->addUsingAlias(TEntitePeer::ID_ENTITE, $tEntite->getIdEntiteParent(), $comparison);
        } elseif ($tEntite instanceof PropelObjectCollection) {
            return $this
                ->useTEntiteRelatedByIdEntiteQuery()
                ->filterByPrimaryKeys($tEntite->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTEntiteRelatedByIdEntite() only accepts arguments of type TEntite or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEntiteRelatedByIdEntite relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function joinTEntiteRelatedByIdEntite($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEntiteRelatedByIdEntite');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEntiteRelatedByIdEntite');
        }

        return $this;
    }

    /**
     * Use the TEntiteRelatedByIdEntite relation TEntite object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEntiteQuery A secondary query class using the current class as primary query
     */
    public function useTEntiteRelatedByIdEntiteQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEntiteRelatedByIdEntite($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEntiteRelatedByIdEntite', 'TEntiteQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEntiteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissement($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TEntitePeer::ID_ENTITE, $tEtablissement->getIdEntite(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            return $this
                ->useTEtablissementQuery()
                ->filterByPrimaryKeys($tEtablissement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTEtablissement() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function joinTEtablissement($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissement');
        }

        return $this;
    }

    /**
     * Use the TEtablissement relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissement', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEntiteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TEntitePeer::ID_ENTITE, $tOrganisation->getIdEntite(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationQuery()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function joinTOrganisation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TReferent object
     *
     * @param   TReferent|PropelObjectCollection $tReferent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TEntiteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferent($tReferent, $comparison = null)
    {
        if ($tReferent instanceof TReferent) {
            return $this
                ->addUsingAlias(TEntitePeer::ID_ENTITE, $tReferent->getIdEntite(), $comparison);
        } elseif ($tReferent instanceof PropelObjectCollection) {
            return $this
                ->useTReferentQuery()
                ->filterByPrimaryKeys($tReferent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTReferent() only accepts arguments of type TReferent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function joinTReferent($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferent');
        }

        return $this;
    }

    /**
     * Use the TReferent relation TReferent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentQuery A secondary query class using the current class as primary query
     */
    public function useTReferentQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTReferent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferent', 'TReferentQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TEntite $tEntite Object to remove from the list of results
     *
     * @return TEntiteQuery The current query, for fluid interface
     */
    public function prune($tEntite = null)
    {
        if ($tEntite) {
            $this->addUsingAlias(TEntitePeer::ID_ENTITE, $tEntite->getIdEntite(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
