<?php


/**
 * Base class that represents a query for the 'T_VALEUR_REFERENTIEL' table.
 *
 *
 *
 * @method TValeurReferentielQuery orderByIdValeurReferentiel($order = Criteria::ASC) Order by the ID_VALEUR_REFERENTIEL column
 * @method TValeurReferentielQuery orderByCodeLibelleValeurReferentiel($order = Criteria::ASC) Order by the CODE_LIBELLE_VALEUR_REFERENTIEL column
 * @method TValeurReferentielQuery orderByIdReferentiel($order = Criteria::ASC) Order by the ID_REFERENTIEL column
 * @method TValeurReferentielQuery orderByIdOrganisation($order = Criteria::ASC) Order by the ID_ORGANISATION column
 *
 * @method TValeurReferentielQuery groupByIdValeurReferentiel() Group by the ID_VALEUR_REFERENTIEL column
 * @method TValeurReferentielQuery groupByCodeLibelleValeurReferentiel() Group by the CODE_LIBELLE_VALEUR_REFERENTIEL column
 * @method TValeurReferentielQuery groupByIdReferentiel() Group by the ID_REFERENTIEL column
 * @method TValeurReferentielQuery groupByIdOrganisation() Group by the ID_ORGANISATION column
 *
 * @method TValeurReferentielQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TValeurReferentielQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TValeurReferentielQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TValeurReferentielQuery leftJoinTTraduction($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraduction relation
 * @method TValeurReferentielQuery rightJoinTTraduction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraduction relation
 * @method TValeurReferentielQuery innerJoinTTraduction($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraduction relation
 *
 * @method TValeurReferentielQuery leftJoinTOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisation relation
 * @method TValeurReferentielQuery rightJoinTOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisation relation
 * @method TValeurReferentielQuery innerJoinTOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisation relation
 *
 * @method TValeurReferentielQuery leftJoinTReferentiel($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferentiel relation
 * @method TValeurReferentielQuery rightJoinTReferentiel($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferentiel relation
 * @method TValeurReferentielQuery innerJoinTReferentiel($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferentiel relation
 *
 * @method TValeurReferentielQuery leftJoinTCitoyenRelatedByIdRef1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TCitoyenRelatedByIdRef1 relation
 * @method TValeurReferentielQuery rightJoinTCitoyenRelatedByIdRef1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TCitoyenRelatedByIdRef1 relation
 * @method TValeurReferentielQuery innerJoinTCitoyenRelatedByIdRef1($relationAlias = null) Adds a INNER JOIN clause to the query using the TCitoyenRelatedByIdRef1 relation
 *
 * @method TValeurReferentielQuery leftJoinTCitoyenRelatedByIdRef2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TCitoyenRelatedByIdRef2 relation
 * @method TValeurReferentielQuery rightJoinTCitoyenRelatedByIdRef2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TCitoyenRelatedByIdRef2 relation
 * @method TValeurReferentielQuery innerJoinTCitoyenRelatedByIdRef2($relationAlias = null) Adds a INNER JOIN clause to the query using the TCitoyenRelatedByIdRef2 relation
 *
 * @method TValeurReferentielQuery leftJoinTCitoyenRelatedByIdRef3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TCitoyenRelatedByIdRef3 relation
 * @method TValeurReferentielQuery rightJoinTCitoyenRelatedByIdRef3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TCitoyenRelatedByIdRef3 relation
 * @method TValeurReferentielQuery innerJoinTCitoyenRelatedByIdRef3($relationAlias = null) Adds a INNER JOIN clause to the query using the TCitoyenRelatedByIdRef3 relation
 *
 * @method TValeurReferentielQuery leftJoinTRendezVous($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVous relation
 * @method TValeurReferentielQuery rightJoinTRendezVous($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVous relation
 * @method TValeurReferentielQuery innerJoinTRendezVous($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVous relation
 *
 * @method TValeurReferentiel findOne(PropelPDO $con = null) Return the first TValeurReferentiel matching the query
 * @method TValeurReferentiel findOneOrCreate(PropelPDO $con = null) Return the first TValeurReferentiel matching the query, or a new TValeurReferentiel object populated from the query conditions when no match is found
 *
 * @method TValeurReferentiel findOneByCodeLibelleValeurReferentiel(int $CODE_LIBELLE_VALEUR_REFERENTIEL) Return the first TValeurReferentiel filtered by the CODE_LIBELLE_VALEUR_REFERENTIEL column
 * @method TValeurReferentiel findOneByIdReferentiel(int $ID_REFERENTIEL) Return the first TValeurReferentiel filtered by the ID_REFERENTIEL column
 * @method TValeurReferentiel findOneByIdOrganisation(int $ID_ORGANISATION) Return the first TValeurReferentiel filtered by the ID_ORGANISATION column
 *
 * @method array findByIdValeurReferentiel(int $ID_VALEUR_REFERENTIEL) Return TValeurReferentiel objects filtered by the ID_VALEUR_REFERENTIEL column
 * @method array findByCodeLibelleValeurReferentiel(int $CODE_LIBELLE_VALEUR_REFERENTIEL) Return TValeurReferentiel objects filtered by the CODE_LIBELLE_VALEUR_REFERENTIEL column
 * @method array findByIdReferentiel(int $ID_REFERENTIEL) Return TValeurReferentiel objects filtered by the ID_REFERENTIEL column
 * @method array findByIdOrganisation(int $ID_ORGANISATION) Return TValeurReferentiel objects filtered by the ID_ORGANISATION column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTValeurReferentielQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTValeurReferentielQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TValeurReferentiel', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TValeurReferentielQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TValeurReferentielQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TValeurReferentielQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TValeurReferentielQuery) {
            return $criteria;
        }
        $query = new TValeurReferentielQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TValeurReferentiel|TValeurReferentiel[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TValeurReferentielPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TValeurReferentielPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TValeurReferentiel A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdValeurReferentiel($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TValeurReferentiel A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_VALEUR_REFERENTIEL`, `CODE_LIBELLE_VALEUR_REFERENTIEL`, `ID_REFERENTIEL`, `ID_ORGANISATION` FROM `T_VALEUR_REFERENTIEL` WHERE `ID_VALEUR_REFERENTIEL` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TValeurReferentiel();
            $obj->hydrate($row);
            TValeurReferentielPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TValeurReferentiel|TValeurReferentiel[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TValeurReferentiel[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_VALEUR_REFERENTIEL column
     *
     * Example usage:
     * <code>
     * $query->filterByIdValeurReferentiel(1234); // WHERE ID_VALEUR_REFERENTIEL = 1234
     * $query->filterByIdValeurReferentiel(array(12, 34)); // WHERE ID_VALEUR_REFERENTIEL IN (12, 34)
     * $query->filterByIdValeurReferentiel(array('min' => 12)); // WHERE ID_VALEUR_REFERENTIEL >= 12
     * $query->filterByIdValeurReferentiel(array('max' => 12)); // WHERE ID_VALEUR_REFERENTIEL <= 12
     * </code>
     *
     * @param     mixed $idValeurReferentiel The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function filterByIdValeurReferentiel($idValeurReferentiel = null, $comparison = null)
    {
        if (is_array($idValeurReferentiel)) {
            $useMinMax = false;
            if (isset($idValeurReferentiel['min'])) {
                $this->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $idValeurReferentiel['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idValeurReferentiel['max'])) {
                $this->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $idValeurReferentiel['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $idValeurReferentiel, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_VALEUR_REFERENTIEL column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleValeurReferentiel(1234); // WHERE CODE_LIBELLE_VALEUR_REFERENTIEL = 1234
     * $query->filterByCodeLibelleValeurReferentiel(array(12, 34)); // WHERE CODE_LIBELLE_VALEUR_REFERENTIEL IN (12, 34)
     * $query->filterByCodeLibelleValeurReferentiel(array('min' => 12)); // WHERE CODE_LIBELLE_VALEUR_REFERENTIEL >= 12
     * $query->filterByCodeLibelleValeurReferentiel(array('max' => 12)); // WHERE CODE_LIBELLE_VALEUR_REFERENTIEL <= 12
     * </code>
     *
     * @see       filterByTTraduction()
     *
     * @param     mixed $codeLibelleValeurReferentiel The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleValeurReferentiel($codeLibelleValeurReferentiel = null, $comparison = null)
    {
        if (is_array($codeLibelleValeurReferentiel)) {
            $useMinMax = false;
            if (isset($codeLibelleValeurReferentiel['min'])) {
                $this->addUsingAlias(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL, $codeLibelleValeurReferentiel['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleValeurReferentiel['max'])) {
                $this->addUsingAlias(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL, $codeLibelleValeurReferentiel['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL, $codeLibelleValeurReferentiel, $comparison);
    }

    /**
     * Filter the query on the ID_REFERENTIEL column
     *
     * Example usage:
     * <code>
     * $query->filterByIdReferentiel(1234); // WHERE ID_REFERENTIEL = 1234
     * $query->filterByIdReferentiel(array(12, 34)); // WHERE ID_REFERENTIEL IN (12, 34)
     * $query->filterByIdReferentiel(array('min' => 12)); // WHERE ID_REFERENTIEL >= 12
     * $query->filterByIdReferentiel(array('max' => 12)); // WHERE ID_REFERENTIEL <= 12
     * </code>
     *
     * @see       filterByTReferentiel()
     *
     * @param     mixed $idReferentiel The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function filterByIdReferentiel($idReferentiel = null, $comparison = null)
    {
        if (is_array($idReferentiel)) {
            $useMinMax = false;
            if (isset($idReferentiel['min'])) {
                $this->addUsingAlias(TValeurReferentielPeer::ID_REFERENTIEL, $idReferentiel['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idReferentiel['max'])) {
                $this->addUsingAlias(TValeurReferentielPeer::ID_REFERENTIEL, $idReferentiel['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TValeurReferentielPeer::ID_REFERENTIEL, $idReferentiel, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisation(1234); // WHERE ID_ORGANISATION = 1234
     * $query->filterByIdOrganisation(array(12, 34)); // WHERE ID_ORGANISATION IN (12, 34)
     * $query->filterByIdOrganisation(array('min' => 12)); // WHERE ID_ORGANISATION >= 12
     * $query->filterByIdOrganisation(array('max' => 12)); // WHERE ID_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTOrganisation()
     *
     * @param     mixed $idOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function filterByIdOrganisation($idOrganisation = null, $comparison = null)
    {
        if (is_array($idOrganisation)) {
            $useMinMax = false;
            if (isset($idOrganisation['min'])) {
                $this->addUsingAlias(TValeurReferentielPeer::ID_ORGANISATION, $idOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisation['max'])) {
                $this->addUsingAlias(TValeurReferentielPeer::ID_ORGANISATION, $idOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TValeurReferentielPeer::ID_ORGANISATION, $idOrganisation, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TValeurReferentielQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraduction($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraduction() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraduction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function joinTTraduction($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraduction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraduction');
        }

        return $this;
    }

    /**
     * Use the TTraduction relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraduction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraduction', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TValeurReferentielQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_ORGANISATION, $tOrganisation->getIdOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_ORGANISATION, $tOrganisation->toKeyValue('PrimaryKey', 'IdOrganisation'), $comparison);
        } else {
            throw new PropelException('filterByTOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function joinTOrganisation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TReferentiel object
     *
     * @param   TReferentiel|PropelObjectCollection $tReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TValeurReferentielQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferentiel($tReferentiel, $comparison = null)
    {
        if ($tReferentiel instanceof TReferentiel) {
            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_REFERENTIEL, $tReferentiel->getIdReferentiel(), $comparison);
        } elseif ($tReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_REFERENTIEL, $tReferentiel->toKeyValue('PrimaryKey', 'IdReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTReferentiel() only accepts arguments of type TReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferentiel relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function joinTReferentiel($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferentiel');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferentiel');
        }

        return $this;
    }

    /**
     * Use the TReferentiel relation TReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTReferentielQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTReferentiel($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferentiel', 'TReferentielQuery');
    }

    /**
     * Filter the query by a related TCitoyen object
     *
     * @param   TCitoyen|PropelObjectCollection $tCitoyen  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TValeurReferentielQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTCitoyenRelatedByIdRef1($tCitoyen, $comparison = null)
    {
        if ($tCitoyen instanceof TCitoyen) {
            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $tCitoyen->getIdRef1(), $comparison);
        } elseif ($tCitoyen instanceof PropelObjectCollection) {
            return $this
                ->useTCitoyenRelatedByIdRef1Query()
                ->filterByPrimaryKeys($tCitoyen->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTCitoyenRelatedByIdRef1() only accepts arguments of type TCitoyen or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TCitoyenRelatedByIdRef1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function joinTCitoyenRelatedByIdRef1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TCitoyenRelatedByIdRef1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TCitoyenRelatedByIdRef1');
        }

        return $this;
    }

    /**
     * Use the TCitoyenRelatedByIdRef1 relation TCitoyen object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TCitoyenQuery A secondary query class using the current class as primary query
     */
    public function useTCitoyenRelatedByIdRef1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTCitoyenRelatedByIdRef1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TCitoyenRelatedByIdRef1', 'TCitoyenQuery');
    }

    /**
     * Filter the query by a related TCitoyen object
     *
     * @param   TCitoyen|PropelObjectCollection $tCitoyen  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TValeurReferentielQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTCitoyenRelatedByIdRef2($tCitoyen, $comparison = null)
    {
        if ($tCitoyen instanceof TCitoyen) {
            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $tCitoyen->getIdRef2(), $comparison);
        } elseif ($tCitoyen instanceof PropelObjectCollection) {
            return $this
                ->useTCitoyenRelatedByIdRef2Query()
                ->filterByPrimaryKeys($tCitoyen->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTCitoyenRelatedByIdRef2() only accepts arguments of type TCitoyen or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TCitoyenRelatedByIdRef2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function joinTCitoyenRelatedByIdRef2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TCitoyenRelatedByIdRef2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TCitoyenRelatedByIdRef2');
        }

        return $this;
    }

    /**
     * Use the TCitoyenRelatedByIdRef2 relation TCitoyen object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TCitoyenQuery A secondary query class using the current class as primary query
     */
    public function useTCitoyenRelatedByIdRef2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTCitoyenRelatedByIdRef2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TCitoyenRelatedByIdRef2', 'TCitoyenQuery');
    }

    /**
     * Filter the query by a related TCitoyen object
     *
     * @param   TCitoyen|PropelObjectCollection $tCitoyen  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TValeurReferentielQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTCitoyenRelatedByIdRef3($tCitoyen, $comparison = null)
    {
        if ($tCitoyen instanceof TCitoyen) {
            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $tCitoyen->getIdRef3(), $comparison);
        } elseif ($tCitoyen instanceof PropelObjectCollection) {
            return $this
                ->useTCitoyenRelatedByIdRef3Query()
                ->filterByPrimaryKeys($tCitoyen->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTCitoyenRelatedByIdRef3() only accepts arguments of type TCitoyen or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TCitoyenRelatedByIdRef3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function joinTCitoyenRelatedByIdRef3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TCitoyenRelatedByIdRef3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TCitoyenRelatedByIdRef3');
        }

        return $this;
    }

    /**
     * Use the TCitoyenRelatedByIdRef3 relation TCitoyen object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TCitoyenQuery A secondary query class using the current class as primary query
     */
    public function useTCitoyenRelatedByIdRef3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTCitoyenRelatedByIdRef3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TCitoyenRelatedByIdRef3', 'TCitoyenQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TValeurReferentielQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVous($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $tRendezVous->getIdValeurReferentiel(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVous() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVous relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function joinTRendezVous($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVous');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVous');
        }

        return $this;
    }

    /**
     * Use the TRendezVous relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRendezVous($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVous', 'TRendezVousQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TValeurReferentiel $tValeurReferentiel Object to remove from the list of results
     *
     * @return TValeurReferentielQuery The current query, for fluid interface
     */
    public function prune($tValeurReferentiel = null)
    {
        if ($tValeurReferentiel) {
            $this->addUsingAlias(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $tValeurReferentiel->getIdValeurReferentiel(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
