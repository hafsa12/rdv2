<?php


/**
 * Base class that represents a query for the 'T_ORGANISATION' table.
 *
 *
 *
 * @method TOrganisationQuery orderByIdOrganisation($order = Criteria::ASC) Order by the ID_ORGANISATION column
 * @method TOrganisationQuery orderByCodeDenominationOrganisation($order = Criteria::ASC) Order by the CODE_DENOMINATION_ORGANISATION column
 * @method TOrganisationQuery orderByCodeAdresseOrganisation($order = Criteria::ASC) Order by the CODE_ADRESSE_ORGANISATION column
 * @method TOrganisationQuery orderByCodePostal($order = Criteria::ASC) Order by the CODE_POSTAL column
 * @method TOrganisationQuery orderByTelephoneOrganisation($order = Criteria::ASC) Order by the TELEPHONE_ORGANISATION column
 * @method TOrganisationQuery orderByMailOrganisation($order = Criteria::ASC) Order by the MAIL_ORGANISATION column
 * @method TOrganisationQuery orderByCodeDescriptionOrganisation($order = Criteria::ASC) Order by the CODE_DESCRIPTION_ORGANISATION column
 * @method TOrganisationQuery orderByCodeTitreBienvenue($order = Criteria::ASC) Order by the CODE_TITRE_BIENVENUE column
 * @method TOrganisationQuery orderByCodeMessageBienvenue($order = Criteria::ASC) Order by the CODE_MESSAGE_BIENVENUE column
 * @method TOrganisationQuery orderByIdEntite($order = Criteria::ASC) Order by the ID_ENTITE column
 * @method TOrganisationQuery orderByTypePrestation($order = Criteria::ASC) Order by the TYPE_PRESTATION column
 * @method TOrganisationQuery orderByCodeLibelleLien1($order = Criteria::ASC) Order by the CODE_LIBELLE_LIEN1 column
 * @method TOrganisationQuery orderByUrlLien1($order = Criteria::ASC) Order by the URL_LIEN1 column
 * @method TOrganisationQuery orderByCodeLibelleLien2($order = Criteria::ASC) Order by the CODE_LIBELLE_LIEN2 column
 * @method TOrganisationQuery orderByUrlLien2($order = Criteria::ASC) Order by the URL_LIEN2 column
 * @method TOrganisationQuery orderByCodeLibelleLien3($order = Criteria::ASC) Order by the CODE_LIBELLE_LIEN3 column
 * @method TOrganisationQuery orderByUrlLien3($order = Criteria::ASC) Order by the URL_LIEN3 column
 * @method TOrganisationQuery orderByAcronyme($order = Criteria::ASC) Order by the ACRONYME column
 * @method TOrganisationQuery orderByNomDomaine($order = Criteria::ASC) Order by the NOM_DOMAINE column
 * @method TOrganisationQuery orderByIdParametreForm($order = Criteria::ASC) Order by the ID_PARAMETRE_FORM column
 * @method TOrganisationQuery orderByRessource($order = Criteria::ASC) Order by the RESSOURCE column
 *
 * @method TOrganisationQuery groupByIdOrganisation() Group by the ID_ORGANISATION column
 * @method TOrganisationQuery groupByCodeDenominationOrganisation() Group by the CODE_DENOMINATION_ORGANISATION column
 * @method TOrganisationQuery groupByCodeAdresseOrganisation() Group by the CODE_ADRESSE_ORGANISATION column
 * @method TOrganisationQuery groupByCodePostal() Group by the CODE_POSTAL column
 * @method TOrganisationQuery groupByTelephoneOrganisation() Group by the TELEPHONE_ORGANISATION column
 * @method TOrganisationQuery groupByMailOrganisation() Group by the MAIL_ORGANISATION column
 * @method TOrganisationQuery groupByCodeDescriptionOrganisation() Group by the CODE_DESCRIPTION_ORGANISATION column
 * @method TOrganisationQuery groupByCodeTitreBienvenue() Group by the CODE_TITRE_BIENVENUE column
 * @method TOrganisationQuery groupByCodeMessageBienvenue() Group by the CODE_MESSAGE_BIENVENUE column
 * @method TOrganisationQuery groupByIdEntite() Group by the ID_ENTITE column
 * @method TOrganisationQuery groupByTypePrestation() Group by the TYPE_PRESTATION column
 * @method TOrganisationQuery groupByCodeLibelleLien1() Group by the CODE_LIBELLE_LIEN1 column
 * @method TOrganisationQuery groupByUrlLien1() Group by the URL_LIEN1 column
 * @method TOrganisationQuery groupByCodeLibelleLien2() Group by the CODE_LIBELLE_LIEN2 column
 * @method TOrganisationQuery groupByUrlLien2() Group by the URL_LIEN2 column
 * @method TOrganisationQuery groupByCodeLibelleLien3() Group by the CODE_LIBELLE_LIEN3 column
 * @method TOrganisationQuery groupByUrlLien3() Group by the URL_LIEN3 column
 * @method TOrganisationQuery groupByAcronyme() Group by the ACRONYME column
 * @method TOrganisationQuery groupByNomDomaine() Group by the NOM_DOMAINE column
 * @method TOrganisationQuery groupByIdParametreForm() Group by the ID_PARAMETRE_FORM column
 * @method TOrganisationQuery groupByRessource() Group by the RESSOURCE column
 *
 * @method TOrganisationQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TOrganisationQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TOrganisationQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeAdresseOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeAdresseOrganisation relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeAdresseOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeAdresseOrganisation relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeAdresseOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeAdresseOrganisation relation
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeDenominationOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeDenominationOrganisation relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeDenominationOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeDenominationOrganisation relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeDenominationOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeDenominationOrganisation relation
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeDescriptionOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeDescriptionOrganisation relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeDescriptionOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeDescriptionOrganisation relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeDescriptionOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeDescriptionOrganisation relation
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeLibelleLien1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien1 relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeLibelleLien1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien1 relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeLibelleLien1($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien1 relation
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeLibelleLien2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien2 relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeLibelleLien2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien2 relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeLibelleLien2($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien2 relation
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeLibelleLien3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien3 relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeLibelleLien3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien3 relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeLibelleLien3($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien3 relation
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeMessageBienvenue($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeMessageBienvenue relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeMessageBienvenue($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeMessageBienvenue relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeMessageBienvenue($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeMessageBienvenue relation
 *
 * @method TOrganisationQuery leftJoinTTraductionRelatedByCodeTitreBienvenue($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeTitreBienvenue relation
 * @method TOrganisationQuery rightJoinTTraductionRelatedByCodeTitreBienvenue($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeTitreBienvenue relation
 * @method TOrganisationQuery innerJoinTTraductionRelatedByCodeTitreBienvenue($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeTitreBienvenue relation
 *
 * @method TOrganisationQuery leftJoinTParametreForm($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreForm relation
 * @method TOrganisationQuery rightJoinTParametreForm($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreForm relation
 * @method TOrganisationQuery innerJoinTParametreForm($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreForm relation
 *
 * @method TOrganisationQuery leftJoinTEntite($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEntite relation
 * @method TOrganisationQuery rightJoinTEntite($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEntite relation
 * @method TOrganisationQuery innerJoinTEntite($relationAlias = null) Adds a INNER JOIN clause to the query using the TEntite relation
 *
 * @method TOrganisationQuery leftJoinTAgentRelatedByIdOrganisationAttache($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdOrganisationAttache relation
 * @method TOrganisationQuery rightJoinTAgentRelatedByIdOrganisationAttache($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdOrganisationAttache relation
 * @method TOrganisationQuery innerJoinTAgentRelatedByIdOrganisationAttache($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdOrganisationAttache relation
 *
 * @method TOrganisationQuery leftJoinTAgentRelatedByIdOrganisationGere($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByIdOrganisationGere relation
 * @method TOrganisationQuery rightJoinTAgentRelatedByIdOrganisationGere($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByIdOrganisationGere relation
 * @method TOrganisationQuery innerJoinTAgentRelatedByIdOrganisationGere($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByIdOrganisationGere relation
 *
 * @method TOrganisationQuery leftJoinTChampsSupp($relationAlias = null) Adds a LEFT JOIN clause to the query using the TChampsSupp relation
 * @method TOrganisationQuery rightJoinTChampsSupp($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TChampsSupp relation
 * @method TOrganisationQuery innerJoinTChampsSupp($relationAlias = null) Adds a INNER JOIN clause to the query using the TChampsSupp relation
 *
 * @method TOrganisationQuery leftJoinTEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissement relation
 * @method TOrganisationQuery rightJoinTEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissement relation
 * @method TOrganisationQuery innerJoinTEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissement relation
 *
 * @method TOrganisationQuery leftJoinTGroupe($relationAlias = null) Adds a LEFT JOIN clause to the query using the TGroupe relation
 * @method TOrganisationQuery rightJoinTGroupe($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TGroupe relation
 * @method TOrganisationQuery innerJoinTGroupe($relationAlias = null) Adds a INNER JOIN clause to the query using the TGroupe relation
 *
 * @method TOrganisationQuery leftJoinTJourFerie($relationAlias = null) Adds a LEFT JOIN clause to the query using the TJourFerie relation
 * @method TOrganisationQuery rightJoinTJourFerie($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TJourFerie relation
 * @method TOrganisationQuery innerJoinTJourFerie($relationAlias = null) Adds a INNER JOIN clause to the query using the TJourFerie relation
 *
 * @method TOrganisationQuery leftJoinTParametragePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametragePrestation relation
 * @method TOrganisationQuery rightJoinTParametragePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametragePrestation relation
 * @method TOrganisationQuery innerJoinTParametragePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametragePrestation relation
 *
 * @method TOrganisationQuery leftJoinTProfil($relationAlias = null) Adds a LEFT JOIN clause to the query using the TProfil relation
 * @method TOrganisationQuery rightJoinTProfil($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TProfil relation
 * @method TOrganisationQuery innerJoinTProfil($relationAlias = null) Adds a INNER JOIN clause to the query using the TProfil relation
 *
 * @method TOrganisationQuery leftJoinTRefPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefPrestation relation
 * @method TOrganisationQuery rightJoinTRefPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefPrestation relation
 * @method TOrganisationQuery innerJoinTRefPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefPrestation relation
 *
 * @method TOrganisationQuery leftJoinTRefTypePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefTypePrestation relation
 * @method TOrganisationQuery rightJoinTRefTypePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefTypePrestation relation
 * @method TOrganisationQuery innerJoinTRefTypePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefTypePrestation relation
 *
 * @method TOrganisationQuery leftJoinTValeurReferentiel($relationAlias = null) Adds a LEFT JOIN clause to the query using the TValeurReferentiel relation
 * @method TOrganisationQuery rightJoinTValeurReferentiel($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TValeurReferentiel relation
 * @method TOrganisationQuery innerJoinTValeurReferentiel($relationAlias = null) Adds a INNER JOIN clause to the query using the TValeurReferentiel relation
 *
 * @method TOrganisation findOne(PropelPDO $con = null) Return the first TOrganisation matching the query
 * @method TOrganisation findOneOrCreate(PropelPDO $con = null) Return the first TOrganisation matching the query, or a new TOrganisation object populated from the query conditions when no match is found
 *
 * @method TOrganisation findOneByCodeDenominationOrganisation(int $CODE_DENOMINATION_ORGANISATION) Return the first TOrganisation filtered by the CODE_DENOMINATION_ORGANISATION column
 * @method TOrganisation findOneByCodeAdresseOrganisation(int $CODE_ADRESSE_ORGANISATION) Return the first TOrganisation filtered by the CODE_ADRESSE_ORGANISATION column
 * @method TOrganisation findOneByCodePostal(string $CODE_POSTAL) Return the first TOrganisation filtered by the CODE_POSTAL column
 * @method TOrganisation findOneByTelephoneOrganisation(string $TELEPHONE_ORGANISATION) Return the first TOrganisation filtered by the TELEPHONE_ORGANISATION column
 * @method TOrganisation findOneByMailOrganisation(string $MAIL_ORGANISATION) Return the first TOrganisation filtered by the MAIL_ORGANISATION column
 * @method TOrganisation findOneByCodeDescriptionOrganisation(int $CODE_DESCRIPTION_ORGANISATION) Return the first TOrganisation filtered by the CODE_DESCRIPTION_ORGANISATION column
 * @method TOrganisation findOneByCodeTitreBienvenue(int $CODE_TITRE_BIENVENUE) Return the first TOrganisation filtered by the CODE_TITRE_BIENVENUE column
 * @method TOrganisation findOneByCodeMessageBienvenue(int $CODE_MESSAGE_BIENVENUE) Return the first TOrganisation filtered by the CODE_MESSAGE_BIENVENUE column
 * @method TOrganisation findOneByIdEntite(int $ID_ENTITE) Return the first TOrganisation filtered by the ID_ENTITE column
 * @method TOrganisation findOneByTypePrestation(string $TYPE_PRESTATION) Return the first TOrganisation filtered by the TYPE_PRESTATION column
 * @method TOrganisation findOneByCodeLibelleLien1(int $CODE_LIBELLE_LIEN1) Return the first TOrganisation filtered by the CODE_LIBELLE_LIEN1 column
 * @method TOrganisation findOneByUrlLien1(string $URL_LIEN1) Return the first TOrganisation filtered by the URL_LIEN1 column
 * @method TOrganisation findOneByCodeLibelleLien2(int $CODE_LIBELLE_LIEN2) Return the first TOrganisation filtered by the CODE_LIBELLE_LIEN2 column
 * @method TOrganisation findOneByUrlLien2(string $URL_LIEN2) Return the first TOrganisation filtered by the URL_LIEN2 column
 * @method TOrganisation findOneByCodeLibelleLien3(int $CODE_LIBELLE_LIEN3) Return the first TOrganisation filtered by the CODE_LIBELLE_LIEN3 column
 * @method TOrganisation findOneByUrlLien3(string $URL_LIEN3) Return the first TOrganisation filtered by the URL_LIEN3 column
 * @method TOrganisation findOneByAcronyme(string $ACRONYME) Return the first TOrganisation filtered by the ACRONYME column
 * @method TOrganisation findOneByNomDomaine(string $NOM_DOMAINE) Return the first TOrganisation filtered by the NOM_DOMAINE column
 * @method TOrganisation findOneByIdParametreForm(int $ID_PARAMETRE_FORM) Return the first TOrganisation filtered by the ID_PARAMETRE_FORM column
 * @method TOrganisation findOneByRessource(string $RESSOURCE) Return the first TOrganisation filtered by the RESSOURCE column
 *
 * @method array findByIdOrganisation(int $ID_ORGANISATION) Return TOrganisation objects filtered by the ID_ORGANISATION column
 * @method array findByCodeDenominationOrganisation(int $CODE_DENOMINATION_ORGANISATION) Return TOrganisation objects filtered by the CODE_DENOMINATION_ORGANISATION column
 * @method array findByCodeAdresseOrganisation(int $CODE_ADRESSE_ORGANISATION) Return TOrganisation objects filtered by the CODE_ADRESSE_ORGANISATION column
 * @method array findByCodePostal(string $CODE_POSTAL) Return TOrganisation objects filtered by the CODE_POSTAL column
 * @method array findByTelephoneOrganisation(string $TELEPHONE_ORGANISATION) Return TOrganisation objects filtered by the TELEPHONE_ORGANISATION column
 * @method array findByMailOrganisation(string $MAIL_ORGANISATION) Return TOrganisation objects filtered by the MAIL_ORGANISATION column
 * @method array findByCodeDescriptionOrganisation(int $CODE_DESCRIPTION_ORGANISATION) Return TOrganisation objects filtered by the CODE_DESCRIPTION_ORGANISATION column
 * @method array findByCodeTitreBienvenue(int $CODE_TITRE_BIENVENUE) Return TOrganisation objects filtered by the CODE_TITRE_BIENVENUE column
 * @method array findByCodeMessageBienvenue(int $CODE_MESSAGE_BIENVENUE) Return TOrganisation objects filtered by the CODE_MESSAGE_BIENVENUE column
 * @method array findByIdEntite(int $ID_ENTITE) Return TOrganisation objects filtered by the ID_ENTITE column
 * @method array findByTypePrestation(string $TYPE_PRESTATION) Return TOrganisation objects filtered by the TYPE_PRESTATION column
 * @method array findByCodeLibelleLien1(int $CODE_LIBELLE_LIEN1) Return TOrganisation objects filtered by the CODE_LIBELLE_LIEN1 column
 * @method array findByUrlLien1(string $URL_LIEN1) Return TOrganisation objects filtered by the URL_LIEN1 column
 * @method array findByCodeLibelleLien2(int $CODE_LIBELLE_LIEN2) Return TOrganisation objects filtered by the CODE_LIBELLE_LIEN2 column
 * @method array findByUrlLien2(string $URL_LIEN2) Return TOrganisation objects filtered by the URL_LIEN2 column
 * @method array findByCodeLibelleLien3(int $CODE_LIBELLE_LIEN3) Return TOrganisation objects filtered by the CODE_LIBELLE_LIEN3 column
 * @method array findByUrlLien3(string $URL_LIEN3) Return TOrganisation objects filtered by the URL_LIEN3 column
 * @method array findByAcronyme(string $ACRONYME) Return TOrganisation objects filtered by the ACRONYME column
 * @method array findByNomDomaine(string $NOM_DOMAINE) Return TOrganisation objects filtered by the NOM_DOMAINE column
 * @method array findByIdParametreForm(int $ID_PARAMETRE_FORM) Return TOrganisation objects filtered by the ID_PARAMETRE_FORM column
 * @method array findByRessource(string $RESSOURCE) Return TOrganisation objects filtered by the RESSOURCE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTOrganisationQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTOrganisationQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TOrganisation', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TOrganisationQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TOrganisationQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TOrganisationQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TOrganisationQuery) {
            return $criteria;
        }
        $query = new TOrganisationQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TOrganisation|TOrganisation[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TOrganisationPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TOrganisation A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdOrganisation($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TOrganisation A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_ORGANISATION`, `CODE_DENOMINATION_ORGANISATION`, `CODE_ADRESSE_ORGANISATION`, `CODE_POSTAL`, `TELEPHONE_ORGANISATION`, `MAIL_ORGANISATION`, `CODE_DESCRIPTION_ORGANISATION`, `CODE_TITRE_BIENVENUE`, `CODE_MESSAGE_BIENVENUE`, `ID_ENTITE`, `TYPE_PRESTATION`, `CODE_LIBELLE_LIEN1`, `URL_LIEN1`, `CODE_LIBELLE_LIEN2`, `URL_LIEN2`, `CODE_LIBELLE_LIEN3`, `URL_LIEN3`, `ACRONYME`, `NOM_DOMAINE`, `ID_PARAMETRE_FORM`, `RESSOURCE` FROM `T_ORGANISATION` WHERE `ID_ORGANISATION` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TOrganisation();
            $obj->hydrate($row);
            TOrganisationPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TOrganisation|TOrganisation[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TOrganisation[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisation(1234); // WHERE ID_ORGANISATION = 1234
     * $query->filterByIdOrganisation(array(12, 34)); // WHERE ID_ORGANISATION IN (12, 34)
     * $query->filterByIdOrganisation(array('min' => 12)); // WHERE ID_ORGANISATION >= 12
     * $query->filterByIdOrganisation(array('max' => 12)); // WHERE ID_ORGANISATION <= 12
     * </code>
     *
     * @param     mixed $idOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByIdOrganisation($idOrganisation = null, $comparison = null)
    {
        if (is_array($idOrganisation)) {
            $useMinMax = false;
            if (isset($idOrganisation['min'])) {
                $this->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $idOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisation['max'])) {
                $this->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $idOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $idOrganisation, $comparison);
    }

    /**
     * Filter the query on the CODE_DENOMINATION_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeDenominationOrganisation(1234); // WHERE CODE_DENOMINATION_ORGANISATION = 1234
     * $query->filterByCodeDenominationOrganisation(array(12, 34)); // WHERE CODE_DENOMINATION_ORGANISATION IN (12, 34)
     * $query->filterByCodeDenominationOrganisation(array('min' => 12)); // WHERE CODE_DENOMINATION_ORGANISATION >= 12
     * $query->filterByCodeDenominationOrganisation(array('max' => 12)); // WHERE CODE_DENOMINATION_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeDenominationOrganisation()
     *
     * @param     mixed $codeDenominationOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeDenominationOrganisation($codeDenominationOrganisation = null, $comparison = null)
    {
        if (is_array($codeDenominationOrganisation)) {
            $useMinMax = false;
            if (isset($codeDenominationOrganisation['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, $codeDenominationOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeDenominationOrganisation['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, $codeDenominationOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, $codeDenominationOrganisation, $comparison);
    }

    /**
     * Filter the query on the CODE_ADRESSE_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeAdresseOrganisation(1234); // WHERE CODE_ADRESSE_ORGANISATION = 1234
     * $query->filterByCodeAdresseOrganisation(array(12, 34)); // WHERE CODE_ADRESSE_ORGANISATION IN (12, 34)
     * $query->filterByCodeAdresseOrganisation(array('min' => 12)); // WHERE CODE_ADRESSE_ORGANISATION >= 12
     * $query->filterByCodeAdresseOrganisation(array('max' => 12)); // WHERE CODE_ADRESSE_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeAdresseOrganisation()
     *
     * @param     mixed $codeAdresseOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeAdresseOrganisation($codeAdresseOrganisation = null, $comparison = null)
    {
        if (is_array($codeAdresseOrganisation)) {
            $useMinMax = false;
            if (isset($codeAdresseOrganisation['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, $codeAdresseOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeAdresseOrganisation['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, $codeAdresseOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, $codeAdresseOrganisation, $comparison);
    }

    /**
     * Filter the query on the CODE_POSTAL column
     *
     * Example usage:
     * <code>
     * $query->filterByCodePostal('fooValue');   // WHERE CODE_POSTAL = 'fooValue'
     * $query->filterByCodePostal('%fooValue%'); // WHERE CODE_POSTAL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $codePostal The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodePostal($codePostal = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($codePostal)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $codePostal)) {
                $codePostal = str_replace('*', '%', $codePostal);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_POSTAL, $codePostal, $comparison);
    }

    /**
     * Filter the query on the TELEPHONE_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByTelephoneOrganisation('fooValue');   // WHERE TELEPHONE_ORGANISATION = 'fooValue'
     * $query->filterByTelephoneOrganisation('%fooValue%'); // WHERE TELEPHONE_ORGANISATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $telephoneOrganisation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByTelephoneOrganisation($telephoneOrganisation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($telephoneOrganisation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $telephoneOrganisation)) {
                $telephoneOrganisation = str_replace('*', '%', $telephoneOrganisation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::TELEPHONE_ORGANISATION, $telephoneOrganisation, $comparison);
    }

    /**
     * Filter the query on the MAIL_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByMailOrganisation('fooValue');   // WHERE MAIL_ORGANISATION = 'fooValue'
     * $query->filterByMailOrganisation('%fooValue%'); // WHERE MAIL_ORGANISATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mailOrganisation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByMailOrganisation($mailOrganisation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mailOrganisation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mailOrganisation)) {
                $mailOrganisation = str_replace('*', '%', $mailOrganisation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::MAIL_ORGANISATION, $mailOrganisation, $comparison);
    }

    /**
     * Filter the query on the CODE_DESCRIPTION_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeDescriptionOrganisation(1234); // WHERE CODE_DESCRIPTION_ORGANISATION = 1234
     * $query->filterByCodeDescriptionOrganisation(array(12, 34)); // WHERE CODE_DESCRIPTION_ORGANISATION IN (12, 34)
     * $query->filterByCodeDescriptionOrganisation(array('min' => 12)); // WHERE CODE_DESCRIPTION_ORGANISATION >= 12
     * $query->filterByCodeDescriptionOrganisation(array('max' => 12)); // WHERE CODE_DESCRIPTION_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeDescriptionOrganisation()
     *
     * @param     mixed $codeDescriptionOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeDescriptionOrganisation($codeDescriptionOrganisation = null, $comparison = null)
    {
        if (is_array($codeDescriptionOrganisation)) {
            $useMinMax = false;
            if (isset($codeDescriptionOrganisation['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, $codeDescriptionOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeDescriptionOrganisation['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, $codeDescriptionOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, $codeDescriptionOrganisation, $comparison);
    }

    /**
     * Filter the query on the CODE_TITRE_BIENVENUE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeTitreBienvenue(1234); // WHERE CODE_TITRE_BIENVENUE = 1234
     * $query->filterByCodeTitreBienvenue(array(12, 34)); // WHERE CODE_TITRE_BIENVENUE IN (12, 34)
     * $query->filterByCodeTitreBienvenue(array('min' => 12)); // WHERE CODE_TITRE_BIENVENUE >= 12
     * $query->filterByCodeTitreBienvenue(array('max' => 12)); // WHERE CODE_TITRE_BIENVENUE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeTitreBienvenue()
     *
     * @param     mixed $codeTitreBienvenue The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeTitreBienvenue($codeTitreBienvenue = null, $comparison = null)
    {
        if (is_array($codeTitreBienvenue)) {
            $useMinMax = false;
            if (isset($codeTitreBienvenue['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_TITRE_BIENVENUE, $codeTitreBienvenue['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeTitreBienvenue['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_TITRE_BIENVENUE, $codeTitreBienvenue['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_TITRE_BIENVENUE, $codeTitreBienvenue, $comparison);
    }

    /**
     * Filter the query on the CODE_MESSAGE_BIENVENUE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeMessageBienvenue(1234); // WHERE CODE_MESSAGE_BIENVENUE = 1234
     * $query->filterByCodeMessageBienvenue(array(12, 34)); // WHERE CODE_MESSAGE_BIENVENUE IN (12, 34)
     * $query->filterByCodeMessageBienvenue(array('min' => 12)); // WHERE CODE_MESSAGE_BIENVENUE >= 12
     * $query->filterByCodeMessageBienvenue(array('max' => 12)); // WHERE CODE_MESSAGE_BIENVENUE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeMessageBienvenue()
     *
     * @param     mixed $codeMessageBienvenue The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeMessageBienvenue($codeMessageBienvenue = null, $comparison = null)
    {
        if (is_array($codeMessageBienvenue)) {
            $useMinMax = false;
            if (isset($codeMessageBienvenue['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, $codeMessageBienvenue['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeMessageBienvenue['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, $codeMessageBienvenue['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, $codeMessageBienvenue, $comparison);
    }

    /**
     * Filter the query on the ID_ENTITE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEntite(1234); // WHERE ID_ENTITE = 1234
     * $query->filterByIdEntite(array(12, 34)); // WHERE ID_ENTITE IN (12, 34)
     * $query->filterByIdEntite(array('min' => 12)); // WHERE ID_ENTITE >= 12
     * $query->filterByIdEntite(array('max' => 12)); // WHERE ID_ENTITE <= 12
     * </code>
     *
     * @see       filterByTEntite()
     *
     * @param     mixed $idEntite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByIdEntite($idEntite = null, $comparison = null)
    {
        if (is_array($idEntite)) {
            $useMinMax = false;
            if (isset($idEntite['min'])) {
                $this->addUsingAlias(TOrganisationPeer::ID_ENTITE, $idEntite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEntite['max'])) {
                $this->addUsingAlias(TOrganisationPeer::ID_ENTITE, $idEntite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::ID_ENTITE, $idEntite, $comparison);
    }

    /**
     * Filter the query on the TYPE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByTypePrestation('fooValue');   // WHERE TYPE_PRESTATION = 'fooValue'
     * $query->filterByTypePrestation('%fooValue%'); // WHERE TYPE_PRESTATION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $typePrestation The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByTypePrestation($typePrestation = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($typePrestation)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $typePrestation)) {
                $typePrestation = str_replace('*', '%', $typePrestation);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::TYPE_PRESTATION, $typePrestation, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_LIEN1 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleLien1(1234); // WHERE CODE_LIBELLE_LIEN1 = 1234
     * $query->filterByCodeLibelleLien1(array(12, 34)); // WHERE CODE_LIBELLE_LIEN1 IN (12, 34)
     * $query->filterByCodeLibelleLien1(array('min' => 12)); // WHERE CODE_LIBELLE_LIEN1 >= 12
     * $query->filterByCodeLibelleLien1(array('max' => 12)); // WHERE CODE_LIBELLE_LIEN1 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleLien1()
     *
     * @param     mixed $codeLibelleLien1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleLien1($codeLibelleLien1 = null, $comparison = null)
    {
        if (is_array($codeLibelleLien1)) {
            $useMinMax = false;
            if (isset($codeLibelleLien1['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN1, $codeLibelleLien1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleLien1['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN1, $codeLibelleLien1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN1, $codeLibelleLien1, $comparison);
    }

    /**
     * Filter the query on the URL_LIEN1 column
     *
     * Example usage:
     * <code>
     * $query->filterByUrlLien1('fooValue');   // WHERE URL_LIEN1 = 'fooValue'
     * $query->filterByUrlLien1('%fooValue%'); // WHERE URL_LIEN1 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $urlLien1 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByUrlLien1($urlLien1 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($urlLien1)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $urlLien1)) {
                $urlLien1 = str_replace('*', '%', $urlLien1);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::URL_LIEN1, $urlLien1, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_LIEN2 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleLien2(1234); // WHERE CODE_LIBELLE_LIEN2 = 1234
     * $query->filterByCodeLibelleLien2(array(12, 34)); // WHERE CODE_LIBELLE_LIEN2 IN (12, 34)
     * $query->filterByCodeLibelleLien2(array('min' => 12)); // WHERE CODE_LIBELLE_LIEN2 >= 12
     * $query->filterByCodeLibelleLien2(array('max' => 12)); // WHERE CODE_LIBELLE_LIEN2 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleLien2()
     *
     * @param     mixed $codeLibelleLien2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleLien2($codeLibelleLien2 = null, $comparison = null)
    {
        if (is_array($codeLibelleLien2)) {
            $useMinMax = false;
            if (isset($codeLibelleLien2['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN2, $codeLibelleLien2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleLien2['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN2, $codeLibelleLien2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN2, $codeLibelleLien2, $comparison);
    }

    /**
     * Filter the query on the URL_LIEN2 column
     *
     * Example usage:
     * <code>
     * $query->filterByUrlLien2('fooValue');   // WHERE URL_LIEN2 = 'fooValue'
     * $query->filterByUrlLien2('%fooValue%'); // WHERE URL_LIEN2 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $urlLien2 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByUrlLien2($urlLien2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($urlLien2)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $urlLien2)) {
                $urlLien2 = str_replace('*', '%', $urlLien2);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::URL_LIEN2, $urlLien2, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_LIEN3 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleLien3(1234); // WHERE CODE_LIBELLE_LIEN3 = 1234
     * $query->filterByCodeLibelleLien3(array(12, 34)); // WHERE CODE_LIBELLE_LIEN3 IN (12, 34)
     * $query->filterByCodeLibelleLien3(array('min' => 12)); // WHERE CODE_LIBELLE_LIEN3 >= 12
     * $query->filterByCodeLibelleLien3(array('max' => 12)); // WHERE CODE_LIBELLE_LIEN3 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleLien3()
     *
     * @param     mixed $codeLibelleLien3 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleLien3($codeLibelleLien3 = null, $comparison = null)
    {
        if (is_array($codeLibelleLien3)) {
            $useMinMax = false;
            if (isset($codeLibelleLien3['min'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN3, $codeLibelleLien3['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleLien3['max'])) {
                $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN3, $codeLibelleLien3['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN3, $codeLibelleLien3, $comparison);
    }

    /**
     * Filter the query on the URL_LIEN3 column
     *
     * Example usage:
     * <code>
     * $query->filterByUrlLien3('fooValue');   // WHERE URL_LIEN3 = 'fooValue'
     * $query->filterByUrlLien3('%fooValue%'); // WHERE URL_LIEN3 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $urlLien3 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByUrlLien3($urlLien3 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($urlLien3)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $urlLien3)) {
                $urlLien3 = str_replace('*', '%', $urlLien3);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::URL_LIEN3, $urlLien3, $comparison);
    }

    /**
     * Filter the query on the ACRONYME column
     *
     * Example usage:
     * <code>
     * $query->filterByAcronyme('fooValue');   // WHERE ACRONYME = 'fooValue'
     * $query->filterByAcronyme('%fooValue%'); // WHERE ACRONYME LIKE '%fooValue%'
     * </code>
     *
     * @param     string $acronyme The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByAcronyme($acronyme = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($acronyme)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $acronyme)) {
                $acronyme = str_replace('*', '%', $acronyme);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::ACRONYME, $acronyme, $comparison);
    }

    /**
     * Filter the query on the NOM_DOMAINE column
     *
     * Example usage:
     * <code>
     * $query->filterByNomDomaine('fooValue');   // WHERE NOM_DOMAINE = 'fooValue'
     * $query->filterByNomDomaine('%fooValue%'); // WHERE NOM_DOMAINE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $nomDomaine The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByNomDomaine($nomDomaine = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($nomDomaine)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $nomDomaine)) {
                $nomDomaine = str_replace('*', '%', $nomDomaine);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::NOM_DOMAINE, $nomDomaine, $comparison);
    }

    /**
     * Filter the query on the ID_PARAMETRE_FORM column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametreForm(1234); // WHERE ID_PARAMETRE_FORM = 1234
     * $query->filterByIdParametreForm(array(12, 34)); // WHERE ID_PARAMETRE_FORM IN (12, 34)
     * $query->filterByIdParametreForm(array('min' => 12)); // WHERE ID_PARAMETRE_FORM >= 12
     * $query->filterByIdParametreForm(array('max' => 12)); // WHERE ID_PARAMETRE_FORM <= 12
     * </code>
     *
     * @see       filterByTParametreForm()
     *
     * @param     mixed $idParametreForm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByIdParametreForm($idParametreForm = null, $comparison = null)
    {
        if (is_array($idParametreForm)) {
            $useMinMax = false;
            if (isset($idParametreForm['min'])) {
                $this->addUsingAlias(TOrganisationPeer::ID_PARAMETRE_FORM, $idParametreForm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametreForm['max'])) {
                $this->addUsingAlias(TOrganisationPeer::ID_PARAMETRE_FORM, $idParametreForm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::ID_PARAMETRE_FORM, $idParametreForm, $comparison);
    }

    /**
     * Filter the query on the RESSOURCE column
     *
     * Example usage:
     * <code>
     * $query->filterByRessource('fooValue');   // WHERE RESSOURCE = 'fooValue'
     * $query->filterByRessource('%fooValue%'); // WHERE RESSOURCE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ressource The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function filterByRessource($ressource = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ressource)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ressource)) {
                $ressource = str_replace('*', '%', $ressource);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TOrganisationPeer::RESSOURCE, $ressource, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeAdresseOrganisation($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeAdresseOrganisation() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeAdresseOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeAdresseOrganisation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeAdresseOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeAdresseOrganisation');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeAdresseOrganisation relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeAdresseOrganisationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeAdresseOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeAdresseOrganisation', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeDenominationOrganisation($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeDenominationOrganisation() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeDenominationOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeDenominationOrganisation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeDenominationOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeDenominationOrganisation');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeDenominationOrganisation relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeDenominationOrganisationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeDenominationOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeDenominationOrganisation', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeDescriptionOrganisation($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeDescriptionOrganisation() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeDescriptionOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeDescriptionOrganisation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeDescriptionOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeDescriptionOrganisation');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeDescriptionOrganisation relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeDescriptionOrganisationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeDescriptionOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeDescriptionOrganisation', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleLien1($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN1, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN1, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleLien1() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleLien1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleLien1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleLien1');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleLien1 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleLien1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleLien1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleLien1', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleLien2($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN2, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN2, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleLien2() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleLien2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleLien2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleLien2');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleLien2 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleLien2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleLien2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleLien2', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleLien3($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN3, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_LIBELLE_LIEN3, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleLien3() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleLien3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleLien3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleLien3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleLien3');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleLien3 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleLien3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleLien3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleLien3', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeMessageBienvenue($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeMessageBienvenue() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeMessageBienvenue relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeMessageBienvenue($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeMessageBienvenue');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeMessageBienvenue');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeMessageBienvenue relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeMessageBienvenueQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeMessageBienvenue($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeMessageBienvenue', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeTitreBienvenue($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_TITRE_BIENVENUE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::CODE_TITRE_BIENVENUE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeTitreBienvenue() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeTitreBienvenue relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeTitreBienvenue($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeTitreBienvenue');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeTitreBienvenue');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeTitreBienvenue relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeTitreBienvenueQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeTitreBienvenue($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeTitreBienvenue', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreForm($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_PARAMETRE_FORM, $tParametreForm->getIdParametreForm(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::ID_PARAMETRE_FORM, $tParametreForm->toKeyValue('PrimaryKey', 'IdParametreForm'), $comparison);
        } else {
            throw new PropelException('filterByTParametreForm() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreForm relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTParametreForm($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreForm');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreForm');
        }

        return $this;
    }

    /**
     * Use the TParametreForm relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreForm($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreForm', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TEntite object
     *
     * @param   TEntite|PropelObjectCollection $tEntite The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEntite($tEntite, $comparison = null)
    {
        if ($tEntite instanceof TEntite) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ENTITE, $tEntite->getIdEntite(), $comparison);
        } elseif ($tEntite instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ENTITE, $tEntite->toKeyValue('PrimaryKey', 'IdEntite'), $comparison);
        } else {
            throw new PropelException('filterByTEntite() only accepts arguments of type TEntite or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEntite relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTEntite($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEntite');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEntite');
        }

        return $this;
    }

    /**
     * Use the TEntite relation TEntite object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEntiteQuery A secondary query class using the current class as primary query
     */
    public function useTEntiteQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTEntite($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEntite', 'TEntiteQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdOrganisationAttache($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tAgent->getIdOrganisationAttache(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentRelatedByIdOrganisationAttacheQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentRelatedByIdOrganisationAttache() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdOrganisationAttache relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdOrganisationAttache($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdOrganisationAttache');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdOrganisationAttache');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdOrganisationAttache relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdOrganisationAttacheQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdOrganisationAttache($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdOrganisationAttache', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByIdOrganisationGere($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tAgent->getIdOrganisationGere(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentRelatedByIdOrganisationGereQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentRelatedByIdOrganisationGere() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByIdOrganisationGere relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByIdOrganisationGere($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByIdOrganisationGere');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByIdOrganisationGere');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByIdOrganisationGere relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByIdOrganisationGereQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByIdOrganisationGere($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByIdOrganisationGere', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TChampsSupp object
     *
     * @param   TChampsSupp|PropelObjectCollection $tChampsSupp  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTChampsSupp($tChampsSupp, $comparison = null)
    {
        if ($tChampsSupp instanceof TChampsSupp) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tChampsSupp->getIdOrganisation(), $comparison);
        } elseif ($tChampsSupp instanceof PropelObjectCollection) {
            return $this
                ->useTChampsSuppQuery()
                ->filterByPrimaryKeys($tChampsSupp->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTChampsSupp() only accepts arguments of type TChampsSupp or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TChampsSupp relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTChampsSupp($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TChampsSupp');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TChampsSupp');
        }

        return $this;
    }

    /**
     * Use the TChampsSupp relation TChampsSupp object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TChampsSuppQuery A secondary query class using the current class as primary query
     */
    public function useTChampsSuppQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTChampsSupp($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TChampsSupp', 'TChampsSuppQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissement($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tEtablissement->getIdOrganisation(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            return $this
                ->useTEtablissementQuery()
                ->filterByPrimaryKeys($tEtablissement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTEtablissement() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTEtablissement($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissement');
        }

        return $this;
    }

    /**
     * Use the TEtablissement relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissement', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TGroupe object
     *
     * @param   TGroupe|PropelObjectCollection $tGroupe  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTGroupe($tGroupe, $comparison = null)
    {
        if ($tGroupe instanceof TGroupe) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tGroupe->getIdOrganisation(), $comparison);
        } elseif ($tGroupe instanceof PropelObjectCollection) {
            return $this
                ->useTGroupeQuery()
                ->filterByPrimaryKeys($tGroupe->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTGroupe() only accepts arguments of type TGroupe or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TGroupe relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTGroupe($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TGroupe');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TGroupe');
        }

        return $this;
    }

    /**
     * Use the TGroupe relation TGroupe object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TGroupeQuery A secondary query class using the current class as primary query
     */
    public function useTGroupeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTGroupe($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TGroupe', 'TGroupeQuery');
    }

    /**
     * Filter the query by a related TJourFerie object
     *
     * @param   TJourFerie|PropelObjectCollection $tJourFerie  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTJourFerie($tJourFerie, $comparison = null)
    {
        if ($tJourFerie instanceof TJourFerie) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tJourFerie->getIdOrganisme(), $comparison);
        } elseif ($tJourFerie instanceof PropelObjectCollection) {
            return $this
                ->useTJourFerieQuery()
                ->filterByPrimaryKeys($tJourFerie->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTJourFerie() only accepts arguments of type TJourFerie or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TJourFerie relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTJourFerie($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TJourFerie');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TJourFerie');
        }

        return $this;
    }

    /**
     * Use the TJourFerie relation TJourFerie object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TJourFerieQuery A secondary query class using the current class as primary query
     */
    public function useTJourFerieQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTJourFerie($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TJourFerie', 'TJourFerieQuery');
    }

    /**
     * Filter the query by a related TParametragePrestation object
     *
     * @param   TParametragePrestation|PropelObjectCollection $tParametragePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametragePrestation($tParametragePrestation, $comparison = null)
    {
        if ($tParametragePrestation instanceof TParametragePrestation) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tParametragePrestation->getIdOrganisation(), $comparison);
        } elseif ($tParametragePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTParametragePrestationQuery()
                ->filterByPrimaryKeys($tParametragePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametragePrestation() only accepts arguments of type TParametragePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametragePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTParametragePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametragePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametragePrestation');
        }

        return $this;
    }

    /**
     * Use the TParametragePrestation relation TParametragePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametragePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTParametragePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTParametragePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametragePrestation', 'TParametragePrestationQuery');
    }

    /**
     * Filter the query by a related TProfil object
     *
     * @param   TProfil|PropelObjectCollection $tProfil  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTProfil($tProfil, $comparison = null)
    {
        if ($tProfil instanceof TProfil) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tProfil->getIdOrganisation(), $comparison);
        } elseif ($tProfil instanceof PropelObjectCollection) {
            return $this
                ->useTProfilQuery()
                ->filterByPrimaryKeys($tProfil->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTProfil() only accepts arguments of type TProfil or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TProfil relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTProfil($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TProfil');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TProfil');
        }

        return $this;
    }

    /**
     * Use the TProfil relation TProfil object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TProfilQuery A secondary query class using the current class as primary query
     */
    public function useTProfilQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTProfil($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TProfil', 'TProfilQuery');
    }

    /**
     * Filter the query by a related TRefPrestation object
     *
     * @param   TRefPrestation|PropelObjectCollection $tRefPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefPrestation($tRefPrestation, $comparison = null)
    {
        if ($tRefPrestation instanceof TRefPrestation) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tRefPrestation->getIdOrganisation(), $comparison);
        } elseif ($tRefPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTRefPrestationQuery()
                ->filterByPrimaryKeys($tRefPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRefPrestation() only accepts arguments of type TRefPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTRefPrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefPrestation');
        }

        return $this;
    }

    /**
     * Use the TRefPrestation relation TRefPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefPrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRefPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefPrestation', 'TRefPrestationQuery');
    }

    /**
     * Filter the query by a related TRefTypePrestation object
     *
     * @param   TRefTypePrestation|PropelObjectCollection $tRefTypePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefTypePrestation($tRefTypePrestation, $comparison = null)
    {
        if ($tRefTypePrestation instanceof TRefTypePrestation) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tRefTypePrestation->getIdOrganisation(), $comparison);
        } elseif ($tRefTypePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTRefTypePrestationQuery()
                ->filterByPrimaryKeys($tRefTypePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRefTypePrestation() only accepts arguments of type TRefTypePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefTypePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTRefTypePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefTypePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefTypePrestation');
        }

        return $this;
    }

    /**
     * Use the TRefTypePrestation relation TRefTypePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefTypePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefTypePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRefTypePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefTypePrestation', 'TRefTypePrestationQuery');
    }

    /**
     * Filter the query by a related TValeurReferentiel object
     *
     * @param   TValeurReferentiel|PropelObjectCollection $tValeurReferentiel  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TOrganisationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTValeurReferentiel($tValeurReferentiel, $comparison = null)
    {
        if ($tValeurReferentiel instanceof TValeurReferentiel) {
            return $this
                ->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tValeurReferentiel->getIdOrganisation(), $comparison);
        } elseif ($tValeurReferentiel instanceof PropelObjectCollection) {
            return $this
                ->useTValeurReferentielQuery()
                ->filterByPrimaryKeys($tValeurReferentiel->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTValeurReferentiel() only accepts arguments of type TValeurReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TValeurReferentiel relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function joinTValeurReferentiel($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TValeurReferentiel');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TValeurReferentiel');
        }

        return $this;
    }

    /**
     * Use the TValeurReferentiel relation TValeurReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TValeurReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTValeurReferentielQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTValeurReferentiel($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TValeurReferentiel', 'TValeurReferentielQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TOrganisation $tOrganisation Object to remove from the list of results
     *
     * @return TOrganisationQuery The current query, for fluid interface
     */
    public function prune($tOrganisation = null)
    {
        if ($tOrganisation) {
            $this->addUsingAlias(TOrganisationPeer::ID_ORGANISATION, $tOrganisation->getIdOrganisation(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
