<?php


/**
 * Base class that represents a query for the 'T_PERIODE_INDISPONIBILITE' table.
 *
 *
 *
 * @method TPeriodeIndisponibiliteQuery orderByIdPeriodeIndisponibilite($order = Criteria::ASC) Order by the ID_PERIODE_INDISPONIBILITE column
 * @method TPeriodeIndisponibiliteQuery orderByDateDebut($order = Criteria::ASC) Order by the DATE_DEBUT column
 * @method TPeriodeIndisponibiliteQuery orderByDateFin($order = Criteria::ASC) Order by the DATE_FIN column
 * @method TPeriodeIndisponibiliteQuery orderByIdAgent($order = Criteria::ASC) Order by the ID_AGENT column
 *
 * @method TPeriodeIndisponibiliteQuery groupByIdPeriodeIndisponibilite() Group by the ID_PERIODE_INDISPONIBILITE column
 * @method TPeriodeIndisponibiliteQuery groupByDateDebut() Group by the DATE_DEBUT column
 * @method TPeriodeIndisponibiliteQuery groupByDateFin() Group by the DATE_FIN column
 * @method TPeriodeIndisponibiliteQuery groupByIdAgent() Group by the ID_AGENT column
 *
 * @method TPeriodeIndisponibiliteQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TPeriodeIndisponibiliteQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TPeriodeIndisponibiliteQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TPeriodeIndisponibiliteQuery leftJoinTAgent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgent relation
 * @method TPeriodeIndisponibiliteQuery rightJoinTAgent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgent relation
 * @method TPeriodeIndisponibiliteQuery innerJoinTAgent($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgent relation
 *
 * @method TPeriodeIndisponibilite findOne(PropelPDO $con = null) Return the first TPeriodeIndisponibilite matching the query
 * @method TPeriodeIndisponibilite findOneOrCreate(PropelPDO $con = null) Return the first TPeriodeIndisponibilite matching the query, or a new TPeriodeIndisponibilite object populated from the query conditions when no match is found
 *
 * @method TPeriodeIndisponibilite findOneByDateDebut(string $DATE_DEBUT) Return the first TPeriodeIndisponibilite filtered by the DATE_DEBUT column
 * @method TPeriodeIndisponibilite findOneByDateFin(string $DATE_FIN) Return the first TPeriodeIndisponibilite filtered by the DATE_FIN column
 * @method TPeriodeIndisponibilite findOneByIdAgent(int $ID_AGENT) Return the first TPeriodeIndisponibilite filtered by the ID_AGENT column
 *
 * @method array findByIdPeriodeIndisponibilite(int $ID_PERIODE_INDISPONIBILITE) Return TPeriodeIndisponibilite objects filtered by the ID_PERIODE_INDISPONIBILITE column
 * @method array findByDateDebut(string $DATE_DEBUT) Return TPeriodeIndisponibilite objects filtered by the DATE_DEBUT column
 * @method array findByDateFin(string $DATE_FIN) Return TPeriodeIndisponibilite objects filtered by the DATE_FIN column
 * @method array findByIdAgent(int $ID_AGENT) Return TPeriodeIndisponibilite objects filtered by the ID_AGENT column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPeriodeIndisponibiliteQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTPeriodeIndisponibiliteQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TPeriodeIndisponibilite', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TPeriodeIndisponibiliteQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TPeriodeIndisponibiliteQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TPeriodeIndisponibiliteQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TPeriodeIndisponibiliteQuery) {
            return $criteria;
        }
        $query = new TPeriodeIndisponibiliteQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TPeriodeIndisponibilite|TPeriodeIndisponibilite[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TPeriodeIndisponibilitePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TPeriodeIndisponibilitePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPeriodeIndisponibilite A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdPeriodeIndisponibilite($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPeriodeIndisponibilite A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PERIODE_INDISPONIBILITE`, `DATE_DEBUT`, `DATE_FIN`, `ID_AGENT` FROM `T_PERIODE_INDISPONIBILITE` WHERE `ID_PERIODE_INDISPONIBILITE` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TPeriodeIndisponibilite();
            $obj->hydrate($row);
            TPeriodeIndisponibilitePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TPeriodeIndisponibilite|TPeriodeIndisponibilite[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TPeriodeIndisponibilite[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_PERIODE_INDISPONIBILITE, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_PERIODE_INDISPONIBILITE, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PERIODE_INDISPONIBILITE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPeriodeIndisponibilite(1234); // WHERE ID_PERIODE_INDISPONIBILITE = 1234
     * $query->filterByIdPeriodeIndisponibilite(array(12, 34)); // WHERE ID_PERIODE_INDISPONIBILITE IN (12, 34)
     * $query->filterByIdPeriodeIndisponibilite(array('min' => 12)); // WHERE ID_PERIODE_INDISPONIBILITE >= 12
     * $query->filterByIdPeriodeIndisponibilite(array('max' => 12)); // WHERE ID_PERIODE_INDISPONIBILITE <= 12
     * </code>
     *
     * @param     mixed $idPeriodeIndisponibilite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function filterByIdPeriodeIndisponibilite($idPeriodeIndisponibilite = null, $comparison = null)
    {
        if (is_array($idPeriodeIndisponibilite)) {
            $useMinMax = false;
            if (isset($idPeriodeIndisponibilite['min'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_PERIODE_INDISPONIBILITE, $idPeriodeIndisponibilite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPeriodeIndisponibilite['max'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_PERIODE_INDISPONIBILITE, $idPeriodeIndisponibilite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_PERIODE_INDISPONIBILITE, $idPeriodeIndisponibilite, $comparison);
    }

    /**
     * Filter the query on the DATE_DEBUT column
     *
     * Example usage:
     * <code>
     * $query->filterByDateDebut('2011-03-14'); // WHERE DATE_DEBUT = '2011-03-14'
     * $query->filterByDateDebut('now'); // WHERE DATE_DEBUT = '2011-03-14'
     * $query->filterByDateDebut(array('max' => 'yesterday')); // WHERE DATE_DEBUT > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateDebut The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function filterByDateDebut($dateDebut = null, $comparison = null)
    {
        if (is_array($dateDebut)) {
            $useMinMax = false;
            if (isset($dateDebut['min'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::DATE_DEBUT, $dateDebut['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateDebut['max'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::DATE_DEBUT, $dateDebut['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodeIndisponibilitePeer::DATE_DEBUT, $dateDebut, $comparison);
    }

    /**
     * Filter the query on the DATE_FIN column
     *
     * Example usage:
     * <code>
     * $query->filterByDateFin('2011-03-14'); // WHERE DATE_FIN = '2011-03-14'
     * $query->filterByDateFin('now'); // WHERE DATE_FIN = '2011-03-14'
     * $query->filterByDateFin(array('max' => 'yesterday')); // WHERE DATE_FIN > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateFin The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function filterByDateFin($dateFin = null, $comparison = null)
    {
        if (is_array($dateFin)) {
            $useMinMax = false;
            if (isset($dateFin['min'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::DATE_FIN, $dateFin['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateFin['max'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::DATE_FIN, $dateFin['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodeIndisponibilitePeer::DATE_FIN, $dateFin, $comparison);
    }

    /**
     * Filter the query on the ID_AGENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgent(1234); // WHERE ID_AGENT = 1234
     * $query->filterByIdAgent(array(12, 34)); // WHERE ID_AGENT IN (12, 34)
     * $query->filterByIdAgent(array('min' => 12)); // WHERE ID_AGENT >= 12
     * $query->filterByIdAgent(array('max' => 12)); // WHERE ID_AGENT <= 12
     * </code>
     *
     * @see       filterByTAgent()
     *
     * @param     mixed $idAgent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function filterByIdAgent($idAgent = null, $comparison = null)
    {
        if (is_array($idAgent)) {
            $useMinMax = false;
            if (isset($idAgent['min'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_AGENT, $idAgent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgent['max'])) {
                $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_AGENT, $idAgent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_AGENT, $idAgent, $comparison);
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPeriodeIndisponibiliteQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgent($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TPeriodeIndisponibilitePeer::ID_AGENT, $tAgent->getIdAgent(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPeriodeIndisponibilitePeer::ID_AGENT, $tAgent->toKeyValue('PrimaryKey', 'IdAgent'), $comparison);
        } else {
            throw new PropelException('filterByTAgent() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function joinTAgent($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgent');
        }

        return $this;
    }

    /**
     * Use the TAgent relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTAgent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgent', 'TAgentQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TPeriodeIndisponibilite $tPeriodeIndisponibilite Object to remove from the list of results
     *
     * @return TPeriodeIndisponibiliteQuery The current query, for fluid interface
     */
    public function prune($tPeriodeIndisponibilite = null)
    {
        if ($tPeriodeIndisponibilite) {
            $this->addUsingAlias(TPeriodeIndisponibilitePeer::ID_PERIODE_INDISPONIBILITE, $tPeriodeIndisponibilite->getIdPeriodeIndisponibilite(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
