<?php


/**
 * Base class that represents a query for the 'T_PARAMETRE_FORM' table.
 *
 *
 *
 * @method TParametreFormQuery orderByIdParametreForm($order = Criteria::ASC) Order by the ID_PARAMETRE_FORM column
 * @method TParametreFormQuery orderByRdvSimilaire($order = Criteria::ASC) Order by the RDV_SIMILAIRE column
 * @method TParametreFormQuery orderByNbJourRdvSimilaire($order = Criteria::ASC) Order by the NB_JOUR_RDV_SIMILAIRE column
 * @method TParametreFormQuery orderByDelaiMin($order = Criteria::ASC) Order by the DELAI_MIN column
 * @method TParametreFormQuery orderByRessourceVisible($order = Criteria::ASC) Order by the RESSOURCE_VISIBLE column
 * @method TParametreFormQuery orderByRessourceObligatoire($order = Criteria::ASC) Order by the RESSOURCE_OBLIGATOIRE column
 * @method TParametreFormQuery orderByCodeCommentaire($order = Criteria::ASC) Order by the CODE_COMMENTAIRE column
 * @method TParametreFormQuery orderByReferentVisible($order = Criteria::ASC) Order by the REFERENT_VISIBLE column
 * @method TParametreFormQuery orderByText1Actif($order = Criteria::ASC) Order by the TEXT_1_ACTIF column
 * @method TParametreFormQuery orderByCodeLibelleText1($order = Criteria::ASC) Order by the CODE_LIBELLE_TEXT_1 column
 * @method TParametreFormQuery orderByObligatoireText1($order = Criteria::ASC) Order by the OBLIGATOIRE_TEXT_1 column
 * @method TParametreFormQuery orderByText2Actif($order = Criteria::ASC) Order by the TEXT_2_ACTIF column
 * @method TParametreFormQuery orderByCodeLibelleText2($order = Criteria::ASC) Order by the CODE_LIBELLE_TEXT_2 column
 * @method TParametreFormQuery orderByObligatoireText2($order = Criteria::ASC) Order by the OBLIGATOIRE_TEXT_2 column
 * @method TParametreFormQuery orderByText3Actif($order = Criteria::ASC) Order by the TEXT_3_ACTIF column
 * @method TParametreFormQuery orderByCodeLibelleText3($order = Criteria::ASC) Order by the CODE_LIBELLE_TEXT_3 column
 * @method TParametreFormQuery orderByObligatoireText3($order = Criteria::ASC) Order by the OBLIGATOIRE_TEXT_3 column
 * @method TParametreFormQuery orderByRef1Actif($order = Criteria::ASC) Order by the REF_1_ACTIF column
 * @method TParametreFormQuery orderByIdRef1($order = Criteria::ASC) Order by the ID_REF_1 column
 * @method TParametreFormQuery orderByCodeLibelleRef1($order = Criteria::ASC) Order by the CODE_LIBELLE_REF_1 column
 * @method TParametreFormQuery orderByObligatoireRef1($order = Criteria::ASC) Order by the OBLIGATOIRE_REF_1 column
 * @method TParametreFormQuery orderByRef2Actif($order = Criteria::ASC) Order by the REF_2_ACTIF column
 * @method TParametreFormQuery orderByIdRef2($order = Criteria::ASC) Order by the ID_REF_2 column
 * @method TParametreFormQuery orderByCodeLibelleRef2($order = Criteria::ASC) Order by the CODE_LIBELLE_REF_2 column
 * @method TParametreFormQuery orderByObligatoireRef2($order = Criteria::ASC) Order by the OBLIGATOIRE_REF_2 column
 * @method TParametreFormQuery orderByRef3Actif($order = Criteria::ASC) Order by the REF_3_ACTIF column
 * @method TParametreFormQuery orderByIdRef3($order = Criteria::ASC) Order by the ID_REF_3 column
 * @method TParametreFormQuery orderByCodeLibelleRef3($order = Criteria::ASC) Order by the CODE_LIBELLE_REF_3 column
 * @method TParametreFormQuery orderByObligatoireRef3($order = Criteria::ASC) Order by the OBLIGATOIRE_REF_3 column
 * @method TParametreFormQuery orderByObligatoireNom($order = Criteria::ASC) Order by the OBLIGATOIRE_NOM column
 * @method TParametreFormQuery orderByObligatoirePrenom($order = Criteria::ASC) Order by the OBLIGATOIRE_PRENOM column
 * @method TParametreFormQuery orderByObligatoireDateNaissance($order = Criteria::ASC) Order by the OBLIGATOIRE_DATE_NAISSANCE column
 * @method TParametreFormQuery orderByObligatoireEmail($order = Criteria::ASC) Order by the OBLIGATOIRE_EMAIL column
 * @method TParametreFormQuery orderByObligatoireIdentifiant($order = Criteria::ASC) Order by the OBLIGATOIRE_IDENTIFIANT column
 * @method TParametreFormQuery orderByObligatoireTelephone($order = Criteria::ASC) Order by the OBLIGATOIRE_TELEPHONE column
 * @method TParametreFormQuery orderByObligatoireRaisonSocial($order = Criteria::ASC) Order by the OBLIGATOIRE_RAISON_SOCIAL column
 * @method TParametreFormQuery orderByObligatoireAdresse($order = Criteria::ASC) Order by the OBLIGATOIRE_ADRESSE column
 * @method TParametreFormQuery orderByObligatoireFax($order = Criteria::ASC) Order by the OBLIGATOIRE_FAX column
 * @method TParametreFormQuery orderByVisibleNom($order = Criteria::ASC) Order by the VISIBLE_NOM column
 * @method TParametreFormQuery orderByVisiblePrenom($order = Criteria::ASC) Order by the VISIBLE_PRENOM column
 * @method TParametreFormQuery orderByVisibleDateNaissance($order = Criteria::ASC) Order by the VISIBLE_DATE_NAISSANCE column
 * @method TParametreFormQuery orderByVisibleEmail($order = Criteria::ASC) Order by the VISIBLE_EMAIL column
 * @method TParametreFormQuery orderByVisibleIdentifiant($order = Criteria::ASC) Order by the VISIBLE_IDENTIFIANT column
 * @method TParametreFormQuery orderByVisibleTelephone($order = Criteria::ASC) Order by the VISIBLE_TELEPHONE column
 * @method TParametreFormQuery orderByVisibleRaisonSocial($order = Criteria::ASC) Order by the VISIBLE_RAISON_SOCIAL column
 * @method TParametreFormQuery orderByVisibleAdresse($order = Criteria::ASC) Order by the VISIBLE_ADRESSE column
 * @method TParametreFormQuery orderByVisibleFax($order = Criteria::ASC) Order by the VISIBLE_FAX column
 * @method TParametreFormQuery orderByText1Type($order = Criteria::ASC) Order by the TEXT_1_TYPE column
 * @method TParametreFormQuery orderByText2Type($order = Criteria::ASC) Order by the TEXT_2_TYPE column
 * @method TParametreFormQuery orderByText3Type($order = Criteria::ASC) Order by the TEXT_3_TYPE column
 * @method TParametreFormQuery orderByText1Liste($order = Criteria::ASC) Order by the TEXT_1_LISTE column
 * @method TParametreFormQuery orderByText2Liste($order = Criteria::ASC) Order by the TEXT_2_LISTE column
 * @method TParametreFormQuery orderByText3Liste($order = Criteria::ASC) Order by the TEXT_3_LISTE column
 *
 * @method TParametreFormQuery groupByIdParametreForm() Group by the ID_PARAMETRE_FORM column
 * @method TParametreFormQuery groupByRdvSimilaire() Group by the RDV_SIMILAIRE column
 * @method TParametreFormQuery groupByNbJourRdvSimilaire() Group by the NB_JOUR_RDV_SIMILAIRE column
 * @method TParametreFormQuery groupByDelaiMin() Group by the DELAI_MIN column
 * @method TParametreFormQuery groupByRessourceVisible() Group by the RESSOURCE_VISIBLE column
 * @method TParametreFormQuery groupByRessourceObligatoire() Group by the RESSOURCE_OBLIGATOIRE column
 * @method TParametreFormQuery groupByCodeCommentaire() Group by the CODE_COMMENTAIRE column
 * @method TParametreFormQuery groupByReferentVisible() Group by the REFERENT_VISIBLE column
 * @method TParametreFormQuery groupByText1Actif() Group by the TEXT_1_ACTIF column
 * @method TParametreFormQuery groupByCodeLibelleText1() Group by the CODE_LIBELLE_TEXT_1 column
 * @method TParametreFormQuery groupByObligatoireText1() Group by the OBLIGATOIRE_TEXT_1 column
 * @method TParametreFormQuery groupByText2Actif() Group by the TEXT_2_ACTIF column
 * @method TParametreFormQuery groupByCodeLibelleText2() Group by the CODE_LIBELLE_TEXT_2 column
 * @method TParametreFormQuery groupByObligatoireText2() Group by the OBLIGATOIRE_TEXT_2 column
 * @method TParametreFormQuery groupByText3Actif() Group by the TEXT_3_ACTIF column
 * @method TParametreFormQuery groupByCodeLibelleText3() Group by the CODE_LIBELLE_TEXT_3 column
 * @method TParametreFormQuery groupByObligatoireText3() Group by the OBLIGATOIRE_TEXT_3 column
 * @method TParametreFormQuery groupByRef1Actif() Group by the REF_1_ACTIF column
 * @method TParametreFormQuery groupByIdRef1() Group by the ID_REF_1 column
 * @method TParametreFormQuery groupByCodeLibelleRef1() Group by the CODE_LIBELLE_REF_1 column
 * @method TParametreFormQuery groupByObligatoireRef1() Group by the OBLIGATOIRE_REF_1 column
 * @method TParametreFormQuery groupByRef2Actif() Group by the REF_2_ACTIF column
 * @method TParametreFormQuery groupByIdRef2() Group by the ID_REF_2 column
 * @method TParametreFormQuery groupByCodeLibelleRef2() Group by the CODE_LIBELLE_REF_2 column
 * @method TParametreFormQuery groupByObligatoireRef2() Group by the OBLIGATOIRE_REF_2 column
 * @method TParametreFormQuery groupByRef3Actif() Group by the REF_3_ACTIF column
 * @method TParametreFormQuery groupByIdRef3() Group by the ID_REF_3 column
 * @method TParametreFormQuery groupByCodeLibelleRef3() Group by the CODE_LIBELLE_REF_3 column
 * @method TParametreFormQuery groupByObligatoireRef3() Group by the OBLIGATOIRE_REF_3 column
 * @method TParametreFormQuery groupByObligatoireNom() Group by the OBLIGATOIRE_NOM column
 * @method TParametreFormQuery groupByObligatoirePrenom() Group by the OBLIGATOIRE_PRENOM column
 * @method TParametreFormQuery groupByObligatoireDateNaissance() Group by the OBLIGATOIRE_DATE_NAISSANCE column
 * @method TParametreFormQuery groupByObligatoireEmail() Group by the OBLIGATOIRE_EMAIL column
 * @method TParametreFormQuery groupByObligatoireIdentifiant() Group by the OBLIGATOIRE_IDENTIFIANT column
 * @method TParametreFormQuery groupByObligatoireTelephone() Group by the OBLIGATOIRE_TELEPHONE column
 * @method TParametreFormQuery groupByObligatoireRaisonSocial() Group by the OBLIGATOIRE_RAISON_SOCIAL column
 * @method TParametreFormQuery groupByObligatoireAdresse() Group by the OBLIGATOIRE_ADRESSE column
 * @method TParametreFormQuery groupByObligatoireFax() Group by the OBLIGATOIRE_FAX column
 * @method TParametreFormQuery groupByVisibleNom() Group by the VISIBLE_NOM column
 * @method TParametreFormQuery groupByVisiblePrenom() Group by the VISIBLE_PRENOM column
 * @method TParametreFormQuery groupByVisibleDateNaissance() Group by the VISIBLE_DATE_NAISSANCE column
 * @method TParametreFormQuery groupByVisibleEmail() Group by the VISIBLE_EMAIL column
 * @method TParametreFormQuery groupByVisibleIdentifiant() Group by the VISIBLE_IDENTIFIANT column
 * @method TParametreFormQuery groupByVisibleTelephone() Group by the VISIBLE_TELEPHONE column
 * @method TParametreFormQuery groupByVisibleRaisonSocial() Group by the VISIBLE_RAISON_SOCIAL column
 * @method TParametreFormQuery groupByVisibleAdresse() Group by the VISIBLE_ADRESSE column
 * @method TParametreFormQuery groupByVisibleFax() Group by the VISIBLE_FAX column
 * @method TParametreFormQuery groupByText1Type() Group by the TEXT_1_TYPE column
 * @method TParametreFormQuery groupByText2Type() Group by the TEXT_2_TYPE column
 * @method TParametreFormQuery groupByText3Type() Group by the TEXT_3_TYPE column
 * @method TParametreFormQuery groupByText1Liste() Group by the TEXT_1_LISTE column
 * @method TParametreFormQuery groupByText2Liste() Group by the TEXT_2_LISTE column
 * @method TParametreFormQuery groupByText3Liste() Group by the TEXT_3_LISTE column
 *
 * @method TParametreFormQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TParametreFormQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TParametreFormQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TParametreFormQuery leftJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 * @method TParametreFormQuery rightJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 * @method TParametreFormQuery innerJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 *
 * @method TParametreFormQuery leftJoinTTraductionRelatedByCodeLibelleRef1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef1 relation
 * @method TParametreFormQuery rightJoinTTraductionRelatedByCodeLibelleRef1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef1 relation
 * @method TParametreFormQuery innerJoinTTraductionRelatedByCodeLibelleRef1($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef1 relation
 *
 * @method TParametreFormQuery leftJoinTTraductionRelatedByCodeLibelleRef2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef2 relation
 * @method TParametreFormQuery rightJoinTTraductionRelatedByCodeLibelleRef2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef2 relation
 * @method TParametreFormQuery innerJoinTTraductionRelatedByCodeLibelleRef2($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef2 relation
 *
 * @method TParametreFormQuery leftJoinTTraductionRelatedByCodeLibelleRef3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef3 relation
 * @method TParametreFormQuery rightJoinTTraductionRelatedByCodeLibelleRef3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef3 relation
 * @method TParametreFormQuery innerJoinTTraductionRelatedByCodeLibelleRef3($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef3 relation
 *
 * @method TParametreFormQuery leftJoinTTraductionRelatedByCodeLibelleText1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleText1 relation
 * @method TParametreFormQuery rightJoinTTraductionRelatedByCodeLibelleText1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleText1 relation
 * @method TParametreFormQuery innerJoinTTraductionRelatedByCodeLibelleText1($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleText1 relation
 *
 * @method TParametreFormQuery leftJoinTTraductionRelatedByCodeLibelleText2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleText2 relation
 * @method TParametreFormQuery rightJoinTTraductionRelatedByCodeLibelleText2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleText2 relation
 * @method TParametreFormQuery innerJoinTTraductionRelatedByCodeLibelleText2($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleText2 relation
 *
 * @method TParametreFormQuery leftJoinTTraductionRelatedByCodeLibelleText3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelleText3 relation
 * @method TParametreFormQuery rightJoinTTraductionRelatedByCodeLibelleText3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelleText3 relation
 * @method TParametreFormQuery innerJoinTTraductionRelatedByCodeLibelleText3($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelleText3 relation
 *
 * @method TParametreFormQuery leftJoinTReferentielRelatedByIdRef1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferentielRelatedByIdRef1 relation
 * @method TParametreFormQuery rightJoinTReferentielRelatedByIdRef1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferentielRelatedByIdRef1 relation
 * @method TParametreFormQuery innerJoinTReferentielRelatedByIdRef1($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferentielRelatedByIdRef1 relation
 *
 * @method TParametreFormQuery leftJoinTReferentielRelatedByIdRef2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferentielRelatedByIdRef2 relation
 * @method TParametreFormQuery rightJoinTReferentielRelatedByIdRef2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferentielRelatedByIdRef2 relation
 * @method TParametreFormQuery innerJoinTReferentielRelatedByIdRef2($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferentielRelatedByIdRef2 relation
 *
 * @method TParametreFormQuery leftJoinTReferentielRelatedByIdRef3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferentielRelatedByIdRef3 relation
 * @method TParametreFormQuery rightJoinTReferentielRelatedByIdRef3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferentielRelatedByIdRef3 relation
 * @method TParametreFormQuery innerJoinTReferentielRelatedByIdRef3($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferentielRelatedByIdRef3 relation
 *
 * @method TParametreFormQuery leftJoinTOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisation relation
 * @method TParametreFormQuery rightJoinTOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisation relation
 * @method TParametreFormQuery innerJoinTOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisation relation
 *
 * @method TParametreFormQuery leftJoinTParametragePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametragePrestation relation
 * @method TParametreFormQuery rightJoinTParametragePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametragePrestation relation
 * @method TParametreFormQuery innerJoinTParametragePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametragePrestation relation
 *
 * @method TParametreFormQuery leftJoinTPieceParamForm($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPieceParamForm relation
 * @method TParametreFormQuery rightJoinTPieceParamForm($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPieceParamForm relation
 * @method TParametreFormQuery innerJoinTPieceParamForm($relationAlias = null) Adds a INNER JOIN clause to the query using the TPieceParamForm relation
 *
 * @method TParametreFormQuery leftJoinTPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestation relation
 * @method TParametreFormQuery rightJoinTPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestation relation
 * @method TParametreFormQuery innerJoinTPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestation relation
 *
 * @method TParametreFormQuery leftJoinTRefPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefPrestation relation
 * @method TParametreFormQuery rightJoinTRefPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefPrestation relation
 * @method TParametreFormQuery innerJoinTRefPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefPrestation relation
 *
 * @method TParametreForm findOne(PropelPDO $con = null) Return the first TParametreForm matching the query
 * @method TParametreForm findOneOrCreate(PropelPDO $con = null) Return the first TParametreForm matching the query, or a new TParametreForm object populated from the query conditions when no match is found
 *
 * @method TParametreForm findOneByRdvSimilaire(string $RDV_SIMILAIRE) Return the first TParametreForm filtered by the RDV_SIMILAIRE column
 * @method TParametreForm findOneByNbJourRdvSimilaire(int $NB_JOUR_RDV_SIMILAIRE) Return the first TParametreForm filtered by the NB_JOUR_RDV_SIMILAIRE column
 * @method TParametreForm findOneByDelaiMin(int $DELAI_MIN) Return the first TParametreForm filtered by the DELAI_MIN column
 * @method TParametreForm findOneByRessourceVisible(string $RESSOURCE_VISIBLE) Return the first TParametreForm filtered by the RESSOURCE_VISIBLE column
 * @method TParametreForm findOneByRessourceObligatoire(string $RESSOURCE_OBLIGATOIRE) Return the first TParametreForm filtered by the RESSOURCE_OBLIGATOIRE column
 * @method TParametreForm findOneByCodeCommentaire(int $CODE_COMMENTAIRE) Return the first TParametreForm filtered by the CODE_COMMENTAIRE column
 * @method TParametreForm findOneByReferentVisible(string $REFERENT_VISIBLE) Return the first TParametreForm filtered by the REFERENT_VISIBLE column
 * @method TParametreForm findOneByText1Actif(string $TEXT_1_ACTIF) Return the first TParametreForm filtered by the TEXT_1_ACTIF column
 * @method TParametreForm findOneByCodeLibelleText1(int $CODE_LIBELLE_TEXT_1) Return the first TParametreForm filtered by the CODE_LIBELLE_TEXT_1 column
 * @method TParametreForm findOneByObligatoireText1(string $OBLIGATOIRE_TEXT_1) Return the first TParametreForm filtered by the OBLIGATOIRE_TEXT_1 column
 * @method TParametreForm findOneByText2Actif(string $TEXT_2_ACTIF) Return the first TParametreForm filtered by the TEXT_2_ACTIF column
 * @method TParametreForm findOneByCodeLibelleText2(int $CODE_LIBELLE_TEXT_2) Return the first TParametreForm filtered by the CODE_LIBELLE_TEXT_2 column
 * @method TParametreForm findOneByObligatoireText2(string $OBLIGATOIRE_TEXT_2) Return the first TParametreForm filtered by the OBLIGATOIRE_TEXT_2 column
 * @method TParametreForm findOneByText3Actif(string $TEXT_3_ACTIF) Return the first TParametreForm filtered by the TEXT_3_ACTIF column
 * @method TParametreForm findOneByCodeLibelleText3(int $CODE_LIBELLE_TEXT_3) Return the first TParametreForm filtered by the CODE_LIBELLE_TEXT_3 column
 * @method TParametreForm findOneByObligatoireText3(string $OBLIGATOIRE_TEXT_3) Return the first TParametreForm filtered by the OBLIGATOIRE_TEXT_3 column
 * @method TParametreForm findOneByRef1Actif(string $REF_1_ACTIF) Return the first TParametreForm filtered by the REF_1_ACTIF column
 * @method TParametreForm findOneByIdRef1(int $ID_REF_1) Return the first TParametreForm filtered by the ID_REF_1 column
 * @method TParametreForm findOneByCodeLibelleRef1(int $CODE_LIBELLE_REF_1) Return the first TParametreForm filtered by the CODE_LIBELLE_REF_1 column
 * @method TParametreForm findOneByObligatoireRef1(string $OBLIGATOIRE_REF_1) Return the first TParametreForm filtered by the OBLIGATOIRE_REF_1 column
 * @method TParametreForm findOneByRef2Actif(string $REF_2_ACTIF) Return the first TParametreForm filtered by the REF_2_ACTIF column
 * @method TParametreForm findOneByIdRef2(int $ID_REF_2) Return the first TParametreForm filtered by the ID_REF_2 column
 * @method TParametreForm findOneByCodeLibelleRef2(int $CODE_LIBELLE_REF_2) Return the first TParametreForm filtered by the CODE_LIBELLE_REF_2 column
 * @method TParametreForm findOneByObligatoireRef2(string $OBLIGATOIRE_REF_2) Return the first TParametreForm filtered by the OBLIGATOIRE_REF_2 column
 * @method TParametreForm findOneByRef3Actif(string $REF_3_ACTIF) Return the first TParametreForm filtered by the REF_3_ACTIF column
 * @method TParametreForm findOneByIdRef3(int $ID_REF_3) Return the first TParametreForm filtered by the ID_REF_3 column
 * @method TParametreForm findOneByCodeLibelleRef3(int $CODE_LIBELLE_REF_3) Return the first TParametreForm filtered by the CODE_LIBELLE_REF_3 column
 * @method TParametreForm findOneByObligatoireRef3(string $OBLIGATOIRE_REF_3) Return the first TParametreForm filtered by the OBLIGATOIRE_REF_3 column
 * @method TParametreForm findOneByObligatoireNom(string $OBLIGATOIRE_NOM) Return the first TParametreForm filtered by the OBLIGATOIRE_NOM column
 * @method TParametreForm findOneByObligatoirePrenom(string $OBLIGATOIRE_PRENOM) Return the first TParametreForm filtered by the OBLIGATOIRE_PRENOM column
 * @method TParametreForm findOneByObligatoireDateNaissance(string $OBLIGATOIRE_DATE_NAISSANCE) Return the first TParametreForm filtered by the OBLIGATOIRE_DATE_NAISSANCE column
 * @method TParametreForm findOneByObligatoireEmail(string $OBLIGATOIRE_EMAIL) Return the first TParametreForm filtered by the OBLIGATOIRE_EMAIL column
 * @method TParametreForm findOneByObligatoireIdentifiant(string $OBLIGATOIRE_IDENTIFIANT) Return the first TParametreForm filtered by the OBLIGATOIRE_IDENTIFIANT column
 * @method TParametreForm findOneByObligatoireTelephone(string $OBLIGATOIRE_TELEPHONE) Return the first TParametreForm filtered by the OBLIGATOIRE_TELEPHONE column
 * @method TParametreForm findOneByObligatoireRaisonSocial(string $OBLIGATOIRE_RAISON_SOCIAL) Return the first TParametreForm filtered by the OBLIGATOIRE_RAISON_SOCIAL column
 * @method TParametreForm findOneByObligatoireAdresse(string $OBLIGATOIRE_ADRESSE) Return the first TParametreForm filtered by the OBLIGATOIRE_ADRESSE column
 * @method TParametreForm findOneByObligatoireFax(string $OBLIGATOIRE_FAX) Return the first TParametreForm filtered by the OBLIGATOIRE_FAX column
 * @method TParametreForm findOneByVisibleNom(string $VISIBLE_NOM) Return the first TParametreForm filtered by the VISIBLE_NOM column
 * @method TParametreForm findOneByVisiblePrenom(string $VISIBLE_PRENOM) Return the first TParametreForm filtered by the VISIBLE_PRENOM column
 * @method TParametreForm findOneByVisibleDateNaissance(string $VISIBLE_DATE_NAISSANCE) Return the first TParametreForm filtered by the VISIBLE_DATE_NAISSANCE column
 * @method TParametreForm findOneByVisibleEmail(string $VISIBLE_EMAIL) Return the first TParametreForm filtered by the VISIBLE_EMAIL column
 * @method TParametreForm findOneByVisibleIdentifiant(string $VISIBLE_IDENTIFIANT) Return the first TParametreForm filtered by the VISIBLE_IDENTIFIANT column
 * @method TParametreForm findOneByVisibleTelephone(string $VISIBLE_TELEPHONE) Return the first TParametreForm filtered by the VISIBLE_TELEPHONE column
 * @method TParametreForm findOneByVisibleRaisonSocial(string $VISIBLE_RAISON_SOCIAL) Return the first TParametreForm filtered by the VISIBLE_RAISON_SOCIAL column
 * @method TParametreForm findOneByVisibleAdresse(string $VISIBLE_ADRESSE) Return the first TParametreForm filtered by the VISIBLE_ADRESSE column
 * @method TParametreForm findOneByVisibleFax(string $VISIBLE_FAX) Return the first TParametreForm filtered by the VISIBLE_FAX column
 * @method TParametreForm findOneByText1Type(string $TEXT_1_TYPE) Return the first TParametreForm filtered by the TEXT_1_TYPE column
 * @method TParametreForm findOneByText2Type(string $TEXT_2_TYPE) Return the first TParametreForm filtered by the TEXT_2_TYPE column
 * @method TParametreForm findOneByText3Type(string $TEXT_3_TYPE) Return the first TParametreForm filtered by the TEXT_3_TYPE column
 * @method TParametreForm findOneByText1Liste(string $TEXT_1_LISTE) Return the first TParametreForm filtered by the TEXT_1_LISTE column
 * @method TParametreForm findOneByText2Liste(string $TEXT_2_LISTE) Return the first TParametreForm filtered by the TEXT_2_LISTE column
 * @method TParametreForm findOneByText3Liste(string $TEXT_3_LISTE) Return the first TParametreForm filtered by the TEXT_3_LISTE column
 *
 * @method array findByIdParametreForm(int $ID_PARAMETRE_FORM) Return TParametreForm objects filtered by the ID_PARAMETRE_FORM column
 * @method array findByRdvSimilaire(string $RDV_SIMILAIRE) Return TParametreForm objects filtered by the RDV_SIMILAIRE column
 * @method array findByNbJourRdvSimilaire(int $NB_JOUR_RDV_SIMILAIRE) Return TParametreForm objects filtered by the NB_JOUR_RDV_SIMILAIRE column
 * @method array findByDelaiMin(int $DELAI_MIN) Return TParametreForm objects filtered by the DELAI_MIN column
 * @method array findByRessourceVisible(string $RESSOURCE_VISIBLE) Return TParametreForm objects filtered by the RESSOURCE_VISIBLE column
 * @method array findByRessourceObligatoire(string $RESSOURCE_OBLIGATOIRE) Return TParametreForm objects filtered by the RESSOURCE_OBLIGATOIRE column
 * @method array findByCodeCommentaire(int $CODE_COMMENTAIRE) Return TParametreForm objects filtered by the CODE_COMMENTAIRE column
 * @method array findByReferentVisible(string $REFERENT_VISIBLE) Return TParametreForm objects filtered by the REFERENT_VISIBLE column
 * @method array findByText1Actif(string $TEXT_1_ACTIF) Return TParametreForm objects filtered by the TEXT_1_ACTIF column
 * @method array findByCodeLibelleText1(int $CODE_LIBELLE_TEXT_1) Return TParametreForm objects filtered by the CODE_LIBELLE_TEXT_1 column
 * @method array findByObligatoireText1(string $OBLIGATOIRE_TEXT_1) Return TParametreForm objects filtered by the OBLIGATOIRE_TEXT_1 column
 * @method array findByText2Actif(string $TEXT_2_ACTIF) Return TParametreForm objects filtered by the TEXT_2_ACTIF column
 * @method array findByCodeLibelleText2(int $CODE_LIBELLE_TEXT_2) Return TParametreForm objects filtered by the CODE_LIBELLE_TEXT_2 column
 * @method array findByObligatoireText2(string $OBLIGATOIRE_TEXT_2) Return TParametreForm objects filtered by the OBLIGATOIRE_TEXT_2 column
 * @method array findByText3Actif(string $TEXT_3_ACTIF) Return TParametreForm objects filtered by the TEXT_3_ACTIF column
 * @method array findByCodeLibelleText3(int $CODE_LIBELLE_TEXT_3) Return TParametreForm objects filtered by the CODE_LIBELLE_TEXT_3 column
 * @method array findByObligatoireText3(string $OBLIGATOIRE_TEXT_3) Return TParametreForm objects filtered by the OBLIGATOIRE_TEXT_3 column
 * @method array findByRef1Actif(string $REF_1_ACTIF) Return TParametreForm objects filtered by the REF_1_ACTIF column
 * @method array findByIdRef1(int $ID_REF_1) Return TParametreForm objects filtered by the ID_REF_1 column
 * @method array findByCodeLibelleRef1(int $CODE_LIBELLE_REF_1) Return TParametreForm objects filtered by the CODE_LIBELLE_REF_1 column
 * @method array findByObligatoireRef1(string $OBLIGATOIRE_REF_1) Return TParametreForm objects filtered by the OBLIGATOIRE_REF_1 column
 * @method array findByRef2Actif(string $REF_2_ACTIF) Return TParametreForm objects filtered by the REF_2_ACTIF column
 * @method array findByIdRef2(int $ID_REF_2) Return TParametreForm objects filtered by the ID_REF_2 column
 * @method array findByCodeLibelleRef2(int $CODE_LIBELLE_REF_2) Return TParametreForm objects filtered by the CODE_LIBELLE_REF_2 column
 * @method array findByObligatoireRef2(string $OBLIGATOIRE_REF_2) Return TParametreForm objects filtered by the OBLIGATOIRE_REF_2 column
 * @method array findByRef3Actif(string $REF_3_ACTIF) Return TParametreForm objects filtered by the REF_3_ACTIF column
 * @method array findByIdRef3(int $ID_REF_3) Return TParametreForm objects filtered by the ID_REF_3 column
 * @method array findByCodeLibelleRef3(int $CODE_LIBELLE_REF_3) Return TParametreForm objects filtered by the CODE_LIBELLE_REF_3 column
 * @method array findByObligatoireRef3(string $OBLIGATOIRE_REF_3) Return TParametreForm objects filtered by the OBLIGATOIRE_REF_3 column
 * @method array findByObligatoireNom(string $OBLIGATOIRE_NOM) Return TParametreForm objects filtered by the OBLIGATOIRE_NOM column
 * @method array findByObligatoirePrenom(string $OBLIGATOIRE_PRENOM) Return TParametreForm objects filtered by the OBLIGATOIRE_PRENOM column
 * @method array findByObligatoireDateNaissance(string $OBLIGATOIRE_DATE_NAISSANCE) Return TParametreForm objects filtered by the OBLIGATOIRE_DATE_NAISSANCE column
 * @method array findByObligatoireEmail(string $OBLIGATOIRE_EMAIL) Return TParametreForm objects filtered by the OBLIGATOIRE_EMAIL column
 * @method array findByObligatoireIdentifiant(string $OBLIGATOIRE_IDENTIFIANT) Return TParametreForm objects filtered by the OBLIGATOIRE_IDENTIFIANT column
 * @method array findByObligatoireTelephone(string $OBLIGATOIRE_TELEPHONE) Return TParametreForm objects filtered by the OBLIGATOIRE_TELEPHONE column
 * @method array findByObligatoireRaisonSocial(string $OBLIGATOIRE_RAISON_SOCIAL) Return TParametreForm objects filtered by the OBLIGATOIRE_RAISON_SOCIAL column
 * @method array findByObligatoireAdresse(string $OBLIGATOIRE_ADRESSE) Return TParametreForm objects filtered by the OBLIGATOIRE_ADRESSE column
 * @method array findByObligatoireFax(string $OBLIGATOIRE_FAX) Return TParametreForm objects filtered by the OBLIGATOIRE_FAX column
 * @method array findByVisibleNom(string $VISIBLE_NOM) Return TParametreForm objects filtered by the VISIBLE_NOM column
 * @method array findByVisiblePrenom(string $VISIBLE_PRENOM) Return TParametreForm objects filtered by the VISIBLE_PRENOM column
 * @method array findByVisibleDateNaissance(string $VISIBLE_DATE_NAISSANCE) Return TParametreForm objects filtered by the VISIBLE_DATE_NAISSANCE column
 * @method array findByVisibleEmail(string $VISIBLE_EMAIL) Return TParametreForm objects filtered by the VISIBLE_EMAIL column
 * @method array findByVisibleIdentifiant(string $VISIBLE_IDENTIFIANT) Return TParametreForm objects filtered by the VISIBLE_IDENTIFIANT column
 * @method array findByVisibleTelephone(string $VISIBLE_TELEPHONE) Return TParametreForm objects filtered by the VISIBLE_TELEPHONE column
 * @method array findByVisibleRaisonSocial(string $VISIBLE_RAISON_SOCIAL) Return TParametreForm objects filtered by the VISIBLE_RAISON_SOCIAL column
 * @method array findByVisibleAdresse(string $VISIBLE_ADRESSE) Return TParametreForm objects filtered by the VISIBLE_ADRESSE column
 * @method array findByVisibleFax(string $VISIBLE_FAX) Return TParametreForm objects filtered by the VISIBLE_FAX column
 * @method array findByText1Type(string $TEXT_1_TYPE) Return TParametreForm objects filtered by the TEXT_1_TYPE column
 * @method array findByText2Type(string $TEXT_2_TYPE) Return TParametreForm objects filtered by the TEXT_2_TYPE column
 * @method array findByText3Type(string $TEXT_3_TYPE) Return TParametreForm objects filtered by the TEXT_3_TYPE column
 * @method array findByText1Liste(string $TEXT_1_LISTE) Return TParametreForm objects filtered by the TEXT_1_LISTE column
 * @method array findByText2Liste(string $TEXT_2_LISTE) Return TParametreForm objects filtered by the TEXT_2_LISTE column
 * @method array findByText3Liste(string $TEXT_3_LISTE) Return TParametreForm objects filtered by the TEXT_3_LISTE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTParametreFormQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTParametreFormQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TParametreForm', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TParametreFormQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TParametreFormQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TParametreFormQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TParametreFormQuery) {
            return $criteria;
        }
        $query = new TParametreFormQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TParametreForm|TParametreForm[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TParametreFormPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TParametreForm A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdParametreForm($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TParametreForm A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PARAMETRE_FORM`, `RDV_SIMILAIRE`, `NB_JOUR_RDV_SIMILAIRE`, `DELAI_MIN`, `RESSOURCE_VISIBLE`, `RESSOURCE_OBLIGATOIRE`, `CODE_COMMENTAIRE`, `REFERENT_VISIBLE`, `TEXT_1_ACTIF`, `CODE_LIBELLE_TEXT_1`, `OBLIGATOIRE_TEXT_1`, `TEXT_2_ACTIF`, `CODE_LIBELLE_TEXT_2`, `OBLIGATOIRE_TEXT_2`, `TEXT_3_ACTIF`, `CODE_LIBELLE_TEXT_3`, `OBLIGATOIRE_TEXT_3`, `REF_1_ACTIF`, `ID_REF_1`, `CODE_LIBELLE_REF_1`, `OBLIGATOIRE_REF_1`, `REF_2_ACTIF`, `ID_REF_2`, `CODE_LIBELLE_REF_2`, `OBLIGATOIRE_REF_2`, `REF_3_ACTIF`, `ID_REF_3`, `CODE_LIBELLE_REF_3`, `OBLIGATOIRE_REF_3`, `OBLIGATOIRE_NOM`, `OBLIGATOIRE_PRENOM`, `OBLIGATOIRE_DATE_NAISSANCE`, `OBLIGATOIRE_EMAIL`, `OBLIGATOIRE_IDENTIFIANT`, `OBLIGATOIRE_TELEPHONE`, `OBLIGATOIRE_RAISON_SOCIAL`, `OBLIGATOIRE_ADRESSE`, `OBLIGATOIRE_FAX`, `VISIBLE_NOM`, `VISIBLE_PRENOM`, `VISIBLE_DATE_NAISSANCE`, `VISIBLE_EMAIL`, `VISIBLE_IDENTIFIANT`, `VISIBLE_TELEPHONE`, `VISIBLE_RAISON_SOCIAL`, `VISIBLE_ADRESSE`, `VISIBLE_FAX`, `TEXT_1_TYPE`, `TEXT_2_TYPE`, `TEXT_3_TYPE`, `TEXT_1_LISTE`, `TEXT_2_LISTE`, `TEXT_3_LISTE` FROM `T_PARAMETRE_FORM` WHERE `ID_PARAMETRE_FORM` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TParametreForm();
            $obj->hydrate($row);
            TParametreFormPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TParametreForm|TParametreForm[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TParametreForm[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PARAMETRE_FORM column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametreForm(1234); // WHERE ID_PARAMETRE_FORM = 1234
     * $query->filterByIdParametreForm(array(12, 34)); // WHERE ID_PARAMETRE_FORM IN (12, 34)
     * $query->filterByIdParametreForm(array('min' => 12)); // WHERE ID_PARAMETRE_FORM >= 12
     * $query->filterByIdParametreForm(array('max' => 12)); // WHERE ID_PARAMETRE_FORM <= 12
     * </code>
     *
     * @param     mixed $idParametreForm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByIdParametreForm($idParametreForm = null, $comparison = null)
    {
        if (is_array($idParametreForm)) {
            $useMinMax = false;
            if (isset($idParametreForm['min'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $idParametreForm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametreForm['max'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $idParametreForm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $idParametreForm, $comparison);
    }

    /**
     * Filter the query on the RDV_SIMILAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByRdvSimilaire('fooValue');   // WHERE RDV_SIMILAIRE = 'fooValue'
     * $query->filterByRdvSimilaire('%fooValue%'); // WHERE RDV_SIMILAIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rdvSimilaire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByRdvSimilaire($rdvSimilaire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rdvSimilaire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rdvSimilaire)) {
                $rdvSimilaire = str_replace('*', '%', $rdvSimilaire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::RDV_SIMILAIRE, $rdvSimilaire, $comparison);
    }

    /**
     * Filter the query on the NB_JOUR_RDV_SIMILAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByNbJourRdvSimilaire(1234); // WHERE NB_JOUR_RDV_SIMILAIRE = 1234
     * $query->filterByNbJourRdvSimilaire(array(12, 34)); // WHERE NB_JOUR_RDV_SIMILAIRE IN (12, 34)
     * $query->filterByNbJourRdvSimilaire(array('min' => 12)); // WHERE NB_JOUR_RDV_SIMILAIRE >= 12
     * $query->filterByNbJourRdvSimilaire(array('max' => 12)); // WHERE NB_JOUR_RDV_SIMILAIRE <= 12
     * </code>
     *
     * @param     mixed $nbJourRdvSimilaire The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByNbJourRdvSimilaire($nbJourRdvSimilaire = null, $comparison = null)
    {
        if (is_array($nbJourRdvSimilaire)) {
            $useMinMax = false;
            if (isset($nbJourRdvSimilaire['min'])) {
                $this->addUsingAlias(TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($nbJourRdvSimilaire['max'])) {
                $this->addUsingAlias(TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire, $comparison);
    }

    /**
     * Filter the query on the DELAI_MIN column
     *
     * Example usage:
     * <code>
     * $query->filterByDelaiMin(1234); // WHERE DELAI_MIN = 1234
     * $query->filterByDelaiMin(array(12, 34)); // WHERE DELAI_MIN IN (12, 34)
     * $query->filterByDelaiMin(array('min' => 12)); // WHERE DELAI_MIN >= 12
     * $query->filterByDelaiMin(array('max' => 12)); // WHERE DELAI_MIN <= 12
     * </code>
     *
     * @param     mixed $delaiMin The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByDelaiMin($delaiMin = null, $comparison = null)
    {
        if (is_array($delaiMin)) {
            $useMinMax = false;
            if (isset($delaiMin['min'])) {
                $this->addUsingAlias(TParametreFormPeer::DELAI_MIN, $delaiMin['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($delaiMin['max'])) {
                $this->addUsingAlias(TParametreFormPeer::DELAI_MIN, $delaiMin['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::DELAI_MIN, $delaiMin, $comparison);
    }

    /**
     * Filter the query on the RESSOURCE_VISIBLE column
     *
     * Example usage:
     * <code>
     * $query->filterByRessourceVisible('fooValue');   // WHERE RESSOURCE_VISIBLE = 'fooValue'
     * $query->filterByRessourceVisible('%fooValue%'); // WHERE RESSOURCE_VISIBLE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ressourceVisible The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByRessourceVisible($ressourceVisible = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ressourceVisible)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ressourceVisible)) {
                $ressourceVisible = str_replace('*', '%', $ressourceVisible);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::RESSOURCE_VISIBLE, $ressourceVisible, $comparison);
    }

    /**
     * Filter the query on the RESSOURCE_OBLIGATOIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByRessourceObligatoire('fooValue');   // WHERE RESSOURCE_OBLIGATOIRE = 'fooValue'
     * $query->filterByRessourceObligatoire('%fooValue%'); // WHERE RESSOURCE_OBLIGATOIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ressourceObligatoire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByRessourceObligatoire($ressourceObligatoire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ressourceObligatoire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ressourceObligatoire)) {
                $ressourceObligatoire = str_replace('*', '%', $ressourceObligatoire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::RESSOURCE_OBLIGATOIRE, $ressourceObligatoire, $comparison);
    }

    /**
     * Filter the query on the CODE_COMMENTAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeCommentaire(1234); // WHERE CODE_COMMENTAIRE = 1234
     * $query->filterByCodeCommentaire(array(12, 34)); // WHERE CODE_COMMENTAIRE IN (12, 34)
     * $query->filterByCodeCommentaire(array('min' => 12)); // WHERE CODE_COMMENTAIRE >= 12
     * $query->filterByCodeCommentaire(array('max' => 12)); // WHERE CODE_COMMENTAIRE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeCommentaire()
     *
     * @param     mixed $codeCommentaire The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByCodeCommentaire($codeCommentaire = null, $comparison = null)
    {
        if (is_array($codeCommentaire)) {
            $useMinMax = false;
            if (isset($codeCommentaire['min'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_COMMENTAIRE, $codeCommentaire['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeCommentaire['max'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_COMMENTAIRE, $codeCommentaire['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::CODE_COMMENTAIRE, $codeCommentaire, $comparison);
    }

    /**
     * Filter the query on the REFERENT_VISIBLE column
     *
     * Example usage:
     * <code>
     * $query->filterByReferentVisible('fooValue');   // WHERE REFERENT_VISIBLE = 'fooValue'
     * $query->filterByReferentVisible('%fooValue%'); // WHERE REFERENT_VISIBLE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $referentVisible The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByReferentVisible($referentVisible = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($referentVisible)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $referentVisible)) {
                $referentVisible = str_replace('*', '%', $referentVisible);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::REFERENT_VISIBLE, $referentVisible, $comparison);
    }

    /**
     * Filter the query on the TEXT_1_ACTIF column
     *
     * Example usage:
     * <code>
     * $query->filterByText1Actif('fooValue');   // WHERE TEXT_1_ACTIF = 'fooValue'
     * $query->filterByText1Actif('%fooValue%'); // WHERE TEXT_1_ACTIF LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text1Actif The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText1Actif($text1Actif = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text1Actif)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text1Actif)) {
                $text1Actif = str_replace('*', '%', $text1Actif);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_1_ACTIF, $text1Actif, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_TEXT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleText1(1234); // WHERE CODE_LIBELLE_TEXT_1 = 1234
     * $query->filterByCodeLibelleText1(array(12, 34)); // WHERE CODE_LIBELLE_TEXT_1 IN (12, 34)
     * $query->filterByCodeLibelleText1(array('min' => 12)); // WHERE CODE_LIBELLE_TEXT_1 >= 12
     * $query->filterByCodeLibelleText1(array('max' => 12)); // WHERE CODE_LIBELLE_TEXT_1 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleText1()
     *
     * @param     mixed $codeLibelleText1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleText1($codeLibelleText1 = null, $comparison = null)
    {
        if (is_array($codeLibelleText1)) {
            $useMinMax = false;
            if (isset($codeLibelleText1['min'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_1, $codeLibelleText1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleText1['max'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_1, $codeLibelleText1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_1, $codeLibelleText1, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_TEXT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireText1('fooValue');   // WHERE OBLIGATOIRE_TEXT_1 = 'fooValue'
     * $query->filterByObligatoireText1('%fooValue%'); // WHERE OBLIGATOIRE_TEXT_1 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireText1 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireText1($obligatoireText1 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireText1)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireText1)) {
                $obligatoireText1 = str_replace('*', '%', $obligatoireText1);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_TEXT_1, $obligatoireText1, $comparison);
    }

    /**
     * Filter the query on the TEXT_2_ACTIF column
     *
     * Example usage:
     * <code>
     * $query->filterByText2Actif('fooValue');   // WHERE TEXT_2_ACTIF = 'fooValue'
     * $query->filterByText2Actif('%fooValue%'); // WHERE TEXT_2_ACTIF LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text2Actif The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText2Actif($text2Actif = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text2Actif)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text2Actif)) {
                $text2Actif = str_replace('*', '%', $text2Actif);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_2_ACTIF, $text2Actif, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_TEXT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleText2(1234); // WHERE CODE_LIBELLE_TEXT_2 = 1234
     * $query->filterByCodeLibelleText2(array(12, 34)); // WHERE CODE_LIBELLE_TEXT_2 IN (12, 34)
     * $query->filterByCodeLibelleText2(array('min' => 12)); // WHERE CODE_LIBELLE_TEXT_2 >= 12
     * $query->filterByCodeLibelleText2(array('max' => 12)); // WHERE CODE_LIBELLE_TEXT_2 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleText2()
     *
     * @param     mixed $codeLibelleText2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleText2($codeLibelleText2 = null, $comparison = null)
    {
        if (is_array($codeLibelleText2)) {
            $useMinMax = false;
            if (isset($codeLibelleText2['min'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_2, $codeLibelleText2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleText2['max'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_2, $codeLibelleText2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_2, $codeLibelleText2, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_TEXT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireText2('fooValue');   // WHERE OBLIGATOIRE_TEXT_2 = 'fooValue'
     * $query->filterByObligatoireText2('%fooValue%'); // WHERE OBLIGATOIRE_TEXT_2 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireText2 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireText2($obligatoireText2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireText2)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireText2)) {
                $obligatoireText2 = str_replace('*', '%', $obligatoireText2);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_TEXT_2, $obligatoireText2, $comparison);
    }

    /**
     * Filter the query on the TEXT_3_ACTIF column
     *
     * Example usage:
     * <code>
     * $query->filterByText3Actif('fooValue');   // WHERE TEXT_3_ACTIF = 'fooValue'
     * $query->filterByText3Actif('%fooValue%'); // WHERE TEXT_3_ACTIF LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text3Actif The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText3Actif($text3Actif = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text3Actif)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text3Actif)) {
                $text3Actif = str_replace('*', '%', $text3Actif);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_3_ACTIF, $text3Actif, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_TEXT_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleText3(1234); // WHERE CODE_LIBELLE_TEXT_3 = 1234
     * $query->filterByCodeLibelleText3(array(12, 34)); // WHERE CODE_LIBELLE_TEXT_3 IN (12, 34)
     * $query->filterByCodeLibelleText3(array('min' => 12)); // WHERE CODE_LIBELLE_TEXT_3 >= 12
     * $query->filterByCodeLibelleText3(array('max' => 12)); // WHERE CODE_LIBELLE_TEXT_3 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleText3()
     *
     * @param     mixed $codeLibelleText3 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleText3($codeLibelleText3 = null, $comparison = null)
    {
        if (is_array($codeLibelleText3)) {
            $useMinMax = false;
            if (isset($codeLibelleText3['min'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_3, $codeLibelleText3['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleText3['max'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_3, $codeLibelleText3['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_3, $codeLibelleText3, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_TEXT_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireText3('fooValue');   // WHERE OBLIGATOIRE_TEXT_3 = 'fooValue'
     * $query->filterByObligatoireText3('%fooValue%'); // WHERE OBLIGATOIRE_TEXT_3 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireText3 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireText3($obligatoireText3 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireText3)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireText3)) {
                $obligatoireText3 = str_replace('*', '%', $obligatoireText3);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_TEXT_3, $obligatoireText3, $comparison);
    }

    /**
     * Filter the query on the REF_1_ACTIF column
     *
     * Example usage:
     * <code>
     * $query->filterByRef1Actif('fooValue');   // WHERE REF_1_ACTIF = 'fooValue'
     * $query->filterByRef1Actif('%fooValue%'); // WHERE REF_1_ACTIF LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ref1Actif The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByRef1Actif($ref1Actif = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ref1Actif)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ref1Actif)) {
                $ref1Actif = str_replace('*', '%', $ref1Actif);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::REF_1_ACTIF, $ref1Actif, $comparison);
    }

    /**
     * Filter the query on the ID_REF_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRef1(1234); // WHERE ID_REF_1 = 1234
     * $query->filterByIdRef1(array(12, 34)); // WHERE ID_REF_1 IN (12, 34)
     * $query->filterByIdRef1(array('min' => 12)); // WHERE ID_REF_1 >= 12
     * $query->filterByIdRef1(array('max' => 12)); // WHERE ID_REF_1 <= 12
     * </code>
     *
     * @see       filterByTReferentielRelatedByIdRef1()
     *
     * @param     mixed $idRef1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByIdRef1($idRef1 = null, $comparison = null)
    {
        if (is_array($idRef1)) {
            $useMinMax = false;
            if (isset($idRef1['min'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_REF_1, $idRef1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRef1['max'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_REF_1, $idRef1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::ID_REF_1, $idRef1, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_REF_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleRef1(1234); // WHERE CODE_LIBELLE_REF_1 = 1234
     * $query->filterByCodeLibelleRef1(array(12, 34)); // WHERE CODE_LIBELLE_REF_1 IN (12, 34)
     * $query->filterByCodeLibelleRef1(array('min' => 12)); // WHERE CODE_LIBELLE_REF_1 >= 12
     * $query->filterByCodeLibelleRef1(array('max' => 12)); // WHERE CODE_LIBELLE_REF_1 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleRef1()
     *
     * @param     mixed $codeLibelleRef1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleRef1($codeLibelleRef1 = null, $comparison = null)
    {
        if (is_array($codeLibelleRef1)) {
            $useMinMax = false;
            if (isset($codeLibelleRef1['min'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_1, $codeLibelleRef1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleRef1['max'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_1, $codeLibelleRef1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_1, $codeLibelleRef1, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_REF_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireRef1('fooValue');   // WHERE OBLIGATOIRE_REF_1 = 'fooValue'
     * $query->filterByObligatoireRef1('%fooValue%'); // WHERE OBLIGATOIRE_REF_1 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireRef1 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireRef1($obligatoireRef1 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireRef1)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireRef1)) {
                $obligatoireRef1 = str_replace('*', '%', $obligatoireRef1);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_REF_1, $obligatoireRef1, $comparison);
    }

    /**
     * Filter the query on the REF_2_ACTIF column
     *
     * Example usage:
     * <code>
     * $query->filterByRef2Actif('fooValue');   // WHERE REF_2_ACTIF = 'fooValue'
     * $query->filterByRef2Actif('%fooValue%'); // WHERE REF_2_ACTIF LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ref2Actif The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByRef2Actif($ref2Actif = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ref2Actif)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ref2Actif)) {
                $ref2Actif = str_replace('*', '%', $ref2Actif);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::REF_2_ACTIF, $ref2Actif, $comparison);
    }

    /**
     * Filter the query on the ID_REF_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRef2(1234); // WHERE ID_REF_2 = 1234
     * $query->filterByIdRef2(array(12, 34)); // WHERE ID_REF_2 IN (12, 34)
     * $query->filterByIdRef2(array('min' => 12)); // WHERE ID_REF_2 >= 12
     * $query->filterByIdRef2(array('max' => 12)); // WHERE ID_REF_2 <= 12
     * </code>
     *
     * @see       filterByTReferentielRelatedByIdRef2()
     *
     * @param     mixed $idRef2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByIdRef2($idRef2 = null, $comparison = null)
    {
        if (is_array($idRef2)) {
            $useMinMax = false;
            if (isset($idRef2['min'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_REF_2, $idRef2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRef2['max'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_REF_2, $idRef2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::ID_REF_2, $idRef2, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_REF_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleRef2(1234); // WHERE CODE_LIBELLE_REF_2 = 1234
     * $query->filterByCodeLibelleRef2(array(12, 34)); // WHERE CODE_LIBELLE_REF_2 IN (12, 34)
     * $query->filterByCodeLibelleRef2(array('min' => 12)); // WHERE CODE_LIBELLE_REF_2 >= 12
     * $query->filterByCodeLibelleRef2(array('max' => 12)); // WHERE CODE_LIBELLE_REF_2 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleRef2()
     *
     * @param     mixed $codeLibelleRef2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleRef2($codeLibelleRef2 = null, $comparison = null)
    {
        if (is_array($codeLibelleRef2)) {
            $useMinMax = false;
            if (isset($codeLibelleRef2['min'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_2, $codeLibelleRef2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleRef2['max'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_2, $codeLibelleRef2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_2, $codeLibelleRef2, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_REF_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireRef2('fooValue');   // WHERE OBLIGATOIRE_REF_2 = 'fooValue'
     * $query->filterByObligatoireRef2('%fooValue%'); // WHERE OBLIGATOIRE_REF_2 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireRef2 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireRef2($obligatoireRef2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireRef2)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireRef2)) {
                $obligatoireRef2 = str_replace('*', '%', $obligatoireRef2);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_REF_2, $obligatoireRef2, $comparison);
    }

    /**
     * Filter the query on the REF_3_ACTIF column
     *
     * Example usage:
     * <code>
     * $query->filterByRef3Actif('fooValue');   // WHERE REF_3_ACTIF = 'fooValue'
     * $query->filterByRef3Actif('%fooValue%'); // WHERE REF_3_ACTIF LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ref3Actif The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByRef3Actif($ref3Actif = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ref3Actif)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ref3Actif)) {
                $ref3Actif = str_replace('*', '%', $ref3Actif);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::REF_3_ACTIF, $ref3Actif, $comparison);
    }

    /**
     * Filter the query on the ID_REF_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRef3(1234); // WHERE ID_REF_3 = 1234
     * $query->filterByIdRef3(array(12, 34)); // WHERE ID_REF_3 IN (12, 34)
     * $query->filterByIdRef3(array('min' => 12)); // WHERE ID_REF_3 >= 12
     * $query->filterByIdRef3(array('max' => 12)); // WHERE ID_REF_3 <= 12
     * </code>
     *
     * @see       filterByTReferentielRelatedByIdRef3()
     *
     * @param     mixed $idRef3 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByIdRef3($idRef3 = null, $comparison = null)
    {
        if (is_array($idRef3)) {
            $useMinMax = false;
            if (isset($idRef3['min'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_REF_3, $idRef3['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRef3['max'])) {
                $this->addUsingAlias(TParametreFormPeer::ID_REF_3, $idRef3['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::ID_REF_3, $idRef3, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_REF_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelleRef3(1234); // WHERE CODE_LIBELLE_REF_3 = 1234
     * $query->filterByCodeLibelleRef3(array(12, 34)); // WHERE CODE_LIBELLE_REF_3 IN (12, 34)
     * $query->filterByCodeLibelleRef3(array('min' => 12)); // WHERE CODE_LIBELLE_REF_3 >= 12
     * $query->filterByCodeLibelleRef3(array('max' => 12)); // WHERE CODE_LIBELLE_REF_3 <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelleRef3()
     *
     * @param     mixed $codeLibelleRef3 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByCodeLibelleRef3($codeLibelleRef3 = null, $comparison = null)
    {
        if (is_array($codeLibelleRef3)) {
            $useMinMax = false;
            if (isset($codeLibelleRef3['min'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_3, $codeLibelleRef3['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelleRef3['max'])) {
                $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_3, $codeLibelleRef3['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_3, $codeLibelleRef3, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_REF_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireRef3('fooValue');   // WHERE OBLIGATOIRE_REF_3 = 'fooValue'
     * $query->filterByObligatoireRef3('%fooValue%'); // WHERE OBLIGATOIRE_REF_3 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireRef3 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireRef3($obligatoireRef3 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireRef3)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireRef3)) {
                $obligatoireRef3 = str_replace('*', '%', $obligatoireRef3);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_REF_3, $obligatoireRef3, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_NOM column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireNom('fooValue');   // WHERE OBLIGATOIRE_NOM = 'fooValue'
     * $query->filterByObligatoireNom('%fooValue%'); // WHERE OBLIGATOIRE_NOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireNom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireNom($obligatoireNom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireNom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireNom)) {
                $obligatoireNom = str_replace('*', '%', $obligatoireNom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_NOM, $obligatoireNom, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_PRENOM column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoirePrenom('fooValue');   // WHERE OBLIGATOIRE_PRENOM = 'fooValue'
     * $query->filterByObligatoirePrenom('%fooValue%'); // WHERE OBLIGATOIRE_PRENOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoirePrenom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoirePrenom($obligatoirePrenom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoirePrenom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoirePrenom)) {
                $obligatoirePrenom = str_replace('*', '%', $obligatoirePrenom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_PRENOM, $obligatoirePrenom, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_DATE_NAISSANCE column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireDateNaissance('fooValue');   // WHERE OBLIGATOIRE_DATE_NAISSANCE = 'fooValue'
     * $query->filterByObligatoireDateNaissance('%fooValue%'); // WHERE OBLIGATOIRE_DATE_NAISSANCE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireDateNaissance The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireDateNaissance($obligatoireDateNaissance = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireDateNaissance)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireDateNaissance)) {
                $obligatoireDateNaissance = str_replace('*', '%', $obligatoireDateNaissance);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE, $obligatoireDateNaissance, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_EMAIL column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireEmail('fooValue');   // WHERE OBLIGATOIRE_EMAIL = 'fooValue'
     * $query->filterByObligatoireEmail('%fooValue%'); // WHERE OBLIGATOIRE_EMAIL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireEmail The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireEmail($obligatoireEmail = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireEmail)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireEmail)) {
                $obligatoireEmail = str_replace('*', '%', $obligatoireEmail);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_EMAIL, $obligatoireEmail, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_IDENTIFIANT column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireIdentifiant('fooValue');   // WHERE OBLIGATOIRE_IDENTIFIANT = 'fooValue'
     * $query->filterByObligatoireIdentifiant('%fooValue%'); // WHERE OBLIGATOIRE_IDENTIFIANT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireIdentifiant The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireIdentifiant($obligatoireIdentifiant = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireIdentifiant)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireIdentifiant)) {
                $obligatoireIdentifiant = str_replace('*', '%', $obligatoireIdentifiant);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT, $obligatoireIdentifiant, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_TELEPHONE column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireTelephone('fooValue');   // WHERE OBLIGATOIRE_TELEPHONE = 'fooValue'
     * $query->filterByObligatoireTelephone('%fooValue%'); // WHERE OBLIGATOIRE_TELEPHONE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireTelephone The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireTelephone($obligatoireTelephone = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireTelephone)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireTelephone)) {
                $obligatoireTelephone = str_replace('*', '%', $obligatoireTelephone);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_TELEPHONE, $obligatoireTelephone, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_RAISON_SOCIAL column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireRaisonSocial('fooValue');   // WHERE OBLIGATOIRE_RAISON_SOCIAL = 'fooValue'
     * $query->filterByObligatoireRaisonSocial('%fooValue%'); // WHERE OBLIGATOIRE_RAISON_SOCIAL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireRaisonSocial The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireRaisonSocial($obligatoireRaisonSocial = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireRaisonSocial)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireRaisonSocial)) {
                $obligatoireRaisonSocial = str_replace('*', '%', $obligatoireRaisonSocial);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL, $obligatoireRaisonSocial, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_ADRESSE column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireAdresse('fooValue');   // WHERE OBLIGATOIRE_ADRESSE = 'fooValue'
     * $query->filterByObligatoireAdresse('%fooValue%'); // WHERE OBLIGATOIRE_ADRESSE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireAdresse The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireAdresse($obligatoireAdresse = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireAdresse)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireAdresse)) {
                $obligatoireAdresse = str_replace('*', '%', $obligatoireAdresse);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_ADRESSE, $obligatoireAdresse, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE_FAX column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoireFax('fooValue');   // WHERE OBLIGATOIRE_FAX = 'fooValue'
     * $query->filterByObligatoireFax('%fooValue%'); // WHERE OBLIGATOIRE_FAX LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoireFax The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByObligatoireFax($obligatoireFax = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoireFax)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoireFax)) {
                $obligatoireFax = str_replace('*', '%', $obligatoireFax);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::OBLIGATOIRE_FAX, $obligatoireFax, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_NOM column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleNom('fooValue');   // WHERE VISIBLE_NOM = 'fooValue'
     * $query->filterByVisibleNom('%fooValue%'); // WHERE VISIBLE_NOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleNom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleNom($visibleNom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleNom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleNom)) {
                $visibleNom = str_replace('*', '%', $visibleNom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_NOM, $visibleNom, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_PRENOM column
     *
     * Example usage:
     * <code>
     * $query->filterByVisiblePrenom('fooValue');   // WHERE VISIBLE_PRENOM = 'fooValue'
     * $query->filterByVisiblePrenom('%fooValue%'); // WHERE VISIBLE_PRENOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visiblePrenom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisiblePrenom($visiblePrenom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visiblePrenom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visiblePrenom)) {
                $visiblePrenom = str_replace('*', '%', $visiblePrenom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_PRENOM, $visiblePrenom, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_DATE_NAISSANCE column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleDateNaissance('fooValue');   // WHERE VISIBLE_DATE_NAISSANCE = 'fooValue'
     * $query->filterByVisibleDateNaissance('%fooValue%'); // WHERE VISIBLE_DATE_NAISSANCE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleDateNaissance The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleDateNaissance($visibleDateNaissance = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleDateNaissance)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleDateNaissance)) {
                $visibleDateNaissance = str_replace('*', '%', $visibleDateNaissance);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_DATE_NAISSANCE, $visibleDateNaissance, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_EMAIL column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleEmail('fooValue');   // WHERE VISIBLE_EMAIL = 'fooValue'
     * $query->filterByVisibleEmail('%fooValue%'); // WHERE VISIBLE_EMAIL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleEmail The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleEmail($visibleEmail = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleEmail)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleEmail)) {
                $visibleEmail = str_replace('*', '%', $visibleEmail);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_EMAIL, $visibleEmail, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_IDENTIFIANT column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleIdentifiant('fooValue');   // WHERE VISIBLE_IDENTIFIANT = 'fooValue'
     * $query->filterByVisibleIdentifiant('%fooValue%'); // WHERE VISIBLE_IDENTIFIANT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleIdentifiant The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleIdentifiant($visibleIdentifiant = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleIdentifiant)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleIdentifiant)) {
                $visibleIdentifiant = str_replace('*', '%', $visibleIdentifiant);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_IDENTIFIANT, $visibleIdentifiant, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_TELEPHONE column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleTelephone('fooValue');   // WHERE VISIBLE_TELEPHONE = 'fooValue'
     * $query->filterByVisibleTelephone('%fooValue%'); // WHERE VISIBLE_TELEPHONE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleTelephone The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleTelephone($visibleTelephone = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleTelephone)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleTelephone)) {
                $visibleTelephone = str_replace('*', '%', $visibleTelephone);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_TELEPHONE, $visibleTelephone, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_RAISON_SOCIAL column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleRaisonSocial('fooValue');   // WHERE VISIBLE_RAISON_SOCIAL = 'fooValue'
     * $query->filterByVisibleRaisonSocial('%fooValue%'); // WHERE VISIBLE_RAISON_SOCIAL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleRaisonSocial The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleRaisonSocial($visibleRaisonSocial = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleRaisonSocial)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleRaisonSocial)) {
                $visibleRaisonSocial = str_replace('*', '%', $visibleRaisonSocial);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_RAISON_SOCIAL, $visibleRaisonSocial, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_ADRESSE column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleAdresse('fooValue');   // WHERE VISIBLE_ADRESSE = 'fooValue'
     * $query->filterByVisibleAdresse('%fooValue%'); // WHERE VISIBLE_ADRESSE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleAdresse The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleAdresse($visibleAdresse = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleAdresse)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleAdresse)) {
                $visibleAdresse = str_replace('*', '%', $visibleAdresse);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_ADRESSE, $visibleAdresse, $comparison);
    }

    /**
     * Filter the query on the VISIBLE_FAX column
     *
     * Example usage:
     * <code>
     * $query->filterByVisibleFax('fooValue');   // WHERE VISIBLE_FAX = 'fooValue'
     * $query->filterByVisibleFax('%fooValue%'); // WHERE VISIBLE_FAX LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visibleFax The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByVisibleFax($visibleFax = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visibleFax)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visibleFax)) {
                $visibleFax = str_replace('*', '%', $visibleFax);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::VISIBLE_FAX, $visibleFax, $comparison);
    }

    /**
     * Filter the query on the TEXT_1_TYPE column
     *
     * Example usage:
     * <code>
     * $query->filterByText1Type('fooValue');   // WHERE TEXT_1_TYPE = 'fooValue'
     * $query->filterByText1Type('%fooValue%'); // WHERE TEXT_1_TYPE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text1Type The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText1Type($text1Type = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text1Type)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text1Type)) {
                $text1Type = str_replace('*', '%', $text1Type);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_1_TYPE, $text1Type, $comparison);
    }

    /**
     * Filter the query on the TEXT_2_TYPE column
     *
     * Example usage:
     * <code>
     * $query->filterByText2Type('fooValue');   // WHERE TEXT_2_TYPE = 'fooValue'
     * $query->filterByText2Type('%fooValue%'); // WHERE TEXT_2_TYPE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text2Type The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText2Type($text2Type = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text2Type)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text2Type)) {
                $text2Type = str_replace('*', '%', $text2Type);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_2_TYPE, $text2Type, $comparison);
    }

    /**
     * Filter the query on the TEXT_3_TYPE column
     *
     * Example usage:
     * <code>
     * $query->filterByText3Type('fooValue');   // WHERE TEXT_3_TYPE = 'fooValue'
     * $query->filterByText3Type('%fooValue%'); // WHERE TEXT_3_TYPE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text3Type The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText3Type($text3Type = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text3Type)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text3Type)) {
                $text3Type = str_replace('*', '%', $text3Type);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_3_TYPE, $text3Type, $comparison);
    }

    /**
     * Filter the query on the TEXT_1_LISTE column
     *
     * Example usage:
     * <code>
     * $query->filterByText1Liste('fooValue');   // WHERE TEXT_1_LISTE = 'fooValue'
     * $query->filterByText1Liste('%fooValue%'); // WHERE TEXT_1_LISTE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text1Liste The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText1Liste($text1Liste = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text1Liste)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text1Liste)) {
                $text1Liste = str_replace('*', '%', $text1Liste);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_1_LISTE, $text1Liste, $comparison);
    }

    /**
     * Filter the query on the TEXT_2_LISTE column
     *
     * Example usage:
     * <code>
     * $query->filterByText2Liste('fooValue');   // WHERE TEXT_2_LISTE = 'fooValue'
     * $query->filterByText2Liste('%fooValue%'); // WHERE TEXT_2_LISTE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text2Liste The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText2Liste($text2Liste = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text2Liste)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text2Liste)) {
                $text2Liste = str_replace('*', '%', $text2Liste);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_2_LISTE, $text2Liste, $comparison);
    }

    /**
     * Filter the query on the TEXT_3_LISTE column
     *
     * Example usage:
     * <code>
     * $query->filterByText3Liste('fooValue');   // WHERE TEXT_3_LISTE = 'fooValue'
     * $query->filterByText3Liste('%fooValue%'); // WHERE TEXT_3_LISTE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text3Liste The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function filterByText3Liste($text3Liste = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text3Liste)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text3Liste)) {
                $text3Liste = str_replace('*', '%', $text3Liste);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TParametreFormPeer::TEXT_3_LISTE, $text3Liste, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeCommentaire($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_COMMENTAIRE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_COMMENTAIRE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeCommentaire() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeCommentaire($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeCommentaire');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeCommentaire');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeCommentaire relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeCommentaireQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeCommentaire($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeCommentaire', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleRef1($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_1, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_1, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleRef1() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleRef1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleRef1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleRef1');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleRef1 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleRef1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleRef1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleRef1', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleRef2($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_2, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_2, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleRef2() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleRef2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleRef2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleRef2');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleRef2 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleRef2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleRef2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleRef2', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleRef3($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_3, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_REF_3, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleRef3() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleRef3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleRef3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleRef3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleRef3');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleRef3 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleRef3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleRef3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleRef3', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleText1($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_1, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_1, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleText1() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleText1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleText1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleText1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleText1');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleText1 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleText1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleText1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleText1', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleText2($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_2, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_2, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleText2() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleText2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleText2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleText2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleText2');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleText2 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleText2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleText2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleText2', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelleText3($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_3, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::CODE_LIBELLE_TEXT_3, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelleText3() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelleText3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelleText3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelleText3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelleText3');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelleText3 relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleText3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelleText3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelleText3', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TReferentiel object
     *
     * @param   TReferentiel|PropelObjectCollection $tReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferentielRelatedByIdRef1($tReferentiel, $comparison = null)
    {
        if ($tReferentiel instanceof TReferentiel) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_REF_1, $tReferentiel->getIdReferentiel(), $comparison);
        } elseif ($tReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::ID_REF_1, $tReferentiel->toKeyValue('PrimaryKey', 'IdReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTReferentielRelatedByIdRef1() only accepts arguments of type TReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferentielRelatedByIdRef1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTReferentielRelatedByIdRef1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferentielRelatedByIdRef1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferentielRelatedByIdRef1');
        }

        return $this;
    }

    /**
     * Use the TReferentielRelatedByIdRef1 relation TReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTReferentielRelatedByIdRef1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTReferentielRelatedByIdRef1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferentielRelatedByIdRef1', 'TReferentielQuery');
    }

    /**
     * Filter the query by a related TReferentiel object
     *
     * @param   TReferentiel|PropelObjectCollection $tReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferentielRelatedByIdRef2($tReferentiel, $comparison = null)
    {
        if ($tReferentiel instanceof TReferentiel) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_REF_2, $tReferentiel->getIdReferentiel(), $comparison);
        } elseif ($tReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::ID_REF_2, $tReferentiel->toKeyValue('PrimaryKey', 'IdReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTReferentielRelatedByIdRef2() only accepts arguments of type TReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferentielRelatedByIdRef2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTReferentielRelatedByIdRef2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferentielRelatedByIdRef2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferentielRelatedByIdRef2');
        }

        return $this;
    }

    /**
     * Use the TReferentielRelatedByIdRef2 relation TReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTReferentielRelatedByIdRef2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTReferentielRelatedByIdRef2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferentielRelatedByIdRef2', 'TReferentielQuery');
    }

    /**
     * Filter the query by a related TReferentiel object
     *
     * @param   TReferentiel|PropelObjectCollection $tReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferentielRelatedByIdRef3($tReferentiel, $comparison = null)
    {
        if ($tReferentiel instanceof TReferentiel) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_REF_3, $tReferentiel->getIdReferentiel(), $comparison);
        } elseif ($tReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TParametreFormPeer::ID_REF_3, $tReferentiel->toKeyValue('PrimaryKey', 'IdReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTReferentielRelatedByIdRef3() only accepts arguments of type TReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferentielRelatedByIdRef3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTReferentielRelatedByIdRef3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferentielRelatedByIdRef3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferentielRelatedByIdRef3');
        }

        return $this;
    }

    /**
     * Use the TReferentielRelatedByIdRef3 relation TReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTReferentielRelatedByIdRef3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTReferentielRelatedByIdRef3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferentielRelatedByIdRef3', 'TReferentielQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $tOrganisation->getIdParametreForm(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationQuery()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTOrganisation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TParametragePrestation object
     *
     * @param   TParametragePrestation|PropelObjectCollection $tParametragePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametragePrestation($tParametragePrestation, $comparison = null)
    {
        if ($tParametragePrestation instanceof TParametragePrestation) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $tParametragePrestation->getIdParametreForm(), $comparison);
        } elseif ($tParametragePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTParametragePrestationQuery()
                ->filterByPrimaryKeys($tParametragePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametragePrestation() only accepts arguments of type TParametragePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametragePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTParametragePrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametragePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametragePrestation');
        }

        return $this;
    }

    /**
     * Use the TParametragePrestation relation TParametragePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametragePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTParametragePrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametragePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametragePrestation', 'TParametragePrestationQuery');
    }

    /**
     * Filter the query by a related TPieceParamForm object
     *
     * @param   TPieceParamForm|PropelObjectCollection $tPieceParamForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPieceParamForm($tPieceParamForm, $comparison = null)
    {
        if ($tPieceParamForm instanceof TPieceParamForm) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $tPieceParamForm->getIdParametreForm(), $comparison);
        } elseif ($tPieceParamForm instanceof PropelObjectCollection) {
            return $this
                ->useTPieceParamFormQuery()
                ->filterByPrimaryKeys($tPieceParamForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPieceParamForm() only accepts arguments of type TPieceParamForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPieceParamForm relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTPieceParamForm($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPieceParamForm');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPieceParamForm');
        }

        return $this;
    }

    /**
     * Use the TPieceParamForm relation TPieceParamForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPieceParamFormQuery A secondary query class using the current class as primary query
     */
    public function useTPieceParamFormQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPieceParamForm($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPieceParamForm', 'TPieceParamFormQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $tPrestation->getIdParametreForm(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTPrestationQuery()
                ->filterByPrimaryKeys($tPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTPrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestation', 'TPrestationQuery');
    }

    /**
     * Filter the query by a related TRefPrestation object
     *
     * @param   TRefPrestation|PropelObjectCollection $tRefPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TParametreFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefPrestation($tRefPrestation, $comparison = null)
    {
        if ($tRefPrestation instanceof TRefPrestation) {
            return $this
                ->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $tRefPrestation->getIdParametreForm(), $comparison);
        } elseif ($tRefPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTRefPrestationQuery()
                ->filterByPrimaryKeys($tRefPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRefPrestation() only accepts arguments of type TRefPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function joinTRefPrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefPrestation');
        }

        return $this;
    }

    /**
     * Use the TRefPrestation relation TRefPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefPrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRefPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefPrestation', 'TRefPrestationQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TParametreForm $tParametreForm Object to remove from the list of results
     *
     * @return TParametreFormQuery The current query, for fluid interface
     */
    public function prune($tParametreForm = null)
    {
        if ($tParametreForm) {
            $this->addUsingAlias(TParametreFormPeer::ID_PARAMETRE_FORM, $tParametreForm->getIdParametreForm(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
