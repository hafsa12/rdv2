<?php


/**
 * Base class that represents a row from the 'T_PARAMETRAGE_PRESTATION' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTParametragePrestation extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TParametragePrestationPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TParametragePrestationPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_parametrage_prestation field.
     * @var        int
     */
    protected $id_parametrage_prestation;

    /**
     * The value for the id_organisation field.
     * @var        int
     */
    protected $id_organisation;

    /**
     * The value for the id_ref_type_prestation field.
     * @var        int
     */
    protected $id_ref_type_prestation;

    /**
     * The value for the id_ref_prestation field.
     * @var        int
     */
    protected $id_ref_prestation;

    /**
     * The value for the rdv_similaire field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $rdv_similaire;

    /**
     * The value for the nb_jour_rdv_similaire field.
     * @var        int
     */
    protected $nb_jour_rdv_similaire;

    /**
     * The value for the delai_min field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $delai_min;

    /**
     * The value for the periodicite field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $periodicite;

    /**
     * The value for the ressource_visible field.
     * Note: this column has a database default value of: '1'
     * @var        string
     */
    protected $ressource_visible;

    /**
     * The value for the ressource_obligatoire field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $ressource_obligatoire;

    /**
     * The value for the id_parametre_form field.
     * @var        int
     */
    protected $id_parametre_form;

    /**
     * The value for the code_commentaire field.
     * @var        int
     */
    protected $code_commentaire;

    /**
     * The value for the referent_visible field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $referent_visible;

    /**
     * The value for the code_aide field.
     * @var        int
     */
    protected $code_aide;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeCommentaire;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisation;

    /**
     * @var        TParametreForm
     */
    protected $aTParametreForm;

    /**
     * @var        TRefPrestation
     */
    protected $aTRefPrestation;

    /**
     * @var        TRefTypePrestation
     */
    protected $aTRefTypePrestation;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeAide;

    /**
     * @var        PropelObjectCollection|TPieceParamPresta[] Collection to store aggregation of TPieceParamPresta objects.
     */
    protected $collTPieceParamPrestas;
    protected $collTPieceParamPrestasPartial;

    /**
     * @var        PropelObjectCollection|TPrestation[] Collection to store aggregation of TPrestation objects.
     */
    protected $collTPrestations;
    protected $collTPrestationsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPieceParamPrestasScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPrestationsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->rdv_similaire = '0';
        $this->delai_min = 0;
        $this->periodicite = 0;
        $this->ressource_visible = '1';
        $this->ressource_obligatoire = '0';
        $this->referent_visible = '0';
    }

    /**
     * Initializes internal state of BaseTParametragePrestation object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_parametrage_prestation] column value.
     *
     * @return int
     */
    public function getIdParametragePrestation()
    {
        return $this->id_parametrage_prestation;
    }

    /**
     * Get the [id_organisation] column value.
     *
     * @return int
     */
    public function getIdOrganisation()
    {
        return $this->id_organisation;
    }

    /**
     * Get the [id_ref_type_prestation] column value.
     *
     * @return int
     */
    public function getIdRefTypePrestation()
    {
        return $this->id_ref_type_prestation;
    }

    /**
     * Get the [id_ref_prestation] column value.
     *
     * @return int
     */
    public function getIdRefPrestation()
    {
        return $this->id_ref_prestation;
    }

    /**
     * Get the [rdv_similaire] column value.
     *
     * @return string
     */
    public function getRdvSimilaire()
    {
        return $this->rdv_similaire;
    }

    /**
     * Get the [nb_jour_rdv_similaire] column value.
     *
     * @return int
     */
    public function getNbJourRdvSimilaire()
    {
        return $this->nb_jour_rdv_similaire;
    }

    /**
     * Get the [delai_min] column value.
     *
     * @return int
     */
    public function getDelaiMin()
    {
        return $this->delai_min;
    }

    /**
     * Get the [periodicite] column value.
     *
     * @return int
     */
    public function getPeriodicite()
    {
        return $this->periodicite;
    }

    /**
     * Get the [ressource_visible] column value.
     *
     * @return string
     */
    public function getRessourceVisible()
    {
        return $this->ressource_visible;
    }

    /**
     * Get the [ressource_obligatoire] column value.
     *
     * @return string
     */
    public function getRessourceObligatoire()
    {
        return $this->ressource_obligatoire;
    }

    /**
     * Get the [id_parametre_form] column value.
     *
     * @return int
     */
    public function getIdParametreForm()
    {
        return $this->id_parametre_form;
    }

    /**
     * Get the [code_commentaire] column value.
     *
     * @return int
     */
    public function getCodeCommentaire()
    {
        return $this->code_commentaire;
    }

    /**
     * Get the [referent_visible] column value.
     *
     * @return string
     */
    public function getReferentVisible()
    {
        return $this->referent_visible;
    }

    /**
     * Get the [code_aide] column value.
     *
     * @return int
     */
    public function getCodeAide()
    {
        return $this->code_aide;
    }

    /**
     * Set the value of [id_parametrage_prestation] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setIdParametragePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_parametrage_prestation !== $v) {
            $this->id_parametrage_prestation = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION;
        }


        return $this;
    } // setIdParametragePrestation()

    /**
     * Set the value of [id_organisation] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setIdOrganisation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation !== $v) {
            $this->id_organisation = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::ID_ORGANISATION;
        }

        if ($this->aTOrganisation !== null && $this->aTOrganisation->getIdOrganisation() !== $v) {
            $this->aTOrganisation = null;
        }


        return $this;
    } // setIdOrganisation()

    /**
     * Set the value of [id_ref_type_prestation] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setIdRefTypePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_type_prestation !== $v) {
            $this->id_ref_type_prestation = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::ID_REF_TYPE_PRESTATION;
        }

        if ($this->aTRefTypePrestation !== null && $this->aTRefTypePrestation->getIdRefTypePrestation() !== $v) {
            $this->aTRefTypePrestation = null;
        }


        return $this;
    } // setIdRefTypePrestation()

    /**
     * Set the value of [id_ref_prestation] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setIdRefPrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_prestation !== $v) {
            $this->id_ref_prestation = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::ID_REF_PRESTATION;
        }

        if ($this->aTRefPrestation !== null && $this->aTRefPrestation->getIdRefPrestation() !== $v) {
            $this->aTRefPrestation = null;
        }


        return $this;
    } // setIdRefPrestation()

    /**
     * Set the value of [rdv_similaire] column.
     *
     * @param string $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setRdvSimilaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->rdv_similaire !== $v) {
            $this->rdv_similaire = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::RDV_SIMILAIRE;
        }


        return $this;
    } // setRdvSimilaire()

    /**
     * Set the value of [nb_jour_rdv_similaire] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setNbJourRdvSimilaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->nb_jour_rdv_similaire !== $v) {
            $this->nb_jour_rdv_similaire = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::NB_JOUR_RDV_SIMILAIRE;
        }


        return $this;
    } // setNbJourRdvSimilaire()

    /**
     * Set the value of [delai_min] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setDelaiMin($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->delai_min !== $v) {
            $this->delai_min = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::DELAI_MIN;
        }


        return $this;
    } // setDelaiMin()

    /**
     * Set the value of [periodicite] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setPeriodicite($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->periodicite !== $v) {
            $this->periodicite = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::PERIODICITE;
        }


        return $this;
    } // setPeriodicite()

    /**
     * Set the value of [ressource_visible] column.
     *
     * @param string $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setRessourceVisible($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ressource_visible !== $v) {
            $this->ressource_visible = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::RESSOURCE_VISIBLE;
        }


        return $this;
    } // setRessourceVisible()

    /**
     * Set the value of [ressource_obligatoire] column.
     *
     * @param string $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setRessourceObligatoire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ressource_obligatoire !== $v) {
            $this->ressource_obligatoire = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::RESSOURCE_OBLIGATOIRE;
        }


        return $this;
    } // setRessourceObligatoire()

    /**
     * Set the value of [id_parametre_form] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setIdParametreForm($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_parametre_form !== $v) {
            $this->id_parametre_form = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::ID_PARAMETRE_FORM;
        }

        if ($this->aTParametreForm !== null && $this->aTParametreForm->getIdParametreForm() !== $v) {
            $this->aTParametreForm = null;
        }


        return $this;
    } // setIdParametreForm()

    /**
     * Set the value of [code_commentaire] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setCodeCommentaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_commentaire !== $v) {
            $this->code_commentaire = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::CODE_COMMENTAIRE;
        }

        if ($this->aTTraductionRelatedByCodeCommentaire !== null && $this->aTTraductionRelatedByCodeCommentaire->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeCommentaire = null;
        }


        return $this;
    } // setCodeCommentaire()

    /**
     * Set the value of [referent_visible] column.
     *
     * @param string $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setReferentVisible($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->referent_visible !== $v) {
            $this->referent_visible = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::REFERENT_VISIBLE;
        }


        return $this;
    } // setReferentVisible()

    /**
     * Set the value of [code_aide] column.
     *
     * @param int $v new value
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setCodeAide($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_aide !== $v) {
            $this->code_aide = $v;
            $this->modifiedColumns[] = TParametragePrestationPeer::CODE_AIDE;
        }

        if ($this->aTTraductionRelatedByCodeAide !== null && $this->aTTraductionRelatedByCodeAide->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeAide = null;
        }


        return $this;
    } // setCodeAide()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->rdv_similaire !== '0') {
                return false;
            }

            if ($this->delai_min !== 0) {
                return false;
            }

            if ($this->periodicite !== 0) {
                return false;
            }

            if ($this->ressource_visible !== '1') {
                return false;
            }

            if ($this->ressource_obligatoire !== '0') {
                return false;
            }

            if ($this->referent_visible !== '0') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_parametrage_prestation = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->id_organisation = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->id_ref_type_prestation = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->id_ref_prestation = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->rdv_similaire = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->nb_jour_rdv_similaire = ($row[$startcol + 5] !== null) ? (int) $row[$startcol + 5] : null;
            $this->delai_min = ($row[$startcol + 6] !== null) ? (int) $row[$startcol + 6] : null;
            $this->periodicite = ($row[$startcol + 7] !== null) ? (int) $row[$startcol + 7] : null;
            $this->ressource_visible = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->ressource_obligatoire = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->id_parametre_form = ($row[$startcol + 10] !== null) ? (int) $row[$startcol + 10] : null;
            $this->code_commentaire = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->referent_visible = ($row[$startcol + 12] !== null) ? (string) $row[$startcol + 12] : null;
            $this->code_aide = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 14; // 14 = TParametragePrestationPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TParametragePrestation object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTOrganisation !== null && $this->id_organisation !== $this->aTOrganisation->getIdOrganisation()) {
            $this->aTOrganisation = null;
        }
        if ($this->aTRefTypePrestation !== null && $this->id_ref_type_prestation !== $this->aTRefTypePrestation->getIdRefTypePrestation()) {
            $this->aTRefTypePrestation = null;
        }
        if ($this->aTRefPrestation !== null && $this->id_ref_prestation !== $this->aTRefPrestation->getIdRefPrestation()) {
            $this->aTRefPrestation = null;
        }
        if ($this->aTParametreForm !== null && $this->id_parametre_form !== $this->aTParametreForm->getIdParametreForm()) {
            $this->aTParametreForm = null;
        }
        if ($this->aTTraductionRelatedByCodeCommentaire !== null && $this->code_commentaire !== $this->aTTraductionRelatedByCodeCommentaire->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeCommentaire = null;
        }
        if ($this->aTTraductionRelatedByCodeAide !== null && $this->code_aide !== $this->aTTraductionRelatedByCodeAide->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeAide = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TParametragePrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TParametragePrestationPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraductionRelatedByCodeCommentaire = null;
            $this->aTOrganisation = null;
            $this->aTParametreForm = null;
            $this->aTRefPrestation = null;
            $this->aTRefTypePrestation = null;
            $this->aTTraductionRelatedByCodeAide = null;
            $this->collTPieceParamPrestas = null;

            $this->collTPrestations = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TParametragePrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TParametragePrestationQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TParametragePrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TParametragePrestationPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeCommentaire !== null) {
                if ($this->aTTraductionRelatedByCodeCommentaire->isModified() || $this->aTTraductionRelatedByCodeCommentaire->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeCommentaire->save($con);
                }
                $this->setTTraductionRelatedByCodeCommentaire($this->aTTraductionRelatedByCodeCommentaire);
            }

            if ($this->aTOrganisation !== null) {
                if ($this->aTOrganisation->isModified() || $this->aTOrganisation->isNew()) {
                    $affectedRows += $this->aTOrganisation->save($con);
                }
                $this->setTOrganisation($this->aTOrganisation);
            }

            if ($this->aTParametreForm !== null) {
                if ($this->aTParametreForm->isModified() || $this->aTParametreForm->isNew()) {
                    $affectedRows += $this->aTParametreForm->save($con);
                }
                $this->setTParametreForm($this->aTParametreForm);
            }

            if ($this->aTRefPrestation !== null) {
                if ($this->aTRefPrestation->isModified() || $this->aTRefPrestation->isNew()) {
                    $affectedRows += $this->aTRefPrestation->save($con);
                }
                $this->setTRefPrestation($this->aTRefPrestation);
            }

            if ($this->aTRefTypePrestation !== null) {
                if ($this->aTRefTypePrestation->isModified() || $this->aTRefTypePrestation->isNew()) {
                    $affectedRows += $this->aTRefTypePrestation->save($con);
                }
                $this->setTRefTypePrestation($this->aTRefTypePrestation);
            }

            if ($this->aTTraductionRelatedByCodeAide !== null) {
                if ($this->aTTraductionRelatedByCodeAide->isModified() || $this->aTTraductionRelatedByCodeAide->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeAide->save($con);
                }
                $this->setTTraductionRelatedByCodeAide($this->aTTraductionRelatedByCodeAide);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tPieceParamPrestasScheduledForDeletion !== null) {
                if (!$this->tPieceParamPrestasScheduledForDeletion->isEmpty()) {
                    TPieceParamPrestaQuery::create()
                        ->filterByPrimaryKeys($this->tPieceParamPrestasScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tPieceParamPrestasScheduledForDeletion = null;
                }
            }

            if ($this->collTPieceParamPrestas !== null) {
                foreach ($this->collTPieceParamPrestas as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPrestationsScheduledForDeletion !== null) {
                if (!$this->tPrestationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tPrestationsScheduledForDeletion as $tPrestation) {
                        // need to save related object because we set the relation to null
                        $tPrestation->save($con);
                    }
                    $this->tPrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTPrestations !== null) {
                foreach ($this->collTPrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION;
        if (null !== $this->id_parametrage_prestation) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PARAMETRAGE_PRESTATION`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::ID_ORGANISATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_TYPE_PRESTATION`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::ID_REF_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_PRESTATION`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::RDV_SIMILAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`RDV_SIMILAIRE`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::NB_JOUR_RDV_SIMILAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`NB_JOUR_RDV_SIMILAIRE`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::DELAI_MIN)) {
            $modifiedColumns[':p' . $index++]  = '`DELAI_MIN`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::PERIODICITE)) {
            $modifiedColumns[':p' . $index++]  = '`PERIODICITE`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::RESSOURCE_VISIBLE)) {
            $modifiedColumns[':p' . $index++]  = '`RESSOURCE_VISIBLE`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::RESSOURCE_OBLIGATOIRE)) {
            $modifiedColumns[':p' . $index++]  = '`RESSOURCE_OBLIGATOIRE`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::ID_PARAMETRE_FORM)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PARAMETRE_FORM`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::CODE_COMMENTAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_COMMENTAIRE`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::REFERENT_VISIBLE)) {
            $modifiedColumns[':p' . $index++]  = '`REFERENT_VISIBLE`';
        }
        if ($this->isColumnModified(TParametragePrestationPeer::CODE_AIDE)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_AIDE`';
        }

        $sql = sprintf(
            'INSERT INTO `T_PARAMETRAGE_PRESTATION` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_PARAMETRAGE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_parametrage_prestation, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION`':
                        $stmt->bindValue($identifier, $this->id_organisation, PDO::PARAM_INT);
                        break;
                    case '`ID_REF_TYPE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_ref_type_prestation, PDO::PARAM_INT);
                        break;
                    case '`ID_REF_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_ref_prestation, PDO::PARAM_INT);
                        break;
                    case '`RDV_SIMILAIRE`':
                        $stmt->bindValue($identifier, $this->rdv_similaire, PDO::PARAM_STR);
                        break;
                    case '`NB_JOUR_RDV_SIMILAIRE`':
                        $stmt->bindValue($identifier, $this->nb_jour_rdv_similaire, PDO::PARAM_INT);
                        break;
                    case '`DELAI_MIN`':
                        $stmt->bindValue($identifier, $this->delai_min, PDO::PARAM_INT);
                        break;
                    case '`PERIODICITE`':
                        $stmt->bindValue($identifier, $this->periodicite, PDO::PARAM_INT);
                        break;
                    case '`RESSOURCE_VISIBLE`':
                        $stmt->bindValue($identifier, $this->ressource_visible, PDO::PARAM_STR);
                        break;
                    case '`RESSOURCE_OBLIGATOIRE`':
                        $stmt->bindValue($identifier, $this->ressource_obligatoire, PDO::PARAM_STR);
                        break;
                    case '`ID_PARAMETRE_FORM`':
                        $stmt->bindValue($identifier, $this->id_parametre_form, PDO::PARAM_INT);
                        break;
                    case '`CODE_COMMENTAIRE`':
                        $stmt->bindValue($identifier, $this->code_commentaire, PDO::PARAM_INT);
                        break;
                    case '`REFERENT_VISIBLE`':
                        $stmt->bindValue($identifier, $this->referent_visible, PDO::PARAM_STR);
                        break;
                    case '`CODE_AIDE`':
                        $stmt->bindValue($identifier, $this->code_aide, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdParametragePrestation($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeCommentaire !== null) {
                if (!$this->aTTraductionRelatedByCodeCommentaire->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeCommentaire->getValidationFailures());
                }
            }

            if ($this->aTOrganisation !== null) {
                if (!$this->aTOrganisation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisation->getValidationFailures());
                }
            }

            if ($this->aTParametreForm !== null) {
                if (!$this->aTParametreForm->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTParametreForm->getValidationFailures());
                }
            }

            if ($this->aTRefPrestation !== null) {
                if (!$this->aTRefPrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTRefPrestation->getValidationFailures());
                }
            }

            if ($this->aTRefTypePrestation !== null) {
                if (!$this->aTRefTypePrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTRefTypePrestation->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeAide !== null) {
                if (!$this->aTTraductionRelatedByCodeAide->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeAide->getValidationFailures());
                }
            }


            if (($retval = TParametragePrestationPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTPieceParamPrestas !== null) {
                    foreach ($this->collTPieceParamPrestas as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPrestations !== null) {
                    foreach ($this->collTPrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TParametragePrestationPeer::DATABASE_NAME);

        if ($this->isColumnModified(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION)) $criteria->add(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $this->id_parametrage_prestation);
        if ($this->isColumnModified(TParametragePrestationPeer::ID_ORGANISATION)) $criteria->add(TParametragePrestationPeer::ID_ORGANISATION, $this->id_organisation);
        if ($this->isColumnModified(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION)) $criteria->add(TParametragePrestationPeer::ID_REF_TYPE_PRESTATION, $this->id_ref_type_prestation);
        if ($this->isColumnModified(TParametragePrestationPeer::ID_REF_PRESTATION)) $criteria->add(TParametragePrestationPeer::ID_REF_PRESTATION, $this->id_ref_prestation);
        if ($this->isColumnModified(TParametragePrestationPeer::RDV_SIMILAIRE)) $criteria->add(TParametragePrestationPeer::RDV_SIMILAIRE, $this->rdv_similaire);
        if ($this->isColumnModified(TParametragePrestationPeer::NB_JOUR_RDV_SIMILAIRE)) $criteria->add(TParametragePrestationPeer::NB_JOUR_RDV_SIMILAIRE, $this->nb_jour_rdv_similaire);
        if ($this->isColumnModified(TParametragePrestationPeer::DELAI_MIN)) $criteria->add(TParametragePrestationPeer::DELAI_MIN, $this->delai_min);
        if ($this->isColumnModified(TParametragePrestationPeer::PERIODICITE)) $criteria->add(TParametragePrestationPeer::PERIODICITE, $this->periodicite);
        if ($this->isColumnModified(TParametragePrestationPeer::RESSOURCE_VISIBLE)) $criteria->add(TParametragePrestationPeer::RESSOURCE_VISIBLE, $this->ressource_visible);
        if ($this->isColumnModified(TParametragePrestationPeer::RESSOURCE_OBLIGATOIRE)) $criteria->add(TParametragePrestationPeer::RESSOURCE_OBLIGATOIRE, $this->ressource_obligatoire);
        if ($this->isColumnModified(TParametragePrestationPeer::ID_PARAMETRE_FORM)) $criteria->add(TParametragePrestationPeer::ID_PARAMETRE_FORM, $this->id_parametre_form);
        if ($this->isColumnModified(TParametragePrestationPeer::CODE_COMMENTAIRE)) $criteria->add(TParametragePrestationPeer::CODE_COMMENTAIRE, $this->code_commentaire);
        if ($this->isColumnModified(TParametragePrestationPeer::REFERENT_VISIBLE)) $criteria->add(TParametragePrestationPeer::REFERENT_VISIBLE, $this->referent_visible);
        if ($this->isColumnModified(TParametragePrestationPeer::CODE_AIDE)) $criteria->add(TParametragePrestationPeer::CODE_AIDE, $this->code_aide);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TParametragePrestationPeer::DATABASE_NAME);
        $criteria->add(TParametragePrestationPeer::ID_PARAMETRAGE_PRESTATION, $this->id_parametrage_prestation);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdParametragePrestation();
    }

    /**
     * Generic method to set the primary key (id_parametrage_prestation column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdParametragePrestation($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdParametragePrestation();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TParametragePrestation (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setIdOrganisation($this->getIdOrganisation());
        $copyObj->setIdRefTypePrestation($this->getIdRefTypePrestation());
        $copyObj->setIdRefPrestation($this->getIdRefPrestation());
        $copyObj->setRdvSimilaire($this->getRdvSimilaire());
        $copyObj->setNbJourRdvSimilaire($this->getNbJourRdvSimilaire());
        $copyObj->setDelaiMin($this->getDelaiMin());
        $copyObj->setPeriodicite($this->getPeriodicite());
        $copyObj->setRessourceVisible($this->getRessourceVisible());
        $copyObj->setRessourceObligatoire($this->getRessourceObligatoire());
        $copyObj->setIdParametreForm($this->getIdParametreForm());
        $copyObj->setCodeCommentaire($this->getCodeCommentaire());
        $copyObj->setReferentVisible($this->getReferentVisible());
        $copyObj->setCodeAide($this->getCodeAide());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTPieceParamPrestas() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPieceParamPresta($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPrestation($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdParametragePrestation(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TParametragePrestation Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TParametragePrestationPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TParametragePrestationPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametragePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeCommentaire(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeCommentaire(NULL);
        } else {
            $this->setCodeCommentaire($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeCommentaire = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametragePrestationRelatedByCodeCommentaire($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeCommentaire(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeCommentaire === null && ($this->code_commentaire !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeCommentaire = TTraductionQuery::create()->findPk($this->code_commentaire, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeCommentaire->addTParametragePrestationsRelatedByCodeCommentaire($this);
             */
        }

        return $this->aTTraductionRelatedByCodeCommentaire;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TParametragePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisation(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisation(NULL);
        } else {
            $this->setIdOrganisation($v->getIdOrganisation());
        }

        $this->aTOrganisation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametragePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisation === null && ($this->id_organisation !== null) && $doQuery) {
            $this->aTOrganisation = TOrganisationQuery::create()->findPk($this->id_organisation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisation->addTParametragePrestations($this);
             */
        }

        return $this->aTOrganisation;
    }

    /**
     * Declares an association between this object and a TParametreForm object.
     *
     * @param             TParametreForm $v
     * @return TParametragePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTParametreForm(TParametreForm $v = null)
    {
        if ($v === null) {
            $this->setIdParametreForm(NULL);
        } else {
            $this->setIdParametreForm($v->getIdParametreForm());
        }

        $this->aTParametreForm = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TParametreForm object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametragePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TParametreForm object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TParametreForm The associated TParametreForm object.
     * @throws PropelException
     */
    public function getTParametreForm(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTParametreForm === null && ($this->id_parametre_form !== null) && $doQuery) {
            $this->aTParametreForm = TParametreFormQuery::create()->findPk($this->id_parametre_form, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTParametreForm->addTParametragePrestations($this);
             */
        }

        return $this->aTParametreForm;
    }

    /**
     * Declares an association between this object and a TRefPrestation object.
     *
     * @param             TRefPrestation $v
     * @return TParametragePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTRefPrestation(TRefPrestation $v = null)
    {
        if ($v === null) {
            $this->setIdRefPrestation(NULL);
        } else {
            $this->setIdRefPrestation($v->getIdRefPrestation());
        }

        $this->aTRefPrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TRefPrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametragePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TRefPrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TRefPrestation The associated TRefPrestation object.
     * @throws PropelException
     */
    public function getTRefPrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTRefPrestation === null && ($this->id_ref_prestation !== null) && $doQuery) {
            $this->aTRefPrestation = TRefPrestationQuery::create()->findPk($this->id_ref_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTRefPrestation->addTParametragePrestations($this);
             */
        }

        return $this->aTRefPrestation;
    }

    /**
     * Declares an association between this object and a TRefTypePrestation object.
     *
     * @param             TRefTypePrestation $v
     * @return TParametragePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTRefTypePrestation(TRefTypePrestation $v = null)
    {
        if ($v === null) {
            $this->setIdRefTypePrestation(NULL);
        } else {
            $this->setIdRefTypePrestation($v->getIdRefTypePrestation());
        }

        $this->aTRefTypePrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TRefTypePrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametragePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TRefTypePrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TRefTypePrestation The associated TRefTypePrestation object.
     * @throws PropelException
     */
    public function getTRefTypePrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTRefTypePrestation === null && ($this->id_ref_type_prestation !== null) && $doQuery) {
            $this->aTRefTypePrestation = TRefTypePrestationQuery::create()->findPk($this->id_ref_type_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTRefTypePrestation->addTParametragePrestations($this);
             */
        }

        return $this->aTRefTypePrestation;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametragePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeAide(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeAide(NULL);
        } else {
            $this->setCodeAide($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeAide = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametragePrestationRelatedByCodeAide($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeAide(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeAide === null && ($this->code_aide !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeAide = TTraductionQuery::create()->findPk($this->code_aide, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeAide->addTParametragePrestationsRelatedByCodeAide($this);
             */
        }

        return $this->aTTraductionRelatedByCodeAide;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TPieceParamPresta' == $relationName) {
            $this->initTPieceParamPrestas();
        }
        if ('TPrestation' == $relationName) {
            $this->initTPrestations();
        }
    }

    /**
     * Clears out the collTPieceParamPrestas collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TParametragePrestation The current object (for fluent API support)
     * @see        addTPieceParamPrestas()
     */
    public function clearTPieceParamPrestas()
    {
        $this->collTPieceParamPrestas = null; // important to set this to null since that means it is uninitialized
        $this->collTPieceParamPrestasPartial = null;

        return $this;
    }

    /**
     * reset is the collTPieceParamPrestas collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPieceParamPrestas($v = true)
    {
        $this->collTPieceParamPrestasPartial = $v;
    }

    /**
     * Initializes the collTPieceParamPrestas collection.
     *
     * By default this just sets the collTPieceParamPrestas collection to an empty array (like clearcollTPieceParamPrestas());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPieceParamPrestas($overrideExisting = true)
    {
        if (null !== $this->collTPieceParamPrestas && !$overrideExisting) {
            return;
        }
        $this->collTPieceParamPrestas = new PropelObjectCollection();
        $this->collTPieceParamPrestas->setModel('TPieceParamPresta');
    }

    /**
     * Gets an array of TPieceParamPresta objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TParametragePrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPieceParamPresta[] List of TPieceParamPresta objects
     * @throws PropelException
     */
    public function getTPieceParamPrestas($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPieceParamPrestasPartial && !$this->isNew();
        if (null === $this->collTPieceParamPrestas || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPieceParamPrestas) {
                // return empty collection
                $this->initTPieceParamPrestas();
            } else {
                $collTPieceParamPrestas = TPieceParamPrestaQuery::create(null, $criteria)
                    ->filterByTParametragePrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPieceParamPrestasPartial && count($collTPieceParamPrestas)) {
                      $this->initTPieceParamPrestas(false);

                      foreach($collTPieceParamPrestas as $obj) {
                        if (false == $this->collTPieceParamPrestas->contains($obj)) {
                          $this->collTPieceParamPrestas->append($obj);
                        }
                      }

                      $this->collTPieceParamPrestasPartial = true;
                    }

                    $collTPieceParamPrestas->getInternalIterator()->rewind();
                    return $collTPieceParamPrestas;
                }

                if($partial && $this->collTPieceParamPrestas) {
                    foreach($this->collTPieceParamPrestas as $obj) {
                        if($obj->isNew()) {
                            $collTPieceParamPrestas[] = $obj;
                        }
                    }
                }

                $this->collTPieceParamPrestas = $collTPieceParamPrestas;
                $this->collTPieceParamPrestasPartial = false;
            }
        }

        return $this->collTPieceParamPrestas;
    }

    /**
     * Sets a collection of TPieceParamPresta objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPieceParamPrestas A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setTPieceParamPrestas(PropelCollection $tPieceParamPrestas, PropelPDO $con = null)
    {
        $tPieceParamPrestasToDelete = $this->getTPieceParamPrestas(new Criteria(), $con)->diff($tPieceParamPrestas);

        $this->tPieceParamPrestasScheduledForDeletion = unserialize(serialize($tPieceParamPrestasToDelete));

        foreach ($tPieceParamPrestasToDelete as $tPieceParamPrestaRemoved) {
            $tPieceParamPrestaRemoved->setTParametragePrestation(null);
        }

        $this->collTPieceParamPrestas = null;
        foreach ($tPieceParamPrestas as $tPieceParamPresta) {
            $this->addTPieceParamPresta($tPieceParamPresta);
        }

        $this->collTPieceParamPrestas = $tPieceParamPrestas;
        $this->collTPieceParamPrestasPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPieceParamPresta objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPieceParamPresta objects.
     * @throws PropelException
     */
    public function countTPieceParamPrestas(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPieceParamPrestasPartial && !$this->isNew();
        if (null === $this->collTPieceParamPrestas || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPieceParamPrestas) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPieceParamPrestas());
            }
            $query = TPieceParamPrestaQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTParametragePrestation($this)
                ->count($con);
        }

        return count($this->collTPieceParamPrestas);
    }

    /**
     * Method called to associate a TPieceParamPresta object to this object
     * through the TPieceParamPresta foreign key attribute.
     *
     * @param    TPieceParamPresta $l TPieceParamPresta
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function addTPieceParamPresta(TPieceParamPresta $l)
    {
        if ($this->collTPieceParamPrestas === null) {
            $this->initTPieceParamPrestas();
            $this->collTPieceParamPrestasPartial = true;
        }
        if (!in_array($l, $this->collTPieceParamPrestas->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPieceParamPresta($l);
        }

        return $this;
    }

    /**
     * @param	TPieceParamPresta $tPieceParamPresta The tPieceParamPresta object to add.
     */
    protected function doAddTPieceParamPresta($tPieceParamPresta)
    {
        $this->collTPieceParamPrestas[]= $tPieceParamPresta;
        $tPieceParamPresta->setTParametragePrestation($this);
    }

    /**
     * @param	TPieceParamPresta $tPieceParamPresta The tPieceParamPresta object to remove.
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function removeTPieceParamPresta($tPieceParamPresta)
    {
        if ($this->getTPieceParamPrestas()->contains($tPieceParamPresta)) {
            $this->collTPieceParamPrestas->remove($this->collTPieceParamPrestas->search($tPieceParamPresta));
            if (null === $this->tPieceParamPrestasScheduledForDeletion) {
                $this->tPieceParamPrestasScheduledForDeletion = clone $this->collTPieceParamPrestas;
                $this->tPieceParamPrestasScheduledForDeletion->clear();
            }
            $this->tPieceParamPrestasScheduledForDeletion[]= clone $tPieceParamPresta;
            $tPieceParamPresta->setTParametragePrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPieceParamPrestas from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPieceParamPresta[] List of TPieceParamPresta objects
     */
    public function getTPieceParamPrestasJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPieceParamPrestaQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTPieceParamPrestas($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPieceParamPrestas from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPieceParamPresta[] List of TPieceParamPresta objects
     */
    public function getTPieceParamPrestasJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPieceParamPrestaQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTPieceParamPrestas($query, $con);
    }

    /**
     * Clears out the collTPrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TParametragePrestation The current object (for fluent API support)
     * @see        addTPrestations()
     */
    public function clearTPrestations()
    {
        $this->collTPrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTPrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTPrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPrestations($v = true)
    {
        $this->collTPrestationsPartial = $v;
    }

    /**
     * Initializes the collTPrestations collection.
     *
     * By default this just sets the collTPrestations collection to an empty array (like clearcollTPrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPrestations($overrideExisting = true)
    {
        if (null !== $this->collTPrestations && !$overrideExisting) {
            return;
        }
        $this->collTPrestations = new PropelObjectCollection();
        $this->collTPrestations->setModel('TPrestation');
    }

    /**
     * Gets an array of TPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TParametragePrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     * @throws PropelException
     */
    public function getTPrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsPartial && !$this->isNew();
        if (null === $this->collTPrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPrestations) {
                // return empty collection
                $this->initTPrestations();
            } else {
                $collTPrestations = TPrestationQuery::create(null, $criteria)
                    ->filterByTParametragePrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPrestationsPartial && count($collTPrestations)) {
                      $this->initTPrestations(false);

                      foreach($collTPrestations as $obj) {
                        if (false == $this->collTPrestations->contains($obj)) {
                          $this->collTPrestations->append($obj);
                        }
                      }

                      $this->collTPrestationsPartial = true;
                    }

                    $collTPrestations->getInternalIterator()->rewind();
                    return $collTPrestations;
                }

                if($partial && $this->collTPrestations) {
                    foreach($this->collTPrestations as $obj) {
                        if($obj->isNew()) {
                            $collTPrestations[] = $obj;
                        }
                    }
                }

                $this->collTPrestations = $collTPrestations;
                $this->collTPrestationsPartial = false;
            }
        }

        return $this->collTPrestations;
    }

    /**
     * Sets a collection of TPrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function setTPrestations(PropelCollection $tPrestations, PropelPDO $con = null)
    {
        $tPrestationsToDelete = $this->getTPrestations(new Criteria(), $con)->diff($tPrestations);

        $this->tPrestationsScheduledForDeletion = unserialize(serialize($tPrestationsToDelete));

        foreach ($tPrestationsToDelete as $tPrestationRemoved) {
            $tPrestationRemoved->setTParametragePrestation(null);
        }

        $this->collTPrestations = null;
        foreach ($tPrestations as $tPrestation) {
            $this->addTPrestation($tPrestation);
        }

        $this->collTPrestations = $tPrestations;
        $this->collTPrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPrestation objects.
     * @throws PropelException
     */
    public function countTPrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsPartial && !$this->isNew();
        if (null === $this->collTPrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPrestations());
            }
            $query = TPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTParametragePrestation($this)
                ->count($con);
        }

        return count($this->collTPrestations);
    }

    /**
     * Method called to associate a TPrestation object to this object
     * through the TPrestation foreign key attribute.
     *
     * @param    TPrestation $l TPrestation
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function addTPrestation(TPrestation $l)
    {
        if ($this->collTPrestations === null) {
            $this->initTPrestations();
            $this->collTPrestationsPartial = true;
        }
        if (!in_array($l, $this->collTPrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPrestation($l);
        }

        return $this;
    }

    /**
     * @param	TPrestation $tPrestation The tPrestation object to add.
     */
    protected function doAddTPrestation($tPrestation)
    {
        $this->collTPrestations[]= $tPrestation;
        $tPrestation->setTParametragePrestation($this);
    }

    /**
     * @param	TPrestation $tPrestation The tPrestation object to remove.
     * @return TParametragePrestation The current object (for fluent API support)
     */
    public function removeTPrestation($tPrestation)
    {
        if ($this->getTPrestations()->contains($tPrestation)) {
            $this->collTPrestations->remove($this->collTPrestations->search($tPrestation));
            if (null === $this->tPrestationsScheduledForDeletion) {
                $this->tPrestationsScheduledForDeletion = clone $this->collTPrestations;
                $this->tPrestationsScheduledForDeletion->clear();
            }
            $this->tPrestationsScheduledForDeletion[]= $tPrestation;
            $tPrestation->setTParametragePrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTTraductionRelatedByCodeLibellePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibellePrestation', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTypePrestation', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTChampsSuppRelatedByIdChampsSupp1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp1', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTChampsSuppRelatedByIdChampsSupp2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp2', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametragePrestation is new, it will return
     * an empty collection; or if this TParametragePrestation has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametragePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTChampsSuppRelatedByIdChampsSupp3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp3', $join_behavior);

        return $this->getTPrestations($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_parametrage_prestation = null;
        $this->id_organisation = null;
        $this->id_ref_type_prestation = null;
        $this->id_ref_prestation = null;
        $this->rdv_similaire = null;
        $this->nb_jour_rdv_similaire = null;
        $this->delai_min = null;
        $this->periodicite = null;
        $this->ressource_visible = null;
        $this->ressource_obligatoire = null;
        $this->id_parametre_form = null;
        $this->code_commentaire = null;
        $this->referent_visible = null;
        $this->code_aide = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTPieceParamPrestas) {
                foreach ($this->collTPieceParamPrestas as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPrestations) {
                foreach ($this->collTPrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraductionRelatedByCodeCommentaire instanceof Persistent) {
              $this->aTTraductionRelatedByCodeCommentaire->clearAllReferences($deep);
            }
            if ($this->aTOrganisation instanceof Persistent) {
              $this->aTOrganisation->clearAllReferences($deep);
            }
            if ($this->aTParametreForm instanceof Persistent) {
              $this->aTParametreForm->clearAllReferences($deep);
            }
            if ($this->aTRefPrestation instanceof Persistent) {
              $this->aTRefPrestation->clearAllReferences($deep);
            }
            if ($this->aTRefTypePrestation instanceof Persistent) {
              $this->aTRefTypePrestation->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeAide instanceof Persistent) {
              $this->aTTraductionRelatedByCodeAide->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTPieceParamPrestas instanceof PropelCollection) {
            $this->collTPieceParamPrestas->clearIterator();
        }
        $this->collTPieceParamPrestas = null;
        if ($this->collTPrestations instanceof PropelCollection) {
            $this->collTPrestations->clearIterator();
        }
        $this->collTPrestations = null;
        $this->aTTraductionRelatedByCodeCommentaire = null;
        $this->aTOrganisation = null;
        $this->aTParametreForm = null;
        $this->aTRefPrestation = null;
        $this->aTRefTypePrestation = null;
        $this->aTTraductionRelatedByCodeAide = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TParametragePrestationPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
