<?php


/**
 * Base static class for performing query and update operations on the 'T_ORGANISATION' table.
 *
 *
 *
 * @package propel.generator.RDV.om
 */
abstract class BaseTOrganisationPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'RDV';

    /** the table name for this class */
    const TABLE_NAME = 'T_ORGANISATION';

    /** the related Propel class for this table */
    const OM_CLASS = 'TOrganisation';

    /** the related TableMap class for this table */
    const TM_CLASS = 'TOrganisationTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 21;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 21;

    /** the column name for the ID_ORGANISATION field */
    const ID_ORGANISATION = 'T_ORGANISATION.ID_ORGANISATION';

    /** the column name for the CODE_DENOMINATION_ORGANISATION field */
    const CODE_DENOMINATION_ORGANISATION = 'T_ORGANISATION.CODE_DENOMINATION_ORGANISATION';

    /** the column name for the CODE_ADRESSE_ORGANISATION field */
    const CODE_ADRESSE_ORGANISATION = 'T_ORGANISATION.CODE_ADRESSE_ORGANISATION';

    /** the column name for the CODE_POSTAL field */
    const CODE_POSTAL = 'T_ORGANISATION.CODE_POSTAL';

    /** the column name for the TELEPHONE_ORGANISATION field */
    const TELEPHONE_ORGANISATION = 'T_ORGANISATION.TELEPHONE_ORGANISATION';

    /** the column name for the MAIL_ORGANISATION field */
    const MAIL_ORGANISATION = 'T_ORGANISATION.MAIL_ORGANISATION';

    /** the column name for the CODE_DESCRIPTION_ORGANISATION field */
    const CODE_DESCRIPTION_ORGANISATION = 'T_ORGANISATION.CODE_DESCRIPTION_ORGANISATION';

    /** the column name for the CODE_TITRE_BIENVENUE field */
    const CODE_TITRE_BIENVENUE = 'T_ORGANISATION.CODE_TITRE_BIENVENUE';

    /** the column name for the CODE_MESSAGE_BIENVENUE field */
    const CODE_MESSAGE_BIENVENUE = 'T_ORGANISATION.CODE_MESSAGE_BIENVENUE';

    /** the column name for the ID_ENTITE field */
    const ID_ENTITE = 'T_ORGANISATION.ID_ENTITE';

    /** the column name for the TYPE_PRESTATION field */
    const TYPE_PRESTATION = 'T_ORGANISATION.TYPE_PRESTATION';

    /** the column name for the CODE_LIBELLE_LIEN1 field */
    const CODE_LIBELLE_LIEN1 = 'T_ORGANISATION.CODE_LIBELLE_LIEN1';

    /** the column name for the URL_LIEN1 field */
    const URL_LIEN1 = 'T_ORGANISATION.URL_LIEN1';

    /** the column name for the CODE_LIBELLE_LIEN2 field */
    const CODE_LIBELLE_LIEN2 = 'T_ORGANISATION.CODE_LIBELLE_LIEN2';

    /** the column name for the URL_LIEN2 field */
    const URL_LIEN2 = 'T_ORGANISATION.URL_LIEN2';

    /** the column name for the CODE_LIBELLE_LIEN3 field */
    const CODE_LIBELLE_LIEN3 = 'T_ORGANISATION.CODE_LIBELLE_LIEN3';

    /** the column name for the URL_LIEN3 field */
    const URL_LIEN3 = 'T_ORGANISATION.URL_LIEN3';

    /** the column name for the ACRONYME field */
    const ACRONYME = 'T_ORGANISATION.ACRONYME';

    /** the column name for the NOM_DOMAINE field */
    const NOM_DOMAINE = 'T_ORGANISATION.NOM_DOMAINE';

    /** the column name for the ID_PARAMETRE_FORM field */
    const ID_PARAMETRE_FORM = 'T_ORGANISATION.ID_PARAMETRE_FORM';

    /** the column name for the RESSOURCE field */
    const RESSOURCE = 'T_ORGANISATION.RESSOURCE';

    /** The enumerated values for the TYPE_PRESTATION field */
    const TYPE_PRESTATION_0 = '0';
    const TYPE_PRESTATION_1 = '1';

    /** The enumerated values for the RESSOURCE field */
    const RESSOURCE_0 = '0';
    const RESSOURCE_1 = '1';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identiy map to hold any loaded instances of TOrganisation objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array TOrganisation[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. TOrganisationPeer::$fieldNames[TOrganisationPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('IdOrganisation', 'CodeDenominationOrganisation', 'CodeAdresseOrganisation', 'CodePostal', 'TelephoneOrganisation', 'MailOrganisation', 'CodeDescriptionOrganisation', 'CodeTitreBienvenue', 'CodeMessageBienvenue', 'IdEntite', 'TypePrestation', 'CodeLibelleLien1', 'UrlLien1', 'CodeLibelleLien2', 'UrlLien2', 'CodeLibelleLien3', 'UrlLien3', 'Acronyme', 'NomDomaine', 'IdParametreForm', 'Ressource', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idOrganisation', 'codeDenominationOrganisation', 'codeAdresseOrganisation', 'codePostal', 'telephoneOrganisation', 'mailOrganisation', 'codeDescriptionOrganisation', 'codeTitreBienvenue', 'codeMessageBienvenue', 'idEntite', 'typePrestation', 'codeLibelleLien1', 'urlLien1', 'codeLibelleLien2', 'urlLien2', 'codeLibelleLien3', 'urlLien3', 'acronyme', 'nomDomaine', 'idParametreForm', 'ressource', ),
        BasePeer::TYPE_COLNAME => array (TOrganisationPeer::ID_ORGANISATION, TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TOrganisationPeer::CODE_POSTAL, TOrganisationPeer::TELEPHONE_ORGANISATION, TOrganisationPeer::MAIL_ORGANISATION, TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TOrganisationPeer::CODE_TITRE_BIENVENUE, TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TOrganisationPeer::ID_ENTITE, TOrganisationPeer::TYPE_PRESTATION, TOrganisationPeer::CODE_LIBELLE_LIEN1, TOrganisationPeer::URL_LIEN1, TOrganisationPeer::CODE_LIBELLE_LIEN2, TOrganisationPeer::URL_LIEN2, TOrganisationPeer::CODE_LIBELLE_LIEN3, TOrganisationPeer::URL_LIEN3, TOrganisationPeer::ACRONYME, TOrganisationPeer::NOM_DOMAINE, TOrganisationPeer::ID_PARAMETRE_FORM, TOrganisationPeer::RESSOURCE, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_ORGANISATION', 'CODE_DENOMINATION_ORGANISATION', 'CODE_ADRESSE_ORGANISATION', 'CODE_POSTAL', 'TELEPHONE_ORGANISATION', 'MAIL_ORGANISATION', 'CODE_DESCRIPTION_ORGANISATION', 'CODE_TITRE_BIENVENUE', 'CODE_MESSAGE_BIENVENUE', 'ID_ENTITE', 'TYPE_PRESTATION', 'CODE_LIBELLE_LIEN1', 'URL_LIEN1', 'CODE_LIBELLE_LIEN2', 'URL_LIEN2', 'CODE_LIBELLE_LIEN3', 'URL_LIEN3', 'ACRONYME', 'NOM_DOMAINE', 'ID_PARAMETRE_FORM', 'RESSOURCE', ),
        BasePeer::TYPE_FIELDNAME => array ('ID_ORGANISATION', 'CODE_DENOMINATION_ORGANISATION', 'CODE_ADRESSE_ORGANISATION', 'CODE_POSTAL', 'TELEPHONE_ORGANISATION', 'MAIL_ORGANISATION', 'CODE_DESCRIPTION_ORGANISATION', 'CODE_TITRE_BIENVENUE', 'CODE_MESSAGE_BIENVENUE', 'ID_ENTITE', 'TYPE_PRESTATION', 'CODE_LIBELLE_LIEN1', 'URL_LIEN1', 'CODE_LIBELLE_LIEN2', 'URL_LIEN2', 'CODE_LIBELLE_LIEN3', 'URL_LIEN3', 'ACRONYME', 'NOM_DOMAINE', 'ID_PARAMETRE_FORM', 'RESSOURCE', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. TOrganisationPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('IdOrganisation' => 0, 'CodeDenominationOrganisation' => 1, 'CodeAdresseOrganisation' => 2, 'CodePostal' => 3, 'TelephoneOrganisation' => 4, 'MailOrganisation' => 5, 'CodeDescriptionOrganisation' => 6, 'CodeTitreBienvenue' => 7, 'CodeMessageBienvenue' => 8, 'IdEntite' => 9, 'TypePrestation' => 10, 'CodeLibelleLien1' => 11, 'UrlLien1' => 12, 'CodeLibelleLien2' => 13, 'UrlLien2' => 14, 'CodeLibelleLien3' => 15, 'UrlLien3' => 16, 'Acronyme' => 17, 'NomDomaine' => 18, 'IdParametreForm' => 19, 'Ressource' => 20, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idOrganisation' => 0, 'codeDenominationOrganisation' => 1, 'codeAdresseOrganisation' => 2, 'codePostal' => 3, 'telephoneOrganisation' => 4, 'mailOrganisation' => 5, 'codeDescriptionOrganisation' => 6, 'codeTitreBienvenue' => 7, 'codeMessageBienvenue' => 8, 'idEntite' => 9, 'typePrestation' => 10, 'codeLibelleLien1' => 11, 'urlLien1' => 12, 'codeLibelleLien2' => 13, 'urlLien2' => 14, 'codeLibelleLien3' => 15, 'urlLien3' => 16, 'acronyme' => 17, 'nomDomaine' => 18, 'idParametreForm' => 19, 'ressource' => 20, ),
        BasePeer::TYPE_COLNAME => array (TOrganisationPeer::ID_ORGANISATION => 0, TOrganisationPeer::CODE_DENOMINATION_ORGANISATION => 1, TOrganisationPeer::CODE_ADRESSE_ORGANISATION => 2, TOrganisationPeer::CODE_POSTAL => 3, TOrganisationPeer::TELEPHONE_ORGANISATION => 4, TOrganisationPeer::MAIL_ORGANISATION => 5, TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION => 6, TOrganisationPeer::CODE_TITRE_BIENVENUE => 7, TOrganisationPeer::CODE_MESSAGE_BIENVENUE => 8, TOrganisationPeer::ID_ENTITE => 9, TOrganisationPeer::TYPE_PRESTATION => 10, TOrganisationPeer::CODE_LIBELLE_LIEN1 => 11, TOrganisationPeer::URL_LIEN1 => 12, TOrganisationPeer::CODE_LIBELLE_LIEN2 => 13, TOrganisationPeer::URL_LIEN2 => 14, TOrganisationPeer::CODE_LIBELLE_LIEN3 => 15, TOrganisationPeer::URL_LIEN3 => 16, TOrganisationPeer::ACRONYME => 17, TOrganisationPeer::NOM_DOMAINE => 18, TOrganisationPeer::ID_PARAMETRE_FORM => 19, TOrganisationPeer::RESSOURCE => 20, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_ORGANISATION' => 0, 'CODE_DENOMINATION_ORGANISATION' => 1, 'CODE_ADRESSE_ORGANISATION' => 2, 'CODE_POSTAL' => 3, 'TELEPHONE_ORGANISATION' => 4, 'MAIL_ORGANISATION' => 5, 'CODE_DESCRIPTION_ORGANISATION' => 6, 'CODE_TITRE_BIENVENUE' => 7, 'CODE_MESSAGE_BIENVENUE' => 8, 'ID_ENTITE' => 9, 'TYPE_PRESTATION' => 10, 'CODE_LIBELLE_LIEN1' => 11, 'URL_LIEN1' => 12, 'CODE_LIBELLE_LIEN2' => 13, 'URL_LIEN2' => 14, 'CODE_LIBELLE_LIEN3' => 15, 'URL_LIEN3' => 16, 'ACRONYME' => 17, 'NOM_DOMAINE' => 18, 'ID_PARAMETRE_FORM' => 19, 'RESSOURCE' => 20, ),
        BasePeer::TYPE_FIELDNAME => array ('ID_ORGANISATION' => 0, 'CODE_DENOMINATION_ORGANISATION' => 1, 'CODE_ADRESSE_ORGANISATION' => 2, 'CODE_POSTAL' => 3, 'TELEPHONE_ORGANISATION' => 4, 'MAIL_ORGANISATION' => 5, 'CODE_DESCRIPTION_ORGANISATION' => 6, 'CODE_TITRE_BIENVENUE' => 7, 'CODE_MESSAGE_BIENVENUE' => 8, 'ID_ENTITE' => 9, 'TYPE_PRESTATION' => 10, 'CODE_LIBELLE_LIEN1' => 11, 'URL_LIEN1' => 12, 'CODE_LIBELLE_LIEN2' => 13, 'URL_LIEN2' => 14, 'CODE_LIBELLE_LIEN3' => 15, 'URL_LIEN3' => 16, 'ACRONYME' => 17, 'NOM_DOMAINE' => 18, 'ID_PARAMETRE_FORM' => 19, 'RESSOURCE' => 20, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, )
    );

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
        TOrganisationPeer::TYPE_PRESTATION => array(
            TOrganisationPeer::TYPE_PRESTATION_0,
            TOrganisationPeer::TYPE_PRESTATION_1,
        ),
        TOrganisationPeer::RESSOURCE => array(
            TOrganisationPeer::RESSOURCE_0,
            TOrganisationPeer::RESSOURCE_1,
        ),
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = TOrganisationPeer::getFieldNames($toType);
        $key = isset(TOrganisationPeer::$fieldKeys[$fromType][$name]) ? TOrganisationPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(TOrganisationPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, TOrganisationPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return TOrganisationPeer::$fieldNames[$type];
    }

    /**
     * Gets the list of values for all ENUM columns
     * @return array
     */
    public static function getValueSets()
    {
      return TOrganisationPeer::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM column
     *
     * @param string $colname The ENUM column name.
     *
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = TOrganisationPeer::getValueSets();

        if (!isset($valueSets[$colname])) {
            throw new PropelException(sprintf('Column "%s" has no ValueSet.', $colname));
        }

        return $valueSets[$colname];
    }

    /**
     * Gets the SQL value for the ENUM column value
     *
     * @param string $colname ENUM column name.
     * @param string $enumVal ENUM value.
     *
     * @return int            SQL value
     */
    public static function getSqlValueForEnum($colname, $enumVal)
    {
        $values = TOrganisationPeer::getValueSet($colname);
        if (!in_array($enumVal, $values)) {
            throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $colname));
        }
        return array_search($enumVal, $values);
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. TOrganisationPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(TOrganisationPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(TOrganisationPeer::ID_ORGANISATION);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_ADRESSE_ORGANISATION);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_POSTAL);
            $criteria->addSelectColumn(TOrganisationPeer::TELEPHONE_ORGANISATION);
            $criteria->addSelectColumn(TOrganisationPeer::MAIL_ORGANISATION);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_TITRE_BIENVENUE);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_MESSAGE_BIENVENUE);
            $criteria->addSelectColumn(TOrganisationPeer::ID_ENTITE);
            $criteria->addSelectColumn(TOrganisationPeer::TYPE_PRESTATION);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_LIBELLE_LIEN1);
            $criteria->addSelectColumn(TOrganisationPeer::URL_LIEN1);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_LIBELLE_LIEN2);
            $criteria->addSelectColumn(TOrganisationPeer::URL_LIEN2);
            $criteria->addSelectColumn(TOrganisationPeer::CODE_LIBELLE_LIEN3);
            $criteria->addSelectColumn(TOrganisationPeer::URL_LIEN3);
            $criteria->addSelectColumn(TOrganisationPeer::ACRONYME);
            $criteria->addSelectColumn(TOrganisationPeer::NOM_DOMAINE);
            $criteria->addSelectColumn(TOrganisationPeer::ID_PARAMETRE_FORM);
            $criteria->addSelectColumn(TOrganisationPeer::RESSOURCE);
        } else {
            $criteria->addSelectColumn($alias . '.ID_ORGANISATION');
            $criteria->addSelectColumn($alias . '.CODE_DENOMINATION_ORGANISATION');
            $criteria->addSelectColumn($alias . '.CODE_ADRESSE_ORGANISATION');
            $criteria->addSelectColumn($alias . '.CODE_POSTAL');
            $criteria->addSelectColumn($alias . '.TELEPHONE_ORGANISATION');
            $criteria->addSelectColumn($alias . '.MAIL_ORGANISATION');
            $criteria->addSelectColumn($alias . '.CODE_DESCRIPTION_ORGANISATION');
            $criteria->addSelectColumn($alias . '.CODE_TITRE_BIENVENUE');
            $criteria->addSelectColumn($alias . '.CODE_MESSAGE_BIENVENUE');
            $criteria->addSelectColumn($alias . '.ID_ENTITE');
            $criteria->addSelectColumn($alias . '.TYPE_PRESTATION');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_LIEN1');
            $criteria->addSelectColumn($alias . '.URL_LIEN1');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_LIEN2');
            $criteria->addSelectColumn($alias . '.URL_LIEN2');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_LIEN3');
            $criteria->addSelectColumn($alias . '.URL_LIEN3');
            $criteria->addSelectColumn($alias . '.ACRONYME');
            $criteria->addSelectColumn($alias . '.NOM_DOMAINE');
            $criteria->addSelectColumn($alias . '.ID_PARAMETRE_FORM');
            $criteria->addSelectColumn($alias . '.RESSOURCE');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return                 TOrganisation
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = TOrganisationPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return TOrganisationPeer::populateObjects(TOrganisationPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            TOrganisationPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param      TOrganisation $obj A TOrganisation object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getIdOrganisation();
            } // if key === null
            TOrganisationPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A TOrganisation object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof TOrganisation) {
                $key = (string) $value->getIdOrganisation();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or TOrganisation object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(TOrganisationPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return   TOrganisation Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(TOrganisationPeer::$instances[$key])) {
                return TOrganisationPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references)
      {
        foreach (TOrganisationPeer::$instances as $instance)
        {
          $instance->clearAllReferences(true);
        }
      }
        TOrganisationPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to T_ORGANISATION
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = TOrganisationPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = TOrganisationPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                TOrganisationPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (TOrganisation object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = TOrganisationPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = TOrganisationPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = TOrganisationPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            TOrganisationPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeAdresseOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeAdresseOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeDenominationOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeDenominationOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeDescriptionOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeDescriptionOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleLien1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleLien1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleLien2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleLien2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleLien3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleLien3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeMessageBienvenue table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeMessageBienvenue(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeTitreBienvenue table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeTitreBienvenue(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TEntite table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTEntite(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TParametreForm table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTParametreForm(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeAdresseOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeAdresseOrganisation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeDenominationOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeDenominationOrganisation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeDescriptionOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeDescriptionOrganisation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleLien1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeLibelleLien1($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleLien2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeLibelleLien2($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleLien3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeLibelleLien3($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeMessageBienvenue(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeMessageBienvenue($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeTitreBienvenue(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeTitreBienvenue($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TEntite objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTEntite(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TEntitePeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TEntitePeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with their TParametreForm objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTParametreForm(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol = TOrganisationPeer::NUM_HYDRATE_COLUMNS;
        TParametreFormPeer::addSelectColumns($criteria);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TParametreFormPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TParametreFormPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TParametreFormPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TOrganisation) to $obj2 (TParametreForm)
                $obj2->addTOrganisation($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined TTraduction rows

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeAdresseOrganisation($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TTraduction)
                $obj3->addTOrganisationRelatedByCodeDenominationOrganisation($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key4 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = TTraductionPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTraductionPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj4 (TTraduction)
                $obj4->addTOrganisationRelatedByCodeDescriptionOrganisation($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key5 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol5);
            if ($key5 !== null) {
                $obj5 = TTraductionPeer::getInstanceFromPool($key5);
                if (!$obj5) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTraductionPeer::addInstanceToPool($obj5, $key5);
                } // if obj5 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj5 (TTraduction)
                $obj5->addTOrganisationRelatedByCodeLibelleLien1($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key6 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol6);
            if ($key6 !== null) {
                $obj6 = TTraductionPeer::getInstanceFromPool($key6);
                if (!$obj6) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTraductionPeer::addInstanceToPool($obj6, $key6);
                } // if obj6 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj6 (TTraduction)
                $obj6->addTOrganisationRelatedByCodeLibelleLien2($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key7 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol7);
            if ($key7 !== null) {
                $obj7 = TTraductionPeer::getInstanceFromPool($key7);
                if (!$obj7) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTraductionPeer::addInstanceToPool($obj7, $key7);
                } // if obj7 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj7 (TTraduction)
                $obj7->addTOrganisationRelatedByCodeLibelleLien3($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key8 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol8);
            if ($key8 !== null) {
                $obj8 = TTraductionPeer::getInstanceFromPool($key8);
                if (!$obj8) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TTraductionPeer::addInstanceToPool($obj8, $key8);
                } // if obj8 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj8 (TTraduction)
                $obj8->addTOrganisationRelatedByCodeMessageBienvenue($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key9 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol9);
            if ($key9 !== null) {
                $obj9 = TTraductionPeer::getInstanceFromPool($key9);
                if (!$obj9) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TTraductionPeer::addInstanceToPool($obj9, $key9);
                } // if obj9 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj9 (TTraduction)
                $obj9->addTOrganisationRelatedByCodeTitreBienvenue($obj1);
            } // if joined row not null

            // Add objects for joined TEntite rows

            $key10 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol10);
            if ($key10 !== null) {
                $obj10 = TEntitePeer::getInstanceFromPool($key10);
                if (!$obj10) {

                    $cls = TEntitePeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TEntitePeer::addInstanceToPool($obj10, $key10);
                } // if obj10 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj10 (TEntite)
                $obj10->addTOrganisation($obj1);
            } // if joined row not null

            // Add objects for joined TParametreForm rows

            $key11 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol11);
            if ($key11 !== null) {
                $obj11 = TParametreFormPeer::getInstanceFromPool($key11);
                if (!$obj11) {

                    $cls = TParametreFormPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    TParametreFormPeer::addInstanceToPool($obj11, $key11);
                } // if obj11 loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj11 (TParametreForm)
                $obj11->addTOrganisation($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeAdresseOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeAdresseOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeDenominationOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeDenominationOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeDescriptionOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeDescriptionOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleLien1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleLien1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleLien2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleLien2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleLien3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleLien3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeMessageBienvenue table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeMessageBienvenue(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeTitreBienvenue table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeTitreBienvenue(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TEntite table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTEntite(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TParametreForm table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTParametreForm(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TOrganisationPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeAdresseOrganisation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeAdresseOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeDenominationOrganisation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeDenominationOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeDescriptionOrganisation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeDescriptionOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleLien1.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleLien1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleLien2.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleLien2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleLien3.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleLien3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeMessageBienvenue.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeMessageBienvenue(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TTraductionRelatedByCodeTitreBienvenue.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeTitreBienvenue(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TEntite rows

                $key2 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TEntitePeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TEntitePeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TEntitePeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TEntite)
                $obj2->addTOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key3 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TParametreFormPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TParametreFormPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TParametreForm)
                $obj3->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TEntite.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTEntite(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_PARAMETRE_FORM, TParametreFormPeer::ID_PARAMETRE_FORM, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeAdresseOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TTraduction)
                $obj3->addTOrganisationRelatedByCodeDenominationOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key4 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TTraductionPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTraductionPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj4 (TTraduction)
                $obj4->addTOrganisationRelatedByCodeDescriptionOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key5 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TTraductionPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTraductionPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj5 (TTraduction)
                $obj5->addTOrganisationRelatedByCodeLibelleLien1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key6 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTraductionPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTraductionPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj6 (TTraduction)
                $obj6->addTOrganisationRelatedByCodeLibelleLien2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key7 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTraductionPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTraductionPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj7 (TTraduction)
                $obj7->addTOrganisationRelatedByCodeLibelleLien3($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key8 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TTraductionPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TTraductionPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj8 (TTraduction)
                $obj8->addTOrganisationRelatedByCodeMessageBienvenue($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key9 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TTraductionPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TTraductionPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj9 (TTraduction)
                $obj9->addTOrganisationRelatedByCodeTitreBienvenue($obj1);

            } // if joined row is not null

                // Add objects for joined TParametreForm rows

                $key10 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = TParametreFormPeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = TParametreFormPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TParametreFormPeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj10 (TParametreForm)
                $obj10->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TOrganisation objects pre-filled with all related objects except TParametreForm.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TOrganisation objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTParametreForm(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);
        }

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol2 = TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TEntitePeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TEntitePeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TOrganisationPeer::CODE_ADRESSE_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DENOMINATION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_DESCRIPTION_ORGANISATION, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_LIBELLE_LIEN3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_MESSAGE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::CODE_TITRE_BIENVENUE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TOrganisationPeer::ID_ENTITE, TEntitePeer::ID_ENTITE, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TOrganisationPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TOrganisationPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TOrganisationPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj2 (TTraduction)
                $obj2->addTOrganisationRelatedByCodeAdresseOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj3 (TTraduction)
                $obj3->addTOrganisationRelatedByCodeDenominationOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key4 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TTraductionPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTraductionPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj4 (TTraduction)
                $obj4->addTOrganisationRelatedByCodeDescriptionOrganisation($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key5 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TTraductionPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTraductionPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj5 (TTraduction)
                $obj5->addTOrganisationRelatedByCodeLibelleLien1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key6 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTraductionPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTraductionPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj6 (TTraduction)
                $obj6->addTOrganisationRelatedByCodeLibelleLien2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key7 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTraductionPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTraductionPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj7 (TTraduction)
                $obj7->addTOrganisationRelatedByCodeLibelleLien3($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key8 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TTraductionPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TTraductionPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj8 (TTraduction)
                $obj8->addTOrganisationRelatedByCodeMessageBienvenue($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key9 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol9);
                if ($key9 !== null) {
                    $obj9 = TTraductionPeer::getInstanceFromPool($key9);
                    if (!$obj9) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TTraductionPeer::addInstanceToPool($obj9, $key9);
                } // if $obj9 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj9 (TTraduction)
                $obj9->addTOrganisationRelatedByCodeTitreBienvenue($obj1);

            } // if joined row is not null

                // Add objects for joined TEntite rows

                $key10 = TEntitePeer::getPrimaryKeyHashFromRow($row, $startcol10);
                if ($key10 !== null) {
                    $obj10 = TEntitePeer::getInstanceFromPool($key10);
                    if (!$obj10) {

                        $cls = TEntitePeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TEntitePeer::addInstanceToPool($obj10, $key10);
                } // if $obj10 already loaded

                // Add the $obj1 (TOrganisation) to the collection in $obj10 (TEntite)
                $obj10->addTOrganisation($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(TOrganisationPeer::DATABASE_NAME)->getTable(TOrganisationPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseTOrganisationPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseTOrganisationPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new TOrganisationTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return TOrganisationPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a TOrganisation or Criteria object.
     *
     * @param      mixed $values Criteria or TOrganisation object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from TOrganisation object
        }

        if ($criteria->containsKey(TOrganisationPeer::ID_ORGANISATION) && $criteria->keyContainsValue(TOrganisationPeer::ID_ORGANISATION) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.TOrganisationPeer::ID_ORGANISATION.')');
        }


        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a TOrganisation or Criteria object.
     *
     * @param      mixed $values Criteria or TOrganisation object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(TOrganisationPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(TOrganisationPeer::ID_ORGANISATION);
            $value = $criteria->remove(TOrganisationPeer::ID_ORGANISATION);
            if ($value) {
                $selectCriteria->add(TOrganisationPeer::ID_ORGANISATION, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(TOrganisationPeer::TABLE_NAME);
            }

        } else { // $values is TOrganisation object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the T_ORGANISATION table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(TOrganisationPeer::TABLE_NAME, $con, TOrganisationPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            TOrganisationPeer::clearInstancePool();
            TOrganisationPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a TOrganisation or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or TOrganisation object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            TOrganisationPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof TOrganisation) { // it's a model object
            // invalidate the cache for this single object
            TOrganisationPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(TOrganisationPeer::DATABASE_NAME);
            $criteria->add(TOrganisationPeer::ID_ORGANISATION, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                TOrganisationPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(TOrganisationPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            TOrganisationPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given TOrganisation object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param      TOrganisation $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(TOrganisationPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(TOrganisationPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(TOrganisationPeer::DATABASE_NAME, TOrganisationPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param      int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return TOrganisation
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = TOrganisationPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(TOrganisationPeer::DATABASE_NAME);
        $criteria->add(TOrganisationPeer::ID_ORGANISATION, $pk);

        $v = TOrganisationPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return TOrganisation[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TOrganisationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(TOrganisationPeer::DATABASE_NAME);
            $criteria->add(TOrganisationPeer::ID_ORGANISATION, $pks, Criteria::IN);
            $objs = TOrganisationPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseTOrganisationPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseTOrganisationPeer::buildTableMap();

