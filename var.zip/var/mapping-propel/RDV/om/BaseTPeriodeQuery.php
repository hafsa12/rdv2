<?php


/**
 * Base class that represents a query for the 'T_PERIODE' table.
 *
 *
 *
 * @method TPeriodeQuery orderByIdPeriode($order = Criteria::ASC) Order by the ID_PERIODE column
 * @method TPeriodeQuery orderByDebutPeriode($order = Criteria::ASC) Order by the DEBUT_PERIODE column
 * @method TPeriodeQuery orderByFinPeriode($order = Criteria::ASC) Order by the FIN_PERIODE column
 * @method TPeriodeQuery orderByLundiHeureDebut1($order = Criteria::ASC) Order by the LUNDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery orderByLundiHeureFin1($order = Criteria::ASC) Order by the LUNDI_HEURE_FIN_1 column
 * @method TPeriodeQuery orderByLundiCapacite1($order = Criteria::ASC) Order by the LUNDI_CAPACITE_1 column
 * @method TPeriodeQuery orderByLundiNbRdvSite1($order = Criteria::ASC) Order by the LUNDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery orderByLundiHeureDebut2($order = Criteria::ASC) Order by the LUNDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery orderByLundiHeureFin2($order = Criteria::ASC) Order by the LUNDI_HEURE_FIN_2 column
 * @method TPeriodeQuery orderByLundiCapacite2($order = Criteria::ASC) Order by the LUNDI_CAPACITE_2 column
 * @method TPeriodeQuery orderByLundiNbRdvSite2($order = Criteria::ASC) Order by the LUNDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery orderByMardiHeureDebut1($order = Criteria::ASC) Order by the MARDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery orderByMardiHeureFin1($order = Criteria::ASC) Order by the MARDI_HEURE_FIN_1 column
 * @method TPeriodeQuery orderByMardiCapacite1($order = Criteria::ASC) Order by the MARDI_CAPACITE_1 column
 * @method TPeriodeQuery orderByMardiNbRdvSite1($order = Criteria::ASC) Order by the MARDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery orderByMardiHeureDebut2($order = Criteria::ASC) Order by the MARDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery orderByMardiHeureFin2($order = Criteria::ASC) Order by the MARDI_HEURE_FIN_2 column
 * @method TPeriodeQuery orderByMardiCapacite2($order = Criteria::ASC) Order by the MARDI_CAPACITE_2 column
 * @method TPeriodeQuery orderByMardiNbRdvSite2($order = Criteria::ASC) Order by the MARDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery orderByMercrediHeureDebut1($order = Criteria::ASC) Order by the MERCREDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery orderByMercrediHeureFin1($order = Criteria::ASC) Order by the MERCREDI_HEURE_FIN_1 column
 * @method TPeriodeQuery orderByMercrediCapacite1($order = Criteria::ASC) Order by the MERCREDI_CAPACITE_1 column
 * @method TPeriodeQuery orderByMercrediNbRdvSite1($order = Criteria::ASC) Order by the MERCREDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery orderByMercrediHeureDebut2($order = Criteria::ASC) Order by the MERCREDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery orderByMercrediHeureFin2($order = Criteria::ASC) Order by the MERCREDI_HEURE_FIN_2 column
 * @method TPeriodeQuery orderByMercrediCapacite2($order = Criteria::ASC) Order by the MERCREDI_CAPACITE_2 column
 * @method TPeriodeQuery orderByMercrediNbRdvSite2($order = Criteria::ASC) Order by the MERCREDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery orderByJeudiHeureDebut1($order = Criteria::ASC) Order by the JEUDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery orderByJeudiHeureFin1($order = Criteria::ASC) Order by the JEUDI_HEURE_FIN_1 column
 * @method TPeriodeQuery orderByJeudiCapacite1($order = Criteria::ASC) Order by the JEUDI_CAPACITE_1 column
 * @method TPeriodeQuery orderByJeudiNbRdvSite1($order = Criteria::ASC) Order by the JEUDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery orderByJeudiHeureDebut2($order = Criteria::ASC) Order by the JEUDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery orderByJeudiHeureFin2($order = Criteria::ASC) Order by the JEUDI_HEURE_FIN_2 column
 * @method TPeriodeQuery orderByJeudiCapacite2($order = Criteria::ASC) Order by the JEUDI_CAPACITE_2 column
 * @method TPeriodeQuery orderByJeudiNbRdvSite2($order = Criteria::ASC) Order by the JEUDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery orderByVendrediHeureDebut1($order = Criteria::ASC) Order by the VENDREDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery orderByVendrediHeureFin1($order = Criteria::ASC) Order by the VENDREDI_HEURE_FIN_1 column
 * @method TPeriodeQuery orderByVendrediCapacite1($order = Criteria::ASC) Order by the VENDREDI_CAPACITE_1 column
 * @method TPeriodeQuery orderByVendrediNbRdvSite1($order = Criteria::ASC) Order by the VENDREDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery orderByVendrediHeureDebut2($order = Criteria::ASC) Order by the VENDREDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery orderByVendrediHeureFin2($order = Criteria::ASC) Order by the VENDREDI_HEURE_FIN_2 column
 * @method TPeriodeQuery orderByVendrediCapacite2($order = Criteria::ASC) Order by the VENDREDI_CAPACITE_2 column
 * @method TPeriodeQuery orderByVendrediNbRdvSite2($order = Criteria::ASC) Order by the VENDREDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery orderBySamediHeureDebut1($order = Criteria::ASC) Order by the SAMEDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery orderBySamediHeureFin1($order = Criteria::ASC) Order by the SAMEDI_HEURE_FIN_1 column
 * @method TPeriodeQuery orderBySamediCapacite1($order = Criteria::ASC) Order by the SAMEDI_CAPACITE_1 column
 * @method TPeriodeQuery orderBySamediNbRdvSite1($order = Criteria::ASC) Order by the SAMEDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery orderBySamediHeureDebut2($order = Criteria::ASC) Order by the SAMEDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery orderBySamediHeureFin2($order = Criteria::ASC) Order by the SAMEDI_HEURE_FIN_2 column
 * @method TPeriodeQuery orderBySamediCapacite2($order = Criteria::ASC) Order by the SAMEDI_CAPACITE_2 column
 * @method TPeriodeQuery orderBySamediNbRdvSite2($order = Criteria::ASC) Order by the SAMEDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery orderByDimancheHeureDebut1($order = Criteria::ASC) Order by the DIMANCHE_HEURE_DEBUT_1 column
 * @method TPeriodeQuery orderByDimancheHeureFin1($order = Criteria::ASC) Order by the DIMANCHE_HEURE_FIN_1 column
 * @method TPeriodeQuery orderByDimancheCapacite1($order = Criteria::ASC) Order by the DIMANCHE_CAPACITE_1 column
 * @method TPeriodeQuery orderByDimancheNbRdvSite1($order = Criteria::ASC) Order by the DIMANCHE_NB_RDV_SITE_1 column
 * @method TPeriodeQuery orderByDimancheHeureDebut2($order = Criteria::ASC) Order by the DIMANCHE_HEURE_DEBUT_2 column
 * @method TPeriodeQuery orderByDimancheHeureFin2($order = Criteria::ASC) Order by the DIMANCHE_HEURE_FIN_2 column
 * @method TPeriodeQuery orderByDimancheCapacite2($order = Criteria::ASC) Order by the DIMANCHE_CAPACITE_2 column
 * @method TPeriodeQuery orderByDimancheNbRdvSite2($order = Criteria::ASC) Order by the DIMANCHE_NB_RDV_SITE_2 column
 * @method TPeriodeQuery orderByIdAgenda($order = Criteria::ASC) Order by the ID_AGENDA column
 * @method TPeriodeQuery orderByPeriodicite($order = Criteria::ASC) Order by the PERIODICITE column
 *
 * @method TPeriodeQuery groupByIdPeriode() Group by the ID_PERIODE column
 * @method TPeriodeQuery groupByDebutPeriode() Group by the DEBUT_PERIODE column
 * @method TPeriodeQuery groupByFinPeriode() Group by the FIN_PERIODE column
 * @method TPeriodeQuery groupByLundiHeureDebut1() Group by the LUNDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery groupByLundiHeureFin1() Group by the LUNDI_HEURE_FIN_1 column
 * @method TPeriodeQuery groupByLundiCapacite1() Group by the LUNDI_CAPACITE_1 column
 * @method TPeriodeQuery groupByLundiNbRdvSite1() Group by the LUNDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery groupByLundiHeureDebut2() Group by the LUNDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery groupByLundiHeureFin2() Group by the LUNDI_HEURE_FIN_2 column
 * @method TPeriodeQuery groupByLundiCapacite2() Group by the LUNDI_CAPACITE_2 column
 * @method TPeriodeQuery groupByLundiNbRdvSite2() Group by the LUNDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery groupByMardiHeureDebut1() Group by the MARDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery groupByMardiHeureFin1() Group by the MARDI_HEURE_FIN_1 column
 * @method TPeriodeQuery groupByMardiCapacite1() Group by the MARDI_CAPACITE_1 column
 * @method TPeriodeQuery groupByMardiNbRdvSite1() Group by the MARDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery groupByMardiHeureDebut2() Group by the MARDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery groupByMardiHeureFin2() Group by the MARDI_HEURE_FIN_2 column
 * @method TPeriodeQuery groupByMardiCapacite2() Group by the MARDI_CAPACITE_2 column
 * @method TPeriodeQuery groupByMardiNbRdvSite2() Group by the MARDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery groupByMercrediHeureDebut1() Group by the MERCREDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery groupByMercrediHeureFin1() Group by the MERCREDI_HEURE_FIN_1 column
 * @method TPeriodeQuery groupByMercrediCapacite1() Group by the MERCREDI_CAPACITE_1 column
 * @method TPeriodeQuery groupByMercrediNbRdvSite1() Group by the MERCREDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery groupByMercrediHeureDebut2() Group by the MERCREDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery groupByMercrediHeureFin2() Group by the MERCREDI_HEURE_FIN_2 column
 * @method TPeriodeQuery groupByMercrediCapacite2() Group by the MERCREDI_CAPACITE_2 column
 * @method TPeriodeQuery groupByMercrediNbRdvSite2() Group by the MERCREDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery groupByJeudiHeureDebut1() Group by the JEUDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery groupByJeudiHeureFin1() Group by the JEUDI_HEURE_FIN_1 column
 * @method TPeriodeQuery groupByJeudiCapacite1() Group by the JEUDI_CAPACITE_1 column
 * @method TPeriodeQuery groupByJeudiNbRdvSite1() Group by the JEUDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery groupByJeudiHeureDebut2() Group by the JEUDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery groupByJeudiHeureFin2() Group by the JEUDI_HEURE_FIN_2 column
 * @method TPeriodeQuery groupByJeudiCapacite2() Group by the JEUDI_CAPACITE_2 column
 * @method TPeriodeQuery groupByJeudiNbRdvSite2() Group by the JEUDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery groupByVendrediHeureDebut1() Group by the VENDREDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery groupByVendrediHeureFin1() Group by the VENDREDI_HEURE_FIN_1 column
 * @method TPeriodeQuery groupByVendrediCapacite1() Group by the VENDREDI_CAPACITE_1 column
 * @method TPeriodeQuery groupByVendrediNbRdvSite1() Group by the VENDREDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery groupByVendrediHeureDebut2() Group by the VENDREDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery groupByVendrediHeureFin2() Group by the VENDREDI_HEURE_FIN_2 column
 * @method TPeriodeQuery groupByVendrediCapacite2() Group by the VENDREDI_CAPACITE_2 column
 * @method TPeriodeQuery groupByVendrediNbRdvSite2() Group by the VENDREDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery groupBySamediHeureDebut1() Group by the SAMEDI_HEURE_DEBUT_1 column
 * @method TPeriodeQuery groupBySamediHeureFin1() Group by the SAMEDI_HEURE_FIN_1 column
 * @method TPeriodeQuery groupBySamediCapacite1() Group by the SAMEDI_CAPACITE_1 column
 * @method TPeriodeQuery groupBySamediNbRdvSite1() Group by the SAMEDI_NB_RDV_SITE_1 column
 * @method TPeriodeQuery groupBySamediHeureDebut2() Group by the SAMEDI_HEURE_DEBUT_2 column
 * @method TPeriodeQuery groupBySamediHeureFin2() Group by the SAMEDI_HEURE_FIN_2 column
 * @method TPeriodeQuery groupBySamediCapacite2() Group by the SAMEDI_CAPACITE_2 column
 * @method TPeriodeQuery groupBySamediNbRdvSite2() Group by the SAMEDI_NB_RDV_SITE_2 column
 * @method TPeriodeQuery groupByDimancheHeureDebut1() Group by the DIMANCHE_HEURE_DEBUT_1 column
 * @method TPeriodeQuery groupByDimancheHeureFin1() Group by the DIMANCHE_HEURE_FIN_1 column
 * @method TPeriodeQuery groupByDimancheCapacite1() Group by the DIMANCHE_CAPACITE_1 column
 * @method TPeriodeQuery groupByDimancheNbRdvSite1() Group by the DIMANCHE_NB_RDV_SITE_1 column
 * @method TPeriodeQuery groupByDimancheHeureDebut2() Group by the DIMANCHE_HEURE_DEBUT_2 column
 * @method TPeriodeQuery groupByDimancheHeureFin2() Group by the DIMANCHE_HEURE_FIN_2 column
 * @method TPeriodeQuery groupByDimancheCapacite2() Group by the DIMANCHE_CAPACITE_2 column
 * @method TPeriodeQuery groupByDimancheNbRdvSite2() Group by the DIMANCHE_NB_RDV_SITE_2 column
 * @method TPeriodeQuery groupByIdAgenda() Group by the ID_AGENDA column
 * @method TPeriodeQuery groupByPeriodicite() Group by the PERIODICITE column
 *
 * @method TPeriodeQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TPeriodeQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TPeriodeQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TPeriodeQuery leftJoinTAgenda($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgenda relation
 * @method TPeriodeQuery rightJoinTAgenda($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgenda relation
 * @method TPeriodeQuery innerJoinTAgenda($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgenda relation
 *
 * @method TPeriode findOne(PropelPDO $con = null) Return the first TPeriode matching the query
 * @method TPeriode findOneOrCreate(PropelPDO $con = null) Return the first TPeriode matching the query, or a new TPeriode object populated from the query conditions when no match is found
 *
 * @method TPeriode findOneByDebutPeriode(string $DEBUT_PERIODE) Return the first TPeriode filtered by the DEBUT_PERIODE column
 * @method TPeriode findOneByFinPeriode(string $FIN_PERIODE) Return the first TPeriode filtered by the FIN_PERIODE column
 * @method TPeriode findOneByLundiHeureDebut1(string $LUNDI_HEURE_DEBUT_1) Return the first TPeriode filtered by the LUNDI_HEURE_DEBUT_1 column
 * @method TPeriode findOneByLundiHeureFin1(string $LUNDI_HEURE_FIN_1) Return the first TPeriode filtered by the LUNDI_HEURE_FIN_1 column
 * @method TPeriode findOneByLundiCapacite1(int $LUNDI_CAPACITE_1) Return the first TPeriode filtered by the LUNDI_CAPACITE_1 column
 * @method TPeriode findOneByLundiNbRdvSite1(int $LUNDI_NB_RDV_SITE_1) Return the first TPeriode filtered by the LUNDI_NB_RDV_SITE_1 column
 * @method TPeriode findOneByLundiHeureDebut2(string $LUNDI_HEURE_DEBUT_2) Return the first TPeriode filtered by the LUNDI_HEURE_DEBUT_2 column
 * @method TPeriode findOneByLundiHeureFin2(string $LUNDI_HEURE_FIN_2) Return the first TPeriode filtered by the LUNDI_HEURE_FIN_2 column
 * @method TPeriode findOneByLundiCapacite2(int $LUNDI_CAPACITE_2) Return the first TPeriode filtered by the LUNDI_CAPACITE_2 column
 * @method TPeriode findOneByLundiNbRdvSite2(int $LUNDI_NB_RDV_SITE_2) Return the first TPeriode filtered by the LUNDI_NB_RDV_SITE_2 column
 * @method TPeriode findOneByMardiHeureDebut1(string $MARDI_HEURE_DEBUT_1) Return the first TPeriode filtered by the MARDI_HEURE_DEBUT_1 column
 * @method TPeriode findOneByMardiHeureFin1(string $MARDI_HEURE_FIN_1) Return the first TPeriode filtered by the MARDI_HEURE_FIN_1 column
 * @method TPeriode findOneByMardiCapacite1(int $MARDI_CAPACITE_1) Return the first TPeriode filtered by the MARDI_CAPACITE_1 column
 * @method TPeriode findOneByMardiNbRdvSite1(int $MARDI_NB_RDV_SITE_1) Return the first TPeriode filtered by the MARDI_NB_RDV_SITE_1 column
 * @method TPeriode findOneByMardiHeureDebut2(string $MARDI_HEURE_DEBUT_2) Return the first TPeriode filtered by the MARDI_HEURE_DEBUT_2 column
 * @method TPeriode findOneByMardiHeureFin2(string $MARDI_HEURE_FIN_2) Return the first TPeriode filtered by the MARDI_HEURE_FIN_2 column
 * @method TPeriode findOneByMardiCapacite2(int $MARDI_CAPACITE_2) Return the first TPeriode filtered by the MARDI_CAPACITE_2 column
 * @method TPeriode findOneByMardiNbRdvSite2(int $MARDI_NB_RDV_SITE_2) Return the first TPeriode filtered by the MARDI_NB_RDV_SITE_2 column
 * @method TPeriode findOneByMercrediHeureDebut1(string $MERCREDI_HEURE_DEBUT_1) Return the first TPeriode filtered by the MERCREDI_HEURE_DEBUT_1 column
 * @method TPeriode findOneByMercrediHeureFin1(string $MERCREDI_HEURE_FIN_1) Return the first TPeriode filtered by the MERCREDI_HEURE_FIN_1 column
 * @method TPeriode findOneByMercrediCapacite1(int $MERCREDI_CAPACITE_1) Return the first TPeriode filtered by the MERCREDI_CAPACITE_1 column
 * @method TPeriode findOneByMercrediNbRdvSite1(int $MERCREDI_NB_RDV_SITE_1) Return the first TPeriode filtered by the MERCREDI_NB_RDV_SITE_1 column
 * @method TPeriode findOneByMercrediHeureDebut2(string $MERCREDI_HEURE_DEBUT_2) Return the first TPeriode filtered by the MERCREDI_HEURE_DEBUT_2 column
 * @method TPeriode findOneByMercrediHeureFin2(string $MERCREDI_HEURE_FIN_2) Return the first TPeriode filtered by the MERCREDI_HEURE_FIN_2 column
 * @method TPeriode findOneByMercrediCapacite2(int $MERCREDI_CAPACITE_2) Return the first TPeriode filtered by the MERCREDI_CAPACITE_2 column
 * @method TPeriode findOneByMercrediNbRdvSite2(int $MERCREDI_NB_RDV_SITE_2) Return the first TPeriode filtered by the MERCREDI_NB_RDV_SITE_2 column
 * @method TPeriode findOneByJeudiHeureDebut1(string $JEUDI_HEURE_DEBUT_1) Return the first TPeriode filtered by the JEUDI_HEURE_DEBUT_1 column
 * @method TPeriode findOneByJeudiHeureFin1(string $JEUDI_HEURE_FIN_1) Return the first TPeriode filtered by the JEUDI_HEURE_FIN_1 column
 * @method TPeriode findOneByJeudiCapacite1(int $JEUDI_CAPACITE_1) Return the first TPeriode filtered by the JEUDI_CAPACITE_1 column
 * @method TPeriode findOneByJeudiNbRdvSite1(int $JEUDI_NB_RDV_SITE_1) Return the first TPeriode filtered by the JEUDI_NB_RDV_SITE_1 column
 * @method TPeriode findOneByJeudiHeureDebut2(string $JEUDI_HEURE_DEBUT_2) Return the first TPeriode filtered by the JEUDI_HEURE_DEBUT_2 column
 * @method TPeriode findOneByJeudiHeureFin2(string $JEUDI_HEURE_FIN_2) Return the first TPeriode filtered by the JEUDI_HEURE_FIN_2 column
 * @method TPeriode findOneByJeudiCapacite2(int $JEUDI_CAPACITE_2) Return the first TPeriode filtered by the JEUDI_CAPACITE_2 column
 * @method TPeriode findOneByJeudiNbRdvSite2(int $JEUDI_NB_RDV_SITE_2) Return the first TPeriode filtered by the JEUDI_NB_RDV_SITE_2 column
 * @method TPeriode findOneByVendrediHeureDebut1(string $VENDREDI_HEURE_DEBUT_1) Return the first TPeriode filtered by the VENDREDI_HEURE_DEBUT_1 column
 * @method TPeriode findOneByVendrediHeureFin1(string $VENDREDI_HEURE_FIN_1) Return the first TPeriode filtered by the VENDREDI_HEURE_FIN_1 column
 * @method TPeriode findOneByVendrediCapacite1(int $VENDREDI_CAPACITE_1) Return the first TPeriode filtered by the VENDREDI_CAPACITE_1 column
 * @method TPeriode findOneByVendrediNbRdvSite1(int $VENDREDI_NB_RDV_SITE_1) Return the first TPeriode filtered by the VENDREDI_NB_RDV_SITE_1 column
 * @method TPeriode findOneByVendrediHeureDebut2(string $VENDREDI_HEURE_DEBUT_2) Return the first TPeriode filtered by the VENDREDI_HEURE_DEBUT_2 column
 * @method TPeriode findOneByVendrediHeureFin2(string $VENDREDI_HEURE_FIN_2) Return the first TPeriode filtered by the VENDREDI_HEURE_FIN_2 column
 * @method TPeriode findOneByVendrediCapacite2(int $VENDREDI_CAPACITE_2) Return the first TPeriode filtered by the VENDREDI_CAPACITE_2 column
 * @method TPeriode findOneByVendrediNbRdvSite2(int $VENDREDI_NB_RDV_SITE_2) Return the first TPeriode filtered by the VENDREDI_NB_RDV_SITE_2 column
 * @method TPeriode findOneBySamediHeureDebut1(string $SAMEDI_HEURE_DEBUT_1) Return the first TPeriode filtered by the SAMEDI_HEURE_DEBUT_1 column
 * @method TPeriode findOneBySamediHeureFin1(string $SAMEDI_HEURE_FIN_1) Return the first TPeriode filtered by the SAMEDI_HEURE_FIN_1 column
 * @method TPeriode findOneBySamediCapacite1(int $SAMEDI_CAPACITE_1) Return the first TPeriode filtered by the SAMEDI_CAPACITE_1 column
 * @method TPeriode findOneBySamediNbRdvSite1(int $SAMEDI_NB_RDV_SITE_1) Return the first TPeriode filtered by the SAMEDI_NB_RDV_SITE_1 column
 * @method TPeriode findOneBySamediHeureDebut2(string $SAMEDI_HEURE_DEBUT_2) Return the first TPeriode filtered by the SAMEDI_HEURE_DEBUT_2 column
 * @method TPeriode findOneBySamediHeureFin2(string $SAMEDI_HEURE_FIN_2) Return the first TPeriode filtered by the SAMEDI_HEURE_FIN_2 column
 * @method TPeriode findOneBySamediCapacite2(int $SAMEDI_CAPACITE_2) Return the first TPeriode filtered by the SAMEDI_CAPACITE_2 column
 * @method TPeriode findOneBySamediNbRdvSite2(int $SAMEDI_NB_RDV_SITE_2) Return the first TPeriode filtered by the SAMEDI_NB_RDV_SITE_2 column
 * @method TPeriode findOneByDimancheHeureDebut1(string $DIMANCHE_HEURE_DEBUT_1) Return the first TPeriode filtered by the DIMANCHE_HEURE_DEBUT_1 column
 * @method TPeriode findOneByDimancheHeureFin1(string $DIMANCHE_HEURE_FIN_1) Return the first TPeriode filtered by the DIMANCHE_HEURE_FIN_1 column
 * @method TPeriode findOneByDimancheCapacite1(int $DIMANCHE_CAPACITE_1) Return the first TPeriode filtered by the DIMANCHE_CAPACITE_1 column
 * @method TPeriode findOneByDimancheNbRdvSite1(int $DIMANCHE_NB_RDV_SITE_1) Return the first TPeriode filtered by the DIMANCHE_NB_RDV_SITE_1 column
 * @method TPeriode findOneByDimancheHeureDebut2(string $DIMANCHE_HEURE_DEBUT_2) Return the first TPeriode filtered by the DIMANCHE_HEURE_DEBUT_2 column
 * @method TPeriode findOneByDimancheHeureFin2(string $DIMANCHE_HEURE_FIN_2) Return the first TPeriode filtered by the DIMANCHE_HEURE_FIN_2 column
 * @method TPeriode findOneByDimancheCapacite2(int $DIMANCHE_CAPACITE_2) Return the first TPeriode filtered by the DIMANCHE_CAPACITE_2 column
 * @method TPeriode findOneByDimancheNbRdvSite2(int $DIMANCHE_NB_RDV_SITE_2) Return the first TPeriode filtered by the DIMANCHE_NB_RDV_SITE_2 column
 * @method TPeriode findOneByIdAgenda(int $ID_AGENDA) Return the first TPeriode filtered by the ID_AGENDA column
 * @method TPeriode findOneByPeriodicite(int $PERIODICITE) Return the first TPeriode filtered by the PERIODICITE column
 *
 * @method array findByIdPeriode(int $ID_PERIODE) Return TPeriode objects filtered by the ID_PERIODE column
 * @method array findByDebutPeriode(string $DEBUT_PERIODE) Return TPeriode objects filtered by the DEBUT_PERIODE column
 * @method array findByFinPeriode(string $FIN_PERIODE) Return TPeriode objects filtered by the FIN_PERIODE column
 * @method array findByLundiHeureDebut1(string $LUNDI_HEURE_DEBUT_1) Return TPeriode objects filtered by the LUNDI_HEURE_DEBUT_1 column
 * @method array findByLundiHeureFin1(string $LUNDI_HEURE_FIN_1) Return TPeriode objects filtered by the LUNDI_HEURE_FIN_1 column
 * @method array findByLundiCapacite1(int $LUNDI_CAPACITE_1) Return TPeriode objects filtered by the LUNDI_CAPACITE_1 column
 * @method array findByLundiNbRdvSite1(int $LUNDI_NB_RDV_SITE_1) Return TPeriode objects filtered by the LUNDI_NB_RDV_SITE_1 column
 * @method array findByLundiHeureDebut2(string $LUNDI_HEURE_DEBUT_2) Return TPeriode objects filtered by the LUNDI_HEURE_DEBUT_2 column
 * @method array findByLundiHeureFin2(string $LUNDI_HEURE_FIN_2) Return TPeriode objects filtered by the LUNDI_HEURE_FIN_2 column
 * @method array findByLundiCapacite2(int $LUNDI_CAPACITE_2) Return TPeriode objects filtered by the LUNDI_CAPACITE_2 column
 * @method array findByLundiNbRdvSite2(int $LUNDI_NB_RDV_SITE_2) Return TPeriode objects filtered by the LUNDI_NB_RDV_SITE_2 column
 * @method array findByMardiHeureDebut1(string $MARDI_HEURE_DEBUT_1) Return TPeriode objects filtered by the MARDI_HEURE_DEBUT_1 column
 * @method array findByMardiHeureFin1(string $MARDI_HEURE_FIN_1) Return TPeriode objects filtered by the MARDI_HEURE_FIN_1 column
 * @method array findByMardiCapacite1(int $MARDI_CAPACITE_1) Return TPeriode objects filtered by the MARDI_CAPACITE_1 column
 * @method array findByMardiNbRdvSite1(int $MARDI_NB_RDV_SITE_1) Return TPeriode objects filtered by the MARDI_NB_RDV_SITE_1 column
 * @method array findByMardiHeureDebut2(string $MARDI_HEURE_DEBUT_2) Return TPeriode objects filtered by the MARDI_HEURE_DEBUT_2 column
 * @method array findByMardiHeureFin2(string $MARDI_HEURE_FIN_2) Return TPeriode objects filtered by the MARDI_HEURE_FIN_2 column
 * @method array findByMardiCapacite2(int $MARDI_CAPACITE_2) Return TPeriode objects filtered by the MARDI_CAPACITE_2 column
 * @method array findByMardiNbRdvSite2(int $MARDI_NB_RDV_SITE_2) Return TPeriode objects filtered by the MARDI_NB_RDV_SITE_2 column
 * @method array findByMercrediHeureDebut1(string $MERCREDI_HEURE_DEBUT_1) Return TPeriode objects filtered by the MERCREDI_HEURE_DEBUT_1 column
 * @method array findByMercrediHeureFin1(string $MERCREDI_HEURE_FIN_1) Return TPeriode objects filtered by the MERCREDI_HEURE_FIN_1 column
 * @method array findByMercrediCapacite1(int $MERCREDI_CAPACITE_1) Return TPeriode objects filtered by the MERCREDI_CAPACITE_1 column
 * @method array findByMercrediNbRdvSite1(int $MERCREDI_NB_RDV_SITE_1) Return TPeriode objects filtered by the MERCREDI_NB_RDV_SITE_1 column
 * @method array findByMercrediHeureDebut2(string $MERCREDI_HEURE_DEBUT_2) Return TPeriode objects filtered by the MERCREDI_HEURE_DEBUT_2 column
 * @method array findByMercrediHeureFin2(string $MERCREDI_HEURE_FIN_2) Return TPeriode objects filtered by the MERCREDI_HEURE_FIN_2 column
 * @method array findByMercrediCapacite2(int $MERCREDI_CAPACITE_2) Return TPeriode objects filtered by the MERCREDI_CAPACITE_2 column
 * @method array findByMercrediNbRdvSite2(int $MERCREDI_NB_RDV_SITE_2) Return TPeriode objects filtered by the MERCREDI_NB_RDV_SITE_2 column
 * @method array findByJeudiHeureDebut1(string $JEUDI_HEURE_DEBUT_1) Return TPeriode objects filtered by the JEUDI_HEURE_DEBUT_1 column
 * @method array findByJeudiHeureFin1(string $JEUDI_HEURE_FIN_1) Return TPeriode objects filtered by the JEUDI_HEURE_FIN_1 column
 * @method array findByJeudiCapacite1(int $JEUDI_CAPACITE_1) Return TPeriode objects filtered by the JEUDI_CAPACITE_1 column
 * @method array findByJeudiNbRdvSite1(int $JEUDI_NB_RDV_SITE_1) Return TPeriode objects filtered by the JEUDI_NB_RDV_SITE_1 column
 * @method array findByJeudiHeureDebut2(string $JEUDI_HEURE_DEBUT_2) Return TPeriode objects filtered by the JEUDI_HEURE_DEBUT_2 column
 * @method array findByJeudiHeureFin2(string $JEUDI_HEURE_FIN_2) Return TPeriode objects filtered by the JEUDI_HEURE_FIN_2 column
 * @method array findByJeudiCapacite2(int $JEUDI_CAPACITE_2) Return TPeriode objects filtered by the JEUDI_CAPACITE_2 column
 * @method array findByJeudiNbRdvSite2(int $JEUDI_NB_RDV_SITE_2) Return TPeriode objects filtered by the JEUDI_NB_RDV_SITE_2 column
 * @method array findByVendrediHeureDebut1(string $VENDREDI_HEURE_DEBUT_1) Return TPeriode objects filtered by the VENDREDI_HEURE_DEBUT_1 column
 * @method array findByVendrediHeureFin1(string $VENDREDI_HEURE_FIN_1) Return TPeriode objects filtered by the VENDREDI_HEURE_FIN_1 column
 * @method array findByVendrediCapacite1(int $VENDREDI_CAPACITE_1) Return TPeriode objects filtered by the VENDREDI_CAPACITE_1 column
 * @method array findByVendrediNbRdvSite1(int $VENDREDI_NB_RDV_SITE_1) Return TPeriode objects filtered by the VENDREDI_NB_RDV_SITE_1 column
 * @method array findByVendrediHeureDebut2(string $VENDREDI_HEURE_DEBUT_2) Return TPeriode objects filtered by the VENDREDI_HEURE_DEBUT_2 column
 * @method array findByVendrediHeureFin2(string $VENDREDI_HEURE_FIN_2) Return TPeriode objects filtered by the VENDREDI_HEURE_FIN_2 column
 * @method array findByVendrediCapacite2(int $VENDREDI_CAPACITE_2) Return TPeriode objects filtered by the VENDREDI_CAPACITE_2 column
 * @method array findByVendrediNbRdvSite2(int $VENDREDI_NB_RDV_SITE_2) Return TPeriode objects filtered by the VENDREDI_NB_RDV_SITE_2 column
 * @method array findBySamediHeureDebut1(string $SAMEDI_HEURE_DEBUT_1) Return TPeriode objects filtered by the SAMEDI_HEURE_DEBUT_1 column
 * @method array findBySamediHeureFin1(string $SAMEDI_HEURE_FIN_1) Return TPeriode objects filtered by the SAMEDI_HEURE_FIN_1 column
 * @method array findBySamediCapacite1(int $SAMEDI_CAPACITE_1) Return TPeriode objects filtered by the SAMEDI_CAPACITE_1 column
 * @method array findBySamediNbRdvSite1(int $SAMEDI_NB_RDV_SITE_1) Return TPeriode objects filtered by the SAMEDI_NB_RDV_SITE_1 column
 * @method array findBySamediHeureDebut2(string $SAMEDI_HEURE_DEBUT_2) Return TPeriode objects filtered by the SAMEDI_HEURE_DEBUT_2 column
 * @method array findBySamediHeureFin2(string $SAMEDI_HEURE_FIN_2) Return TPeriode objects filtered by the SAMEDI_HEURE_FIN_2 column
 * @method array findBySamediCapacite2(int $SAMEDI_CAPACITE_2) Return TPeriode objects filtered by the SAMEDI_CAPACITE_2 column
 * @method array findBySamediNbRdvSite2(int $SAMEDI_NB_RDV_SITE_2) Return TPeriode objects filtered by the SAMEDI_NB_RDV_SITE_2 column
 * @method array findByDimancheHeureDebut1(string $DIMANCHE_HEURE_DEBUT_1) Return TPeriode objects filtered by the DIMANCHE_HEURE_DEBUT_1 column
 * @method array findByDimancheHeureFin1(string $DIMANCHE_HEURE_FIN_1) Return TPeriode objects filtered by the DIMANCHE_HEURE_FIN_1 column
 * @method array findByDimancheCapacite1(int $DIMANCHE_CAPACITE_1) Return TPeriode objects filtered by the DIMANCHE_CAPACITE_1 column
 * @method array findByDimancheNbRdvSite1(int $DIMANCHE_NB_RDV_SITE_1) Return TPeriode objects filtered by the DIMANCHE_NB_RDV_SITE_1 column
 * @method array findByDimancheHeureDebut2(string $DIMANCHE_HEURE_DEBUT_2) Return TPeriode objects filtered by the DIMANCHE_HEURE_DEBUT_2 column
 * @method array findByDimancheHeureFin2(string $DIMANCHE_HEURE_FIN_2) Return TPeriode objects filtered by the DIMANCHE_HEURE_FIN_2 column
 * @method array findByDimancheCapacite2(int $DIMANCHE_CAPACITE_2) Return TPeriode objects filtered by the DIMANCHE_CAPACITE_2 column
 * @method array findByDimancheNbRdvSite2(int $DIMANCHE_NB_RDV_SITE_2) Return TPeriode objects filtered by the DIMANCHE_NB_RDV_SITE_2 column
 * @method array findByIdAgenda(int $ID_AGENDA) Return TPeriode objects filtered by the ID_AGENDA column
 * @method array findByPeriodicite(int $PERIODICITE) Return TPeriode objects filtered by the PERIODICITE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPeriodeQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTPeriodeQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TPeriode', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TPeriodeQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TPeriodeQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TPeriodeQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TPeriodeQuery) {
            return $criteria;
        }
        $query = new TPeriodeQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TPeriode|TPeriode[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TPeriodePeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TPeriodePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPeriode A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdPeriode($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPeriode A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PERIODE`, `DEBUT_PERIODE`, `FIN_PERIODE`, `LUNDI_HEURE_DEBUT_1`, `LUNDI_HEURE_FIN_1`, `LUNDI_CAPACITE_1`, `LUNDI_NB_RDV_SITE_1`, `LUNDI_HEURE_DEBUT_2`, `LUNDI_HEURE_FIN_2`, `LUNDI_CAPACITE_2`, `LUNDI_NB_RDV_SITE_2`, `MARDI_HEURE_DEBUT_1`, `MARDI_HEURE_FIN_1`, `MARDI_CAPACITE_1`, `MARDI_NB_RDV_SITE_1`, `MARDI_HEURE_DEBUT_2`, `MARDI_HEURE_FIN_2`, `MARDI_CAPACITE_2`, `MARDI_NB_RDV_SITE_2`, `MERCREDI_HEURE_DEBUT_1`, `MERCREDI_HEURE_FIN_1`, `MERCREDI_CAPACITE_1`, `MERCREDI_NB_RDV_SITE_1`, `MERCREDI_HEURE_DEBUT_2`, `MERCREDI_HEURE_FIN_2`, `MERCREDI_CAPACITE_2`, `MERCREDI_NB_RDV_SITE_2`, `JEUDI_HEURE_DEBUT_1`, `JEUDI_HEURE_FIN_1`, `JEUDI_CAPACITE_1`, `JEUDI_NB_RDV_SITE_1`, `JEUDI_HEURE_DEBUT_2`, `JEUDI_HEURE_FIN_2`, `JEUDI_CAPACITE_2`, `JEUDI_NB_RDV_SITE_2`, `VENDREDI_HEURE_DEBUT_1`, `VENDREDI_HEURE_FIN_1`, `VENDREDI_CAPACITE_1`, `VENDREDI_NB_RDV_SITE_1`, `VENDREDI_HEURE_DEBUT_2`, `VENDREDI_HEURE_FIN_2`, `VENDREDI_CAPACITE_2`, `VENDREDI_NB_RDV_SITE_2`, `SAMEDI_HEURE_DEBUT_1`, `SAMEDI_HEURE_FIN_1`, `SAMEDI_CAPACITE_1`, `SAMEDI_NB_RDV_SITE_1`, `SAMEDI_HEURE_DEBUT_2`, `SAMEDI_HEURE_FIN_2`, `SAMEDI_CAPACITE_2`, `SAMEDI_NB_RDV_SITE_2`, `DIMANCHE_HEURE_DEBUT_1`, `DIMANCHE_HEURE_FIN_1`, `DIMANCHE_CAPACITE_1`, `DIMANCHE_NB_RDV_SITE_1`, `DIMANCHE_HEURE_DEBUT_2`, `DIMANCHE_HEURE_FIN_2`, `DIMANCHE_CAPACITE_2`, `DIMANCHE_NB_RDV_SITE_2`, `ID_AGENDA`, `PERIODICITE` FROM `T_PERIODE` WHERE `ID_PERIODE` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TPeriode();
            $obj->hydrate($row);
            TPeriodePeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TPeriode|TPeriode[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TPeriode[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TPeriodePeer::ID_PERIODE, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TPeriodePeer::ID_PERIODE, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PERIODE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPeriode(1234); // WHERE ID_PERIODE = 1234
     * $query->filterByIdPeriode(array(12, 34)); // WHERE ID_PERIODE IN (12, 34)
     * $query->filterByIdPeriode(array('min' => 12)); // WHERE ID_PERIODE >= 12
     * $query->filterByIdPeriode(array('max' => 12)); // WHERE ID_PERIODE <= 12
     * </code>
     *
     * @param     mixed $idPeriode The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByIdPeriode($idPeriode = null, $comparison = null)
    {
        if (is_array($idPeriode)) {
            $useMinMax = false;
            if (isset($idPeriode['min'])) {
                $this->addUsingAlias(TPeriodePeer::ID_PERIODE, $idPeriode['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPeriode['max'])) {
                $this->addUsingAlias(TPeriodePeer::ID_PERIODE, $idPeriode['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::ID_PERIODE, $idPeriode, $comparison);
    }

    /**
     * Filter the query on the DEBUT_PERIODE column
     *
     * Example usage:
     * <code>
     * $query->filterByDebutPeriode('2011-03-14'); // WHERE DEBUT_PERIODE = '2011-03-14'
     * $query->filterByDebutPeriode('now'); // WHERE DEBUT_PERIODE = '2011-03-14'
     * $query->filterByDebutPeriode(array('max' => 'yesterday')); // WHERE DEBUT_PERIODE > '2011-03-13'
     * </code>
     *
     * @param     mixed $debutPeriode The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDebutPeriode($debutPeriode = null, $comparison = null)
    {
        if (is_array($debutPeriode)) {
            $useMinMax = false;
            if (isset($debutPeriode['min'])) {
                $this->addUsingAlias(TPeriodePeer::DEBUT_PERIODE, $debutPeriode['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($debutPeriode['max'])) {
                $this->addUsingAlias(TPeriodePeer::DEBUT_PERIODE, $debutPeriode['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DEBUT_PERIODE, $debutPeriode, $comparison);
    }

    /**
     * Filter the query on the FIN_PERIODE column
     *
     * Example usage:
     * <code>
     * $query->filterByFinPeriode('2011-03-14'); // WHERE FIN_PERIODE = '2011-03-14'
     * $query->filterByFinPeriode('now'); // WHERE FIN_PERIODE = '2011-03-14'
     * $query->filterByFinPeriode(array('max' => 'yesterday')); // WHERE FIN_PERIODE > '2011-03-13'
     * </code>
     *
     * @param     mixed $finPeriode The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByFinPeriode($finPeriode = null, $comparison = null)
    {
        if (is_array($finPeriode)) {
            $useMinMax = false;
            if (isset($finPeriode['min'])) {
                $this->addUsingAlias(TPeriodePeer::FIN_PERIODE, $finPeriode['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($finPeriode['max'])) {
                $this->addUsingAlias(TPeriodePeer::FIN_PERIODE, $finPeriode['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::FIN_PERIODE, $finPeriode, $comparison);
    }

    /**
     * Filter the query on the LUNDI_HEURE_DEBUT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiHeureDebut1('2011-03-14'); // WHERE LUNDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByLundiHeureDebut1('now'); // WHERE LUNDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByLundiHeureDebut1(array('max' => 'yesterday')); // WHERE LUNDI_HEURE_DEBUT_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $lundiHeureDebut1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiHeureDebut1($lundiHeureDebut1 = null, $comparison = null)
    {
        if (is_array($lundiHeureDebut1)) {
            $useMinMax = false;
            if (isset($lundiHeureDebut1['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_DEBUT_1, $lundiHeureDebut1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiHeureDebut1['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_DEBUT_1, $lundiHeureDebut1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_DEBUT_1, $lundiHeureDebut1, $comparison);
    }

    /**
     * Filter the query on the LUNDI_HEURE_FIN_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiHeureFin1('2011-03-14'); // WHERE LUNDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByLundiHeureFin1('now'); // WHERE LUNDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByLundiHeureFin1(array('max' => 'yesterday')); // WHERE LUNDI_HEURE_FIN_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $lundiHeureFin1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiHeureFin1($lundiHeureFin1 = null, $comparison = null)
    {
        if (is_array($lundiHeureFin1)) {
            $useMinMax = false;
            if (isset($lundiHeureFin1['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_FIN_1, $lundiHeureFin1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiHeureFin1['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_FIN_1, $lundiHeureFin1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_FIN_1, $lundiHeureFin1, $comparison);
    }

    /**
     * Filter the query on the LUNDI_CAPACITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiCapacite1(1234); // WHERE LUNDI_CAPACITE_1 = 1234
     * $query->filterByLundiCapacite1(array(12, 34)); // WHERE LUNDI_CAPACITE_1 IN (12, 34)
     * $query->filterByLundiCapacite1(array('min' => 12)); // WHERE LUNDI_CAPACITE_1 >= 12
     * $query->filterByLundiCapacite1(array('max' => 12)); // WHERE LUNDI_CAPACITE_1 <= 12
     * </code>
     *
     * @param     mixed $lundiCapacite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiCapacite1($lundiCapacite1 = null, $comparison = null)
    {
        if (is_array($lundiCapacite1)) {
            $useMinMax = false;
            if (isset($lundiCapacite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_CAPACITE_1, $lundiCapacite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiCapacite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_CAPACITE_1, $lundiCapacite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_CAPACITE_1, $lundiCapacite1, $comparison);
    }

    /**
     * Filter the query on the LUNDI_NB_RDV_SITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiNbRdvSite1(1234); // WHERE LUNDI_NB_RDV_SITE_1 = 1234
     * $query->filterByLundiNbRdvSite1(array(12, 34)); // WHERE LUNDI_NB_RDV_SITE_1 IN (12, 34)
     * $query->filterByLundiNbRdvSite1(array('min' => 12)); // WHERE LUNDI_NB_RDV_SITE_1 >= 12
     * $query->filterByLundiNbRdvSite1(array('max' => 12)); // WHERE LUNDI_NB_RDV_SITE_1 <= 12
     * </code>
     *
     * @param     mixed $lundiNbRdvSite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiNbRdvSite1($lundiNbRdvSite1 = null, $comparison = null)
    {
        if (is_array($lundiNbRdvSite1)) {
            $useMinMax = false;
            if (isset($lundiNbRdvSite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_NB_RDV_SITE_1, $lundiNbRdvSite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiNbRdvSite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_NB_RDV_SITE_1, $lundiNbRdvSite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_NB_RDV_SITE_1, $lundiNbRdvSite1, $comparison);
    }

    /**
     * Filter the query on the LUNDI_HEURE_DEBUT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiHeureDebut2('2011-03-14'); // WHERE LUNDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByLundiHeureDebut2('now'); // WHERE LUNDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByLundiHeureDebut2(array('max' => 'yesterday')); // WHERE LUNDI_HEURE_DEBUT_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $lundiHeureDebut2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiHeureDebut2($lundiHeureDebut2 = null, $comparison = null)
    {
        if (is_array($lundiHeureDebut2)) {
            $useMinMax = false;
            if (isset($lundiHeureDebut2['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_DEBUT_2, $lundiHeureDebut2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiHeureDebut2['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_DEBUT_2, $lundiHeureDebut2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_DEBUT_2, $lundiHeureDebut2, $comparison);
    }

    /**
     * Filter the query on the LUNDI_HEURE_FIN_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiHeureFin2('2011-03-14'); // WHERE LUNDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByLundiHeureFin2('now'); // WHERE LUNDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByLundiHeureFin2(array('max' => 'yesterday')); // WHERE LUNDI_HEURE_FIN_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $lundiHeureFin2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiHeureFin2($lundiHeureFin2 = null, $comparison = null)
    {
        if (is_array($lundiHeureFin2)) {
            $useMinMax = false;
            if (isset($lundiHeureFin2['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_FIN_2, $lundiHeureFin2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiHeureFin2['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_FIN_2, $lundiHeureFin2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_HEURE_FIN_2, $lundiHeureFin2, $comparison);
    }

    /**
     * Filter the query on the LUNDI_CAPACITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiCapacite2(1234); // WHERE LUNDI_CAPACITE_2 = 1234
     * $query->filterByLundiCapacite2(array(12, 34)); // WHERE LUNDI_CAPACITE_2 IN (12, 34)
     * $query->filterByLundiCapacite2(array('min' => 12)); // WHERE LUNDI_CAPACITE_2 >= 12
     * $query->filterByLundiCapacite2(array('max' => 12)); // WHERE LUNDI_CAPACITE_2 <= 12
     * </code>
     *
     * @param     mixed $lundiCapacite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiCapacite2($lundiCapacite2 = null, $comparison = null)
    {
        if (is_array($lundiCapacite2)) {
            $useMinMax = false;
            if (isset($lundiCapacite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_CAPACITE_2, $lundiCapacite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiCapacite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_CAPACITE_2, $lundiCapacite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_CAPACITE_2, $lundiCapacite2, $comparison);
    }

    /**
     * Filter the query on the LUNDI_NB_RDV_SITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByLundiNbRdvSite2(1234); // WHERE LUNDI_NB_RDV_SITE_2 = 1234
     * $query->filterByLundiNbRdvSite2(array(12, 34)); // WHERE LUNDI_NB_RDV_SITE_2 IN (12, 34)
     * $query->filterByLundiNbRdvSite2(array('min' => 12)); // WHERE LUNDI_NB_RDV_SITE_2 >= 12
     * $query->filterByLundiNbRdvSite2(array('max' => 12)); // WHERE LUNDI_NB_RDV_SITE_2 <= 12
     * </code>
     *
     * @param     mixed $lundiNbRdvSite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByLundiNbRdvSite2($lundiNbRdvSite2 = null, $comparison = null)
    {
        if (is_array($lundiNbRdvSite2)) {
            $useMinMax = false;
            if (isset($lundiNbRdvSite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_NB_RDV_SITE_2, $lundiNbRdvSite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($lundiNbRdvSite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::LUNDI_NB_RDV_SITE_2, $lundiNbRdvSite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::LUNDI_NB_RDV_SITE_2, $lundiNbRdvSite2, $comparison);
    }

    /**
     * Filter the query on the MARDI_HEURE_DEBUT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiHeureDebut1('2011-03-14'); // WHERE MARDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByMardiHeureDebut1('now'); // WHERE MARDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByMardiHeureDebut1(array('max' => 'yesterday')); // WHERE MARDI_HEURE_DEBUT_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mardiHeureDebut1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiHeureDebut1($mardiHeureDebut1 = null, $comparison = null)
    {
        if (is_array($mardiHeureDebut1)) {
            $useMinMax = false;
            if (isset($mardiHeureDebut1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_DEBUT_1, $mardiHeureDebut1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiHeureDebut1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_DEBUT_1, $mardiHeureDebut1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_DEBUT_1, $mardiHeureDebut1, $comparison);
    }

    /**
     * Filter the query on the MARDI_HEURE_FIN_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiHeureFin1('2011-03-14'); // WHERE MARDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByMardiHeureFin1('now'); // WHERE MARDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByMardiHeureFin1(array('max' => 'yesterday')); // WHERE MARDI_HEURE_FIN_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mardiHeureFin1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiHeureFin1($mardiHeureFin1 = null, $comparison = null)
    {
        if (is_array($mardiHeureFin1)) {
            $useMinMax = false;
            if (isset($mardiHeureFin1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_FIN_1, $mardiHeureFin1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiHeureFin1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_FIN_1, $mardiHeureFin1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_FIN_1, $mardiHeureFin1, $comparison);
    }

    /**
     * Filter the query on the MARDI_CAPACITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiCapacite1(1234); // WHERE MARDI_CAPACITE_1 = 1234
     * $query->filterByMardiCapacite1(array(12, 34)); // WHERE MARDI_CAPACITE_1 IN (12, 34)
     * $query->filterByMardiCapacite1(array('min' => 12)); // WHERE MARDI_CAPACITE_1 >= 12
     * $query->filterByMardiCapacite1(array('max' => 12)); // WHERE MARDI_CAPACITE_1 <= 12
     * </code>
     *
     * @param     mixed $mardiCapacite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiCapacite1($mardiCapacite1 = null, $comparison = null)
    {
        if (is_array($mardiCapacite1)) {
            $useMinMax = false;
            if (isset($mardiCapacite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_CAPACITE_1, $mardiCapacite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiCapacite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_CAPACITE_1, $mardiCapacite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_CAPACITE_1, $mardiCapacite1, $comparison);
    }

    /**
     * Filter the query on the MARDI_NB_RDV_SITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiNbRdvSite1(1234); // WHERE MARDI_NB_RDV_SITE_1 = 1234
     * $query->filterByMardiNbRdvSite1(array(12, 34)); // WHERE MARDI_NB_RDV_SITE_1 IN (12, 34)
     * $query->filterByMardiNbRdvSite1(array('min' => 12)); // WHERE MARDI_NB_RDV_SITE_1 >= 12
     * $query->filterByMardiNbRdvSite1(array('max' => 12)); // WHERE MARDI_NB_RDV_SITE_1 <= 12
     * </code>
     *
     * @param     mixed $mardiNbRdvSite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiNbRdvSite1($mardiNbRdvSite1 = null, $comparison = null)
    {
        if (is_array($mardiNbRdvSite1)) {
            $useMinMax = false;
            if (isset($mardiNbRdvSite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_NB_RDV_SITE_1, $mardiNbRdvSite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiNbRdvSite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_NB_RDV_SITE_1, $mardiNbRdvSite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_NB_RDV_SITE_1, $mardiNbRdvSite1, $comparison);
    }

    /**
     * Filter the query on the MARDI_HEURE_DEBUT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiHeureDebut2('2011-03-14'); // WHERE MARDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByMardiHeureDebut2('now'); // WHERE MARDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByMardiHeureDebut2(array('max' => 'yesterday')); // WHERE MARDI_HEURE_DEBUT_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mardiHeureDebut2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiHeureDebut2($mardiHeureDebut2 = null, $comparison = null)
    {
        if (is_array($mardiHeureDebut2)) {
            $useMinMax = false;
            if (isset($mardiHeureDebut2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_DEBUT_2, $mardiHeureDebut2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiHeureDebut2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_DEBUT_2, $mardiHeureDebut2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_DEBUT_2, $mardiHeureDebut2, $comparison);
    }

    /**
     * Filter the query on the MARDI_HEURE_FIN_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiHeureFin2('2011-03-14'); // WHERE MARDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByMardiHeureFin2('now'); // WHERE MARDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByMardiHeureFin2(array('max' => 'yesterday')); // WHERE MARDI_HEURE_FIN_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mardiHeureFin2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiHeureFin2($mardiHeureFin2 = null, $comparison = null)
    {
        if (is_array($mardiHeureFin2)) {
            $useMinMax = false;
            if (isset($mardiHeureFin2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_FIN_2, $mardiHeureFin2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiHeureFin2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_FIN_2, $mardiHeureFin2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_HEURE_FIN_2, $mardiHeureFin2, $comparison);
    }

    /**
     * Filter the query on the MARDI_CAPACITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiCapacite2(1234); // WHERE MARDI_CAPACITE_2 = 1234
     * $query->filterByMardiCapacite2(array(12, 34)); // WHERE MARDI_CAPACITE_2 IN (12, 34)
     * $query->filterByMardiCapacite2(array('min' => 12)); // WHERE MARDI_CAPACITE_2 >= 12
     * $query->filterByMardiCapacite2(array('max' => 12)); // WHERE MARDI_CAPACITE_2 <= 12
     * </code>
     *
     * @param     mixed $mardiCapacite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiCapacite2($mardiCapacite2 = null, $comparison = null)
    {
        if (is_array($mardiCapacite2)) {
            $useMinMax = false;
            if (isset($mardiCapacite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_CAPACITE_2, $mardiCapacite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiCapacite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_CAPACITE_2, $mardiCapacite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_CAPACITE_2, $mardiCapacite2, $comparison);
    }

    /**
     * Filter the query on the MARDI_NB_RDV_SITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMardiNbRdvSite2(1234); // WHERE MARDI_NB_RDV_SITE_2 = 1234
     * $query->filterByMardiNbRdvSite2(array(12, 34)); // WHERE MARDI_NB_RDV_SITE_2 IN (12, 34)
     * $query->filterByMardiNbRdvSite2(array('min' => 12)); // WHERE MARDI_NB_RDV_SITE_2 >= 12
     * $query->filterByMardiNbRdvSite2(array('max' => 12)); // WHERE MARDI_NB_RDV_SITE_2 <= 12
     * </code>
     *
     * @param     mixed $mardiNbRdvSite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMardiNbRdvSite2($mardiNbRdvSite2 = null, $comparison = null)
    {
        if (is_array($mardiNbRdvSite2)) {
            $useMinMax = false;
            if (isset($mardiNbRdvSite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_NB_RDV_SITE_2, $mardiNbRdvSite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mardiNbRdvSite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MARDI_NB_RDV_SITE_2, $mardiNbRdvSite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MARDI_NB_RDV_SITE_2, $mardiNbRdvSite2, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_HEURE_DEBUT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediHeureDebut1('2011-03-14'); // WHERE MERCREDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByMercrediHeureDebut1('now'); // WHERE MERCREDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByMercrediHeureDebut1(array('max' => 'yesterday')); // WHERE MERCREDI_HEURE_DEBUT_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mercrediHeureDebut1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediHeureDebut1($mercrediHeureDebut1 = null, $comparison = null)
    {
        if (is_array($mercrediHeureDebut1)) {
            $useMinMax = false;
            if (isset($mercrediHeureDebut1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_DEBUT_1, $mercrediHeureDebut1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediHeureDebut1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_DEBUT_1, $mercrediHeureDebut1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_DEBUT_1, $mercrediHeureDebut1, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_HEURE_FIN_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediHeureFin1('2011-03-14'); // WHERE MERCREDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByMercrediHeureFin1('now'); // WHERE MERCREDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByMercrediHeureFin1(array('max' => 'yesterday')); // WHERE MERCREDI_HEURE_FIN_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mercrediHeureFin1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediHeureFin1($mercrediHeureFin1 = null, $comparison = null)
    {
        if (is_array($mercrediHeureFin1)) {
            $useMinMax = false;
            if (isset($mercrediHeureFin1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_FIN_1, $mercrediHeureFin1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediHeureFin1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_FIN_1, $mercrediHeureFin1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_FIN_1, $mercrediHeureFin1, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_CAPACITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediCapacite1(1234); // WHERE MERCREDI_CAPACITE_1 = 1234
     * $query->filterByMercrediCapacite1(array(12, 34)); // WHERE MERCREDI_CAPACITE_1 IN (12, 34)
     * $query->filterByMercrediCapacite1(array('min' => 12)); // WHERE MERCREDI_CAPACITE_1 >= 12
     * $query->filterByMercrediCapacite1(array('max' => 12)); // WHERE MERCREDI_CAPACITE_1 <= 12
     * </code>
     *
     * @param     mixed $mercrediCapacite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediCapacite1($mercrediCapacite1 = null, $comparison = null)
    {
        if (is_array($mercrediCapacite1)) {
            $useMinMax = false;
            if (isset($mercrediCapacite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_CAPACITE_1, $mercrediCapacite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediCapacite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_CAPACITE_1, $mercrediCapacite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_CAPACITE_1, $mercrediCapacite1, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_NB_RDV_SITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediNbRdvSite1(1234); // WHERE MERCREDI_NB_RDV_SITE_1 = 1234
     * $query->filterByMercrediNbRdvSite1(array(12, 34)); // WHERE MERCREDI_NB_RDV_SITE_1 IN (12, 34)
     * $query->filterByMercrediNbRdvSite1(array('min' => 12)); // WHERE MERCREDI_NB_RDV_SITE_1 >= 12
     * $query->filterByMercrediNbRdvSite1(array('max' => 12)); // WHERE MERCREDI_NB_RDV_SITE_1 <= 12
     * </code>
     *
     * @param     mixed $mercrediNbRdvSite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediNbRdvSite1($mercrediNbRdvSite1 = null, $comparison = null)
    {
        if (is_array($mercrediNbRdvSite1)) {
            $useMinMax = false;
            if (isset($mercrediNbRdvSite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_NB_RDV_SITE_1, $mercrediNbRdvSite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediNbRdvSite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_NB_RDV_SITE_1, $mercrediNbRdvSite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_NB_RDV_SITE_1, $mercrediNbRdvSite1, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_HEURE_DEBUT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediHeureDebut2('2011-03-14'); // WHERE MERCREDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByMercrediHeureDebut2('now'); // WHERE MERCREDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByMercrediHeureDebut2(array('max' => 'yesterday')); // WHERE MERCREDI_HEURE_DEBUT_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mercrediHeureDebut2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediHeureDebut2($mercrediHeureDebut2 = null, $comparison = null)
    {
        if (is_array($mercrediHeureDebut2)) {
            $useMinMax = false;
            if (isset($mercrediHeureDebut2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_DEBUT_2, $mercrediHeureDebut2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediHeureDebut2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_DEBUT_2, $mercrediHeureDebut2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_DEBUT_2, $mercrediHeureDebut2, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_HEURE_FIN_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediHeureFin2('2011-03-14'); // WHERE MERCREDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByMercrediHeureFin2('now'); // WHERE MERCREDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByMercrediHeureFin2(array('max' => 'yesterday')); // WHERE MERCREDI_HEURE_FIN_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $mercrediHeureFin2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediHeureFin2($mercrediHeureFin2 = null, $comparison = null)
    {
        if (is_array($mercrediHeureFin2)) {
            $useMinMax = false;
            if (isset($mercrediHeureFin2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_FIN_2, $mercrediHeureFin2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediHeureFin2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_FIN_2, $mercrediHeureFin2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_HEURE_FIN_2, $mercrediHeureFin2, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_CAPACITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediCapacite2(1234); // WHERE MERCREDI_CAPACITE_2 = 1234
     * $query->filterByMercrediCapacite2(array(12, 34)); // WHERE MERCREDI_CAPACITE_2 IN (12, 34)
     * $query->filterByMercrediCapacite2(array('min' => 12)); // WHERE MERCREDI_CAPACITE_2 >= 12
     * $query->filterByMercrediCapacite2(array('max' => 12)); // WHERE MERCREDI_CAPACITE_2 <= 12
     * </code>
     *
     * @param     mixed $mercrediCapacite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediCapacite2($mercrediCapacite2 = null, $comparison = null)
    {
        if (is_array($mercrediCapacite2)) {
            $useMinMax = false;
            if (isset($mercrediCapacite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_CAPACITE_2, $mercrediCapacite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediCapacite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_CAPACITE_2, $mercrediCapacite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_CAPACITE_2, $mercrediCapacite2, $comparison);
    }

    /**
     * Filter the query on the MERCREDI_NB_RDV_SITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByMercrediNbRdvSite2(1234); // WHERE MERCREDI_NB_RDV_SITE_2 = 1234
     * $query->filterByMercrediNbRdvSite2(array(12, 34)); // WHERE MERCREDI_NB_RDV_SITE_2 IN (12, 34)
     * $query->filterByMercrediNbRdvSite2(array('min' => 12)); // WHERE MERCREDI_NB_RDV_SITE_2 >= 12
     * $query->filterByMercrediNbRdvSite2(array('max' => 12)); // WHERE MERCREDI_NB_RDV_SITE_2 <= 12
     * </code>
     *
     * @param     mixed $mercrediNbRdvSite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByMercrediNbRdvSite2($mercrediNbRdvSite2 = null, $comparison = null)
    {
        if (is_array($mercrediNbRdvSite2)) {
            $useMinMax = false;
            if (isset($mercrediNbRdvSite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_NB_RDV_SITE_2, $mercrediNbRdvSite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($mercrediNbRdvSite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::MERCREDI_NB_RDV_SITE_2, $mercrediNbRdvSite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::MERCREDI_NB_RDV_SITE_2, $mercrediNbRdvSite2, $comparison);
    }

    /**
     * Filter the query on the JEUDI_HEURE_DEBUT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiHeureDebut1('2011-03-14'); // WHERE JEUDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByJeudiHeureDebut1('now'); // WHERE JEUDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByJeudiHeureDebut1(array('max' => 'yesterday')); // WHERE JEUDI_HEURE_DEBUT_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $jeudiHeureDebut1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiHeureDebut1($jeudiHeureDebut1 = null, $comparison = null)
    {
        if (is_array($jeudiHeureDebut1)) {
            $useMinMax = false;
            if (isset($jeudiHeureDebut1['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_DEBUT_1, $jeudiHeureDebut1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiHeureDebut1['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_DEBUT_1, $jeudiHeureDebut1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_DEBUT_1, $jeudiHeureDebut1, $comparison);
    }

    /**
     * Filter the query on the JEUDI_HEURE_FIN_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiHeureFin1('2011-03-14'); // WHERE JEUDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByJeudiHeureFin1('now'); // WHERE JEUDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByJeudiHeureFin1(array('max' => 'yesterday')); // WHERE JEUDI_HEURE_FIN_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $jeudiHeureFin1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiHeureFin1($jeudiHeureFin1 = null, $comparison = null)
    {
        if (is_array($jeudiHeureFin1)) {
            $useMinMax = false;
            if (isset($jeudiHeureFin1['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_FIN_1, $jeudiHeureFin1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiHeureFin1['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_FIN_1, $jeudiHeureFin1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_FIN_1, $jeudiHeureFin1, $comparison);
    }

    /**
     * Filter the query on the JEUDI_CAPACITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiCapacite1(1234); // WHERE JEUDI_CAPACITE_1 = 1234
     * $query->filterByJeudiCapacite1(array(12, 34)); // WHERE JEUDI_CAPACITE_1 IN (12, 34)
     * $query->filterByJeudiCapacite1(array('min' => 12)); // WHERE JEUDI_CAPACITE_1 >= 12
     * $query->filterByJeudiCapacite1(array('max' => 12)); // WHERE JEUDI_CAPACITE_1 <= 12
     * </code>
     *
     * @param     mixed $jeudiCapacite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiCapacite1($jeudiCapacite1 = null, $comparison = null)
    {
        if (is_array($jeudiCapacite1)) {
            $useMinMax = false;
            if (isset($jeudiCapacite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_CAPACITE_1, $jeudiCapacite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiCapacite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_CAPACITE_1, $jeudiCapacite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_CAPACITE_1, $jeudiCapacite1, $comparison);
    }

    /**
     * Filter the query on the JEUDI_NB_RDV_SITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiNbRdvSite1(1234); // WHERE JEUDI_NB_RDV_SITE_1 = 1234
     * $query->filterByJeudiNbRdvSite1(array(12, 34)); // WHERE JEUDI_NB_RDV_SITE_1 IN (12, 34)
     * $query->filterByJeudiNbRdvSite1(array('min' => 12)); // WHERE JEUDI_NB_RDV_SITE_1 >= 12
     * $query->filterByJeudiNbRdvSite1(array('max' => 12)); // WHERE JEUDI_NB_RDV_SITE_1 <= 12
     * </code>
     *
     * @param     mixed $jeudiNbRdvSite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiNbRdvSite1($jeudiNbRdvSite1 = null, $comparison = null)
    {
        if (is_array($jeudiNbRdvSite1)) {
            $useMinMax = false;
            if (isset($jeudiNbRdvSite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_NB_RDV_SITE_1, $jeudiNbRdvSite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiNbRdvSite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_NB_RDV_SITE_1, $jeudiNbRdvSite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_NB_RDV_SITE_1, $jeudiNbRdvSite1, $comparison);
    }

    /**
     * Filter the query on the JEUDI_HEURE_DEBUT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiHeureDebut2('2011-03-14'); // WHERE JEUDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByJeudiHeureDebut2('now'); // WHERE JEUDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByJeudiHeureDebut2(array('max' => 'yesterday')); // WHERE JEUDI_HEURE_DEBUT_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $jeudiHeureDebut2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiHeureDebut2($jeudiHeureDebut2 = null, $comparison = null)
    {
        if (is_array($jeudiHeureDebut2)) {
            $useMinMax = false;
            if (isset($jeudiHeureDebut2['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_DEBUT_2, $jeudiHeureDebut2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiHeureDebut2['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_DEBUT_2, $jeudiHeureDebut2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_DEBUT_2, $jeudiHeureDebut2, $comparison);
    }

    /**
     * Filter the query on the JEUDI_HEURE_FIN_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiHeureFin2('2011-03-14'); // WHERE JEUDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByJeudiHeureFin2('now'); // WHERE JEUDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByJeudiHeureFin2(array('max' => 'yesterday')); // WHERE JEUDI_HEURE_FIN_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $jeudiHeureFin2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiHeureFin2($jeudiHeureFin2 = null, $comparison = null)
    {
        if (is_array($jeudiHeureFin2)) {
            $useMinMax = false;
            if (isset($jeudiHeureFin2['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_FIN_2, $jeudiHeureFin2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiHeureFin2['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_FIN_2, $jeudiHeureFin2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_HEURE_FIN_2, $jeudiHeureFin2, $comparison);
    }

    /**
     * Filter the query on the JEUDI_CAPACITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiCapacite2(1234); // WHERE JEUDI_CAPACITE_2 = 1234
     * $query->filterByJeudiCapacite2(array(12, 34)); // WHERE JEUDI_CAPACITE_2 IN (12, 34)
     * $query->filterByJeudiCapacite2(array('min' => 12)); // WHERE JEUDI_CAPACITE_2 >= 12
     * $query->filterByJeudiCapacite2(array('max' => 12)); // WHERE JEUDI_CAPACITE_2 <= 12
     * </code>
     *
     * @param     mixed $jeudiCapacite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiCapacite2($jeudiCapacite2 = null, $comparison = null)
    {
        if (is_array($jeudiCapacite2)) {
            $useMinMax = false;
            if (isset($jeudiCapacite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_CAPACITE_2, $jeudiCapacite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiCapacite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_CAPACITE_2, $jeudiCapacite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_CAPACITE_2, $jeudiCapacite2, $comparison);
    }

    /**
     * Filter the query on the JEUDI_NB_RDV_SITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByJeudiNbRdvSite2(1234); // WHERE JEUDI_NB_RDV_SITE_2 = 1234
     * $query->filterByJeudiNbRdvSite2(array(12, 34)); // WHERE JEUDI_NB_RDV_SITE_2 IN (12, 34)
     * $query->filterByJeudiNbRdvSite2(array('min' => 12)); // WHERE JEUDI_NB_RDV_SITE_2 >= 12
     * $query->filterByJeudiNbRdvSite2(array('max' => 12)); // WHERE JEUDI_NB_RDV_SITE_2 <= 12
     * </code>
     *
     * @param     mixed $jeudiNbRdvSite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByJeudiNbRdvSite2($jeudiNbRdvSite2 = null, $comparison = null)
    {
        if (is_array($jeudiNbRdvSite2)) {
            $useMinMax = false;
            if (isset($jeudiNbRdvSite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_NB_RDV_SITE_2, $jeudiNbRdvSite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($jeudiNbRdvSite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::JEUDI_NB_RDV_SITE_2, $jeudiNbRdvSite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::JEUDI_NB_RDV_SITE_2, $jeudiNbRdvSite2, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_HEURE_DEBUT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediHeureDebut1('2011-03-14'); // WHERE VENDREDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByVendrediHeureDebut1('now'); // WHERE VENDREDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByVendrediHeureDebut1(array('max' => 'yesterday')); // WHERE VENDREDI_HEURE_DEBUT_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $vendrediHeureDebut1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediHeureDebut1($vendrediHeureDebut1 = null, $comparison = null)
    {
        if (is_array($vendrediHeureDebut1)) {
            $useMinMax = false;
            if (isset($vendrediHeureDebut1['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_DEBUT_1, $vendrediHeureDebut1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediHeureDebut1['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_DEBUT_1, $vendrediHeureDebut1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_DEBUT_1, $vendrediHeureDebut1, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_HEURE_FIN_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediHeureFin1('2011-03-14'); // WHERE VENDREDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByVendrediHeureFin1('now'); // WHERE VENDREDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByVendrediHeureFin1(array('max' => 'yesterday')); // WHERE VENDREDI_HEURE_FIN_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $vendrediHeureFin1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediHeureFin1($vendrediHeureFin1 = null, $comparison = null)
    {
        if (is_array($vendrediHeureFin1)) {
            $useMinMax = false;
            if (isset($vendrediHeureFin1['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_FIN_1, $vendrediHeureFin1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediHeureFin1['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_FIN_1, $vendrediHeureFin1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_FIN_1, $vendrediHeureFin1, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_CAPACITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediCapacite1(1234); // WHERE VENDREDI_CAPACITE_1 = 1234
     * $query->filterByVendrediCapacite1(array(12, 34)); // WHERE VENDREDI_CAPACITE_1 IN (12, 34)
     * $query->filterByVendrediCapacite1(array('min' => 12)); // WHERE VENDREDI_CAPACITE_1 >= 12
     * $query->filterByVendrediCapacite1(array('max' => 12)); // WHERE VENDREDI_CAPACITE_1 <= 12
     * </code>
     *
     * @param     mixed $vendrediCapacite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediCapacite1($vendrediCapacite1 = null, $comparison = null)
    {
        if (is_array($vendrediCapacite1)) {
            $useMinMax = false;
            if (isset($vendrediCapacite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_CAPACITE_1, $vendrediCapacite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediCapacite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_CAPACITE_1, $vendrediCapacite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_CAPACITE_1, $vendrediCapacite1, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_NB_RDV_SITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediNbRdvSite1(1234); // WHERE VENDREDI_NB_RDV_SITE_1 = 1234
     * $query->filterByVendrediNbRdvSite1(array(12, 34)); // WHERE VENDREDI_NB_RDV_SITE_1 IN (12, 34)
     * $query->filterByVendrediNbRdvSite1(array('min' => 12)); // WHERE VENDREDI_NB_RDV_SITE_1 >= 12
     * $query->filterByVendrediNbRdvSite1(array('max' => 12)); // WHERE VENDREDI_NB_RDV_SITE_1 <= 12
     * </code>
     *
     * @param     mixed $vendrediNbRdvSite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediNbRdvSite1($vendrediNbRdvSite1 = null, $comparison = null)
    {
        if (is_array($vendrediNbRdvSite1)) {
            $useMinMax = false;
            if (isset($vendrediNbRdvSite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_NB_RDV_SITE_1, $vendrediNbRdvSite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediNbRdvSite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_NB_RDV_SITE_1, $vendrediNbRdvSite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_NB_RDV_SITE_1, $vendrediNbRdvSite1, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_HEURE_DEBUT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediHeureDebut2('2011-03-14'); // WHERE VENDREDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByVendrediHeureDebut2('now'); // WHERE VENDREDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByVendrediHeureDebut2(array('max' => 'yesterday')); // WHERE VENDREDI_HEURE_DEBUT_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $vendrediHeureDebut2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediHeureDebut2($vendrediHeureDebut2 = null, $comparison = null)
    {
        if (is_array($vendrediHeureDebut2)) {
            $useMinMax = false;
            if (isset($vendrediHeureDebut2['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_DEBUT_2, $vendrediHeureDebut2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediHeureDebut2['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_DEBUT_2, $vendrediHeureDebut2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_DEBUT_2, $vendrediHeureDebut2, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_HEURE_FIN_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediHeureFin2('2011-03-14'); // WHERE VENDREDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByVendrediHeureFin2('now'); // WHERE VENDREDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByVendrediHeureFin2(array('max' => 'yesterday')); // WHERE VENDREDI_HEURE_FIN_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $vendrediHeureFin2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediHeureFin2($vendrediHeureFin2 = null, $comparison = null)
    {
        if (is_array($vendrediHeureFin2)) {
            $useMinMax = false;
            if (isset($vendrediHeureFin2['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_FIN_2, $vendrediHeureFin2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediHeureFin2['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_FIN_2, $vendrediHeureFin2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_HEURE_FIN_2, $vendrediHeureFin2, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_CAPACITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediCapacite2(1234); // WHERE VENDREDI_CAPACITE_2 = 1234
     * $query->filterByVendrediCapacite2(array(12, 34)); // WHERE VENDREDI_CAPACITE_2 IN (12, 34)
     * $query->filterByVendrediCapacite2(array('min' => 12)); // WHERE VENDREDI_CAPACITE_2 >= 12
     * $query->filterByVendrediCapacite2(array('max' => 12)); // WHERE VENDREDI_CAPACITE_2 <= 12
     * </code>
     *
     * @param     mixed $vendrediCapacite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediCapacite2($vendrediCapacite2 = null, $comparison = null)
    {
        if (is_array($vendrediCapacite2)) {
            $useMinMax = false;
            if (isset($vendrediCapacite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_CAPACITE_2, $vendrediCapacite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediCapacite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_CAPACITE_2, $vendrediCapacite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_CAPACITE_2, $vendrediCapacite2, $comparison);
    }

    /**
     * Filter the query on the VENDREDI_NB_RDV_SITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByVendrediNbRdvSite2(1234); // WHERE VENDREDI_NB_RDV_SITE_2 = 1234
     * $query->filterByVendrediNbRdvSite2(array(12, 34)); // WHERE VENDREDI_NB_RDV_SITE_2 IN (12, 34)
     * $query->filterByVendrediNbRdvSite2(array('min' => 12)); // WHERE VENDREDI_NB_RDV_SITE_2 >= 12
     * $query->filterByVendrediNbRdvSite2(array('max' => 12)); // WHERE VENDREDI_NB_RDV_SITE_2 <= 12
     * </code>
     *
     * @param     mixed $vendrediNbRdvSite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByVendrediNbRdvSite2($vendrediNbRdvSite2 = null, $comparison = null)
    {
        if (is_array($vendrediNbRdvSite2)) {
            $useMinMax = false;
            if (isset($vendrediNbRdvSite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_NB_RDV_SITE_2, $vendrediNbRdvSite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($vendrediNbRdvSite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::VENDREDI_NB_RDV_SITE_2, $vendrediNbRdvSite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::VENDREDI_NB_RDV_SITE_2, $vendrediNbRdvSite2, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_HEURE_DEBUT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediHeureDebut1('2011-03-14'); // WHERE SAMEDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterBySamediHeureDebut1('now'); // WHERE SAMEDI_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterBySamediHeureDebut1(array('max' => 'yesterday')); // WHERE SAMEDI_HEURE_DEBUT_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $samediHeureDebut1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediHeureDebut1($samediHeureDebut1 = null, $comparison = null)
    {
        if (is_array($samediHeureDebut1)) {
            $useMinMax = false;
            if (isset($samediHeureDebut1['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_DEBUT_1, $samediHeureDebut1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediHeureDebut1['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_DEBUT_1, $samediHeureDebut1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_DEBUT_1, $samediHeureDebut1, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_HEURE_FIN_1 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediHeureFin1('2011-03-14'); // WHERE SAMEDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterBySamediHeureFin1('now'); // WHERE SAMEDI_HEURE_FIN_1 = '2011-03-14'
     * $query->filterBySamediHeureFin1(array('max' => 'yesterday')); // WHERE SAMEDI_HEURE_FIN_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $samediHeureFin1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediHeureFin1($samediHeureFin1 = null, $comparison = null)
    {
        if (is_array($samediHeureFin1)) {
            $useMinMax = false;
            if (isset($samediHeureFin1['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_FIN_1, $samediHeureFin1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediHeureFin1['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_FIN_1, $samediHeureFin1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_FIN_1, $samediHeureFin1, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_CAPACITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediCapacite1(1234); // WHERE SAMEDI_CAPACITE_1 = 1234
     * $query->filterBySamediCapacite1(array(12, 34)); // WHERE SAMEDI_CAPACITE_1 IN (12, 34)
     * $query->filterBySamediCapacite1(array('min' => 12)); // WHERE SAMEDI_CAPACITE_1 >= 12
     * $query->filterBySamediCapacite1(array('max' => 12)); // WHERE SAMEDI_CAPACITE_1 <= 12
     * </code>
     *
     * @param     mixed $samediCapacite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediCapacite1($samediCapacite1 = null, $comparison = null)
    {
        if (is_array($samediCapacite1)) {
            $useMinMax = false;
            if (isset($samediCapacite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_CAPACITE_1, $samediCapacite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediCapacite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_CAPACITE_1, $samediCapacite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_CAPACITE_1, $samediCapacite1, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_NB_RDV_SITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediNbRdvSite1(1234); // WHERE SAMEDI_NB_RDV_SITE_1 = 1234
     * $query->filterBySamediNbRdvSite1(array(12, 34)); // WHERE SAMEDI_NB_RDV_SITE_1 IN (12, 34)
     * $query->filterBySamediNbRdvSite1(array('min' => 12)); // WHERE SAMEDI_NB_RDV_SITE_1 >= 12
     * $query->filterBySamediNbRdvSite1(array('max' => 12)); // WHERE SAMEDI_NB_RDV_SITE_1 <= 12
     * </code>
     *
     * @param     mixed $samediNbRdvSite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediNbRdvSite1($samediNbRdvSite1 = null, $comparison = null)
    {
        if (is_array($samediNbRdvSite1)) {
            $useMinMax = false;
            if (isset($samediNbRdvSite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_NB_RDV_SITE_1, $samediNbRdvSite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediNbRdvSite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_NB_RDV_SITE_1, $samediNbRdvSite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_NB_RDV_SITE_1, $samediNbRdvSite1, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_HEURE_DEBUT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediHeureDebut2('2011-03-14'); // WHERE SAMEDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterBySamediHeureDebut2('now'); // WHERE SAMEDI_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterBySamediHeureDebut2(array('max' => 'yesterday')); // WHERE SAMEDI_HEURE_DEBUT_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $samediHeureDebut2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediHeureDebut2($samediHeureDebut2 = null, $comparison = null)
    {
        if (is_array($samediHeureDebut2)) {
            $useMinMax = false;
            if (isset($samediHeureDebut2['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_DEBUT_2, $samediHeureDebut2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediHeureDebut2['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_DEBUT_2, $samediHeureDebut2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_DEBUT_2, $samediHeureDebut2, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_HEURE_FIN_2 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediHeureFin2('2011-03-14'); // WHERE SAMEDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterBySamediHeureFin2('now'); // WHERE SAMEDI_HEURE_FIN_2 = '2011-03-14'
     * $query->filterBySamediHeureFin2(array('max' => 'yesterday')); // WHERE SAMEDI_HEURE_FIN_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $samediHeureFin2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediHeureFin2($samediHeureFin2 = null, $comparison = null)
    {
        if (is_array($samediHeureFin2)) {
            $useMinMax = false;
            if (isset($samediHeureFin2['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_FIN_2, $samediHeureFin2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediHeureFin2['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_FIN_2, $samediHeureFin2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_HEURE_FIN_2, $samediHeureFin2, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_CAPACITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediCapacite2(1234); // WHERE SAMEDI_CAPACITE_2 = 1234
     * $query->filterBySamediCapacite2(array(12, 34)); // WHERE SAMEDI_CAPACITE_2 IN (12, 34)
     * $query->filterBySamediCapacite2(array('min' => 12)); // WHERE SAMEDI_CAPACITE_2 >= 12
     * $query->filterBySamediCapacite2(array('max' => 12)); // WHERE SAMEDI_CAPACITE_2 <= 12
     * </code>
     *
     * @param     mixed $samediCapacite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediCapacite2($samediCapacite2 = null, $comparison = null)
    {
        if (is_array($samediCapacite2)) {
            $useMinMax = false;
            if (isset($samediCapacite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_CAPACITE_2, $samediCapacite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediCapacite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_CAPACITE_2, $samediCapacite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_CAPACITE_2, $samediCapacite2, $comparison);
    }

    /**
     * Filter the query on the SAMEDI_NB_RDV_SITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterBySamediNbRdvSite2(1234); // WHERE SAMEDI_NB_RDV_SITE_2 = 1234
     * $query->filterBySamediNbRdvSite2(array(12, 34)); // WHERE SAMEDI_NB_RDV_SITE_2 IN (12, 34)
     * $query->filterBySamediNbRdvSite2(array('min' => 12)); // WHERE SAMEDI_NB_RDV_SITE_2 >= 12
     * $query->filterBySamediNbRdvSite2(array('max' => 12)); // WHERE SAMEDI_NB_RDV_SITE_2 <= 12
     * </code>
     *
     * @param     mixed $samediNbRdvSite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterBySamediNbRdvSite2($samediNbRdvSite2 = null, $comparison = null)
    {
        if (is_array($samediNbRdvSite2)) {
            $useMinMax = false;
            if (isset($samediNbRdvSite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_NB_RDV_SITE_2, $samediNbRdvSite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($samediNbRdvSite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::SAMEDI_NB_RDV_SITE_2, $samediNbRdvSite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::SAMEDI_NB_RDV_SITE_2, $samediNbRdvSite2, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_HEURE_DEBUT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheHeureDebut1('2011-03-14'); // WHERE DIMANCHE_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByDimancheHeureDebut1('now'); // WHERE DIMANCHE_HEURE_DEBUT_1 = '2011-03-14'
     * $query->filterByDimancheHeureDebut1(array('max' => 'yesterday')); // WHERE DIMANCHE_HEURE_DEBUT_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $dimancheHeureDebut1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheHeureDebut1($dimancheHeureDebut1 = null, $comparison = null)
    {
        if (is_array($dimancheHeureDebut1)) {
            $useMinMax = false;
            if (isset($dimancheHeureDebut1['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_DEBUT_1, $dimancheHeureDebut1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheHeureDebut1['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_DEBUT_1, $dimancheHeureDebut1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_DEBUT_1, $dimancheHeureDebut1, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_HEURE_FIN_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheHeureFin1('2011-03-14'); // WHERE DIMANCHE_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByDimancheHeureFin1('now'); // WHERE DIMANCHE_HEURE_FIN_1 = '2011-03-14'
     * $query->filterByDimancheHeureFin1(array('max' => 'yesterday')); // WHERE DIMANCHE_HEURE_FIN_1 > '2011-03-13'
     * </code>
     *
     * @param     mixed $dimancheHeureFin1 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheHeureFin1($dimancheHeureFin1 = null, $comparison = null)
    {
        if (is_array($dimancheHeureFin1)) {
            $useMinMax = false;
            if (isset($dimancheHeureFin1['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_FIN_1, $dimancheHeureFin1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheHeureFin1['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_FIN_1, $dimancheHeureFin1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_FIN_1, $dimancheHeureFin1, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_CAPACITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheCapacite1(1234); // WHERE DIMANCHE_CAPACITE_1 = 1234
     * $query->filterByDimancheCapacite1(array(12, 34)); // WHERE DIMANCHE_CAPACITE_1 IN (12, 34)
     * $query->filterByDimancheCapacite1(array('min' => 12)); // WHERE DIMANCHE_CAPACITE_1 >= 12
     * $query->filterByDimancheCapacite1(array('max' => 12)); // WHERE DIMANCHE_CAPACITE_1 <= 12
     * </code>
     *
     * @param     mixed $dimancheCapacite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheCapacite1($dimancheCapacite1 = null, $comparison = null)
    {
        if (is_array($dimancheCapacite1)) {
            $useMinMax = false;
            if (isset($dimancheCapacite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_CAPACITE_1, $dimancheCapacite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheCapacite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_CAPACITE_1, $dimancheCapacite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_CAPACITE_1, $dimancheCapacite1, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_NB_RDV_SITE_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheNbRdvSite1(1234); // WHERE DIMANCHE_NB_RDV_SITE_1 = 1234
     * $query->filterByDimancheNbRdvSite1(array(12, 34)); // WHERE DIMANCHE_NB_RDV_SITE_1 IN (12, 34)
     * $query->filterByDimancheNbRdvSite1(array('min' => 12)); // WHERE DIMANCHE_NB_RDV_SITE_1 >= 12
     * $query->filterByDimancheNbRdvSite1(array('max' => 12)); // WHERE DIMANCHE_NB_RDV_SITE_1 <= 12
     * </code>
     *
     * @param     mixed $dimancheNbRdvSite1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheNbRdvSite1($dimancheNbRdvSite1 = null, $comparison = null)
    {
        if (is_array($dimancheNbRdvSite1)) {
            $useMinMax = false;
            if (isset($dimancheNbRdvSite1['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_NB_RDV_SITE_1, $dimancheNbRdvSite1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheNbRdvSite1['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_NB_RDV_SITE_1, $dimancheNbRdvSite1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_NB_RDV_SITE_1, $dimancheNbRdvSite1, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_HEURE_DEBUT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheHeureDebut2('2011-03-14'); // WHERE DIMANCHE_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByDimancheHeureDebut2('now'); // WHERE DIMANCHE_HEURE_DEBUT_2 = '2011-03-14'
     * $query->filterByDimancheHeureDebut2(array('max' => 'yesterday')); // WHERE DIMANCHE_HEURE_DEBUT_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $dimancheHeureDebut2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheHeureDebut2($dimancheHeureDebut2 = null, $comparison = null)
    {
        if (is_array($dimancheHeureDebut2)) {
            $useMinMax = false;
            if (isset($dimancheHeureDebut2['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_DEBUT_2, $dimancheHeureDebut2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheHeureDebut2['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_DEBUT_2, $dimancheHeureDebut2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_DEBUT_2, $dimancheHeureDebut2, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_HEURE_FIN_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheHeureFin2('2011-03-14'); // WHERE DIMANCHE_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByDimancheHeureFin2('now'); // WHERE DIMANCHE_HEURE_FIN_2 = '2011-03-14'
     * $query->filterByDimancheHeureFin2(array('max' => 'yesterday')); // WHERE DIMANCHE_HEURE_FIN_2 > '2011-03-13'
     * </code>
     *
     * @param     mixed $dimancheHeureFin2 The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheHeureFin2($dimancheHeureFin2 = null, $comparison = null)
    {
        if (is_array($dimancheHeureFin2)) {
            $useMinMax = false;
            if (isset($dimancheHeureFin2['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_FIN_2, $dimancheHeureFin2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheHeureFin2['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_FIN_2, $dimancheHeureFin2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_HEURE_FIN_2, $dimancheHeureFin2, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_CAPACITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheCapacite2(1234); // WHERE DIMANCHE_CAPACITE_2 = 1234
     * $query->filterByDimancheCapacite2(array(12, 34)); // WHERE DIMANCHE_CAPACITE_2 IN (12, 34)
     * $query->filterByDimancheCapacite2(array('min' => 12)); // WHERE DIMANCHE_CAPACITE_2 >= 12
     * $query->filterByDimancheCapacite2(array('max' => 12)); // WHERE DIMANCHE_CAPACITE_2 <= 12
     * </code>
     *
     * @param     mixed $dimancheCapacite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheCapacite2($dimancheCapacite2 = null, $comparison = null)
    {
        if (is_array($dimancheCapacite2)) {
            $useMinMax = false;
            if (isset($dimancheCapacite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_CAPACITE_2, $dimancheCapacite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheCapacite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_CAPACITE_2, $dimancheCapacite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_CAPACITE_2, $dimancheCapacite2, $comparison);
    }

    /**
     * Filter the query on the DIMANCHE_NB_RDV_SITE_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByDimancheNbRdvSite2(1234); // WHERE DIMANCHE_NB_RDV_SITE_2 = 1234
     * $query->filterByDimancheNbRdvSite2(array(12, 34)); // WHERE DIMANCHE_NB_RDV_SITE_2 IN (12, 34)
     * $query->filterByDimancheNbRdvSite2(array('min' => 12)); // WHERE DIMANCHE_NB_RDV_SITE_2 >= 12
     * $query->filterByDimancheNbRdvSite2(array('max' => 12)); // WHERE DIMANCHE_NB_RDV_SITE_2 <= 12
     * </code>
     *
     * @param     mixed $dimancheNbRdvSite2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByDimancheNbRdvSite2($dimancheNbRdvSite2 = null, $comparison = null)
    {
        if (is_array($dimancheNbRdvSite2)) {
            $useMinMax = false;
            if (isset($dimancheNbRdvSite2['min'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_NB_RDV_SITE_2, $dimancheNbRdvSite2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dimancheNbRdvSite2['max'])) {
                $this->addUsingAlias(TPeriodePeer::DIMANCHE_NB_RDV_SITE_2, $dimancheNbRdvSite2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::DIMANCHE_NB_RDV_SITE_2, $dimancheNbRdvSite2, $comparison);
    }

    /**
     * Filter the query on the ID_AGENDA column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgenda(1234); // WHERE ID_AGENDA = 1234
     * $query->filterByIdAgenda(array(12, 34)); // WHERE ID_AGENDA IN (12, 34)
     * $query->filterByIdAgenda(array('min' => 12)); // WHERE ID_AGENDA >= 12
     * $query->filterByIdAgenda(array('max' => 12)); // WHERE ID_AGENDA <= 12
     * </code>
     *
     * @see       filterByTAgenda()
     *
     * @param     mixed $idAgenda The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByIdAgenda($idAgenda = null, $comparison = null)
    {
        if (is_array($idAgenda)) {
            $useMinMax = false;
            if (isset($idAgenda['min'])) {
                $this->addUsingAlias(TPeriodePeer::ID_AGENDA, $idAgenda['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgenda['max'])) {
                $this->addUsingAlias(TPeriodePeer::ID_AGENDA, $idAgenda['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::ID_AGENDA, $idAgenda, $comparison);
    }

    /**
     * Filter the query on the PERIODICITE column
     *
     * Example usage:
     * <code>
     * $query->filterByPeriodicite(1234); // WHERE PERIODICITE = 1234
     * $query->filterByPeriodicite(array(12, 34)); // WHERE PERIODICITE IN (12, 34)
     * $query->filterByPeriodicite(array('min' => 12)); // WHERE PERIODICITE >= 12
     * $query->filterByPeriodicite(array('max' => 12)); // WHERE PERIODICITE <= 12
     * </code>
     *
     * @param     mixed $periodicite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function filterByPeriodicite($periodicite = null, $comparison = null)
    {
        if (is_array($periodicite)) {
            $useMinMax = false;
            if (isset($periodicite['min'])) {
                $this->addUsingAlias(TPeriodePeer::PERIODICITE, $periodicite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($periodicite['max'])) {
                $this->addUsingAlias(TPeriodePeer::PERIODICITE, $periodicite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPeriodePeer::PERIODICITE, $periodicite, $comparison);
    }

    /**
     * Filter the query by a related TAgenda object
     *
     * @param   TAgenda|PropelObjectCollection $tAgenda The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPeriodeQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgenda($tAgenda, $comparison = null)
    {
        if ($tAgenda instanceof TAgenda) {
            return $this
                ->addUsingAlias(TPeriodePeer::ID_AGENDA, $tAgenda->getIdAgenda(), $comparison);
        } elseif ($tAgenda instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPeriodePeer::ID_AGENDA, $tAgenda->toKeyValue('PrimaryKey', 'IdAgenda'), $comparison);
        } else {
            throw new PropelException('filterByTAgenda() only accepts arguments of type TAgenda or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgenda relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function joinTAgenda($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgenda');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgenda');
        }

        return $this;
    }

    /**
     * Use the TAgenda relation TAgenda object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgendaQuery A secondary query class using the current class as primary query
     */
    public function useTAgendaQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTAgenda($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgenda', 'TAgendaQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TPeriode $tPeriode Object to remove from the list of results
     *
     * @return TPeriodeQuery The current query, for fluid interface
     */
    public function prune($tPeriode = null)
    {
        if ($tPeriode) {
            $this->addUsingAlias(TPeriodePeer::ID_PERIODE, $tPeriode->getIdPeriode(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
