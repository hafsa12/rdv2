<?php


/**
 * Base class that represents a query for the 'T_CITOYEN' table.
 *
 *
 *
 * @method TCitoyenQuery orderByIdCitoyen($order = Criteria::ASC) Order by the ID_CITOYEN column
 * @method TCitoyenQuery orderByRaisonSocial($order = Criteria::ASC) Order by the RAISON_SOCIAL column
 * @method TCitoyenQuery orderByNom($order = Criteria::ASC) Order by the NOM column
 * @method TCitoyenQuery orderByPrenom($order = Criteria::ASC) Order by the PRENOM column
 * @method TCitoyenQuery orderByDateNaissance($order = Criteria::ASC) Order by the DATE_NAISSANCE column
 * @method TCitoyenQuery orderByIdentifiant($order = Criteria::ASC) Order by the IDENTIFIANT column
 * @method TCitoyenQuery orderByAdresse($order = Criteria::ASC) Order by the ADRESSE column
 * @method TCitoyenQuery orderByMail($order = Criteria::ASC) Order by the MAIL column
 * @method TCitoyenQuery orderByTelephone($order = Criteria::ASC) Order by the TELEPHONE column
 * @method TCitoyenQuery orderByFax($order = Criteria::ASC) Order by the FAX column
 * @method TCitoyenQuery orderByText1($order = Criteria::ASC) Order by the TEXT_1 column
 * @method TCitoyenQuery orderByIdRef1($order = Criteria::ASC) Order by the ID_REF_1 column
 * @method TCitoyenQuery orderByText2($order = Criteria::ASC) Order by the TEXT_2 column
 * @method TCitoyenQuery orderByIdRef2($order = Criteria::ASC) Order by the ID_REF_2 column
 * @method TCitoyenQuery orderByText3($order = Criteria::ASC) Order by the TEXT_3 column
 * @method TCitoyenQuery orderByIdRef3($order = Criteria::ASC) Order by the ID_REF_3 column
 *
 * @method TCitoyenQuery groupByIdCitoyen() Group by the ID_CITOYEN column
 * @method TCitoyenQuery groupByRaisonSocial() Group by the RAISON_SOCIAL column
 * @method TCitoyenQuery groupByNom() Group by the NOM column
 * @method TCitoyenQuery groupByPrenom() Group by the PRENOM column
 * @method TCitoyenQuery groupByDateNaissance() Group by the DATE_NAISSANCE column
 * @method TCitoyenQuery groupByIdentifiant() Group by the IDENTIFIANT column
 * @method TCitoyenQuery groupByAdresse() Group by the ADRESSE column
 * @method TCitoyenQuery groupByMail() Group by the MAIL column
 * @method TCitoyenQuery groupByTelephone() Group by the TELEPHONE column
 * @method TCitoyenQuery groupByFax() Group by the FAX column
 * @method TCitoyenQuery groupByText1() Group by the TEXT_1 column
 * @method TCitoyenQuery groupByIdRef1() Group by the ID_REF_1 column
 * @method TCitoyenQuery groupByText2() Group by the TEXT_2 column
 * @method TCitoyenQuery groupByIdRef2() Group by the ID_REF_2 column
 * @method TCitoyenQuery groupByText3() Group by the TEXT_3 column
 * @method TCitoyenQuery groupByIdRef3() Group by the ID_REF_3 column
 *
 * @method TCitoyenQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TCitoyenQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TCitoyenQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TCitoyenQuery leftJoinTValeurReferentielRelatedByIdRef1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TValeurReferentielRelatedByIdRef1 relation
 * @method TCitoyenQuery rightJoinTValeurReferentielRelatedByIdRef1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TValeurReferentielRelatedByIdRef1 relation
 * @method TCitoyenQuery innerJoinTValeurReferentielRelatedByIdRef1($relationAlias = null) Adds a INNER JOIN clause to the query using the TValeurReferentielRelatedByIdRef1 relation
 *
 * @method TCitoyenQuery leftJoinTValeurReferentielRelatedByIdRef2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TValeurReferentielRelatedByIdRef2 relation
 * @method TCitoyenQuery rightJoinTValeurReferentielRelatedByIdRef2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TValeurReferentielRelatedByIdRef2 relation
 * @method TCitoyenQuery innerJoinTValeurReferentielRelatedByIdRef2($relationAlias = null) Adds a INNER JOIN clause to the query using the TValeurReferentielRelatedByIdRef2 relation
 *
 * @method TCitoyenQuery leftJoinTValeurReferentielRelatedByIdRef3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TValeurReferentielRelatedByIdRef3 relation
 * @method TCitoyenQuery rightJoinTValeurReferentielRelatedByIdRef3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TValeurReferentielRelatedByIdRef3 relation
 * @method TCitoyenQuery innerJoinTValeurReferentielRelatedByIdRef3($relationAlias = null) Adds a INNER JOIN clause to the query using the TValeurReferentielRelatedByIdRef3 relation
 *
 * @method TCitoyenQuery leftJoinTRendezVous($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVous relation
 * @method TCitoyenQuery rightJoinTRendezVous($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVous relation
 * @method TCitoyenQuery innerJoinTRendezVous($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVous relation
 *
 * @method TCitoyen findOne(PropelPDO $con = null) Return the first TCitoyen matching the query
 * @method TCitoyen findOneOrCreate(PropelPDO $con = null) Return the first TCitoyen matching the query, or a new TCitoyen object populated from the query conditions when no match is found
 *
 * @method TCitoyen findOneByRaisonSocial(string $RAISON_SOCIAL) Return the first TCitoyen filtered by the RAISON_SOCIAL column
 * @method TCitoyen findOneByNom(string $NOM) Return the first TCitoyen filtered by the NOM column
 * @method TCitoyen findOneByPrenom(string $PRENOM) Return the first TCitoyen filtered by the PRENOM column
 * @method TCitoyen findOneByDateNaissance(string $DATE_NAISSANCE) Return the first TCitoyen filtered by the DATE_NAISSANCE column
 * @method TCitoyen findOneByIdentifiant(string $IDENTIFIANT) Return the first TCitoyen filtered by the IDENTIFIANT column
 * @method TCitoyen findOneByAdresse(string $ADRESSE) Return the first TCitoyen filtered by the ADRESSE column
 * @method TCitoyen findOneByMail(string $MAIL) Return the first TCitoyen filtered by the MAIL column
 * @method TCitoyen findOneByTelephone(string $TELEPHONE) Return the first TCitoyen filtered by the TELEPHONE column
 * @method TCitoyen findOneByFax(string $FAX) Return the first TCitoyen filtered by the FAX column
 * @method TCitoyen findOneByText1(string $TEXT_1) Return the first TCitoyen filtered by the TEXT_1 column
 * @method TCitoyen findOneByIdRef1(int $ID_REF_1) Return the first TCitoyen filtered by the ID_REF_1 column
 * @method TCitoyen findOneByText2(string $TEXT_2) Return the first TCitoyen filtered by the TEXT_2 column
 * @method TCitoyen findOneByIdRef2(int $ID_REF_2) Return the first TCitoyen filtered by the ID_REF_2 column
 * @method TCitoyen findOneByText3(string $TEXT_3) Return the first TCitoyen filtered by the TEXT_3 column
 * @method TCitoyen findOneByIdRef3(int $ID_REF_3) Return the first TCitoyen filtered by the ID_REF_3 column
 *
 * @method array findByIdCitoyen(int $ID_CITOYEN) Return TCitoyen objects filtered by the ID_CITOYEN column
 * @method array findByRaisonSocial(string $RAISON_SOCIAL) Return TCitoyen objects filtered by the RAISON_SOCIAL column
 * @method array findByNom(string $NOM) Return TCitoyen objects filtered by the NOM column
 * @method array findByPrenom(string $PRENOM) Return TCitoyen objects filtered by the PRENOM column
 * @method array findByDateNaissance(string $DATE_NAISSANCE) Return TCitoyen objects filtered by the DATE_NAISSANCE column
 * @method array findByIdentifiant(string $IDENTIFIANT) Return TCitoyen objects filtered by the IDENTIFIANT column
 * @method array findByAdresse(string $ADRESSE) Return TCitoyen objects filtered by the ADRESSE column
 * @method array findByMail(string $MAIL) Return TCitoyen objects filtered by the MAIL column
 * @method array findByTelephone(string $TELEPHONE) Return TCitoyen objects filtered by the TELEPHONE column
 * @method array findByFax(string $FAX) Return TCitoyen objects filtered by the FAX column
 * @method array findByText1(string $TEXT_1) Return TCitoyen objects filtered by the TEXT_1 column
 * @method array findByIdRef1(int $ID_REF_1) Return TCitoyen objects filtered by the ID_REF_1 column
 * @method array findByText2(string $TEXT_2) Return TCitoyen objects filtered by the TEXT_2 column
 * @method array findByIdRef2(int $ID_REF_2) Return TCitoyen objects filtered by the ID_REF_2 column
 * @method array findByText3(string $TEXT_3) Return TCitoyen objects filtered by the TEXT_3 column
 * @method array findByIdRef3(int $ID_REF_3) Return TCitoyen objects filtered by the ID_REF_3 column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTCitoyenQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTCitoyenQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TCitoyen', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TCitoyenQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TCitoyenQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TCitoyenQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TCitoyenQuery) {
            return $criteria;
        }
        $query = new TCitoyenQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TCitoyen|TCitoyen[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TCitoyenPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TCitoyen A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdCitoyen($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TCitoyen A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_CITOYEN`, `RAISON_SOCIAL`, `NOM`, `PRENOM`, `DATE_NAISSANCE`, `IDENTIFIANT`, `ADRESSE`, `MAIL`, `TELEPHONE`, `FAX`, `TEXT_1`, `ID_REF_1`, `TEXT_2`, `ID_REF_2`, `TEXT_3`, `ID_REF_3` FROM `T_CITOYEN` WHERE `ID_CITOYEN` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TCitoyen();
            $obj->hydrate($row);
            TCitoyenPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TCitoyen|TCitoyen[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TCitoyen[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TCitoyenPeer::ID_CITOYEN, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TCitoyenPeer::ID_CITOYEN, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_CITOYEN column
     *
     * Example usage:
     * <code>
     * $query->filterByIdCitoyen(1234); // WHERE ID_CITOYEN = 1234
     * $query->filterByIdCitoyen(array(12, 34)); // WHERE ID_CITOYEN IN (12, 34)
     * $query->filterByIdCitoyen(array('min' => 12)); // WHERE ID_CITOYEN >= 12
     * $query->filterByIdCitoyen(array('max' => 12)); // WHERE ID_CITOYEN <= 12
     * </code>
     *
     * @param     mixed $idCitoyen The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByIdCitoyen($idCitoyen = null, $comparison = null)
    {
        if (is_array($idCitoyen)) {
            $useMinMax = false;
            if (isset($idCitoyen['min'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_CITOYEN, $idCitoyen['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idCitoyen['max'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_CITOYEN, $idCitoyen['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::ID_CITOYEN, $idCitoyen, $comparison);
    }

    /**
     * Filter the query on the RAISON_SOCIAL column
     *
     * Example usage:
     * <code>
     * $query->filterByRaisonSocial('fooValue');   // WHERE RAISON_SOCIAL = 'fooValue'
     * $query->filterByRaisonSocial('%fooValue%'); // WHERE RAISON_SOCIAL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $raisonSocial The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByRaisonSocial($raisonSocial = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($raisonSocial)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $raisonSocial)) {
                $raisonSocial = str_replace('*', '%', $raisonSocial);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::RAISON_SOCIAL, $raisonSocial, $comparison);
    }

    /**
     * Filter the query on the NOM column
     *
     * Example usage:
     * <code>
     * $query->filterByNom('fooValue');   // WHERE NOM = 'fooValue'
     * $query->filterByNom('%fooValue%'); // WHERE NOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $nom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByNom($nom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($nom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $nom)) {
                $nom = str_replace('*', '%', $nom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::NOM, $nom, $comparison);
    }

    /**
     * Filter the query on the PRENOM column
     *
     * Example usage:
     * <code>
     * $query->filterByPrenom('fooValue');   // WHERE PRENOM = 'fooValue'
     * $query->filterByPrenom('%fooValue%'); // WHERE PRENOM LIKE '%fooValue%'
     * </code>
     *
     * @param     string $prenom The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByPrenom($prenom = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($prenom)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $prenom)) {
                $prenom = str_replace('*', '%', $prenom);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::PRENOM, $prenom, $comparison);
    }

    /**
     * Filter the query on the DATE_NAISSANCE column
     *
     * Example usage:
     * <code>
     * $query->filterByDateNaissance('2011-03-14'); // WHERE DATE_NAISSANCE = '2011-03-14'
     * $query->filterByDateNaissance('now'); // WHERE DATE_NAISSANCE = '2011-03-14'
     * $query->filterByDateNaissance(array('max' => 'yesterday')); // WHERE DATE_NAISSANCE > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateNaissance The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByDateNaissance($dateNaissance = null, $comparison = null)
    {
        if (is_array($dateNaissance)) {
            $useMinMax = false;
            if (isset($dateNaissance['min'])) {
                $this->addUsingAlias(TCitoyenPeer::DATE_NAISSANCE, $dateNaissance['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateNaissance['max'])) {
                $this->addUsingAlias(TCitoyenPeer::DATE_NAISSANCE, $dateNaissance['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::DATE_NAISSANCE, $dateNaissance, $comparison);
    }

    /**
     * Filter the query on the IDENTIFIANT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdentifiant('fooValue');   // WHERE IDENTIFIANT = 'fooValue'
     * $query->filterByIdentifiant('%fooValue%'); // WHERE IDENTIFIANT LIKE '%fooValue%'
     * </code>
     *
     * @param     string $identifiant The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByIdentifiant($identifiant = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($identifiant)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $identifiant)) {
                $identifiant = str_replace('*', '%', $identifiant);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::IDENTIFIANT, $identifiant, $comparison);
    }

    /**
     * Filter the query on the ADRESSE column
     *
     * Example usage:
     * <code>
     * $query->filterByAdresse('fooValue');   // WHERE ADRESSE = 'fooValue'
     * $query->filterByAdresse('%fooValue%'); // WHERE ADRESSE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $adresse The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByAdresse($adresse = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($adresse)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $adresse)) {
                $adresse = str_replace('*', '%', $adresse);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::ADRESSE, $adresse, $comparison);
    }

    /**
     * Filter the query on the MAIL column
     *
     * Example usage:
     * <code>
     * $query->filterByMail('fooValue');   // WHERE MAIL = 'fooValue'
     * $query->filterByMail('%fooValue%'); // WHERE MAIL LIKE '%fooValue%'
     * </code>
     *
     * @param     string $mail The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByMail($mail = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($mail)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $mail)) {
                $mail = str_replace('*', '%', $mail);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::MAIL, $mail, $comparison);
    }

    /**
     * Filter the query on the TELEPHONE column
     *
     * Example usage:
     * <code>
     * $query->filterByTelephone('fooValue');   // WHERE TELEPHONE = 'fooValue'
     * $query->filterByTelephone('%fooValue%'); // WHERE TELEPHONE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $telephone The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByTelephone($telephone = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($telephone)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $telephone)) {
                $telephone = str_replace('*', '%', $telephone);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::TELEPHONE, $telephone, $comparison);
    }

    /**
     * Filter the query on the FAX column
     *
     * Example usage:
     * <code>
     * $query->filterByFax('fooValue');   // WHERE FAX = 'fooValue'
     * $query->filterByFax('%fooValue%'); // WHERE FAX LIKE '%fooValue%'
     * </code>
     *
     * @param     string $fax The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByFax($fax = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($fax)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $fax)) {
                $fax = str_replace('*', '%', $fax);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::FAX, $fax, $comparison);
    }

    /**
     * Filter the query on the TEXT_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByText1('fooValue');   // WHERE TEXT_1 = 'fooValue'
     * $query->filterByText1('%fooValue%'); // WHERE TEXT_1 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text1 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByText1($text1 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text1)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text1)) {
                $text1 = str_replace('*', '%', $text1);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::TEXT_1, $text1, $comparison);
    }

    /**
     * Filter the query on the ID_REF_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRef1(1234); // WHERE ID_REF_1 = 1234
     * $query->filterByIdRef1(array(12, 34)); // WHERE ID_REF_1 IN (12, 34)
     * $query->filterByIdRef1(array('min' => 12)); // WHERE ID_REF_1 >= 12
     * $query->filterByIdRef1(array('max' => 12)); // WHERE ID_REF_1 <= 12
     * </code>
     *
     * @see       filterByTValeurReferentielRelatedByIdRef1()
     *
     * @param     mixed $idRef1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByIdRef1($idRef1 = null, $comparison = null)
    {
        if (is_array($idRef1)) {
            $useMinMax = false;
            if (isset($idRef1['min'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_REF_1, $idRef1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRef1['max'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_REF_1, $idRef1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::ID_REF_1, $idRef1, $comparison);
    }

    /**
     * Filter the query on the TEXT_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByText2('fooValue');   // WHERE TEXT_2 = 'fooValue'
     * $query->filterByText2('%fooValue%'); // WHERE TEXT_2 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text2 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByText2($text2 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text2)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text2)) {
                $text2 = str_replace('*', '%', $text2);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::TEXT_2, $text2, $comparison);
    }

    /**
     * Filter the query on the ID_REF_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRef2(1234); // WHERE ID_REF_2 = 1234
     * $query->filterByIdRef2(array(12, 34)); // WHERE ID_REF_2 IN (12, 34)
     * $query->filterByIdRef2(array('min' => 12)); // WHERE ID_REF_2 >= 12
     * $query->filterByIdRef2(array('max' => 12)); // WHERE ID_REF_2 <= 12
     * </code>
     *
     * @see       filterByTValeurReferentielRelatedByIdRef2()
     *
     * @param     mixed $idRef2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByIdRef2($idRef2 = null, $comparison = null)
    {
        if (is_array($idRef2)) {
            $useMinMax = false;
            if (isset($idRef2['min'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_REF_2, $idRef2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRef2['max'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_REF_2, $idRef2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::ID_REF_2, $idRef2, $comparison);
    }

    /**
     * Filter the query on the TEXT_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByText3('fooValue');   // WHERE TEXT_3 = 'fooValue'
     * $query->filterByText3('%fooValue%'); // WHERE TEXT_3 LIKE '%fooValue%'
     * </code>
     *
     * @param     string $text3 The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByText3($text3 = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($text3)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $text3)) {
                $text3 = str_replace('*', '%', $text3);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::TEXT_3, $text3, $comparison);
    }

    /**
     * Filter the query on the ID_REF_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRef3(1234); // WHERE ID_REF_3 = 1234
     * $query->filterByIdRef3(array(12, 34)); // WHERE ID_REF_3 IN (12, 34)
     * $query->filterByIdRef3(array('min' => 12)); // WHERE ID_REF_3 >= 12
     * $query->filterByIdRef3(array('max' => 12)); // WHERE ID_REF_3 <= 12
     * </code>
     *
     * @see       filterByTValeurReferentielRelatedByIdRef3()
     *
     * @param     mixed $idRef3 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function filterByIdRef3($idRef3 = null, $comparison = null)
    {
        if (is_array($idRef3)) {
            $useMinMax = false;
            if (isset($idRef3['min'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_REF_3, $idRef3['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRef3['max'])) {
                $this->addUsingAlias(TCitoyenPeer::ID_REF_3, $idRef3['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TCitoyenPeer::ID_REF_3, $idRef3, $comparison);
    }

    /**
     * Filter the query by a related TValeurReferentiel object
     *
     * @param   TValeurReferentiel|PropelObjectCollection $tValeurReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TCitoyenQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTValeurReferentielRelatedByIdRef1($tValeurReferentiel, $comparison = null)
    {
        if ($tValeurReferentiel instanceof TValeurReferentiel) {
            return $this
                ->addUsingAlias(TCitoyenPeer::ID_REF_1, $tValeurReferentiel->getIdValeurReferentiel(), $comparison);
        } elseif ($tValeurReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TCitoyenPeer::ID_REF_1, $tValeurReferentiel->toKeyValue('PrimaryKey', 'IdValeurReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTValeurReferentielRelatedByIdRef1() only accepts arguments of type TValeurReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TValeurReferentielRelatedByIdRef1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function joinTValeurReferentielRelatedByIdRef1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TValeurReferentielRelatedByIdRef1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TValeurReferentielRelatedByIdRef1');
        }

        return $this;
    }

    /**
     * Use the TValeurReferentielRelatedByIdRef1 relation TValeurReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TValeurReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTValeurReferentielRelatedByIdRef1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTValeurReferentielRelatedByIdRef1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TValeurReferentielRelatedByIdRef1', 'TValeurReferentielQuery');
    }

    /**
     * Filter the query by a related TValeurReferentiel object
     *
     * @param   TValeurReferentiel|PropelObjectCollection $tValeurReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TCitoyenQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTValeurReferentielRelatedByIdRef2($tValeurReferentiel, $comparison = null)
    {
        if ($tValeurReferentiel instanceof TValeurReferentiel) {
            return $this
                ->addUsingAlias(TCitoyenPeer::ID_REF_2, $tValeurReferentiel->getIdValeurReferentiel(), $comparison);
        } elseif ($tValeurReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TCitoyenPeer::ID_REF_2, $tValeurReferentiel->toKeyValue('PrimaryKey', 'IdValeurReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTValeurReferentielRelatedByIdRef2() only accepts arguments of type TValeurReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TValeurReferentielRelatedByIdRef2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function joinTValeurReferentielRelatedByIdRef2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TValeurReferentielRelatedByIdRef2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TValeurReferentielRelatedByIdRef2');
        }

        return $this;
    }

    /**
     * Use the TValeurReferentielRelatedByIdRef2 relation TValeurReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TValeurReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTValeurReferentielRelatedByIdRef2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTValeurReferentielRelatedByIdRef2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TValeurReferentielRelatedByIdRef2', 'TValeurReferentielQuery');
    }

    /**
     * Filter the query by a related TValeurReferentiel object
     *
     * @param   TValeurReferentiel|PropelObjectCollection $tValeurReferentiel The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TCitoyenQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTValeurReferentielRelatedByIdRef3($tValeurReferentiel, $comparison = null)
    {
        if ($tValeurReferentiel instanceof TValeurReferentiel) {
            return $this
                ->addUsingAlias(TCitoyenPeer::ID_REF_3, $tValeurReferentiel->getIdValeurReferentiel(), $comparison);
        } elseif ($tValeurReferentiel instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TCitoyenPeer::ID_REF_3, $tValeurReferentiel->toKeyValue('PrimaryKey', 'IdValeurReferentiel'), $comparison);
        } else {
            throw new PropelException('filterByTValeurReferentielRelatedByIdRef3() only accepts arguments of type TValeurReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TValeurReferentielRelatedByIdRef3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function joinTValeurReferentielRelatedByIdRef3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TValeurReferentielRelatedByIdRef3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TValeurReferentielRelatedByIdRef3');
        }

        return $this;
    }

    /**
     * Use the TValeurReferentielRelatedByIdRef3 relation TValeurReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TValeurReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTValeurReferentielRelatedByIdRef3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTValeurReferentielRelatedByIdRef3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TValeurReferentielRelatedByIdRef3', 'TValeurReferentielQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TCitoyenQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVous($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TCitoyenPeer::ID_CITOYEN, $tRendezVous->getIdCitoyen(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVous() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVous relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function joinTRendezVous($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVous');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVous');
        }

        return $this;
    }

    /**
     * Use the TRendezVous relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRendezVous($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVous', 'TRendezVousQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TCitoyen $tCitoyen Object to remove from the list of results
     *
     * @return TCitoyenQuery The current query, for fluid interface
     */
    public function prune($tCitoyen = null)
    {
        if ($tCitoyen) {
            $this->addUsingAlias(TCitoyenPeer::ID_CITOYEN, $tCitoyen->getIdCitoyen(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
