<?php


/**
 * Base class that represents a row from the 'T_REF_TYPE_PRESTATION' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTRefTypePrestation extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TRefTypePrestationPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TRefTypePrestationPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_ref_type_prestation field.
     * @var        int
     */
    protected $id_ref_type_prestation;

    /**
     * The value for the id_organisation field.
     * @var        int
     */
    protected $id_organisation;

    /**
     * The value for the code_libelle field.
     * @var        int
     */
    protected $code_libelle;

    /**
     * The value for the id_groupe field.
     * @var        int
     */
    protected $id_groupe;

    /**
     * @var        TGroupe
     */
    protected $aTGroupe;

    /**
     * @var        TTraduction
     */
    protected $aTTraduction;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisation;

    /**
     * @var        PropelObjectCollection|TParametragePrestation[] Collection to store aggregation of TParametragePrestation objects.
     */
    protected $collTParametragePrestations;
    protected $collTParametragePrestationsPartial;

    /**
     * @var        PropelObjectCollection|TTypePrestation[] Collection to store aggregation of TTypePrestation objects.
     */
    protected $collTTypePrestations;
    protected $collTTypePrestationsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametragePrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tTypePrestationsScheduledForDeletion = null;

    /**
     * Get the [id_ref_type_prestation] column value.
     *
     * @return int
     */
    public function getIdRefTypePrestation()
    {
        return $this->id_ref_type_prestation;
    }

    /**
     * Get the [id_organisation] column value.
     *
     * @return int
     */
    public function getIdOrganisation()
    {
        return $this->id_organisation;
    }

    /**
     * Get the [code_libelle] column value.
     *
     * @return int
     */
    public function getCodeLibelle()
    {
        return $this->code_libelle;
    }

    /**
     * Get the [id_groupe] column value.
     *
     * @return int
     */
    public function getIdGroupe()
    {
        return $this->id_groupe;
    }

    /**
     * Set the value of [id_ref_type_prestation] column.
     *
     * @param int $v new value
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function setIdRefTypePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_type_prestation !== $v) {
            $this->id_ref_type_prestation = $v;
            $this->modifiedColumns[] = TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION;
        }


        return $this;
    } // setIdRefTypePrestation()

    /**
     * Set the value of [id_organisation] column.
     *
     * @param int $v new value
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function setIdOrganisation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation !== $v) {
            $this->id_organisation = $v;
            $this->modifiedColumns[] = TRefTypePrestationPeer::ID_ORGANISATION;
        }

        if ($this->aTOrganisation !== null && $this->aTOrganisation->getIdOrganisation() !== $v) {
            $this->aTOrganisation = null;
        }


        return $this;
    } // setIdOrganisation()

    /**
     * Set the value of [code_libelle] column.
     *
     * @param int $v new value
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function setCodeLibelle($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle !== $v) {
            $this->code_libelle = $v;
            $this->modifiedColumns[] = TRefTypePrestationPeer::CODE_LIBELLE;
        }

        if ($this->aTTraduction !== null && $this->aTTraduction->getIdTraduction() !== $v) {
            $this->aTTraduction = null;
        }


        return $this;
    } // setCodeLibelle()

    /**
     * Set the value of [id_groupe] column.
     *
     * @param int $v new value
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function setIdGroupe($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_groupe !== $v) {
            $this->id_groupe = $v;
            $this->modifiedColumns[] = TRefTypePrestationPeer::ID_GROUPE;
        }

        if ($this->aTGroupe !== null && $this->aTGroupe->getIdGroupe() !== $v) {
            $this->aTGroupe = null;
        }


        return $this;
    } // setIdGroupe()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_ref_type_prestation = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->id_organisation = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->code_libelle = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->id_groupe = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 4; // 4 = TRefTypePrestationPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TRefTypePrestation object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTOrganisation !== null && $this->id_organisation !== $this->aTOrganisation->getIdOrganisation()) {
            $this->aTOrganisation = null;
        }
        if ($this->aTTraduction !== null && $this->code_libelle !== $this->aTTraduction->getIdTraduction()) {
            $this->aTTraduction = null;
        }
        if ($this->aTGroupe !== null && $this->id_groupe !== $this->aTGroupe->getIdGroupe()) {
            $this->aTGroupe = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TRefTypePrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TRefTypePrestationPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTGroupe = null;
            $this->aTTraduction = null;
            $this->aTOrganisation = null;
            $this->collTParametragePrestations = null;

            $this->collTTypePrestations = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TRefTypePrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TRefTypePrestationQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TRefTypePrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TRefTypePrestationPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTGroupe !== null) {
                if ($this->aTGroupe->isModified() || $this->aTGroupe->isNew()) {
                    $affectedRows += $this->aTGroupe->save($con);
                }
                $this->setTGroupe($this->aTGroupe);
            }

            if ($this->aTTraduction !== null) {
                if ($this->aTTraduction->isModified() || $this->aTTraduction->isNew()) {
                    $affectedRows += $this->aTTraduction->save($con);
                }
                $this->setTTraduction($this->aTTraduction);
            }

            if ($this->aTOrganisation !== null) {
                if ($this->aTOrganisation->isModified() || $this->aTOrganisation->isNew()) {
                    $affectedRows += $this->aTOrganisation->save($con);
                }
                $this->setTOrganisation($this->aTOrganisation);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tParametragePrestationsScheduledForDeletion !== null) {
                if (!$this->tParametragePrestationsScheduledForDeletion->isEmpty()) {
                    TParametragePrestationQuery::create()
                        ->filterByPrimaryKeys($this->tParametragePrestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tParametragePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTParametragePrestations !== null) {
                foreach ($this->collTParametragePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tTypePrestationsScheduledForDeletion !== null) {
                if (!$this->tTypePrestationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tTypePrestationsScheduledForDeletion as $tTypePrestation) {
                        // need to save related object because we set the relation to null
                        $tTypePrestation->save($con);
                    }
                    $this->tTypePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTTypePrestations !== null) {
                foreach ($this->collTTypePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION;
        if (null !== $this->id_ref_type_prestation) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_TYPE_PRESTATION`';
        }
        if ($this->isColumnModified(TRefTypePrestationPeer::ID_ORGANISATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION`';
        }
        if ($this->isColumnModified(TRefTypePrestationPeer::CODE_LIBELLE)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE`';
        }
        if ($this->isColumnModified(TRefTypePrestationPeer::ID_GROUPE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_GROUPE`';
        }

        $sql = sprintf(
            'INSERT INTO `T_REF_TYPE_PRESTATION` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_REF_TYPE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_ref_type_prestation, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION`':
                        $stmt->bindValue($identifier, $this->id_organisation, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE`':
                        $stmt->bindValue($identifier, $this->code_libelle, PDO::PARAM_INT);
                        break;
                    case '`ID_GROUPE`':
                        $stmt->bindValue($identifier, $this->id_groupe, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdRefTypePrestation($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTGroupe !== null) {
                if (!$this->aTGroupe->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTGroupe->getValidationFailures());
                }
            }

            if ($this->aTTraduction !== null) {
                if (!$this->aTTraduction->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraduction->getValidationFailures());
                }
            }

            if ($this->aTOrganisation !== null) {
                if (!$this->aTOrganisation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisation->getValidationFailures());
                }
            }


            if (($retval = TRefTypePrestationPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTParametragePrestations !== null) {
                    foreach ($this->collTParametragePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTTypePrestations !== null) {
                    foreach ($this->collTTypePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TRefTypePrestationPeer::DATABASE_NAME);

        if ($this->isColumnModified(TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION)) $criteria->add(TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION, $this->id_ref_type_prestation);
        if ($this->isColumnModified(TRefTypePrestationPeer::ID_ORGANISATION)) $criteria->add(TRefTypePrestationPeer::ID_ORGANISATION, $this->id_organisation);
        if ($this->isColumnModified(TRefTypePrestationPeer::CODE_LIBELLE)) $criteria->add(TRefTypePrestationPeer::CODE_LIBELLE, $this->code_libelle);
        if ($this->isColumnModified(TRefTypePrestationPeer::ID_GROUPE)) $criteria->add(TRefTypePrestationPeer::ID_GROUPE, $this->id_groupe);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TRefTypePrestationPeer::DATABASE_NAME);
        $criteria->add(TRefTypePrestationPeer::ID_REF_TYPE_PRESTATION, $this->id_ref_type_prestation);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdRefTypePrestation();
    }

    /**
     * Generic method to set the primary key (id_ref_type_prestation column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdRefTypePrestation($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdRefTypePrestation();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TRefTypePrestation (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setIdOrganisation($this->getIdOrganisation());
        $copyObj->setCodeLibelle($this->getCodeLibelle());
        $copyObj->setIdGroupe($this->getIdGroupe());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTParametragePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametragePrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTTypePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTTypePrestation($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdRefTypePrestation(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TRefTypePrestation Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TRefTypePrestationPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TRefTypePrestationPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TGroupe object.
     *
     * @param             TGroupe $v
     * @return TRefTypePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTGroupe(TGroupe $v = null)
    {
        if ($v === null) {
            $this->setIdGroupe(NULL);
        } else {
            $this->setIdGroupe($v->getIdGroupe());
        }

        $this->aTGroupe = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TGroupe object, it will not be re-added.
        if ($v !== null) {
            $v->addTRefTypePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TGroupe object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TGroupe The associated TGroupe object.
     * @throws PropelException
     */
    public function getTGroupe(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTGroupe === null && ($this->id_groupe !== null) && $doQuery) {
            $this->aTGroupe = TGroupeQuery::create()->findPk($this->id_groupe, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTGroupe->addTRefTypePrestations($this);
             */
        }

        return $this->aTGroupe;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TRefTypePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraduction(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelle(NULL);
        } else {
            $this->setCodeLibelle($v->getIdTraduction());
        }

        $this->aTTraduction = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTRefTypePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraduction(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraduction === null && ($this->code_libelle !== null) && $doQuery) {
            $this->aTTraduction = TTraductionQuery::create()->findPk($this->code_libelle, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraduction->addTRefTypePrestations($this);
             */
        }

        return $this->aTTraduction;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TRefTypePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisation(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisation(NULL);
        } else {
            $this->setIdOrganisation($v->getIdOrganisation());
        }

        $this->aTOrganisation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTRefTypePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisation === null && ($this->id_organisation !== null) && $doQuery) {
            $this->aTOrganisation = TOrganisationQuery::create()->findPk($this->id_organisation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisation->addTRefTypePrestations($this);
             */
        }

        return $this->aTOrganisation;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TParametragePrestation' == $relationName) {
            $this->initTParametragePrestations();
        }
        if ('TTypePrestation' == $relationName) {
            $this->initTTypePrestations();
        }
    }

    /**
     * Clears out the collTParametragePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TRefTypePrestation The current object (for fluent API support)
     * @see        addTParametragePrestations()
     */
    public function clearTParametragePrestations()
    {
        $this->collTParametragePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTParametragePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTParametragePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametragePrestations($v = true)
    {
        $this->collTParametragePrestationsPartial = $v;
    }

    /**
     * Initializes the collTParametragePrestations collection.
     *
     * By default this just sets the collTParametragePrestations collection to an empty array (like clearcollTParametragePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametragePrestations($overrideExisting = true)
    {
        if (null !== $this->collTParametragePrestations && !$overrideExisting) {
            return;
        }
        $this->collTParametragePrestations = new PropelObjectCollection();
        $this->collTParametragePrestations->setModel('TParametragePrestation');
    }

    /**
     * Gets an array of TParametragePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TRefTypePrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     * @throws PropelException
     */
    public function getTParametragePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsPartial && !$this->isNew();
        if (null === $this->collTParametragePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestations) {
                // return empty collection
                $this->initTParametragePrestations();
            } else {
                $collTParametragePrestations = TParametragePrestationQuery::create(null, $criteria)
                    ->filterByTRefTypePrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametragePrestationsPartial && count($collTParametragePrestations)) {
                      $this->initTParametragePrestations(false);

                      foreach($collTParametragePrestations as $obj) {
                        if (false == $this->collTParametragePrestations->contains($obj)) {
                          $this->collTParametragePrestations->append($obj);
                        }
                      }

                      $this->collTParametragePrestationsPartial = true;
                    }

                    $collTParametragePrestations->getInternalIterator()->rewind();
                    return $collTParametragePrestations;
                }

                if($partial && $this->collTParametragePrestations) {
                    foreach($this->collTParametragePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTParametragePrestations[] = $obj;
                        }
                    }
                }

                $this->collTParametragePrestations = $collTParametragePrestations;
                $this->collTParametragePrestationsPartial = false;
            }
        }

        return $this->collTParametragePrestations;
    }

    /**
     * Sets a collection of TParametragePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametragePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function setTParametragePrestations(PropelCollection $tParametragePrestations, PropelPDO $con = null)
    {
        $tParametragePrestationsToDelete = $this->getTParametragePrestations(new Criteria(), $con)->diff($tParametragePrestations);

        $this->tParametragePrestationsScheduledForDeletion = unserialize(serialize($tParametragePrestationsToDelete));

        foreach ($tParametragePrestationsToDelete as $tParametragePrestationRemoved) {
            $tParametragePrestationRemoved->setTRefTypePrestation(null);
        }

        $this->collTParametragePrestations = null;
        foreach ($tParametragePrestations as $tParametragePrestation) {
            $this->addTParametragePrestation($tParametragePrestation);
        }

        $this->collTParametragePrestations = $tParametragePrestations;
        $this->collTParametragePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametragePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametragePrestation objects.
     * @throws PropelException
     */
    public function countTParametragePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsPartial && !$this->isNew();
        if (null === $this->collTParametragePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametragePrestations());
            }
            $query = TParametragePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTRefTypePrestation($this)
                ->count($con);
        }

        return count($this->collTParametragePrestations);
    }

    /**
     * Method called to associate a TParametragePrestation object to this object
     * through the TParametragePrestation foreign key attribute.
     *
     * @param    TParametragePrestation $l TParametragePrestation
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function addTParametragePrestation(TParametragePrestation $l)
    {
        if ($this->collTParametragePrestations === null) {
            $this->initTParametragePrestations();
            $this->collTParametragePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTParametragePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametragePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TParametragePrestation $tParametragePrestation The tParametragePrestation object to add.
     */
    protected function doAddTParametragePrestation($tParametragePrestation)
    {
        $this->collTParametragePrestations[]= $tParametragePrestation;
        $tParametragePrestation->setTRefTypePrestation($this);
    }

    /**
     * @param	TParametragePrestation $tParametragePrestation The tParametragePrestation object to remove.
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function removeTParametragePrestation($tParametragePrestation)
    {
        if ($this->getTParametragePrestations()->contains($tParametragePrestation)) {
            $this->collTParametragePrestations->remove($this->collTParametragePrestations->search($tParametragePrestation));
            if (null === $this->tParametragePrestationsScheduledForDeletion) {
                $this->tParametragePrestationsScheduledForDeletion = clone $this->collTParametragePrestations;
                $this->tParametragePrestationsScheduledForDeletion->clear();
            }
            $this->tParametragePrestationsScheduledForDeletion[]= clone $tParametragePrestation;
            $tParametragePrestation->setTRefTypePrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TRefTypePrestation is new, it will return
     * an empty collection; or if this TRefTypePrestation has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TRefTypePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TRefTypePrestation is new, it will return
     * an empty collection; or if this TRefTypePrestation has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TRefTypePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TRefTypePrestation is new, it will return
     * an empty collection; or if this TRefTypePrestation has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TRefTypePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TRefTypePrestation is new, it will return
     * an empty collection; or if this TRefTypePrestation has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TRefTypePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }

    /**
     * Clears out the collTTypePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TRefTypePrestation The current object (for fluent API support)
     * @see        addTTypePrestations()
     */
    public function clearTTypePrestations()
    {
        $this->collTTypePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTTypePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTTypePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTTypePrestations($v = true)
    {
        $this->collTTypePrestationsPartial = $v;
    }

    /**
     * Initializes the collTTypePrestations collection.
     *
     * By default this just sets the collTTypePrestations collection to an empty array (like clearcollTTypePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTTypePrestations($overrideExisting = true)
    {
        if (null !== $this->collTTypePrestations && !$overrideExisting) {
            return;
        }
        $this->collTTypePrestations = new PropelObjectCollection();
        $this->collTTypePrestations->setModel('TTypePrestation');
    }

    /**
     * Gets an array of TTypePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TRefTypePrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     * @throws PropelException
     */
    public function getTTypePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTTypePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTTypePrestations) {
                // return empty collection
                $this->initTTypePrestations();
            } else {
                $collTTypePrestations = TTypePrestationQuery::create(null, $criteria)
                    ->filterByTRefTypePrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTTypePrestationsPartial && count($collTTypePrestations)) {
                      $this->initTTypePrestations(false);

                      foreach($collTTypePrestations as $obj) {
                        if (false == $this->collTTypePrestations->contains($obj)) {
                          $this->collTTypePrestations->append($obj);
                        }
                      }

                      $this->collTTypePrestationsPartial = true;
                    }

                    $collTTypePrestations->getInternalIterator()->rewind();
                    return $collTTypePrestations;
                }

                if($partial && $this->collTTypePrestations) {
                    foreach($this->collTTypePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTTypePrestations[] = $obj;
                        }
                    }
                }

                $this->collTTypePrestations = $collTTypePrestations;
                $this->collTTypePrestationsPartial = false;
            }
        }

        return $this->collTTypePrestations;
    }

    /**
     * Sets a collection of TTypePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tTypePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function setTTypePrestations(PropelCollection $tTypePrestations, PropelPDO $con = null)
    {
        $tTypePrestationsToDelete = $this->getTTypePrestations(new Criteria(), $con)->diff($tTypePrestations);

        $this->tTypePrestationsScheduledForDeletion = unserialize(serialize($tTypePrestationsToDelete));

        foreach ($tTypePrestationsToDelete as $tTypePrestationRemoved) {
            $tTypePrestationRemoved->setTRefTypePrestation(null);
        }

        $this->collTTypePrestations = null;
        foreach ($tTypePrestations as $tTypePrestation) {
            $this->addTTypePrestation($tTypePrestation);
        }

        $this->collTTypePrestations = $tTypePrestations;
        $this->collTTypePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TTypePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TTypePrestation objects.
     * @throws PropelException
     */
    public function countTTypePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTTypePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTTypePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTTypePrestations());
            }
            $query = TTypePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTRefTypePrestation($this)
                ->count($con);
        }

        return count($this->collTTypePrestations);
    }

    /**
     * Method called to associate a TTypePrestation object to this object
     * through the TTypePrestation foreign key attribute.
     *
     * @param    TTypePrestation $l TTypePrestation
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function addTTypePrestation(TTypePrestation $l)
    {
        if ($this->collTTypePrestations === null) {
            $this->initTTypePrestations();
            $this->collTTypePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTTypePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTTypePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TTypePrestation $tTypePrestation The tTypePrestation object to add.
     */
    protected function doAddTTypePrestation($tTypePrestation)
    {
        $this->collTTypePrestations[]= $tTypePrestation;
        $tTypePrestation->setTRefTypePrestation($this);
    }

    /**
     * @param	TTypePrestation $tTypePrestation The tTypePrestation object to remove.
     * @return TRefTypePrestation The current object (for fluent API support)
     */
    public function removeTTypePrestation($tTypePrestation)
    {
        if ($this->getTTypePrestations()->contains($tTypePrestation)) {
            $this->collTTypePrestations->remove($this->collTTypePrestations->search($tTypePrestation));
            if (null === $this->tTypePrestationsScheduledForDeletion) {
                $this->tTypePrestationsScheduledForDeletion = clone $this->collTTypePrestations;
                $this->tTypePrestationsScheduledForDeletion->clear();
            }
            $this->tTypePrestationsScheduledForDeletion[]= $tTypePrestation;
            $tTypePrestation->setTRefTypePrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TRefTypePrestation is new, it will return
     * an empty collection; or if this TRefTypePrestation has previously
     * been saved, it will retrieve related TTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TRefTypePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     */
    public function getTTypePrestationsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTTypePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TRefTypePrestation is new, it will return
     * an empty collection; or if this TRefTypePrestation has previously
     * been saved, it will retrieve related TTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TRefTypePrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     */
    public function getTTypePrestationsJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTTypePrestations($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_ref_type_prestation = null;
        $this->id_organisation = null;
        $this->code_libelle = null;
        $this->id_groupe = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTParametragePrestations) {
                foreach ($this->collTParametragePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTTypePrestations) {
                foreach ($this->collTTypePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTGroupe instanceof Persistent) {
              $this->aTGroupe->clearAllReferences($deep);
            }
            if ($this->aTTraduction instanceof Persistent) {
              $this->aTTraduction->clearAllReferences($deep);
            }
            if ($this->aTOrganisation instanceof Persistent) {
              $this->aTOrganisation->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTParametragePrestations instanceof PropelCollection) {
            $this->collTParametragePrestations->clearIterator();
        }
        $this->collTParametragePrestations = null;
        if ($this->collTTypePrestations instanceof PropelCollection) {
            $this->collTTypePrestations->clearIterator();
        }
        $this->collTTypePrestations = null;
        $this->aTGroupe = null;
        $this->aTTraduction = null;
        $this->aTOrganisation = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TRefTypePrestationPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
