<?php


/**
 * Base static class for performing query and update operations on the 'T_CITOYEN' table.
 *
 *
 *
 * @package propel.generator.RDV.om
 */
abstract class BaseTCitoyenPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'RDV';

    /** the table name for this class */
    const TABLE_NAME = 'T_CITOYEN';

    /** the related Propel class for this table */
    const OM_CLASS = 'TCitoyen';

    /** the related TableMap class for this table */
    const TM_CLASS = 'TCitoyenTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 16;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 16;

    /** the column name for the ID_CITOYEN field */
    const ID_CITOYEN = 'T_CITOYEN.ID_CITOYEN';

    /** the column name for the RAISON_SOCIAL field */
    const RAISON_SOCIAL = 'T_CITOYEN.RAISON_SOCIAL';

    /** the column name for the NOM field */
    const NOM = 'T_CITOYEN.NOM';

    /** the column name for the PRENOM field */
    const PRENOM = 'T_CITOYEN.PRENOM';

    /** the column name for the DATE_NAISSANCE field */
    const DATE_NAISSANCE = 'T_CITOYEN.DATE_NAISSANCE';

    /** the column name for the IDENTIFIANT field */
    const IDENTIFIANT = 'T_CITOYEN.IDENTIFIANT';

    /** the column name for the ADRESSE field */
    const ADRESSE = 'T_CITOYEN.ADRESSE';

    /** the column name for the MAIL field */
    const MAIL = 'T_CITOYEN.MAIL';

    /** the column name for the TELEPHONE field */
    const TELEPHONE = 'T_CITOYEN.TELEPHONE';

    /** the column name for the FAX field */
    const FAX = 'T_CITOYEN.FAX';

    /** the column name for the TEXT_1 field */
    const TEXT_1 = 'T_CITOYEN.TEXT_1';

    /** the column name for the ID_REF_1 field */
    const ID_REF_1 = 'T_CITOYEN.ID_REF_1';

    /** the column name for the TEXT_2 field */
    const TEXT_2 = 'T_CITOYEN.TEXT_2';

    /** the column name for the ID_REF_2 field */
    const ID_REF_2 = 'T_CITOYEN.ID_REF_2';

    /** the column name for the TEXT_3 field */
    const TEXT_3 = 'T_CITOYEN.TEXT_3';

    /** the column name for the ID_REF_3 field */
    const ID_REF_3 = 'T_CITOYEN.ID_REF_3';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identiy map to hold any loaded instances of TCitoyen objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array TCitoyen[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. TCitoyenPeer::$fieldNames[TCitoyenPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('IdCitoyen', 'RaisonSocial', 'Nom', 'Prenom', 'DateNaissance', 'Identifiant', 'Adresse', 'Mail', 'Telephone', 'Fax', 'Text1', 'IdRef1', 'Text2', 'IdRef2', 'Text3', 'IdRef3', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idCitoyen', 'raisonSocial', 'nom', 'prenom', 'dateNaissance', 'identifiant', 'adresse', 'mail', 'telephone', 'fax', 'text1', 'idRef1', 'text2', 'idRef2', 'text3', 'idRef3', ),
        BasePeer::TYPE_COLNAME => array (TCitoyenPeer::ID_CITOYEN, TCitoyenPeer::RAISON_SOCIAL, TCitoyenPeer::NOM, TCitoyenPeer::PRENOM, TCitoyenPeer::DATE_NAISSANCE, TCitoyenPeer::IDENTIFIANT, TCitoyenPeer::ADRESSE, TCitoyenPeer::MAIL, TCitoyenPeer::TELEPHONE, TCitoyenPeer::FAX, TCitoyenPeer::TEXT_1, TCitoyenPeer::ID_REF_1, TCitoyenPeer::TEXT_2, TCitoyenPeer::ID_REF_2, TCitoyenPeer::TEXT_3, TCitoyenPeer::ID_REF_3, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_CITOYEN', 'RAISON_SOCIAL', 'NOM', 'PRENOM', 'DATE_NAISSANCE', 'IDENTIFIANT', 'ADRESSE', 'MAIL', 'TELEPHONE', 'FAX', 'TEXT_1', 'ID_REF_1', 'TEXT_2', 'ID_REF_2', 'TEXT_3', 'ID_REF_3', ),
        BasePeer::TYPE_FIELDNAME => array ('ID_CITOYEN', 'RAISON_SOCIAL', 'NOM', 'PRENOM', 'DATE_NAISSANCE', 'IDENTIFIANT', 'ADRESSE', 'MAIL', 'TELEPHONE', 'FAX', 'TEXT_1', 'ID_REF_1', 'TEXT_2', 'ID_REF_2', 'TEXT_3', 'ID_REF_3', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. TCitoyenPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('IdCitoyen' => 0, 'RaisonSocial' => 1, 'Nom' => 2, 'Prenom' => 3, 'DateNaissance' => 4, 'Identifiant' => 5, 'Adresse' => 6, 'Mail' => 7, 'Telephone' => 8, 'Fax' => 9, 'Text1' => 10, 'IdRef1' => 11, 'Text2' => 12, 'IdRef2' => 13, 'Text3' => 14, 'IdRef3' => 15, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idCitoyen' => 0, 'raisonSocial' => 1, 'nom' => 2, 'prenom' => 3, 'dateNaissance' => 4, 'identifiant' => 5, 'adresse' => 6, 'mail' => 7, 'telephone' => 8, 'fax' => 9, 'text1' => 10, 'idRef1' => 11, 'text2' => 12, 'idRef2' => 13, 'text3' => 14, 'idRef3' => 15, ),
        BasePeer::TYPE_COLNAME => array (TCitoyenPeer::ID_CITOYEN => 0, TCitoyenPeer::RAISON_SOCIAL => 1, TCitoyenPeer::NOM => 2, TCitoyenPeer::PRENOM => 3, TCitoyenPeer::DATE_NAISSANCE => 4, TCitoyenPeer::IDENTIFIANT => 5, TCitoyenPeer::ADRESSE => 6, TCitoyenPeer::MAIL => 7, TCitoyenPeer::TELEPHONE => 8, TCitoyenPeer::FAX => 9, TCitoyenPeer::TEXT_1 => 10, TCitoyenPeer::ID_REF_1 => 11, TCitoyenPeer::TEXT_2 => 12, TCitoyenPeer::ID_REF_2 => 13, TCitoyenPeer::TEXT_3 => 14, TCitoyenPeer::ID_REF_3 => 15, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_CITOYEN' => 0, 'RAISON_SOCIAL' => 1, 'NOM' => 2, 'PRENOM' => 3, 'DATE_NAISSANCE' => 4, 'IDENTIFIANT' => 5, 'ADRESSE' => 6, 'MAIL' => 7, 'TELEPHONE' => 8, 'FAX' => 9, 'TEXT_1' => 10, 'ID_REF_1' => 11, 'TEXT_2' => 12, 'ID_REF_2' => 13, 'TEXT_3' => 14, 'ID_REF_3' => 15, ),
        BasePeer::TYPE_FIELDNAME => array ('ID_CITOYEN' => 0, 'RAISON_SOCIAL' => 1, 'NOM' => 2, 'PRENOM' => 3, 'DATE_NAISSANCE' => 4, 'IDENTIFIANT' => 5, 'ADRESSE' => 6, 'MAIL' => 7, 'TELEPHONE' => 8, 'FAX' => 9, 'TEXT_1' => 10, 'ID_REF_1' => 11, 'TEXT_2' => 12, 'ID_REF_2' => 13, 'TEXT_3' => 14, 'ID_REF_3' => 15, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, )
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = TCitoyenPeer::getFieldNames($toType);
        $key = isset(TCitoyenPeer::$fieldKeys[$fromType][$name]) ? TCitoyenPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(TCitoyenPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, TCitoyenPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return TCitoyenPeer::$fieldNames[$type];
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. TCitoyenPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(TCitoyenPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(TCitoyenPeer::ID_CITOYEN);
            $criteria->addSelectColumn(TCitoyenPeer::RAISON_SOCIAL);
            $criteria->addSelectColumn(TCitoyenPeer::NOM);
            $criteria->addSelectColumn(TCitoyenPeer::PRENOM);
            $criteria->addSelectColumn(TCitoyenPeer::DATE_NAISSANCE);
            $criteria->addSelectColumn(TCitoyenPeer::IDENTIFIANT);
            $criteria->addSelectColumn(TCitoyenPeer::ADRESSE);
            $criteria->addSelectColumn(TCitoyenPeer::MAIL);
            $criteria->addSelectColumn(TCitoyenPeer::TELEPHONE);
            $criteria->addSelectColumn(TCitoyenPeer::FAX);
            $criteria->addSelectColumn(TCitoyenPeer::TEXT_1);
            $criteria->addSelectColumn(TCitoyenPeer::ID_REF_1);
            $criteria->addSelectColumn(TCitoyenPeer::TEXT_2);
            $criteria->addSelectColumn(TCitoyenPeer::ID_REF_2);
            $criteria->addSelectColumn(TCitoyenPeer::TEXT_3);
            $criteria->addSelectColumn(TCitoyenPeer::ID_REF_3);
        } else {
            $criteria->addSelectColumn($alias . '.ID_CITOYEN');
            $criteria->addSelectColumn($alias . '.RAISON_SOCIAL');
            $criteria->addSelectColumn($alias . '.NOM');
            $criteria->addSelectColumn($alias . '.PRENOM');
            $criteria->addSelectColumn($alias . '.DATE_NAISSANCE');
            $criteria->addSelectColumn($alias . '.IDENTIFIANT');
            $criteria->addSelectColumn($alias . '.ADRESSE');
            $criteria->addSelectColumn($alias . '.MAIL');
            $criteria->addSelectColumn($alias . '.TELEPHONE');
            $criteria->addSelectColumn($alias . '.FAX');
            $criteria->addSelectColumn($alias . '.TEXT_1');
            $criteria->addSelectColumn($alias . '.ID_REF_1');
            $criteria->addSelectColumn($alias . '.TEXT_2');
            $criteria->addSelectColumn($alias . '.ID_REF_2');
            $criteria->addSelectColumn($alias . '.TEXT_3');
            $criteria->addSelectColumn($alias . '.ID_REF_3');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return                 TCitoyen
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = TCitoyenPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return TCitoyenPeer::populateObjects(TCitoyenPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            TCitoyenPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param      TCitoyen $obj A TCitoyen object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getIdCitoyen();
            } // if key === null
            TCitoyenPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A TCitoyen object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof TCitoyen) {
                $key = (string) $value->getIdCitoyen();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or TCitoyen object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(TCitoyenPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return   TCitoyen Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(TCitoyenPeer::$instances[$key])) {
                return TCitoyenPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references)
      {
        foreach (TCitoyenPeer::$instances as $instance)
        {
          $instance->clearAllReferences(true);
        }
      }
        TCitoyenPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to T_CITOYEN
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = TCitoyenPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = TCitoyenPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                TCitoyenPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (TCitoyen object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = TCitoyenPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = TCitoyenPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + TCitoyenPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = TCitoyenPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            TCitoyenPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentielRelatedByIdRef1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTValeurReferentielRelatedByIdRef1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TCitoyenPeer::ID_REF_1, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentielRelatedByIdRef2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTValeurReferentielRelatedByIdRef2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TCitoyenPeer::ID_REF_2, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentielRelatedByIdRef3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTValeurReferentielRelatedByIdRef3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TCitoyenPeer::ID_REF_3, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TCitoyen objects pre-filled with their TValeurReferentiel objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TCitoyen objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTValeurReferentielRelatedByIdRef1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);
        }

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol = TCitoyenPeer::NUM_HYDRATE_COLUMNS;
        TValeurReferentielPeer::addSelectColumns($criteria);

        $criteria->addJoin(TCitoyenPeer::ID_REF_1, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TCitoyenPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TCitoyenPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TCitoyenPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TValeurReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TValeurReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TCitoyen) to $obj2 (TValeurReferentiel)
                $obj2->addTCitoyenRelatedByIdRef1($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TCitoyen objects pre-filled with their TValeurReferentiel objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TCitoyen objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTValeurReferentielRelatedByIdRef2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);
        }

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol = TCitoyenPeer::NUM_HYDRATE_COLUMNS;
        TValeurReferentielPeer::addSelectColumns($criteria);

        $criteria->addJoin(TCitoyenPeer::ID_REF_2, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TCitoyenPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TCitoyenPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TCitoyenPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TValeurReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TValeurReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TCitoyen) to $obj2 (TValeurReferentiel)
                $obj2->addTCitoyenRelatedByIdRef2($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TCitoyen objects pre-filled with their TValeurReferentiel objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TCitoyen objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTValeurReferentielRelatedByIdRef3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);
        }

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol = TCitoyenPeer::NUM_HYDRATE_COLUMNS;
        TValeurReferentielPeer::addSelectColumns($criteria);

        $criteria->addJoin(TCitoyenPeer::ID_REF_3, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TCitoyenPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TCitoyenPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TCitoyenPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TValeurReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TValeurReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TCitoyen) to $obj2 (TValeurReferentiel)
                $obj2->addTCitoyenRelatedByIdRef3($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TCitoyenPeer::ID_REF_1, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TCitoyenPeer::ID_REF_2, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TCitoyenPeer::ID_REF_3, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of TCitoyen objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TCitoyen objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);
        }

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol2 = TCitoyenPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        TValeurReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TValeurReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TCitoyenPeer::ID_REF_1, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TCitoyenPeer::ID_REF_2, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TCitoyenPeer::ID_REF_3, TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TCitoyenPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TCitoyenPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TCitoyenPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined TValeurReferentiel rows

            $key2 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = TValeurReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TValeurReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (TCitoyen) to the collection in $obj2 (TValeurReferentiel)
                $obj2->addTCitoyenRelatedByIdRef1($obj1);
            } // if joined row not null

            // Add objects for joined TValeurReferentiel rows

            $key3 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = TValeurReferentielPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TValeurReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (TCitoyen) to the collection in $obj3 (TValeurReferentiel)
                $obj3->addTCitoyenRelatedByIdRef2($obj1);
            } // if joined row not null

            // Add objects for joined TValeurReferentiel rows

            $key4 = TValeurReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = TValeurReferentielPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = TValeurReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TValeurReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (TCitoyen) to the collection in $obj4 (TValeurReferentiel)
                $obj4->addTCitoyenRelatedByIdRef3($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentielRelatedByIdRef1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTValeurReferentielRelatedByIdRef1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentielRelatedByIdRef2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTValeurReferentielRelatedByIdRef2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TValeurReferentielRelatedByIdRef3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTValeurReferentielRelatedByIdRef3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TCitoyenPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TCitoyen objects pre-filled with all related objects except TValeurReferentielRelatedByIdRef1.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TCitoyen objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTValeurReferentielRelatedByIdRef1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);
        }

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol2 = TCitoyenPeer::NUM_HYDRATE_COLUMNS;


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TCitoyenPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TCitoyenPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TCitoyenPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TCitoyen objects pre-filled with all related objects except TValeurReferentielRelatedByIdRef2.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TCitoyen objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTValeurReferentielRelatedByIdRef2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);
        }

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol2 = TCitoyenPeer::NUM_HYDRATE_COLUMNS;


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TCitoyenPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TCitoyenPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TCitoyenPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TCitoyen objects pre-filled with all related objects except TValeurReferentielRelatedByIdRef3.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TCitoyen objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTValeurReferentielRelatedByIdRef3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);
        }

        TCitoyenPeer::addSelectColumns($criteria);
        $startcol2 = TCitoyenPeer::NUM_HYDRATE_COLUMNS;


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TCitoyenPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TCitoyenPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TCitoyenPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TCitoyenPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(TCitoyenPeer::DATABASE_NAME)->getTable(TCitoyenPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseTCitoyenPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseTCitoyenPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new TCitoyenTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return TCitoyenPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a TCitoyen or Criteria object.
     *
     * @param      mixed $values Criteria or TCitoyen object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from TCitoyen object
        }

        if ($criteria->containsKey(TCitoyenPeer::ID_CITOYEN) && $criteria->keyContainsValue(TCitoyenPeer::ID_CITOYEN) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.TCitoyenPeer::ID_CITOYEN.')');
        }


        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a TCitoyen or Criteria object.
     *
     * @param      mixed $values Criteria or TCitoyen object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(TCitoyenPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(TCitoyenPeer::ID_CITOYEN);
            $value = $criteria->remove(TCitoyenPeer::ID_CITOYEN);
            if ($value) {
                $selectCriteria->add(TCitoyenPeer::ID_CITOYEN, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(TCitoyenPeer::TABLE_NAME);
            }

        } else { // $values is TCitoyen object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the T_CITOYEN table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(TCitoyenPeer::TABLE_NAME, $con, TCitoyenPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            TCitoyenPeer::clearInstancePool();
            TCitoyenPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a TCitoyen or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or TCitoyen object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            TCitoyenPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof TCitoyen) { // it's a model object
            // invalidate the cache for this single object
            TCitoyenPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(TCitoyenPeer::DATABASE_NAME);
            $criteria->add(TCitoyenPeer::ID_CITOYEN, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                TCitoyenPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(TCitoyenPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            TCitoyenPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given TCitoyen object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param      TCitoyen $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(TCitoyenPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(TCitoyenPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(TCitoyenPeer::DATABASE_NAME, TCitoyenPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param      int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return TCitoyen
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = TCitoyenPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(TCitoyenPeer::DATABASE_NAME);
        $criteria->add(TCitoyenPeer::ID_CITOYEN, $pk);

        $v = TCitoyenPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return TCitoyen[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TCitoyenPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(TCitoyenPeer::DATABASE_NAME);
            $criteria->add(TCitoyenPeer::ID_CITOYEN, $pks, Criteria::IN);
            $objs = TCitoyenPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseTCitoyenPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseTCitoyenPeer::buildTableMap();

