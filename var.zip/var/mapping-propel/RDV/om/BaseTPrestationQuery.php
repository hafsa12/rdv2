<?php


/**
 * Base class that represents a query for the 'T_PRESTATION' table.
 *
 *
 *
 * @method TPrestationQuery orderByIdPrestation($order = Criteria::ASC) Order by the ID_PRESTATION column
 * @method TPrestationQuery orderByIdRefPrestation($order = Criteria::ASC) Order by the ID_REF_PRESTATION column
 * @method TPrestationQuery orderByCodeLibellePrestation($order = Criteria::ASC) Order by the CODE_LIBELLE_PRESTATION column
 * @method TPrestationQuery orderByIdTypePrestation($order = Criteria::ASC) Order by the ID_TYPE_PRESTATION column
 * @method TPrestationQuery orderByRdvSimilaire($order = Criteria::ASC) Order by the RDV_SIMILAIRE column
 * @method TPrestationQuery orderByNbJourRdvSimilaire($order = Criteria::ASC) Order by the NB_JOUR_RDV_SIMILAIRE column
 * @method TPrestationQuery orderByDelaiMin($order = Criteria::ASC) Order by the DELAI_MIN column
 * @method TPrestationQuery orderByPeriodicite($order = Criteria::ASC) Order by the PERIODICITE column
 * @method TPrestationQuery orderByRessourceVisible($order = Criteria::ASC) Order by the RESSOURCE_VISIBLE column
 * @method TPrestationQuery orderByRessourceObligatoire($order = Criteria::ASC) Order by the RESSOURCE_OBLIGATOIRE column
 * @method TPrestationQuery orderByIdParametreForm($order = Criteria::ASC) Order by the ID_PARAMETRE_FORM column
 * @method TPrestationQuery orderByCodeCommentaire($order = Criteria::ASC) Order by the CODE_COMMENTAIRE column
 * @method TPrestationQuery orderByReferentVisible($order = Criteria::ASC) Order by the REFERENT_VISIBLE column
 * @method TPrestationQuery orderByIdParametragePrestation($order = Criteria::ASC) Order by the ID_PARAMETRAGE_PRESTATION column
 * @method TPrestationQuery orderByIdChampsSupp1($order = Criteria::ASC) Order by the ID_CHAMPS_SUPP_1 column
 * @method TPrestationQuery orderByIdChampsSupp2($order = Criteria::ASC) Order by the ID_CHAMPS_SUPP_2 column
 * @method TPrestationQuery orderByIdChampsSupp3($order = Criteria::ASC) Order by the ID_CHAMPS_SUPP_3 column
 * @method TPrestationQuery orderByVisioconference($order = Criteria::ASC) Order by the VISIOCONFERENCE column
 * @method TPrestationQuery orderByRdvGroupe($order = Criteria::ASC) Order by the RDV_GROUPE column
 * @method TPrestationQuery orderByNombreMaxParticipants($order = Criteria::ASC) Order by the NOMBRE_MAX_PARTICIPANTS column
 * @method TPrestationQuery orderByTypeSession($order = Criteria::ASC) Order by the TYPE_SESSION column
 *
 * @method TPrestationQuery groupByIdPrestation() Group by the ID_PRESTATION column
 * @method TPrestationQuery groupByIdRefPrestation() Group by the ID_REF_PRESTATION column
 * @method TPrestationQuery groupByCodeLibellePrestation() Group by the CODE_LIBELLE_PRESTATION column
 * @method TPrestationQuery groupByIdTypePrestation() Group by the ID_TYPE_PRESTATION column
 * @method TPrestationQuery groupByRdvSimilaire() Group by the RDV_SIMILAIRE column
 * @method TPrestationQuery groupByNbJourRdvSimilaire() Group by the NB_JOUR_RDV_SIMILAIRE column
 * @method TPrestationQuery groupByDelaiMin() Group by the DELAI_MIN column
 * @method TPrestationQuery groupByPeriodicite() Group by the PERIODICITE column
 * @method TPrestationQuery groupByRessourceVisible() Group by the RESSOURCE_VISIBLE column
 * @method TPrestationQuery groupByRessourceObligatoire() Group by the RESSOURCE_OBLIGATOIRE column
 * @method TPrestationQuery groupByIdParametreForm() Group by the ID_PARAMETRE_FORM column
 * @method TPrestationQuery groupByCodeCommentaire() Group by the CODE_COMMENTAIRE column
 * @method TPrestationQuery groupByReferentVisible() Group by the REFERENT_VISIBLE column
 * @method TPrestationQuery groupByIdParametragePrestation() Group by the ID_PARAMETRAGE_PRESTATION column
 * @method TPrestationQuery groupByIdChampsSupp1() Group by the ID_CHAMPS_SUPP_1 column
 * @method TPrestationQuery groupByIdChampsSupp2() Group by the ID_CHAMPS_SUPP_2 column
 * @method TPrestationQuery groupByIdChampsSupp3() Group by the ID_CHAMPS_SUPP_3 column
 * @method TPrestationQuery groupByVisioconference() Group by the VISIOCONFERENCE column
 * @method TPrestationQuery groupByRdvGroupe() Group by the RDV_GROUPE column
 * @method TPrestationQuery groupByNombreMaxParticipants() Group by the NOMBRE_MAX_PARTICIPANTS column
 * @method TPrestationQuery groupByTypeSession() Group by the TYPE_SESSION column
 *
 * @method TPrestationQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TPrestationQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TPrestationQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TPrestationQuery leftJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 * @method TPrestationQuery rightJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 * @method TPrestationQuery innerJoinTTraductionRelatedByCodeCommentaire($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
 *
 * @method TPrestationQuery leftJoinTTraductionRelatedByCodeLibellePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibellePrestation relation
 * @method TPrestationQuery rightJoinTTraductionRelatedByCodeLibellePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibellePrestation relation
 * @method TPrestationQuery innerJoinTTraductionRelatedByCodeLibellePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibellePrestation relation
 *
 * @method TPrestationQuery leftJoinTParametragePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametragePrestation relation
 * @method TPrestationQuery rightJoinTParametragePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametragePrestation relation
 * @method TPrestationQuery innerJoinTParametragePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametragePrestation relation
 *
 * @method TPrestationQuery leftJoinTParametreForm($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreForm relation
 * @method TPrestationQuery rightJoinTParametreForm($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreForm relation
 * @method TPrestationQuery innerJoinTParametreForm($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreForm relation
 *
 * @method TPrestationQuery leftJoinTRefPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefPrestation relation
 * @method TPrestationQuery rightJoinTRefPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefPrestation relation
 * @method TPrestationQuery innerJoinTRefPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefPrestation relation
 *
 * @method TPrestationQuery leftJoinTTypePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTypePrestation relation
 * @method TPrestationQuery rightJoinTTypePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTypePrestation relation
 * @method TPrestationQuery innerJoinTTypePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TTypePrestation relation
 *
 * @method TPrestationQuery leftJoinTChampsSuppRelatedByIdChampsSupp1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp1 relation
 * @method TPrestationQuery rightJoinTChampsSuppRelatedByIdChampsSupp1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp1 relation
 * @method TPrestationQuery innerJoinTChampsSuppRelatedByIdChampsSupp1($relationAlias = null) Adds a INNER JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp1 relation
 *
 * @method TPrestationQuery leftJoinTChampsSuppRelatedByIdChampsSupp2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp2 relation
 * @method TPrestationQuery rightJoinTChampsSuppRelatedByIdChampsSupp2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp2 relation
 * @method TPrestationQuery innerJoinTChampsSuppRelatedByIdChampsSupp2($relationAlias = null) Adds a INNER JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp2 relation
 *
 * @method TPrestationQuery leftJoinTChampsSuppRelatedByIdChampsSupp3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp3 relation
 * @method TPrestationQuery rightJoinTChampsSuppRelatedByIdChampsSupp3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp3 relation
 * @method TPrestationQuery innerJoinTChampsSuppRelatedByIdChampsSupp3($relationAlias = null) Adds a INNER JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp3 relation
 *
 * @method TPrestationQuery leftJoinTAgenda($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgenda relation
 * @method TPrestationQuery rightJoinTAgenda($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgenda relation
 * @method TPrestationQuery innerJoinTAgenda($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgenda relation
 *
 * @method TPrestationQuery leftJoinTAgent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgent relation
 * @method TPrestationQuery rightJoinTAgent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgent relation
 * @method TPrestationQuery innerJoinTAgent($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgent relation
 *
 * @method TPrestationQuery leftJoinTAgentPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentPrestation relation
 * @method TPrestationQuery rightJoinTAgentPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentPrestation relation
 * @method TPrestationQuery innerJoinTAgentPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentPrestation relation
 *
 * @method TPrestationQuery leftJoinTDelaiObtention($relationAlias = null) Adds a LEFT JOIN clause to the query using the TDelaiObtention relation
 * @method TPrestationQuery rightJoinTDelaiObtention($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TDelaiObtention relation
 * @method TPrestationQuery innerJoinTDelaiObtention($relationAlias = null) Adds a INNER JOIN clause to the query using the TDelaiObtention relation
 *
 * @method TPrestationQuery leftJoinTPiecePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPiecePrestation relation
 * @method TPrestationQuery rightJoinTPiecePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPiecePrestation relation
 * @method TPrestationQuery innerJoinTPiecePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPiecePrestation relation
 *
 * @method TPrestationQuery leftJoinTRendezVous($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVous relation
 * @method TPrestationQuery rightJoinTRendezVous($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVous relation
 * @method TPrestationQuery innerJoinTRendezVous($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVous relation
 *
 * @method TPrestation findOne(PropelPDO $con = null) Return the first TPrestation matching the query
 * @method TPrestation findOneOrCreate(PropelPDO $con = null) Return the first TPrestation matching the query, or a new TPrestation object populated from the query conditions when no match is found
 *
 * @method TPrestation findOneByIdRefPrestation(int $ID_REF_PRESTATION) Return the first TPrestation filtered by the ID_REF_PRESTATION column
 * @method TPrestation findOneByCodeLibellePrestation(int $CODE_LIBELLE_PRESTATION) Return the first TPrestation filtered by the CODE_LIBELLE_PRESTATION column
 * @method TPrestation findOneByIdTypePrestation(int $ID_TYPE_PRESTATION) Return the first TPrestation filtered by the ID_TYPE_PRESTATION column
 * @method TPrestation findOneByRdvSimilaire(string $RDV_SIMILAIRE) Return the first TPrestation filtered by the RDV_SIMILAIRE column
 * @method TPrestation findOneByNbJourRdvSimilaire(int $NB_JOUR_RDV_SIMILAIRE) Return the first TPrestation filtered by the NB_JOUR_RDV_SIMILAIRE column
 * @method TPrestation findOneByDelaiMin(int $DELAI_MIN) Return the first TPrestation filtered by the DELAI_MIN column
 * @method TPrestation findOneByPeriodicite(int $PERIODICITE) Return the first TPrestation filtered by the PERIODICITE column
 * @method TPrestation findOneByRessourceVisible(string $RESSOURCE_VISIBLE) Return the first TPrestation filtered by the RESSOURCE_VISIBLE column
 * @method TPrestation findOneByRessourceObligatoire(string $RESSOURCE_OBLIGATOIRE) Return the first TPrestation filtered by the RESSOURCE_OBLIGATOIRE column
 * @method TPrestation findOneByIdParametreForm(int $ID_PARAMETRE_FORM) Return the first TPrestation filtered by the ID_PARAMETRE_FORM column
 * @method TPrestation findOneByCodeCommentaire(int $CODE_COMMENTAIRE) Return the first TPrestation filtered by the CODE_COMMENTAIRE column
 * @method TPrestation findOneByReferentVisible(string $REFERENT_VISIBLE) Return the first TPrestation filtered by the REFERENT_VISIBLE column
 * @method TPrestation findOneByIdParametragePrestation(int $ID_PARAMETRAGE_PRESTATION) Return the first TPrestation filtered by the ID_PARAMETRAGE_PRESTATION column
 * @method TPrestation findOneByIdChampsSupp1(int $ID_CHAMPS_SUPP_1) Return the first TPrestation filtered by the ID_CHAMPS_SUPP_1 column
 * @method TPrestation findOneByIdChampsSupp2(int $ID_CHAMPS_SUPP_2) Return the first TPrestation filtered by the ID_CHAMPS_SUPP_2 column
 * @method TPrestation findOneByIdChampsSupp3(int $ID_CHAMPS_SUPP_3) Return the first TPrestation filtered by the ID_CHAMPS_SUPP_3 column
 * @method TPrestation findOneByVisioconference(string $VISIOCONFERENCE) Return the first TPrestation filtered by the VISIOCONFERENCE column
 * @method TPrestation findOneByRdvGroupe(string $RDV_GROUPE) Return the first TPrestation filtered by the RDV_GROUPE column
 * @method TPrestation findOneByNombreMaxParticipants(int $NOMBRE_MAX_PARTICIPANTS) Return the first TPrestation filtered by the NOMBRE_MAX_PARTICIPANTS column
 * @method TPrestation findOneByTypeSession(string $TYPE_SESSION) Return the first TPrestation filtered by the TYPE_SESSION column
 *
 * @method array findByIdPrestation(int $ID_PRESTATION) Return TPrestation objects filtered by the ID_PRESTATION column
 * @method array findByIdRefPrestation(int $ID_REF_PRESTATION) Return TPrestation objects filtered by the ID_REF_PRESTATION column
 * @method array findByCodeLibellePrestation(int $CODE_LIBELLE_PRESTATION) Return TPrestation objects filtered by the CODE_LIBELLE_PRESTATION column
 * @method array findByIdTypePrestation(int $ID_TYPE_PRESTATION) Return TPrestation objects filtered by the ID_TYPE_PRESTATION column
 * @method array findByRdvSimilaire(string $RDV_SIMILAIRE) Return TPrestation objects filtered by the RDV_SIMILAIRE column
 * @method array findByNbJourRdvSimilaire(int $NB_JOUR_RDV_SIMILAIRE) Return TPrestation objects filtered by the NB_JOUR_RDV_SIMILAIRE column
 * @method array findByDelaiMin(int $DELAI_MIN) Return TPrestation objects filtered by the DELAI_MIN column
 * @method array findByPeriodicite(int $PERIODICITE) Return TPrestation objects filtered by the PERIODICITE column
 * @method array findByRessourceVisible(string $RESSOURCE_VISIBLE) Return TPrestation objects filtered by the RESSOURCE_VISIBLE column
 * @method array findByRessourceObligatoire(string $RESSOURCE_OBLIGATOIRE) Return TPrestation objects filtered by the RESSOURCE_OBLIGATOIRE column
 * @method array findByIdParametreForm(int $ID_PARAMETRE_FORM) Return TPrestation objects filtered by the ID_PARAMETRE_FORM column
 * @method array findByCodeCommentaire(int $CODE_COMMENTAIRE) Return TPrestation objects filtered by the CODE_COMMENTAIRE column
 * @method array findByReferentVisible(string $REFERENT_VISIBLE) Return TPrestation objects filtered by the REFERENT_VISIBLE column
 * @method array findByIdParametragePrestation(int $ID_PARAMETRAGE_PRESTATION) Return TPrestation objects filtered by the ID_PARAMETRAGE_PRESTATION column
 * @method array findByIdChampsSupp1(int $ID_CHAMPS_SUPP_1) Return TPrestation objects filtered by the ID_CHAMPS_SUPP_1 column
 * @method array findByIdChampsSupp2(int $ID_CHAMPS_SUPP_2) Return TPrestation objects filtered by the ID_CHAMPS_SUPP_2 column
 * @method array findByIdChampsSupp3(int $ID_CHAMPS_SUPP_3) Return TPrestation objects filtered by the ID_CHAMPS_SUPP_3 column
 * @method array findByVisioconference(string $VISIOCONFERENCE) Return TPrestation objects filtered by the VISIOCONFERENCE column
 * @method array findByRdvGroupe(string $RDV_GROUPE) Return TPrestation objects filtered by the RDV_GROUPE column
 * @method array findByNombreMaxParticipants(int $NOMBRE_MAX_PARTICIPANTS) Return TPrestation objects filtered by the NOMBRE_MAX_PARTICIPANTS column
 * @method array findByTypeSession(string $TYPE_SESSION) Return TPrestation objects filtered by the TYPE_SESSION column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPrestationQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTPrestationQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TPrestation', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TPrestationQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TPrestationQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TPrestationQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TPrestationQuery) {
            return $criteria;
        }
        $query = new TPrestationQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TPrestation|TPrestation[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TPrestationPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPrestation A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdPrestation($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPrestation A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PRESTATION`, `ID_REF_PRESTATION`, `CODE_LIBELLE_PRESTATION`, `ID_TYPE_PRESTATION`, `RDV_SIMILAIRE`, `NB_JOUR_RDV_SIMILAIRE`, `DELAI_MIN`, `PERIODICITE`, `RESSOURCE_VISIBLE`, `RESSOURCE_OBLIGATOIRE`, `ID_PARAMETRE_FORM`, `CODE_COMMENTAIRE`, `REFERENT_VISIBLE`, `ID_PARAMETRAGE_PRESTATION`, `ID_CHAMPS_SUPP_1`, `ID_CHAMPS_SUPP_2`, `ID_CHAMPS_SUPP_3`, `VISIOCONFERENCE`, `RDV_GROUPE`, `NOMBRE_MAX_PARTICIPANTS`, `TYPE_SESSION` FROM `T_PRESTATION` WHERE `ID_PRESTATION` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TPrestation();
            $obj->hydrate($row);
            TPrestationPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TPrestation|TPrestation[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TPrestation[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TPrestationPeer::ID_PRESTATION, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TPrestationPeer::ID_PRESTATION, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPrestation(1234); // WHERE ID_PRESTATION = 1234
     * $query->filterByIdPrestation(array(12, 34)); // WHERE ID_PRESTATION IN (12, 34)
     * $query->filterByIdPrestation(array('min' => 12)); // WHERE ID_PRESTATION >= 12
     * $query->filterByIdPrestation(array('max' => 12)); // WHERE ID_PRESTATION <= 12
     * </code>
     *
     * @param     mixed $idPrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdPrestation($idPrestation = null, $comparison = null)
    {
        if (is_array($idPrestation)) {
            $useMinMax = false;
            if (isset($idPrestation['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_PRESTATION, $idPrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPrestation['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_PRESTATION, $idPrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_PRESTATION, $idPrestation, $comparison);
    }

    /**
     * Filter the query on the ID_REF_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRefPrestation(1234); // WHERE ID_REF_PRESTATION = 1234
     * $query->filterByIdRefPrestation(array(12, 34)); // WHERE ID_REF_PRESTATION IN (12, 34)
     * $query->filterByIdRefPrestation(array('min' => 12)); // WHERE ID_REF_PRESTATION >= 12
     * $query->filterByIdRefPrestation(array('max' => 12)); // WHERE ID_REF_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTRefPrestation()
     *
     * @param     mixed $idRefPrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdRefPrestation($idRefPrestation = null, $comparison = null)
    {
        if (is_array($idRefPrestation)) {
            $useMinMax = false;
            if (isset($idRefPrestation['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_REF_PRESTATION, $idRefPrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRefPrestation['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_REF_PRESTATION, $idRefPrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_REF_PRESTATION, $idRefPrestation, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibellePrestation(1234); // WHERE CODE_LIBELLE_PRESTATION = 1234
     * $query->filterByCodeLibellePrestation(array(12, 34)); // WHERE CODE_LIBELLE_PRESTATION IN (12, 34)
     * $query->filterByCodeLibellePrestation(array('min' => 12)); // WHERE CODE_LIBELLE_PRESTATION >= 12
     * $query->filterByCodeLibellePrestation(array('max' => 12)); // WHERE CODE_LIBELLE_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibellePrestation()
     *
     * @param     mixed $codeLibellePrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByCodeLibellePrestation($codeLibellePrestation = null, $comparison = null)
    {
        if (is_array($codeLibellePrestation)) {
            $useMinMax = false;
            if (isset($codeLibellePrestation['min'])) {
                $this->addUsingAlias(TPrestationPeer::CODE_LIBELLE_PRESTATION, $codeLibellePrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibellePrestation['max'])) {
                $this->addUsingAlias(TPrestationPeer::CODE_LIBELLE_PRESTATION, $codeLibellePrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::CODE_LIBELLE_PRESTATION, $codeLibellePrestation, $comparison);
    }

    /**
     * Filter the query on the ID_TYPE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdTypePrestation(1234); // WHERE ID_TYPE_PRESTATION = 1234
     * $query->filterByIdTypePrestation(array(12, 34)); // WHERE ID_TYPE_PRESTATION IN (12, 34)
     * $query->filterByIdTypePrestation(array('min' => 12)); // WHERE ID_TYPE_PRESTATION >= 12
     * $query->filterByIdTypePrestation(array('max' => 12)); // WHERE ID_TYPE_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTTypePrestation()
     *
     * @param     mixed $idTypePrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdTypePrestation($idTypePrestation = null, $comparison = null)
    {
        if (is_array($idTypePrestation)) {
            $useMinMax = false;
            if (isset($idTypePrestation['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_TYPE_PRESTATION, $idTypePrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idTypePrestation['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_TYPE_PRESTATION, $idTypePrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_TYPE_PRESTATION, $idTypePrestation, $comparison);
    }

    /**
     * Filter the query on the RDV_SIMILAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByRdvSimilaire('fooValue');   // WHERE RDV_SIMILAIRE = 'fooValue'
     * $query->filterByRdvSimilaire('%fooValue%'); // WHERE RDV_SIMILAIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rdvSimilaire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByRdvSimilaire($rdvSimilaire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rdvSimilaire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rdvSimilaire)) {
                $rdvSimilaire = str_replace('*', '%', $rdvSimilaire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::RDV_SIMILAIRE, $rdvSimilaire, $comparison);
    }

    /**
     * Filter the query on the NB_JOUR_RDV_SIMILAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByNbJourRdvSimilaire(1234); // WHERE NB_JOUR_RDV_SIMILAIRE = 1234
     * $query->filterByNbJourRdvSimilaire(array(12, 34)); // WHERE NB_JOUR_RDV_SIMILAIRE IN (12, 34)
     * $query->filterByNbJourRdvSimilaire(array('min' => 12)); // WHERE NB_JOUR_RDV_SIMILAIRE >= 12
     * $query->filterByNbJourRdvSimilaire(array('max' => 12)); // WHERE NB_JOUR_RDV_SIMILAIRE <= 12
     * </code>
     *
     * @param     mixed $nbJourRdvSimilaire The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByNbJourRdvSimilaire($nbJourRdvSimilaire = null, $comparison = null)
    {
        if (is_array($nbJourRdvSimilaire)) {
            $useMinMax = false;
            if (isset($nbJourRdvSimilaire['min'])) {
                $this->addUsingAlias(TPrestationPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($nbJourRdvSimilaire['max'])) {
                $this->addUsingAlias(TPrestationPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::NB_JOUR_RDV_SIMILAIRE, $nbJourRdvSimilaire, $comparison);
    }

    /**
     * Filter the query on the DELAI_MIN column
     *
     * Example usage:
     * <code>
     * $query->filterByDelaiMin(1234); // WHERE DELAI_MIN = 1234
     * $query->filterByDelaiMin(array(12, 34)); // WHERE DELAI_MIN IN (12, 34)
     * $query->filterByDelaiMin(array('min' => 12)); // WHERE DELAI_MIN >= 12
     * $query->filterByDelaiMin(array('max' => 12)); // WHERE DELAI_MIN <= 12
     * </code>
     *
     * @param     mixed $delaiMin The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByDelaiMin($delaiMin = null, $comparison = null)
    {
        if (is_array($delaiMin)) {
            $useMinMax = false;
            if (isset($delaiMin['min'])) {
                $this->addUsingAlias(TPrestationPeer::DELAI_MIN, $delaiMin['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($delaiMin['max'])) {
                $this->addUsingAlias(TPrestationPeer::DELAI_MIN, $delaiMin['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::DELAI_MIN, $delaiMin, $comparison);
    }

    /**
     * Filter the query on the PERIODICITE column
     *
     * Example usage:
     * <code>
     * $query->filterByPeriodicite(1234); // WHERE PERIODICITE = 1234
     * $query->filterByPeriodicite(array(12, 34)); // WHERE PERIODICITE IN (12, 34)
     * $query->filterByPeriodicite(array('min' => 12)); // WHERE PERIODICITE >= 12
     * $query->filterByPeriodicite(array('max' => 12)); // WHERE PERIODICITE <= 12
     * </code>
     *
     * @param     mixed $periodicite The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByPeriodicite($periodicite = null, $comparison = null)
    {
        if (is_array($periodicite)) {
            $useMinMax = false;
            if (isset($periodicite['min'])) {
                $this->addUsingAlias(TPrestationPeer::PERIODICITE, $periodicite['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($periodicite['max'])) {
                $this->addUsingAlias(TPrestationPeer::PERIODICITE, $periodicite['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::PERIODICITE, $periodicite, $comparison);
    }

    /**
     * Filter the query on the RESSOURCE_VISIBLE column
     *
     * Example usage:
     * <code>
     * $query->filterByRessourceVisible('fooValue');   // WHERE RESSOURCE_VISIBLE = 'fooValue'
     * $query->filterByRessourceVisible('%fooValue%'); // WHERE RESSOURCE_VISIBLE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ressourceVisible The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByRessourceVisible($ressourceVisible = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ressourceVisible)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ressourceVisible)) {
                $ressourceVisible = str_replace('*', '%', $ressourceVisible);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::RESSOURCE_VISIBLE, $ressourceVisible, $comparison);
    }

    /**
     * Filter the query on the RESSOURCE_OBLIGATOIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByRessourceObligatoire('fooValue');   // WHERE RESSOURCE_OBLIGATOIRE = 'fooValue'
     * $query->filterByRessourceObligatoire('%fooValue%'); // WHERE RESSOURCE_OBLIGATOIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $ressourceObligatoire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByRessourceObligatoire($ressourceObligatoire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($ressourceObligatoire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $ressourceObligatoire)) {
                $ressourceObligatoire = str_replace('*', '%', $ressourceObligatoire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::RESSOURCE_OBLIGATOIRE, $ressourceObligatoire, $comparison);
    }

    /**
     * Filter the query on the ID_PARAMETRE_FORM column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametreForm(1234); // WHERE ID_PARAMETRE_FORM = 1234
     * $query->filterByIdParametreForm(array(12, 34)); // WHERE ID_PARAMETRE_FORM IN (12, 34)
     * $query->filterByIdParametreForm(array('min' => 12)); // WHERE ID_PARAMETRE_FORM >= 12
     * $query->filterByIdParametreForm(array('max' => 12)); // WHERE ID_PARAMETRE_FORM <= 12
     * </code>
     *
     * @see       filterByTParametreForm()
     *
     * @param     mixed $idParametreForm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdParametreForm($idParametreForm = null, $comparison = null)
    {
        if (is_array($idParametreForm)) {
            $useMinMax = false;
            if (isset($idParametreForm['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_PARAMETRE_FORM, $idParametreForm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametreForm['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_PARAMETRE_FORM, $idParametreForm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_PARAMETRE_FORM, $idParametreForm, $comparison);
    }

    /**
     * Filter the query on the CODE_COMMENTAIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeCommentaire(1234); // WHERE CODE_COMMENTAIRE = 1234
     * $query->filterByCodeCommentaire(array(12, 34)); // WHERE CODE_COMMENTAIRE IN (12, 34)
     * $query->filterByCodeCommentaire(array('min' => 12)); // WHERE CODE_COMMENTAIRE >= 12
     * $query->filterByCodeCommentaire(array('max' => 12)); // WHERE CODE_COMMENTAIRE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeCommentaire()
     *
     * @param     mixed $codeCommentaire The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByCodeCommentaire($codeCommentaire = null, $comparison = null)
    {
        if (is_array($codeCommentaire)) {
            $useMinMax = false;
            if (isset($codeCommentaire['min'])) {
                $this->addUsingAlias(TPrestationPeer::CODE_COMMENTAIRE, $codeCommentaire['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeCommentaire['max'])) {
                $this->addUsingAlias(TPrestationPeer::CODE_COMMENTAIRE, $codeCommentaire['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::CODE_COMMENTAIRE, $codeCommentaire, $comparison);
    }

    /**
     * Filter the query on the REFERENT_VISIBLE column
     *
     * Example usage:
     * <code>
     * $query->filterByReferentVisible('fooValue');   // WHERE REFERENT_VISIBLE = 'fooValue'
     * $query->filterByReferentVisible('%fooValue%'); // WHERE REFERENT_VISIBLE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $referentVisible The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByReferentVisible($referentVisible = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($referentVisible)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $referentVisible)) {
                $referentVisible = str_replace('*', '%', $referentVisible);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::REFERENT_VISIBLE, $referentVisible, $comparison);
    }

    /**
     * Filter the query on the ID_PARAMETRAGE_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametragePrestation(1234); // WHERE ID_PARAMETRAGE_PRESTATION = 1234
     * $query->filterByIdParametragePrestation(array(12, 34)); // WHERE ID_PARAMETRAGE_PRESTATION IN (12, 34)
     * $query->filterByIdParametragePrestation(array('min' => 12)); // WHERE ID_PARAMETRAGE_PRESTATION >= 12
     * $query->filterByIdParametragePrestation(array('max' => 12)); // WHERE ID_PARAMETRAGE_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTParametragePrestation()
     *
     * @param     mixed $idParametragePrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdParametragePrestation($idParametragePrestation = null, $comparison = null)
    {
        if (is_array($idParametragePrestation)) {
            $useMinMax = false;
            if (isset($idParametragePrestation['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, $idParametragePrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametragePrestation['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, $idParametragePrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, $idParametragePrestation, $comparison);
    }

    /**
     * Filter the query on the ID_CHAMPS_SUPP_1 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdChampsSupp1(1234); // WHERE ID_CHAMPS_SUPP_1 = 1234
     * $query->filterByIdChampsSupp1(array(12, 34)); // WHERE ID_CHAMPS_SUPP_1 IN (12, 34)
     * $query->filterByIdChampsSupp1(array('min' => 12)); // WHERE ID_CHAMPS_SUPP_1 >= 12
     * $query->filterByIdChampsSupp1(array('max' => 12)); // WHERE ID_CHAMPS_SUPP_1 <= 12
     * </code>
     *
     * @see       filterByTChampsSuppRelatedByIdChampsSupp1()
     *
     * @param     mixed $idChampsSupp1 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdChampsSupp1($idChampsSupp1 = null, $comparison = null)
    {
        if (is_array($idChampsSupp1)) {
            $useMinMax = false;
            if (isset($idChampsSupp1['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_1, $idChampsSupp1['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idChampsSupp1['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_1, $idChampsSupp1['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_1, $idChampsSupp1, $comparison);
    }

    /**
     * Filter the query on the ID_CHAMPS_SUPP_2 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdChampsSupp2(1234); // WHERE ID_CHAMPS_SUPP_2 = 1234
     * $query->filterByIdChampsSupp2(array(12, 34)); // WHERE ID_CHAMPS_SUPP_2 IN (12, 34)
     * $query->filterByIdChampsSupp2(array('min' => 12)); // WHERE ID_CHAMPS_SUPP_2 >= 12
     * $query->filterByIdChampsSupp2(array('max' => 12)); // WHERE ID_CHAMPS_SUPP_2 <= 12
     * </code>
     *
     * @see       filterByTChampsSuppRelatedByIdChampsSupp2()
     *
     * @param     mixed $idChampsSupp2 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdChampsSupp2($idChampsSupp2 = null, $comparison = null)
    {
        if (is_array($idChampsSupp2)) {
            $useMinMax = false;
            if (isset($idChampsSupp2['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_2, $idChampsSupp2['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idChampsSupp2['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_2, $idChampsSupp2['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_2, $idChampsSupp2, $comparison);
    }

    /**
     * Filter the query on the ID_CHAMPS_SUPP_3 column
     *
     * Example usage:
     * <code>
     * $query->filterByIdChampsSupp3(1234); // WHERE ID_CHAMPS_SUPP_3 = 1234
     * $query->filterByIdChampsSupp3(array(12, 34)); // WHERE ID_CHAMPS_SUPP_3 IN (12, 34)
     * $query->filterByIdChampsSupp3(array('min' => 12)); // WHERE ID_CHAMPS_SUPP_3 >= 12
     * $query->filterByIdChampsSupp3(array('max' => 12)); // WHERE ID_CHAMPS_SUPP_3 <= 12
     * </code>
     *
     * @see       filterByTChampsSuppRelatedByIdChampsSupp3()
     *
     * @param     mixed $idChampsSupp3 The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByIdChampsSupp3($idChampsSupp3 = null, $comparison = null)
    {
        if (is_array($idChampsSupp3)) {
            $useMinMax = false;
            if (isset($idChampsSupp3['min'])) {
                $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_3, $idChampsSupp3['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idChampsSupp3['max'])) {
                $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_3, $idChampsSupp3['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_3, $idChampsSupp3, $comparison);
    }

    /**
     * Filter the query on the VISIOCONFERENCE column
     *
     * Example usage:
     * <code>
     * $query->filterByVisioconference('fooValue');   // WHERE VISIOCONFERENCE = 'fooValue'
     * $query->filterByVisioconference('%fooValue%'); // WHERE VISIOCONFERENCE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $visioconference The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByVisioconference($visioconference = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($visioconference)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $visioconference)) {
                $visioconference = str_replace('*', '%', $visioconference);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::VISIOCONFERENCE, $visioconference, $comparison);
    }

    /**
     * Filter the query on the RDV_GROUPE column
     *
     * Example usage:
     * <code>
     * $query->filterByRdvGroupe('fooValue');   // WHERE RDV_GROUPE = 'fooValue'
     * $query->filterByRdvGroupe('%fooValue%'); // WHERE RDV_GROUPE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $rdvGroupe The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByRdvGroupe($rdvGroupe = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($rdvGroupe)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $rdvGroupe)) {
                $rdvGroupe = str_replace('*', '%', $rdvGroupe);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::RDV_GROUPE, $rdvGroupe, $comparison);
    }

    /**
     * Filter the query on the NOMBRE_MAX_PARTICIPANTS column
     *
     * Example usage:
     * <code>
     * $query->filterByNombreMaxParticipants(1234); // WHERE NOMBRE_MAX_PARTICIPANTS = 1234
     * $query->filterByNombreMaxParticipants(array(12, 34)); // WHERE NOMBRE_MAX_PARTICIPANTS IN (12, 34)
     * $query->filterByNombreMaxParticipants(array('min' => 12)); // WHERE NOMBRE_MAX_PARTICIPANTS >= 12
     * $query->filterByNombreMaxParticipants(array('max' => 12)); // WHERE NOMBRE_MAX_PARTICIPANTS <= 12
     * </code>
     *
     * @param     mixed $nombreMaxParticipants The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByNombreMaxParticipants($nombreMaxParticipants = null, $comparison = null)
    {
        if (is_array($nombreMaxParticipants)) {
            $useMinMax = false;
            if (isset($nombreMaxParticipants['min'])) {
                $this->addUsingAlias(TPrestationPeer::NOMBRE_MAX_PARTICIPANTS, $nombreMaxParticipants['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($nombreMaxParticipants['max'])) {
                $this->addUsingAlias(TPrestationPeer::NOMBRE_MAX_PARTICIPANTS, $nombreMaxParticipants['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::NOMBRE_MAX_PARTICIPANTS, $nombreMaxParticipants, $comparison);
    }

    /**
     * Filter the query on the TYPE_SESSION column
     *
     * Example usage:
     * <code>
     * $query->filterByTypeSession('fooValue');   // WHERE TYPE_SESSION = 'fooValue'
     * $query->filterByTypeSession('%fooValue%'); // WHERE TYPE_SESSION LIKE '%fooValue%'
     * </code>
     *
     * @param     string $typeSession The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function filterByTypeSession($typeSession = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($typeSession)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $typeSession)) {
                $typeSession = str_replace('*', '%', $typeSession);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPrestationPeer::TYPE_SESSION, $typeSession, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeCommentaire($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TPrestationPeer::CODE_COMMENTAIRE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::CODE_COMMENTAIRE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeCommentaire() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeCommentaire relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeCommentaire($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeCommentaire');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeCommentaire');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeCommentaire relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeCommentaireQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeCommentaire($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeCommentaire', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibellePrestation($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TPrestationPeer::CODE_LIBELLE_PRESTATION, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::CODE_LIBELLE_PRESTATION, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibellePrestation() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibellePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibellePrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibellePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibellePrestation');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibellePrestation relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibellePrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibellePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibellePrestation', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TParametragePrestation object
     *
     * @param   TParametragePrestation|PropelObjectCollection $tParametragePrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametragePrestation($tParametragePrestation, $comparison = null)
    {
        if ($tParametragePrestation instanceof TParametragePrestation) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, $tParametragePrestation->getIdParametragePrestation(), $comparison);
        } elseif ($tParametragePrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, $tParametragePrestation->toKeyValue('PrimaryKey', 'IdParametragePrestation'), $comparison);
        } else {
            throw new PropelException('filterByTParametragePrestation() only accepts arguments of type TParametragePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametragePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTParametragePrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametragePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametragePrestation');
        }

        return $this;
    }

    /**
     * Use the TParametragePrestation relation TParametragePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametragePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTParametragePrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametragePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametragePrestation', 'TParametragePrestationQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreForm($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PARAMETRE_FORM, $tParametreForm->getIdParametreForm(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::ID_PARAMETRE_FORM, $tParametreForm->toKeyValue('PrimaryKey', 'IdParametreForm'), $comparison);
        } else {
            throw new PropelException('filterByTParametreForm() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreForm relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTParametreForm($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreForm');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreForm');
        }

        return $this;
    }

    /**
     * Use the TParametreForm relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreForm($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreForm', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TRefPrestation object
     *
     * @param   TRefPrestation|PropelObjectCollection $tRefPrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefPrestation($tRefPrestation, $comparison = null)
    {
        if ($tRefPrestation instanceof TRefPrestation) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_REF_PRESTATION, $tRefPrestation->getIdRefPrestation(), $comparison);
        } elseif ($tRefPrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::ID_REF_PRESTATION, $tRefPrestation->toKeyValue('PrimaryKey', 'IdRefPrestation'), $comparison);
        } else {
            throw new PropelException('filterByTRefPrestation() only accepts arguments of type TRefPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTRefPrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefPrestation');
        }

        return $this;
    }

    /**
     * Use the TRefPrestation relation TRefPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefPrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRefPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefPrestation', 'TRefPrestationQuery');
    }

    /**
     * Filter the query by a related TTypePrestation object
     *
     * @param   TTypePrestation|PropelObjectCollection $tTypePrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTypePrestation($tTypePrestation, $comparison = null)
    {
        if ($tTypePrestation instanceof TTypePrestation) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_TYPE_PRESTATION, $tTypePrestation->getIdTypePrestation(), $comparison);
        } elseif ($tTypePrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::ID_TYPE_PRESTATION, $tTypePrestation->toKeyValue('PrimaryKey', 'IdTypePrestation'), $comparison);
        } else {
            throw new PropelException('filterByTTypePrestation() only accepts arguments of type TTypePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTypePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTTypePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTypePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTypePrestation');
        }

        return $this;
    }

    /**
     * Use the TTypePrestation relation TTypePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTypePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTTypePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTypePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTypePrestation', 'TTypePrestationQuery');
    }

    /**
     * Filter the query by a related TChampsSupp object
     *
     * @param   TChampsSupp|PropelObjectCollection $tChampsSupp The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTChampsSuppRelatedByIdChampsSupp1($tChampsSupp, $comparison = null)
    {
        if ($tChampsSupp instanceof TChampsSupp) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_1, $tChampsSupp->getIdChampsSupp(), $comparison);
        } elseif ($tChampsSupp instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_1, $tChampsSupp->toKeyValue('PrimaryKey', 'IdChampsSupp'), $comparison);
        } else {
            throw new PropelException('filterByTChampsSuppRelatedByIdChampsSupp1() only accepts arguments of type TChampsSupp or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTChampsSuppRelatedByIdChampsSupp1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TChampsSuppRelatedByIdChampsSupp1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TChampsSuppRelatedByIdChampsSupp1');
        }

        return $this;
    }

    /**
     * Use the TChampsSuppRelatedByIdChampsSupp1 relation TChampsSupp object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TChampsSuppQuery A secondary query class using the current class as primary query
     */
    public function useTChampsSuppRelatedByIdChampsSupp1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTChampsSuppRelatedByIdChampsSupp1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TChampsSuppRelatedByIdChampsSupp1', 'TChampsSuppQuery');
    }

    /**
     * Filter the query by a related TChampsSupp object
     *
     * @param   TChampsSupp|PropelObjectCollection $tChampsSupp The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTChampsSuppRelatedByIdChampsSupp2($tChampsSupp, $comparison = null)
    {
        if ($tChampsSupp instanceof TChampsSupp) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_2, $tChampsSupp->getIdChampsSupp(), $comparison);
        } elseif ($tChampsSupp instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_2, $tChampsSupp->toKeyValue('PrimaryKey', 'IdChampsSupp'), $comparison);
        } else {
            throw new PropelException('filterByTChampsSuppRelatedByIdChampsSupp2() only accepts arguments of type TChampsSupp or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTChampsSuppRelatedByIdChampsSupp2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TChampsSuppRelatedByIdChampsSupp2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TChampsSuppRelatedByIdChampsSupp2');
        }

        return $this;
    }

    /**
     * Use the TChampsSuppRelatedByIdChampsSupp2 relation TChampsSupp object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TChampsSuppQuery A secondary query class using the current class as primary query
     */
    public function useTChampsSuppRelatedByIdChampsSupp2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTChampsSuppRelatedByIdChampsSupp2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TChampsSuppRelatedByIdChampsSupp2', 'TChampsSuppQuery');
    }

    /**
     * Filter the query by a related TChampsSupp object
     *
     * @param   TChampsSupp|PropelObjectCollection $tChampsSupp The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTChampsSuppRelatedByIdChampsSupp3($tChampsSupp, $comparison = null)
    {
        if ($tChampsSupp instanceof TChampsSupp) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_3, $tChampsSupp->getIdChampsSupp(), $comparison);
        } elseif ($tChampsSupp instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPrestationPeer::ID_CHAMPS_SUPP_3, $tChampsSupp->toKeyValue('PrimaryKey', 'IdChampsSupp'), $comparison);
        } else {
            throw new PropelException('filterByTChampsSuppRelatedByIdChampsSupp3() only accepts arguments of type TChampsSupp or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TChampsSuppRelatedByIdChampsSupp3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTChampsSuppRelatedByIdChampsSupp3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TChampsSuppRelatedByIdChampsSupp3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TChampsSuppRelatedByIdChampsSupp3');
        }

        return $this;
    }

    /**
     * Use the TChampsSuppRelatedByIdChampsSupp3 relation TChampsSupp object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TChampsSuppQuery A secondary query class using the current class as primary query
     */
    public function useTChampsSuppRelatedByIdChampsSupp3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTChampsSuppRelatedByIdChampsSupp3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TChampsSuppRelatedByIdChampsSupp3', 'TChampsSuppQuery');
    }

    /**
     * Filter the query by a related TAgenda object
     *
     * @param   TAgenda|PropelObjectCollection $tAgenda  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgenda($tAgenda, $comparison = null)
    {
        if ($tAgenda instanceof TAgenda) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PRESTATION, $tAgenda->getIdPrestation(), $comparison);
        } elseif ($tAgenda instanceof PropelObjectCollection) {
            return $this
                ->useTAgendaQuery()
                ->filterByPrimaryKeys($tAgenda->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgenda() only accepts arguments of type TAgenda or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgenda relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTAgenda($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgenda');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgenda');
        }

        return $this;
    }

    /**
     * Use the TAgenda relation TAgenda object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgendaQuery A secondary query class using the current class as primary query
     */
    public function useTAgendaQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgenda($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgenda', 'TAgendaQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgent($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PRESTATION, $tAgent->getIdPrestationAttache(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgent() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTAgent($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgent');
        }

        return $this;
    }

    /**
     * Use the TAgent relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgent', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgentPrestation object
     *
     * @param   TAgentPrestation|PropelObjectCollection $tAgentPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentPrestation($tAgentPrestation, $comparison = null)
    {
        if ($tAgentPrestation instanceof TAgentPrestation) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PRESTATION, $tAgentPrestation->getIdPrestation(), $comparison);
        } elseif ($tAgentPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTAgentPrestationQuery()
                ->filterByPrimaryKeys($tAgentPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentPrestation() only accepts arguments of type TAgentPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTAgentPrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentPrestation');
        }

        return $this;
    }

    /**
     * Use the TAgentPrestation relation TAgentPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTAgentPrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTAgentPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentPrestation', 'TAgentPrestationQuery');
    }

    /**
     * Filter the query by a related TDelaiObtention object
     *
     * @param   TDelaiObtention|PropelObjectCollection $tDelaiObtention  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTDelaiObtention($tDelaiObtention, $comparison = null)
    {
        if ($tDelaiObtention instanceof TDelaiObtention) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PRESTATION, $tDelaiObtention->getIdPrestation(), $comparison);
        } elseif ($tDelaiObtention instanceof PropelObjectCollection) {
            return $this
                ->useTDelaiObtentionQuery()
                ->filterByPrimaryKeys($tDelaiObtention->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTDelaiObtention() only accepts arguments of type TDelaiObtention or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TDelaiObtention relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTDelaiObtention($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TDelaiObtention');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TDelaiObtention');
        }

        return $this;
    }

    /**
     * Use the TDelaiObtention relation TDelaiObtention object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TDelaiObtentionQuery A secondary query class using the current class as primary query
     */
    public function useTDelaiObtentionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTDelaiObtention($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TDelaiObtention', 'TDelaiObtentionQuery');
    }

    /**
     * Filter the query by a related TPiecePrestation object
     *
     * @param   TPiecePrestation|PropelObjectCollection $tPiecePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPiecePrestation($tPiecePrestation, $comparison = null)
    {
        if ($tPiecePrestation instanceof TPiecePrestation) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PRESTATION, $tPiecePrestation->getIdPrestation(), $comparison);
        } elseif ($tPiecePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTPiecePrestationQuery()
                ->filterByPrimaryKeys($tPiecePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPiecePrestation() only accepts arguments of type TPiecePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPiecePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTPiecePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPiecePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPiecePrestation');
        }

        return $this;
    }

    /**
     * Use the TPiecePrestation relation TPiecePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPiecePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPiecePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPiecePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPiecePrestation', 'TPiecePrestationQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVous($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TPrestationPeer::ID_PRESTATION, $tRendezVous->getIdPrestation(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVous() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVous relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function joinTRendezVous($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVous');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVous');
        }

        return $this;
    }

    /**
     * Use the TRendezVous relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRendezVous($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVous', 'TRendezVousQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TPrestation $tPrestation Object to remove from the list of results
     *
     * @return TPrestationQuery The current query, for fluid interface
     */
    public function prune($tPrestation = null)
    {
        if ($tPrestation) {
            $this->addUsingAlias(TPrestationPeer::ID_PRESTATION, $tPrestation->getIdPrestation(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
