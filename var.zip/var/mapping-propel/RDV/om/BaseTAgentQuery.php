<?php


/**
 * Base class that represents a query for the 'T_AGENT' table.
 *
 *
 *
 * @method TAgentQuery orderByIdAgent($order = Criteria::ASC) Order by the ID_AGENT column
 * @method TAgentQuery orderByLogin($order = Criteria::ASC) Order by the LOGIN column
 * @method TAgentQuery orderByMotDePasse($order = Criteria::ASC) Order by the MOT_DE_PASSE column
 * @method TAgentQuery orderByCodeNomUtilisateur($order = Criteria::ASC) Order by the CODE_NOM_UTILISATEUR column
 * @method TAgentQuery orderByCodePrenomUtilisateur($order = Criteria::ASC) Order by the CODE_PRENOM_UTILISATEUR column
 * @method TAgentQuery orderByCodeUtilisateur($order = Criteria::ASC) Order by the CODE_UTILISATEUR column
 * @method TAgentQuery orderByEmailUtilisateur($order = Criteria::ASC) Order by the EMAIL_UTILISATEUR column
 * @method TAgentQuery orderByTelephoneUtilisateur($order = Criteria::ASC) Order by the TELEPHONE_UTILISATEUR column
 * @method TAgentQuery orderByIdEtablissementAttache($order = Criteria::ASC) Order by the ID_ETABLISSEMENT_ATTACHE column
 * @method TAgentQuery orderByIdProfil($order = Criteria::ASC) Order by the ID_PROFIL column
 * @method TAgentQuery orderByIdOrganisationAttache($order = Criteria::ASC) Order by the ID_ORGANISATION_ATTACHE column
 * @method TAgentQuery orderByTentativesMdp($order = Criteria::ASC) Order by the TENTATIVES_MDP column
 * @method TAgentQuery orderByIdPrestationAttache($order = Criteria::ASC) Order by the ID_PRESTATION_ATTACHE column
 * @method TAgentQuery orderByIdEtablissementGere($order = Criteria::ASC) Order by the ID_ETABLISSEMENT_GERE column
 * @method TAgentQuery orderByIdOrganisationGere($order = Criteria::ASC) Order by the ID_ORGANISATION_GERE column
 * @method TAgentQuery orderByActif($order = Criteria::ASC) Order by the ACTIF column
 * @method TAgentQuery orderByAlerte($order = Criteria::ASC) Order by the ALERTE column
 *
 * @method TAgentQuery groupByIdAgent() Group by the ID_AGENT column
 * @method TAgentQuery groupByLogin() Group by the LOGIN column
 * @method TAgentQuery groupByMotDePasse() Group by the MOT_DE_PASSE column
 * @method TAgentQuery groupByCodeNomUtilisateur() Group by the CODE_NOM_UTILISATEUR column
 * @method TAgentQuery groupByCodePrenomUtilisateur() Group by the CODE_PRENOM_UTILISATEUR column
 * @method TAgentQuery groupByCodeUtilisateur() Group by the CODE_UTILISATEUR column
 * @method TAgentQuery groupByEmailUtilisateur() Group by the EMAIL_UTILISATEUR column
 * @method TAgentQuery groupByTelephoneUtilisateur() Group by the TELEPHONE_UTILISATEUR column
 * @method TAgentQuery groupByIdEtablissementAttache() Group by the ID_ETABLISSEMENT_ATTACHE column
 * @method TAgentQuery groupByIdProfil() Group by the ID_PROFIL column
 * @method TAgentQuery groupByIdOrganisationAttache() Group by the ID_ORGANISATION_ATTACHE column
 * @method TAgentQuery groupByTentativesMdp() Group by the TENTATIVES_MDP column
 * @method TAgentQuery groupByIdPrestationAttache() Group by the ID_PRESTATION_ATTACHE column
 * @method TAgentQuery groupByIdEtablissementGere() Group by the ID_ETABLISSEMENT_GERE column
 * @method TAgentQuery groupByIdOrganisationGere() Group by the ID_ORGANISATION_GERE column
 * @method TAgentQuery groupByActif() Group by the ACTIF column
 * @method TAgentQuery groupByAlerte() Group by the ALERTE column
 *
 * @method TAgentQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TAgentQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TAgentQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TAgentQuery leftJoinTTraductionRelatedByCodeNomUtilisateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeNomUtilisateur relation
 * @method TAgentQuery rightJoinTTraductionRelatedByCodeNomUtilisateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeNomUtilisateur relation
 * @method TAgentQuery innerJoinTTraductionRelatedByCodeNomUtilisateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeNomUtilisateur relation
 *
 * @method TAgentQuery leftJoinTTraductionRelatedByCodePrenomUtilisateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodePrenomUtilisateur relation
 * @method TAgentQuery rightJoinTTraductionRelatedByCodePrenomUtilisateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodePrenomUtilisateur relation
 * @method TAgentQuery innerJoinTTraductionRelatedByCodePrenomUtilisateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodePrenomUtilisateur relation
 *
 * @method TAgentQuery leftJoinTEtablissementRelatedByIdEtablissementAttache($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissementRelatedByIdEtablissementAttache relation
 * @method TAgentQuery rightJoinTEtablissementRelatedByIdEtablissementAttache($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissementRelatedByIdEtablissementAttache relation
 * @method TAgentQuery innerJoinTEtablissementRelatedByIdEtablissementAttache($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissementRelatedByIdEtablissementAttache relation
 *
 * @method TAgentQuery leftJoinTEtablissementRelatedByIdEtablissementGere($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissementRelatedByIdEtablissementGere relation
 * @method TAgentQuery rightJoinTEtablissementRelatedByIdEtablissementGere($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissementRelatedByIdEtablissementGere relation
 * @method TAgentQuery innerJoinTEtablissementRelatedByIdEtablissementGere($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissementRelatedByIdEtablissementGere relation
 *
 * @method TAgentQuery leftJoinTOrganisationRelatedByIdOrganisationAttache($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByIdOrganisationAttache relation
 * @method TAgentQuery rightJoinTOrganisationRelatedByIdOrganisationAttache($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByIdOrganisationAttache relation
 * @method TAgentQuery innerJoinTOrganisationRelatedByIdOrganisationAttache($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByIdOrganisationAttache relation
 *
 * @method TAgentQuery leftJoinTOrganisationRelatedByIdOrganisationGere($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByIdOrganisationGere relation
 * @method TAgentQuery rightJoinTOrganisationRelatedByIdOrganisationGere($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByIdOrganisationGere relation
 * @method TAgentQuery innerJoinTOrganisationRelatedByIdOrganisationGere($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByIdOrganisationGere relation
 *
 * @method TAgentQuery leftJoinTPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestation relation
 * @method TAgentQuery rightJoinTPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestation relation
 * @method TAgentQuery innerJoinTPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestation relation
 *
 * @method TAgentQuery leftJoinTProfil($relationAlias = null) Adds a LEFT JOIN clause to the query using the TProfil relation
 * @method TAgentQuery rightJoinTProfil($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TProfil relation
 * @method TAgentQuery innerJoinTProfil($relationAlias = null) Adds a INNER JOIN clause to the query using the TProfil relation
 *
 * @method TAgentQuery leftJoinTTraductionRelatedByCodeUtilisateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeUtilisateur relation
 * @method TAgentQuery rightJoinTTraductionRelatedByCodeUtilisateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeUtilisateur relation
 * @method TAgentQuery innerJoinTTraductionRelatedByCodeUtilisateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeUtilisateur relation
 *
 * @method TAgentQuery leftJoinTAgenda($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgenda relation
 * @method TAgentQuery rightJoinTAgenda($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgenda relation
 * @method TAgentQuery innerJoinTAgenda($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgenda relation
 *
 * @method TAgentQuery leftJoinTAgentEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentEtablissement relation
 * @method TAgentQuery rightJoinTAgentEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentEtablissement relation
 * @method TAgentQuery innerJoinTAgentEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentEtablissement relation
 *
 * @method TAgentQuery leftJoinTAgentPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentPrestation relation
 * @method TAgentQuery rightJoinTAgentPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentPrestation relation
 * @method TAgentQuery innerJoinTAgentPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentPrestation relation
 *
 * @method TAgentQuery leftJoinTPeriodeIndisponibilite($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPeriodeIndisponibilite relation
 * @method TAgentQuery rightJoinTPeriodeIndisponibilite($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPeriodeIndisponibilite relation
 * @method TAgentQuery innerJoinTPeriodeIndisponibilite($relationAlias = null) Adds a INNER JOIN clause to the query using the TPeriodeIndisponibilite relation
 *
 * @method TAgentQuery leftJoinTRendezVousRelatedByIdAgentAccueil($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVousRelatedByIdAgentAccueil relation
 * @method TAgentQuery rightJoinTRendezVousRelatedByIdAgentAccueil($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVousRelatedByIdAgentAccueil relation
 * @method TAgentQuery innerJoinTRendezVousRelatedByIdAgentAccueil($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVousRelatedByIdAgentAccueil relation
 *
 * @method TAgentQuery leftJoinTRendezVousRelatedByIdAgentAnnulation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVousRelatedByIdAgentAnnulation relation
 * @method TAgentQuery rightJoinTRendezVousRelatedByIdAgentAnnulation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVousRelatedByIdAgentAnnulation relation
 * @method TAgentQuery innerJoinTRendezVousRelatedByIdAgentAnnulation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVousRelatedByIdAgentAnnulation relation
 *
 * @method TAgentQuery leftJoinTRendezVousRelatedByIdAgentConfirmation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVousRelatedByIdAgentConfirmation relation
 * @method TAgentQuery rightJoinTRendezVousRelatedByIdAgentConfirmation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVousRelatedByIdAgentConfirmation relation
 * @method TAgentQuery innerJoinTRendezVousRelatedByIdAgentConfirmation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVousRelatedByIdAgentConfirmation relation
 *
 * @method TAgentQuery leftJoinTRendezVousRelatedByIdAgentRessource($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVousRelatedByIdAgentRessource relation
 * @method TAgentQuery rightJoinTRendezVousRelatedByIdAgentRessource($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVousRelatedByIdAgentRessource relation
 * @method TAgentQuery innerJoinTRendezVousRelatedByIdAgentRessource($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVousRelatedByIdAgentRessource relation
 *
 * @method TAgentQuery leftJoinTRendezVousRelatedByIdAgentTeleoperateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVousRelatedByIdAgentTeleoperateur relation
 * @method TAgentQuery rightJoinTRendezVousRelatedByIdAgentTeleoperateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVousRelatedByIdAgentTeleoperateur relation
 * @method TAgentQuery innerJoinTRendezVousRelatedByIdAgentTeleoperateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVousRelatedByIdAgentTeleoperateur relation
 *
 * @method TAgent findOne(PropelPDO $con = null) Return the first TAgent matching the query
 * @method TAgent findOneOrCreate(PropelPDO $con = null) Return the first TAgent matching the query, or a new TAgent object populated from the query conditions when no match is found
 *
 * @method TAgent findOneByLogin(string $LOGIN) Return the first TAgent filtered by the LOGIN column
 * @method TAgent findOneByMotDePasse(string $MOT_DE_PASSE) Return the first TAgent filtered by the MOT_DE_PASSE column
 * @method TAgent findOneByCodeNomUtilisateur(int $CODE_NOM_UTILISATEUR) Return the first TAgent filtered by the CODE_NOM_UTILISATEUR column
 * @method TAgent findOneByCodePrenomUtilisateur(int $CODE_PRENOM_UTILISATEUR) Return the first TAgent filtered by the CODE_PRENOM_UTILISATEUR column
 * @method TAgent findOneByCodeUtilisateur(int $CODE_UTILISATEUR) Return the first TAgent filtered by the CODE_UTILISATEUR column
 * @method TAgent findOneByEmailUtilisateur(string $EMAIL_UTILISATEUR) Return the first TAgent filtered by the EMAIL_UTILISATEUR column
 * @method TAgent findOneByTelephoneUtilisateur(string $TELEPHONE_UTILISATEUR) Return the first TAgent filtered by the TELEPHONE_UTILISATEUR column
 * @method TAgent findOneByIdEtablissementAttache(int $ID_ETABLISSEMENT_ATTACHE) Return the first TAgent filtered by the ID_ETABLISSEMENT_ATTACHE column
 * @method TAgent findOneByIdProfil(int $ID_PROFIL) Return the first TAgent filtered by the ID_PROFIL column
 * @method TAgent findOneByIdOrganisationAttache(int $ID_ORGANISATION_ATTACHE) Return the first TAgent filtered by the ID_ORGANISATION_ATTACHE column
 * @method TAgent findOneByTentativesMdp(int $TENTATIVES_MDP) Return the first TAgent filtered by the TENTATIVES_MDP column
 * @method TAgent findOneByIdPrestationAttache(int $ID_PRESTATION_ATTACHE) Return the first TAgent filtered by the ID_PRESTATION_ATTACHE column
 * @method TAgent findOneByIdEtablissementGere(int $ID_ETABLISSEMENT_GERE) Return the first TAgent filtered by the ID_ETABLISSEMENT_GERE column
 * @method TAgent findOneByIdOrganisationGere(int $ID_ORGANISATION_GERE) Return the first TAgent filtered by the ID_ORGANISATION_GERE column
 * @method TAgent findOneByActif(int $ACTIF) Return the first TAgent filtered by the ACTIF column
 * @method TAgent findOneByAlerte(string $ALERTE) Return the first TAgent filtered by the ALERTE column
 *
 * @method array findByIdAgent(int $ID_AGENT) Return TAgent objects filtered by the ID_AGENT column
 * @method array findByLogin(string $LOGIN) Return TAgent objects filtered by the LOGIN column
 * @method array findByMotDePasse(string $MOT_DE_PASSE) Return TAgent objects filtered by the MOT_DE_PASSE column
 * @method array findByCodeNomUtilisateur(int $CODE_NOM_UTILISATEUR) Return TAgent objects filtered by the CODE_NOM_UTILISATEUR column
 * @method array findByCodePrenomUtilisateur(int $CODE_PRENOM_UTILISATEUR) Return TAgent objects filtered by the CODE_PRENOM_UTILISATEUR column
 * @method array findByCodeUtilisateur(int $CODE_UTILISATEUR) Return TAgent objects filtered by the CODE_UTILISATEUR column
 * @method array findByEmailUtilisateur(string $EMAIL_UTILISATEUR) Return TAgent objects filtered by the EMAIL_UTILISATEUR column
 * @method array findByTelephoneUtilisateur(string $TELEPHONE_UTILISATEUR) Return TAgent objects filtered by the TELEPHONE_UTILISATEUR column
 * @method array findByIdEtablissementAttache(int $ID_ETABLISSEMENT_ATTACHE) Return TAgent objects filtered by the ID_ETABLISSEMENT_ATTACHE column
 * @method array findByIdProfil(int $ID_PROFIL) Return TAgent objects filtered by the ID_PROFIL column
 * @method array findByIdOrganisationAttache(int $ID_ORGANISATION_ATTACHE) Return TAgent objects filtered by the ID_ORGANISATION_ATTACHE column
 * @method array findByTentativesMdp(int $TENTATIVES_MDP) Return TAgent objects filtered by the TENTATIVES_MDP column
 * @method array findByIdPrestationAttache(int $ID_PRESTATION_ATTACHE) Return TAgent objects filtered by the ID_PRESTATION_ATTACHE column
 * @method array findByIdEtablissementGere(int $ID_ETABLISSEMENT_GERE) Return TAgent objects filtered by the ID_ETABLISSEMENT_GERE column
 * @method array findByIdOrganisationGere(int $ID_ORGANISATION_GERE) Return TAgent objects filtered by the ID_ORGANISATION_GERE column
 * @method array findByActif(int $ACTIF) Return TAgent objects filtered by the ACTIF column
 * @method array findByAlerte(string $ALERTE) Return TAgent objects filtered by the ALERTE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTAgentQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTAgentQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TAgent', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TAgentQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TAgentQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TAgentQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TAgentQuery) {
            return $criteria;
        }
        $query = new TAgentQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TAgent|TAgent[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TAgentPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TAgentPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TAgent A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdAgent($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TAgent A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_AGENT`, `LOGIN`, `MOT_DE_PASSE`, `CODE_NOM_UTILISATEUR`, `CODE_PRENOM_UTILISATEUR`, `CODE_UTILISATEUR`, `EMAIL_UTILISATEUR`, `TELEPHONE_UTILISATEUR`, `ID_ETABLISSEMENT_ATTACHE`, `ID_PROFIL`, `ID_ORGANISATION_ATTACHE`, `TENTATIVES_MDP`, `ID_PRESTATION_ATTACHE`, `ID_ETABLISSEMENT_GERE`, `ID_ORGANISATION_GERE`, `ACTIF`, `ALERTE` FROM `T_AGENT` WHERE `ID_AGENT` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TAgent();
            $obj->hydrate($row);
            TAgentPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TAgent|TAgent[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TAgent[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TAgentPeer::ID_AGENT, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TAgentPeer::ID_AGENT, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_AGENT column
     *
     * Example usage:
     * <code>
     * $query->filterByIdAgent(1234); // WHERE ID_AGENT = 1234
     * $query->filterByIdAgent(array(12, 34)); // WHERE ID_AGENT IN (12, 34)
     * $query->filterByIdAgent(array('min' => 12)); // WHERE ID_AGENT >= 12
     * $query->filterByIdAgent(array('max' => 12)); // WHERE ID_AGENT <= 12
     * </code>
     *
     * @param     mixed $idAgent The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByIdAgent($idAgent = null, $comparison = null)
    {
        if (is_array($idAgent)) {
            $useMinMax = false;
            if (isset($idAgent['min'])) {
                $this->addUsingAlias(TAgentPeer::ID_AGENT, $idAgent['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idAgent['max'])) {
                $this->addUsingAlias(TAgentPeer::ID_AGENT, $idAgent['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ID_AGENT, $idAgent, $comparison);
    }

    /**
     * Filter the query on the LOGIN column
     *
     * Example usage:
     * <code>
     * $query->filterByLogin('fooValue');   // WHERE LOGIN = 'fooValue'
     * $query->filterByLogin('%fooValue%'); // WHERE LOGIN LIKE '%fooValue%'
     * </code>
     *
     * @param     string $login The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByLogin($login = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($login)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $login)) {
                $login = str_replace('*', '%', $login);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TAgentPeer::LOGIN, $login, $comparison);
    }

    /**
     * Filter the query on the MOT_DE_PASSE column
     *
     * Example usage:
     * <code>
     * $query->filterByMotDePasse('fooValue');   // WHERE MOT_DE_PASSE = 'fooValue'
     * $query->filterByMotDePasse('%fooValue%'); // WHERE MOT_DE_PASSE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $motDePasse The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByMotDePasse($motDePasse = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($motDePasse)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $motDePasse)) {
                $motDePasse = str_replace('*', '%', $motDePasse);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TAgentPeer::MOT_DE_PASSE, $motDePasse, $comparison);
    }

    /**
     * Filter the query on the CODE_NOM_UTILISATEUR column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeNomUtilisateur(1234); // WHERE CODE_NOM_UTILISATEUR = 1234
     * $query->filterByCodeNomUtilisateur(array(12, 34)); // WHERE CODE_NOM_UTILISATEUR IN (12, 34)
     * $query->filterByCodeNomUtilisateur(array('min' => 12)); // WHERE CODE_NOM_UTILISATEUR >= 12
     * $query->filterByCodeNomUtilisateur(array('max' => 12)); // WHERE CODE_NOM_UTILISATEUR <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeNomUtilisateur()
     *
     * @param     mixed $codeNomUtilisateur The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByCodeNomUtilisateur($codeNomUtilisateur = null, $comparison = null)
    {
        if (is_array($codeNomUtilisateur)) {
            $useMinMax = false;
            if (isset($codeNomUtilisateur['min'])) {
                $this->addUsingAlias(TAgentPeer::CODE_NOM_UTILISATEUR, $codeNomUtilisateur['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeNomUtilisateur['max'])) {
                $this->addUsingAlias(TAgentPeer::CODE_NOM_UTILISATEUR, $codeNomUtilisateur['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::CODE_NOM_UTILISATEUR, $codeNomUtilisateur, $comparison);
    }

    /**
     * Filter the query on the CODE_PRENOM_UTILISATEUR column
     *
     * Example usage:
     * <code>
     * $query->filterByCodePrenomUtilisateur(1234); // WHERE CODE_PRENOM_UTILISATEUR = 1234
     * $query->filterByCodePrenomUtilisateur(array(12, 34)); // WHERE CODE_PRENOM_UTILISATEUR IN (12, 34)
     * $query->filterByCodePrenomUtilisateur(array('min' => 12)); // WHERE CODE_PRENOM_UTILISATEUR >= 12
     * $query->filterByCodePrenomUtilisateur(array('max' => 12)); // WHERE CODE_PRENOM_UTILISATEUR <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodePrenomUtilisateur()
     *
     * @param     mixed $codePrenomUtilisateur The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByCodePrenomUtilisateur($codePrenomUtilisateur = null, $comparison = null)
    {
        if (is_array($codePrenomUtilisateur)) {
            $useMinMax = false;
            if (isset($codePrenomUtilisateur['min'])) {
                $this->addUsingAlias(TAgentPeer::CODE_PRENOM_UTILISATEUR, $codePrenomUtilisateur['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codePrenomUtilisateur['max'])) {
                $this->addUsingAlias(TAgentPeer::CODE_PRENOM_UTILISATEUR, $codePrenomUtilisateur['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::CODE_PRENOM_UTILISATEUR, $codePrenomUtilisateur, $comparison);
    }

    /**
     * Filter the query on the CODE_UTILISATEUR column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeUtilisateur(1234); // WHERE CODE_UTILISATEUR = 1234
     * $query->filterByCodeUtilisateur(array(12, 34)); // WHERE CODE_UTILISATEUR IN (12, 34)
     * $query->filterByCodeUtilisateur(array('min' => 12)); // WHERE CODE_UTILISATEUR >= 12
     * $query->filterByCodeUtilisateur(array('max' => 12)); // WHERE CODE_UTILISATEUR <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeUtilisateur()
     *
     * @param     mixed $codeUtilisateur The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByCodeUtilisateur($codeUtilisateur = null, $comparison = null)
    {
        if (is_array($codeUtilisateur)) {
            $useMinMax = false;
            if (isset($codeUtilisateur['min'])) {
                $this->addUsingAlias(TAgentPeer::CODE_UTILISATEUR, $codeUtilisateur['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeUtilisateur['max'])) {
                $this->addUsingAlias(TAgentPeer::CODE_UTILISATEUR, $codeUtilisateur['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::CODE_UTILISATEUR, $codeUtilisateur, $comparison);
    }

    /**
     * Filter the query on the EMAIL_UTILISATEUR column
     *
     * Example usage:
     * <code>
     * $query->filterByEmailUtilisateur('fooValue');   // WHERE EMAIL_UTILISATEUR = 'fooValue'
     * $query->filterByEmailUtilisateur('%fooValue%'); // WHERE EMAIL_UTILISATEUR LIKE '%fooValue%'
     * </code>
     *
     * @param     string $emailUtilisateur The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByEmailUtilisateur($emailUtilisateur = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($emailUtilisateur)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $emailUtilisateur)) {
                $emailUtilisateur = str_replace('*', '%', $emailUtilisateur);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TAgentPeer::EMAIL_UTILISATEUR, $emailUtilisateur, $comparison);
    }

    /**
     * Filter the query on the TELEPHONE_UTILISATEUR column
     *
     * Example usage:
     * <code>
     * $query->filterByTelephoneUtilisateur('fooValue');   // WHERE TELEPHONE_UTILISATEUR = 'fooValue'
     * $query->filterByTelephoneUtilisateur('%fooValue%'); // WHERE TELEPHONE_UTILISATEUR LIKE '%fooValue%'
     * </code>
     *
     * @param     string $telephoneUtilisateur The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByTelephoneUtilisateur($telephoneUtilisateur = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($telephoneUtilisateur)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $telephoneUtilisateur)) {
                $telephoneUtilisateur = str_replace('*', '%', $telephoneUtilisateur);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TAgentPeer::TELEPHONE_UTILISATEUR, $telephoneUtilisateur, $comparison);
    }

    /**
     * Filter the query on the ID_ETABLISSEMENT_ATTACHE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEtablissementAttache(1234); // WHERE ID_ETABLISSEMENT_ATTACHE = 1234
     * $query->filterByIdEtablissementAttache(array(12, 34)); // WHERE ID_ETABLISSEMENT_ATTACHE IN (12, 34)
     * $query->filterByIdEtablissementAttache(array('min' => 12)); // WHERE ID_ETABLISSEMENT_ATTACHE >= 12
     * $query->filterByIdEtablissementAttache(array('max' => 12)); // WHERE ID_ETABLISSEMENT_ATTACHE <= 12
     * </code>
     *
     * @see       filterByTEtablissementRelatedByIdEtablissementAttache()
     *
     * @param     mixed $idEtablissementAttache The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByIdEtablissementAttache($idEtablissementAttache = null, $comparison = null)
    {
        if (is_array($idEtablissementAttache)) {
            $useMinMax = false;
            if (isset($idEtablissementAttache['min'])) {
                $this->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $idEtablissementAttache['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEtablissementAttache['max'])) {
                $this->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $idEtablissementAttache['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $idEtablissementAttache, $comparison);
    }

    /**
     * Filter the query on the ID_PROFIL column
     *
     * Example usage:
     * <code>
     * $query->filterByIdProfil(1234); // WHERE ID_PROFIL = 1234
     * $query->filterByIdProfil(array(12, 34)); // WHERE ID_PROFIL IN (12, 34)
     * $query->filterByIdProfil(array('min' => 12)); // WHERE ID_PROFIL >= 12
     * $query->filterByIdProfil(array('max' => 12)); // WHERE ID_PROFIL <= 12
     * </code>
     *
     * @see       filterByTProfil()
     *
     * @param     mixed $idProfil The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByIdProfil($idProfil = null, $comparison = null)
    {
        if (is_array($idProfil)) {
            $useMinMax = false;
            if (isset($idProfil['min'])) {
                $this->addUsingAlias(TAgentPeer::ID_PROFIL, $idProfil['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idProfil['max'])) {
                $this->addUsingAlias(TAgentPeer::ID_PROFIL, $idProfil['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ID_PROFIL, $idProfil, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION_ATTACHE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisationAttache(1234); // WHERE ID_ORGANISATION_ATTACHE = 1234
     * $query->filterByIdOrganisationAttache(array(12, 34)); // WHERE ID_ORGANISATION_ATTACHE IN (12, 34)
     * $query->filterByIdOrganisationAttache(array('min' => 12)); // WHERE ID_ORGANISATION_ATTACHE >= 12
     * $query->filterByIdOrganisationAttache(array('max' => 12)); // WHERE ID_ORGANISATION_ATTACHE <= 12
     * </code>
     *
     * @see       filterByTOrganisationRelatedByIdOrganisationAttache()
     *
     * @param     mixed $idOrganisationAttache The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByIdOrganisationAttache($idOrganisationAttache = null, $comparison = null)
    {
        if (is_array($idOrganisationAttache)) {
            $useMinMax = false;
            if (isset($idOrganisationAttache['min'])) {
                $this->addUsingAlias(TAgentPeer::ID_ORGANISATION_ATTACHE, $idOrganisationAttache['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisationAttache['max'])) {
                $this->addUsingAlias(TAgentPeer::ID_ORGANISATION_ATTACHE, $idOrganisationAttache['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ID_ORGANISATION_ATTACHE, $idOrganisationAttache, $comparison);
    }

    /**
     * Filter the query on the TENTATIVES_MDP column
     *
     * Example usage:
     * <code>
     * $query->filterByTentativesMdp(1234); // WHERE TENTATIVES_MDP = 1234
     * $query->filterByTentativesMdp(array(12, 34)); // WHERE TENTATIVES_MDP IN (12, 34)
     * $query->filterByTentativesMdp(array('min' => 12)); // WHERE TENTATIVES_MDP >= 12
     * $query->filterByTentativesMdp(array('max' => 12)); // WHERE TENTATIVES_MDP <= 12
     * </code>
     *
     * @param     mixed $tentativesMdp The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByTentativesMdp($tentativesMdp = null, $comparison = null)
    {
        if (is_array($tentativesMdp)) {
            $useMinMax = false;
            if (isset($tentativesMdp['min'])) {
                $this->addUsingAlias(TAgentPeer::TENTATIVES_MDP, $tentativesMdp['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($tentativesMdp['max'])) {
                $this->addUsingAlias(TAgentPeer::TENTATIVES_MDP, $tentativesMdp['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::TENTATIVES_MDP, $tentativesMdp, $comparison);
    }

    /**
     * Filter the query on the ID_PRESTATION_ATTACHE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPrestationAttache(1234); // WHERE ID_PRESTATION_ATTACHE = 1234
     * $query->filterByIdPrestationAttache(array(12, 34)); // WHERE ID_PRESTATION_ATTACHE IN (12, 34)
     * $query->filterByIdPrestationAttache(array('min' => 12)); // WHERE ID_PRESTATION_ATTACHE >= 12
     * $query->filterByIdPrestationAttache(array('max' => 12)); // WHERE ID_PRESTATION_ATTACHE <= 12
     * </code>
     *
     * @see       filterByTPrestation()
     *
     * @param     mixed $idPrestationAttache The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByIdPrestationAttache($idPrestationAttache = null, $comparison = null)
    {
        if (is_array($idPrestationAttache)) {
            $useMinMax = false;
            if (isset($idPrestationAttache['min'])) {
                $this->addUsingAlias(TAgentPeer::ID_PRESTATION_ATTACHE, $idPrestationAttache['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPrestationAttache['max'])) {
                $this->addUsingAlias(TAgentPeer::ID_PRESTATION_ATTACHE, $idPrestationAttache['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ID_PRESTATION_ATTACHE, $idPrestationAttache, $comparison);
    }

    /**
     * Filter the query on the ID_ETABLISSEMENT_GERE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdEtablissementGere(1234); // WHERE ID_ETABLISSEMENT_GERE = 1234
     * $query->filterByIdEtablissementGere(array(12, 34)); // WHERE ID_ETABLISSEMENT_GERE IN (12, 34)
     * $query->filterByIdEtablissementGere(array('min' => 12)); // WHERE ID_ETABLISSEMENT_GERE >= 12
     * $query->filterByIdEtablissementGere(array('max' => 12)); // WHERE ID_ETABLISSEMENT_GERE <= 12
     * </code>
     *
     * @see       filterByTEtablissementRelatedByIdEtablissementGere()
     *
     * @param     mixed $idEtablissementGere The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByIdEtablissementGere($idEtablissementGere = null, $comparison = null)
    {
        if (is_array($idEtablissementGere)) {
            $useMinMax = false;
            if (isset($idEtablissementGere['min'])) {
                $this->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_GERE, $idEtablissementGere['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idEtablissementGere['max'])) {
                $this->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_GERE, $idEtablissementGere['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_GERE, $idEtablissementGere, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION_GERE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisationGere(1234); // WHERE ID_ORGANISATION_GERE = 1234
     * $query->filterByIdOrganisationGere(array(12, 34)); // WHERE ID_ORGANISATION_GERE IN (12, 34)
     * $query->filterByIdOrganisationGere(array('min' => 12)); // WHERE ID_ORGANISATION_GERE >= 12
     * $query->filterByIdOrganisationGere(array('max' => 12)); // WHERE ID_ORGANISATION_GERE <= 12
     * </code>
     *
     * @see       filterByTOrganisationRelatedByIdOrganisationGere()
     *
     * @param     mixed $idOrganisationGere The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByIdOrganisationGere($idOrganisationGere = null, $comparison = null)
    {
        if (is_array($idOrganisationGere)) {
            $useMinMax = false;
            if (isset($idOrganisationGere['min'])) {
                $this->addUsingAlias(TAgentPeer::ID_ORGANISATION_GERE, $idOrganisationGere['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisationGere['max'])) {
                $this->addUsingAlias(TAgentPeer::ID_ORGANISATION_GERE, $idOrganisationGere['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ID_ORGANISATION_GERE, $idOrganisationGere, $comparison);
    }

    /**
     * Filter the query on the ACTIF column
     *
     * Example usage:
     * <code>
     * $query->filterByActif(1234); // WHERE ACTIF = 1234
     * $query->filterByActif(array(12, 34)); // WHERE ACTIF IN (12, 34)
     * $query->filterByActif(array('min' => 12)); // WHERE ACTIF >= 12
     * $query->filterByActif(array('max' => 12)); // WHERE ACTIF <= 12
     * </code>
     *
     * @param     mixed $actif The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByActif($actif = null, $comparison = null)
    {
        if (is_array($actif)) {
            $useMinMax = false;
            if (isset($actif['min'])) {
                $this->addUsingAlias(TAgentPeer::ACTIF, $actif['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($actif['max'])) {
                $this->addUsingAlias(TAgentPeer::ACTIF, $actif['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ACTIF, $actif, $comparison);
    }

    /**
     * Filter the query on the ALERTE column
     *
     * Example usage:
     * <code>
     * $query->filterByAlerte('fooValue');   // WHERE ALERTE = 'fooValue'
     * $query->filterByAlerte('%fooValue%'); // WHERE ALERTE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $alerte The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function filterByAlerte($alerte = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($alerte)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $alerte)) {
                $alerte = str_replace('*', '%', $alerte);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TAgentPeer::ALERTE, $alerte, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeNomUtilisateur($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TAgentPeer::CODE_NOM_UTILISATEUR, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::CODE_NOM_UTILISATEUR, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeNomUtilisateur() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeNomUtilisateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeNomUtilisateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeNomUtilisateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeNomUtilisateur');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeNomUtilisateur relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeNomUtilisateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeNomUtilisateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeNomUtilisateur', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodePrenomUtilisateur($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TAgentPeer::CODE_PRENOM_UTILISATEUR, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::CODE_PRENOM_UTILISATEUR, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodePrenomUtilisateur() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodePrenomUtilisateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodePrenomUtilisateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodePrenomUtilisateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodePrenomUtilisateur');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodePrenomUtilisateur relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodePrenomUtilisateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodePrenomUtilisateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodePrenomUtilisateur', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissementRelatedByIdEtablissementAttache($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $tEtablissement->getIdEtablissement(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_ATTACHE, $tEtablissement->toKeyValue('PrimaryKey', 'IdEtablissement'), $comparison);
        } else {
            throw new PropelException('filterByTEtablissementRelatedByIdEtablissementAttache() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissementRelatedByIdEtablissementAttache relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTEtablissementRelatedByIdEtablissementAttache($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissementRelatedByIdEtablissementAttache');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissementRelatedByIdEtablissementAttache');
        }

        return $this;
    }

    /**
     * Use the TEtablissementRelatedByIdEtablissementAttache relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementRelatedByIdEtablissementAttacheQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEtablissementRelatedByIdEtablissementAttache($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissementRelatedByIdEtablissementAttache', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissementRelatedByIdEtablissementGere($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_GERE, $tEtablissement->getIdEtablissement(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::ID_ETABLISSEMENT_GERE, $tEtablissement->toKeyValue('PrimaryKey', 'IdEtablissement'), $comparison);
        } else {
            throw new PropelException('filterByTEtablissementRelatedByIdEtablissementGere() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissementRelatedByIdEtablissementGere relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTEtablissementRelatedByIdEtablissementGere($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissementRelatedByIdEtablissementGere');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissementRelatedByIdEtablissementGere');
        }

        return $this;
    }

    /**
     * Use the TEtablissementRelatedByIdEtablissementGere relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementRelatedByIdEtablissementGereQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEtablissementRelatedByIdEtablissementGere($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissementRelatedByIdEtablissementGere', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByIdOrganisationAttache($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_ORGANISATION_ATTACHE, $tOrganisation->getIdOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::ID_ORGANISATION_ATTACHE, $tOrganisation->toKeyValue('PrimaryKey', 'IdOrganisation'), $comparison);
        } else {
            throw new PropelException('filterByTOrganisationRelatedByIdOrganisationAttache() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByIdOrganisationAttache relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByIdOrganisationAttache($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByIdOrganisationAttache');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByIdOrganisationAttache');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByIdOrganisationAttache relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByIdOrganisationAttacheQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByIdOrganisationAttache($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByIdOrganisationAttache', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByIdOrganisationGere($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_ORGANISATION_GERE, $tOrganisation->getIdOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::ID_ORGANISATION_GERE, $tOrganisation->toKeyValue('PrimaryKey', 'IdOrganisation'), $comparison);
        } else {
            throw new PropelException('filterByTOrganisationRelatedByIdOrganisationGere() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByIdOrganisationGere relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByIdOrganisationGere($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByIdOrganisationGere');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByIdOrganisationGere');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByIdOrganisationGere relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByIdOrganisationGereQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByIdOrganisationGere($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByIdOrganisationGere', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_PRESTATION_ATTACHE, $tPrestation->getIdPrestation(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::ID_PRESTATION_ATTACHE, $tPrestation->toKeyValue('PrimaryKey', 'IdPrestation'), $comparison);
        } else {
            throw new PropelException('filterByTPrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTPrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestation', 'TPrestationQuery');
    }

    /**
     * Filter the query by a related TProfil object
     *
     * @param   TProfil|PropelObjectCollection $tProfil The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTProfil($tProfil, $comparison = null)
    {
        if ($tProfil instanceof TProfil) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_PROFIL, $tProfil->getIdProfil(), $comparison);
        } elseif ($tProfil instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::ID_PROFIL, $tProfil->toKeyValue('PrimaryKey', 'IdProfil'), $comparison);
        } else {
            throw new PropelException('filterByTProfil() only accepts arguments of type TProfil or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TProfil relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTProfil($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TProfil');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TProfil');
        }

        return $this;
    }

    /**
     * Use the TProfil relation TProfil object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TProfilQuery A secondary query class using the current class as primary query
     */
    public function useTProfilQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTProfil($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TProfil', 'TProfilQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeUtilisateur($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TAgentPeer::CODE_UTILISATEUR, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TAgentPeer::CODE_UTILISATEUR, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeUtilisateur() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeUtilisateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeUtilisateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeUtilisateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeUtilisateur');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeUtilisateur relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeUtilisateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeUtilisateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeUtilisateur', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TAgenda object
     *
     * @param   TAgenda|PropelObjectCollection $tAgenda  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgenda($tAgenda, $comparison = null)
    {
        if ($tAgenda instanceof TAgenda) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tAgenda->getIdAgent(), $comparison);
        } elseif ($tAgenda instanceof PropelObjectCollection) {
            return $this
                ->useTAgendaQuery()
                ->filterByPrimaryKeys($tAgenda->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgenda() only accepts arguments of type TAgenda or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgenda relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTAgenda($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgenda');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgenda');
        }

        return $this;
    }

    /**
     * Use the TAgenda relation TAgenda object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgendaQuery A secondary query class using the current class as primary query
     */
    public function useTAgendaQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgenda($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgenda', 'TAgendaQuery');
    }

    /**
     * Filter the query by a related TAgentEtablissement object
     *
     * @param   TAgentEtablissement|PropelObjectCollection $tAgentEtablissement  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentEtablissement($tAgentEtablissement, $comparison = null)
    {
        if ($tAgentEtablissement instanceof TAgentEtablissement) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tAgentEtablissement->getIdAgent(), $comparison);
        } elseif ($tAgentEtablissement instanceof PropelObjectCollection) {
            return $this
                ->useTAgentEtablissementQuery()
                ->filterByPrimaryKeys($tAgentEtablissement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentEtablissement() only accepts arguments of type TAgentEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTAgentEtablissement($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentEtablissement');
        }

        return $this;
    }

    /**
     * Use the TAgentEtablissement relation TAgentEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTAgentEtablissementQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTAgentEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentEtablissement', 'TAgentEtablissementQuery');
    }

    /**
     * Filter the query by a related TAgentPrestation object
     *
     * @param   TAgentPrestation|PropelObjectCollection $tAgentPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentPrestation($tAgentPrestation, $comparison = null)
    {
        if ($tAgentPrestation instanceof TAgentPrestation) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tAgentPrestation->getIdAgent(), $comparison);
        } elseif ($tAgentPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTAgentPrestationQuery()
                ->filterByPrimaryKeys($tAgentPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentPrestation() only accepts arguments of type TAgentPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTAgentPrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentPrestation');
        }

        return $this;
    }

    /**
     * Use the TAgentPrestation relation TAgentPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTAgentPrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTAgentPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentPrestation', 'TAgentPrestationQuery');
    }

    /**
     * Filter the query by a related TPeriodeIndisponibilite object
     *
     * @param   TPeriodeIndisponibilite|PropelObjectCollection $tPeriodeIndisponibilite  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPeriodeIndisponibilite($tPeriodeIndisponibilite, $comparison = null)
    {
        if ($tPeriodeIndisponibilite instanceof TPeriodeIndisponibilite) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tPeriodeIndisponibilite->getIdAgent(), $comparison);
        } elseif ($tPeriodeIndisponibilite instanceof PropelObjectCollection) {
            return $this
                ->useTPeriodeIndisponibiliteQuery()
                ->filterByPrimaryKeys($tPeriodeIndisponibilite->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPeriodeIndisponibilite() only accepts arguments of type TPeriodeIndisponibilite or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPeriodeIndisponibilite relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTPeriodeIndisponibilite($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPeriodeIndisponibilite');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPeriodeIndisponibilite');
        }

        return $this;
    }

    /**
     * Use the TPeriodeIndisponibilite relation TPeriodeIndisponibilite object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPeriodeIndisponibiliteQuery A secondary query class using the current class as primary query
     */
    public function useTPeriodeIndisponibiliteQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPeriodeIndisponibilite($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPeriodeIndisponibilite', 'TPeriodeIndisponibiliteQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVousRelatedByIdAgentAccueil($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tRendezVous->getIdAgentAccueil(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousRelatedByIdAgentAccueilQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVousRelatedByIdAgentAccueil() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVousRelatedByIdAgentAccueil relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTRendezVousRelatedByIdAgentAccueil($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVousRelatedByIdAgentAccueil');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVousRelatedByIdAgentAccueil');
        }

        return $this;
    }

    /**
     * Use the TRendezVousRelatedByIdAgentAccueil relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousRelatedByIdAgentAccueilQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRendezVousRelatedByIdAgentAccueil($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVousRelatedByIdAgentAccueil', 'TRendezVousQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVousRelatedByIdAgentAnnulation($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tRendezVous->getIdAgentAnnulation(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousRelatedByIdAgentAnnulationQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVousRelatedByIdAgentAnnulation() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVousRelatedByIdAgentAnnulation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTRendezVousRelatedByIdAgentAnnulation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVousRelatedByIdAgentAnnulation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVousRelatedByIdAgentAnnulation');
        }

        return $this;
    }

    /**
     * Use the TRendezVousRelatedByIdAgentAnnulation relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousRelatedByIdAgentAnnulationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRendezVousRelatedByIdAgentAnnulation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVousRelatedByIdAgentAnnulation', 'TRendezVousQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVousRelatedByIdAgentConfirmation($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tRendezVous->getIdAgentConfirmation(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousRelatedByIdAgentConfirmationQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVousRelatedByIdAgentConfirmation() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVousRelatedByIdAgentConfirmation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTRendezVousRelatedByIdAgentConfirmation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVousRelatedByIdAgentConfirmation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVousRelatedByIdAgentConfirmation');
        }

        return $this;
    }

    /**
     * Use the TRendezVousRelatedByIdAgentConfirmation relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousRelatedByIdAgentConfirmationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRendezVousRelatedByIdAgentConfirmation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVousRelatedByIdAgentConfirmation', 'TRendezVousQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVousRelatedByIdAgentRessource($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tRendezVous->getIdAgentRessource(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousRelatedByIdAgentRessourceQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVousRelatedByIdAgentRessource() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVousRelatedByIdAgentRessource relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTRendezVousRelatedByIdAgentRessource($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVousRelatedByIdAgentRessource');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVousRelatedByIdAgentRessource');
        }

        return $this;
    }

    /**
     * Use the TRendezVousRelatedByIdAgentRessource relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousRelatedByIdAgentRessourceQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRendezVousRelatedByIdAgentRessource($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVousRelatedByIdAgentRessource', 'TRendezVousQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TAgentQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVousRelatedByIdAgentTeleoperateur($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TAgentPeer::ID_AGENT, $tRendezVous->getIdAgentTeleoperateur(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            return $this
                ->useTRendezVousRelatedByIdAgentTeleoperateurQuery()
                ->filterByPrimaryKeys($tRendezVous->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRendezVousRelatedByIdAgentTeleoperateur() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVousRelatedByIdAgentTeleoperateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function joinTRendezVousRelatedByIdAgentTeleoperateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVousRelatedByIdAgentTeleoperateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVousRelatedByIdAgentTeleoperateur');
        }

        return $this;
    }

    /**
     * Use the TRendezVousRelatedByIdAgentTeleoperateur relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousRelatedByIdAgentTeleoperateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTRendezVousRelatedByIdAgentTeleoperateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVousRelatedByIdAgentTeleoperateur', 'TRendezVousQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TAgent $tAgent Object to remove from the list of results
     *
     * @return TAgentQuery The current query, for fluid interface
     */
    public function prune($tAgent = null)
    {
        if ($tAgent) {
            $this->addUsingAlias(TAgentPeer::ID_AGENT, $tAgent->getIdAgent(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
