<?php


/**
 * Base class that represents a row from the 'T_ETABLISSEMENT' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTEtablissement extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TEtablissementPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TEtablissementPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_etablissement field.
     * @var        int
     */
    protected $id_etablissement;

    /**
     * The value for the active field.
     * Note: this column has a database default value of: '1'
     * @var        string
     */
    protected $active;

    /**
     * The value for the code_denomination_etablissement field.
     * @var        int
     */
    protected $code_denomination_etablissement;

    /**
     * The value for the code_adresse_etablissement field.
     * @var        int
     */
    protected $code_adresse_etablissement;

    /**
     * The value for the code_postal field.
     * @var        string
     */
    protected $code_postal;

    /**
     * The value for the telephone_etablissement field.
     * @var        string
     */
    protected $telephone_etablissement;

    /**
     * The value for the mail_etablissement field.
     * @var        string
     */
    protected $mail_etablissement;

    /**
     * The value for the code_description_etablissement field.
     * @var        int
     */
    protected $code_description_etablissement;

    /**
     * The value for the latitude_etablissement field.
     * @var        string
     */
    protected $latitude_etablissement;

    /**
     * The value for the longitude_etablissement field.
     * @var        string
     */
    protected $longitude_etablissement;

    /**
     * The value for the id_entite field.
     * @var        int
     */
    protected $id_entite;

    /**
     * The value for the id_organisation field.
     * @var        int
     */
    protected $id_organisation;

    /**
     * The value for the id_blob_plan field.
     * @var        int
     */
    protected $id_blob_plan;

    /**
     * The value for the id_type_etab field.
     * @var        int
     */
    protected $id_type_etab;

    /**
     * @var        TTypeEtab
     */
    protected $aTTypeEtab;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeAdresseEtablissement;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeDenominationEtablissement;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeDescriptionEtablissement;

    /**
     * @var        TBlob
     */
    protected $aTBlob;

    /**
     * @var        TEntite
     */
    protected $aTEntite;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisation;

    /**
     * @var        PropelObjectCollection|TAgent[] Collection to store aggregation of TAgent objects.
     */
    protected $collTAgentsRelatedByIdEtablissementAttache;
    protected $collTAgentsRelatedByIdEtablissementAttachePartial;

    /**
     * @var        PropelObjectCollection|TAgent[] Collection to store aggregation of TAgent objects.
     */
    protected $collTAgentsRelatedByIdEtablissementGere;
    protected $collTAgentsRelatedByIdEtablissementGerePartial;

    /**
     * @var        PropelObjectCollection|TAgentEtablissement[] Collection to store aggregation of TAgentEtablissement objects.
     */
    protected $collTAgentEtablissements;
    protected $collTAgentEtablissementsPartial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVouss;
    protected $collTRendezVoussPartial;

    /**
     * @var        PropelObjectCollection|TTypePrestation[] Collection to store aggregation of TTypePrestation objects.
     */
    protected $collTTypePrestations;
    protected $collTTypePrestationsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentsRelatedByIdEtablissementGereScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentEtablissementsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tTypePrestationsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->active = '1';
    }

    /**
     * Initializes internal state of BaseTEtablissement object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_etablissement] column value.
     *
     * @return int
     */
    public function getIdEtablissement()
    {
        return $this->id_etablissement;
    }

    /**
     * Get the [active] column value.
     *
     * @return string
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Get the [code_denomination_etablissement] column value.
     *
     * @return int
     */
    public function getCodeDenominationEtablissement()
    {
        return $this->code_denomination_etablissement;
    }

    /**
     * Get the [code_adresse_etablissement] column value.
     *
     * @return int
     */
    public function getCodeAdresseEtablissement()
    {
        return $this->code_adresse_etablissement;
    }

    /**
     * Get the [code_postal] column value.
     *
     * @return string
     */
    public function getCodePostal()
    {
        return $this->code_postal;
    }

    /**
     * Get the [telephone_etablissement] column value.
     *
     * @return string
     */
    public function getTelephoneEtablissement()
    {
        return $this->telephone_etablissement;
    }

    /**
     * Get the [mail_etablissement] column value.
     *
     * @return string
     */
    public function getMailEtablissement()
    {
        return $this->mail_etablissement;
    }

    /**
     * Get the [code_description_etablissement] column value.
     *
     * @return int
     */
    public function getCodeDescriptionEtablissement()
    {
        return $this->code_description_etablissement;
    }

    /**
     * Get the [latitude_etablissement] column value.
     *
     * @return string
     */
    public function getLatitudeEtablissement()
    {
        return $this->latitude_etablissement;
    }

    /**
     * Get the [longitude_etablissement] column value.
     *
     * @return string
     */
    public function getLongitudeEtablissement()
    {
        return $this->longitude_etablissement;
    }

    /**
     * Get the [id_entite] column value.
     *
     * @return int
     */
    public function getIdEntite()
    {
        return $this->id_entite;
    }

    /**
     * Get the [id_organisation] column value.
     *
     * @return int
     */
    public function getIdOrganisation()
    {
        return $this->id_organisation;
    }

    /**
     * Get the [id_blob_plan] column value.
     *
     * @return int
     */
    public function getIdBlobPlan()
    {
        return $this->id_blob_plan;
    }

    /**
     * Get the [id_type_etab] column value.
     *
     * @return int
     */
    public function getIdTypeEtab()
    {
        return $this->id_type_etab;
    }

    /**
     * Set the value of [id_etablissement] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setIdEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_etablissement !== $v) {
            $this->id_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::ID_ETABLISSEMENT;
        }


        return $this;
    } // setIdEtablissement()

    /**
     * Set the value of [active] column.
     *
     * @param string $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setActive($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->active !== $v) {
            $this->active = $v;
            $this->modifiedColumns[] = TEtablissementPeer::ACTIVE;
        }


        return $this;
    } // setActive()

    /**
     * Set the value of [code_denomination_etablissement] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setCodeDenominationEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_denomination_etablissement !== $v) {
            $this->code_denomination_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT;
        }

        if ($this->aTTraductionRelatedByCodeDenominationEtablissement !== null && $this->aTTraductionRelatedByCodeDenominationEtablissement->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeDenominationEtablissement = null;
        }


        return $this;
    } // setCodeDenominationEtablissement()

    /**
     * Set the value of [code_adresse_etablissement] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setCodeAdresseEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_adresse_etablissement !== $v) {
            $this->code_adresse_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT;
        }

        if ($this->aTTraductionRelatedByCodeAdresseEtablissement !== null && $this->aTTraductionRelatedByCodeAdresseEtablissement->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeAdresseEtablissement = null;
        }


        return $this;
    } // setCodeAdresseEtablissement()

    /**
     * Set the value of [code_postal] column.
     *
     * @param string $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setCodePostal($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->code_postal !== $v) {
            $this->code_postal = $v;
            $this->modifiedColumns[] = TEtablissementPeer::CODE_POSTAL;
        }


        return $this;
    } // setCodePostal()

    /**
     * Set the value of [telephone_etablissement] column.
     *
     * @param string $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setTelephoneEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->telephone_etablissement !== $v) {
            $this->telephone_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::TELEPHONE_ETABLISSEMENT;
        }


        return $this;
    } // setTelephoneEtablissement()

    /**
     * Set the value of [mail_etablissement] column.
     *
     * @param string $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setMailEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->mail_etablissement !== $v) {
            $this->mail_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::MAIL_ETABLISSEMENT;
        }


        return $this;
    } // setMailEtablissement()

    /**
     * Set the value of [code_description_etablissement] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setCodeDescriptionEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_description_etablissement !== $v) {
            $this->code_description_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT;
        }

        if ($this->aTTraductionRelatedByCodeDescriptionEtablissement !== null && $this->aTTraductionRelatedByCodeDescriptionEtablissement->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeDescriptionEtablissement = null;
        }


        return $this;
    } // setCodeDescriptionEtablissement()

    /**
     * Set the value of [latitude_etablissement] column.
     *
     * @param string $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setLatitudeEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->latitude_etablissement !== $v) {
            $this->latitude_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::LATITUDE_ETABLISSEMENT;
        }


        return $this;
    } // setLatitudeEtablissement()

    /**
     * Set the value of [longitude_etablissement] column.
     *
     * @param string $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setLongitudeEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->longitude_etablissement !== $v) {
            $this->longitude_etablissement = $v;
            $this->modifiedColumns[] = TEtablissementPeer::LONGITUDE_ETABLISSEMENT;
        }


        return $this;
    } // setLongitudeEtablissement()

    /**
     * Set the value of [id_entite] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setIdEntite($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_entite !== $v) {
            $this->id_entite = $v;
            $this->modifiedColumns[] = TEtablissementPeer::ID_ENTITE;
        }

        if ($this->aTEntite !== null && $this->aTEntite->getIdEntite() !== $v) {
            $this->aTEntite = null;
        }


        return $this;
    } // setIdEntite()

    /**
     * Set the value of [id_organisation] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setIdOrganisation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation !== $v) {
            $this->id_organisation = $v;
            $this->modifiedColumns[] = TEtablissementPeer::ID_ORGANISATION;
        }

        if ($this->aTOrganisation !== null && $this->aTOrganisation->getIdOrganisation() !== $v) {
            $this->aTOrganisation = null;
        }


        return $this;
    } // setIdOrganisation()

    /**
     * Set the value of [id_blob_plan] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setIdBlobPlan($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_blob_plan !== $v) {
            $this->id_blob_plan = $v;
            $this->modifiedColumns[] = TEtablissementPeer::ID_BLOB_PLAN;
        }

        if ($this->aTBlob !== null && $this->aTBlob->getIdBlob() !== $v) {
            $this->aTBlob = null;
        }


        return $this;
    } // setIdBlobPlan()

    /**
     * Set the value of [id_type_etab] column.
     *
     * @param int $v new value
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setIdTypeEtab($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_type_etab !== $v) {
            $this->id_type_etab = $v;
            $this->modifiedColumns[] = TEtablissementPeer::ID_TYPE_ETAB;
        }

        if ($this->aTTypeEtab !== null && $this->aTTypeEtab->getIdTypeEtab() !== $v) {
            $this->aTTypeEtab = null;
        }


        return $this;
    } // setIdTypeEtab()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->active !== '1') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_etablissement = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->active = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->code_denomination_etablissement = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->code_adresse_etablissement = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->code_postal = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->telephone_etablissement = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->mail_etablissement = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->code_description_etablissement = ($row[$startcol + 7] !== null) ? (int) $row[$startcol + 7] : null;
            $this->latitude_etablissement = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->longitude_etablissement = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->id_entite = ($row[$startcol + 10] !== null) ? (int) $row[$startcol + 10] : null;
            $this->id_organisation = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->id_blob_plan = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->id_type_etab = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 14; // 14 = TEtablissementPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TEtablissement object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTTraductionRelatedByCodeDenominationEtablissement !== null && $this->code_denomination_etablissement !== $this->aTTraductionRelatedByCodeDenominationEtablissement->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeDenominationEtablissement = null;
        }
        if ($this->aTTraductionRelatedByCodeAdresseEtablissement !== null && $this->code_adresse_etablissement !== $this->aTTraductionRelatedByCodeAdresseEtablissement->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeAdresseEtablissement = null;
        }
        if ($this->aTTraductionRelatedByCodeDescriptionEtablissement !== null && $this->code_description_etablissement !== $this->aTTraductionRelatedByCodeDescriptionEtablissement->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeDescriptionEtablissement = null;
        }
        if ($this->aTEntite !== null && $this->id_entite !== $this->aTEntite->getIdEntite()) {
            $this->aTEntite = null;
        }
        if ($this->aTOrganisation !== null && $this->id_organisation !== $this->aTOrganisation->getIdOrganisation()) {
            $this->aTOrganisation = null;
        }
        if ($this->aTBlob !== null && $this->id_blob_plan !== $this->aTBlob->getIdBlob()) {
            $this->aTBlob = null;
        }
        if ($this->aTTypeEtab !== null && $this->id_type_etab !== $this->aTTypeEtab->getIdTypeEtab()) {
            $this->aTTypeEtab = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TEtablissementPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TEtablissementPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTypeEtab = null;
            $this->aTTraductionRelatedByCodeAdresseEtablissement = null;
            $this->aTTraductionRelatedByCodeDenominationEtablissement = null;
            $this->aTTraductionRelatedByCodeDescriptionEtablissement = null;
            $this->aTBlob = null;
            $this->aTEntite = null;
            $this->aTOrganisation = null;
            $this->collTAgentsRelatedByIdEtablissementAttache = null;

            $this->collTAgentsRelatedByIdEtablissementGere = null;

            $this->collTAgentEtablissements = null;

            $this->collTRendezVouss = null;

            $this->collTTypePrestations = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TEtablissementPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TEtablissementQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TEtablissementPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TEtablissementPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTypeEtab !== null) {
                if ($this->aTTypeEtab->isModified() || $this->aTTypeEtab->isNew()) {
                    $affectedRows += $this->aTTypeEtab->save($con);
                }
                $this->setTTypeEtab($this->aTTypeEtab);
            }

            if ($this->aTTraductionRelatedByCodeAdresseEtablissement !== null) {
                if ($this->aTTraductionRelatedByCodeAdresseEtablissement->isModified() || $this->aTTraductionRelatedByCodeAdresseEtablissement->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeAdresseEtablissement->save($con);
                }
                $this->setTTraductionRelatedByCodeAdresseEtablissement($this->aTTraductionRelatedByCodeAdresseEtablissement);
            }

            if ($this->aTTraductionRelatedByCodeDenominationEtablissement !== null) {
                if ($this->aTTraductionRelatedByCodeDenominationEtablissement->isModified() || $this->aTTraductionRelatedByCodeDenominationEtablissement->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeDenominationEtablissement->save($con);
                }
                $this->setTTraductionRelatedByCodeDenominationEtablissement($this->aTTraductionRelatedByCodeDenominationEtablissement);
            }

            if ($this->aTTraductionRelatedByCodeDescriptionEtablissement !== null) {
                if ($this->aTTraductionRelatedByCodeDescriptionEtablissement->isModified() || $this->aTTraductionRelatedByCodeDescriptionEtablissement->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeDescriptionEtablissement->save($con);
                }
                $this->setTTraductionRelatedByCodeDescriptionEtablissement($this->aTTraductionRelatedByCodeDescriptionEtablissement);
            }

            if ($this->aTBlob !== null) {
                if ($this->aTBlob->isModified() || $this->aTBlob->isNew()) {
                    $affectedRows += $this->aTBlob->save($con);
                }
                $this->setTBlob($this->aTBlob);
            }

            if ($this->aTEntite !== null) {
                if ($this->aTEntite->isModified() || $this->aTEntite->isNew()) {
                    $affectedRows += $this->aTEntite->save($con);
                }
                $this->setTEntite($this->aTEntite);
            }

            if ($this->aTOrganisation !== null) {
                if ($this->aTOrganisation->isModified() || $this->aTOrganisation->isNew()) {
                    $affectedRows += $this->aTOrganisation->save($con);
                }
                $this->setTOrganisation($this->aTOrganisation);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion !== null) {
                if (!$this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion as $tAgentRelatedByIdEtablissementAttache) {
                        // need to save related object because we set the relation to null
                        $tAgentRelatedByIdEtablissementAttache->save($con);
                    }
                    $this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentsRelatedByIdEtablissementAttache !== null) {
                foreach ($this->collTAgentsRelatedByIdEtablissementAttache as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion !== null) {
                if (!$this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion as $tAgentRelatedByIdEtablissementGere) {
                        // need to save related object because we set the relation to null
                        $tAgentRelatedByIdEtablissementGere->save($con);
                    }
                    $this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentsRelatedByIdEtablissementGere !== null) {
                foreach ($this->collTAgentsRelatedByIdEtablissementGere as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentEtablissementsScheduledForDeletion !== null) {
                if (!$this->tAgentEtablissementsScheduledForDeletion->isEmpty()) {
                    TAgentEtablissementQuery::create()
                        ->filterByPrimaryKeys($this->tAgentEtablissementsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tAgentEtablissementsScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentEtablissements !== null) {
                foreach ($this->collTAgentEtablissements as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussScheduledForDeletion !== null) {
                if (!$this->tRendezVoussScheduledForDeletion->isEmpty()) {
                    TRendezVousQuery::create()
                        ->filterByPrimaryKeys($this->tRendezVoussScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tRendezVoussScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVouss !== null) {
                foreach ($this->collTRendezVouss as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tTypePrestationsScheduledForDeletion !== null) {
                if (!$this->tTypePrestationsScheduledForDeletion->isEmpty()) {
                    TTypePrestationQuery::create()
                        ->filterByPrimaryKeys($this->tTypePrestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tTypePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTTypePrestations !== null) {
                foreach ($this->collTTypePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TEtablissementPeer::ID_ETABLISSEMENT;
        if (null !== $this->id_etablissement) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TEtablissementPeer::ID_ETABLISSEMENT . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TEtablissementPeer::ID_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::ACTIVE)) {
            $modifiedColumns[':p' . $index++]  = '`ACTIVE`';
        }
        if ($this->isColumnModified(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_DENOMINATION_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_ADRESSE_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::CODE_POSTAL)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_POSTAL`';
        }
        if ($this->isColumnModified(TEtablissementPeer::TELEPHONE_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`TELEPHONE_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::MAIL_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`MAIL_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_DESCRIPTION_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::LATITUDE_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`LATITUDE_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::LONGITUDE_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`LONGITUDE_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TEtablissementPeer::ID_ENTITE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ENTITE`';
        }
        if ($this->isColumnModified(TEtablissementPeer::ID_ORGANISATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION`';
        }
        if ($this->isColumnModified(TEtablissementPeer::ID_BLOB_PLAN)) {
            $modifiedColumns[':p' . $index++]  = '`ID_BLOB_PLAN`';
        }
        if ($this->isColumnModified(TEtablissementPeer::ID_TYPE_ETAB)) {
            $modifiedColumns[':p' . $index++]  = '`ID_TYPE_ETAB`';
        }

        $sql = sprintf(
            'INSERT INTO `T_ETABLISSEMENT` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->id_etablissement, PDO::PARAM_INT);
                        break;
                    case '`ACTIVE`':
                        $stmt->bindValue($identifier, $this->active, PDO::PARAM_STR);
                        break;
                    case '`CODE_DENOMINATION_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->code_denomination_etablissement, PDO::PARAM_INT);
                        break;
                    case '`CODE_ADRESSE_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->code_adresse_etablissement, PDO::PARAM_INT);
                        break;
                    case '`CODE_POSTAL`':
                        $stmt->bindValue($identifier, $this->code_postal, PDO::PARAM_STR);
                        break;
                    case '`TELEPHONE_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->telephone_etablissement, PDO::PARAM_STR);
                        break;
                    case '`MAIL_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->mail_etablissement, PDO::PARAM_STR);
                        break;
                    case '`CODE_DESCRIPTION_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->code_description_etablissement, PDO::PARAM_INT);
                        break;
                    case '`LATITUDE_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->latitude_etablissement, PDO::PARAM_STR);
                        break;
                    case '`LONGITUDE_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->longitude_etablissement, PDO::PARAM_STR);
                        break;
                    case '`ID_ENTITE`':
                        $stmt->bindValue($identifier, $this->id_entite, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION`':
                        $stmt->bindValue($identifier, $this->id_organisation, PDO::PARAM_INT);
                        break;
                    case '`ID_BLOB_PLAN`':
                        $stmt->bindValue($identifier, $this->id_blob_plan, PDO::PARAM_INT);
                        break;
                    case '`ID_TYPE_ETAB`':
                        $stmt->bindValue($identifier, $this->id_type_etab, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdEtablissement($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTypeEtab !== null) {
                if (!$this->aTTypeEtab->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTypeEtab->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeAdresseEtablissement !== null) {
                if (!$this->aTTraductionRelatedByCodeAdresseEtablissement->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeAdresseEtablissement->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeDenominationEtablissement !== null) {
                if (!$this->aTTraductionRelatedByCodeDenominationEtablissement->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeDenominationEtablissement->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeDescriptionEtablissement !== null) {
                if (!$this->aTTraductionRelatedByCodeDescriptionEtablissement->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeDescriptionEtablissement->getValidationFailures());
                }
            }

            if ($this->aTBlob !== null) {
                if (!$this->aTBlob->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTBlob->getValidationFailures());
                }
            }

            if ($this->aTEntite !== null) {
                if (!$this->aTEntite->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTEntite->getValidationFailures());
                }
            }

            if ($this->aTOrganisation !== null) {
                if (!$this->aTOrganisation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisation->getValidationFailures());
                }
            }


            if (($retval = TEtablissementPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTAgentsRelatedByIdEtablissementAttache !== null) {
                    foreach ($this->collTAgentsRelatedByIdEtablissementAttache as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgentsRelatedByIdEtablissementGere !== null) {
                    foreach ($this->collTAgentsRelatedByIdEtablissementGere as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgentEtablissements !== null) {
                    foreach ($this->collTAgentEtablissements as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVouss !== null) {
                    foreach ($this->collTRendezVouss as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTTypePrestations !== null) {
                    foreach ($this->collTTypePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TEtablissementPeer::DATABASE_NAME);

        if ($this->isColumnModified(TEtablissementPeer::ID_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::ID_ETABLISSEMENT, $this->id_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::ACTIVE)) $criteria->add(TEtablissementPeer::ACTIVE, $this->active);
        if ($this->isColumnModified(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::CODE_DENOMINATION_ETABLISSEMENT, $this->code_denomination_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::CODE_ADRESSE_ETABLISSEMENT, $this->code_adresse_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::CODE_POSTAL)) $criteria->add(TEtablissementPeer::CODE_POSTAL, $this->code_postal);
        if ($this->isColumnModified(TEtablissementPeer::TELEPHONE_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::TELEPHONE_ETABLISSEMENT, $this->telephone_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::MAIL_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::MAIL_ETABLISSEMENT, $this->mail_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::CODE_DESCRIPTION_ETABLISSEMENT, $this->code_description_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::LATITUDE_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::LATITUDE_ETABLISSEMENT, $this->latitude_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::LONGITUDE_ETABLISSEMENT)) $criteria->add(TEtablissementPeer::LONGITUDE_ETABLISSEMENT, $this->longitude_etablissement);
        if ($this->isColumnModified(TEtablissementPeer::ID_ENTITE)) $criteria->add(TEtablissementPeer::ID_ENTITE, $this->id_entite);
        if ($this->isColumnModified(TEtablissementPeer::ID_ORGANISATION)) $criteria->add(TEtablissementPeer::ID_ORGANISATION, $this->id_organisation);
        if ($this->isColumnModified(TEtablissementPeer::ID_BLOB_PLAN)) $criteria->add(TEtablissementPeer::ID_BLOB_PLAN, $this->id_blob_plan);
        if ($this->isColumnModified(TEtablissementPeer::ID_TYPE_ETAB)) $criteria->add(TEtablissementPeer::ID_TYPE_ETAB, $this->id_type_etab);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TEtablissementPeer::DATABASE_NAME);
        $criteria->add(TEtablissementPeer::ID_ETABLISSEMENT, $this->id_etablissement);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdEtablissement();
    }

    /**
     * Generic method to set the primary key (id_etablissement column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdEtablissement($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdEtablissement();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TEtablissement (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setActive($this->getActive());
        $copyObj->setCodeDenominationEtablissement($this->getCodeDenominationEtablissement());
        $copyObj->setCodeAdresseEtablissement($this->getCodeAdresseEtablissement());
        $copyObj->setCodePostal($this->getCodePostal());
        $copyObj->setTelephoneEtablissement($this->getTelephoneEtablissement());
        $copyObj->setMailEtablissement($this->getMailEtablissement());
        $copyObj->setCodeDescriptionEtablissement($this->getCodeDescriptionEtablissement());
        $copyObj->setLatitudeEtablissement($this->getLatitudeEtablissement());
        $copyObj->setLongitudeEtablissement($this->getLongitudeEtablissement());
        $copyObj->setIdEntite($this->getIdEntite());
        $copyObj->setIdOrganisation($this->getIdOrganisation());
        $copyObj->setIdBlobPlan($this->getIdBlobPlan());
        $copyObj->setIdTypeEtab($this->getIdTypeEtab());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTAgentsRelatedByIdEtablissementAttache() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentRelatedByIdEtablissementAttache($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgentsRelatedByIdEtablissementGere() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentRelatedByIdEtablissementGere($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgentEtablissements() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentEtablissement($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVouss() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVous($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTTypePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTTypePrestation($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdEtablissement(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TEtablissement Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TEtablissementPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TEtablissementPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTypeEtab object.
     *
     * @param             TTypeEtab $v
     * @return TEtablissement The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTypeEtab(TTypeEtab $v = null)
    {
        if ($v === null) {
            $this->setIdTypeEtab(NULL);
        } else {
            $this->setIdTypeEtab($v->getIdTypeEtab());
        }

        $this->aTTypeEtab = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTypeEtab object, it will not be re-added.
        if ($v !== null) {
            $v->addTEtablissement($this);
        }


        return $this;
    }


    /**
     * Get the associated TTypeEtab object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTypeEtab The associated TTypeEtab object.
     * @throws PropelException
     */
    public function getTTypeEtab(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTypeEtab === null && ($this->id_type_etab !== null) && $doQuery) {
            $this->aTTypeEtab = TTypeEtabQuery::create()->findPk($this->id_type_etab, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTypeEtab->addTEtablissements($this);
             */
        }

        return $this->aTTypeEtab;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TEtablissement The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeAdresseEtablissement(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeAdresseEtablissement(NULL);
        } else {
            $this->setCodeAdresseEtablissement($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeAdresseEtablissement = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTEtablissementRelatedByCodeAdresseEtablissement($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeAdresseEtablissement(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeAdresseEtablissement === null && ($this->code_adresse_etablissement !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeAdresseEtablissement = TTraductionQuery::create()->findPk($this->code_adresse_etablissement, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeAdresseEtablissement->addTEtablissementsRelatedByCodeAdresseEtablissement($this);
             */
        }

        return $this->aTTraductionRelatedByCodeAdresseEtablissement;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TEtablissement The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeDenominationEtablissement(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeDenominationEtablissement(NULL);
        } else {
            $this->setCodeDenominationEtablissement($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeDenominationEtablissement = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTEtablissementRelatedByCodeDenominationEtablissement($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeDenominationEtablissement(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeDenominationEtablissement === null && ($this->code_denomination_etablissement !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeDenominationEtablissement = TTraductionQuery::create()->findPk($this->code_denomination_etablissement, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeDenominationEtablissement->addTEtablissementsRelatedByCodeDenominationEtablissement($this);
             */
        }

        return $this->aTTraductionRelatedByCodeDenominationEtablissement;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TEtablissement The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeDescriptionEtablissement(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeDescriptionEtablissement(NULL);
        } else {
            $this->setCodeDescriptionEtablissement($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeDescriptionEtablissement = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTEtablissementRelatedByCodeDescriptionEtablissement($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeDescriptionEtablissement(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeDescriptionEtablissement === null && ($this->code_description_etablissement !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeDescriptionEtablissement = TTraductionQuery::create()->findPk($this->code_description_etablissement, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeDescriptionEtablissement->addTEtablissementsRelatedByCodeDescriptionEtablissement($this);
             */
        }

        return $this->aTTraductionRelatedByCodeDescriptionEtablissement;
    }

    /**
     * Declares an association between this object and a TBlob object.
     *
     * @param             TBlob $v
     * @return TEtablissement The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTBlob(TBlob $v = null)
    {
        if ($v === null) {
            $this->setIdBlobPlan(NULL);
        } else {
            $this->setIdBlobPlan($v->getIdBlob());
        }

        $this->aTBlob = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TBlob object, it will not be re-added.
        if ($v !== null) {
            $v->addTEtablissement($this);
        }


        return $this;
    }


    /**
     * Get the associated TBlob object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TBlob The associated TBlob object.
     * @throws PropelException
     */
    public function getTBlob(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTBlob === null && ($this->id_blob_plan !== null) && $doQuery) {
            $this->aTBlob = TBlobQuery::create()->findPk($this->id_blob_plan, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTBlob->addTEtablissements($this);
             */
        }

        return $this->aTBlob;
    }

    /**
     * Declares an association between this object and a TEntite object.
     *
     * @param             TEntite $v
     * @return TEtablissement The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTEntite(TEntite $v = null)
    {
        if ($v === null) {
            $this->setIdEntite(NULL);
        } else {
            $this->setIdEntite($v->getIdEntite());
        }

        $this->aTEntite = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TEntite object, it will not be re-added.
        if ($v !== null) {
            $v->addTEtablissement($this);
        }


        return $this;
    }


    /**
     * Get the associated TEntite object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TEntite The associated TEntite object.
     * @throws PropelException
     */
    public function getTEntite(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTEntite === null && ($this->id_entite !== null) && $doQuery) {
            $this->aTEntite = TEntiteQuery::create()->findPk($this->id_entite, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTEntite->addTEtablissements($this);
             */
        }

        return $this->aTEntite;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TEtablissement The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisation(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisation(NULL);
        } else {
            $this->setIdOrganisation($v->getIdOrganisation());
        }

        $this->aTOrganisation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTEtablissement($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisation === null && ($this->id_organisation !== null) && $doQuery) {
            $this->aTOrganisation = TOrganisationQuery::create()->findPk($this->id_organisation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisation->addTEtablissements($this);
             */
        }

        return $this->aTOrganisation;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TAgentRelatedByIdEtablissementAttache' == $relationName) {
            $this->initTAgentsRelatedByIdEtablissementAttache();
        }
        if ('TAgentRelatedByIdEtablissementGere' == $relationName) {
            $this->initTAgentsRelatedByIdEtablissementGere();
        }
        if ('TAgentEtablissement' == $relationName) {
            $this->initTAgentEtablissements();
        }
        if ('TRendezVous' == $relationName) {
            $this->initTRendezVouss();
        }
        if ('TTypePrestation' == $relationName) {
            $this->initTTypePrestations();
        }
    }

    /**
     * Clears out the collTAgentsRelatedByIdEtablissementAttache collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TEtablissement The current object (for fluent API support)
     * @see        addTAgentsRelatedByIdEtablissementAttache()
     */
    public function clearTAgentsRelatedByIdEtablissementAttache()
    {
        $this->collTAgentsRelatedByIdEtablissementAttache = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentsRelatedByIdEtablissementAttachePartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentsRelatedByIdEtablissementAttache collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentsRelatedByIdEtablissementAttache($v = true)
    {
        $this->collTAgentsRelatedByIdEtablissementAttachePartial = $v;
    }

    /**
     * Initializes the collTAgentsRelatedByIdEtablissementAttache collection.
     *
     * By default this just sets the collTAgentsRelatedByIdEtablissementAttache collection to an empty array (like clearcollTAgentsRelatedByIdEtablissementAttache());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentsRelatedByIdEtablissementAttache($overrideExisting = true)
    {
        if (null !== $this->collTAgentsRelatedByIdEtablissementAttache && !$overrideExisting) {
            return;
        }
        $this->collTAgentsRelatedByIdEtablissementAttache = new PropelObjectCollection();
        $this->collTAgentsRelatedByIdEtablissementAttache->setModel('TAgent');
    }

    /**
     * Gets an array of TAgent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TEtablissement is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     * @throws PropelException
     */
    public function getTAgentsRelatedByIdEtablissementAttache($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByIdEtablissementAttachePartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByIdEtablissementAttache || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByIdEtablissementAttache) {
                // return empty collection
                $this->initTAgentsRelatedByIdEtablissementAttache();
            } else {
                $collTAgentsRelatedByIdEtablissementAttache = TAgentQuery::create(null, $criteria)
                    ->filterByTEtablissementRelatedByIdEtablissementAttache($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentsRelatedByIdEtablissementAttachePartial && count($collTAgentsRelatedByIdEtablissementAttache)) {
                      $this->initTAgentsRelatedByIdEtablissementAttache(false);

                      foreach($collTAgentsRelatedByIdEtablissementAttache as $obj) {
                        if (false == $this->collTAgentsRelatedByIdEtablissementAttache->contains($obj)) {
                          $this->collTAgentsRelatedByIdEtablissementAttache->append($obj);
                        }
                      }

                      $this->collTAgentsRelatedByIdEtablissementAttachePartial = true;
                    }

                    $collTAgentsRelatedByIdEtablissementAttache->getInternalIterator()->rewind();
                    return $collTAgentsRelatedByIdEtablissementAttache;
                }

                if($partial && $this->collTAgentsRelatedByIdEtablissementAttache) {
                    foreach($this->collTAgentsRelatedByIdEtablissementAttache as $obj) {
                        if($obj->isNew()) {
                            $collTAgentsRelatedByIdEtablissementAttache[] = $obj;
                        }
                    }
                }

                $this->collTAgentsRelatedByIdEtablissementAttache = $collTAgentsRelatedByIdEtablissementAttache;
                $this->collTAgentsRelatedByIdEtablissementAttachePartial = false;
            }
        }

        return $this->collTAgentsRelatedByIdEtablissementAttache;
    }

    /**
     * Sets a collection of TAgentRelatedByIdEtablissementAttache objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentsRelatedByIdEtablissementAttache A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setTAgentsRelatedByIdEtablissementAttache(PropelCollection $tAgentsRelatedByIdEtablissementAttache, PropelPDO $con = null)
    {
        $tAgentsRelatedByIdEtablissementAttacheToDelete = $this->getTAgentsRelatedByIdEtablissementAttache(new Criteria(), $con)->diff($tAgentsRelatedByIdEtablissementAttache);

        $this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion = unserialize(serialize($tAgentsRelatedByIdEtablissementAttacheToDelete));

        foreach ($tAgentsRelatedByIdEtablissementAttacheToDelete as $tAgentRelatedByIdEtablissementAttacheRemoved) {
            $tAgentRelatedByIdEtablissementAttacheRemoved->setTEtablissementRelatedByIdEtablissementAttache(null);
        }

        $this->collTAgentsRelatedByIdEtablissementAttache = null;
        foreach ($tAgentsRelatedByIdEtablissementAttache as $tAgentRelatedByIdEtablissementAttache) {
            $this->addTAgentRelatedByIdEtablissementAttache($tAgentRelatedByIdEtablissementAttache);
        }

        $this->collTAgentsRelatedByIdEtablissementAttache = $tAgentsRelatedByIdEtablissementAttache;
        $this->collTAgentsRelatedByIdEtablissementAttachePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgent objects.
     * @throws PropelException
     */
    public function countTAgentsRelatedByIdEtablissementAttache(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByIdEtablissementAttachePartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByIdEtablissementAttache || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByIdEtablissementAttache) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentsRelatedByIdEtablissementAttache());
            }
            $query = TAgentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTEtablissementRelatedByIdEtablissementAttache($this)
                ->count($con);
        }

        return count($this->collTAgentsRelatedByIdEtablissementAttache);
    }

    /**
     * Method called to associate a TAgent object to this object
     * through the TAgent foreign key attribute.
     *
     * @param    TAgent $l TAgent
     * @return TEtablissement The current object (for fluent API support)
     */
    public function addTAgentRelatedByIdEtablissementAttache(TAgent $l)
    {
        if ($this->collTAgentsRelatedByIdEtablissementAttache === null) {
            $this->initTAgentsRelatedByIdEtablissementAttache();
            $this->collTAgentsRelatedByIdEtablissementAttachePartial = true;
        }
        if (!in_array($l, $this->collTAgentsRelatedByIdEtablissementAttache->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentRelatedByIdEtablissementAttache($l);
        }

        return $this;
    }

    /**
     * @param	TAgentRelatedByIdEtablissementAttache $tAgentRelatedByIdEtablissementAttache The tAgentRelatedByIdEtablissementAttache object to add.
     */
    protected function doAddTAgentRelatedByIdEtablissementAttache($tAgentRelatedByIdEtablissementAttache)
    {
        $this->collTAgentsRelatedByIdEtablissementAttache[]= $tAgentRelatedByIdEtablissementAttache;
        $tAgentRelatedByIdEtablissementAttache->setTEtablissementRelatedByIdEtablissementAttache($this);
    }

    /**
     * @param	TAgentRelatedByIdEtablissementAttache $tAgentRelatedByIdEtablissementAttache The tAgentRelatedByIdEtablissementAttache object to remove.
     * @return TEtablissement The current object (for fluent API support)
     */
    public function removeTAgentRelatedByIdEtablissementAttache($tAgentRelatedByIdEtablissementAttache)
    {
        if ($this->getTAgentsRelatedByIdEtablissementAttache()->contains($tAgentRelatedByIdEtablissementAttache)) {
            $this->collTAgentsRelatedByIdEtablissementAttache->remove($this->collTAgentsRelatedByIdEtablissementAttache->search($tAgentRelatedByIdEtablissementAttache));
            if (null === $this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion) {
                $this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion = clone $this->collTAgentsRelatedByIdEtablissementAttache;
                $this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion->clear();
            }
            $this->tAgentsRelatedByIdEtablissementAttacheScheduledForDeletion[]= $tAgentRelatedByIdEtablissementAttache;
            $tAgentRelatedByIdEtablissementAttache->setTEtablissementRelatedByIdEtablissementAttache(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementAttache from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementAttacheJoinTTraductionRelatedByCodeNomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeNomUtilisateur', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementAttache($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementAttache from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementAttacheJoinTTraductionRelatedByCodePrenomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodePrenomUtilisateur', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementAttache($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementAttache from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementAttacheJoinTOrganisationRelatedByIdOrganisationAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationAttache', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementAttache($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementAttache from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementAttacheJoinTOrganisationRelatedByIdOrganisationGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationGere', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementAttache($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementAttache from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementAttacheJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementAttache($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementAttache from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementAttacheJoinTProfil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TProfil', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementAttache($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementAttache from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementAttacheJoinTTraductionRelatedByCodeUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeUtilisateur', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementAttache($query, $con);
    }

    /**
     * Clears out the collTAgentsRelatedByIdEtablissementGere collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TEtablissement The current object (for fluent API support)
     * @see        addTAgentsRelatedByIdEtablissementGere()
     */
    public function clearTAgentsRelatedByIdEtablissementGere()
    {
        $this->collTAgentsRelatedByIdEtablissementGere = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentsRelatedByIdEtablissementGerePartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentsRelatedByIdEtablissementGere collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentsRelatedByIdEtablissementGere($v = true)
    {
        $this->collTAgentsRelatedByIdEtablissementGerePartial = $v;
    }

    /**
     * Initializes the collTAgentsRelatedByIdEtablissementGere collection.
     *
     * By default this just sets the collTAgentsRelatedByIdEtablissementGere collection to an empty array (like clearcollTAgentsRelatedByIdEtablissementGere());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentsRelatedByIdEtablissementGere($overrideExisting = true)
    {
        if (null !== $this->collTAgentsRelatedByIdEtablissementGere && !$overrideExisting) {
            return;
        }
        $this->collTAgentsRelatedByIdEtablissementGere = new PropelObjectCollection();
        $this->collTAgentsRelatedByIdEtablissementGere->setModel('TAgent');
    }

    /**
     * Gets an array of TAgent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TEtablissement is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     * @throws PropelException
     */
    public function getTAgentsRelatedByIdEtablissementGere($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByIdEtablissementGerePartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByIdEtablissementGere || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByIdEtablissementGere) {
                // return empty collection
                $this->initTAgentsRelatedByIdEtablissementGere();
            } else {
                $collTAgentsRelatedByIdEtablissementGere = TAgentQuery::create(null, $criteria)
                    ->filterByTEtablissementRelatedByIdEtablissementGere($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentsRelatedByIdEtablissementGerePartial && count($collTAgentsRelatedByIdEtablissementGere)) {
                      $this->initTAgentsRelatedByIdEtablissementGere(false);

                      foreach($collTAgentsRelatedByIdEtablissementGere as $obj) {
                        if (false == $this->collTAgentsRelatedByIdEtablissementGere->contains($obj)) {
                          $this->collTAgentsRelatedByIdEtablissementGere->append($obj);
                        }
                      }

                      $this->collTAgentsRelatedByIdEtablissementGerePartial = true;
                    }

                    $collTAgentsRelatedByIdEtablissementGere->getInternalIterator()->rewind();
                    return $collTAgentsRelatedByIdEtablissementGere;
                }

                if($partial && $this->collTAgentsRelatedByIdEtablissementGere) {
                    foreach($this->collTAgentsRelatedByIdEtablissementGere as $obj) {
                        if($obj->isNew()) {
                            $collTAgentsRelatedByIdEtablissementGere[] = $obj;
                        }
                    }
                }

                $this->collTAgentsRelatedByIdEtablissementGere = $collTAgentsRelatedByIdEtablissementGere;
                $this->collTAgentsRelatedByIdEtablissementGerePartial = false;
            }
        }

        return $this->collTAgentsRelatedByIdEtablissementGere;
    }

    /**
     * Sets a collection of TAgentRelatedByIdEtablissementGere objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentsRelatedByIdEtablissementGere A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setTAgentsRelatedByIdEtablissementGere(PropelCollection $tAgentsRelatedByIdEtablissementGere, PropelPDO $con = null)
    {
        $tAgentsRelatedByIdEtablissementGereToDelete = $this->getTAgentsRelatedByIdEtablissementGere(new Criteria(), $con)->diff($tAgentsRelatedByIdEtablissementGere);

        $this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion = unserialize(serialize($tAgentsRelatedByIdEtablissementGereToDelete));

        foreach ($tAgentsRelatedByIdEtablissementGereToDelete as $tAgentRelatedByIdEtablissementGereRemoved) {
            $tAgentRelatedByIdEtablissementGereRemoved->setTEtablissementRelatedByIdEtablissementGere(null);
        }

        $this->collTAgentsRelatedByIdEtablissementGere = null;
        foreach ($tAgentsRelatedByIdEtablissementGere as $tAgentRelatedByIdEtablissementGere) {
            $this->addTAgentRelatedByIdEtablissementGere($tAgentRelatedByIdEtablissementGere);
        }

        $this->collTAgentsRelatedByIdEtablissementGere = $tAgentsRelatedByIdEtablissementGere;
        $this->collTAgentsRelatedByIdEtablissementGerePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgent objects.
     * @throws PropelException
     */
    public function countTAgentsRelatedByIdEtablissementGere(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByIdEtablissementGerePartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByIdEtablissementGere || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByIdEtablissementGere) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentsRelatedByIdEtablissementGere());
            }
            $query = TAgentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTEtablissementRelatedByIdEtablissementGere($this)
                ->count($con);
        }

        return count($this->collTAgentsRelatedByIdEtablissementGere);
    }

    /**
     * Method called to associate a TAgent object to this object
     * through the TAgent foreign key attribute.
     *
     * @param    TAgent $l TAgent
     * @return TEtablissement The current object (for fluent API support)
     */
    public function addTAgentRelatedByIdEtablissementGere(TAgent $l)
    {
        if ($this->collTAgentsRelatedByIdEtablissementGere === null) {
            $this->initTAgentsRelatedByIdEtablissementGere();
            $this->collTAgentsRelatedByIdEtablissementGerePartial = true;
        }
        if (!in_array($l, $this->collTAgentsRelatedByIdEtablissementGere->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentRelatedByIdEtablissementGere($l);
        }

        return $this;
    }

    /**
     * @param	TAgentRelatedByIdEtablissementGere $tAgentRelatedByIdEtablissementGere The tAgentRelatedByIdEtablissementGere object to add.
     */
    protected function doAddTAgentRelatedByIdEtablissementGere($tAgentRelatedByIdEtablissementGere)
    {
        $this->collTAgentsRelatedByIdEtablissementGere[]= $tAgentRelatedByIdEtablissementGere;
        $tAgentRelatedByIdEtablissementGere->setTEtablissementRelatedByIdEtablissementGere($this);
    }

    /**
     * @param	TAgentRelatedByIdEtablissementGere $tAgentRelatedByIdEtablissementGere The tAgentRelatedByIdEtablissementGere object to remove.
     * @return TEtablissement The current object (for fluent API support)
     */
    public function removeTAgentRelatedByIdEtablissementGere($tAgentRelatedByIdEtablissementGere)
    {
        if ($this->getTAgentsRelatedByIdEtablissementGere()->contains($tAgentRelatedByIdEtablissementGere)) {
            $this->collTAgentsRelatedByIdEtablissementGere->remove($this->collTAgentsRelatedByIdEtablissementGere->search($tAgentRelatedByIdEtablissementGere));
            if (null === $this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion) {
                $this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion = clone $this->collTAgentsRelatedByIdEtablissementGere;
                $this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion->clear();
            }
            $this->tAgentsRelatedByIdEtablissementGereScheduledForDeletion[]= $tAgentRelatedByIdEtablissementGere;
            $tAgentRelatedByIdEtablissementGere->setTEtablissementRelatedByIdEtablissementGere(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementGere from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementGereJoinTTraductionRelatedByCodeNomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeNomUtilisateur', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementGere($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementGere from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementGereJoinTTraductionRelatedByCodePrenomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodePrenomUtilisateur', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementGere($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementGere from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementGereJoinTOrganisationRelatedByIdOrganisationAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationAttache', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementGere($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementGere from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementGereJoinTOrganisationRelatedByIdOrganisationGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationGere', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementGere($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementGere from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementGereJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementGere($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementGere from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementGereJoinTProfil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TProfil', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementGere($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentsRelatedByIdEtablissementGere from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByIdEtablissementGereJoinTTraductionRelatedByCodeUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeUtilisateur', $join_behavior);

        return $this->getTAgentsRelatedByIdEtablissementGere($query, $con);
    }

    /**
     * Clears out the collTAgentEtablissements collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TEtablissement The current object (for fluent API support)
     * @see        addTAgentEtablissements()
     */
    public function clearTAgentEtablissements()
    {
        $this->collTAgentEtablissements = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentEtablissementsPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentEtablissements collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentEtablissements($v = true)
    {
        $this->collTAgentEtablissementsPartial = $v;
    }

    /**
     * Initializes the collTAgentEtablissements collection.
     *
     * By default this just sets the collTAgentEtablissements collection to an empty array (like clearcollTAgentEtablissements());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentEtablissements($overrideExisting = true)
    {
        if (null !== $this->collTAgentEtablissements && !$overrideExisting) {
            return;
        }
        $this->collTAgentEtablissements = new PropelObjectCollection();
        $this->collTAgentEtablissements->setModel('TAgentEtablissement');
    }

    /**
     * Gets an array of TAgentEtablissement objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TEtablissement is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgentEtablissement[] List of TAgentEtablissement objects
     * @throws PropelException
     */
    public function getTAgentEtablissements($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentEtablissementsPartial && !$this->isNew();
        if (null === $this->collTAgentEtablissements || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentEtablissements) {
                // return empty collection
                $this->initTAgentEtablissements();
            } else {
                $collTAgentEtablissements = TAgentEtablissementQuery::create(null, $criteria)
                    ->filterByTEtablissement($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentEtablissementsPartial && count($collTAgentEtablissements)) {
                      $this->initTAgentEtablissements(false);

                      foreach($collTAgentEtablissements as $obj) {
                        if (false == $this->collTAgentEtablissements->contains($obj)) {
                          $this->collTAgentEtablissements->append($obj);
                        }
                      }

                      $this->collTAgentEtablissementsPartial = true;
                    }

                    $collTAgentEtablissements->getInternalIterator()->rewind();
                    return $collTAgentEtablissements;
                }

                if($partial && $this->collTAgentEtablissements) {
                    foreach($this->collTAgentEtablissements as $obj) {
                        if($obj->isNew()) {
                            $collTAgentEtablissements[] = $obj;
                        }
                    }
                }

                $this->collTAgentEtablissements = $collTAgentEtablissements;
                $this->collTAgentEtablissementsPartial = false;
            }
        }

        return $this->collTAgentEtablissements;
    }

    /**
     * Sets a collection of TAgentEtablissement objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentEtablissements A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setTAgentEtablissements(PropelCollection $tAgentEtablissements, PropelPDO $con = null)
    {
        $tAgentEtablissementsToDelete = $this->getTAgentEtablissements(new Criteria(), $con)->diff($tAgentEtablissements);

        $this->tAgentEtablissementsScheduledForDeletion = unserialize(serialize($tAgentEtablissementsToDelete));

        foreach ($tAgentEtablissementsToDelete as $tAgentEtablissementRemoved) {
            $tAgentEtablissementRemoved->setTEtablissement(null);
        }

        $this->collTAgentEtablissements = null;
        foreach ($tAgentEtablissements as $tAgentEtablissement) {
            $this->addTAgentEtablissement($tAgentEtablissement);
        }

        $this->collTAgentEtablissements = $tAgentEtablissements;
        $this->collTAgentEtablissementsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgentEtablissement objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgentEtablissement objects.
     * @throws PropelException
     */
    public function countTAgentEtablissements(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentEtablissementsPartial && !$this->isNew();
        if (null === $this->collTAgentEtablissements || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentEtablissements) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentEtablissements());
            }
            $query = TAgentEtablissementQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTEtablissement($this)
                ->count($con);
        }

        return count($this->collTAgentEtablissements);
    }

    /**
     * Method called to associate a TAgentEtablissement object to this object
     * through the TAgentEtablissement foreign key attribute.
     *
     * @param    TAgentEtablissement $l TAgentEtablissement
     * @return TEtablissement The current object (for fluent API support)
     */
    public function addTAgentEtablissement(TAgentEtablissement $l)
    {
        if ($this->collTAgentEtablissements === null) {
            $this->initTAgentEtablissements();
            $this->collTAgentEtablissementsPartial = true;
        }
        if (!in_array($l, $this->collTAgentEtablissements->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentEtablissement($l);
        }

        return $this;
    }

    /**
     * @param	TAgentEtablissement $tAgentEtablissement The tAgentEtablissement object to add.
     */
    protected function doAddTAgentEtablissement($tAgentEtablissement)
    {
        $this->collTAgentEtablissements[]= $tAgentEtablissement;
        $tAgentEtablissement->setTEtablissement($this);
    }

    /**
     * @param	TAgentEtablissement $tAgentEtablissement The tAgentEtablissement object to remove.
     * @return TEtablissement The current object (for fluent API support)
     */
    public function removeTAgentEtablissement($tAgentEtablissement)
    {
        if ($this->getTAgentEtablissements()->contains($tAgentEtablissement)) {
            $this->collTAgentEtablissements->remove($this->collTAgentEtablissements->search($tAgentEtablissement));
            if (null === $this->tAgentEtablissementsScheduledForDeletion) {
                $this->tAgentEtablissementsScheduledForDeletion = clone $this->collTAgentEtablissements;
                $this->tAgentEtablissementsScheduledForDeletion->clear();
            }
            $this->tAgentEtablissementsScheduledForDeletion[]= clone $tAgentEtablissement;
            $tAgentEtablissement->setTEtablissement(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TAgentEtablissements from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgentEtablissement[] List of TAgentEtablissement objects
     */
    public function getTAgentEtablissementsJoinTAgent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentEtablissementQuery::create(null, $criteria);
        $query->joinWith('TAgent', $join_behavior);

        return $this->getTAgentEtablissements($query, $con);
    }

    /**
     * Clears out the collTRendezVouss collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TEtablissement The current object (for fluent API support)
     * @see        addTRendezVouss()
     */
    public function clearTRendezVouss()
    {
        $this->collTRendezVouss = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVouss collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVouss($v = true)
    {
        $this->collTRendezVoussPartial = $v;
    }

    /**
     * Initializes the collTRendezVouss collection.
     *
     * By default this just sets the collTRendezVouss collection to an empty array (like clearcollTRendezVouss());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVouss($overrideExisting = true)
    {
        if (null !== $this->collTRendezVouss && !$overrideExisting) {
            return;
        }
        $this->collTRendezVouss = new PropelObjectCollection();
        $this->collTRendezVouss->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TEtablissement is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVouss($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                // return empty collection
                $this->initTRendezVouss();
            } else {
                $collTRendezVouss = TRendezVousQuery::create(null, $criteria)
                    ->filterByTEtablissement($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussPartial && count($collTRendezVouss)) {
                      $this->initTRendezVouss(false);

                      foreach($collTRendezVouss as $obj) {
                        if (false == $this->collTRendezVouss->contains($obj)) {
                          $this->collTRendezVouss->append($obj);
                        }
                      }

                      $this->collTRendezVoussPartial = true;
                    }

                    $collTRendezVouss->getInternalIterator()->rewind();
                    return $collTRendezVouss;
                }

                if($partial && $this->collTRendezVouss) {
                    foreach($this->collTRendezVouss as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVouss[] = $obj;
                        }
                    }
                }

                $this->collTRendezVouss = $collTRendezVouss;
                $this->collTRendezVoussPartial = false;
            }
        }

        return $this->collTRendezVouss;
    }

    /**
     * Sets a collection of TRendezVous objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVouss A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setTRendezVouss(PropelCollection $tRendezVouss, PropelPDO $con = null)
    {
        $tRendezVoussToDelete = $this->getTRendezVouss(new Criteria(), $con)->diff($tRendezVouss);

        $this->tRendezVoussScheduledForDeletion = unserialize(serialize($tRendezVoussToDelete));

        foreach ($tRendezVoussToDelete as $tRendezVousRemoved) {
            $tRendezVousRemoved->setTEtablissement(null);
        }

        $this->collTRendezVouss = null;
        foreach ($tRendezVouss as $tRendezVous) {
            $this->addTRendezVous($tRendezVous);
        }

        $this->collTRendezVouss = $tRendezVouss;
        $this->collTRendezVoussPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVouss(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVouss());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTEtablissement($this)
                ->count($con);
        }

        return count($this->collTRendezVouss);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TEtablissement The current object (for fluent API support)
     */
    public function addTRendezVous(TRendezVous $l)
    {
        if ($this->collTRendezVouss === null) {
            $this->initTRendezVouss();
            $this->collTRendezVoussPartial = true;
        }
        if (!in_array($l, $this->collTRendezVouss->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVous($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to add.
     */
    protected function doAddTRendezVous($tRendezVous)
    {
        $this->collTRendezVouss[]= $tRendezVous;
        $tRendezVous->setTEtablissement($this);
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to remove.
     * @return TEtablissement The current object (for fluent API support)
     */
    public function removeTRendezVous($tRendezVous)
    {
        if ($this->getTRendezVouss()->contains($tRendezVous)) {
            $this->collTRendezVouss->remove($this->collTRendezVouss->search($tRendezVous));
            if (null === $this->tRendezVoussScheduledForDeletion) {
                $this->tRendezVoussScheduledForDeletion = clone $this->collTRendezVouss;
                $this->tRendezVoussScheduledForDeletion->clear();
            }
            $this->tRendezVoussScheduledForDeletion[]= clone $tRendezVous;
            $tRendezVous->setTEtablissement(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAccueil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAccueil', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAnnulation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAnnulation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentConfirmation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentConfirmation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentRessource($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentRessource', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentTeleoperateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentTeleoperateur', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTValeurReferentiel($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TValeurReferentiel', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }

    /**
     * Clears out the collTTypePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TEtablissement The current object (for fluent API support)
     * @see        addTTypePrestations()
     */
    public function clearTTypePrestations()
    {
        $this->collTTypePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTTypePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTTypePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTTypePrestations($v = true)
    {
        $this->collTTypePrestationsPartial = $v;
    }

    /**
     * Initializes the collTTypePrestations collection.
     *
     * By default this just sets the collTTypePrestations collection to an empty array (like clearcollTTypePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTTypePrestations($overrideExisting = true)
    {
        if (null !== $this->collTTypePrestations && !$overrideExisting) {
            return;
        }
        $this->collTTypePrestations = new PropelObjectCollection();
        $this->collTTypePrestations->setModel('TTypePrestation');
    }

    /**
     * Gets an array of TTypePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TEtablissement is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     * @throws PropelException
     */
    public function getTTypePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTTypePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTTypePrestations) {
                // return empty collection
                $this->initTTypePrestations();
            } else {
                $collTTypePrestations = TTypePrestationQuery::create(null, $criteria)
                    ->filterByTEtablissement($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTTypePrestationsPartial && count($collTTypePrestations)) {
                      $this->initTTypePrestations(false);

                      foreach($collTTypePrestations as $obj) {
                        if (false == $this->collTTypePrestations->contains($obj)) {
                          $this->collTTypePrestations->append($obj);
                        }
                      }

                      $this->collTTypePrestationsPartial = true;
                    }

                    $collTTypePrestations->getInternalIterator()->rewind();
                    return $collTTypePrestations;
                }

                if($partial && $this->collTTypePrestations) {
                    foreach($this->collTTypePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTTypePrestations[] = $obj;
                        }
                    }
                }

                $this->collTTypePrestations = $collTTypePrestations;
                $this->collTTypePrestationsPartial = false;
            }
        }

        return $this->collTTypePrestations;
    }

    /**
     * Sets a collection of TTypePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tTypePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TEtablissement The current object (for fluent API support)
     */
    public function setTTypePrestations(PropelCollection $tTypePrestations, PropelPDO $con = null)
    {
        $tTypePrestationsToDelete = $this->getTTypePrestations(new Criteria(), $con)->diff($tTypePrestations);

        $this->tTypePrestationsScheduledForDeletion = unserialize(serialize($tTypePrestationsToDelete));

        foreach ($tTypePrestationsToDelete as $tTypePrestationRemoved) {
            $tTypePrestationRemoved->setTEtablissement(null);
        }

        $this->collTTypePrestations = null;
        foreach ($tTypePrestations as $tTypePrestation) {
            $this->addTTypePrestation($tTypePrestation);
        }

        $this->collTTypePrestations = $tTypePrestations;
        $this->collTTypePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TTypePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TTypePrestation objects.
     * @throws PropelException
     */
    public function countTTypePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTTypePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTTypePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTTypePrestations());
            }
            $query = TTypePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTEtablissement($this)
                ->count($con);
        }

        return count($this->collTTypePrestations);
    }

    /**
     * Method called to associate a TTypePrestation object to this object
     * through the TTypePrestation foreign key attribute.
     *
     * @param    TTypePrestation $l TTypePrestation
     * @return TEtablissement The current object (for fluent API support)
     */
    public function addTTypePrestation(TTypePrestation $l)
    {
        if ($this->collTTypePrestations === null) {
            $this->initTTypePrestations();
            $this->collTTypePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTTypePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTTypePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TTypePrestation $tTypePrestation The tTypePrestation object to add.
     */
    protected function doAddTTypePrestation($tTypePrestation)
    {
        $this->collTTypePrestations[]= $tTypePrestation;
        $tTypePrestation->setTEtablissement($this);
    }

    /**
     * @param	TTypePrestation $tTypePrestation The tTypePrestation object to remove.
     * @return TEtablissement The current object (for fluent API support)
     */
    public function removeTTypePrestation($tTypePrestation)
    {
        if ($this->getTTypePrestations()->contains($tTypePrestation)) {
            $this->collTTypePrestations->remove($this->collTTypePrestations->search($tTypePrestation));
            if (null === $this->tTypePrestationsScheduledForDeletion) {
                $this->tTypePrestationsScheduledForDeletion = clone $this->collTTypePrestations;
                $this->tTypePrestationsScheduledForDeletion->clear();
            }
            $this->tTypePrestationsScheduledForDeletion[]= clone $tTypePrestation;
            $tTypePrestation->setTEtablissement(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     */
    public function getTTypePrestationsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTTypePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TEtablissement is new, it will return
     * an empty collection; or if this TEtablissement has previously
     * been saved, it will retrieve related TTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TEtablissement.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     */
    public function getTTypePrestationsJoinTRefTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefTypePrestation', $join_behavior);

        return $this->getTTypePrestations($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_etablissement = null;
        $this->active = null;
        $this->code_denomination_etablissement = null;
        $this->code_adresse_etablissement = null;
        $this->code_postal = null;
        $this->telephone_etablissement = null;
        $this->mail_etablissement = null;
        $this->code_description_etablissement = null;
        $this->latitude_etablissement = null;
        $this->longitude_etablissement = null;
        $this->id_entite = null;
        $this->id_organisation = null;
        $this->id_blob_plan = null;
        $this->id_type_etab = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTAgentsRelatedByIdEtablissementAttache) {
                foreach ($this->collTAgentsRelatedByIdEtablissementAttache as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgentsRelatedByIdEtablissementGere) {
                foreach ($this->collTAgentsRelatedByIdEtablissementGere as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgentEtablissements) {
                foreach ($this->collTAgentEtablissements as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVouss) {
                foreach ($this->collTRendezVouss as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTTypePrestations) {
                foreach ($this->collTTypePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTypeEtab instanceof Persistent) {
              $this->aTTypeEtab->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeAdresseEtablissement instanceof Persistent) {
              $this->aTTraductionRelatedByCodeAdresseEtablissement->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeDenominationEtablissement instanceof Persistent) {
              $this->aTTraductionRelatedByCodeDenominationEtablissement->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeDescriptionEtablissement instanceof Persistent) {
              $this->aTTraductionRelatedByCodeDescriptionEtablissement->clearAllReferences($deep);
            }
            if ($this->aTBlob instanceof Persistent) {
              $this->aTBlob->clearAllReferences($deep);
            }
            if ($this->aTEntite instanceof Persistent) {
              $this->aTEntite->clearAllReferences($deep);
            }
            if ($this->aTOrganisation instanceof Persistent) {
              $this->aTOrganisation->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTAgentsRelatedByIdEtablissementAttache instanceof PropelCollection) {
            $this->collTAgentsRelatedByIdEtablissementAttache->clearIterator();
        }
        $this->collTAgentsRelatedByIdEtablissementAttache = null;
        if ($this->collTAgentsRelatedByIdEtablissementGere instanceof PropelCollection) {
            $this->collTAgentsRelatedByIdEtablissementGere->clearIterator();
        }
        $this->collTAgentsRelatedByIdEtablissementGere = null;
        if ($this->collTAgentEtablissements instanceof PropelCollection) {
            $this->collTAgentEtablissements->clearIterator();
        }
        $this->collTAgentEtablissements = null;
        if ($this->collTRendezVouss instanceof PropelCollection) {
            $this->collTRendezVouss->clearIterator();
        }
        $this->collTRendezVouss = null;
        if ($this->collTTypePrestations instanceof PropelCollection) {
            $this->collTTypePrestations->clearIterator();
        }
        $this->collTTypePrestations = null;
        $this->aTTypeEtab = null;
        $this->aTTraductionRelatedByCodeAdresseEtablissement = null;
        $this->aTTraductionRelatedByCodeDenominationEtablissement = null;
        $this->aTTraductionRelatedByCodeDescriptionEtablissement = null;
        $this->aTBlob = null;
        $this->aTEntite = null;
        $this->aTOrganisation = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TEtablissementPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
