<?php


/**
 * Base class that represents a row from the 'T_PERIODE' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPeriode extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TPeriodePeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TPeriodePeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_periode field.
     * @var        int
     */
    protected $id_periode;

    /**
     * The value for the debut_periode field.
     * @var        string
     */
    protected $debut_periode;

    /**
     * The value for the fin_periode field.
     * @var        string
     */
    protected $fin_periode;

    /**
     * The value for the lundi_heure_debut_1 field.
     * @var        string
     */
    protected $lundi_heure_debut_1;

    /**
     * The value for the lundi_heure_fin_1 field.
     * @var        string
     */
    protected $lundi_heure_fin_1;

    /**
     * The value for the lundi_capacite_1 field.
     * @var        int
     */
    protected $lundi_capacite_1;

    /**
     * The value for the lundi_nb_rdv_site_1 field.
     * @var        int
     */
    protected $lundi_nb_rdv_site_1;

    /**
     * The value for the lundi_heure_debut_2 field.
     * @var        string
     */
    protected $lundi_heure_debut_2;

    /**
     * The value for the lundi_heure_fin_2 field.
     * @var        string
     */
    protected $lundi_heure_fin_2;

    /**
     * The value for the lundi_capacite_2 field.
     * @var        int
     */
    protected $lundi_capacite_2;

    /**
     * The value for the lundi_nb_rdv_site_2 field.
     * @var        int
     */
    protected $lundi_nb_rdv_site_2;

    /**
     * The value for the mardi_heure_debut_1 field.
     * @var        string
     */
    protected $mardi_heure_debut_1;

    /**
     * The value for the mardi_heure_fin_1 field.
     * @var        string
     */
    protected $mardi_heure_fin_1;

    /**
     * The value for the mardi_capacite_1 field.
     * @var        int
     */
    protected $mardi_capacite_1;

    /**
     * The value for the mardi_nb_rdv_site_1 field.
     * @var        int
     */
    protected $mardi_nb_rdv_site_1;

    /**
     * The value for the mardi_heure_debut_2 field.
     * @var        string
     */
    protected $mardi_heure_debut_2;

    /**
     * The value for the mardi_heure_fin_2 field.
     * @var        string
     */
    protected $mardi_heure_fin_2;

    /**
     * The value for the mardi_capacite_2 field.
     * @var        int
     */
    protected $mardi_capacite_2;

    /**
     * The value for the mardi_nb_rdv_site_2 field.
     * @var        int
     */
    protected $mardi_nb_rdv_site_2;

    /**
     * The value for the mercredi_heure_debut_1 field.
     * @var        string
     */
    protected $mercredi_heure_debut_1;

    /**
     * The value for the mercredi_heure_fin_1 field.
     * @var        string
     */
    protected $mercredi_heure_fin_1;

    /**
     * The value for the mercredi_capacite_1 field.
     * @var        int
     */
    protected $mercredi_capacite_1;

    /**
     * The value for the mercredi_nb_rdv_site_1 field.
     * @var        int
     */
    protected $mercredi_nb_rdv_site_1;

    /**
     * The value for the mercredi_heure_debut_2 field.
     * @var        string
     */
    protected $mercredi_heure_debut_2;

    /**
     * The value for the mercredi_heure_fin_2 field.
     * @var        string
     */
    protected $mercredi_heure_fin_2;

    /**
     * The value for the mercredi_capacite_2 field.
     * @var        int
     */
    protected $mercredi_capacite_2;

    /**
     * The value for the mercredi_nb_rdv_site_2 field.
     * @var        int
     */
    protected $mercredi_nb_rdv_site_2;

    /**
     * The value for the jeudi_heure_debut_1 field.
     * @var        string
     */
    protected $jeudi_heure_debut_1;

    /**
     * The value for the jeudi_heure_fin_1 field.
     * @var        string
     */
    protected $jeudi_heure_fin_1;

    /**
     * The value for the jeudi_capacite_1 field.
     * @var        int
     */
    protected $jeudi_capacite_1;

    /**
     * The value for the jeudi_nb_rdv_site_1 field.
     * @var        int
     */
    protected $jeudi_nb_rdv_site_1;

    /**
     * The value for the jeudi_heure_debut_2 field.
     * @var        string
     */
    protected $jeudi_heure_debut_2;

    /**
     * The value for the jeudi_heure_fin_2 field.
     * @var        string
     */
    protected $jeudi_heure_fin_2;

    /**
     * The value for the jeudi_capacite_2 field.
     * @var        int
     */
    protected $jeudi_capacite_2;

    /**
     * The value for the jeudi_nb_rdv_site_2 field.
     * @var        int
     */
    protected $jeudi_nb_rdv_site_2;

    /**
     * The value for the vendredi_heure_debut_1 field.
     * @var        string
     */
    protected $vendredi_heure_debut_1;

    /**
     * The value for the vendredi_heure_fin_1 field.
     * @var        string
     */
    protected $vendredi_heure_fin_1;

    /**
     * The value for the vendredi_capacite_1 field.
     * @var        int
     */
    protected $vendredi_capacite_1;

    /**
     * The value for the vendredi_nb_rdv_site_1 field.
     * @var        int
     */
    protected $vendredi_nb_rdv_site_1;

    /**
     * The value for the vendredi_heure_debut_2 field.
     * @var        string
     */
    protected $vendredi_heure_debut_2;

    /**
     * The value for the vendredi_heure_fin_2 field.
     * @var        string
     */
    protected $vendredi_heure_fin_2;

    /**
     * The value for the vendredi_capacite_2 field.
     * @var        int
     */
    protected $vendredi_capacite_2;

    /**
     * The value for the vendredi_nb_rdv_site_2 field.
     * @var        int
     */
    protected $vendredi_nb_rdv_site_2;

    /**
     * The value for the samedi_heure_debut_1 field.
     * @var        string
     */
    protected $samedi_heure_debut_1;

    /**
     * The value for the samedi_heure_fin_1 field.
     * @var        string
     */
    protected $samedi_heure_fin_1;

    /**
     * The value for the samedi_capacite_1 field.
     * @var        int
     */
    protected $samedi_capacite_1;

    /**
     * The value for the samedi_nb_rdv_site_1 field.
     * @var        int
     */
    protected $samedi_nb_rdv_site_1;

    /**
     * The value for the samedi_heure_debut_2 field.
     * @var        string
     */
    protected $samedi_heure_debut_2;

    /**
     * The value for the samedi_heure_fin_2 field.
     * @var        string
     */
    protected $samedi_heure_fin_2;

    /**
     * The value for the samedi_capacite_2 field.
     * @var        int
     */
    protected $samedi_capacite_2;

    /**
     * The value for the samedi_nb_rdv_site_2 field.
     * @var        int
     */
    protected $samedi_nb_rdv_site_2;

    /**
     * The value for the dimanche_heure_debut_1 field.
     * @var        string
     */
    protected $dimanche_heure_debut_1;

    /**
     * The value for the dimanche_heure_fin_1 field.
     * @var        string
     */
    protected $dimanche_heure_fin_1;

    /**
     * The value for the dimanche_capacite_1 field.
     * @var        int
     */
    protected $dimanche_capacite_1;

    /**
     * The value for the dimanche_nb_rdv_site_1 field.
     * @var        int
     */
    protected $dimanche_nb_rdv_site_1;

    /**
     * The value for the dimanche_heure_debut_2 field.
     * @var        string
     */
    protected $dimanche_heure_debut_2;

    /**
     * The value for the dimanche_heure_fin_2 field.
     * @var        string
     */
    protected $dimanche_heure_fin_2;

    /**
     * The value for the dimanche_capacite_2 field.
     * @var        int
     */
    protected $dimanche_capacite_2;

    /**
     * The value for the dimanche_nb_rdv_site_2 field.
     * @var        int
     */
    protected $dimanche_nb_rdv_site_2;

    /**
     * The value for the id_agenda field.
     * @var        int
     */
    protected $id_agenda;

    /**
     * The value for the periodicite field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $periodicite;

    /**
     * @var        TAgenda
     */
    protected $aTAgenda;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->periodicite = 0;
    }

    /**
     * Initializes internal state of BaseTPeriode object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_periode] column value.
     *
     * @return int
     */
    public function getIdPeriode()
    {
        return $this->id_periode;
    }

    /**
     * Get the [optionally formatted] temporal [debut_periode] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDebutPeriode($format = '%x')
    {
        if ($this->debut_periode === null) {
            return null;
        }

        if ($this->debut_periode === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->debut_periode);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->debut_periode, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [fin_periode] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getFinPeriode($format = '%x')
    {
        if ($this->fin_periode === null) {
            return null;
        }

        if ($this->fin_periode === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->fin_periode);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->fin_periode, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [lundi_heure_debut_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getLundiHeureDebut1($format = '%X')
    {
        if ($this->lundi_heure_debut_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->lundi_heure_debut_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->lundi_heure_debut_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [lundi_heure_fin_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getLundiHeureFin1($format = '%X')
    {
        if ($this->lundi_heure_fin_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->lundi_heure_fin_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->lundi_heure_fin_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [lundi_capacite_1] column value.
     *
     * @return int
     */
    public function getLundiCapacite1()
    {
        return $this->lundi_capacite_1;
    }

    /**
     * Get the [lundi_nb_rdv_site_1] column value.
     *
     * @return int
     */
    public function getLundiNbRdvSite1()
    {
        return $this->lundi_nb_rdv_site_1;
    }

    /**
     * Get the [optionally formatted] temporal [lundi_heure_debut_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getLundiHeureDebut2($format = '%X')
    {
        if ($this->lundi_heure_debut_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->lundi_heure_debut_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->lundi_heure_debut_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [lundi_heure_fin_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getLundiHeureFin2($format = '%X')
    {
        if ($this->lundi_heure_fin_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->lundi_heure_fin_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->lundi_heure_fin_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [lundi_capacite_2] column value.
     *
     * @return int
     */
    public function getLundiCapacite2()
    {
        return $this->lundi_capacite_2;
    }

    /**
     * Get the [lundi_nb_rdv_site_2] column value.
     *
     * @return int
     */
    public function getLundiNbRdvSite2()
    {
        return $this->lundi_nb_rdv_site_2;
    }

    /**
     * Get the [optionally formatted] temporal [mardi_heure_debut_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMardiHeureDebut1($format = '%X')
    {
        if ($this->mardi_heure_debut_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mardi_heure_debut_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mardi_heure_debut_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [mardi_heure_fin_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMardiHeureFin1($format = '%X')
    {
        if ($this->mardi_heure_fin_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mardi_heure_fin_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mardi_heure_fin_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [mardi_capacite_1] column value.
     *
     * @return int
     */
    public function getMardiCapacite1()
    {
        return $this->mardi_capacite_1;
    }

    /**
     * Get the [mardi_nb_rdv_site_1] column value.
     *
     * @return int
     */
    public function getMardiNbRdvSite1()
    {
        return $this->mardi_nb_rdv_site_1;
    }

    /**
     * Get the [optionally formatted] temporal [mardi_heure_debut_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMardiHeureDebut2($format = '%X')
    {
        if ($this->mardi_heure_debut_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mardi_heure_debut_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mardi_heure_debut_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [mardi_heure_fin_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMardiHeureFin2($format = '%X')
    {
        if ($this->mardi_heure_fin_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mardi_heure_fin_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mardi_heure_fin_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [mardi_capacite_2] column value.
     *
     * @return int
     */
    public function getMardiCapacite2()
    {
        return $this->mardi_capacite_2;
    }

    /**
     * Get the [mardi_nb_rdv_site_2] column value.
     *
     * @return int
     */
    public function getMardiNbRdvSite2()
    {
        return $this->mardi_nb_rdv_site_2;
    }

    /**
     * Get the [optionally formatted] temporal [mercredi_heure_debut_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMercrediHeureDebut1($format = '%X')
    {
        if ($this->mercredi_heure_debut_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mercredi_heure_debut_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mercredi_heure_debut_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [mercredi_heure_fin_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMercrediHeureFin1($format = '%X')
    {
        if ($this->mercredi_heure_fin_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mercredi_heure_fin_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mercredi_heure_fin_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [mercredi_capacite_1] column value.
     *
     * @return int
     */
    public function getMercrediCapacite1()
    {
        return $this->mercredi_capacite_1;
    }

    /**
     * Get the [mercredi_nb_rdv_site_1] column value.
     *
     * @return int
     */
    public function getMercrediNbRdvSite1()
    {
        return $this->mercredi_nb_rdv_site_1;
    }

    /**
     * Get the [optionally formatted] temporal [mercredi_heure_debut_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMercrediHeureDebut2($format = '%X')
    {
        if ($this->mercredi_heure_debut_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mercredi_heure_debut_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mercredi_heure_debut_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [mercredi_heure_fin_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getMercrediHeureFin2($format = '%X')
    {
        if ($this->mercredi_heure_fin_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->mercredi_heure_fin_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->mercredi_heure_fin_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [mercredi_capacite_2] column value.
     *
     * @return int
     */
    public function getMercrediCapacite2()
    {
        return $this->mercredi_capacite_2;
    }

    /**
     * Get the [mercredi_nb_rdv_site_2] column value.
     *
     * @return int
     */
    public function getMercrediNbRdvSite2()
    {
        return $this->mercredi_nb_rdv_site_2;
    }

    /**
     * Get the [optionally formatted] temporal [jeudi_heure_debut_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getJeudiHeureDebut1($format = '%X')
    {
        if ($this->jeudi_heure_debut_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->jeudi_heure_debut_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->jeudi_heure_debut_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [jeudi_heure_fin_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getJeudiHeureFin1($format = '%X')
    {
        if ($this->jeudi_heure_fin_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->jeudi_heure_fin_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->jeudi_heure_fin_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [jeudi_capacite_1] column value.
     *
     * @return int
     */
    public function getJeudiCapacite1()
    {
        return $this->jeudi_capacite_1;
    }

    /**
     * Get the [jeudi_nb_rdv_site_1] column value.
     *
     * @return int
     */
    public function getJeudiNbRdvSite1()
    {
        return $this->jeudi_nb_rdv_site_1;
    }

    /**
     * Get the [optionally formatted] temporal [jeudi_heure_debut_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getJeudiHeureDebut2($format = '%X')
    {
        if ($this->jeudi_heure_debut_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->jeudi_heure_debut_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->jeudi_heure_debut_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [jeudi_heure_fin_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getJeudiHeureFin2($format = '%X')
    {
        if ($this->jeudi_heure_fin_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->jeudi_heure_fin_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->jeudi_heure_fin_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [jeudi_capacite_2] column value.
     *
     * @return int
     */
    public function getJeudiCapacite2()
    {
        return $this->jeudi_capacite_2;
    }

    /**
     * Get the [jeudi_nb_rdv_site_2] column value.
     *
     * @return int
     */
    public function getJeudiNbRdvSite2()
    {
        return $this->jeudi_nb_rdv_site_2;
    }

    /**
     * Get the [optionally formatted] temporal [vendredi_heure_debut_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getVendrediHeureDebut1($format = '%X')
    {
        if ($this->vendredi_heure_debut_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->vendredi_heure_debut_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->vendredi_heure_debut_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [vendredi_heure_fin_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getVendrediHeureFin1($format = '%X')
    {
        if ($this->vendredi_heure_fin_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->vendredi_heure_fin_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->vendredi_heure_fin_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [vendredi_capacite_1] column value.
     *
     * @return int
     */
    public function getVendrediCapacite1()
    {
        return $this->vendredi_capacite_1;
    }

    /**
     * Get the [vendredi_nb_rdv_site_1] column value.
     *
     * @return int
     */
    public function getVendrediNbRdvSite1()
    {
        return $this->vendredi_nb_rdv_site_1;
    }

    /**
     * Get the [optionally formatted] temporal [vendredi_heure_debut_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getVendrediHeureDebut2($format = '%X')
    {
        if ($this->vendredi_heure_debut_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->vendredi_heure_debut_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->vendredi_heure_debut_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [vendredi_heure_fin_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getVendrediHeureFin2($format = '%X')
    {
        if ($this->vendredi_heure_fin_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->vendredi_heure_fin_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->vendredi_heure_fin_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [vendredi_capacite_2] column value.
     *
     * @return int
     */
    public function getVendrediCapacite2()
    {
        return $this->vendredi_capacite_2;
    }

    /**
     * Get the [vendredi_nb_rdv_site_2] column value.
     *
     * @return int
     */
    public function getVendrediNbRdvSite2()
    {
        return $this->vendredi_nb_rdv_site_2;
    }

    /**
     * Get the [optionally formatted] temporal [samedi_heure_debut_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getSamediHeureDebut1($format = '%X')
    {
        if ($this->samedi_heure_debut_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->samedi_heure_debut_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->samedi_heure_debut_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [samedi_heure_fin_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getSamediHeureFin1($format = '%X')
    {
        if ($this->samedi_heure_fin_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->samedi_heure_fin_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->samedi_heure_fin_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [samedi_capacite_1] column value.
     *
     * @return int
     */
    public function getSamediCapacite1()
    {
        return $this->samedi_capacite_1;
    }

    /**
     * Get the [samedi_nb_rdv_site_1] column value.
     *
     * @return int
     */
    public function getSamediNbRdvSite1()
    {
        return $this->samedi_nb_rdv_site_1;
    }

    /**
     * Get the [optionally formatted] temporal [samedi_heure_debut_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getSamediHeureDebut2($format = '%X')
    {
        if ($this->samedi_heure_debut_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->samedi_heure_debut_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->samedi_heure_debut_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [samedi_heure_fin_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getSamediHeureFin2($format = '%X')
    {
        if ($this->samedi_heure_fin_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->samedi_heure_fin_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->samedi_heure_fin_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [samedi_capacite_2] column value.
     *
     * @return int
     */
    public function getSamediCapacite2()
    {
        return $this->samedi_capacite_2;
    }

    /**
     * Get the [samedi_nb_rdv_site_2] column value.
     *
     * @return int
     */
    public function getSamediNbRdvSite2()
    {
        return $this->samedi_nb_rdv_site_2;
    }

    /**
     * Get the [optionally formatted] temporal [dimanche_heure_debut_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDimancheHeureDebut1($format = '%X')
    {
        if ($this->dimanche_heure_debut_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->dimanche_heure_debut_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->dimanche_heure_debut_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [dimanche_heure_fin_1] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDimancheHeureFin1($format = '%X')
    {
        if ($this->dimanche_heure_fin_1 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->dimanche_heure_fin_1);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->dimanche_heure_fin_1, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [dimanche_capacite_1] column value.
     *
     * @return int
     */
    public function getDimancheCapacite1()
    {
        return $this->dimanche_capacite_1;
    }

    /**
     * Get the [dimanche_nb_rdv_site_1] column value.
     *
     * @return int
     */
    public function getDimancheNbRdvSite1()
    {
        return $this->dimanche_nb_rdv_site_1;
    }

    /**
     * Get the [optionally formatted] temporal [dimanche_heure_debut_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDimancheHeureDebut2($format = '%X')
    {
        if ($this->dimanche_heure_debut_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->dimanche_heure_debut_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->dimanche_heure_debut_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [dimanche_heure_fin_2] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDimancheHeureFin2($format = '%X')
    {
        if ($this->dimanche_heure_fin_2 === null) {
            return null;
        }


        try {
            $dt = new DateTime($this->dimanche_heure_fin_2);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->dimanche_heure_fin_2, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [dimanche_capacite_2] column value.
     *
     * @return int
     */
    public function getDimancheCapacite2()
    {
        return $this->dimanche_capacite_2;
    }

    /**
     * Get the [dimanche_nb_rdv_site_2] column value.
     *
     * @return int
     */
    public function getDimancheNbRdvSite2()
    {
        return $this->dimanche_nb_rdv_site_2;
    }

    /**
     * Get the [id_agenda] column value.
     *
     * @return int
     */
    public function getIdAgenda()
    {
        return $this->id_agenda;
    }

    /**
     * Get the [periodicite] column value.
     *
     * @return int
     */
    public function getPeriodicite()
    {
        return $this->periodicite;
    }

    /**
     * Set the value of [id_periode] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setIdPeriode($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_periode !== $v) {
            $this->id_periode = $v;
            $this->modifiedColumns[] = TPeriodePeer::ID_PERIODE;
        }


        return $this;
    } // setIdPeriode()

    /**
     * Sets the value of [debut_periode] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDebutPeriode($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->debut_periode !== null || $dt !== null) {
            $currentDateAsString = ($this->debut_periode !== null && $tmpDt = new DateTime($this->debut_periode)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->debut_periode = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::DEBUT_PERIODE;
            }
        } // if either are not null


        return $this;
    } // setDebutPeriode()

    /**
     * Sets the value of [fin_periode] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setFinPeriode($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->fin_periode !== null || $dt !== null) {
            $currentDateAsString = ($this->fin_periode !== null && $tmpDt = new DateTime($this->fin_periode)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->fin_periode = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::FIN_PERIODE;
            }
        } // if either are not null


        return $this;
    } // setFinPeriode()

    /**
     * Sets the value of [lundi_heure_debut_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiHeureDebut1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->lundi_heure_debut_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->lundi_heure_debut_1 !== null && $tmpDt = new DateTime($this->lundi_heure_debut_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->lundi_heure_debut_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::LUNDI_HEURE_DEBUT_1;
            }
        } // if either are not null


        return $this;
    } // setLundiHeureDebut1()

    /**
     * Sets the value of [lundi_heure_fin_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiHeureFin1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->lundi_heure_fin_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->lundi_heure_fin_1 !== null && $tmpDt = new DateTime($this->lundi_heure_fin_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->lundi_heure_fin_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::LUNDI_HEURE_FIN_1;
            }
        } // if either are not null


        return $this;
    } // setLundiHeureFin1()

    /**
     * Set the value of [lundi_capacite_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiCapacite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->lundi_capacite_1 !== $v) {
            $this->lundi_capacite_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::LUNDI_CAPACITE_1;
        }


        return $this;
    } // setLundiCapacite1()

    /**
     * Set the value of [lundi_nb_rdv_site_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiNbRdvSite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->lundi_nb_rdv_site_1 !== $v) {
            $this->lundi_nb_rdv_site_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::LUNDI_NB_RDV_SITE_1;
        }


        return $this;
    } // setLundiNbRdvSite1()

    /**
     * Sets the value of [lundi_heure_debut_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiHeureDebut2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->lundi_heure_debut_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->lundi_heure_debut_2 !== null && $tmpDt = new DateTime($this->lundi_heure_debut_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->lundi_heure_debut_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::LUNDI_HEURE_DEBUT_2;
            }
        } // if either are not null


        return $this;
    } // setLundiHeureDebut2()

    /**
     * Sets the value of [lundi_heure_fin_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiHeureFin2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->lundi_heure_fin_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->lundi_heure_fin_2 !== null && $tmpDt = new DateTime($this->lundi_heure_fin_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->lundi_heure_fin_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::LUNDI_HEURE_FIN_2;
            }
        } // if either are not null


        return $this;
    } // setLundiHeureFin2()

    /**
     * Set the value of [lundi_capacite_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiCapacite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->lundi_capacite_2 !== $v) {
            $this->lundi_capacite_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::LUNDI_CAPACITE_2;
        }


        return $this;
    } // setLundiCapacite2()

    /**
     * Set the value of [lundi_nb_rdv_site_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setLundiNbRdvSite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->lundi_nb_rdv_site_2 !== $v) {
            $this->lundi_nb_rdv_site_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::LUNDI_NB_RDV_SITE_2;
        }


        return $this;
    } // setLundiNbRdvSite2()

    /**
     * Sets the value of [mardi_heure_debut_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiHeureDebut1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mardi_heure_debut_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->mardi_heure_debut_1 !== null && $tmpDt = new DateTime($this->mardi_heure_debut_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mardi_heure_debut_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MARDI_HEURE_DEBUT_1;
            }
        } // if either are not null


        return $this;
    } // setMardiHeureDebut1()

    /**
     * Sets the value of [mardi_heure_fin_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiHeureFin1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mardi_heure_fin_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->mardi_heure_fin_1 !== null && $tmpDt = new DateTime($this->mardi_heure_fin_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mardi_heure_fin_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MARDI_HEURE_FIN_1;
            }
        } // if either are not null


        return $this;
    } // setMardiHeureFin1()

    /**
     * Set the value of [mardi_capacite_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiCapacite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mardi_capacite_1 !== $v) {
            $this->mardi_capacite_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MARDI_CAPACITE_1;
        }


        return $this;
    } // setMardiCapacite1()

    /**
     * Set the value of [mardi_nb_rdv_site_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiNbRdvSite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mardi_nb_rdv_site_1 !== $v) {
            $this->mardi_nb_rdv_site_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MARDI_NB_RDV_SITE_1;
        }


        return $this;
    } // setMardiNbRdvSite1()

    /**
     * Sets the value of [mardi_heure_debut_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiHeureDebut2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mardi_heure_debut_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->mardi_heure_debut_2 !== null && $tmpDt = new DateTime($this->mardi_heure_debut_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mardi_heure_debut_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MARDI_HEURE_DEBUT_2;
            }
        } // if either are not null


        return $this;
    } // setMardiHeureDebut2()

    /**
     * Sets the value of [mardi_heure_fin_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiHeureFin2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mardi_heure_fin_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->mardi_heure_fin_2 !== null && $tmpDt = new DateTime($this->mardi_heure_fin_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mardi_heure_fin_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MARDI_HEURE_FIN_2;
            }
        } // if either are not null


        return $this;
    } // setMardiHeureFin2()

    /**
     * Set the value of [mardi_capacite_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiCapacite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mardi_capacite_2 !== $v) {
            $this->mardi_capacite_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MARDI_CAPACITE_2;
        }


        return $this;
    } // setMardiCapacite2()

    /**
     * Set the value of [mardi_nb_rdv_site_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMardiNbRdvSite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mardi_nb_rdv_site_2 !== $v) {
            $this->mardi_nb_rdv_site_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MARDI_NB_RDV_SITE_2;
        }


        return $this;
    } // setMardiNbRdvSite2()

    /**
     * Sets the value of [mercredi_heure_debut_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediHeureDebut1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mercredi_heure_debut_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->mercredi_heure_debut_1 !== null && $tmpDt = new DateTime($this->mercredi_heure_debut_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mercredi_heure_debut_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MERCREDI_HEURE_DEBUT_1;
            }
        } // if either are not null


        return $this;
    } // setMercrediHeureDebut1()

    /**
     * Sets the value of [mercredi_heure_fin_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediHeureFin1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mercredi_heure_fin_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->mercredi_heure_fin_1 !== null && $tmpDt = new DateTime($this->mercredi_heure_fin_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mercredi_heure_fin_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MERCREDI_HEURE_FIN_1;
            }
        } // if either are not null


        return $this;
    } // setMercrediHeureFin1()

    /**
     * Set the value of [mercredi_capacite_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediCapacite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mercredi_capacite_1 !== $v) {
            $this->mercredi_capacite_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MERCREDI_CAPACITE_1;
        }


        return $this;
    } // setMercrediCapacite1()

    /**
     * Set the value of [mercredi_nb_rdv_site_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediNbRdvSite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mercredi_nb_rdv_site_1 !== $v) {
            $this->mercredi_nb_rdv_site_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MERCREDI_NB_RDV_SITE_1;
        }


        return $this;
    } // setMercrediNbRdvSite1()

    /**
     * Sets the value of [mercredi_heure_debut_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediHeureDebut2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mercredi_heure_debut_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->mercredi_heure_debut_2 !== null && $tmpDt = new DateTime($this->mercredi_heure_debut_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mercredi_heure_debut_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MERCREDI_HEURE_DEBUT_2;
            }
        } // if either are not null


        return $this;
    } // setMercrediHeureDebut2()

    /**
     * Sets the value of [mercredi_heure_fin_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediHeureFin2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->mercredi_heure_fin_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->mercredi_heure_fin_2 !== null && $tmpDt = new DateTime($this->mercredi_heure_fin_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->mercredi_heure_fin_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::MERCREDI_HEURE_FIN_2;
            }
        } // if either are not null


        return $this;
    } // setMercrediHeureFin2()

    /**
     * Set the value of [mercredi_capacite_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediCapacite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mercredi_capacite_2 !== $v) {
            $this->mercredi_capacite_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MERCREDI_CAPACITE_2;
        }


        return $this;
    } // setMercrediCapacite2()

    /**
     * Set the value of [mercredi_nb_rdv_site_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setMercrediNbRdvSite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->mercredi_nb_rdv_site_2 !== $v) {
            $this->mercredi_nb_rdv_site_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::MERCREDI_NB_RDV_SITE_2;
        }


        return $this;
    } // setMercrediNbRdvSite2()

    /**
     * Sets the value of [jeudi_heure_debut_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiHeureDebut1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->jeudi_heure_debut_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->jeudi_heure_debut_1 !== null && $tmpDt = new DateTime($this->jeudi_heure_debut_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->jeudi_heure_debut_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::JEUDI_HEURE_DEBUT_1;
            }
        } // if either are not null


        return $this;
    } // setJeudiHeureDebut1()

    /**
     * Sets the value of [jeudi_heure_fin_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiHeureFin1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->jeudi_heure_fin_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->jeudi_heure_fin_1 !== null && $tmpDt = new DateTime($this->jeudi_heure_fin_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->jeudi_heure_fin_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::JEUDI_HEURE_FIN_1;
            }
        } // if either are not null


        return $this;
    } // setJeudiHeureFin1()

    /**
     * Set the value of [jeudi_capacite_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiCapacite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->jeudi_capacite_1 !== $v) {
            $this->jeudi_capacite_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::JEUDI_CAPACITE_1;
        }


        return $this;
    } // setJeudiCapacite1()

    /**
     * Set the value of [jeudi_nb_rdv_site_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiNbRdvSite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->jeudi_nb_rdv_site_1 !== $v) {
            $this->jeudi_nb_rdv_site_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::JEUDI_NB_RDV_SITE_1;
        }


        return $this;
    } // setJeudiNbRdvSite1()

    /**
     * Sets the value of [jeudi_heure_debut_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiHeureDebut2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->jeudi_heure_debut_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->jeudi_heure_debut_2 !== null && $tmpDt = new DateTime($this->jeudi_heure_debut_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->jeudi_heure_debut_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::JEUDI_HEURE_DEBUT_2;
            }
        } // if either are not null


        return $this;
    } // setJeudiHeureDebut2()

    /**
     * Sets the value of [jeudi_heure_fin_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiHeureFin2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->jeudi_heure_fin_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->jeudi_heure_fin_2 !== null && $tmpDt = new DateTime($this->jeudi_heure_fin_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->jeudi_heure_fin_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::JEUDI_HEURE_FIN_2;
            }
        } // if either are not null


        return $this;
    } // setJeudiHeureFin2()

    /**
     * Set the value of [jeudi_capacite_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiCapacite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->jeudi_capacite_2 !== $v) {
            $this->jeudi_capacite_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::JEUDI_CAPACITE_2;
        }


        return $this;
    } // setJeudiCapacite2()

    /**
     * Set the value of [jeudi_nb_rdv_site_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setJeudiNbRdvSite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->jeudi_nb_rdv_site_2 !== $v) {
            $this->jeudi_nb_rdv_site_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::JEUDI_NB_RDV_SITE_2;
        }


        return $this;
    } // setJeudiNbRdvSite2()

    /**
     * Sets the value of [vendredi_heure_debut_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediHeureDebut1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->vendredi_heure_debut_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->vendredi_heure_debut_1 !== null && $tmpDt = new DateTime($this->vendredi_heure_debut_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->vendredi_heure_debut_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::VENDREDI_HEURE_DEBUT_1;
            }
        } // if either are not null


        return $this;
    } // setVendrediHeureDebut1()

    /**
     * Sets the value of [vendredi_heure_fin_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediHeureFin1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->vendredi_heure_fin_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->vendredi_heure_fin_1 !== null && $tmpDt = new DateTime($this->vendredi_heure_fin_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->vendredi_heure_fin_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::VENDREDI_HEURE_FIN_1;
            }
        } // if either are not null


        return $this;
    } // setVendrediHeureFin1()

    /**
     * Set the value of [vendredi_capacite_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediCapacite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->vendredi_capacite_1 !== $v) {
            $this->vendredi_capacite_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::VENDREDI_CAPACITE_1;
        }


        return $this;
    } // setVendrediCapacite1()

    /**
     * Set the value of [vendredi_nb_rdv_site_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediNbRdvSite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->vendredi_nb_rdv_site_1 !== $v) {
            $this->vendredi_nb_rdv_site_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::VENDREDI_NB_RDV_SITE_1;
        }


        return $this;
    } // setVendrediNbRdvSite1()

    /**
     * Sets the value of [vendredi_heure_debut_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediHeureDebut2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->vendredi_heure_debut_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->vendredi_heure_debut_2 !== null && $tmpDt = new DateTime($this->vendredi_heure_debut_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->vendredi_heure_debut_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::VENDREDI_HEURE_DEBUT_2;
            }
        } // if either are not null


        return $this;
    } // setVendrediHeureDebut2()

    /**
     * Sets the value of [vendredi_heure_fin_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediHeureFin2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->vendredi_heure_fin_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->vendredi_heure_fin_2 !== null && $tmpDt = new DateTime($this->vendredi_heure_fin_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->vendredi_heure_fin_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::VENDREDI_HEURE_FIN_2;
            }
        } // if either are not null


        return $this;
    } // setVendrediHeureFin2()

    /**
     * Set the value of [vendredi_capacite_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediCapacite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->vendredi_capacite_2 !== $v) {
            $this->vendredi_capacite_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::VENDREDI_CAPACITE_2;
        }


        return $this;
    } // setVendrediCapacite2()

    /**
     * Set the value of [vendredi_nb_rdv_site_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setVendrediNbRdvSite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->vendredi_nb_rdv_site_2 !== $v) {
            $this->vendredi_nb_rdv_site_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::VENDREDI_NB_RDV_SITE_2;
        }


        return $this;
    } // setVendrediNbRdvSite2()

    /**
     * Sets the value of [samedi_heure_debut_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediHeureDebut1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->samedi_heure_debut_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->samedi_heure_debut_1 !== null && $tmpDt = new DateTime($this->samedi_heure_debut_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->samedi_heure_debut_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::SAMEDI_HEURE_DEBUT_1;
            }
        } // if either are not null


        return $this;
    } // setSamediHeureDebut1()

    /**
     * Sets the value of [samedi_heure_fin_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediHeureFin1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->samedi_heure_fin_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->samedi_heure_fin_1 !== null && $tmpDt = new DateTime($this->samedi_heure_fin_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->samedi_heure_fin_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::SAMEDI_HEURE_FIN_1;
            }
        } // if either are not null


        return $this;
    } // setSamediHeureFin1()

    /**
     * Set the value of [samedi_capacite_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediCapacite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->samedi_capacite_1 !== $v) {
            $this->samedi_capacite_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::SAMEDI_CAPACITE_1;
        }


        return $this;
    } // setSamediCapacite1()

    /**
     * Set the value of [samedi_nb_rdv_site_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediNbRdvSite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->samedi_nb_rdv_site_1 !== $v) {
            $this->samedi_nb_rdv_site_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::SAMEDI_NB_RDV_SITE_1;
        }


        return $this;
    } // setSamediNbRdvSite1()

    /**
     * Sets the value of [samedi_heure_debut_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediHeureDebut2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->samedi_heure_debut_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->samedi_heure_debut_2 !== null && $tmpDt = new DateTime($this->samedi_heure_debut_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->samedi_heure_debut_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::SAMEDI_HEURE_DEBUT_2;
            }
        } // if either are not null


        return $this;
    } // setSamediHeureDebut2()

    /**
     * Sets the value of [samedi_heure_fin_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediHeureFin2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->samedi_heure_fin_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->samedi_heure_fin_2 !== null && $tmpDt = new DateTime($this->samedi_heure_fin_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->samedi_heure_fin_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::SAMEDI_HEURE_FIN_2;
            }
        } // if either are not null


        return $this;
    } // setSamediHeureFin2()

    /**
     * Set the value of [samedi_capacite_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediCapacite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->samedi_capacite_2 !== $v) {
            $this->samedi_capacite_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::SAMEDI_CAPACITE_2;
        }


        return $this;
    } // setSamediCapacite2()

    /**
     * Set the value of [samedi_nb_rdv_site_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setSamediNbRdvSite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->samedi_nb_rdv_site_2 !== $v) {
            $this->samedi_nb_rdv_site_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::SAMEDI_NB_RDV_SITE_2;
        }


        return $this;
    } // setSamediNbRdvSite2()

    /**
     * Sets the value of [dimanche_heure_debut_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheHeureDebut1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->dimanche_heure_debut_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->dimanche_heure_debut_1 !== null && $tmpDt = new DateTime($this->dimanche_heure_debut_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->dimanche_heure_debut_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_HEURE_DEBUT_1;
            }
        } // if either are not null


        return $this;
    } // setDimancheHeureDebut1()

    /**
     * Sets the value of [dimanche_heure_fin_1] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheHeureFin1($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->dimanche_heure_fin_1 !== null || $dt !== null) {
            $currentDateAsString = ($this->dimanche_heure_fin_1 !== null && $tmpDt = new DateTime($this->dimanche_heure_fin_1)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->dimanche_heure_fin_1 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_HEURE_FIN_1;
            }
        } // if either are not null


        return $this;
    } // setDimancheHeureFin1()

    /**
     * Set the value of [dimanche_capacite_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheCapacite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->dimanche_capacite_1 !== $v) {
            $this->dimanche_capacite_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_CAPACITE_1;
        }


        return $this;
    } // setDimancheCapacite1()

    /**
     * Set the value of [dimanche_nb_rdv_site_1] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheNbRdvSite1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->dimanche_nb_rdv_site_1 !== $v) {
            $this->dimanche_nb_rdv_site_1 = $v;
            $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_NB_RDV_SITE_1;
        }


        return $this;
    } // setDimancheNbRdvSite1()

    /**
     * Sets the value of [dimanche_heure_debut_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheHeureDebut2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->dimanche_heure_debut_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->dimanche_heure_debut_2 !== null && $tmpDt = new DateTime($this->dimanche_heure_debut_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->dimanche_heure_debut_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_HEURE_DEBUT_2;
            }
        } // if either are not null


        return $this;
    } // setDimancheHeureDebut2()

    /**
     * Sets the value of [dimanche_heure_fin_2] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheHeureFin2($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->dimanche_heure_fin_2 !== null || $dt !== null) {
            $currentDateAsString = ($this->dimanche_heure_fin_2 !== null && $tmpDt = new DateTime($this->dimanche_heure_fin_2)) ? $tmpDt->format('H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->dimanche_heure_fin_2 = $newDateAsString;
                $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_HEURE_FIN_2;
            }
        } // if either are not null


        return $this;
    } // setDimancheHeureFin2()

    /**
     * Set the value of [dimanche_capacite_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheCapacite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->dimanche_capacite_2 !== $v) {
            $this->dimanche_capacite_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_CAPACITE_2;
        }


        return $this;
    } // setDimancheCapacite2()

    /**
     * Set the value of [dimanche_nb_rdv_site_2] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setDimancheNbRdvSite2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->dimanche_nb_rdv_site_2 !== $v) {
            $this->dimanche_nb_rdv_site_2 = $v;
            $this->modifiedColumns[] = TPeriodePeer::DIMANCHE_NB_RDV_SITE_2;
        }


        return $this;
    } // setDimancheNbRdvSite2()

    /**
     * Set the value of [id_agenda] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setIdAgenda($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_agenda !== $v) {
            $this->id_agenda = $v;
            $this->modifiedColumns[] = TPeriodePeer::ID_AGENDA;
        }

        if ($this->aTAgenda !== null && $this->aTAgenda->getIdAgenda() !== $v) {
            $this->aTAgenda = null;
        }


        return $this;
    } // setIdAgenda()

    /**
     * Set the value of [periodicite] column.
     *
     * @param int $v new value
     * @return TPeriode The current object (for fluent API support)
     */
    public function setPeriodicite($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->periodicite !== $v) {
            $this->periodicite = $v;
            $this->modifiedColumns[] = TPeriodePeer::PERIODICITE;
        }


        return $this;
    } // setPeriodicite()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->periodicite !== 0) {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_periode = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->debut_periode = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->fin_periode = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->lundi_heure_debut_1 = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->lundi_heure_fin_1 = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->lundi_capacite_1 = ($row[$startcol + 5] !== null) ? (int) $row[$startcol + 5] : null;
            $this->lundi_nb_rdv_site_1 = ($row[$startcol + 6] !== null) ? (int) $row[$startcol + 6] : null;
            $this->lundi_heure_debut_2 = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->lundi_heure_fin_2 = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->lundi_capacite_2 = ($row[$startcol + 9] !== null) ? (int) $row[$startcol + 9] : null;
            $this->lundi_nb_rdv_site_2 = ($row[$startcol + 10] !== null) ? (int) $row[$startcol + 10] : null;
            $this->mardi_heure_debut_1 = ($row[$startcol + 11] !== null) ? (string) $row[$startcol + 11] : null;
            $this->mardi_heure_fin_1 = ($row[$startcol + 12] !== null) ? (string) $row[$startcol + 12] : null;
            $this->mardi_capacite_1 = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->mardi_nb_rdv_site_1 = ($row[$startcol + 14] !== null) ? (int) $row[$startcol + 14] : null;
            $this->mardi_heure_debut_2 = ($row[$startcol + 15] !== null) ? (string) $row[$startcol + 15] : null;
            $this->mardi_heure_fin_2 = ($row[$startcol + 16] !== null) ? (string) $row[$startcol + 16] : null;
            $this->mardi_capacite_2 = ($row[$startcol + 17] !== null) ? (int) $row[$startcol + 17] : null;
            $this->mardi_nb_rdv_site_2 = ($row[$startcol + 18] !== null) ? (int) $row[$startcol + 18] : null;
            $this->mercredi_heure_debut_1 = ($row[$startcol + 19] !== null) ? (string) $row[$startcol + 19] : null;
            $this->mercredi_heure_fin_1 = ($row[$startcol + 20] !== null) ? (string) $row[$startcol + 20] : null;
            $this->mercredi_capacite_1 = ($row[$startcol + 21] !== null) ? (int) $row[$startcol + 21] : null;
            $this->mercredi_nb_rdv_site_1 = ($row[$startcol + 22] !== null) ? (int) $row[$startcol + 22] : null;
            $this->mercredi_heure_debut_2 = ($row[$startcol + 23] !== null) ? (string) $row[$startcol + 23] : null;
            $this->mercredi_heure_fin_2 = ($row[$startcol + 24] !== null) ? (string) $row[$startcol + 24] : null;
            $this->mercredi_capacite_2 = ($row[$startcol + 25] !== null) ? (int) $row[$startcol + 25] : null;
            $this->mercredi_nb_rdv_site_2 = ($row[$startcol + 26] !== null) ? (int) $row[$startcol + 26] : null;
            $this->jeudi_heure_debut_1 = ($row[$startcol + 27] !== null) ? (string) $row[$startcol + 27] : null;
            $this->jeudi_heure_fin_1 = ($row[$startcol + 28] !== null) ? (string) $row[$startcol + 28] : null;
            $this->jeudi_capacite_1 = ($row[$startcol + 29] !== null) ? (int) $row[$startcol + 29] : null;
            $this->jeudi_nb_rdv_site_1 = ($row[$startcol + 30] !== null) ? (int) $row[$startcol + 30] : null;
            $this->jeudi_heure_debut_2 = ($row[$startcol + 31] !== null) ? (string) $row[$startcol + 31] : null;
            $this->jeudi_heure_fin_2 = ($row[$startcol + 32] !== null) ? (string) $row[$startcol + 32] : null;
            $this->jeudi_capacite_2 = ($row[$startcol + 33] !== null) ? (int) $row[$startcol + 33] : null;
            $this->jeudi_nb_rdv_site_2 = ($row[$startcol + 34] !== null) ? (int) $row[$startcol + 34] : null;
            $this->vendredi_heure_debut_1 = ($row[$startcol + 35] !== null) ? (string) $row[$startcol + 35] : null;
            $this->vendredi_heure_fin_1 = ($row[$startcol + 36] !== null) ? (string) $row[$startcol + 36] : null;
            $this->vendredi_capacite_1 = ($row[$startcol + 37] !== null) ? (int) $row[$startcol + 37] : null;
            $this->vendredi_nb_rdv_site_1 = ($row[$startcol + 38] !== null) ? (int) $row[$startcol + 38] : null;
            $this->vendredi_heure_debut_2 = ($row[$startcol + 39] !== null) ? (string) $row[$startcol + 39] : null;
            $this->vendredi_heure_fin_2 = ($row[$startcol + 40] !== null) ? (string) $row[$startcol + 40] : null;
            $this->vendredi_capacite_2 = ($row[$startcol + 41] !== null) ? (int) $row[$startcol + 41] : null;
            $this->vendredi_nb_rdv_site_2 = ($row[$startcol + 42] !== null) ? (int) $row[$startcol + 42] : null;
            $this->samedi_heure_debut_1 = ($row[$startcol + 43] !== null) ? (string) $row[$startcol + 43] : null;
            $this->samedi_heure_fin_1 = ($row[$startcol + 44] !== null) ? (string) $row[$startcol + 44] : null;
            $this->samedi_capacite_1 = ($row[$startcol + 45] !== null) ? (int) $row[$startcol + 45] : null;
            $this->samedi_nb_rdv_site_1 = ($row[$startcol + 46] !== null) ? (int) $row[$startcol + 46] : null;
            $this->samedi_heure_debut_2 = ($row[$startcol + 47] !== null) ? (string) $row[$startcol + 47] : null;
            $this->samedi_heure_fin_2 = ($row[$startcol + 48] !== null) ? (string) $row[$startcol + 48] : null;
            $this->samedi_capacite_2 = ($row[$startcol + 49] !== null) ? (int) $row[$startcol + 49] : null;
            $this->samedi_nb_rdv_site_2 = ($row[$startcol + 50] !== null) ? (int) $row[$startcol + 50] : null;
            $this->dimanche_heure_debut_1 = ($row[$startcol + 51] !== null) ? (string) $row[$startcol + 51] : null;
            $this->dimanche_heure_fin_1 = ($row[$startcol + 52] !== null) ? (string) $row[$startcol + 52] : null;
            $this->dimanche_capacite_1 = ($row[$startcol + 53] !== null) ? (int) $row[$startcol + 53] : null;
            $this->dimanche_nb_rdv_site_1 = ($row[$startcol + 54] !== null) ? (int) $row[$startcol + 54] : null;
            $this->dimanche_heure_debut_2 = ($row[$startcol + 55] !== null) ? (string) $row[$startcol + 55] : null;
            $this->dimanche_heure_fin_2 = ($row[$startcol + 56] !== null) ? (string) $row[$startcol + 56] : null;
            $this->dimanche_capacite_2 = ($row[$startcol + 57] !== null) ? (int) $row[$startcol + 57] : null;
            $this->dimanche_nb_rdv_site_2 = ($row[$startcol + 58] !== null) ? (int) $row[$startcol + 58] : null;
            $this->id_agenda = ($row[$startcol + 59] !== null) ? (int) $row[$startcol + 59] : null;
            $this->periodicite = ($row[$startcol + 60] !== null) ? (int) $row[$startcol + 60] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 61; // 61 = TPeriodePeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TPeriode object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTAgenda !== null && $this->id_agenda !== $this->aTAgenda->getIdAgenda()) {
            $this->aTAgenda = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPeriodePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TPeriodePeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTAgenda = null;
        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPeriodePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TPeriodeQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPeriodePeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TPeriodePeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTAgenda !== null) {
                if ($this->aTAgenda->isModified() || $this->aTAgenda->isNew()) {
                    $affectedRows += $this->aTAgenda->save($con);
                }
                $this->setTAgenda($this->aTAgenda);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TPeriodePeer::ID_PERIODE;
        if (null !== $this->id_periode) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TPeriodePeer::ID_PERIODE . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TPeriodePeer::ID_PERIODE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PERIODE`';
        }
        if ($this->isColumnModified(TPeriodePeer::DEBUT_PERIODE)) {
            $modifiedColumns[':p' . $index++]  = '`DEBUT_PERIODE`';
        }
        if ($this->isColumnModified(TPeriodePeer::FIN_PERIODE)) {
            $modifiedColumns[':p' . $index++]  = '`FIN_PERIODE`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_DEBUT_1)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_HEURE_DEBUT_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_FIN_1)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_HEURE_FIN_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_CAPACITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_CAPACITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_NB_RDV_SITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_NB_RDV_SITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_DEBUT_2)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_HEURE_DEBUT_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_FIN_2)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_HEURE_FIN_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_CAPACITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_CAPACITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::LUNDI_NB_RDV_SITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`LUNDI_NB_RDV_SITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_DEBUT_1)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_HEURE_DEBUT_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_FIN_1)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_HEURE_FIN_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_CAPACITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_CAPACITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_NB_RDV_SITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_NB_RDV_SITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_DEBUT_2)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_HEURE_DEBUT_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_FIN_2)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_HEURE_FIN_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_CAPACITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_CAPACITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MARDI_NB_RDV_SITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`MARDI_NB_RDV_SITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_DEBUT_1)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_HEURE_DEBUT_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_FIN_1)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_HEURE_FIN_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_CAPACITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_CAPACITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_NB_RDV_SITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_NB_RDV_SITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_DEBUT_2)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_HEURE_DEBUT_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_FIN_2)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_HEURE_FIN_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_CAPACITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_CAPACITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_NB_RDV_SITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`MERCREDI_NB_RDV_SITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_DEBUT_1)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_HEURE_DEBUT_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_FIN_1)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_HEURE_FIN_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_CAPACITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_CAPACITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_NB_RDV_SITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_NB_RDV_SITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_DEBUT_2)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_HEURE_DEBUT_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_FIN_2)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_HEURE_FIN_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_CAPACITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_CAPACITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::JEUDI_NB_RDV_SITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`JEUDI_NB_RDV_SITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_DEBUT_1)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_HEURE_DEBUT_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_FIN_1)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_HEURE_FIN_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_CAPACITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_CAPACITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_NB_RDV_SITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_NB_RDV_SITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_DEBUT_2)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_HEURE_DEBUT_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_FIN_2)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_HEURE_FIN_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_CAPACITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_CAPACITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_NB_RDV_SITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`VENDREDI_NB_RDV_SITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_DEBUT_1)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_HEURE_DEBUT_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_FIN_1)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_HEURE_FIN_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_CAPACITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_CAPACITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_NB_RDV_SITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_NB_RDV_SITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_DEBUT_2)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_HEURE_DEBUT_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_FIN_2)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_HEURE_FIN_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_CAPACITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_CAPACITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_NB_RDV_SITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`SAMEDI_NB_RDV_SITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_DEBUT_1)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_HEURE_DEBUT_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_FIN_1)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_HEURE_FIN_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_CAPACITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_CAPACITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_NB_RDV_SITE_1)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_NB_RDV_SITE_1`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_DEBUT_2)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_HEURE_DEBUT_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_FIN_2)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_HEURE_FIN_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_CAPACITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_CAPACITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_NB_RDV_SITE_2)) {
            $modifiedColumns[':p' . $index++]  = '`DIMANCHE_NB_RDV_SITE_2`';
        }
        if ($this->isColumnModified(TPeriodePeer::ID_AGENDA)) {
            $modifiedColumns[':p' . $index++]  = '`ID_AGENDA`';
        }
        if ($this->isColumnModified(TPeriodePeer::PERIODICITE)) {
            $modifiedColumns[':p' . $index++]  = '`PERIODICITE`';
        }

        $sql = sprintf(
            'INSERT INTO `T_PERIODE` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_PERIODE`':
                        $stmt->bindValue($identifier, $this->id_periode, PDO::PARAM_INT);
                        break;
                    case '`DEBUT_PERIODE`':
                        $stmt->bindValue($identifier, $this->debut_periode, PDO::PARAM_STR);
                        break;
                    case '`FIN_PERIODE`':
                        $stmt->bindValue($identifier, $this->fin_periode, PDO::PARAM_STR);
                        break;
                    case '`LUNDI_HEURE_DEBUT_1`':
                        $stmt->bindValue($identifier, $this->lundi_heure_debut_1, PDO::PARAM_STR);
                        break;
                    case '`LUNDI_HEURE_FIN_1`':
                        $stmt->bindValue($identifier, $this->lundi_heure_fin_1, PDO::PARAM_STR);
                        break;
                    case '`LUNDI_CAPACITE_1`':
                        $stmt->bindValue($identifier, $this->lundi_capacite_1, PDO::PARAM_INT);
                        break;
                    case '`LUNDI_NB_RDV_SITE_1`':
                        $stmt->bindValue($identifier, $this->lundi_nb_rdv_site_1, PDO::PARAM_INT);
                        break;
                    case '`LUNDI_HEURE_DEBUT_2`':
                        $stmt->bindValue($identifier, $this->lundi_heure_debut_2, PDO::PARAM_STR);
                        break;
                    case '`LUNDI_HEURE_FIN_2`':
                        $stmt->bindValue($identifier, $this->lundi_heure_fin_2, PDO::PARAM_STR);
                        break;
                    case '`LUNDI_CAPACITE_2`':
                        $stmt->bindValue($identifier, $this->lundi_capacite_2, PDO::PARAM_INT);
                        break;
                    case '`LUNDI_NB_RDV_SITE_2`':
                        $stmt->bindValue($identifier, $this->lundi_nb_rdv_site_2, PDO::PARAM_INT);
                        break;
                    case '`MARDI_HEURE_DEBUT_1`':
                        $stmt->bindValue($identifier, $this->mardi_heure_debut_1, PDO::PARAM_STR);
                        break;
                    case '`MARDI_HEURE_FIN_1`':
                        $stmt->bindValue($identifier, $this->mardi_heure_fin_1, PDO::PARAM_STR);
                        break;
                    case '`MARDI_CAPACITE_1`':
                        $stmt->bindValue($identifier, $this->mardi_capacite_1, PDO::PARAM_INT);
                        break;
                    case '`MARDI_NB_RDV_SITE_1`':
                        $stmt->bindValue($identifier, $this->mardi_nb_rdv_site_1, PDO::PARAM_INT);
                        break;
                    case '`MARDI_HEURE_DEBUT_2`':
                        $stmt->bindValue($identifier, $this->mardi_heure_debut_2, PDO::PARAM_STR);
                        break;
                    case '`MARDI_HEURE_FIN_2`':
                        $stmt->bindValue($identifier, $this->mardi_heure_fin_2, PDO::PARAM_STR);
                        break;
                    case '`MARDI_CAPACITE_2`':
                        $stmt->bindValue($identifier, $this->mardi_capacite_2, PDO::PARAM_INT);
                        break;
                    case '`MARDI_NB_RDV_SITE_2`':
                        $stmt->bindValue($identifier, $this->mardi_nb_rdv_site_2, PDO::PARAM_INT);
                        break;
                    case '`MERCREDI_HEURE_DEBUT_1`':
                        $stmt->bindValue($identifier, $this->mercredi_heure_debut_1, PDO::PARAM_STR);
                        break;
                    case '`MERCREDI_HEURE_FIN_1`':
                        $stmt->bindValue($identifier, $this->mercredi_heure_fin_1, PDO::PARAM_STR);
                        break;
                    case '`MERCREDI_CAPACITE_1`':
                        $stmt->bindValue($identifier, $this->mercredi_capacite_1, PDO::PARAM_INT);
                        break;
                    case '`MERCREDI_NB_RDV_SITE_1`':
                        $stmt->bindValue($identifier, $this->mercredi_nb_rdv_site_1, PDO::PARAM_INT);
                        break;
                    case '`MERCREDI_HEURE_DEBUT_2`':
                        $stmt->bindValue($identifier, $this->mercredi_heure_debut_2, PDO::PARAM_STR);
                        break;
                    case '`MERCREDI_HEURE_FIN_2`':
                        $stmt->bindValue($identifier, $this->mercredi_heure_fin_2, PDO::PARAM_STR);
                        break;
                    case '`MERCREDI_CAPACITE_2`':
                        $stmt->bindValue($identifier, $this->mercredi_capacite_2, PDO::PARAM_INT);
                        break;
                    case '`MERCREDI_NB_RDV_SITE_2`':
                        $stmt->bindValue($identifier, $this->mercredi_nb_rdv_site_2, PDO::PARAM_INT);
                        break;
                    case '`JEUDI_HEURE_DEBUT_1`':
                        $stmt->bindValue($identifier, $this->jeudi_heure_debut_1, PDO::PARAM_STR);
                        break;
                    case '`JEUDI_HEURE_FIN_1`':
                        $stmt->bindValue($identifier, $this->jeudi_heure_fin_1, PDO::PARAM_STR);
                        break;
                    case '`JEUDI_CAPACITE_1`':
                        $stmt->bindValue($identifier, $this->jeudi_capacite_1, PDO::PARAM_INT);
                        break;
                    case '`JEUDI_NB_RDV_SITE_1`':
                        $stmt->bindValue($identifier, $this->jeudi_nb_rdv_site_1, PDO::PARAM_INT);
                        break;
                    case '`JEUDI_HEURE_DEBUT_2`':
                        $stmt->bindValue($identifier, $this->jeudi_heure_debut_2, PDO::PARAM_STR);
                        break;
                    case '`JEUDI_HEURE_FIN_2`':
                        $stmt->bindValue($identifier, $this->jeudi_heure_fin_2, PDO::PARAM_STR);
                        break;
                    case '`JEUDI_CAPACITE_2`':
                        $stmt->bindValue($identifier, $this->jeudi_capacite_2, PDO::PARAM_INT);
                        break;
                    case '`JEUDI_NB_RDV_SITE_2`':
                        $stmt->bindValue($identifier, $this->jeudi_nb_rdv_site_2, PDO::PARAM_INT);
                        break;
                    case '`VENDREDI_HEURE_DEBUT_1`':
                        $stmt->bindValue($identifier, $this->vendredi_heure_debut_1, PDO::PARAM_STR);
                        break;
                    case '`VENDREDI_HEURE_FIN_1`':
                        $stmt->bindValue($identifier, $this->vendredi_heure_fin_1, PDO::PARAM_STR);
                        break;
                    case '`VENDREDI_CAPACITE_1`':
                        $stmt->bindValue($identifier, $this->vendredi_capacite_1, PDO::PARAM_INT);
                        break;
                    case '`VENDREDI_NB_RDV_SITE_1`':
                        $stmt->bindValue($identifier, $this->vendredi_nb_rdv_site_1, PDO::PARAM_INT);
                        break;
                    case '`VENDREDI_HEURE_DEBUT_2`':
                        $stmt->bindValue($identifier, $this->vendredi_heure_debut_2, PDO::PARAM_STR);
                        break;
                    case '`VENDREDI_HEURE_FIN_2`':
                        $stmt->bindValue($identifier, $this->vendredi_heure_fin_2, PDO::PARAM_STR);
                        break;
                    case '`VENDREDI_CAPACITE_2`':
                        $stmt->bindValue($identifier, $this->vendredi_capacite_2, PDO::PARAM_INT);
                        break;
                    case '`VENDREDI_NB_RDV_SITE_2`':
                        $stmt->bindValue($identifier, $this->vendredi_nb_rdv_site_2, PDO::PARAM_INT);
                        break;
                    case '`SAMEDI_HEURE_DEBUT_1`':
                        $stmt->bindValue($identifier, $this->samedi_heure_debut_1, PDO::PARAM_STR);
                        break;
                    case '`SAMEDI_HEURE_FIN_1`':
                        $stmt->bindValue($identifier, $this->samedi_heure_fin_1, PDO::PARAM_STR);
                        break;
                    case '`SAMEDI_CAPACITE_1`':
                        $stmt->bindValue($identifier, $this->samedi_capacite_1, PDO::PARAM_INT);
                        break;
                    case '`SAMEDI_NB_RDV_SITE_1`':
                        $stmt->bindValue($identifier, $this->samedi_nb_rdv_site_1, PDO::PARAM_INT);
                        break;
                    case '`SAMEDI_HEURE_DEBUT_2`':
                        $stmt->bindValue($identifier, $this->samedi_heure_debut_2, PDO::PARAM_STR);
                        break;
                    case '`SAMEDI_HEURE_FIN_2`':
                        $stmt->bindValue($identifier, $this->samedi_heure_fin_2, PDO::PARAM_STR);
                        break;
                    case '`SAMEDI_CAPACITE_2`':
                        $stmt->bindValue($identifier, $this->samedi_capacite_2, PDO::PARAM_INT);
                        break;
                    case '`SAMEDI_NB_RDV_SITE_2`':
                        $stmt->bindValue($identifier, $this->samedi_nb_rdv_site_2, PDO::PARAM_INT);
                        break;
                    case '`DIMANCHE_HEURE_DEBUT_1`':
                        $stmt->bindValue($identifier, $this->dimanche_heure_debut_1, PDO::PARAM_STR);
                        break;
                    case '`DIMANCHE_HEURE_FIN_1`':
                        $stmt->bindValue($identifier, $this->dimanche_heure_fin_1, PDO::PARAM_STR);
                        break;
                    case '`DIMANCHE_CAPACITE_1`':
                        $stmt->bindValue($identifier, $this->dimanche_capacite_1, PDO::PARAM_INT);
                        break;
                    case '`DIMANCHE_NB_RDV_SITE_1`':
                        $stmt->bindValue($identifier, $this->dimanche_nb_rdv_site_1, PDO::PARAM_INT);
                        break;
                    case '`DIMANCHE_HEURE_DEBUT_2`':
                        $stmt->bindValue($identifier, $this->dimanche_heure_debut_2, PDO::PARAM_STR);
                        break;
                    case '`DIMANCHE_HEURE_FIN_2`':
                        $stmt->bindValue($identifier, $this->dimanche_heure_fin_2, PDO::PARAM_STR);
                        break;
                    case '`DIMANCHE_CAPACITE_2`':
                        $stmt->bindValue($identifier, $this->dimanche_capacite_2, PDO::PARAM_INT);
                        break;
                    case '`DIMANCHE_NB_RDV_SITE_2`':
                        $stmt->bindValue($identifier, $this->dimanche_nb_rdv_site_2, PDO::PARAM_INT);
                        break;
                    case '`ID_AGENDA`':
                        $stmt->bindValue($identifier, $this->id_agenda, PDO::PARAM_INT);
                        break;
                    case '`PERIODICITE`':
                        $stmt->bindValue($identifier, $this->periodicite, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdPeriode($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTAgenda !== null) {
                if (!$this->aTAgenda->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTAgenda->getValidationFailures());
                }
            }


            if (($retval = TPeriodePeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }



            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TPeriodePeer::DATABASE_NAME);

        if ($this->isColumnModified(TPeriodePeer::ID_PERIODE)) $criteria->add(TPeriodePeer::ID_PERIODE, $this->id_periode);
        if ($this->isColumnModified(TPeriodePeer::DEBUT_PERIODE)) $criteria->add(TPeriodePeer::DEBUT_PERIODE, $this->debut_periode);
        if ($this->isColumnModified(TPeriodePeer::FIN_PERIODE)) $criteria->add(TPeriodePeer::FIN_PERIODE, $this->fin_periode);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_DEBUT_1)) $criteria->add(TPeriodePeer::LUNDI_HEURE_DEBUT_1, $this->lundi_heure_debut_1);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_FIN_1)) $criteria->add(TPeriodePeer::LUNDI_HEURE_FIN_1, $this->lundi_heure_fin_1);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_CAPACITE_1)) $criteria->add(TPeriodePeer::LUNDI_CAPACITE_1, $this->lundi_capacite_1);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_NB_RDV_SITE_1)) $criteria->add(TPeriodePeer::LUNDI_NB_RDV_SITE_1, $this->lundi_nb_rdv_site_1);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_DEBUT_2)) $criteria->add(TPeriodePeer::LUNDI_HEURE_DEBUT_2, $this->lundi_heure_debut_2);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_HEURE_FIN_2)) $criteria->add(TPeriodePeer::LUNDI_HEURE_FIN_2, $this->lundi_heure_fin_2);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_CAPACITE_2)) $criteria->add(TPeriodePeer::LUNDI_CAPACITE_2, $this->lundi_capacite_2);
        if ($this->isColumnModified(TPeriodePeer::LUNDI_NB_RDV_SITE_2)) $criteria->add(TPeriodePeer::LUNDI_NB_RDV_SITE_2, $this->lundi_nb_rdv_site_2);
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_DEBUT_1)) $criteria->add(TPeriodePeer::MARDI_HEURE_DEBUT_1, $this->mardi_heure_debut_1);
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_FIN_1)) $criteria->add(TPeriodePeer::MARDI_HEURE_FIN_1, $this->mardi_heure_fin_1);
        if ($this->isColumnModified(TPeriodePeer::MARDI_CAPACITE_1)) $criteria->add(TPeriodePeer::MARDI_CAPACITE_1, $this->mardi_capacite_1);
        if ($this->isColumnModified(TPeriodePeer::MARDI_NB_RDV_SITE_1)) $criteria->add(TPeriodePeer::MARDI_NB_RDV_SITE_1, $this->mardi_nb_rdv_site_1);
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_DEBUT_2)) $criteria->add(TPeriodePeer::MARDI_HEURE_DEBUT_2, $this->mardi_heure_debut_2);
        if ($this->isColumnModified(TPeriodePeer::MARDI_HEURE_FIN_2)) $criteria->add(TPeriodePeer::MARDI_HEURE_FIN_2, $this->mardi_heure_fin_2);
        if ($this->isColumnModified(TPeriodePeer::MARDI_CAPACITE_2)) $criteria->add(TPeriodePeer::MARDI_CAPACITE_2, $this->mardi_capacite_2);
        if ($this->isColumnModified(TPeriodePeer::MARDI_NB_RDV_SITE_2)) $criteria->add(TPeriodePeer::MARDI_NB_RDV_SITE_2, $this->mardi_nb_rdv_site_2);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_DEBUT_1)) $criteria->add(TPeriodePeer::MERCREDI_HEURE_DEBUT_1, $this->mercredi_heure_debut_1);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_FIN_1)) $criteria->add(TPeriodePeer::MERCREDI_HEURE_FIN_1, $this->mercredi_heure_fin_1);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_CAPACITE_1)) $criteria->add(TPeriodePeer::MERCREDI_CAPACITE_1, $this->mercredi_capacite_1);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_NB_RDV_SITE_1)) $criteria->add(TPeriodePeer::MERCREDI_NB_RDV_SITE_1, $this->mercredi_nb_rdv_site_1);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_DEBUT_2)) $criteria->add(TPeriodePeer::MERCREDI_HEURE_DEBUT_2, $this->mercredi_heure_debut_2);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_HEURE_FIN_2)) $criteria->add(TPeriodePeer::MERCREDI_HEURE_FIN_2, $this->mercredi_heure_fin_2);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_CAPACITE_2)) $criteria->add(TPeriodePeer::MERCREDI_CAPACITE_2, $this->mercredi_capacite_2);
        if ($this->isColumnModified(TPeriodePeer::MERCREDI_NB_RDV_SITE_2)) $criteria->add(TPeriodePeer::MERCREDI_NB_RDV_SITE_2, $this->mercredi_nb_rdv_site_2);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_DEBUT_1)) $criteria->add(TPeriodePeer::JEUDI_HEURE_DEBUT_1, $this->jeudi_heure_debut_1);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_FIN_1)) $criteria->add(TPeriodePeer::JEUDI_HEURE_FIN_1, $this->jeudi_heure_fin_1);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_CAPACITE_1)) $criteria->add(TPeriodePeer::JEUDI_CAPACITE_1, $this->jeudi_capacite_1);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_NB_RDV_SITE_1)) $criteria->add(TPeriodePeer::JEUDI_NB_RDV_SITE_1, $this->jeudi_nb_rdv_site_1);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_DEBUT_2)) $criteria->add(TPeriodePeer::JEUDI_HEURE_DEBUT_2, $this->jeudi_heure_debut_2);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_HEURE_FIN_2)) $criteria->add(TPeriodePeer::JEUDI_HEURE_FIN_2, $this->jeudi_heure_fin_2);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_CAPACITE_2)) $criteria->add(TPeriodePeer::JEUDI_CAPACITE_2, $this->jeudi_capacite_2);
        if ($this->isColumnModified(TPeriodePeer::JEUDI_NB_RDV_SITE_2)) $criteria->add(TPeriodePeer::JEUDI_NB_RDV_SITE_2, $this->jeudi_nb_rdv_site_2);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_DEBUT_1)) $criteria->add(TPeriodePeer::VENDREDI_HEURE_DEBUT_1, $this->vendredi_heure_debut_1);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_FIN_1)) $criteria->add(TPeriodePeer::VENDREDI_HEURE_FIN_1, $this->vendredi_heure_fin_1);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_CAPACITE_1)) $criteria->add(TPeriodePeer::VENDREDI_CAPACITE_1, $this->vendredi_capacite_1);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_NB_RDV_SITE_1)) $criteria->add(TPeriodePeer::VENDREDI_NB_RDV_SITE_1, $this->vendredi_nb_rdv_site_1);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_DEBUT_2)) $criteria->add(TPeriodePeer::VENDREDI_HEURE_DEBUT_2, $this->vendredi_heure_debut_2);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_HEURE_FIN_2)) $criteria->add(TPeriodePeer::VENDREDI_HEURE_FIN_2, $this->vendredi_heure_fin_2);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_CAPACITE_2)) $criteria->add(TPeriodePeer::VENDREDI_CAPACITE_2, $this->vendredi_capacite_2);
        if ($this->isColumnModified(TPeriodePeer::VENDREDI_NB_RDV_SITE_2)) $criteria->add(TPeriodePeer::VENDREDI_NB_RDV_SITE_2, $this->vendredi_nb_rdv_site_2);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_DEBUT_1)) $criteria->add(TPeriodePeer::SAMEDI_HEURE_DEBUT_1, $this->samedi_heure_debut_1);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_FIN_1)) $criteria->add(TPeriodePeer::SAMEDI_HEURE_FIN_1, $this->samedi_heure_fin_1);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_CAPACITE_1)) $criteria->add(TPeriodePeer::SAMEDI_CAPACITE_1, $this->samedi_capacite_1);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_NB_RDV_SITE_1)) $criteria->add(TPeriodePeer::SAMEDI_NB_RDV_SITE_1, $this->samedi_nb_rdv_site_1);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_DEBUT_2)) $criteria->add(TPeriodePeer::SAMEDI_HEURE_DEBUT_2, $this->samedi_heure_debut_2);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_HEURE_FIN_2)) $criteria->add(TPeriodePeer::SAMEDI_HEURE_FIN_2, $this->samedi_heure_fin_2);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_CAPACITE_2)) $criteria->add(TPeriodePeer::SAMEDI_CAPACITE_2, $this->samedi_capacite_2);
        if ($this->isColumnModified(TPeriodePeer::SAMEDI_NB_RDV_SITE_2)) $criteria->add(TPeriodePeer::SAMEDI_NB_RDV_SITE_2, $this->samedi_nb_rdv_site_2);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_DEBUT_1)) $criteria->add(TPeriodePeer::DIMANCHE_HEURE_DEBUT_1, $this->dimanche_heure_debut_1);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_FIN_1)) $criteria->add(TPeriodePeer::DIMANCHE_HEURE_FIN_1, $this->dimanche_heure_fin_1);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_CAPACITE_1)) $criteria->add(TPeriodePeer::DIMANCHE_CAPACITE_1, $this->dimanche_capacite_1);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_NB_RDV_SITE_1)) $criteria->add(TPeriodePeer::DIMANCHE_NB_RDV_SITE_1, $this->dimanche_nb_rdv_site_1);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_DEBUT_2)) $criteria->add(TPeriodePeer::DIMANCHE_HEURE_DEBUT_2, $this->dimanche_heure_debut_2);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_HEURE_FIN_2)) $criteria->add(TPeriodePeer::DIMANCHE_HEURE_FIN_2, $this->dimanche_heure_fin_2);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_CAPACITE_2)) $criteria->add(TPeriodePeer::DIMANCHE_CAPACITE_2, $this->dimanche_capacite_2);
        if ($this->isColumnModified(TPeriodePeer::DIMANCHE_NB_RDV_SITE_2)) $criteria->add(TPeriodePeer::DIMANCHE_NB_RDV_SITE_2, $this->dimanche_nb_rdv_site_2);
        if ($this->isColumnModified(TPeriodePeer::ID_AGENDA)) $criteria->add(TPeriodePeer::ID_AGENDA, $this->id_agenda);
        if ($this->isColumnModified(TPeriodePeer::PERIODICITE)) $criteria->add(TPeriodePeer::PERIODICITE, $this->periodicite);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TPeriodePeer::DATABASE_NAME);
        $criteria->add(TPeriodePeer::ID_PERIODE, $this->id_periode);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdPeriode();
    }

    /**
     * Generic method to set the primary key (id_periode column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdPeriode($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdPeriode();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TPeriode (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setDebutPeriode($this->getDebutPeriode());
        $copyObj->setFinPeriode($this->getFinPeriode());
        $copyObj->setLundiHeureDebut1($this->getLundiHeureDebut1());
        $copyObj->setLundiHeureFin1($this->getLundiHeureFin1());
        $copyObj->setLundiCapacite1($this->getLundiCapacite1());
        $copyObj->setLundiNbRdvSite1($this->getLundiNbRdvSite1());
        $copyObj->setLundiHeureDebut2($this->getLundiHeureDebut2());
        $copyObj->setLundiHeureFin2($this->getLundiHeureFin2());
        $copyObj->setLundiCapacite2($this->getLundiCapacite2());
        $copyObj->setLundiNbRdvSite2($this->getLundiNbRdvSite2());
        $copyObj->setMardiHeureDebut1($this->getMardiHeureDebut1());
        $copyObj->setMardiHeureFin1($this->getMardiHeureFin1());
        $copyObj->setMardiCapacite1($this->getMardiCapacite1());
        $copyObj->setMardiNbRdvSite1($this->getMardiNbRdvSite1());
        $copyObj->setMardiHeureDebut2($this->getMardiHeureDebut2());
        $copyObj->setMardiHeureFin2($this->getMardiHeureFin2());
        $copyObj->setMardiCapacite2($this->getMardiCapacite2());
        $copyObj->setMardiNbRdvSite2($this->getMardiNbRdvSite2());
        $copyObj->setMercrediHeureDebut1($this->getMercrediHeureDebut1());
        $copyObj->setMercrediHeureFin1($this->getMercrediHeureFin1());
        $copyObj->setMercrediCapacite1($this->getMercrediCapacite1());
        $copyObj->setMercrediNbRdvSite1($this->getMercrediNbRdvSite1());
        $copyObj->setMercrediHeureDebut2($this->getMercrediHeureDebut2());
        $copyObj->setMercrediHeureFin2($this->getMercrediHeureFin2());
        $copyObj->setMercrediCapacite2($this->getMercrediCapacite2());
        $copyObj->setMercrediNbRdvSite2($this->getMercrediNbRdvSite2());
        $copyObj->setJeudiHeureDebut1($this->getJeudiHeureDebut1());
        $copyObj->setJeudiHeureFin1($this->getJeudiHeureFin1());
        $copyObj->setJeudiCapacite1($this->getJeudiCapacite1());
        $copyObj->setJeudiNbRdvSite1($this->getJeudiNbRdvSite1());
        $copyObj->setJeudiHeureDebut2($this->getJeudiHeureDebut2());
        $copyObj->setJeudiHeureFin2($this->getJeudiHeureFin2());
        $copyObj->setJeudiCapacite2($this->getJeudiCapacite2());
        $copyObj->setJeudiNbRdvSite2($this->getJeudiNbRdvSite2());
        $copyObj->setVendrediHeureDebut1($this->getVendrediHeureDebut1());
        $copyObj->setVendrediHeureFin1($this->getVendrediHeureFin1());
        $copyObj->setVendrediCapacite1($this->getVendrediCapacite1());
        $copyObj->setVendrediNbRdvSite1($this->getVendrediNbRdvSite1());
        $copyObj->setVendrediHeureDebut2($this->getVendrediHeureDebut2());
        $copyObj->setVendrediHeureFin2($this->getVendrediHeureFin2());
        $copyObj->setVendrediCapacite2($this->getVendrediCapacite2());
        $copyObj->setVendrediNbRdvSite2($this->getVendrediNbRdvSite2());
        $copyObj->setSamediHeureDebut1($this->getSamediHeureDebut1());
        $copyObj->setSamediHeureFin1($this->getSamediHeureFin1());
        $copyObj->setSamediCapacite1($this->getSamediCapacite1());
        $copyObj->setSamediNbRdvSite1($this->getSamediNbRdvSite1());
        $copyObj->setSamediHeureDebut2($this->getSamediHeureDebut2());
        $copyObj->setSamediHeureFin2($this->getSamediHeureFin2());
        $copyObj->setSamediCapacite2($this->getSamediCapacite2());
        $copyObj->setSamediNbRdvSite2($this->getSamediNbRdvSite2());
        $copyObj->setDimancheHeureDebut1($this->getDimancheHeureDebut1());
        $copyObj->setDimancheHeureFin1($this->getDimancheHeureFin1());
        $copyObj->setDimancheCapacite1($this->getDimancheCapacite1());
        $copyObj->setDimancheNbRdvSite1($this->getDimancheNbRdvSite1());
        $copyObj->setDimancheHeureDebut2($this->getDimancheHeureDebut2());
        $copyObj->setDimancheHeureFin2($this->getDimancheHeureFin2());
        $copyObj->setDimancheCapacite2($this->getDimancheCapacite2());
        $copyObj->setDimancheNbRdvSite2($this->getDimancheNbRdvSite2());
        $copyObj->setIdAgenda($this->getIdAgenda());
        $copyObj->setPeriodicite($this->getPeriodicite());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdPeriode(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TPeriode Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TPeriodePeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TPeriodePeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TAgenda object.
     *
     * @param             TAgenda $v
     * @return TPeriode The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTAgenda(TAgenda $v = null)
    {
        if ($v === null) {
            $this->setIdAgenda(NULL);
        } else {
            $this->setIdAgenda($v->getIdAgenda());
        }

        $this->aTAgenda = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TAgenda object, it will not be re-added.
        if ($v !== null) {
            $v->addTPeriode($this);
        }


        return $this;
    }


    /**
     * Get the associated TAgenda object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TAgenda The associated TAgenda object.
     * @throws PropelException
     */
    public function getTAgenda(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTAgenda === null && ($this->id_agenda !== null) && $doQuery) {
            $this->aTAgenda = TAgendaQuery::create()->findPk($this->id_agenda, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTAgenda->addTPeriodes($this);
             */
        }

        return $this->aTAgenda;
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_periode = null;
        $this->debut_periode = null;
        $this->fin_periode = null;
        $this->lundi_heure_debut_1 = null;
        $this->lundi_heure_fin_1 = null;
        $this->lundi_capacite_1 = null;
        $this->lundi_nb_rdv_site_1 = null;
        $this->lundi_heure_debut_2 = null;
        $this->lundi_heure_fin_2 = null;
        $this->lundi_capacite_2 = null;
        $this->lundi_nb_rdv_site_2 = null;
        $this->mardi_heure_debut_1 = null;
        $this->mardi_heure_fin_1 = null;
        $this->mardi_capacite_1 = null;
        $this->mardi_nb_rdv_site_1 = null;
        $this->mardi_heure_debut_2 = null;
        $this->mardi_heure_fin_2 = null;
        $this->mardi_capacite_2 = null;
        $this->mardi_nb_rdv_site_2 = null;
        $this->mercredi_heure_debut_1 = null;
        $this->mercredi_heure_fin_1 = null;
        $this->mercredi_capacite_1 = null;
        $this->mercredi_nb_rdv_site_1 = null;
        $this->mercredi_heure_debut_2 = null;
        $this->mercredi_heure_fin_2 = null;
        $this->mercredi_capacite_2 = null;
        $this->mercredi_nb_rdv_site_2 = null;
        $this->jeudi_heure_debut_1 = null;
        $this->jeudi_heure_fin_1 = null;
        $this->jeudi_capacite_1 = null;
        $this->jeudi_nb_rdv_site_1 = null;
        $this->jeudi_heure_debut_2 = null;
        $this->jeudi_heure_fin_2 = null;
        $this->jeudi_capacite_2 = null;
        $this->jeudi_nb_rdv_site_2 = null;
        $this->vendredi_heure_debut_1 = null;
        $this->vendredi_heure_fin_1 = null;
        $this->vendredi_capacite_1 = null;
        $this->vendredi_nb_rdv_site_1 = null;
        $this->vendredi_heure_debut_2 = null;
        $this->vendredi_heure_fin_2 = null;
        $this->vendredi_capacite_2 = null;
        $this->vendredi_nb_rdv_site_2 = null;
        $this->samedi_heure_debut_1 = null;
        $this->samedi_heure_fin_1 = null;
        $this->samedi_capacite_1 = null;
        $this->samedi_nb_rdv_site_1 = null;
        $this->samedi_heure_debut_2 = null;
        $this->samedi_heure_fin_2 = null;
        $this->samedi_capacite_2 = null;
        $this->samedi_nb_rdv_site_2 = null;
        $this->dimanche_heure_debut_1 = null;
        $this->dimanche_heure_fin_1 = null;
        $this->dimanche_capacite_1 = null;
        $this->dimanche_nb_rdv_site_1 = null;
        $this->dimanche_heure_debut_2 = null;
        $this->dimanche_heure_fin_2 = null;
        $this->dimanche_capacite_2 = null;
        $this->dimanche_nb_rdv_site_2 = null;
        $this->id_agenda = null;
        $this->periodicite = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->aTAgenda instanceof Persistent) {
              $this->aTAgenda->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        $this->aTAgenda = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TPeriodePeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
