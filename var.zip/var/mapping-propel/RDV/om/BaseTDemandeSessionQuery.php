<?php


/**
 * Base class that represents a query for the 'T_DEMANDE_SESSION' table.
 *
 *
 *
 * @method TDemandeSessionQuery orderByIdSession($order = Criteria::ASC) Order by the ID_SESSION column
 * @method TDemandeSessionQuery orderByIdOrganisation($order = Criteria::ASC) Order by the ID_ORGANISATION column
 * @method TDemandeSessionQuery orderByJeton($order = Criteria::ASC) Order by the JETON column
 * @method TDemandeSessionQuery orderByDateExpiration($order = Criteria::ASC) Order by the DATE_EXPIRATION column
 * @method TDemandeSessionQuery orderByJson($order = Criteria::ASC) Order by the JSON column
 *
 * @method TDemandeSessionQuery groupByIdSession() Group by the ID_SESSION column
 * @method TDemandeSessionQuery groupByIdOrganisation() Group by the ID_ORGANISATION column
 * @method TDemandeSessionQuery groupByJeton() Group by the JETON column
 * @method TDemandeSessionQuery groupByDateExpiration() Group by the DATE_EXPIRATION column
 * @method TDemandeSessionQuery groupByJson() Group by the JSON column
 *
 * @method TDemandeSessionQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TDemandeSessionQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TDemandeSessionQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TDemandeSession findOne(PropelPDO $con = null) Return the first TDemandeSession matching the query
 * @method TDemandeSession findOneOrCreate(PropelPDO $con = null) Return the first TDemandeSession matching the query, or a new TDemandeSession object populated from the query conditions when no match is found
 *
 * @method TDemandeSession findOneByIdOrganisation(int $ID_ORGANISATION) Return the first TDemandeSession filtered by the ID_ORGANISATION column
 * @method TDemandeSession findOneByJeton(string $JETON) Return the first TDemandeSession filtered by the JETON column
 * @method TDemandeSession findOneByDateExpiration(string $DATE_EXPIRATION) Return the first TDemandeSession filtered by the DATE_EXPIRATION column
 * @method TDemandeSession findOneByJson(string $JSON) Return the first TDemandeSession filtered by the JSON column
 *
 * @method array findByIdSession(int $ID_SESSION) Return TDemandeSession objects filtered by the ID_SESSION column
 * @method array findByIdOrganisation(int $ID_ORGANISATION) Return TDemandeSession objects filtered by the ID_ORGANISATION column
 * @method array findByJeton(string $JETON) Return TDemandeSession objects filtered by the JETON column
 * @method array findByDateExpiration(string $DATE_EXPIRATION) Return TDemandeSession objects filtered by the DATE_EXPIRATION column
 * @method array findByJson(string $JSON) Return TDemandeSession objects filtered by the JSON column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTDemandeSessionQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTDemandeSessionQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TDemandeSession', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TDemandeSessionQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TDemandeSessionQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TDemandeSessionQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TDemandeSessionQuery) {
            return $criteria;
        }
        $query = new TDemandeSessionQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TDemandeSession|TDemandeSession[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TDemandeSessionPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TDemandeSessionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TDemandeSession A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdSession($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TDemandeSession A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_SESSION`, `ID_ORGANISATION`, `JETON`, `DATE_EXPIRATION`, `JSON` FROM `T_DEMANDE_SESSION` WHERE `ID_SESSION` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TDemandeSession();
            $obj->hydrate($row);
            TDemandeSessionPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TDemandeSession|TDemandeSession[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TDemandeSession[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TDemandeSessionPeer::ID_SESSION, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TDemandeSessionPeer::ID_SESSION, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_SESSION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdSession(1234); // WHERE ID_SESSION = 1234
     * $query->filterByIdSession(array(12, 34)); // WHERE ID_SESSION IN (12, 34)
     * $query->filterByIdSession(array('min' => 12)); // WHERE ID_SESSION >= 12
     * $query->filterByIdSession(array('max' => 12)); // WHERE ID_SESSION <= 12
     * </code>
     *
     * @param     mixed $idSession The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function filterByIdSession($idSession = null, $comparison = null)
    {
        if (is_array($idSession)) {
            $useMinMax = false;
            if (isset($idSession['min'])) {
                $this->addUsingAlias(TDemandeSessionPeer::ID_SESSION, $idSession['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idSession['max'])) {
                $this->addUsingAlias(TDemandeSessionPeer::ID_SESSION, $idSession['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TDemandeSessionPeer::ID_SESSION, $idSession, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisation(1234); // WHERE ID_ORGANISATION = 1234
     * $query->filterByIdOrganisation(array(12, 34)); // WHERE ID_ORGANISATION IN (12, 34)
     * $query->filterByIdOrganisation(array('min' => 12)); // WHERE ID_ORGANISATION >= 12
     * $query->filterByIdOrganisation(array('max' => 12)); // WHERE ID_ORGANISATION <= 12
     * </code>
     *
     * @param     mixed $idOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function filterByIdOrganisation($idOrganisation = null, $comparison = null)
    {
        if (is_array($idOrganisation)) {
            $useMinMax = false;
            if (isset($idOrganisation['min'])) {
                $this->addUsingAlias(TDemandeSessionPeer::ID_ORGANISATION, $idOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisation['max'])) {
                $this->addUsingAlias(TDemandeSessionPeer::ID_ORGANISATION, $idOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TDemandeSessionPeer::ID_ORGANISATION, $idOrganisation, $comparison);
    }

    /**
     * Filter the query on the JETON column
     *
     * Example usage:
     * <code>
     * $query->filterByJeton('fooValue');   // WHERE JETON = 'fooValue'
     * $query->filterByJeton('%fooValue%'); // WHERE JETON LIKE '%fooValue%'
     * </code>
     *
     * @param     string $jeton The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function filterByJeton($jeton = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($jeton)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $jeton)) {
                $jeton = str_replace('*', '%', $jeton);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TDemandeSessionPeer::JETON, $jeton, $comparison);
    }

    /**
     * Filter the query on the DATE_EXPIRATION column
     *
     * Example usage:
     * <code>
     * $query->filterByDateExpiration('2011-03-14'); // WHERE DATE_EXPIRATION = '2011-03-14'
     * $query->filterByDateExpiration('now'); // WHERE DATE_EXPIRATION = '2011-03-14'
     * $query->filterByDateExpiration(array('max' => 'yesterday')); // WHERE DATE_EXPIRATION > '2011-03-13'
     * </code>
     *
     * @param     mixed $dateExpiration The value to use as filter.
     *              Values can be integers (unix timestamps), DateTime objects, or strings.
     *              Empty strings are treated as NULL.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function filterByDateExpiration($dateExpiration = null, $comparison = null)
    {
        if (is_array($dateExpiration)) {
            $useMinMax = false;
            if (isset($dateExpiration['min'])) {
                $this->addUsingAlias(TDemandeSessionPeer::DATE_EXPIRATION, $dateExpiration['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dateExpiration['max'])) {
                $this->addUsingAlias(TDemandeSessionPeer::DATE_EXPIRATION, $dateExpiration['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TDemandeSessionPeer::DATE_EXPIRATION, $dateExpiration, $comparison);
    }

    /**
     * Filter the query on the JSON column
     *
     * Example usage:
     * <code>
     * $query->filterByJson('fooValue');   // WHERE JSON = 'fooValue'
     * $query->filterByJson('%fooValue%'); // WHERE JSON LIKE '%fooValue%'
     * </code>
     *
     * @param     string $json The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function filterByJson($json = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($json)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $json)) {
                $json = str_replace('*', '%', $json);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TDemandeSessionPeer::JSON, $json, $comparison);
    }

    /**
     * Exclude object from result
     *
     * @param   TDemandeSession $tDemandeSession Object to remove from the list of results
     *
     * @return TDemandeSessionQuery The current query, for fluid interface
     */
    public function prune($tDemandeSession = null)
    {
        if ($tDemandeSession) {
            $this->addUsingAlias(TDemandeSessionPeer::ID_SESSION, $tDemandeSession->getIdSession(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
