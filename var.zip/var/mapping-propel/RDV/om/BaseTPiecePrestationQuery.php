<?php


/**
 * Base class that represents a query for the 'T_PIECE_PRESTATION' table.
 *
 *
 *
 * @method TPiecePrestationQuery orderByIdPiece($order = Criteria::ASC) Order by the ID_PIECE column
 * @method TPiecePrestationQuery orderByIdPrestation($order = Criteria::ASC) Order by the ID_PRESTATION column
 * @method TPiecePrestationQuery orderByCodeLibellePiece($order = Criteria::ASC) Order by the CODE_LIBELLE_PIECE column
 * @method TPiecePrestationQuery orderByIdBlobPiece($order = Criteria::ASC) Order by the ID_BLOB_PIECE column
 * @method TPiecePrestationQuery orderByObligatoire($order = Criteria::ASC) Order by the OBLIGATOIRE column
 *
 * @method TPiecePrestationQuery groupByIdPiece() Group by the ID_PIECE column
 * @method TPiecePrestationQuery groupByIdPrestation() Group by the ID_PRESTATION column
 * @method TPiecePrestationQuery groupByCodeLibellePiece() Group by the CODE_LIBELLE_PIECE column
 * @method TPiecePrestationQuery groupByIdBlobPiece() Group by the ID_BLOB_PIECE column
 * @method TPiecePrestationQuery groupByObligatoire() Group by the OBLIGATOIRE column
 *
 * @method TPiecePrestationQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TPiecePrestationQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TPiecePrestationQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TPiecePrestationQuery leftJoinTTraduction($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraduction relation
 * @method TPiecePrestationQuery rightJoinTTraduction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraduction relation
 * @method TPiecePrestationQuery innerJoinTTraduction($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraduction relation
 *
 * @method TPiecePrestationQuery leftJoinTBlob($relationAlias = null) Adds a LEFT JOIN clause to the query using the TBlob relation
 * @method TPiecePrestationQuery rightJoinTBlob($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TBlob relation
 * @method TPiecePrestationQuery innerJoinTBlob($relationAlias = null) Adds a INNER JOIN clause to the query using the TBlob relation
 *
 * @method TPiecePrestationQuery leftJoinTPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestation relation
 * @method TPiecePrestationQuery rightJoinTPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestation relation
 * @method TPiecePrestationQuery innerJoinTPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestation relation
 *
 * @method TPiecePrestation findOne(PropelPDO $con = null) Return the first TPiecePrestation matching the query
 * @method TPiecePrestation findOneOrCreate(PropelPDO $con = null) Return the first TPiecePrestation matching the query, or a new TPiecePrestation object populated from the query conditions when no match is found
 *
 * @method TPiecePrestation findOneByIdPrestation(int $ID_PRESTATION) Return the first TPiecePrestation filtered by the ID_PRESTATION column
 * @method TPiecePrestation findOneByCodeLibellePiece(int $CODE_LIBELLE_PIECE) Return the first TPiecePrestation filtered by the CODE_LIBELLE_PIECE column
 * @method TPiecePrestation findOneByIdBlobPiece(int $ID_BLOB_PIECE) Return the first TPiecePrestation filtered by the ID_BLOB_PIECE column
 * @method TPiecePrestation findOneByObligatoire(string $OBLIGATOIRE) Return the first TPiecePrestation filtered by the OBLIGATOIRE column
 *
 * @method array findByIdPiece(int $ID_PIECE) Return TPiecePrestation objects filtered by the ID_PIECE column
 * @method array findByIdPrestation(int $ID_PRESTATION) Return TPiecePrestation objects filtered by the ID_PRESTATION column
 * @method array findByCodeLibellePiece(int $CODE_LIBELLE_PIECE) Return TPiecePrestation objects filtered by the CODE_LIBELLE_PIECE column
 * @method array findByIdBlobPiece(int $ID_BLOB_PIECE) Return TPiecePrestation objects filtered by the ID_BLOB_PIECE column
 * @method array findByObligatoire(string $OBLIGATOIRE) Return TPiecePrestation objects filtered by the OBLIGATOIRE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPiecePrestationQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTPiecePrestationQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TPiecePrestation', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TPiecePrestationQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TPiecePrestationQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TPiecePrestationQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TPiecePrestationQuery) {
            return $criteria;
        }
        $query = new TPiecePrestationQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TPiecePrestation|TPiecePrestation[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TPiecePrestationPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TPiecePrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPiecePrestation A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdPiece($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPiecePrestation A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PIECE`, `ID_PRESTATION`, `CODE_LIBELLE_PIECE`, `ID_BLOB_PIECE`, `OBLIGATOIRE` FROM `T_PIECE_PRESTATION` WHERE `ID_PIECE` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TPiecePrestation();
            $obj->hydrate($row);
            TPiecePrestationPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TPiecePrestation|TPiecePrestation[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TPiecePrestation[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TPiecePrestationPeer::ID_PIECE, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TPiecePrestationPeer::ID_PIECE, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PIECE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPiece(1234); // WHERE ID_PIECE = 1234
     * $query->filterByIdPiece(array(12, 34)); // WHERE ID_PIECE IN (12, 34)
     * $query->filterByIdPiece(array('min' => 12)); // WHERE ID_PIECE >= 12
     * $query->filterByIdPiece(array('max' => 12)); // WHERE ID_PIECE <= 12
     * </code>
     *
     * @param     mixed $idPiece The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function filterByIdPiece($idPiece = null, $comparison = null)
    {
        if (is_array($idPiece)) {
            $useMinMax = false;
            if (isset($idPiece['min'])) {
                $this->addUsingAlias(TPiecePrestationPeer::ID_PIECE, $idPiece['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPiece['max'])) {
                $this->addUsingAlias(TPiecePrestationPeer::ID_PIECE, $idPiece['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPiecePrestationPeer::ID_PIECE, $idPiece, $comparison);
    }

    /**
     * Filter the query on the ID_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPrestation(1234); // WHERE ID_PRESTATION = 1234
     * $query->filterByIdPrestation(array(12, 34)); // WHERE ID_PRESTATION IN (12, 34)
     * $query->filterByIdPrestation(array('min' => 12)); // WHERE ID_PRESTATION >= 12
     * $query->filterByIdPrestation(array('max' => 12)); // WHERE ID_PRESTATION <= 12
     * </code>
     *
     * @see       filterByTPrestation()
     *
     * @param     mixed $idPrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function filterByIdPrestation($idPrestation = null, $comparison = null)
    {
        if (is_array($idPrestation)) {
            $useMinMax = false;
            if (isset($idPrestation['min'])) {
                $this->addUsingAlias(TPiecePrestationPeer::ID_PRESTATION, $idPrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPrestation['max'])) {
                $this->addUsingAlias(TPiecePrestationPeer::ID_PRESTATION, $idPrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPiecePrestationPeer::ID_PRESTATION, $idPrestation, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_PIECE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibellePiece(1234); // WHERE CODE_LIBELLE_PIECE = 1234
     * $query->filterByCodeLibellePiece(array(12, 34)); // WHERE CODE_LIBELLE_PIECE IN (12, 34)
     * $query->filterByCodeLibellePiece(array('min' => 12)); // WHERE CODE_LIBELLE_PIECE >= 12
     * $query->filterByCodeLibellePiece(array('max' => 12)); // WHERE CODE_LIBELLE_PIECE <= 12
     * </code>
     *
     * @see       filterByTTraduction()
     *
     * @param     mixed $codeLibellePiece The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function filterByCodeLibellePiece($codeLibellePiece = null, $comparison = null)
    {
        if (is_array($codeLibellePiece)) {
            $useMinMax = false;
            if (isset($codeLibellePiece['min'])) {
                $this->addUsingAlias(TPiecePrestationPeer::CODE_LIBELLE_PIECE, $codeLibellePiece['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibellePiece['max'])) {
                $this->addUsingAlias(TPiecePrestationPeer::CODE_LIBELLE_PIECE, $codeLibellePiece['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPiecePrestationPeer::CODE_LIBELLE_PIECE, $codeLibellePiece, $comparison);
    }

    /**
     * Filter the query on the ID_BLOB_PIECE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdBlobPiece(1234); // WHERE ID_BLOB_PIECE = 1234
     * $query->filterByIdBlobPiece(array(12, 34)); // WHERE ID_BLOB_PIECE IN (12, 34)
     * $query->filterByIdBlobPiece(array('min' => 12)); // WHERE ID_BLOB_PIECE >= 12
     * $query->filterByIdBlobPiece(array('max' => 12)); // WHERE ID_BLOB_PIECE <= 12
     * </code>
     *
     * @see       filterByTBlob()
     *
     * @param     mixed $idBlobPiece The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function filterByIdBlobPiece($idBlobPiece = null, $comparison = null)
    {
        if (is_array($idBlobPiece)) {
            $useMinMax = false;
            if (isset($idBlobPiece['min'])) {
                $this->addUsingAlias(TPiecePrestationPeer::ID_BLOB_PIECE, $idBlobPiece['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idBlobPiece['max'])) {
                $this->addUsingAlias(TPiecePrestationPeer::ID_BLOB_PIECE, $idBlobPiece['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPiecePrestationPeer::ID_BLOB_PIECE, $idBlobPiece, $comparison);
    }

    /**
     * Filter the query on the OBLIGATOIRE column
     *
     * Example usage:
     * <code>
     * $query->filterByObligatoire('fooValue');   // WHERE OBLIGATOIRE = 'fooValue'
     * $query->filterByObligatoire('%fooValue%'); // WHERE OBLIGATOIRE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $obligatoire The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function filterByObligatoire($obligatoire = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($obligatoire)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $obligatoire)) {
                $obligatoire = str_replace('*', '%', $obligatoire);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TPiecePrestationPeer::OBLIGATOIRE, $obligatoire, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPiecePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraduction($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TPiecePrestationPeer::CODE_LIBELLE_PIECE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPiecePrestationPeer::CODE_LIBELLE_PIECE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraduction() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraduction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function joinTTraduction($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraduction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraduction');
        }

        return $this;
    }

    /**
     * Use the TTraduction relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraduction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraduction', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TBlob object
     *
     * @param   TBlob|PropelObjectCollection $tBlob The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPiecePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTBlob($tBlob, $comparison = null)
    {
        if ($tBlob instanceof TBlob) {
            return $this
                ->addUsingAlias(TPiecePrestationPeer::ID_BLOB_PIECE, $tBlob->getIdBlob(), $comparison);
        } elseif ($tBlob instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPiecePrestationPeer::ID_BLOB_PIECE, $tBlob->toKeyValue('PrimaryKey', 'IdBlob'), $comparison);
        } else {
            throw new PropelException('filterByTBlob() only accepts arguments of type TBlob or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TBlob relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function joinTBlob($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TBlob');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TBlob');
        }

        return $this;
    }

    /**
     * Use the TBlob relation TBlob object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TBlobQuery A secondary query class using the current class as primary query
     */
    public function useTBlobQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTBlob($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TBlob', 'TBlobQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPiecePrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TPiecePrestationPeer::ID_PRESTATION, $tPrestation->getIdPrestation(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPiecePrestationPeer::ID_PRESTATION, $tPrestation->toKeyValue('PrimaryKey', 'IdPrestation'), $comparison);
        } else {
            throw new PropelException('filterByTPrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function joinTPrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestation', 'TPrestationQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TPiecePrestation $tPiecePrestation Object to remove from the list of results
     *
     * @return TPiecePrestationQuery The current query, for fluid interface
     */
    public function prune($tPiecePrestation = null)
    {
        if ($tPiecePrestation) {
            $this->addUsingAlias(TPiecePrestationPeer::ID_PIECE, $tPiecePrestation->getIdPiece(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
