<?php


/**
 * Base class that represents a row from the 'T_PARAMETRE_FORM' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTParametreForm extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TParametreFormPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TParametreFormPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_parametre_form field.
     * @var        int
     */
    protected $id_parametre_form;

    /**
     * The value for the rdv_similaire field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $rdv_similaire;

    /**
     * The value for the nb_jour_rdv_similaire field.
     * @var        int
     */
    protected $nb_jour_rdv_similaire;

    /**
     * The value for the delai_min field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $delai_min;

    /**
     * The value for the ressource_visible field.
     * Note: this column has a database default value of: '1'
     * @var        string
     */
    protected $ressource_visible;

    /**
     * The value for the ressource_obligatoire field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $ressource_obligatoire;

    /**
     * The value for the code_commentaire field.
     * @var        int
     */
    protected $code_commentaire;

    /**
     * The value for the referent_visible field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $referent_visible;

    /**
     * The value for the text_1_actif field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $text_1_actif;

    /**
     * The value for the code_libelle_text_1 field.
     * @var        int
     */
    protected $code_libelle_text_1;

    /**
     * The value for the obligatoire_text_1 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_text_1;

    /**
     * The value for the text_2_actif field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $text_2_actif;

    /**
     * The value for the code_libelle_text_2 field.
     * @var        int
     */
    protected $code_libelle_text_2;

    /**
     * The value for the obligatoire_text_2 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_text_2;

    /**
     * The value for the text_3_actif field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $text_3_actif;

    /**
     * The value for the code_libelle_text_3 field.
     * @var        int
     */
    protected $code_libelle_text_3;

    /**
     * The value for the obligatoire_text_3 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_text_3;

    /**
     * The value for the ref_1_actif field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $ref_1_actif;

    /**
     * The value for the id_ref_1 field.
     * @var        int
     */
    protected $id_ref_1;

    /**
     * The value for the code_libelle_ref_1 field.
     * @var        int
     */
    protected $code_libelle_ref_1;

    /**
     * The value for the obligatoire_ref_1 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_ref_1;

    /**
     * The value for the ref_2_actif field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $ref_2_actif;

    /**
     * The value for the id_ref_2 field.
     * @var        int
     */
    protected $id_ref_2;

    /**
     * The value for the code_libelle_ref_2 field.
     * @var        int
     */
    protected $code_libelle_ref_2;

    /**
     * The value for the obligatoire_ref_2 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_ref_2;

    /**
     * The value for the ref_3_actif field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $ref_3_actif;

    /**
     * The value for the id_ref_3 field.
     * @var        int
     */
    protected $id_ref_3;

    /**
     * The value for the code_libelle_ref_3 field.
     * @var        int
     */
    protected $code_libelle_ref_3;

    /**
     * The value for the obligatoire_ref_3 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_ref_3;

    /**
     * The value for the obligatoire_nom field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_nom;

    /**
     * The value for the obligatoire_prenom field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_prenom;

    /**
     * The value for the obligatoire_date_naissance field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_date_naissance;

    /**
     * The value for the obligatoire_email field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_email;

    /**
     * The value for the obligatoire_identifiant field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_identifiant;

    /**
     * The value for the obligatoire_telephone field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_telephone;

    /**
     * The value for the obligatoire_raison_social field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_raison_social;

    /**
     * The value for the obligatoire_adresse field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_adresse;

    /**
     * The value for the obligatoire_fax field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire_fax;

    /**
     * The value for the visible_nom field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_nom;

    /**
     * The value for the visible_prenom field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_prenom;

    /**
     * The value for the visible_date_naissance field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_date_naissance;

    /**
     * The value for the visible_email field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_email;

    /**
     * The value for the visible_identifiant field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_identifiant;

    /**
     * The value for the visible_telephone field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_telephone;

    /**
     * The value for the visible_raison_social field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_raison_social;

    /**
     * The value for the visible_adresse field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_adresse;

    /**
     * The value for the visible_fax field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visible_fax;

    /**
     * The value for the text_1_type field.
     * Note: this column has a database default value of: 'TEXT'
     * @var        string
     */
    protected $text_1_type;

    /**
     * The value for the text_2_type field.
     * Note: this column has a database default value of: 'TEXT'
     * @var        string
     */
    protected $text_2_type;

    /**
     * The value for the text_3_type field.
     * Note: this column has a database default value of: 'TEXT'
     * @var        string
     */
    protected $text_3_type;

    /**
     * The value for the text_1_liste field.
     * @var        string
     */
    protected $text_1_liste;

    /**
     * The value for the text_2_liste field.
     * @var        string
     */
    protected $text_2_liste;

    /**
     * The value for the text_3_liste field.
     * @var        string
     */
    protected $text_3_liste;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeCommentaire;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeLibelleRef1;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeLibelleRef2;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeLibelleRef3;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeLibelleText1;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeLibelleText2;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeLibelleText3;

    /**
     * @var        TReferentiel
     */
    protected $aTReferentielRelatedByIdRef1;

    /**
     * @var        TReferentiel
     */
    protected $aTReferentielRelatedByIdRef2;

    /**
     * @var        TReferentiel
     */
    protected $aTReferentielRelatedByIdRef3;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisations;
    protected $collTOrganisationsPartial;

    /**
     * @var        PropelObjectCollection|TParametragePrestation[] Collection to store aggregation of TParametragePrestation objects.
     */
    protected $collTParametragePrestations;
    protected $collTParametragePrestationsPartial;

    /**
     * @var        PropelObjectCollection|TPieceParamForm[] Collection to store aggregation of TPieceParamForm objects.
     */
    protected $collTPieceParamForms;
    protected $collTPieceParamFormsPartial;

    /**
     * @var        PropelObjectCollection|TPrestation[] Collection to store aggregation of TPrestation objects.
     */
    protected $collTPrestations;
    protected $collTPrestationsPartial;

    /**
     * @var        PropelObjectCollection|TRefPrestation[] Collection to store aggregation of TRefPrestation objects.
     */
    protected $collTRefPrestations;
    protected $collTRefPrestationsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametragePrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPieceParamFormsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRefPrestationsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->rdv_similaire = '0';
        $this->delai_min = 0;
        $this->ressource_visible = '1';
        $this->ressource_obligatoire = '0';
        $this->referent_visible = '0';
        $this->text_1_actif = '0';
        $this->obligatoire_text_1 = '0';
        $this->text_2_actif = '0';
        $this->obligatoire_text_2 = '0';
        $this->text_3_actif = '0';
        $this->obligatoire_text_3 = '0';
        $this->ref_1_actif = '0';
        $this->obligatoire_ref_1 = '0';
        $this->ref_2_actif = '0';
        $this->obligatoire_ref_2 = '0';
        $this->ref_3_actif = '0';
        $this->obligatoire_ref_3 = '0';
        $this->obligatoire_nom = '0';
        $this->obligatoire_prenom = '0';
        $this->obligatoire_date_naissance = '0';
        $this->obligatoire_email = '0';
        $this->obligatoire_identifiant = '0';
        $this->obligatoire_telephone = '0';
        $this->obligatoire_raison_social = '0';
        $this->obligatoire_adresse = '0';
        $this->obligatoire_fax = '0';
        $this->visible_nom = '0';
        $this->visible_prenom = '0';
        $this->visible_date_naissance = '0';
        $this->visible_email = '0';
        $this->visible_identifiant = '0';
        $this->visible_telephone = '0';
        $this->visible_raison_social = '0';
        $this->visible_adresse = '0';
        $this->visible_fax = '0';
        $this->text_1_type = 'TEXT';
        $this->text_2_type = 'TEXT';
        $this->text_3_type = 'TEXT';
    }

    /**
     * Initializes internal state of BaseTParametreForm object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_parametre_form] column value.
     *
     * @return int
     */
    public function getIdParametreForm()
    {
        return $this->id_parametre_form;
    }

    /**
     * Get the [rdv_similaire] column value.
     *
     * @return string
     */
    public function getRdvSimilaire()
    {
        return $this->rdv_similaire;
    }

    /**
     * Get the [nb_jour_rdv_similaire] column value.
     *
     * @return int
     */
    public function getNbJourRdvSimilaire()
    {
        return $this->nb_jour_rdv_similaire;
    }

    /**
     * Get the [delai_min] column value.
     *
     * @return int
     */
    public function getDelaiMin()
    {
        return $this->delai_min;
    }

    /**
     * Get the [ressource_visible] column value.
     *
     * @return string
     */
    public function getRessourceVisible()
    {
        return $this->ressource_visible;
    }

    /**
     * Get the [ressource_obligatoire] column value.
     *
     * @return string
     */
    public function getRessourceObligatoire()
    {
        return $this->ressource_obligatoire;
    }

    /**
     * Get the [code_commentaire] column value.
     *
     * @return int
     */
    public function getCodeCommentaire()
    {
        return $this->code_commentaire;
    }

    /**
     * Get the [referent_visible] column value.
     *
     * @return string
     */
    public function getReferentVisible()
    {
        return $this->referent_visible;
    }

    /**
     * Get the [text_1_actif] column value.
     *
     * @return string
     */
    public function getText1Actif()
    {
        return $this->text_1_actif;
    }

    /**
     * Get the [code_libelle_text_1] column value.
     *
     * @return int
     */
    public function getCodeLibelleText1()
    {
        return $this->code_libelle_text_1;
    }

    /**
     * Get the [obligatoire_text_1] column value.
     *
     * @return string
     */
    public function getObligatoireText1()
    {
        return $this->obligatoire_text_1;
    }

    /**
     * Get the [text_2_actif] column value.
     *
     * @return string
     */
    public function getText2Actif()
    {
        return $this->text_2_actif;
    }

    /**
     * Get the [code_libelle_text_2] column value.
     *
     * @return int
     */
    public function getCodeLibelleText2()
    {
        return $this->code_libelle_text_2;
    }

    /**
     * Get the [obligatoire_text_2] column value.
     *
     * @return string
     */
    public function getObligatoireText2()
    {
        return $this->obligatoire_text_2;
    }

    /**
     * Get the [text_3_actif] column value.
     *
     * @return string
     */
    public function getText3Actif()
    {
        return $this->text_3_actif;
    }

    /**
     * Get the [code_libelle_text_3] column value.
     *
     * @return int
     */
    public function getCodeLibelleText3()
    {
        return $this->code_libelle_text_3;
    }

    /**
     * Get the [obligatoire_text_3] column value.
     *
     * @return string
     */
    public function getObligatoireText3()
    {
        return $this->obligatoire_text_3;
    }

    /**
     * Get the [ref_1_actif] column value.
     *
     * @return string
     */
    public function getRef1Actif()
    {
        return $this->ref_1_actif;
    }

    /**
     * Get the [id_ref_1] column value.
     *
     * @return int
     */
    public function getIdRef1()
    {
        return $this->id_ref_1;
    }

    /**
     * Get the [code_libelle_ref_1] column value.
     *
     * @return int
     */
    public function getCodeLibelleRef1()
    {
        return $this->code_libelle_ref_1;
    }

    /**
     * Get the [obligatoire_ref_1] column value.
     *
     * @return string
     */
    public function getObligatoireRef1()
    {
        return $this->obligatoire_ref_1;
    }

    /**
     * Get the [ref_2_actif] column value.
     *
     * @return string
     */
    public function getRef2Actif()
    {
        return $this->ref_2_actif;
    }

    /**
     * Get the [id_ref_2] column value.
     *
     * @return int
     */
    public function getIdRef2()
    {
        return $this->id_ref_2;
    }

    /**
     * Get the [code_libelle_ref_2] column value.
     *
     * @return int
     */
    public function getCodeLibelleRef2()
    {
        return $this->code_libelle_ref_2;
    }

    /**
     * Get the [obligatoire_ref_2] column value.
     *
     * @return string
     */
    public function getObligatoireRef2()
    {
        return $this->obligatoire_ref_2;
    }

    /**
     * Get the [ref_3_actif] column value.
     *
     * @return string
     */
    public function getRef3Actif()
    {
        return $this->ref_3_actif;
    }

    /**
     * Get the [id_ref_3] column value.
     *
     * @return int
     */
    public function getIdRef3()
    {
        return $this->id_ref_3;
    }

    /**
     * Get the [code_libelle_ref_3] column value.
     *
     * @return int
     */
    public function getCodeLibelleRef3()
    {
        return $this->code_libelle_ref_3;
    }

    /**
     * Get the [obligatoire_ref_3] column value.
     *
     * @return string
     */
    public function getObligatoireRef3()
    {
        return $this->obligatoire_ref_3;
    }

    /**
     * Get the [obligatoire_nom] column value.
     *
     * @return string
     */
    public function getObligatoireNom()
    {
        return $this->obligatoire_nom;
    }

    /**
     * Get the [obligatoire_prenom] column value.
     *
     * @return string
     */
    public function getObligatoirePrenom()
    {
        return $this->obligatoire_prenom;
    }

    /**
     * Get the [obligatoire_date_naissance] column value.
     *
     * @return string
     */
    public function getObligatoireDateNaissance()
    {
        return $this->obligatoire_date_naissance;
    }

    /**
     * Get the [obligatoire_email] column value.
     *
     * @return string
     */
    public function getObligatoireEmail()
    {
        return $this->obligatoire_email;
    }

    /**
     * Get the [obligatoire_identifiant] column value.
     *
     * @return string
     */
    public function getObligatoireIdentifiant()
    {
        return $this->obligatoire_identifiant;
    }

    /**
     * Get the [obligatoire_telephone] column value.
     *
     * @return string
     */
    public function getObligatoireTelephone()
    {
        return $this->obligatoire_telephone;
    }

    /**
     * Get the [obligatoire_raison_social] column value.
     *
     * @return string
     */
    public function getObligatoireRaisonSocial()
    {
        return $this->obligatoire_raison_social;
    }

    /**
     * Get the [obligatoire_adresse] column value.
     *
     * @return string
     */
    public function getObligatoireAdresse()
    {
        return $this->obligatoire_adresse;
    }

    /**
     * Get the [obligatoire_fax] column value.
     *
     * @return string
     */
    public function getObligatoireFax()
    {
        return $this->obligatoire_fax;
    }

    /**
     * Get the [visible_nom] column value.
     *
     * @return string
     */
    public function getVisibleNom()
    {
        return $this->visible_nom;
    }

    /**
     * Get the [visible_prenom] column value.
     *
     * @return string
     */
    public function getVisiblePrenom()
    {
        return $this->visible_prenom;
    }

    /**
     * Get the [visible_date_naissance] column value.
     *
     * @return string
     */
    public function getVisibleDateNaissance()
    {
        return $this->visible_date_naissance;
    }

    /**
     * Get the [visible_email] column value.
     *
     * @return string
     */
    public function getVisibleEmail()
    {
        return $this->visible_email;
    }

    /**
     * Get the [visible_identifiant] column value.
     *
     * @return string
     */
    public function getVisibleIdentifiant()
    {
        return $this->visible_identifiant;
    }

    /**
     * Get the [visible_telephone] column value.
     *
     * @return string
     */
    public function getVisibleTelephone()
    {
        return $this->visible_telephone;
    }

    /**
     * Get the [visible_raison_social] column value.
     *
     * @return string
     */
    public function getVisibleRaisonSocial()
    {
        return $this->visible_raison_social;
    }

    /**
     * Get the [visible_adresse] column value.
     *
     * @return string
     */
    public function getVisibleAdresse()
    {
        return $this->visible_adresse;
    }

    /**
     * Get the [visible_fax] column value.
     *
     * @return string
     */
    public function getVisibleFax()
    {
        return $this->visible_fax;
    }

    /**
     * Get the [text_1_type] column value.
     *
     * @return string
     */
    public function getText1Type()
    {
        return $this->text_1_type;
    }

    /**
     * Get the [text_2_type] column value.
     *
     * @return string
     */
    public function getText2Type()
    {
        return $this->text_2_type;
    }

    /**
     * Get the [text_3_type] column value.
     *
     * @return string
     */
    public function getText3Type()
    {
        return $this->text_3_type;
    }

    /**
     * Get the [text_1_liste] column value.
     *
     * @return string
     */
    public function getText1Liste()
    {
        return $this->text_1_liste;
    }

    /**
     * Get the [text_2_liste] column value.
     *
     * @return string
     */
    public function getText2Liste()
    {
        return $this->text_2_liste;
    }

    /**
     * Get the [text_3_liste] column value.
     *
     * @return string
     */
    public function getText3Liste()
    {
        return $this->text_3_liste;
    }

    /**
     * Set the value of [id_parametre_form] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setIdParametreForm($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_parametre_form !== $v) {
            $this->id_parametre_form = $v;
            $this->modifiedColumns[] = TParametreFormPeer::ID_PARAMETRE_FORM;
        }


        return $this;
    } // setIdParametreForm()

    /**
     * Set the value of [rdv_similaire] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setRdvSimilaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->rdv_similaire !== $v) {
            $this->rdv_similaire = $v;
            $this->modifiedColumns[] = TParametreFormPeer::RDV_SIMILAIRE;
        }


        return $this;
    } // setRdvSimilaire()

    /**
     * Set the value of [nb_jour_rdv_similaire] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setNbJourRdvSimilaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->nb_jour_rdv_similaire !== $v) {
            $this->nb_jour_rdv_similaire = $v;
            $this->modifiedColumns[] = TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE;
        }


        return $this;
    } // setNbJourRdvSimilaire()

    /**
     * Set the value of [delai_min] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setDelaiMin($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->delai_min !== $v) {
            $this->delai_min = $v;
            $this->modifiedColumns[] = TParametreFormPeer::DELAI_MIN;
        }


        return $this;
    } // setDelaiMin()

    /**
     * Set the value of [ressource_visible] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setRessourceVisible($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ressource_visible !== $v) {
            $this->ressource_visible = $v;
            $this->modifiedColumns[] = TParametreFormPeer::RESSOURCE_VISIBLE;
        }


        return $this;
    } // setRessourceVisible()

    /**
     * Set the value of [ressource_obligatoire] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setRessourceObligatoire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ressource_obligatoire !== $v) {
            $this->ressource_obligatoire = $v;
            $this->modifiedColumns[] = TParametreFormPeer::RESSOURCE_OBLIGATOIRE;
        }


        return $this;
    } // setRessourceObligatoire()

    /**
     * Set the value of [code_commentaire] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setCodeCommentaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_commentaire !== $v) {
            $this->code_commentaire = $v;
            $this->modifiedColumns[] = TParametreFormPeer::CODE_COMMENTAIRE;
        }

        if ($this->aTTraductionRelatedByCodeCommentaire !== null && $this->aTTraductionRelatedByCodeCommentaire->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeCommentaire = null;
        }


        return $this;
    } // setCodeCommentaire()

    /**
     * Set the value of [referent_visible] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setReferentVisible($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->referent_visible !== $v) {
            $this->referent_visible = $v;
            $this->modifiedColumns[] = TParametreFormPeer::REFERENT_VISIBLE;
        }


        return $this;
    } // setReferentVisible()

    /**
     * Set the value of [text_1_actif] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText1Actif($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_1_actif !== $v) {
            $this->text_1_actif = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_1_ACTIF;
        }


        return $this;
    } // setText1Actif()

    /**
     * Set the value of [code_libelle_text_1] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setCodeLibelleText1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_text_1 !== $v) {
            $this->code_libelle_text_1 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::CODE_LIBELLE_TEXT_1;
        }

        if ($this->aTTraductionRelatedByCodeLibelleText1 !== null && $this->aTTraductionRelatedByCodeLibelleText1->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeLibelleText1 = null;
        }


        return $this;
    } // setCodeLibelleText1()

    /**
     * Set the value of [obligatoire_text_1] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireText1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_text_1 !== $v) {
            $this->obligatoire_text_1 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_TEXT_1;
        }


        return $this;
    } // setObligatoireText1()

    /**
     * Set the value of [text_2_actif] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText2Actif($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_2_actif !== $v) {
            $this->text_2_actif = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_2_ACTIF;
        }


        return $this;
    } // setText2Actif()

    /**
     * Set the value of [code_libelle_text_2] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setCodeLibelleText2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_text_2 !== $v) {
            $this->code_libelle_text_2 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::CODE_LIBELLE_TEXT_2;
        }

        if ($this->aTTraductionRelatedByCodeLibelleText2 !== null && $this->aTTraductionRelatedByCodeLibelleText2->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeLibelleText2 = null;
        }


        return $this;
    } // setCodeLibelleText2()

    /**
     * Set the value of [obligatoire_text_2] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireText2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_text_2 !== $v) {
            $this->obligatoire_text_2 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_TEXT_2;
        }


        return $this;
    } // setObligatoireText2()

    /**
     * Set the value of [text_3_actif] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText3Actif($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_3_actif !== $v) {
            $this->text_3_actif = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_3_ACTIF;
        }


        return $this;
    } // setText3Actif()

    /**
     * Set the value of [code_libelle_text_3] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setCodeLibelleText3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_text_3 !== $v) {
            $this->code_libelle_text_3 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::CODE_LIBELLE_TEXT_3;
        }

        if ($this->aTTraductionRelatedByCodeLibelleText3 !== null && $this->aTTraductionRelatedByCodeLibelleText3->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeLibelleText3 = null;
        }


        return $this;
    } // setCodeLibelleText3()

    /**
     * Set the value of [obligatoire_text_3] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireText3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_text_3 !== $v) {
            $this->obligatoire_text_3 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_TEXT_3;
        }


        return $this;
    } // setObligatoireText3()

    /**
     * Set the value of [ref_1_actif] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setRef1Actif($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ref_1_actif !== $v) {
            $this->ref_1_actif = $v;
            $this->modifiedColumns[] = TParametreFormPeer::REF_1_ACTIF;
        }


        return $this;
    } // setRef1Actif()

    /**
     * Set the value of [id_ref_1] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setIdRef1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_1 !== $v) {
            $this->id_ref_1 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::ID_REF_1;
        }

        if ($this->aTReferentielRelatedByIdRef1 !== null && $this->aTReferentielRelatedByIdRef1->getIdReferentiel() !== $v) {
            $this->aTReferentielRelatedByIdRef1 = null;
        }


        return $this;
    } // setIdRef1()

    /**
     * Set the value of [code_libelle_ref_1] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setCodeLibelleRef1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_ref_1 !== $v) {
            $this->code_libelle_ref_1 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::CODE_LIBELLE_REF_1;
        }

        if ($this->aTTraductionRelatedByCodeLibelleRef1 !== null && $this->aTTraductionRelatedByCodeLibelleRef1->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeLibelleRef1 = null;
        }


        return $this;
    } // setCodeLibelleRef1()

    /**
     * Set the value of [obligatoire_ref_1] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireRef1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_ref_1 !== $v) {
            $this->obligatoire_ref_1 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_REF_1;
        }


        return $this;
    } // setObligatoireRef1()

    /**
     * Set the value of [ref_2_actif] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setRef2Actif($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ref_2_actif !== $v) {
            $this->ref_2_actif = $v;
            $this->modifiedColumns[] = TParametreFormPeer::REF_2_ACTIF;
        }


        return $this;
    } // setRef2Actif()

    /**
     * Set the value of [id_ref_2] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setIdRef2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_2 !== $v) {
            $this->id_ref_2 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::ID_REF_2;
        }

        if ($this->aTReferentielRelatedByIdRef2 !== null && $this->aTReferentielRelatedByIdRef2->getIdReferentiel() !== $v) {
            $this->aTReferentielRelatedByIdRef2 = null;
        }


        return $this;
    } // setIdRef2()

    /**
     * Set the value of [code_libelle_ref_2] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setCodeLibelleRef2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_ref_2 !== $v) {
            $this->code_libelle_ref_2 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::CODE_LIBELLE_REF_2;
        }

        if ($this->aTTraductionRelatedByCodeLibelleRef2 !== null && $this->aTTraductionRelatedByCodeLibelleRef2->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeLibelleRef2 = null;
        }


        return $this;
    } // setCodeLibelleRef2()

    /**
     * Set the value of [obligatoire_ref_2] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireRef2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_ref_2 !== $v) {
            $this->obligatoire_ref_2 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_REF_2;
        }


        return $this;
    } // setObligatoireRef2()

    /**
     * Set the value of [ref_3_actif] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setRef3Actif($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ref_3_actif !== $v) {
            $this->ref_3_actif = $v;
            $this->modifiedColumns[] = TParametreFormPeer::REF_3_ACTIF;
        }


        return $this;
    } // setRef3Actif()

    /**
     * Set the value of [id_ref_3] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setIdRef3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_3 !== $v) {
            $this->id_ref_3 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::ID_REF_3;
        }

        if ($this->aTReferentielRelatedByIdRef3 !== null && $this->aTReferentielRelatedByIdRef3->getIdReferentiel() !== $v) {
            $this->aTReferentielRelatedByIdRef3 = null;
        }


        return $this;
    } // setIdRef3()

    /**
     * Set the value of [code_libelle_ref_3] column.
     *
     * @param int $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setCodeLibelleRef3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_ref_3 !== $v) {
            $this->code_libelle_ref_3 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::CODE_LIBELLE_REF_3;
        }

        if ($this->aTTraductionRelatedByCodeLibelleRef3 !== null && $this->aTTraductionRelatedByCodeLibelleRef3->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeLibelleRef3 = null;
        }


        return $this;
    } // setCodeLibelleRef3()

    /**
     * Set the value of [obligatoire_ref_3] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireRef3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_ref_3 !== $v) {
            $this->obligatoire_ref_3 = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_REF_3;
        }


        return $this;
    } // setObligatoireRef3()

    /**
     * Set the value of [obligatoire_nom] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireNom($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_nom !== $v) {
            $this->obligatoire_nom = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_NOM;
        }


        return $this;
    } // setObligatoireNom()

    /**
     * Set the value of [obligatoire_prenom] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoirePrenom($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_prenom !== $v) {
            $this->obligatoire_prenom = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_PRENOM;
        }


        return $this;
    } // setObligatoirePrenom()

    /**
     * Set the value of [obligatoire_date_naissance] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireDateNaissance($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_date_naissance !== $v) {
            $this->obligatoire_date_naissance = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE;
        }


        return $this;
    } // setObligatoireDateNaissance()

    /**
     * Set the value of [obligatoire_email] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireEmail($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_email !== $v) {
            $this->obligatoire_email = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_EMAIL;
        }


        return $this;
    } // setObligatoireEmail()

    /**
     * Set the value of [obligatoire_identifiant] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireIdentifiant($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_identifiant !== $v) {
            $this->obligatoire_identifiant = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT;
        }


        return $this;
    } // setObligatoireIdentifiant()

    /**
     * Set the value of [obligatoire_telephone] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireTelephone($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_telephone !== $v) {
            $this->obligatoire_telephone = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_TELEPHONE;
        }


        return $this;
    } // setObligatoireTelephone()

    /**
     * Set the value of [obligatoire_raison_social] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireRaisonSocial($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_raison_social !== $v) {
            $this->obligatoire_raison_social = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL;
        }


        return $this;
    } // setObligatoireRaisonSocial()

    /**
     * Set the value of [obligatoire_adresse] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireAdresse($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_adresse !== $v) {
            $this->obligatoire_adresse = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_ADRESSE;
        }


        return $this;
    } // setObligatoireAdresse()

    /**
     * Set the value of [obligatoire_fax] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setObligatoireFax($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire_fax !== $v) {
            $this->obligatoire_fax = $v;
            $this->modifiedColumns[] = TParametreFormPeer::OBLIGATOIRE_FAX;
        }


        return $this;
    } // setObligatoireFax()

    /**
     * Set the value of [visible_nom] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleNom($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_nom !== $v) {
            $this->visible_nom = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_NOM;
        }


        return $this;
    } // setVisibleNom()

    /**
     * Set the value of [visible_prenom] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisiblePrenom($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_prenom !== $v) {
            $this->visible_prenom = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_PRENOM;
        }


        return $this;
    } // setVisiblePrenom()

    /**
     * Set the value of [visible_date_naissance] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleDateNaissance($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_date_naissance !== $v) {
            $this->visible_date_naissance = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_DATE_NAISSANCE;
        }


        return $this;
    } // setVisibleDateNaissance()

    /**
     * Set the value of [visible_email] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleEmail($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_email !== $v) {
            $this->visible_email = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_EMAIL;
        }


        return $this;
    } // setVisibleEmail()

    /**
     * Set the value of [visible_identifiant] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleIdentifiant($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_identifiant !== $v) {
            $this->visible_identifiant = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_IDENTIFIANT;
        }


        return $this;
    } // setVisibleIdentifiant()

    /**
     * Set the value of [visible_telephone] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleTelephone($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_telephone !== $v) {
            $this->visible_telephone = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_TELEPHONE;
        }


        return $this;
    } // setVisibleTelephone()

    /**
     * Set the value of [visible_raison_social] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleRaisonSocial($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_raison_social !== $v) {
            $this->visible_raison_social = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_RAISON_SOCIAL;
        }


        return $this;
    } // setVisibleRaisonSocial()

    /**
     * Set the value of [visible_adresse] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleAdresse($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_adresse !== $v) {
            $this->visible_adresse = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_ADRESSE;
        }


        return $this;
    } // setVisibleAdresse()

    /**
     * Set the value of [visible_fax] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setVisibleFax($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visible_fax !== $v) {
            $this->visible_fax = $v;
            $this->modifiedColumns[] = TParametreFormPeer::VISIBLE_FAX;
        }


        return $this;
    } // setVisibleFax()

    /**
     * Set the value of [text_1_type] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText1Type($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_1_type !== $v) {
            $this->text_1_type = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_1_TYPE;
        }


        return $this;
    } // setText1Type()

    /**
     * Set the value of [text_2_type] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText2Type($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_2_type !== $v) {
            $this->text_2_type = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_2_TYPE;
        }


        return $this;
    } // setText2Type()

    /**
     * Set the value of [text_3_type] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText3Type($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_3_type !== $v) {
            $this->text_3_type = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_3_TYPE;
        }


        return $this;
    } // setText3Type()

    /**
     * Set the value of [text_1_liste] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText1Liste($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_1_liste !== $v) {
            $this->text_1_liste = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_1_LISTE;
        }


        return $this;
    } // setText1Liste()

    /**
     * Set the value of [text_2_liste] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText2Liste($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_2_liste !== $v) {
            $this->text_2_liste = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_2_LISTE;
        }


        return $this;
    } // setText2Liste()

    /**
     * Set the value of [text_3_liste] column.
     *
     * @param string $v new value
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setText3Liste($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->text_3_liste !== $v) {
            $this->text_3_liste = $v;
            $this->modifiedColumns[] = TParametreFormPeer::TEXT_3_LISTE;
        }


        return $this;
    } // setText3Liste()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->rdv_similaire !== '0') {
                return false;
            }

            if ($this->delai_min !== 0) {
                return false;
            }

            if ($this->ressource_visible !== '1') {
                return false;
            }

            if ($this->ressource_obligatoire !== '0') {
                return false;
            }

            if ($this->referent_visible !== '0') {
                return false;
            }

            if ($this->text_1_actif !== '0') {
                return false;
            }

            if ($this->obligatoire_text_1 !== '0') {
                return false;
            }

            if ($this->text_2_actif !== '0') {
                return false;
            }

            if ($this->obligatoire_text_2 !== '0') {
                return false;
            }

            if ($this->text_3_actif !== '0') {
                return false;
            }

            if ($this->obligatoire_text_3 !== '0') {
                return false;
            }

            if ($this->ref_1_actif !== '0') {
                return false;
            }

            if ($this->obligatoire_ref_1 !== '0') {
                return false;
            }

            if ($this->ref_2_actif !== '0') {
                return false;
            }

            if ($this->obligatoire_ref_2 !== '0') {
                return false;
            }

            if ($this->ref_3_actif !== '0') {
                return false;
            }

            if ($this->obligatoire_ref_3 !== '0') {
                return false;
            }

            if ($this->obligatoire_nom !== '0') {
                return false;
            }

            if ($this->obligatoire_prenom !== '0') {
                return false;
            }

            if ($this->obligatoire_date_naissance !== '0') {
                return false;
            }

            if ($this->obligatoire_email !== '0') {
                return false;
            }

            if ($this->obligatoire_identifiant !== '0') {
                return false;
            }

            if ($this->obligatoire_telephone !== '0') {
                return false;
            }

            if ($this->obligatoire_raison_social !== '0') {
                return false;
            }

            if ($this->obligatoire_adresse !== '0') {
                return false;
            }

            if ($this->obligatoire_fax !== '0') {
                return false;
            }

            if ($this->visible_nom !== '0') {
                return false;
            }

            if ($this->visible_prenom !== '0') {
                return false;
            }

            if ($this->visible_date_naissance !== '0') {
                return false;
            }

            if ($this->visible_email !== '0') {
                return false;
            }

            if ($this->visible_identifiant !== '0') {
                return false;
            }

            if ($this->visible_telephone !== '0') {
                return false;
            }

            if ($this->visible_raison_social !== '0') {
                return false;
            }

            if ($this->visible_adresse !== '0') {
                return false;
            }

            if ($this->visible_fax !== '0') {
                return false;
            }

            if ($this->text_1_type !== 'TEXT') {
                return false;
            }

            if ($this->text_2_type !== 'TEXT') {
                return false;
            }

            if ($this->text_3_type !== 'TEXT') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_parametre_form = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->rdv_similaire = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->nb_jour_rdv_similaire = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->delai_min = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->ressource_visible = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->ressource_obligatoire = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->code_commentaire = ($row[$startcol + 6] !== null) ? (int) $row[$startcol + 6] : null;
            $this->referent_visible = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->text_1_actif = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->code_libelle_text_1 = ($row[$startcol + 9] !== null) ? (int) $row[$startcol + 9] : null;
            $this->obligatoire_text_1 = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->text_2_actif = ($row[$startcol + 11] !== null) ? (string) $row[$startcol + 11] : null;
            $this->code_libelle_text_2 = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->obligatoire_text_2 = ($row[$startcol + 13] !== null) ? (string) $row[$startcol + 13] : null;
            $this->text_3_actif = ($row[$startcol + 14] !== null) ? (string) $row[$startcol + 14] : null;
            $this->code_libelle_text_3 = ($row[$startcol + 15] !== null) ? (int) $row[$startcol + 15] : null;
            $this->obligatoire_text_3 = ($row[$startcol + 16] !== null) ? (string) $row[$startcol + 16] : null;
            $this->ref_1_actif = ($row[$startcol + 17] !== null) ? (string) $row[$startcol + 17] : null;
            $this->id_ref_1 = ($row[$startcol + 18] !== null) ? (int) $row[$startcol + 18] : null;
            $this->code_libelle_ref_1 = ($row[$startcol + 19] !== null) ? (int) $row[$startcol + 19] : null;
            $this->obligatoire_ref_1 = ($row[$startcol + 20] !== null) ? (string) $row[$startcol + 20] : null;
            $this->ref_2_actif = ($row[$startcol + 21] !== null) ? (string) $row[$startcol + 21] : null;
            $this->id_ref_2 = ($row[$startcol + 22] !== null) ? (int) $row[$startcol + 22] : null;
            $this->code_libelle_ref_2 = ($row[$startcol + 23] !== null) ? (int) $row[$startcol + 23] : null;
            $this->obligatoire_ref_2 = ($row[$startcol + 24] !== null) ? (string) $row[$startcol + 24] : null;
            $this->ref_3_actif = ($row[$startcol + 25] !== null) ? (string) $row[$startcol + 25] : null;
            $this->id_ref_3 = ($row[$startcol + 26] !== null) ? (int) $row[$startcol + 26] : null;
            $this->code_libelle_ref_3 = ($row[$startcol + 27] !== null) ? (int) $row[$startcol + 27] : null;
            $this->obligatoire_ref_3 = ($row[$startcol + 28] !== null) ? (string) $row[$startcol + 28] : null;
            $this->obligatoire_nom = ($row[$startcol + 29] !== null) ? (string) $row[$startcol + 29] : null;
            $this->obligatoire_prenom = ($row[$startcol + 30] !== null) ? (string) $row[$startcol + 30] : null;
            $this->obligatoire_date_naissance = ($row[$startcol + 31] !== null) ? (string) $row[$startcol + 31] : null;
            $this->obligatoire_email = ($row[$startcol + 32] !== null) ? (string) $row[$startcol + 32] : null;
            $this->obligatoire_identifiant = ($row[$startcol + 33] !== null) ? (string) $row[$startcol + 33] : null;
            $this->obligatoire_telephone = ($row[$startcol + 34] !== null) ? (string) $row[$startcol + 34] : null;
            $this->obligatoire_raison_social = ($row[$startcol + 35] !== null) ? (string) $row[$startcol + 35] : null;
            $this->obligatoire_adresse = ($row[$startcol + 36] !== null) ? (string) $row[$startcol + 36] : null;
            $this->obligatoire_fax = ($row[$startcol + 37] !== null) ? (string) $row[$startcol + 37] : null;
            $this->visible_nom = ($row[$startcol + 38] !== null) ? (string) $row[$startcol + 38] : null;
            $this->visible_prenom = ($row[$startcol + 39] !== null) ? (string) $row[$startcol + 39] : null;
            $this->visible_date_naissance = ($row[$startcol + 40] !== null) ? (string) $row[$startcol + 40] : null;
            $this->visible_email = ($row[$startcol + 41] !== null) ? (string) $row[$startcol + 41] : null;
            $this->visible_identifiant = ($row[$startcol + 42] !== null) ? (string) $row[$startcol + 42] : null;
            $this->visible_telephone = ($row[$startcol + 43] !== null) ? (string) $row[$startcol + 43] : null;
            $this->visible_raison_social = ($row[$startcol + 44] !== null) ? (string) $row[$startcol + 44] : null;
            $this->visible_adresse = ($row[$startcol + 45] !== null) ? (string) $row[$startcol + 45] : null;
            $this->visible_fax = ($row[$startcol + 46] !== null) ? (string) $row[$startcol + 46] : null;
            $this->text_1_type = ($row[$startcol + 47] !== null) ? (string) $row[$startcol + 47] : null;
            $this->text_2_type = ($row[$startcol + 48] !== null) ? (string) $row[$startcol + 48] : null;
            $this->text_3_type = ($row[$startcol + 49] !== null) ? (string) $row[$startcol + 49] : null;
            $this->text_1_liste = ($row[$startcol + 50] !== null) ? (string) $row[$startcol + 50] : null;
            $this->text_2_liste = ($row[$startcol + 51] !== null) ? (string) $row[$startcol + 51] : null;
            $this->text_3_liste = ($row[$startcol + 52] !== null) ? (string) $row[$startcol + 52] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 53; // 53 = TParametreFormPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TParametreForm object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTTraductionRelatedByCodeCommentaire !== null && $this->code_commentaire !== $this->aTTraductionRelatedByCodeCommentaire->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeCommentaire = null;
        }
        if ($this->aTTraductionRelatedByCodeLibelleText1 !== null && $this->code_libelle_text_1 !== $this->aTTraductionRelatedByCodeLibelleText1->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeLibelleText1 = null;
        }
        if ($this->aTTraductionRelatedByCodeLibelleText2 !== null && $this->code_libelle_text_2 !== $this->aTTraductionRelatedByCodeLibelleText2->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeLibelleText2 = null;
        }
        if ($this->aTTraductionRelatedByCodeLibelleText3 !== null && $this->code_libelle_text_3 !== $this->aTTraductionRelatedByCodeLibelleText3->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeLibelleText3 = null;
        }
        if ($this->aTReferentielRelatedByIdRef1 !== null && $this->id_ref_1 !== $this->aTReferentielRelatedByIdRef1->getIdReferentiel()) {
            $this->aTReferentielRelatedByIdRef1 = null;
        }
        if ($this->aTTraductionRelatedByCodeLibelleRef1 !== null && $this->code_libelle_ref_1 !== $this->aTTraductionRelatedByCodeLibelleRef1->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeLibelleRef1 = null;
        }
        if ($this->aTReferentielRelatedByIdRef2 !== null && $this->id_ref_2 !== $this->aTReferentielRelatedByIdRef2->getIdReferentiel()) {
            $this->aTReferentielRelatedByIdRef2 = null;
        }
        if ($this->aTTraductionRelatedByCodeLibelleRef2 !== null && $this->code_libelle_ref_2 !== $this->aTTraductionRelatedByCodeLibelleRef2->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeLibelleRef2 = null;
        }
        if ($this->aTReferentielRelatedByIdRef3 !== null && $this->id_ref_3 !== $this->aTReferentielRelatedByIdRef3->getIdReferentiel()) {
            $this->aTReferentielRelatedByIdRef3 = null;
        }
        if ($this->aTTraductionRelatedByCodeLibelleRef3 !== null && $this->code_libelle_ref_3 !== $this->aTTraductionRelatedByCodeLibelleRef3->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeLibelleRef3 = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TParametreFormPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraductionRelatedByCodeCommentaire = null;
            $this->aTTraductionRelatedByCodeLibelleRef1 = null;
            $this->aTTraductionRelatedByCodeLibelleRef2 = null;
            $this->aTTraductionRelatedByCodeLibelleRef3 = null;
            $this->aTTraductionRelatedByCodeLibelleText1 = null;
            $this->aTTraductionRelatedByCodeLibelleText2 = null;
            $this->aTTraductionRelatedByCodeLibelleText3 = null;
            $this->aTReferentielRelatedByIdRef1 = null;
            $this->aTReferentielRelatedByIdRef2 = null;
            $this->aTReferentielRelatedByIdRef3 = null;
            $this->collTOrganisations = null;

            $this->collTParametragePrestations = null;

            $this->collTPieceParamForms = null;

            $this->collTPrestations = null;

            $this->collTRefPrestations = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TParametreFormQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TParametreFormPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeCommentaire !== null) {
                if ($this->aTTraductionRelatedByCodeCommentaire->isModified() || $this->aTTraductionRelatedByCodeCommentaire->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeCommentaire->save($con);
                }
                $this->setTTraductionRelatedByCodeCommentaire($this->aTTraductionRelatedByCodeCommentaire);
            }

            if ($this->aTTraductionRelatedByCodeLibelleRef1 !== null) {
                if ($this->aTTraductionRelatedByCodeLibelleRef1->isModified() || $this->aTTraductionRelatedByCodeLibelleRef1->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeLibelleRef1->save($con);
                }
                $this->setTTraductionRelatedByCodeLibelleRef1($this->aTTraductionRelatedByCodeLibelleRef1);
            }

            if ($this->aTTraductionRelatedByCodeLibelleRef2 !== null) {
                if ($this->aTTraductionRelatedByCodeLibelleRef2->isModified() || $this->aTTraductionRelatedByCodeLibelleRef2->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeLibelleRef2->save($con);
                }
                $this->setTTraductionRelatedByCodeLibelleRef2($this->aTTraductionRelatedByCodeLibelleRef2);
            }

            if ($this->aTTraductionRelatedByCodeLibelleRef3 !== null) {
                if ($this->aTTraductionRelatedByCodeLibelleRef3->isModified() || $this->aTTraductionRelatedByCodeLibelleRef3->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeLibelleRef3->save($con);
                }
                $this->setTTraductionRelatedByCodeLibelleRef3($this->aTTraductionRelatedByCodeLibelleRef3);
            }

            if ($this->aTTraductionRelatedByCodeLibelleText1 !== null) {
                if ($this->aTTraductionRelatedByCodeLibelleText1->isModified() || $this->aTTraductionRelatedByCodeLibelleText1->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeLibelleText1->save($con);
                }
                $this->setTTraductionRelatedByCodeLibelleText1($this->aTTraductionRelatedByCodeLibelleText1);
            }

            if ($this->aTTraductionRelatedByCodeLibelleText2 !== null) {
                if ($this->aTTraductionRelatedByCodeLibelleText2->isModified() || $this->aTTraductionRelatedByCodeLibelleText2->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeLibelleText2->save($con);
                }
                $this->setTTraductionRelatedByCodeLibelleText2($this->aTTraductionRelatedByCodeLibelleText2);
            }

            if ($this->aTTraductionRelatedByCodeLibelleText3 !== null) {
                if ($this->aTTraductionRelatedByCodeLibelleText3->isModified() || $this->aTTraductionRelatedByCodeLibelleText3->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeLibelleText3->save($con);
                }
                $this->setTTraductionRelatedByCodeLibelleText3($this->aTTraductionRelatedByCodeLibelleText3);
            }

            if ($this->aTReferentielRelatedByIdRef1 !== null) {
                if ($this->aTReferentielRelatedByIdRef1->isModified() || $this->aTReferentielRelatedByIdRef1->isNew()) {
                    $affectedRows += $this->aTReferentielRelatedByIdRef1->save($con);
                }
                $this->setTReferentielRelatedByIdRef1($this->aTReferentielRelatedByIdRef1);
            }

            if ($this->aTReferentielRelatedByIdRef2 !== null) {
                if ($this->aTReferentielRelatedByIdRef2->isModified() || $this->aTReferentielRelatedByIdRef2->isNew()) {
                    $affectedRows += $this->aTReferentielRelatedByIdRef2->save($con);
                }
                $this->setTReferentielRelatedByIdRef2($this->aTReferentielRelatedByIdRef2);
            }

            if ($this->aTReferentielRelatedByIdRef3 !== null) {
                if ($this->aTReferentielRelatedByIdRef3->isModified() || $this->aTReferentielRelatedByIdRef3->isNew()) {
                    $affectedRows += $this->aTReferentielRelatedByIdRef3->save($con);
                }
                $this->setTReferentielRelatedByIdRef3($this->aTReferentielRelatedByIdRef3);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tOrganisationsScheduledForDeletion !== null) {
                if (!$this->tOrganisationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsScheduledForDeletion as $tOrganisation) {
                        // need to save related object because we set the relation to null
                        $tOrganisation->save($con);
                    }
                    $this->tOrganisationsScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisations !== null) {
                foreach ($this->collTOrganisations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametragePrestationsScheduledForDeletion !== null) {
                if (!$this->tParametragePrestationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametragePrestationsScheduledForDeletion as $tParametragePrestation) {
                        // need to save related object because we set the relation to null
                        $tParametragePrestation->save($con);
                    }
                    $this->tParametragePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTParametragePrestations !== null) {
                foreach ($this->collTParametragePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPieceParamFormsScheduledForDeletion !== null) {
                if (!$this->tPieceParamFormsScheduledForDeletion->isEmpty()) {
                    TPieceParamFormQuery::create()
                        ->filterByPrimaryKeys($this->tPieceParamFormsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tPieceParamFormsScheduledForDeletion = null;
                }
            }

            if ($this->collTPieceParamForms !== null) {
                foreach ($this->collTPieceParamForms as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPrestationsScheduledForDeletion !== null) {
                if (!$this->tPrestationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tPrestationsScheduledForDeletion as $tPrestation) {
                        // need to save related object because we set the relation to null
                        $tPrestation->save($con);
                    }
                    $this->tPrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTPrestations !== null) {
                foreach ($this->collTPrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRefPrestationsScheduledForDeletion !== null) {
                if (!$this->tRefPrestationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tRefPrestationsScheduledForDeletion as $tRefPrestation) {
                        // need to save related object because we set the relation to null
                        $tRefPrestation->save($con);
                    }
                    $this->tRefPrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTRefPrestations !== null) {
                foreach ($this->collTRefPrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TParametreFormPeer::ID_PARAMETRE_FORM;
        if (null !== $this->id_parametre_form) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TParametreFormPeer::ID_PARAMETRE_FORM . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TParametreFormPeer::ID_PARAMETRE_FORM)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PARAMETRE_FORM`';
        }
        if ($this->isColumnModified(TParametreFormPeer::RDV_SIMILAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`RDV_SIMILAIRE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`NB_JOUR_RDV_SIMILAIRE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::DELAI_MIN)) {
            $modifiedColumns[':p' . $index++]  = '`DELAI_MIN`';
        }
        if ($this->isColumnModified(TParametreFormPeer::RESSOURCE_VISIBLE)) {
            $modifiedColumns[':p' . $index++]  = '`RESSOURCE_VISIBLE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::RESSOURCE_OBLIGATOIRE)) {
            $modifiedColumns[':p' . $index++]  = '`RESSOURCE_OBLIGATOIRE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::CODE_COMMENTAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_COMMENTAIRE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::REFERENT_VISIBLE)) {
            $modifiedColumns[':p' . $index++]  = '`REFERENT_VISIBLE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_1_ACTIF)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_1_ACTIF`';
        }
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_TEXT_1)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_TEXT_1`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TEXT_1)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_TEXT_1`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_2_ACTIF)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_2_ACTIF`';
        }
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_TEXT_2)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_TEXT_2`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TEXT_2)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_TEXT_2`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_3_ACTIF)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_3_ACTIF`';
        }
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_TEXT_3)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_TEXT_3`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TEXT_3)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_TEXT_3`';
        }
        if ($this->isColumnModified(TParametreFormPeer::REF_1_ACTIF)) {
            $modifiedColumns[':p' . $index++]  = '`REF_1_ACTIF`';
        }
        if ($this->isColumnModified(TParametreFormPeer::ID_REF_1)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_1`';
        }
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_REF_1)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_REF_1`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_REF_1)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_REF_1`';
        }
        if ($this->isColumnModified(TParametreFormPeer::REF_2_ACTIF)) {
            $modifiedColumns[':p' . $index++]  = '`REF_2_ACTIF`';
        }
        if ($this->isColumnModified(TParametreFormPeer::ID_REF_2)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_2`';
        }
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_REF_2)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_REF_2`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_REF_2)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_REF_2`';
        }
        if ($this->isColumnModified(TParametreFormPeer::REF_3_ACTIF)) {
            $modifiedColumns[':p' . $index++]  = '`REF_3_ACTIF`';
        }
        if ($this->isColumnModified(TParametreFormPeer::ID_REF_3)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_3`';
        }
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_REF_3)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_REF_3`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_REF_3)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_REF_3`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_NOM)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_NOM`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_PRENOM)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_PRENOM`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_DATE_NAISSANCE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_EMAIL)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_EMAIL`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_IDENTIFIANT`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TELEPHONE)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_TELEPHONE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_RAISON_SOCIAL`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_ADRESSE)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_ADRESSE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_FAX)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE_FAX`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_NOM)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_NOM`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_PRENOM)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_PRENOM`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_DATE_NAISSANCE)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_DATE_NAISSANCE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_EMAIL)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_EMAIL`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_IDENTIFIANT)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_IDENTIFIANT`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_TELEPHONE)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_TELEPHONE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_RAISON_SOCIAL)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_RAISON_SOCIAL`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_ADRESSE)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_ADRESSE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_FAX)) {
            $modifiedColumns[':p' . $index++]  = '`VISIBLE_FAX`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_1_TYPE)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_1_TYPE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_2_TYPE)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_2_TYPE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_3_TYPE)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_3_TYPE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_1_LISTE)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_1_LISTE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_2_LISTE)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_2_LISTE`';
        }
        if ($this->isColumnModified(TParametreFormPeer::TEXT_3_LISTE)) {
            $modifiedColumns[':p' . $index++]  = '`TEXT_3_LISTE`';
        }

        $sql = sprintf(
            'INSERT INTO `T_PARAMETRE_FORM` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_PARAMETRE_FORM`':
                        $stmt->bindValue($identifier, $this->id_parametre_form, PDO::PARAM_INT);
                        break;
                    case '`RDV_SIMILAIRE`':
                        $stmt->bindValue($identifier, $this->rdv_similaire, PDO::PARAM_STR);
                        break;
                    case '`NB_JOUR_RDV_SIMILAIRE`':
                        $stmt->bindValue($identifier, $this->nb_jour_rdv_similaire, PDO::PARAM_INT);
                        break;
                    case '`DELAI_MIN`':
                        $stmt->bindValue($identifier, $this->delai_min, PDO::PARAM_INT);
                        break;
                    case '`RESSOURCE_VISIBLE`':
                        $stmt->bindValue($identifier, $this->ressource_visible, PDO::PARAM_STR);
                        break;
                    case '`RESSOURCE_OBLIGATOIRE`':
                        $stmt->bindValue($identifier, $this->ressource_obligatoire, PDO::PARAM_STR);
                        break;
                    case '`CODE_COMMENTAIRE`':
                        $stmt->bindValue($identifier, $this->code_commentaire, PDO::PARAM_INT);
                        break;
                    case '`REFERENT_VISIBLE`':
                        $stmt->bindValue($identifier, $this->referent_visible, PDO::PARAM_STR);
                        break;
                    case '`TEXT_1_ACTIF`':
                        $stmt->bindValue($identifier, $this->text_1_actif, PDO::PARAM_STR);
                        break;
                    case '`CODE_LIBELLE_TEXT_1`':
                        $stmt->bindValue($identifier, $this->code_libelle_text_1, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE_TEXT_1`':
                        $stmt->bindValue($identifier, $this->obligatoire_text_1, PDO::PARAM_STR);
                        break;
                    case '`TEXT_2_ACTIF`':
                        $stmt->bindValue($identifier, $this->text_2_actif, PDO::PARAM_STR);
                        break;
                    case '`CODE_LIBELLE_TEXT_2`':
                        $stmt->bindValue($identifier, $this->code_libelle_text_2, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE_TEXT_2`':
                        $stmt->bindValue($identifier, $this->obligatoire_text_2, PDO::PARAM_STR);
                        break;
                    case '`TEXT_3_ACTIF`':
                        $stmt->bindValue($identifier, $this->text_3_actif, PDO::PARAM_STR);
                        break;
                    case '`CODE_LIBELLE_TEXT_3`':
                        $stmt->bindValue($identifier, $this->code_libelle_text_3, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE_TEXT_3`':
                        $stmt->bindValue($identifier, $this->obligatoire_text_3, PDO::PARAM_STR);
                        break;
                    case '`REF_1_ACTIF`':
                        $stmt->bindValue($identifier, $this->ref_1_actif, PDO::PARAM_STR);
                        break;
                    case '`ID_REF_1`':
                        $stmt->bindValue($identifier, $this->id_ref_1, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_REF_1`':
                        $stmt->bindValue($identifier, $this->code_libelle_ref_1, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE_REF_1`':
                        $stmt->bindValue($identifier, $this->obligatoire_ref_1, PDO::PARAM_STR);
                        break;
                    case '`REF_2_ACTIF`':
                        $stmt->bindValue($identifier, $this->ref_2_actif, PDO::PARAM_STR);
                        break;
                    case '`ID_REF_2`':
                        $stmt->bindValue($identifier, $this->id_ref_2, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_REF_2`':
                        $stmt->bindValue($identifier, $this->code_libelle_ref_2, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE_REF_2`':
                        $stmt->bindValue($identifier, $this->obligatoire_ref_2, PDO::PARAM_STR);
                        break;
                    case '`REF_3_ACTIF`':
                        $stmt->bindValue($identifier, $this->ref_3_actif, PDO::PARAM_STR);
                        break;
                    case '`ID_REF_3`':
                        $stmt->bindValue($identifier, $this->id_ref_3, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_REF_3`':
                        $stmt->bindValue($identifier, $this->code_libelle_ref_3, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE_REF_3`':
                        $stmt->bindValue($identifier, $this->obligatoire_ref_3, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_NOM`':
                        $stmt->bindValue($identifier, $this->obligatoire_nom, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_PRENOM`':
                        $stmt->bindValue($identifier, $this->obligatoire_prenom, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_DATE_NAISSANCE`':
                        $stmt->bindValue($identifier, $this->obligatoire_date_naissance, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_EMAIL`':
                        $stmt->bindValue($identifier, $this->obligatoire_email, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_IDENTIFIANT`':
                        $stmt->bindValue($identifier, $this->obligatoire_identifiant, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_TELEPHONE`':
                        $stmt->bindValue($identifier, $this->obligatoire_telephone, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_RAISON_SOCIAL`':
                        $stmt->bindValue($identifier, $this->obligatoire_raison_social, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_ADRESSE`':
                        $stmt->bindValue($identifier, $this->obligatoire_adresse, PDO::PARAM_STR);
                        break;
                    case '`OBLIGATOIRE_FAX`':
                        $stmt->bindValue($identifier, $this->obligatoire_fax, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_NOM`':
                        $stmt->bindValue($identifier, $this->visible_nom, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_PRENOM`':
                        $stmt->bindValue($identifier, $this->visible_prenom, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_DATE_NAISSANCE`':
                        $stmt->bindValue($identifier, $this->visible_date_naissance, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_EMAIL`':
                        $stmt->bindValue($identifier, $this->visible_email, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_IDENTIFIANT`':
                        $stmt->bindValue($identifier, $this->visible_identifiant, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_TELEPHONE`':
                        $stmt->bindValue($identifier, $this->visible_telephone, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_RAISON_SOCIAL`':
                        $stmt->bindValue($identifier, $this->visible_raison_social, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_ADRESSE`':
                        $stmt->bindValue($identifier, $this->visible_adresse, PDO::PARAM_STR);
                        break;
                    case '`VISIBLE_FAX`':
                        $stmt->bindValue($identifier, $this->visible_fax, PDO::PARAM_STR);
                        break;
                    case '`TEXT_1_TYPE`':
                        $stmt->bindValue($identifier, $this->text_1_type, PDO::PARAM_STR);
                        break;
                    case '`TEXT_2_TYPE`':
                        $stmt->bindValue($identifier, $this->text_2_type, PDO::PARAM_STR);
                        break;
                    case '`TEXT_3_TYPE`':
                        $stmt->bindValue($identifier, $this->text_3_type, PDO::PARAM_STR);
                        break;
                    case '`TEXT_1_LISTE`':
                        $stmt->bindValue($identifier, $this->text_1_liste, PDO::PARAM_STR);
                        break;
                    case '`TEXT_2_LISTE`':
                        $stmt->bindValue($identifier, $this->text_2_liste, PDO::PARAM_STR);
                        break;
                    case '`TEXT_3_LISTE`':
                        $stmt->bindValue($identifier, $this->text_3_liste, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdParametreForm($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeCommentaire !== null) {
                if (!$this->aTTraductionRelatedByCodeCommentaire->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeCommentaire->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeLibelleRef1 !== null) {
                if (!$this->aTTraductionRelatedByCodeLibelleRef1->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeLibelleRef1->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeLibelleRef2 !== null) {
                if (!$this->aTTraductionRelatedByCodeLibelleRef2->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeLibelleRef2->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeLibelleRef3 !== null) {
                if (!$this->aTTraductionRelatedByCodeLibelleRef3->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeLibelleRef3->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeLibelleText1 !== null) {
                if (!$this->aTTraductionRelatedByCodeLibelleText1->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeLibelleText1->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeLibelleText2 !== null) {
                if (!$this->aTTraductionRelatedByCodeLibelleText2->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeLibelleText2->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeLibelleText3 !== null) {
                if (!$this->aTTraductionRelatedByCodeLibelleText3->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeLibelleText3->getValidationFailures());
                }
            }

            if ($this->aTReferentielRelatedByIdRef1 !== null) {
                if (!$this->aTReferentielRelatedByIdRef1->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTReferentielRelatedByIdRef1->getValidationFailures());
                }
            }

            if ($this->aTReferentielRelatedByIdRef2 !== null) {
                if (!$this->aTReferentielRelatedByIdRef2->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTReferentielRelatedByIdRef2->getValidationFailures());
                }
            }

            if ($this->aTReferentielRelatedByIdRef3 !== null) {
                if (!$this->aTReferentielRelatedByIdRef3->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTReferentielRelatedByIdRef3->getValidationFailures());
                }
            }


            if (($retval = TParametreFormPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTOrganisations !== null) {
                    foreach ($this->collTOrganisations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametragePrestations !== null) {
                    foreach ($this->collTParametragePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPieceParamForms !== null) {
                    foreach ($this->collTPieceParamForms as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPrestations !== null) {
                    foreach ($this->collTPrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRefPrestations !== null) {
                    foreach ($this->collTRefPrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TParametreFormPeer::DATABASE_NAME);

        if ($this->isColumnModified(TParametreFormPeer::ID_PARAMETRE_FORM)) $criteria->add(TParametreFormPeer::ID_PARAMETRE_FORM, $this->id_parametre_form);
        if ($this->isColumnModified(TParametreFormPeer::RDV_SIMILAIRE)) $criteria->add(TParametreFormPeer::RDV_SIMILAIRE, $this->rdv_similaire);
        if ($this->isColumnModified(TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE)) $criteria->add(TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE, $this->nb_jour_rdv_similaire);
        if ($this->isColumnModified(TParametreFormPeer::DELAI_MIN)) $criteria->add(TParametreFormPeer::DELAI_MIN, $this->delai_min);
        if ($this->isColumnModified(TParametreFormPeer::RESSOURCE_VISIBLE)) $criteria->add(TParametreFormPeer::RESSOURCE_VISIBLE, $this->ressource_visible);
        if ($this->isColumnModified(TParametreFormPeer::RESSOURCE_OBLIGATOIRE)) $criteria->add(TParametreFormPeer::RESSOURCE_OBLIGATOIRE, $this->ressource_obligatoire);
        if ($this->isColumnModified(TParametreFormPeer::CODE_COMMENTAIRE)) $criteria->add(TParametreFormPeer::CODE_COMMENTAIRE, $this->code_commentaire);
        if ($this->isColumnModified(TParametreFormPeer::REFERENT_VISIBLE)) $criteria->add(TParametreFormPeer::REFERENT_VISIBLE, $this->referent_visible);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_1_ACTIF)) $criteria->add(TParametreFormPeer::TEXT_1_ACTIF, $this->text_1_actif);
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_TEXT_1)) $criteria->add(TParametreFormPeer::CODE_LIBELLE_TEXT_1, $this->code_libelle_text_1);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TEXT_1)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_TEXT_1, $this->obligatoire_text_1);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_2_ACTIF)) $criteria->add(TParametreFormPeer::TEXT_2_ACTIF, $this->text_2_actif);
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_TEXT_2)) $criteria->add(TParametreFormPeer::CODE_LIBELLE_TEXT_2, $this->code_libelle_text_2);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TEXT_2)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_TEXT_2, $this->obligatoire_text_2);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_3_ACTIF)) $criteria->add(TParametreFormPeer::TEXT_3_ACTIF, $this->text_3_actif);
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_TEXT_3)) $criteria->add(TParametreFormPeer::CODE_LIBELLE_TEXT_3, $this->code_libelle_text_3);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TEXT_3)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_TEXT_3, $this->obligatoire_text_3);
        if ($this->isColumnModified(TParametreFormPeer::REF_1_ACTIF)) $criteria->add(TParametreFormPeer::REF_1_ACTIF, $this->ref_1_actif);
        if ($this->isColumnModified(TParametreFormPeer::ID_REF_1)) $criteria->add(TParametreFormPeer::ID_REF_1, $this->id_ref_1);
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_REF_1)) $criteria->add(TParametreFormPeer::CODE_LIBELLE_REF_1, $this->code_libelle_ref_1);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_REF_1)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_REF_1, $this->obligatoire_ref_1);
        if ($this->isColumnModified(TParametreFormPeer::REF_2_ACTIF)) $criteria->add(TParametreFormPeer::REF_2_ACTIF, $this->ref_2_actif);
        if ($this->isColumnModified(TParametreFormPeer::ID_REF_2)) $criteria->add(TParametreFormPeer::ID_REF_2, $this->id_ref_2);
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_REF_2)) $criteria->add(TParametreFormPeer::CODE_LIBELLE_REF_2, $this->code_libelle_ref_2);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_REF_2)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_REF_2, $this->obligatoire_ref_2);
        if ($this->isColumnModified(TParametreFormPeer::REF_3_ACTIF)) $criteria->add(TParametreFormPeer::REF_3_ACTIF, $this->ref_3_actif);
        if ($this->isColumnModified(TParametreFormPeer::ID_REF_3)) $criteria->add(TParametreFormPeer::ID_REF_3, $this->id_ref_3);
        if ($this->isColumnModified(TParametreFormPeer::CODE_LIBELLE_REF_3)) $criteria->add(TParametreFormPeer::CODE_LIBELLE_REF_3, $this->code_libelle_ref_3);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_REF_3)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_REF_3, $this->obligatoire_ref_3);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_NOM)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_NOM, $this->obligatoire_nom);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_PRENOM)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_PRENOM, $this->obligatoire_prenom);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE, $this->obligatoire_date_naissance);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_EMAIL)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_EMAIL, $this->obligatoire_email);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT, $this->obligatoire_identifiant);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_TELEPHONE)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_TELEPHONE, $this->obligatoire_telephone);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL, $this->obligatoire_raison_social);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_ADRESSE)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_ADRESSE, $this->obligatoire_adresse);
        if ($this->isColumnModified(TParametreFormPeer::OBLIGATOIRE_FAX)) $criteria->add(TParametreFormPeer::OBLIGATOIRE_FAX, $this->obligatoire_fax);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_NOM)) $criteria->add(TParametreFormPeer::VISIBLE_NOM, $this->visible_nom);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_PRENOM)) $criteria->add(TParametreFormPeer::VISIBLE_PRENOM, $this->visible_prenom);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_DATE_NAISSANCE)) $criteria->add(TParametreFormPeer::VISIBLE_DATE_NAISSANCE, $this->visible_date_naissance);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_EMAIL)) $criteria->add(TParametreFormPeer::VISIBLE_EMAIL, $this->visible_email);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_IDENTIFIANT)) $criteria->add(TParametreFormPeer::VISIBLE_IDENTIFIANT, $this->visible_identifiant);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_TELEPHONE)) $criteria->add(TParametreFormPeer::VISIBLE_TELEPHONE, $this->visible_telephone);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_RAISON_SOCIAL)) $criteria->add(TParametreFormPeer::VISIBLE_RAISON_SOCIAL, $this->visible_raison_social);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_ADRESSE)) $criteria->add(TParametreFormPeer::VISIBLE_ADRESSE, $this->visible_adresse);
        if ($this->isColumnModified(TParametreFormPeer::VISIBLE_FAX)) $criteria->add(TParametreFormPeer::VISIBLE_FAX, $this->visible_fax);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_1_TYPE)) $criteria->add(TParametreFormPeer::TEXT_1_TYPE, $this->text_1_type);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_2_TYPE)) $criteria->add(TParametreFormPeer::TEXT_2_TYPE, $this->text_2_type);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_3_TYPE)) $criteria->add(TParametreFormPeer::TEXT_3_TYPE, $this->text_3_type);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_1_LISTE)) $criteria->add(TParametreFormPeer::TEXT_1_LISTE, $this->text_1_liste);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_2_LISTE)) $criteria->add(TParametreFormPeer::TEXT_2_LISTE, $this->text_2_liste);
        if ($this->isColumnModified(TParametreFormPeer::TEXT_3_LISTE)) $criteria->add(TParametreFormPeer::TEXT_3_LISTE, $this->text_3_liste);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TParametreFormPeer::DATABASE_NAME);
        $criteria->add(TParametreFormPeer::ID_PARAMETRE_FORM, $this->id_parametre_form);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdParametreForm();
    }

    /**
     * Generic method to set the primary key (id_parametre_form column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdParametreForm($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdParametreForm();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TParametreForm (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setRdvSimilaire($this->getRdvSimilaire());
        $copyObj->setNbJourRdvSimilaire($this->getNbJourRdvSimilaire());
        $copyObj->setDelaiMin($this->getDelaiMin());
        $copyObj->setRessourceVisible($this->getRessourceVisible());
        $copyObj->setRessourceObligatoire($this->getRessourceObligatoire());
        $copyObj->setCodeCommentaire($this->getCodeCommentaire());
        $copyObj->setReferentVisible($this->getReferentVisible());
        $copyObj->setText1Actif($this->getText1Actif());
        $copyObj->setCodeLibelleText1($this->getCodeLibelleText1());
        $copyObj->setObligatoireText1($this->getObligatoireText1());
        $copyObj->setText2Actif($this->getText2Actif());
        $copyObj->setCodeLibelleText2($this->getCodeLibelleText2());
        $copyObj->setObligatoireText2($this->getObligatoireText2());
        $copyObj->setText3Actif($this->getText3Actif());
        $copyObj->setCodeLibelleText3($this->getCodeLibelleText3());
        $copyObj->setObligatoireText3($this->getObligatoireText3());
        $copyObj->setRef1Actif($this->getRef1Actif());
        $copyObj->setIdRef1($this->getIdRef1());
        $copyObj->setCodeLibelleRef1($this->getCodeLibelleRef1());
        $copyObj->setObligatoireRef1($this->getObligatoireRef1());
        $copyObj->setRef2Actif($this->getRef2Actif());
        $copyObj->setIdRef2($this->getIdRef2());
        $copyObj->setCodeLibelleRef2($this->getCodeLibelleRef2());
        $copyObj->setObligatoireRef2($this->getObligatoireRef2());
        $copyObj->setRef3Actif($this->getRef3Actif());
        $copyObj->setIdRef3($this->getIdRef3());
        $copyObj->setCodeLibelleRef3($this->getCodeLibelleRef3());
        $copyObj->setObligatoireRef3($this->getObligatoireRef3());
        $copyObj->setObligatoireNom($this->getObligatoireNom());
        $copyObj->setObligatoirePrenom($this->getObligatoirePrenom());
        $copyObj->setObligatoireDateNaissance($this->getObligatoireDateNaissance());
        $copyObj->setObligatoireEmail($this->getObligatoireEmail());
        $copyObj->setObligatoireIdentifiant($this->getObligatoireIdentifiant());
        $copyObj->setObligatoireTelephone($this->getObligatoireTelephone());
        $copyObj->setObligatoireRaisonSocial($this->getObligatoireRaisonSocial());
        $copyObj->setObligatoireAdresse($this->getObligatoireAdresse());
        $copyObj->setObligatoireFax($this->getObligatoireFax());
        $copyObj->setVisibleNom($this->getVisibleNom());
        $copyObj->setVisiblePrenom($this->getVisiblePrenom());
        $copyObj->setVisibleDateNaissance($this->getVisibleDateNaissance());
        $copyObj->setVisibleEmail($this->getVisibleEmail());
        $copyObj->setVisibleIdentifiant($this->getVisibleIdentifiant());
        $copyObj->setVisibleTelephone($this->getVisibleTelephone());
        $copyObj->setVisibleRaisonSocial($this->getVisibleRaisonSocial());
        $copyObj->setVisibleAdresse($this->getVisibleAdresse());
        $copyObj->setVisibleFax($this->getVisibleFax());
        $copyObj->setText1Type($this->getText1Type());
        $copyObj->setText2Type($this->getText2Type());
        $copyObj->setText3Type($this->getText3Type());
        $copyObj->setText1Liste($this->getText1Liste());
        $copyObj->setText2Liste($this->getText2Liste());
        $copyObj->setText3Liste($this->getText3Liste());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTOrganisations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametragePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametragePrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPieceParamForms() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPieceParamForm($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRefPrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRefPrestation($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdParametreForm(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TParametreForm Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TParametreFormPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TParametreFormPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeCommentaire(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeCommentaire(NULL);
        } else {
            $this->setCodeCommentaire($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeCommentaire = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByCodeCommentaire($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeCommentaire(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeCommentaire === null && ($this->code_commentaire !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeCommentaire = TTraductionQuery::create()->findPk($this->code_commentaire, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeCommentaire->addTParametreFormsRelatedByCodeCommentaire($this);
             */
        }

        return $this->aTTraductionRelatedByCodeCommentaire;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeLibelleRef1(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleRef1(NULL);
        } else {
            $this->setCodeLibelleRef1($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeLibelleRef1 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByCodeLibelleRef1($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeLibelleRef1(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeLibelleRef1 === null && ($this->code_libelle_ref_1 !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeLibelleRef1 = TTraductionQuery::create()->findPk($this->code_libelle_ref_1, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeLibelleRef1->addTParametreFormsRelatedByCodeLibelleRef1($this);
             */
        }

        return $this->aTTraductionRelatedByCodeLibelleRef1;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeLibelleRef2(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleRef2(NULL);
        } else {
            $this->setCodeLibelleRef2($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeLibelleRef2 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByCodeLibelleRef2($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeLibelleRef2(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeLibelleRef2 === null && ($this->code_libelle_ref_2 !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeLibelleRef2 = TTraductionQuery::create()->findPk($this->code_libelle_ref_2, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeLibelleRef2->addTParametreFormsRelatedByCodeLibelleRef2($this);
             */
        }

        return $this->aTTraductionRelatedByCodeLibelleRef2;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeLibelleRef3(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleRef3(NULL);
        } else {
            $this->setCodeLibelleRef3($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeLibelleRef3 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByCodeLibelleRef3($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeLibelleRef3(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeLibelleRef3 === null && ($this->code_libelle_ref_3 !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeLibelleRef3 = TTraductionQuery::create()->findPk($this->code_libelle_ref_3, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeLibelleRef3->addTParametreFormsRelatedByCodeLibelleRef3($this);
             */
        }

        return $this->aTTraductionRelatedByCodeLibelleRef3;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeLibelleText1(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleText1(NULL);
        } else {
            $this->setCodeLibelleText1($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeLibelleText1 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByCodeLibelleText1($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeLibelleText1(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeLibelleText1 === null && ($this->code_libelle_text_1 !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeLibelleText1 = TTraductionQuery::create()->findPk($this->code_libelle_text_1, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeLibelleText1->addTParametreFormsRelatedByCodeLibelleText1($this);
             */
        }

        return $this->aTTraductionRelatedByCodeLibelleText1;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeLibelleText2(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleText2(NULL);
        } else {
            $this->setCodeLibelleText2($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeLibelleText2 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByCodeLibelleText2($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeLibelleText2(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeLibelleText2 === null && ($this->code_libelle_text_2 !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeLibelleText2 = TTraductionQuery::create()->findPk($this->code_libelle_text_2, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeLibelleText2->addTParametreFormsRelatedByCodeLibelleText2($this);
             */
        }

        return $this->aTTraductionRelatedByCodeLibelleText2;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeLibelleText3(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleText3(NULL);
        } else {
            $this->setCodeLibelleText3($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeLibelleText3 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByCodeLibelleText3($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeLibelleText3(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeLibelleText3 === null && ($this->code_libelle_text_3 !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeLibelleText3 = TTraductionQuery::create()->findPk($this->code_libelle_text_3, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeLibelleText3->addTParametreFormsRelatedByCodeLibelleText3($this);
             */
        }

        return $this->aTTraductionRelatedByCodeLibelleText3;
    }

    /**
     * Declares an association between this object and a TReferentiel object.
     *
     * @param             TReferentiel $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTReferentielRelatedByIdRef1(TReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdRef1(NULL);
        } else {
            $this->setIdRef1($v->getIdReferentiel());
        }

        $this->aTReferentielRelatedByIdRef1 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByIdRef1($this);
        }


        return $this;
    }


    /**
     * Get the associated TReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TReferentiel The associated TReferentiel object.
     * @throws PropelException
     */
    public function getTReferentielRelatedByIdRef1(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTReferentielRelatedByIdRef1 === null && ($this->id_ref_1 !== null) && $doQuery) {
            $this->aTReferentielRelatedByIdRef1 = TReferentielQuery::create()->findPk($this->id_ref_1, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTReferentielRelatedByIdRef1->addTParametreFormsRelatedByIdRef1($this);
             */
        }

        return $this->aTReferentielRelatedByIdRef1;
    }

    /**
     * Declares an association between this object and a TReferentiel object.
     *
     * @param             TReferentiel $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTReferentielRelatedByIdRef2(TReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdRef2(NULL);
        } else {
            $this->setIdRef2($v->getIdReferentiel());
        }

        $this->aTReferentielRelatedByIdRef2 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByIdRef2($this);
        }


        return $this;
    }


    /**
     * Get the associated TReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TReferentiel The associated TReferentiel object.
     * @throws PropelException
     */
    public function getTReferentielRelatedByIdRef2(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTReferentielRelatedByIdRef2 === null && ($this->id_ref_2 !== null) && $doQuery) {
            $this->aTReferentielRelatedByIdRef2 = TReferentielQuery::create()->findPk($this->id_ref_2, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTReferentielRelatedByIdRef2->addTParametreFormsRelatedByIdRef2($this);
             */
        }

        return $this->aTReferentielRelatedByIdRef2;
    }

    /**
     * Declares an association between this object and a TReferentiel object.
     *
     * @param             TReferentiel $v
     * @return TParametreForm The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTReferentielRelatedByIdRef3(TReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdRef3(NULL);
        } else {
            $this->setIdRef3($v->getIdReferentiel());
        }

        $this->aTReferentielRelatedByIdRef3 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTParametreFormRelatedByIdRef3($this);
        }


        return $this;
    }


    /**
     * Get the associated TReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TReferentiel The associated TReferentiel object.
     * @throws PropelException
     */
    public function getTReferentielRelatedByIdRef3(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTReferentielRelatedByIdRef3 === null && ($this->id_ref_3 !== null) && $doQuery) {
            $this->aTReferentielRelatedByIdRef3 = TReferentielQuery::create()->findPk($this->id_ref_3, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTReferentielRelatedByIdRef3->addTParametreFormsRelatedByIdRef3($this);
             */
        }

        return $this->aTReferentielRelatedByIdRef3;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TOrganisation' == $relationName) {
            $this->initTOrganisations();
        }
        if ('TParametragePrestation' == $relationName) {
            $this->initTParametragePrestations();
        }
        if ('TPieceParamForm' == $relationName) {
            $this->initTPieceParamForms();
        }
        if ('TPrestation' == $relationName) {
            $this->initTPrestations();
        }
        if ('TRefPrestation' == $relationName) {
            $this->initTRefPrestations();
        }
    }

    /**
     * Clears out the collTOrganisations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TParametreForm The current object (for fluent API support)
     * @see        addTOrganisations()
     */
    public function clearTOrganisations()
    {
        $this->collTOrganisations = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisations($v = true)
    {
        $this->collTOrganisationsPartial = $v;
    }

    /**
     * Initializes the collTOrganisations collection.
     *
     * By default this just sets the collTOrganisations collection to an empty array (like clearcollTOrganisations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisations($overrideExisting = true)
    {
        if (null !== $this->collTOrganisations && !$overrideExisting) {
            return;
        }
        $this->collTOrganisations = new PropelObjectCollection();
        $this->collTOrganisations->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TParametreForm is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsPartial && !$this->isNew();
        if (null === $this->collTOrganisations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisations) {
                // return empty collection
                $this->initTOrganisations();
            } else {
                $collTOrganisations = TOrganisationQuery::create(null, $criteria)
                    ->filterByTParametreForm($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsPartial && count($collTOrganisations)) {
                      $this->initTOrganisations(false);

                      foreach($collTOrganisations as $obj) {
                        if (false == $this->collTOrganisations->contains($obj)) {
                          $this->collTOrganisations->append($obj);
                        }
                      }

                      $this->collTOrganisationsPartial = true;
                    }

                    $collTOrganisations->getInternalIterator()->rewind();
                    return $collTOrganisations;
                }

                if($partial && $this->collTOrganisations) {
                    foreach($this->collTOrganisations as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisations[] = $obj;
                        }
                    }
                }

                $this->collTOrganisations = $collTOrganisations;
                $this->collTOrganisationsPartial = false;
            }
        }

        return $this->collTOrganisations;
    }

    /**
     * Sets a collection of TOrganisation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setTOrganisations(PropelCollection $tOrganisations, PropelPDO $con = null)
    {
        $tOrganisationsToDelete = $this->getTOrganisations(new Criteria(), $con)->diff($tOrganisations);

        $this->tOrganisationsScheduledForDeletion = unserialize(serialize($tOrganisationsToDelete));

        foreach ($tOrganisationsToDelete as $tOrganisationRemoved) {
            $tOrganisationRemoved->setTParametreForm(null);
        }

        $this->collTOrganisations = null;
        foreach ($tOrganisations as $tOrganisation) {
            $this->addTOrganisation($tOrganisation);
        }

        $this->collTOrganisations = $tOrganisations;
        $this->collTOrganisationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsPartial && !$this->isNew();
        if (null === $this->collTOrganisations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisations());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTParametreForm($this)
                ->count($con);
        }

        return count($this->collTOrganisations);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TParametreForm The current object (for fluent API support)
     */
    public function addTOrganisation(TOrganisation $l)
    {
        if ($this->collTOrganisations === null) {
            $this->initTOrganisations();
            $this->collTOrganisationsPartial = true;
        }
        if (!in_array($l, $this->collTOrganisations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisation($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisation $tOrganisation The tOrganisation object to add.
     */
    protected function doAddTOrganisation($tOrganisation)
    {
        $this->collTOrganisations[]= $tOrganisation;
        $tOrganisation->setTParametreForm($this);
    }

    /**
     * @param	TOrganisation $tOrganisation The tOrganisation object to remove.
     * @return TParametreForm The current object (for fluent API support)
     */
    public function removeTOrganisation($tOrganisation)
    {
        if ($this->getTOrganisations()->contains($tOrganisation)) {
            $this->collTOrganisations->remove($this->collTOrganisations->search($tOrganisation));
            if (null === $this->tOrganisationsScheduledForDeletion) {
                $this->tOrganisationsScheduledForDeletion = clone $this->collTOrganisations;
                $this->tOrganisationsScheduledForDeletion->clear();
            }
            $this->tOrganisationsScheduledForDeletion[]= $tOrganisation;
            $tOrganisation->setTParametreForm(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeAdresseOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeAdresseOrganisation', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeDenominationOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeDenominationOrganisation', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeDescriptionOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeDescriptionOrganisation', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeLibelleLien1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleLien1', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeLibelleLien2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleLien2', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeLibelleLien3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleLien3', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeMessageBienvenue($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeMessageBienvenue', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTTraductionRelatedByCodeTitreBienvenue($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeTitreBienvenue', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TOrganisations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisations($query, $con);
    }

    /**
     * Clears out the collTParametragePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TParametreForm The current object (for fluent API support)
     * @see        addTParametragePrestations()
     */
    public function clearTParametragePrestations()
    {
        $this->collTParametragePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTParametragePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTParametragePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametragePrestations($v = true)
    {
        $this->collTParametragePrestationsPartial = $v;
    }

    /**
     * Initializes the collTParametragePrestations collection.
     *
     * By default this just sets the collTParametragePrestations collection to an empty array (like clearcollTParametragePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametragePrestations($overrideExisting = true)
    {
        if (null !== $this->collTParametragePrestations && !$overrideExisting) {
            return;
        }
        $this->collTParametragePrestations = new PropelObjectCollection();
        $this->collTParametragePrestations->setModel('TParametragePrestation');
    }

    /**
     * Gets an array of TParametragePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TParametreForm is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     * @throws PropelException
     */
    public function getTParametragePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsPartial && !$this->isNew();
        if (null === $this->collTParametragePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestations) {
                // return empty collection
                $this->initTParametragePrestations();
            } else {
                $collTParametragePrestations = TParametragePrestationQuery::create(null, $criteria)
                    ->filterByTParametreForm($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametragePrestationsPartial && count($collTParametragePrestations)) {
                      $this->initTParametragePrestations(false);

                      foreach($collTParametragePrestations as $obj) {
                        if (false == $this->collTParametragePrestations->contains($obj)) {
                          $this->collTParametragePrestations->append($obj);
                        }
                      }

                      $this->collTParametragePrestationsPartial = true;
                    }

                    $collTParametragePrestations->getInternalIterator()->rewind();
                    return $collTParametragePrestations;
                }

                if($partial && $this->collTParametragePrestations) {
                    foreach($this->collTParametragePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTParametragePrestations[] = $obj;
                        }
                    }
                }

                $this->collTParametragePrestations = $collTParametragePrestations;
                $this->collTParametragePrestationsPartial = false;
            }
        }

        return $this->collTParametragePrestations;
    }

    /**
     * Sets a collection of TParametragePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametragePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setTParametragePrestations(PropelCollection $tParametragePrestations, PropelPDO $con = null)
    {
        $tParametragePrestationsToDelete = $this->getTParametragePrestations(new Criteria(), $con)->diff($tParametragePrestations);

        $this->tParametragePrestationsScheduledForDeletion = unserialize(serialize($tParametragePrestationsToDelete));

        foreach ($tParametragePrestationsToDelete as $tParametragePrestationRemoved) {
            $tParametragePrestationRemoved->setTParametreForm(null);
        }

        $this->collTParametragePrestations = null;
        foreach ($tParametragePrestations as $tParametragePrestation) {
            $this->addTParametragePrestation($tParametragePrestation);
        }

        $this->collTParametragePrestations = $tParametragePrestations;
        $this->collTParametragePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametragePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametragePrestation objects.
     * @throws PropelException
     */
    public function countTParametragePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsPartial && !$this->isNew();
        if (null === $this->collTParametragePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametragePrestations());
            }
            $query = TParametragePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTParametreForm($this)
                ->count($con);
        }

        return count($this->collTParametragePrestations);
    }

    /**
     * Method called to associate a TParametragePrestation object to this object
     * through the TParametragePrestation foreign key attribute.
     *
     * @param    TParametragePrestation $l TParametragePrestation
     * @return TParametreForm The current object (for fluent API support)
     */
    public function addTParametragePrestation(TParametragePrestation $l)
    {
        if ($this->collTParametragePrestations === null) {
            $this->initTParametragePrestations();
            $this->collTParametragePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTParametragePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametragePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TParametragePrestation $tParametragePrestation The tParametragePrestation object to add.
     */
    protected function doAddTParametragePrestation($tParametragePrestation)
    {
        $this->collTParametragePrestations[]= $tParametragePrestation;
        $tParametragePrestation->setTParametreForm($this);
    }

    /**
     * @param	TParametragePrestation $tParametragePrestation The tParametragePrestation object to remove.
     * @return TParametreForm The current object (for fluent API support)
     */
    public function removeTParametragePrestation($tParametragePrestation)
    {
        if ($this->getTParametragePrestations()->contains($tParametragePrestation)) {
            $this->collTParametragePrestations->remove($this->collTParametragePrestations->search($tParametragePrestation));
            if (null === $this->tParametragePrestationsScheduledForDeletion) {
                $this->tParametragePrestationsScheduledForDeletion = clone $this->collTParametragePrestations;
                $this->tParametragePrestationsScheduledForDeletion->clear();
            }
            $this->tParametragePrestationsScheduledForDeletion[]= $tParametragePrestation;
            $tParametragePrestation->setTParametreForm(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TParametragePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsJoinTRefTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefTypePrestation', $join_behavior);

        return $this->getTParametragePrestations($query, $con);
    }

    /**
     * Clears out the collTPieceParamForms collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TParametreForm The current object (for fluent API support)
     * @see        addTPieceParamForms()
     */
    public function clearTPieceParamForms()
    {
        $this->collTPieceParamForms = null; // important to set this to null since that means it is uninitialized
        $this->collTPieceParamFormsPartial = null;

        return $this;
    }

    /**
     * reset is the collTPieceParamForms collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPieceParamForms($v = true)
    {
        $this->collTPieceParamFormsPartial = $v;
    }

    /**
     * Initializes the collTPieceParamForms collection.
     *
     * By default this just sets the collTPieceParamForms collection to an empty array (like clearcollTPieceParamForms());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPieceParamForms($overrideExisting = true)
    {
        if (null !== $this->collTPieceParamForms && !$overrideExisting) {
            return;
        }
        $this->collTPieceParamForms = new PropelObjectCollection();
        $this->collTPieceParamForms->setModel('TPieceParamForm');
    }

    /**
     * Gets an array of TPieceParamForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TParametreForm is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPieceParamForm[] List of TPieceParamForm objects
     * @throws PropelException
     */
    public function getTPieceParamForms($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPieceParamFormsPartial && !$this->isNew();
        if (null === $this->collTPieceParamForms || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPieceParamForms) {
                // return empty collection
                $this->initTPieceParamForms();
            } else {
                $collTPieceParamForms = TPieceParamFormQuery::create(null, $criteria)
                    ->filterByTParametreForm($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPieceParamFormsPartial && count($collTPieceParamForms)) {
                      $this->initTPieceParamForms(false);

                      foreach($collTPieceParamForms as $obj) {
                        if (false == $this->collTPieceParamForms->contains($obj)) {
                          $this->collTPieceParamForms->append($obj);
                        }
                      }

                      $this->collTPieceParamFormsPartial = true;
                    }

                    $collTPieceParamForms->getInternalIterator()->rewind();
                    return $collTPieceParamForms;
                }

                if($partial && $this->collTPieceParamForms) {
                    foreach($this->collTPieceParamForms as $obj) {
                        if($obj->isNew()) {
                            $collTPieceParamForms[] = $obj;
                        }
                    }
                }

                $this->collTPieceParamForms = $collTPieceParamForms;
                $this->collTPieceParamFormsPartial = false;
            }
        }

        return $this->collTPieceParamForms;
    }

    /**
     * Sets a collection of TPieceParamForm objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPieceParamForms A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setTPieceParamForms(PropelCollection $tPieceParamForms, PropelPDO $con = null)
    {
        $tPieceParamFormsToDelete = $this->getTPieceParamForms(new Criteria(), $con)->diff($tPieceParamForms);

        $this->tPieceParamFormsScheduledForDeletion = unserialize(serialize($tPieceParamFormsToDelete));

        foreach ($tPieceParamFormsToDelete as $tPieceParamFormRemoved) {
            $tPieceParamFormRemoved->setTParametreForm(null);
        }

        $this->collTPieceParamForms = null;
        foreach ($tPieceParamForms as $tPieceParamForm) {
            $this->addTPieceParamForm($tPieceParamForm);
        }

        $this->collTPieceParamForms = $tPieceParamForms;
        $this->collTPieceParamFormsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPieceParamForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPieceParamForm objects.
     * @throws PropelException
     */
    public function countTPieceParamForms(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPieceParamFormsPartial && !$this->isNew();
        if (null === $this->collTPieceParamForms || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPieceParamForms) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPieceParamForms());
            }
            $query = TPieceParamFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTParametreForm($this)
                ->count($con);
        }

        return count($this->collTPieceParamForms);
    }

    /**
     * Method called to associate a TPieceParamForm object to this object
     * through the TPieceParamForm foreign key attribute.
     *
     * @param    TPieceParamForm $l TPieceParamForm
     * @return TParametreForm The current object (for fluent API support)
     */
    public function addTPieceParamForm(TPieceParamForm $l)
    {
        if ($this->collTPieceParamForms === null) {
            $this->initTPieceParamForms();
            $this->collTPieceParamFormsPartial = true;
        }
        if (!in_array($l, $this->collTPieceParamForms->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPieceParamForm($l);
        }

        return $this;
    }

    /**
     * @param	TPieceParamForm $tPieceParamForm The tPieceParamForm object to add.
     */
    protected function doAddTPieceParamForm($tPieceParamForm)
    {
        $this->collTPieceParamForms[]= $tPieceParamForm;
        $tPieceParamForm->setTParametreForm($this);
    }

    /**
     * @param	TPieceParamForm $tPieceParamForm The tPieceParamForm object to remove.
     * @return TParametreForm The current object (for fluent API support)
     */
    public function removeTPieceParamForm($tPieceParamForm)
    {
        if ($this->getTPieceParamForms()->contains($tPieceParamForm)) {
            $this->collTPieceParamForms->remove($this->collTPieceParamForms->search($tPieceParamForm));
            if (null === $this->tPieceParamFormsScheduledForDeletion) {
                $this->tPieceParamFormsScheduledForDeletion = clone $this->collTPieceParamForms;
                $this->tPieceParamFormsScheduledForDeletion->clear();
            }
            $this->tPieceParamFormsScheduledForDeletion[]= clone $tPieceParamForm;
            $tPieceParamForm->setTParametreForm(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TPieceParamForms from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPieceParamForm[] List of TPieceParamForm objects
     */
    public function getTPieceParamFormsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPieceParamFormQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTPieceParamForms($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TPieceParamForms from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPieceParamForm[] List of TPieceParamForm objects
     */
    public function getTPieceParamFormsJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPieceParamFormQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTPieceParamForms($query, $con);
    }

    /**
     * Clears out the collTPrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TParametreForm The current object (for fluent API support)
     * @see        addTPrestations()
     */
    public function clearTPrestations()
    {
        $this->collTPrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTPrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTPrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPrestations($v = true)
    {
        $this->collTPrestationsPartial = $v;
    }

    /**
     * Initializes the collTPrestations collection.
     *
     * By default this just sets the collTPrestations collection to an empty array (like clearcollTPrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPrestations($overrideExisting = true)
    {
        if (null !== $this->collTPrestations && !$overrideExisting) {
            return;
        }
        $this->collTPrestations = new PropelObjectCollection();
        $this->collTPrestations->setModel('TPrestation');
    }

    /**
     * Gets an array of TPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TParametreForm is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     * @throws PropelException
     */
    public function getTPrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsPartial && !$this->isNew();
        if (null === $this->collTPrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPrestations) {
                // return empty collection
                $this->initTPrestations();
            } else {
                $collTPrestations = TPrestationQuery::create(null, $criteria)
                    ->filterByTParametreForm($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPrestationsPartial && count($collTPrestations)) {
                      $this->initTPrestations(false);

                      foreach($collTPrestations as $obj) {
                        if (false == $this->collTPrestations->contains($obj)) {
                          $this->collTPrestations->append($obj);
                        }
                      }

                      $this->collTPrestationsPartial = true;
                    }

                    $collTPrestations->getInternalIterator()->rewind();
                    return $collTPrestations;
                }

                if($partial && $this->collTPrestations) {
                    foreach($this->collTPrestations as $obj) {
                        if($obj->isNew()) {
                            $collTPrestations[] = $obj;
                        }
                    }
                }

                $this->collTPrestations = $collTPrestations;
                $this->collTPrestationsPartial = false;
            }
        }

        return $this->collTPrestations;
    }

    /**
     * Sets a collection of TPrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setTPrestations(PropelCollection $tPrestations, PropelPDO $con = null)
    {
        $tPrestationsToDelete = $this->getTPrestations(new Criteria(), $con)->diff($tPrestations);

        $this->tPrestationsScheduledForDeletion = unserialize(serialize($tPrestationsToDelete));

        foreach ($tPrestationsToDelete as $tPrestationRemoved) {
            $tPrestationRemoved->setTParametreForm(null);
        }

        $this->collTPrestations = null;
        foreach ($tPrestations as $tPrestation) {
            $this->addTPrestation($tPrestation);
        }

        $this->collTPrestations = $tPrestations;
        $this->collTPrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPrestation objects.
     * @throws PropelException
     */
    public function countTPrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsPartial && !$this->isNew();
        if (null === $this->collTPrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPrestations());
            }
            $query = TPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTParametreForm($this)
                ->count($con);
        }

        return count($this->collTPrestations);
    }

    /**
     * Method called to associate a TPrestation object to this object
     * through the TPrestation foreign key attribute.
     *
     * @param    TPrestation $l TPrestation
     * @return TParametreForm The current object (for fluent API support)
     */
    public function addTPrestation(TPrestation $l)
    {
        if ($this->collTPrestations === null) {
            $this->initTPrestations();
            $this->collTPrestationsPartial = true;
        }
        if (!in_array($l, $this->collTPrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPrestation($l);
        }

        return $this;
    }

    /**
     * @param	TPrestation $tPrestation The tPrestation object to add.
     */
    protected function doAddTPrestation($tPrestation)
    {
        $this->collTPrestations[]= $tPrestation;
        $tPrestation->setTParametreForm($this);
    }

    /**
     * @param	TPrestation $tPrestation The tPrestation object to remove.
     * @return TParametreForm The current object (for fluent API support)
     */
    public function removeTPrestation($tPrestation)
    {
        if ($this->getTPrestations()->contains($tPrestation)) {
            $this->collTPrestations->remove($this->collTPrestations->search($tPrestation));
            if (null === $this->tPrestationsScheduledForDeletion) {
                $this->tPrestationsScheduledForDeletion = clone $this->collTPrestations;
                $this->tPrestationsScheduledForDeletion->clear();
            }
            $this->tPrestationsScheduledForDeletion[]= $tPrestation;
            $tPrestation->setTParametreForm(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTTraductionRelatedByCodeLibellePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibellePrestation', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTParametragePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametragePrestation', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsJoinTTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTypePrestation', $join_behavior);

        return $this->getTPrestations($query, $con);
    }

    /**
     * Clears out the collTRefPrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TParametreForm The current object (for fluent API support)
     * @see        addTRefPrestations()
     */
    public function clearTRefPrestations()
    {
        $this->collTRefPrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTRefPrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTRefPrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRefPrestations($v = true)
    {
        $this->collTRefPrestationsPartial = $v;
    }

    /**
     * Initializes the collTRefPrestations collection.
     *
     * By default this just sets the collTRefPrestations collection to an empty array (like clearcollTRefPrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRefPrestations($overrideExisting = true)
    {
        if (null !== $this->collTRefPrestations && !$overrideExisting) {
            return;
        }
        $this->collTRefPrestations = new PropelObjectCollection();
        $this->collTRefPrestations->setModel('TRefPrestation');
    }

    /**
     * Gets an array of TRefPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TParametreForm is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     * @throws PropelException
     */
    public function getTRefPrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRefPrestationsPartial && !$this->isNew();
        if (null === $this->collTRefPrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRefPrestations) {
                // return empty collection
                $this->initTRefPrestations();
            } else {
                $collTRefPrestations = TRefPrestationQuery::create(null, $criteria)
                    ->filterByTParametreForm($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRefPrestationsPartial && count($collTRefPrestations)) {
                      $this->initTRefPrestations(false);

                      foreach($collTRefPrestations as $obj) {
                        if (false == $this->collTRefPrestations->contains($obj)) {
                          $this->collTRefPrestations->append($obj);
                        }
                      }

                      $this->collTRefPrestationsPartial = true;
                    }

                    $collTRefPrestations->getInternalIterator()->rewind();
                    return $collTRefPrestations;
                }

                if($partial && $this->collTRefPrestations) {
                    foreach($this->collTRefPrestations as $obj) {
                        if($obj->isNew()) {
                            $collTRefPrestations[] = $obj;
                        }
                    }
                }

                $this->collTRefPrestations = $collTRefPrestations;
                $this->collTRefPrestationsPartial = false;
            }
        }

        return $this->collTRefPrestations;
    }

    /**
     * Sets a collection of TRefPrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRefPrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TParametreForm The current object (for fluent API support)
     */
    public function setTRefPrestations(PropelCollection $tRefPrestations, PropelPDO $con = null)
    {
        $tRefPrestationsToDelete = $this->getTRefPrestations(new Criteria(), $con)->diff($tRefPrestations);

        $this->tRefPrestationsScheduledForDeletion = unserialize(serialize($tRefPrestationsToDelete));

        foreach ($tRefPrestationsToDelete as $tRefPrestationRemoved) {
            $tRefPrestationRemoved->setTParametreForm(null);
        }

        $this->collTRefPrestations = null;
        foreach ($tRefPrestations as $tRefPrestation) {
            $this->addTRefPrestation($tRefPrestation);
        }

        $this->collTRefPrestations = $tRefPrestations;
        $this->collTRefPrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRefPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRefPrestation objects.
     * @throws PropelException
     */
    public function countTRefPrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRefPrestationsPartial && !$this->isNew();
        if (null === $this->collTRefPrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRefPrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRefPrestations());
            }
            $query = TRefPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTParametreForm($this)
                ->count($con);
        }

        return count($this->collTRefPrestations);
    }

    /**
     * Method called to associate a TRefPrestation object to this object
     * through the TRefPrestation foreign key attribute.
     *
     * @param    TRefPrestation $l TRefPrestation
     * @return TParametreForm The current object (for fluent API support)
     */
    public function addTRefPrestation(TRefPrestation $l)
    {
        if ($this->collTRefPrestations === null) {
            $this->initTRefPrestations();
            $this->collTRefPrestationsPartial = true;
        }
        if (!in_array($l, $this->collTRefPrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRefPrestation($l);
        }

        return $this;
    }

    /**
     * @param	TRefPrestation $tRefPrestation The tRefPrestation object to add.
     */
    protected function doAddTRefPrestation($tRefPrestation)
    {
        $this->collTRefPrestations[]= $tRefPrestation;
        $tRefPrestation->setTParametreForm($this);
    }

    /**
     * @param	TRefPrestation $tRefPrestation The tRefPrestation object to remove.
     * @return TParametreForm The current object (for fluent API support)
     */
    public function removeTRefPrestation($tRefPrestation)
    {
        if ($this->getTRefPrestations()->contains($tRefPrestation)) {
            $this->collTRefPrestations->remove($this->collTRefPrestations->search($tRefPrestation));
            if (null === $this->tRefPrestationsScheduledForDeletion) {
                $this->tRefPrestationsScheduledForDeletion = clone $this->collTRefPrestations;
                $this->tRefPrestationsScheduledForDeletion->clear();
            }
            $this->tRefPrestationsScheduledForDeletion[]= $tRefPrestation;
            $tRefPrestation->setTParametreForm(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TRefPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     */
    public function getTRefPrestationsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTRefPrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TParametreForm is new, it will return
     * an empty collection; or if this TParametreForm has previously
     * been saved, it will retrieve related TRefPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TParametreForm.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     */
    public function getTRefPrestationsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefPrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTRefPrestations($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_parametre_form = null;
        $this->rdv_similaire = null;
        $this->nb_jour_rdv_similaire = null;
        $this->delai_min = null;
        $this->ressource_visible = null;
        $this->ressource_obligatoire = null;
        $this->code_commentaire = null;
        $this->referent_visible = null;
        $this->text_1_actif = null;
        $this->code_libelle_text_1 = null;
        $this->obligatoire_text_1 = null;
        $this->text_2_actif = null;
        $this->code_libelle_text_2 = null;
        $this->obligatoire_text_2 = null;
        $this->text_3_actif = null;
        $this->code_libelle_text_3 = null;
        $this->obligatoire_text_3 = null;
        $this->ref_1_actif = null;
        $this->id_ref_1 = null;
        $this->code_libelle_ref_1 = null;
        $this->obligatoire_ref_1 = null;
        $this->ref_2_actif = null;
        $this->id_ref_2 = null;
        $this->code_libelle_ref_2 = null;
        $this->obligatoire_ref_2 = null;
        $this->ref_3_actif = null;
        $this->id_ref_3 = null;
        $this->code_libelle_ref_3 = null;
        $this->obligatoire_ref_3 = null;
        $this->obligatoire_nom = null;
        $this->obligatoire_prenom = null;
        $this->obligatoire_date_naissance = null;
        $this->obligatoire_email = null;
        $this->obligatoire_identifiant = null;
        $this->obligatoire_telephone = null;
        $this->obligatoire_raison_social = null;
        $this->obligatoire_adresse = null;
        $this->obligatoire_fax = null;
        $this->visible_nom = null;
        $this->visible_prenom = null;
        $this->visible_date_naissance = null;
        $this->visible_email = null;
        $this->visible_identifiant = null;
        $this->visible_telephone = null;
        $this->visible_raison_social = null;
        $this->visible_adresse = null;
        $this->visible_fax = null;
        $this->text_1_type = null;
        $this->text_2_type = null;
        $this->text_3_type = null;
        $this->text_1_liste = null;
        $this->text_2_liste = null;
        $this->text_3_liste = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTOrganisations) {
                foreach ($this->collTOrganisations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametragePrestations) {
                foreach ($this->collTParametragePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPieceParamForms) {
                foreach ($this->collTPieceParamForms as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPrestations) {
                foreach ($this->collTPrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRefPrestations) {
                foreach ($this->collTRefPrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraductionRelatedByCodeCommentaire instanceof Persistent) {
              $this->aTTraductionRelatedByCodeCommentaire->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeLibelleRef1 instanceof Persistent) {
              $this->aTTraductionRelatedByCodeLibelleRef1->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeLibelleRef2 instanceof Persistent) {
              $this->aTTraductionRelatedByCodeLibelleRef2->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeLibelleRef3 instanceof Persistent) {
              $this->aTTraductionRelatedByCodeLibelleRef3->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeLibelleText1 instanceof Persistent) {
              $this->aTTraductionRelatedByCodeLibelleText1->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeLibelleText2 instanceof Persistent) {
              $this->aTTraductionRelatedByCodeLibelleText2->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeLibelleText3 instanceof Persistent) {
              $this->aTTraductionRelatedByCodeLibelleText3->clearAllReferences($deep);
            }
            if ($this->aTReferentielRelatedByIdRef1 instanceof Persistent) {
              $this->aTReferentielRelatedByIdRef1->clearAllReferences($deep);
            }
            if ($this->aTReferentielRelatedByIdRef2 instanceof Persistent) {
              $this->aTReferentielRelatedByIdRef2->clearAllReferences($deep);
            }
            if ($this->aTReferentielRelatedByIdRef3 instanceof Persistent) {
              $this->aTReferentielRelatedByIdRef3->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTOrganisations instanceof PropelCollection) {
            $this->collTOrganisations->clearIterator();
        }
        $this->collTOrganisations = null;
        if ($this->collTParametragePrestations instanceof PropelCollection) {
            $this->collTParametragePrestations->clearIterator();
        }
        $this->collTParametragePrestations = null;
        if ($this->collTPieceParamForms instanceof PropelCollection) {
            $this->collTPieceParamForms->clearIterator();
        }
        $this->collTPieceParamForms = null;
        if ($this->collTPrestations instanceof PropelCollection) {
            $this->collTPrestations->clearIterator();
        }
        $this->collTPrestations = null;
        if ($this->collTRefPrestations instanceof PropelCollection) {
            $this->collTRefPrestations->clearIterator();
        }
        $this->collTRefPrestations = null;
        $this->aTTraductionRelatedByCodeCommentaire = null;
        $this->aTTraductionRelatedByCodeLibelleRef1 = null;
        $this->aTTraductionRelatedByCodeLibelleRef2 = null;
        $this->aTTraductionRelatedByCodeLibelleRef3 = null;
        $this->aTTraductionRelatedByCodeLibelleText1 = null;
        $this->aTTraductionRelatedByCodeLibelleText2 = null;
        $this->aTTraductionRelatedByCodeLibelleText3 = null;
        $this->aTReferentielRelatedByIdRef1 = null;
        $this->aTReferentielRelatedByIdRef2 = null;
        $this->aTReferentielRelatedByIdRef3 = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TParametreFormPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
