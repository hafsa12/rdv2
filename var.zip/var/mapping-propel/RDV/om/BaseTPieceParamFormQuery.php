<?php


/**
 * Base class that represents a query for the 'T_PIECE_PARAM_FORM' table.
 *
 *
 *
 * @method TPieceParamFormQuery orderByIdPieceParamForm($order = Criteria::ASC) Order by the ID_PIECE_PARAM_FORM column
 * @method TPieceParamFormQuery orderByIdParametreForm($order = Criteria::ASC) Order by the ID_PARAMETRE_FORM column
 * @method TPieceParamFormQuery orderByCodeLibellePiece($order = Criteria::ASC) Order by the CODE_LIBELLE_PIECE column
 * @method TPieceParamFormQuery orderByIdBlobPiece($order = Criteria::ASC) Order by the ID_BLOB_PIECE column
 *
 * @method TPieceParamFormQuery groupByIdPieceParamForm() Group by the ID_PIECE_PARAM_FORM column
 * @method TPieceParamFormQuery groupByIdParametreForm() Group by the ID_PARAMETRE_FORM column
 * @method TPieceParamFormQuery groupByCodeLibellePiece() Group by the CODE_LIBELLE_PIECE column
 * @method TPieceParamFormQuery groupByIdBlobPiece() Group by the ID_BLOB_PIECE column
 *
 * @method TPieceParamFormQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TPieceParamFormQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TPieceParamFormQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TPieceParamFormQuery leftJoinTParametreForm($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreForm relation
 * @method TPieceParamFormQuery rightJoinTParametreForm($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreForm relation
 * @method TPieceParamFormQuery innerJoinTParametreForm($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreForm relation
 *
 * @method TPieceParamFormQuery leftJoinTTraduction($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraduction relation
 * @method TPieceParamFormQuery rightJoinTTraduction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraduction relation
 * @method TPieceParamFormQuery innerJoinTTraduction($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraduction relation
 *
 * @method TPieceParamFormQuery leftJoinTBlob($relationAlias = null) Adds a LEFT JOIN clause to the query using the TBlob relation
 * @method TPieceParamFormQuery rightJoinTBlob($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TBlob relation
 * @method TPieceParamFormQuery innerJoinTBlob($relationAlias = null) Adds a INNER JOIN clause to the query using the TBlob relation
 *
 * @method TPieceParamForm findOne(PropelPDO $con = null) Return the first TPieceParamForm matching the query
 * @method TPieceParamForm findOneOrCreate(PropelPDO $con = null) Return the first TPieceParamForm matching the query, or a new TPieceParamForm object populated from the query conditions when no match is found
 *
 * @method TPieceParamForm findOneByIdParametreForm(int $ID_PARAMETRE_FORM) Return the first TPieceParamForm filtered by the ID_PARAMETRE_FORM column
 * @method TPieceParamForm findOneByCodeLibellePiece(int $CODE_LIBELLE_PIECE) Return the first TPieceParamForm filtered by the CODE_LIBELLE_PIECE column
 * @method TPieceParamForm findOneByIdBlobPiece(int $ID_BLOB_PIECE) Return the first TPieceParamForm filtered by the ID_BLOB_PIECE column
 *
 * @method array findByIdPieceParamForm(int $ID_PIECE_PARAM_FORM) Return TPieceParamForm objects filtered by the ID_PIECE_PARAM_FORM column
 * @method array findByIdParametreForm(int $ID_PARAMETRE_FORM) Return TPieceParamForm objects filtered by the ID_PARAMETRE_FORM column
 * @method array findByCodeLibellePiece(int $CODE_LIBELLE_PIECE) Return TPieceParamForm objects filtered by the CODE_LIBELLE_PIECE column
 * @method array findByIdBlobPiece(int $ID_BLOB_PIECE) Return TPieceParamForm objects filtered by the ID_BLOB_PIECE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPieceParamFormQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTPieceParamFormQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TPieceParamForm', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TPieceParamFormQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TPieceParamFormQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TPieceParamFormQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TPieceParamFormQuery) {
            return $criteria;
        }
        $query = new TPieceParamFormQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TPieceParamForm|TPieceParamForm[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TPieceParamFormPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TPieceParamFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPieceParamForm A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdPieceParamForm($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TPieceParamForm A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_PIECE_PARAM_FORM`, `ID_PARAMETRE_FORM`, `CODE_LIBELLE_PIECE`, `ID_BLOB_PIECE` FROM `T_PIECE_PARAM_FORM` WHERE `ID_PIECE_PARAM_FORM` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TPieceParamForm();
            $obj->hydrate($row);
            TPieceParamFormPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TPieceParamForm|TPieceParamForm[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TPieceParamForm[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TPieceParamFormPeer::ID_PIECE_PARAM_FORM, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TPieceParamFormPeer::ID_PIECE_PARAM_FORM, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_PIECE_PARAM_FORM column
     *
     * Example usage:
     * <code>
     * $query->filterByIdPieceParamForm(1234); // WHERE ID_PIECE_PARAM_FORM = 1234
     * $query->filterByIdPieceParamForm(array(12, 34)); // WHERE ID_PIECE_PARAM_FORM IN (12, 34)
     * $query->filterByIdPieceParamForm(array('min' => 12)); // WHERE ID_PIECE_PARAM_FORM >= 12
     * $query->filterByIdPieceParamForm(array('max' => 12)); // WHERE ID_PIECE_PARAM_FORM <= 12
     * </code>
     *
     * @param     mixed $idPieceParamForm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function filterByIdPieceParamForm($idPieceParamForm = null, $comparison = null)
    {
        if (is_array($idPieceParamForm)) {
            $useMinMax = false;
            if (isset($idPieceParamForm['min'])) {
                $this->addUsingAlias(TPieceParamFormPeer::ID_PIECE_PARAM_FORM, $idPieceParamForm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idPieceParamForm['max'])) {
                $this->addUsingAlias(TPieceParamFormPeer::ID_PIECE_PARAM_FORM, $idPieceParamForm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPieceParamFormPeer::ID_PIECE_PARAM_FORM, $idPieceParamForm, $comparison);
    }

    /**
     * Filter the query on the ID_PARAMETRE_FORM column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametreForm(1234); // WHERE ID_PARAMETRE_FORM = 1234
     * $query->filterByIdParametreForm(array(12, 34)); // WHERE ID_PARAMETRE_FORM IN (12, 34)
     * $query->filterByIdParametreForm(array('min' => 12)); // WHERE ID_PARAMETRE_FORM >= 12
     * $query->filterByIdParametreForm(array('max' => 12)); // WHERE ID_PARAMETRE_FORM <= 12
     * </code>
     *
     * @see       filterByTParametreForm()
     *
     * @param     mixed $idParametreForm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function filterByIdParametreForm($idParametreForm = null, $comparison = null)
    {
        if (is_array($idParametreForm)) {
            $useMinMax = false;
            if (isset($idParametreForm['min'])) {
                $this->addUsingAlias(TPieceParamFormPeer::ID_PARAMETRE_FORM, $idParametreForm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametreForm['max'])) {
                $this->addUsingAlias(TPieceParamFormPeer::ID_PARAMETRE_FORM, $idParametreForm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPieceParamFormPeer::ID_PARAMETRE_FORM, $idParametreForm, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE_PIECE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibellePiece(1234); // WHERE CODE_LIBELLE_PIECE = 1234
     * $query->filterByCodeLibellePiece(array(12, 34)); // WHERE CODE_LIBELLE_PIECE IN (12, 34)
     * $query->filterByCodeLibellePiece(array('min' => 12)); // WHERE CODE_LIBELLE_PIECE >= 12
     * $query->filterByCodeLibellePiece(array('max' => 12)); // WHERE CODE_LIBELLE_PIECE <= 12
     * </code>
     *
     * @see       filterByTTraduction()
     *
     * @param     mixed $codeLibellePiece The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function filterByCodeLibellePiece($codeLibellePiece = null, $comparison = null)
    {
        if (is_array($codeLibellePiece)) {
            $useMinMax = false;
            if (isset($codeLibellePiece['min'])) {
                $this->addUsingAlias(TPieceParamFormPeer::CODE_LIBELLE_PIECE, $codeLibellePiece['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibellePiece['max'])) {
                $this->addUsingAlias(TPieceParamFormPeer::CODE_LIBELLE_PIECE, $codeLibellePiece['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPieceParamFormPeer::CODE_LIBELLE_PIECE, $codeLibellePiece, $comparison);
    }

    /**
     * Filter the query on the ID_BLOB_PIECE column
     *
     * Example usage:
     * <code>
     * $query->filterByIdBlobPiece(1234); // WHERE ID_BLOB_PIECE = 1234
     * $query->filterByIdBlobPiece(array(12, 34)); // WHERE ID_BLOB_PIECE IN (12, 34)
     * $query->filterByIdBlobPiece(array('min' => 12)); // WHERE ID_BLOB_PIECE >= 12
     * $query->filterByIdBlobPiece(array('max' => 12)); // WHERE ID_BLOB_PIECE <= 12
     * </code>
     *
     * @see       filterByTBlob()
     *
     * @param     mixed $idBlobPiece The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function filterByIdBlobPiece($idBlobPiece = null, $comparison = null)
    {
        if (is_array($idBlobPiece)) {
            $useMinMax = false;
            if (isset($idBlobPiece['min'])) {
                $this->addUsingAlias(TPieceParamFormPeer::ID_BLOB_PIECE, $idBlobPiece['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idBlobPiece['max'])) {
                $this->addUsingAlias(TPieceParamFormPeer::ID_BLOB_PIECE, $idBlobPiece['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TPieceParamFormPeer::ID_BLOB_PIECE, $idBlobPiece, $comparison);
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPieceParamFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreForm($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TPieceParamFormPeer::ID_PARAMETRE_FORM, $tParametreForm->getIdParametreForm(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPieceParamFormPeer::ID_PARAMETRE_FORM, $tParametreForm->toKeyValue('PrimaryKey', 'IdParametreForm'), $comparison);
        } else {
            throw new PropelException('filterByTParametreForm() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreForm relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function joinTParametreForm($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreForm');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreForm');
        }

        return $this;
    }

    /**
     * Use the TParametreForm relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTParametreForm($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreForm', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPieceParamFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraduction($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TPieceParamFormPeer::CODE_LIBELLE_PIECE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPieceParamFormPeer::CODE_LIBELLE_PIECE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraduction() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraduction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function joinTTraduction($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraduction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraduction');
        }

        return $this;
    }

    /**
     * Use the TTraduction relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraduction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraduction', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TBlob object
     *
     * @param   TBlob|PropelObjectCollection $tBlob The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TPieceParamFormQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTBlob($tBlob, $comparison = null)
    {
        if ($tBlob instanceof TBlob) {
            return $this
                ->addUsingAlias(TPieceParamFormPeer::ID_BLOB_PIECE, $tBlob->getIdBlob(), $comparison);
        } elseif ($tBlob instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TPieceParamFormPeer::ID_BLOB_PIECE, $tBlob->toKeyValue('PrimaryKey', 'IdBlob'), $comparison);
        } else {
            throw new PropelException('filterByTBlob() only accepts arguments of type TBlob or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TBlob relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function joinTBlob($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TBlob');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TBlob');
        }

        return $this;
    }

    /**
     * Use the TBlob relation TBlob object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TBlobQuery A secondary query class using the current class as primary query
     */
    public function useTBlobQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTBlob($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TBlob', 'TBlobQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TPieceParamForm $tPieceParamForm Object to remove from the list of results
     *
     * @return TPieceParamFormQuery The current query, for fluid interface
     */
    public function prune($tPieceParamForm = null)
    {
        if ($tPieceParamForm) {
            $this->addUsingAlias(TPieceParamFormPeer::ID_PIECE_PARAM_FORM, $tPieceParamForm->getIdPieceParamForm(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
