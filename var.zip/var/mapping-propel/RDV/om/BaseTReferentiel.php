<?php


/**
 * Base class that represents a row from the 'T_REFERENTIEL' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTReferentiel extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TReferentielPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TReferentielPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_referentiel field.
     * @var        int
     */
    protected $id_referentiel;

    /**
     * The value for the code_libelle_referentiel field.
     * @var        int
     */
    protected $code_libelle_referentiel;

    /**
     * @var        TTraduction
     */
    protected $aTTraduction;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByIdRef1;
    protected $collTParametreFormsRelatedByIdRef1Partial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByIdRef2;
    protected $collTParametreFormsRelatedByIdRef2Partial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByIdRef3;
    protected $collTParametreFormsRelatedByIdRef3Partial;

    /**
     * @var        PropelObjectCollection|TValeurReferentiel[] Collection to store aggregation of TValeurReferentiel objects.
     */
    protected $collTValeurReferentiels;
    protected $collTValeurReferentielsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByIdRef1ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByIdRef2ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByIdRef3ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tValeurReferentielsScheduledForDeletion = null;

    /**
     * Get the [id_referentiel] column value.
     *
     * @return int
     */
    public function getIdReferentiel()
    {
        return $this->id_referentiel;
    }

    /**
     * Get the [code_libelle_referentiel] column value.
     *
     * @return int
     */
    public function getCodeLibelleReferentiel()
    {
        return $this->code_libelle_referentiel;
    }

    /**
     * Set the value of [id_referentiel] column.
     *
     * @param int $v new value
     * @return TReferentiel The current object (for fluent API support)
     */
    public function setIdReferentiel($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_referentiel !== $v) {
            $this->id_referentiel = $v;
            $this->modifiedColumns[] = TReferentielPeer::ID_REFERENTIEL;
        }


        return $this;
    } // setIdReferentiel()

    /**
     * Set the value of [code_libelle_referentiel] column.
     *
     * @param int $v new value
     * @return TReferentiel The current object (for fluent API support)
     */
    public function setCodeLibelleReferentiel($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_referentiel !== $v) {
            $this->code_libelle_referentiel = $v;
            $this->modifiedColumns[] = TReferentielPeer::CODE_LIBELLE_REFERENTIEL;
        }

        if ($this->aTTraduction !== null && $this->aTTraduction->getIdTraduction() !== $v) {
            $this->aTTraduction = null;
        }


        return $this;
    } // setCodeLibelleReferentiel()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_referentiel = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->code_libelle_referentiel = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 2; // 2 = TReferentielPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TReferentiel object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTTraduction !== null && $this->code_libelle_referentiel !== $this->aTTraduction->getIdTraduction()) {
            $this->aTTraduction = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TReferentielPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TReferentielPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraduction = null;
            $this->collTParametreFormsRelatedByIdRef1 = null;

            $this->collTParametreFormsRelatedByIdRef2 = null;

            $this->collTParametreFormsRelatedByIdRef3 = null;

            $this->collTValeurReferentiels = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TReferentielPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TReferentielQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TReferentielPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TReferentielPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if ($this->aTTraduction->isModified() || $this->aTTraduction->isNew()) {
                    $affectedRows += $this->aTTraduction->save($con);
                }
                $this->setTTraduction($this->aTTraduction);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tParametreFormsRelatedByIdRef1ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByIdRef1ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByIdRef1ScheduledForDeletion as $tParametreFormRelatedByIdRef1) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByIdRef1->save($con);
                    }
                    $this->tParametreFormsRelatedByIdRef1ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByIdRef1 !== null) {
                foreach ($this->collTParametreFormsRelatedByIdRef1 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByIdRef2ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByIdRef2ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByIdRef2ScheduledForDeletion as $tParametreFormRelatedByIdRef2) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByIdRef2->save($con);
                    }
                    $this->tParametreFormsRelatedByIdRef2ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByIdRef2 !== null) {
                foreach ($this->collTParametreFormsRelatedByIdRef2 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByIdRef3ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByIdRef3ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByIdRef3ScheduledForDeletion as $tParametreFormRelatedByIdRef3) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByIdRef3->save($con);
                    }
                    $this->tParametreFormsRelatedByIdRef3ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByIdRef3 !== null) {
                foreach ($this->collTParametreFormsRelatedByIdRef3 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tValeurReferentielsScheduledForDeletion !== null) {
                if (!$this->tValeurReferentielsScheduledForDeletion->isEmpty()) {
                    TValeurReferentielQuery::create()
                        ->filterByPrimaryKeys($this->tValeurReferentielsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tValeurReferentielsScheduledForDeletion = null;
                }
            }

            if ($this->collTValeurReferentiels !== null) {
                foreach ($this->collTValeurReferentiels as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TReferentielPeer::ID_REFERENTIEL;
        if (null !== $this->id_referentiel) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TReferentielPeer::ID_REFERENTIEL . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TReferentielPeer::ID_REFERENTIEL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REFERENTIEL`';
        }
        if ($this->isColumnModified(TReferentielPeer::CODE_LIBELLE_REFERENTIEL)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_REFERENTIEL`';
        }

        $sql = sprintf(
            'INSERT INTO `T_REFERENTIEL` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_REFERENTIEL`':
                        $stmt->bindValue($identifier, $this->id_referentiel, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_REFERENTIEL`':
                        $stmt->bindValue($identifier, $this->code_libelle_referentiel, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdReferentiel($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if (!$this->aTTraduction->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraduction->getValidationFailures());
                }
            }


            if (($retval = TReferentielPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTParametreFormsRelatedByIdRef1 !== null) {
                    foreach ($this->collTParametreFormsRelatedByIdRef1 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByIdRef2 !== null) {
                    foreach ($this->collTParametreFormsRelatedByIdRef2 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByIdRef3 !== null) {
                    foreach ($this->collTParametreFormsRelatedByIdRef3 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTValeurReferentiels !== null) {
                    foreach ($this->collTValeurReferentiels as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TReferentielPeer::DATABASE_NAME);

        if ($this->isColumnModified(TReferentielPeer::ID_REFERENTIEL)) $criteria->add(TReferentielPeer::ID_REFERENTIEL, $this->id_referentiel);
        if ($this->isColumnModified(TReferentielPeer::CODE_LIBELLE_REFERENTIEL)) $criteria->add(TReferentielPeer::CODE_LIBELLE_REFERENTIEL, $this->code_libelle_referentiel);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TReferentielPeer::DATABASE_NAME);
        $criteria->add(TReferentielPeer::ID_REFERENTIEL, $this->id_referentiel);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdReferentiel();
    }

    /**
     * Generic method to set the primary key (id_referentiel column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdReferentiel($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdReferentiel();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TReferentiel (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setCodeLibelleReferentiel($this->getCodeLibelleReferentiel());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTParametreFormsRelatedByIdRef1() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByIdRef1($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByIdRef2() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByIdRef2($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByIdRef3() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByIdRef3($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTValeurReferentiels() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTValeurReferentiel($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdReferentiel(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TReferentiel Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TReferentielPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TReferentielPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TReferentiel The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraduction(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleReferentiel(NULL);
        } else {
            $this->setCodeLibelleReferentiel($v->getIdTraduction());
        }

        $this->aTTraduction = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTReferentiel($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraduction(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraduction === null && ($this->code_libelle_referentiel !== null) && $doQuery) {
            $this->aTTraduction = TTraductionQuery::create()->findPk($this->code_libelle_referentiel, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraduction->addTReferentiels($this);
             */
        }

        return $this->aTTraduction;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TParametreFormRelatedByIdRef1' == $relationName) {
            $this->initTParametreFormsRelatedByIdRef1();
        }
        if ('TParametreFormRelatedByIdRef2' == $relationName) {
            $this->initTParametreFormsRelatedByIdRef2();
        }
        if ('TParametreFormRelatedByIdRef3' == $relationName) {
            $this->initTParametreFormsRelatedByIdRef3();
        }
        if ('TValeurReferentiel' == $relationName) {
            $this->initTValeurReferentiels();
        }
    }

    /**
     * Clears out the collTParametreFormsRelatedByIdRef1 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TReferentiel The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByIdRef1()
     */
    public function clearTParametreFormsRelatedByIdRef1()
    {
        $this->collTParametreFormsRelatedByIdRef1 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByIdRef1Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByIdRef1 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByIdRef1($v = true)
    {
        $this->collTParametreFormsRelatedByIdRef1Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByIdRef1 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByIdRef1 collection to an empty array (like clearcollTParametreFormsRelatedByIdRef1());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByIdRef1($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByIdRef1 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByIdRef1 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByIdRef1->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByIdRef1($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByIdRef1Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByIdRef1 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByIdRef1) {
                // return empty collection
                $this->initTParametreFormsRelatedByIdRef1();
            } else {
                $collTParametreFormsRelatedByIdRef1 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTReferentielRelatedByIdRef1($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByIdRef1Partial && count($collTParametreFormsRelatedByIdRef1)) {
                      $this->initTParametreFormsRelatedByIdRef1(false);

                      foreach($collTParametreFormsRelatedByIdRef1 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByIdRef1->contains($obj)) {
                          $this->collTParametreFormsRelatedByIdRef1->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByIdRef1Partial = true;
                    }

                    $collTParametreFormsRelatedByIdRef1->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByIdRef1;
                }

                if($partial && $this->collTParametreFormsRelatedByIdRef1) {
                    foreach($this->collTParametreFormsRelatedByIdRef1 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByIdRef1[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByIdRef1 = $collTParametreFormsRelatedByIdRef1;
                $this->collTParametreFormsRelatedByIdRef1Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByIdRef1;
    }

    /**
     * Sets a collection of TParametreFormRelatedByIdRef1 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByIdRef1 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TReferentiel The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByIdRef1(PropelCollection $tParametreFormsRelatedByIdRef1, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByIdRef1ToDelete = $this->getTParametreFormsRelatedByIdRef1(new Criteria(), $con)->diff($tParametreFormsRelatedByIdRef1);

        $this->tParametreFormsRelatedByIdRef1ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByIdRef1ToDelete));

        foreach ($tParametreFormsRelatedByIdRef1ToDelete as $tParametreFormRelatedByIdRef1Removed) {
            $tParametreFormRelatedByIdRef1Removed->setTReferentielRelatedByIdRef1(null);
        }

        $this->collTParametreFormsRelatedByIdRef1 = null;
        foreach ($tParametreFormsRelatedByIdRef1 as $tParametreFormRelatedByIdRef1) {
            $this->addTParametreFormRelatedByIdRef1($tParametreFormRelatedByIdRef1);
        }

        $this->collTParametreFormsRelatedByIdRef1 = $tParametreFormsRelatedByIdRef1;
        $this->collTParametreFormsRelatedByIdRef1Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByIdRef1(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByIdRef1Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByIdRef1 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByIdRef1) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByIdRef1());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTReferentielRelatedByIdRef1($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByIdRef1);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TReferentiel The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByIdRef1(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByIdRef1 === null) {
            $this->initTParametreFormsRelatedByIdRef1();
            $this->collTParametreFormsRelatedByIdRef1Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByIdRef1->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByIdRef1($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByIdRef1 $tParametreFormRelatedByIdRef1 The tParametreFormRelatedByIdRef1 object to add.
     */
    protected function doAddTParametreFormRelatedByIdRef1($tParametreFormRelatedByIdRef1)
    {
        $this->collTParametreFormsRelatedByIdRef1[]= $tParametreFormRelatedByIdRef1;
        $tParametreFormRelatedByIdRef1->setTReferentielRelatedByIdRef1($this);
    }

    /**
     * @param	TParametreFormRelatedByIdRef1 $tParametreFormRelatedByIdRef1 The tParametreFormRelatedByIdRef1 object to remove.
     * @return TReferentiel The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByIdRef1($tParametreFormRelatedByIdRef1)
    {
        if ($this->getTParametreFormsRelatedByIdRef1()->contains($tParametreFormRelatedByIdRef1)) {
            $this->collTParametreFormsRelatedByIdRef1->remove($this->collTParametreFormsRelatedByIdRef1->search($tParametreFormRelatedByIdRef1));
            if (null === $this->tParametreFormsRelatedByIdRef1ScheduledForDeletion) {
                $this->tParametreFormsRelatedByIdRef1ScheduledForDeletion = clone $this->collTParametreFormsRelatedByIdRef1;
                $this->tParametreFormsRelatedByIdRef1ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByIdRef1ScheduledForDeletion[]= $tParametreFormRelatedByIdRef1;
            $tParametreFormRelatedByIdRef1->setTReferentielRelatedByIdRef1(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef1JoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef1JoinTTraductionRelatedByCodeLibelleRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef1JoinTTraductionRelatedByCodeLibelleRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef1JoinTTraductionRelatedByCodeLibelleRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef1JoinTTraductionRelatedByCodeLibelleText1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText1', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef1JoinTTraductionRelatedByCodeLibelleText2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText2', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef1JoinTTraductionRelatedByCodeLibelleText3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText3', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef1($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByIdRef2 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TReferentiel The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByIdRef2()
     */
    public function clearTParametreFormsRelatedByIdRef2()
    {
        $this->collTParametreFormsRelatedByIdRef2 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByIdRef2Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByIdRef2 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByIdRef2($v = true)
    {
        $this->collTParametreFormsRelatedByIdRef2Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByIdRef2 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByIdRef2 collection to an empty array (like clearcollTParametreFormsRelatedByIdRef2());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByIdRef2($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByIdRef2 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByIdRef2 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByIdRef2->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByIdRef2($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByIdRef2Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByIdRef2 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByIdRef2) {
                // return empty collection
                $this->initTParametreFormsRelatedByIdRef2();
            } else {
                $collTParametreFormsRelatedByIdRef2 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTReferentielRelatedByIdRef2($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByIdRef2Partial && count($collTParametreFormsRelatedByIdRef2)) {
                      $this->initTParametreFormsRelatedByIdRef2(false);

                      foreach($collTParametreFormsRelatedByIdRef2 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByIdRef2->contains($obj)) {
                          $this->collTParametreFormsRelatedByIdRef2->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByIdRef2Partial = true;
                    }

                    $collTParametreFormsRelatedByIdRef2->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByIdRef2;
                }

                if($partial && $this->collTParametreFormsRelatedByIdRef2) {
                    foreach($this->collTParametreFormsRelatedByIdRef2 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByIdRef2[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByIdRef2 = $collTParametreFormsRelatedByIdRef2;
                $this->collTParametreFormsRelatedByIdRef2Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByIdRef2;
    }

    /**
     * Sets a collection of TParametreFormRelatedByIdRef2 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByIdRef2 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TReferentiel The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByIdRef2(PropelCollection $tParametreFormsRelatedByIdRef2, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByIdRef2ToDelete = $this->getTParametreFormsRelatedByIdRef2(new Criteria(), $con)->diff($tParametreFormsRelatedByIdRef2);

        $this->tParametreFormsRelatedByIdRef2ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByIdRef2ToDelete));

        foreach ($tParametreFormsRelatedByIdRef2ToDelete as $tParametreFormRelatedByIdRef2Removed) {
            $tParametreFormRelatedByIdRef2Removed->setTReferentielRelatedByIdRef2(null);
        }

        $this->collTParametreFormsRelatedByIdRef2 = null;
        foreach ($tParametreFormsRelatedByIdRef2 as $tParametreFormRelatedByIdRef2) {
            $this->addTParametreFormRelatedByIdRef2($tParametreFormRelatedByIdRef2);
        }

        $this->collTParametreFormsRelatedByIdRef2 = $tParametreFormsRelatedByIdRef2;
        $this->collTParametreFormsRelatedByIdRef2Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByIdRef2(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByIdRef2Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByIdRef2 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByIdRef2) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByIdRef2());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTReferentielRelatedByIdRef2($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByIdRef2);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TReferentiel The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByIdRef2(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByIdRef2 === null) {
            $this->initTParametreFormsRelatedByIdRef2();
            $this->collTParametreFormsRelatedByIdRef2Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByIdRef2->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByIdRef2($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByIdRef2 $tParametreFormRelatedByIdRef2 The tParametreFormRelatedByIdRef2 object to add.
     */
    protected function doAddTParametreFormRelatedByIdRef2($tParametreFormRelatedByIdRef2)
    {
        $this->collTParametreFormsRelatedByIdRef2[]= $tParametreFormRelatedByIdRef2;
        $tParametreFormRelatedByIdRef2->setTReferentielRelatedByIdRef2($this);
    }

    /**
     * @param	TParametreFormRelatedByIdRef2 $tParametreFormRelatedByIdRef2 The tParametreFormRelatedByIdRef2 object to remove.
     * @return TReferentiel The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByIdRef2($tParametreFormRelatedByIdRef2)
    {
        if ($this->getTParametreFormsRelatedByIdRef2()->contains($tParametreFormRelatedByIdRef2)) {
            $this->collTParametreFormsRelatedByIdRef2->remove($this->collTParametreFormsRelatedByIdRef2->search($tParametreFormRelatedByIdRef2));
            if (null === $this->tParametreFormsRelatedByIdRef2ScheduledForDeletion) {
                $this->tParametreFormsRelatedByIdRef2ScheduledForDeletion = clone $this->collTParametreFormsRelatedByIdRef2;
                $this->tParametreFormsRelatedByIdRef2ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByIdRef2ScheduledForDeletion[]= $tParametreFormRelatedByIdRef2;
            $tParametreFormRelatedByIdRef2->setTReferentielRelatedByIdRef2(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef2JoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef2JoinTTraductionRelatedByCodeLibelleRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef2JoinTTraductionRelatedByCodeLibelleRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef2JoinTTraductionRelatedByCodeLibelleRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef2JoinTTraductionRelatedByCodeLibelleText1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText1', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef2JoinTTraductionRelatedByCodeLibelleText2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText2', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef2JoinTTraductionRelatedByCodeLibelleText3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText3', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef2($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByIdRef3 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TReferentiel The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByIdRef3()
     */
    public function clearTParametreFormsRelatedByIdRef3()
    {
        $this->collTParametreFormsRelatedByIdRef3 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByIdRef3Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByIdRef3 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByIdRef3($v = true)
    {
        $this->collTParametreFormsRelatedByIdRef3Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByIdRef3 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByIdRef3 collection to an empty array (like clearcollTParametreFormsRelatedByIdRef3());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByIdRef3($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByIdRef3 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByIdRef3 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByIdRef3->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByIdRef3($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByIdRef3Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByIdRef3 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByIdRef3) {
                // return empty collection
                $this->initTParametreFormsRelatedByIdRef3();
            } else {
                $collTParametreFormsRelatedByIdRef3 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTReferentielRelatedByIdRef3($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByIdRef3Partial && count($collTParametreFormsRelatedByIdRef3)) {
                      $this->initTParametreFormsRelatedByIdRef3(false);

                      foreach($collTParametreFormsRelatedByIdRef3 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByIdRef3->contains($obj)) {
                          $this->collTParametreFormsRelatedByIdRef3->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByIdRef3Partial = true;
                    }

                    $collTParametreFormsRelatedByIdRef3->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByIdRef3;
                }

                if($partial && $this->collTParametreFormsRelatedByIdRef3) {
                    foreach($this->collTParametreFormsRelatedByIdRef3 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByIdRef3[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByIdRef3 = $collTParametreFormsRelatedByIdRef3;
                $this->collTParametreFormsRelatedByIdRef3Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByIdRef3;
    }

    /**
     * Sets a collection of TParametreFormRelatedByIdRef3 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByIdRef3 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TReferentiel The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByIdRef3(PropelCollection $tParametreFormsRelatedByIdRef3, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByIdRef3ToDelete = $this->getTParametreFormsRelatedByIdRef3(new Criteria(), $con)->diff($tParametreFormsRelatedByIdRef3);

        $this->tParametreFormsRelatedByIdRef3ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByIdRef3ToDelete));

        foreach ($tParametreFormsRelatedByIdRef3ToDelete as $tParametreFormRelatedByIdRef3Removed) {
            $tParametreFormRelatedByIdRef3Removed->setTReferentielRelatedByIdRef3(null);
        }

        $this->collTParametreFormsRelatedByIdRef3 = null;
        foreach ($tParametreFormsRelatedByIdRef3 as $tParametreFormRelatedByIdRef3) {
            $this->addTParametreFormRelatedByIdRef3($tParametreFormRelatedByIdRef3);
        }

        $this->collTParametreFormsRelatedByIdRef3 = $tParametreFormsRelatedByIdRef3;
        $this->collTParametreFormsRelatedByIdRef3Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByIdRef3(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByIdRef3Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByIdRef3 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByIdRef3) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByIdRef3());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTReferentielRelatedByIdRef3($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByIdRef3);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TReferentiel The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByIdRef3(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByIdRef3 === null) {
            $this->initTParametreFormsRelatedByIdRef3();
            $this->collTParametreFormsRelatedByIdRef3Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByIdRef3->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByIdRef3($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByIdRef3 $tParametreFormRelatedByIdRef3 The tParametreFormRelatedByIdRef3 object to add.
     */
    protected function doAddTParametreFormRelatedByIdRef3($tParametreFormRelatedByIdRef3)
    {
        $this->collTParametreFormsRelatedByIdRef3[]= $tParametreFormRelatedByIdRef3;
        $tParametreFormRelatedByIdRef3->setTReferentielRelatedByIdRef3($this);
    }

    /**
     * @param	TParametreFormRelatedByIdRef3 $tParametreFormRelatedByIdRef3 The tParametreFormRelatedByIdRef3 object to remove.
     * @return TReferentiel The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByIdRef3($tParametreFormRelatedByIdRef3)
    {
        if ($this->getTParametreFormsRelatedByIdRef3()->contains($tParametreFormRelatedByIdRef3)) {
            $this->collTParametreFormsRelatedByIdRef3->remove($this->collTParametreFormsRelatedByIdRef3->search($tParametreFormRelatedByIdRef3));
            if (null === $this->tParametreFormsRelatedByIdRef3ScheduledForDeletion) {
                $this->tParametreFormsRelatedByIdRef3ScheduledForDeletion = clone $this->collTParametreFormsRelatedByIdRef3;
                $this->tParametreFormsRelatedByIdRef3ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByIdRef3ScheduledForDeletion[]= $tParametreFormRelatedByIdRef3;
            $tParametreFormRelatedByIdRef3->setTReferentielRelatedByIdRef3(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef3JoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef3JoinTTraductionRelatedByCodeLibelleRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef3JoinTTraductionRelatedByCodeLibelleRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef3JoinTTraductionRelatedByCodeLibelleRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef3JoinTTraductionRelatedByCodeLibelleText1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText1', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef3JoinTTraductionRelatedByCodeLibelleText2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText2', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TParametreFormsRelatedByIdRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByIdRef3JoinTTraductionRelatedByCodeLibelleText3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibelleText3', $join_behavior);

        return $this->getTParametreFormsRelatedByIdRef3($query, $con);
    }

    /**
     * Clears out the collTValeurReferentiels collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TReferentiel The current object (for fluent API support)
     * @see        addTValeurReferentiels()
     */
    public function clearTValeurReferentiels()
    {
        $this->collTValeurReferentiels = null; // important to set this to null since that means it is uninitialized
        $this->collTValeurReferentielsPartial = null;

        return $this;
    }

    /**
     * reset is the collTValeurReferentiels collection loaded partially
     *
     * @return void
     */
    public function resetPartialTValeurReferentiels($v = true)
    {
        $this->collTValeurReferentielsPartial = $v;
    }

    /**
     * Initializes the collTValeurReferentiels collection.
     *
     * By default this just sets the collTValeurReferentiels collection to an empty array (like clearcollTValeurReferentiels());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTValeurReferentiels($overrideExisting = true)
    {
        if (null !== $this->collTValeurReferentiels && !$overrideExisting) {
            return;
        }
        $this->collTValeurReferentiels = new PropelObjectCollection();
        $this->collTValeurReferentiels->setModel('TValeurReferentiel');
    }

    /**
     * Gets an array of TValeurReferentiel objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TValeurReferentiel[] List of TValeurReferentiel objects
     * @throws PropelException
     */
    public function getTValeurReferentiels($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTValeurReferentielsPartial && !$this->isNew();
        if (null === $this->collTValeurReferentiels || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTValeurReferentiels) {
                // return empty collection
                $this->initTValeurReferentiels();
            } else {
                $collTValeurReferentiels = TValeurReferentielQuery::create(null, $criteria)
                    ->filterByTReferentiel($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTValeurReferentielsPartial && count($collTValeurReferentiels)) {
                      $this->initTValeurReferentiels(false);

                      foreach($collTValeurReferentiels as $obj) {
                        if (false == $this->collTValeurReferentiels->contains($obj)) {
                          $this->collTValeurReferentiels->append($obj);
                        }
                      }

                      $this->collTValeurReferentielsPartial = true;
                    }

                    $collTValeurReferentiels->getInternalIterator()->rewind();
                    return $collTValeurReferentiels;
                }

                if($partial && $this->collTValeurReferentiels) {
                    foreach($this->collTValeurReferentiels as $obj) {
                        if($obj->isNew()) {
                            $collTValeurReferentiels[] = $obj;
                        }
                    }
                }

                $this->collTValeurReferentiels = $collTValeurReferentiels;
                $this->collTValeurReferentielsPartial = false;
            }
        }

        return $this->collTValeurReferentiels;
    }

    /**
     * Sets a collection of TValeurReferentiel objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tValeurReferentiels A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TReferentiel The current object (for fluent API support)
     */
    public function setTValeurReferentiels(PropelCollection $tValeurReferentiels, PropelPDO $con = null)
    {
        $tValeurReferentielsToDelete = $this->getTValeurReferentiels(new Criteria(), $con)->diff($tValeurReferentiels);

        $this->tValeurReferentielsScheduledForDeletion = unserialize(serialize($tValeurReferentielsToDelete));

        foreach ($tValeurReferentielsToDelete as $tValeurReferentielRemoved) {
            $tValeurReferentielRemoved->setTReferentiel(null);
        }

        $this->collTValeurReferentiels = null;
        foreach ($tValeurReferentiels as $tValeurReferentiel) {
            $this->addTValeurReferentiel($tValeurReferentiel);
        }

        $this->collTValeurReferentiels = $tValeurReferentiels;
        $this->collTValeurReferentielsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TValeurReferentiel objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TValeurReferentiel objects.
     * @throws PropelException
     */
    public function countTValeurReferentiels(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTValeurReferentielsPartial && !$this->isNew();
        if (null === $this->collTValeurReferentiels || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTValeurReferentiels) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTValeurReferentiels());
            }
            $query = TValeurReferentielQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTReferentiel($this)
                ->count($con);
        }

        return count($this->collTValeurReferentiels);
    }

    /**
     * Method called to associate a TValeurReferentiel object to this object
     * through the TValeurReferentiel foreign key attribute.
     *
     * @param    TValeurReferentiel $l TValeurReferentiel
     * @return TReferentiel The current object (for fluent API support)
     */
    public function addTValeurReferentiel(TValeurReferentiel $l)
    {
        if ($this->collTValeurReferentiels === null) {
            $this->initTValeurReferentiels();
            $this->collTValeurReferentielsPartial = true;
        }
        if (!in_array($l, $this->collTValeurReferentiels->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTValeurReferentiel($l);
        }

        return $this;
    }

    /**
     * @param	TValeurReferentiel $tValeurReferentiel The tValeurReferentiel object to add.
     */
    protected function doAddTValeurReferentiel($tValeurReferentiel)
    {
        $this->collTValeurReferentiels[]= $tValeurReferentiel;
        $tValeurReferentiel->setTReferentiel($this);
    }

    /**
     * @param	TValeurReferentiel $tValeurReferentiel The tValeurReferentiel object to remove.
     * @return TReferentiel The current object (for fluent API support)
     */
    public function removeTValeurReferentiel($tValeurReferentiel)
    {
        if ($this->getTValeurReferentiels()->contains($tValeurReferentiel)) {
            $this->collTValeurReferentiels->remove($this->collTValeurReferentiels->search($tValeurReferentiel));
            if (null === $this->tValeurReferentielsScheduledForDeletion) {
                $this->tValeurReferentielsScheduledForDeletion = clone $this->collTValeurReferentiels;
                $this->tValeurReferentielsScheduledForDeletion->clear();
            }
            $this->tValeurReferentielsScheduledForDeletion[]= clone $tValeurReferentiel;
            $tValeurReferentiel->setTReferentiel(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TValeurReferentiels from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TValeurReferentiel[] List of TValeurReferentiel objects
     */
    public function getTValeurReferentielsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TValeurReferentielQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTValeurReferentiels($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TReferentiel is new, it will return
     * an empty collection; or if this TReferentiel has previously
     * been saved, it will retrieve related TValeurReferentiels from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TValeurReferentiel[] List of TValeurReferentiel objects
     */
    public function getTValeurReferentielsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TValeurReferentielQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTValeurReferentiels($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_referentiel = null;
        $this->code_libelle_referentiel = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTParametreFormsRelatedByIdRef1) {
                foreach ($this->collTParametreFormsRelatedByIdRef1 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByIdRef2) {
                foreach ($this->collTParametreFormsRelatedByIdRef2 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByIdRef3) {
                foreach ($this->collTParametreFormsRelatedByIdRef3 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTValeurReferentiels) {
                foreach ($this->collTValeurReferentiels as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraduction instanceof Persistent) {
              $this->aTTraduction->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTParametreFormsRelatedByIdRef1 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByIdRef1->clearIterator();
        }
        $this->collTParametreFormsRelatedByIdRef1 = null;
        if ($this->collTParametreFormsRelatedByIdRef2 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByIdRef2->clearIterator();
        }
        $this->collTParametreFormsRelatedByIdRef2 = null;
        if ($this->collTParametreFormsRelatedByIdRef3 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByIdRef3->clearIterator();
        }
        $this->collTParametreFormsRelatedByIdRef3 = null;
        if ($this->collTValeurReferentiels instanceof PropelCollection) {
            $this->collTValeurReferentiels->clearIterator();
        }
        $this->collTValeurReferentiels = null;
        $this->aTTraduction = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TReferentielPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
