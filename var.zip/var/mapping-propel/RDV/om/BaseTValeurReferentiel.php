<?php


/**
 * Base class that represents a row from the 'T_VALEUR_REFERENTIEL' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTValeurReferentiel extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TValeurReferentielPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TValeurReferentielPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_valeur_referentiel field.
     * @var        int
     */
    protected $id_valeur_referentiel;

    /**
     * The value for the code_libelle_valeur_referentiel field.
     * @var        int
     */
    protected $code_libelle_valeur_referentiel;

    /**
     * The value for the id_referentiel field.
     * @var        int
     */
    protected $id_referentiel;

    /**
     * The value for the id_organisation field.
     * @var        int
     */
    protected $id_organisation;

    /**
     * @var        TTraduction
     */
    protected $aTTraduction;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisation;

    /**
     * @var        TReferentiel
     */
    protected $aTReferentiel;

    /**
     * @var        PropelObjectCollection|TCitoyen[] Collection to store aggregation of TCitoyen objects.
     */
    protected $collTCitoyensRelatedByIdRef1;
    protected $collTCitoyensRelatedByIdRef1Partial;

    /**
     * @var        PropelObjectCollection|TCitoyen[] Collection to store aggregation of TCitoyen objects.
     */
    protected $collTCitoyensRelatedByIdRef2;
    protected $collTCitoyensRelatedByIdRef2Partial;

    /**
     * @var        PropelObjectCollection|TCitoyen[] Collection to store aggregation of TCitoyen objects.
     */
    protected $collTCitoyensRelatedByIdRef3;
    protected $collTCitoyensRelatedByIdRef3Partial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVouss;
    protected $collTRendezVoussPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tCitoyensRelatedByIdRef1ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tCitoyensRelatedByIdRef2ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tCitoyensRelatedByIdRef3ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussScheduledForDeletion = null;

    /**
     * Get the [id_valeur_referentiel] column value.
     *
     * @return int
     */
    public function getIdValeurReferentiel()
    {
        return $this->id_valeur_referentiel;
    }

    /**
     * Get the [code_libelle_valeur_referentiel] column value.
     *
     * @return int
     */
    public function getCodeLibelleValeurReferentiel()
    {
        return $this->code_libelle_valeur_referentiel;
    }

    /**
     * Get the [id_referentiel] column value.
     *
     * @return int
     */
    public function getIdReferentiel()
    {
        return $this->id_referentiel;
    }

    /**
     * Get the [id_organisation] column value.
     *
     * @return int
     */
    public function getIdOrganisation()
    {
        return $this->id_organisation;
    }

    /**
     * Set the value of [id_valeur_referentiel] column.
     *
     * @param int $v new value
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setIdValeurReferentiel($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_valeur_referentiel !== $v) {
            $this->id_valeur_referentiel = $v;
            $this->modifiedColumns[] = TValeurReferentielPeer::ID_VALEUR_REFERENTIEL;
        }


        return $this;
    } // setIdValeurReferentiel()

    /**
     * Set the value of [code_libelle_valeur_referentiel] column.
     *
     * @param int $v new value
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setCodeLibelleValeurReferentiel($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_valeur_referentiel !== $v) {
            $this->code_libelle_valeur_referentiel = $v;
            $this->modifiedColumns[] = TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL;
        }

        if ($this->aTTraduction !== null && $this->aTTraduction->getIdTraduction() !== $v) {
            $this->aTTraduction = null;
        }


        return $this;
    } // setCodeLibelleValeurReferentiel()

    /**
     * Set the value of [id_referentiel] column.
     *
     * @param int $v new value
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setIdReferentiel($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_referentiel !== $v) {
            $this->id_referentiel = $v;
            $this->modifiedColumns[] = TValeurReferentielPeer::ID_REFERENTIEL;
        }

        if ($this->aTReferentiel !== null && $this->aTReferentiel->getIdReferentiel() !== $v) {
            $this->aTReferentiel = null;
        }


        return $this;
    } // setIdReferentiel()

    /**
     * Set the value of [id_organisation] column.
     *
     * @param int $v new value
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setIdOrganisation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation !== $v) {
            $this->id_organisation = $v;
            $this->modifiedColumns[] = TValeurReferentielPeer::ID_ORGANISATION;
        }

        if ($this->aTOrganisation !== null && $this->aTOrganisation->getIdOrganisation() !== $v) {
            $this->aTOrganisation = null;
        }


        return $this;
    } // setIdOrganisation()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_valeur_referentiel = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->code_libelle_valeur_referentiel = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->id_referentiel = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->id_organisation = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 4; // 4 = TValeurReferentielPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TValeurReferentiel object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTTraduction !== null && $this->code_libelle_valeur_referentiel !== $this->aTTraduction->getIdTraduction()) {
            $this->aTTraduction = null;
        }
        if ($this->aTReferentiel !== null && $this->id_referentiel !== $this->aTReferentiel->getIdReferentiel()) {
            $this->aTReferentiel = null;
        }
        if ($this->aTOrganisation !== null && $this->id_organisation !== $this->aTOrganisation->getIdOrganisation()) {
            $this->aTOrganisation = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TValeurReferentielPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TValeurReferentielPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraduction = null;
            $this->aTOrganisation = null;
            $this->aTReferentiel = null;
            $this->collTCitoyensRelatedByIdRef1 = null;

            $this->collTCitoyensRelatedByIdRef2 = null;

            $this->collTCitoyensRelatedByIdRef3 = null;

            $this->collTRendezVouss = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TValeurReferentielPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TValeurReferentielQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TValeurReferentielPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TValeurReferentielPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if ($this->aTTraduction->isModified() || $this->aTTraduction->isNew()) {
                    $affectedRows += $this->aTTraduction->save($con);
                }
                $this->setTTraduction($this->aTTraduction);
            }

            if ($this->aTOrganisation !== null) {
                if ($this->aTOrganisation->isModified() || $this->aTOrganisation->isNew()) {
                    $affectedRows += $this->aTOrganisation->save($con);
                }
                $this->setTOrganisation($this->aTOrganisation);
            }

            if ($this->aTReferentiel !== null) {
                if ($this->aTReferentiel->isModified() || $this->aTReferentiel->isNew()) {
                    $affectedRows += $this->aTReferentiel->save($con);
                }
                $this->setTReferentiel($this->aTReferentiel);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tCitoyensRelatedByIdRef1ScheduledForDeletion !== null) {
                if (!$this->tCitoyensRelatedByIdRef1ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tCitoyensRelatedByIdRef1ScheduledForDeletion as $tCitoyenRelatedByIdRef1) {
                        // need to save related object because we set the relation to null
                        $tCitoyenRelatedByIdRef1->save($con);
                    }
                    $this->tCitoyensRelatedByIdRef1ScheduledForDeletion = null;
                }
            }

            if ($this->collTCitoyensRelatedByIdRef1 !== null) {
                foreach ($this->collTCitoyensRelatedByIdRef1 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tCitoyensRelatedByIdRef2ScheduledForDeletion !== null) {
                if (!$this->tCitoyensRelatedByIdRef2ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tCitoyensRelatedByIdRef2ScheduledForDeletion as $tCitoyenRelatedByIdRef2) {
                        // need to save related object because we set the relation to null
                        $tCitoyenRelatedByIdRef2->save($con);
                    }
                    $this->tCitoyensRelatedByIdRef2ScheduledForDeletion = null;
                }
            }

            if ($this->collTCitoyensRelatedByIdRef2 !== null) {
                foreach ($this->collTCitoyensRelatedByIdRef2 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tCitoyensRelatedByIdRef3ScheduledForDeletion !== null) {
                if (!$this->tCitoyensRelatedByIdRef3ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tCitoyensRelatedByIdRef3ScheduledForDeletion as $tCitoyenRelatedByIdRef3) {
                        // need to save related object because we set the relation to null
                        $tCitoyenRelatedByIdRef3->save($con);
                    }
                    $this->tCitoyensRelatedByIdRef3ScheduledForDeletion = null;
                }
            }

            if ($this->collTCitoyensRelatedByIdRef3 !== null) {
                foreach ($this->collTCitoyensRelatedByIdRef3 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussScheduledForDeletion !== null) {
                if (!$this->tRendezVoussScheduledForDeletion->isEmpty()) {
                    foreach ($this->tRendezVoussScheduledForDeletion as $tRendezVous) {
                        // need to save related object because we set the relation to null
                        $tRendezVous->save($con);
                    }
                    $this->tRendezVoussScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVouss !== null) {
                foreach ($this->collTRendezVouss as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;


         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_VALEUR_REFERENTIEL`';
        }
        if ($this->isColumnModified(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_VALEUR_REFERENTIEL`';
        }
        if ($this->isColumnModified(TValeurReferentielPeer::ID_REFERENTIEL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REFERENTIEL`';
        }
        if ($this->isColumnModified(TValeurReferentielPeer::ID_ORGANISATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION`';
        }

        $sql = sprintf(
            'INSERT INTO `T_VALEUR_REFERENTIEL` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_VALEUR_REFERENTIEL`':
                        $stmt->bindValue($identifier, $this->id_valeur_referentiel, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_VALEUR_REFERENTIEL`':
                        $stmt->bindValue($identifier, $this->code_libelle_valeur_referentiel, PDO::PARAM_INT);
                        break;
                    case '`ID_REFERENTIEL`':
                        $stmt->bindValue($identifier, $this->id_referentiel, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION`':
                        $stmt->bindValue($identifier, $this->id_organisation, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if (!$this->aTTraduction->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraduction->getValidationFailures());
                }
            }

            if ($this->aTOrganisation !== null) {
                if (!$this->aTOrganisation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisation->getValidationFailures());
                }
            }

            if ($this->aTReferentiel !== null) {
                if (!$this->aTReferentiel->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTReferentiel->getValidationFailures());
                }
            }


            if (($retval = TValeurReferentielPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTCitoyensRelatedByIdRef1 !== null) {
                    foreach ($this->collTCitoyensRelatedByIdRef1 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTCitoyensRelatedByIdRef2 !== null) {
                    foreach ($this->collTCitoyensRelatedByIdRef2 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTCitoyensRelatedByIdRef3 !== null) {
                    foreach ($this->collTCitoyensRelatedByIdRef3 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVouss !== null) {
                    foreach ($this->collTRendezVouss as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TValeurReferentielPeer::DATABASE_NAME);

        if ($this->isColumnModified(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL)) $criteria->add(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $this->id_valeur_referentiel);
        if ($this->isColumnModified(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL)) $criteria->add(TValeurReferentielPeer::CODE_LIBELLE_VALEUR_REFERENTIEL, $this->code_libelle_valeur_referentiel);
        if ($this->isColumnModified(TValeurReferentielPeer::ID_REFERENTIEL)) $criteria->add(TValeurReferentielPeer::ID_REFERENTIEL, $this->id_referentiel);
        if ($this->isColumnModified(TValeurReferentielPeer::ID_ORGANISATION)) $criteria->add(TValeurReferentielPeer::ID_ORGANISATION, $this->id_organisation);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TValeurReferentielPeer::DATABASE_NAME);
        $criteria->add(TValeurReferentielPeer::ID_VALEUR_REFERENTIEL, $this->id_valeur_referentiel);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdValeurReferentiel();
    }

    /**
     * Generic method to set the primary key (id_valeur_referentiel column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdValeurReferentiel($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdValeurReferentiel();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TValeurReferentiel (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setCodeLibelleValeurReferentiel($this->getCodeLibelleValeurReferentiel());
        $copyObj->setIdReferentiel($this->getIdReferentiel());
        $copyObj->setIdOrganisation($this->getIdOrganisation());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTCitoyensRelatedByIdRef1() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTCitoyenRelatedByIdRef1($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTCitoyensRelatedByIdRef2() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTCitoyenRelatedByIdRef2($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTCitoyensRelatedByIdRef3() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTCitoyenRelatedByIdRef3($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVouss() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVous($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdValeurReferentiel(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TValeurReferentiel Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TValeurReferentielPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TValeurReferentielPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TValeurReferentiel The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraduction(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleValeurReferentiel(NULL);
        } else {
            $this->setCodeLibelleValeurReferentiel($v->getIdTraduction());
        }

        $this->aTTraduction = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTValeurReferentiel($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraduction(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraduction === null && ($this->code_libelle_valeur_referentiel !== null) && $doQuery) {
            $this->aTTraduction = TTraductionQuery::create()->findPk($this->code_libelle_valeur_referentiel, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraduction->addTValeurReferentiels($this);
             */
        }

        return $this->aTTraduction;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TValeurReferentiel The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisation(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisation(NULL);
        } else {
            $this->setIdOrganisation($v->getIdOrganisation());
        }

        $this->aTOrganisation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTValeurReferentiel($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisation === null && ($this->id_organisation !== null) && $doQuery) {
            $this->aTOrganisation = TOrganisationQuery::create()->findPk($this->id_organisation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisation->addTValeurReferentiels($this);
             */
        }

        return $this->aTOrganisation;
    }

    /**
     * Declares an association between this object and a TReferentiel object.
     *
     * @param             TReferentiel $v
     * @return TValeurReferentiel The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTReferentiel(TReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdReferentiel(NULL);
        } else {
            $this->setIdReferentiel($v->getIdReferentiel());
        }

        $this->aTReferentiel = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTValeurReferentiel($this);
        }


        return $this;
    }


    /**
     * Get the associated TReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TReferentiel The associated TReferentiel object.
     * @throws PropelException
     */
    public function getTReferentiel(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTReferentiel === null && ($this->id_referentiel !== null) && $doQuery) {
            $this->aTReferentiel = TReferentielQuery::create()->findPk($this->id_referentiel, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTReferentiel->addTValeurReferentiels($this);
             */
        }

        return $this->aTReferentiel;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TCitoyenRelatedByIdRef1' == $relationName) {
            $this->initTCitoyensRelatedByIdRef1();
        }
        if ('TCitoyenRelatedByIdRef2' == $relationName) {
            $this->initTCitoyensRelatedByIdRef2();
        }
        if ('TCitoyenRelatedByIdRef3' == $relationName) {
            $this->initTCitoyensRelatedByIdRef3();
        }
        if ('TRendezVous' == $relationName) {
            $this->initTRendezVouss();
        }
    }

    /**
     * Clears out the collTCitoyensRelatedByIdRef1 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TValeurReferentiel The current object (for fluent API support)
     * @see        addTCitoyensRelatedByIdRef1()
     */
    public function clearTCitoyensRelatedByIdRef1()
    {
        $this->collTCitoyensRelatedByIdRef1 = null; // important to set this to null since that means it is uninitialized
        $this->collTCitoyensRelatedByIdRef1Partial = null;

        return $this;
    }

    /**
     * reset is the collTCitoyensRelatedByIdRef1 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTCitoyensRelatedByIdRef1($v = true)
    {
        $this->collTCitoyensRelatedByIdRef1Partial = $v;
    }

    /**
     * Initializes the collTCitoyensRelatedByIdRef1 collection.
     *
     * By default this just sets the collTCitoyensRelatedByIdRef1 collection to an empty array (like clearcollTCitoyensRelatedByIdRef1());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTCitoyensRelatedByIdRef1($overrideExisting = true)
    {
        if (null !== $this->collTCitoyensRelatedByIdRef1 && !$overrideExisting) {
            return;
        }
        $this->collTCitoyensRelatedByIdRef1 = new PropelObjectCollection();
        $this->collTCitoyensRelatedByIdRef1->setModel('TCitoyen');
    }

    /**
     * Gets an array of TCitoyen objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TValeurReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TCitoyen[] List of TCitoyen objects
     * @throws PropelException
     */
    public function getTCitoyensRelatedByIdRef1($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTCitoyensRelatedByIdRef1Partial && !$this->isNew();
        if (null === $this->collTCitoyensRelatedByIdRef1 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTCitoyensRelatedByIdRef1) {
                // return empty collection
                $this->initTCitoyensRelatedByIdRef1();
            } else {
                $collTCitoyensRelatedByIdRef1 = TCitoyenQuery::create(null, $criteria)
                    ->filterByTValeurReferentielRelatedByIdRef1($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTCitoyensRelatedByIdRef1Partial && count($collTCitoyensRelatedByIdRef1)) {
                      $this->initTCitoyensRelatedByIdRef1(false);

                      foreach($collTCitoyensRelatedByIdRef1 as $obj) {
                        if (false == $this->collTCitoyensRelatedByIdRef1->contains($obj)) {
                          $this->collTCitoyensRelatedByIdRef1->append($obj);
                        }
                      }

                      $this->collTCitoyensRelatedByIdRef1Partial = true;
                    }

                    $collTCitoyensRelatedByIdRef1->getInternalIterator()->rewind();
                    return $collTCitoyensRelatedByIdRef1;
                }

                if($partial && $this->collTCitoyensRelatedByIdRef1) {
                    foreach($this->collTCitoyensRelatedByIdRef1 as $obj) {
                        if($obj->isNew()) {
                            $collTCitoyensRelatedByIdRef1[] = $obj;
                        }
                    }
                }

                $this->collTCitoyensRelatedByIdRef1 = $collTCitoyensRelatedByIdRef1;
                $this->collTCitoyensRelatedByIdRef1Partial = false;
            }
        }

        return $this->collTCitoyensRelatedByIdRef1;
    }

    /**
     * Sets a collection of TCitoyenRelatedByIdRef1 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tCitoyensRelatedByIdRef1 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setTCitoyensRelatedByIdRef1(PropelCollection $tCitoyensRelatedByIdRef1, PropelPDO $con = null)
    {
        $tCitoyensRelatedByIdRef1ToDelete = $this->getTCitoyensRelatedByIdRef1(new Criteria(), $con)->diff($tCitoyensRelatedByIdRef1);

        $this->tCitoyensRelatedByIdRef1ScheduledForDeletion = unserialize(serialize($tCitoyensRelatedByIdRef1ToDelete));

        foreach ($tCitoyensRelatedByIdRef1ToDelete as $tCitoyenRelatedByIdRef1Removed) {
            $tCitoyenRelatedByIdRef1Removed->setTValeurReferentielRelatedByIdRef1(null);
        }

        $this->collTCitoyensRelatedByIdRef1 = null;
        foreach ($tCitoyensRelatedByIdRef1 as $tCitoyenRelatedByIdRef1) {
            $this->addTCitoyenRelatedByIdRef1($tCitoyenRelatedByIdRef1);
        }

        $this->collTCitoyensRelatedByIdRef1 = $tCitoyensRelatedByIdRef1;
        $this->collTCitoyensRelatedByIdRef1Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TCitoyen objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TCitoyen objects.
     * @throws PropelException
     */
    public function countTCitoyensRelatedByIdRef1(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTCitoyensRelatedByIdRef1Partial && !$this->isNew();
        if (null === $this->collTCitoyensRelatedByIdRef1 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTCitoyensRelatedByIdRef1) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTCitoyensRelatedByIdRef1());
            }
            $query = TCitoyenQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTValeurReferentielRelatedByIdRef1($this)
                ->count($con);
        }

        return count($this->collTCitoyensRelatedByIdRef1);
    }

    /**
     * Method called to associate a TCitoyen object to this object
     * through the TCitoyen foreign key attribute.
     *
     * @param    TCitoyen $l TCitoyen
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function addTCitoyenRelatedByIdRef1(TCitoyen $l)
    {
        if ($this->collTCitoyensRelatedByIdRef1 === null) {
            $this->initTCitoyensRelatedByIdRef1();
            $this->collTCitoyensRelatedByIdRef1Partial = true;
        }
        if (!in_array($l, $this->collTCitoyensRelatedByIdRef1->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTCitoyenRelatedByIdRef1($l);
        }

        return $this;
    }

    /**
     * @param	TCitoyenRelatedByIdRef1 $tCitoyenRelatedByIdRef1 The tCitoyenRelatedByIdRef1 object to add.
     */
    protected function doAddTCitoyenRelatedByIdRef1($tCitoyenRelatedByIdRef1)
    {
        $this->collTCitoyensRelatedByIdRef1[]= $tCitoyenRelatedByIdRef1;
        $tCitoyenRelatedByIdRef1->setTValeurReferentielRelatedByIdRef1($this);
    }

    /**
     * @param	TCitoyenRelatedByIdRef1 $tCitoyenRelatedByIdRef1 The tCitoyenRelatedByIdRef1 object to remove.
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function removeTCitoyenRelatedByIdRef1($tCitoyenRelatedByIdRef1)
    {
        if ($this->getTCitoyensRelatedByIdRef1()->contains($tCitoyenRelatedByIdRef1)) {
            $this->collTCitoyensRelatedByIdRef1->remove($this->collTCitoyensRelatedByIdRef1->search($tCitoyenRelatedByIdRef1));
            if (null === $this->tCitoyensRelatedByIdRef1ScheduledForDeletion) {
                $this->tCitoyensRelatedByIdRef1ScheduledForDeletion = clone $this->collTCitoyensRelatedByIdRef1;
                $this->tCitoyensRelatedByIdRef1ScheduledForDeletion->clear();
            }
            $this->tCitoyensRelatedByIdRef1ScheduledForDeletion[]= $tCitoyenRelatedByIdRef1;
            $tCitoyenRelatedByIdRef1->setTValeurReferentielRelatedByIdRef1(null);
        }

        return $this;
    }

    /**
     * Clears out the collTCitoyensRelatedByIdRef2 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TValeurReferentiel The current object (for fluent API support)
     * @see        addTCitoyensRelatedByIdRef2()
     */
    public function clearTCitoyensRelatedByIdRef2()
    {
        $this->collTCitoyensRelatedByIdRef2 = null; // important to set this to null since that means it is uninitialized
        $this->collTCitoyensRelatedByIdRef2Partial = null;

        return $this;
    }

    /**
     * reset is the collTCitoyensRelatedByIdRef2 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTCitoyensRelatedByIdRef2($v = true)
    {
        $this->collTCitoyensRelatedByIdRef2Partial = $v;
    }

    /**
     * Initializes the collTCitoyensRelatedByIdRef2 collection.
     *
     * By default this just sets the collTCitoyensRelatedByIdRef2 collection to an empty array (like clearcollTCitoyensRelatedByIdRef2());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTCitoyensRelatedByIdRef2($overrideExisting = true)
    {
        if (null !== $this->collTCitoyensRelatedByIdRef2 && !$overrideExisting) {
            return;
        }
        $this->collTCitoyensRelatedByIdRef2 = new PropelObjectCollection();
        $this->collTCitoyensRelatedByIdRef2->setModel('TCitoyen');
    }

    /**
     * Gets an array of TCitoyen objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TValeurReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TCitoyen[] List of TCitoyen objects
     * @throws PropelException
     */
    public function getTCitoyensRelatedByIdRef2($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTCitoyensRelatedByIdRef2Partial && !$this->isNew();
        if (null === $this->collTCitoyensRelatedByIdRef2 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTCitoyensRelatedByIdRef2) {
                // return empty collection
                $this->initTCitoyensRelatedByIdRef2();
            } else {
                $collTCitoyensRelatedByIdRef2 = TCitoyenQuery::create(null, $criteria)
                    ->filterByTValeurReferentielRelatedByIdRef2($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTCitoyensRelatedByIdRef2Partial && count($collTCitoyensRelatedByIdRef2)) {
                      $this->initTCitoyensRelatedByIdRef2(false);

                      foreach($collTCitoyensRelatedByIdRef2 as $obj) {
                        if (false == $this->collTCitoyensRelatedByIdRef2->contains($obj)) {
                          $this->collTCitoyensRelatedByIdRef2->append($obj);
                        }
                      }

                      $this->collTCitoyensRelatedByIdRef2Partial = true;
                    }

                    $collTCitoyensRelatedByIdRef2->getInternalIterator()->rewind();
                    return $collTCitoyensRelatedByIdRef2;
                }

                if($partial && $this->collTCitoyensRelatedByIdRef2) {
                    foreach($this->collTCitoyensRelatedByIdRef2 as $obj) {
                        if($obj->isNew()) {
                            $collTCitoyensRelatedByIdRef2[] = $obj;
                        }
                    }
                }

                $this->collTCitoyensRelatedByIdRef2 = $collTCitoyensRelatedByIdRef2;
                $this->collTCitoyensRelatedByIdRef2Partial = false;
            }
        }

        return $this->collTCitoyensRelatedByIdRef2;
    }

    /**
     * Sets a collection of TCitoyenRelatedByIdRef2 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tCitoyensRelatedByIdRef2 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setTCitoyensRelatedByIdRef2(PropelCollection $tCitoyensRelatedByIdRef2, PropelPDO $con = null)
    {
        $tCitoyensRelatedByIdRef2ToDelete = $this->getTCitoyensRelatedByIdRef2(new Criteria(), $con)->diff($tCitoyensRelatedByIdRef2);

        $this->tCitoyensRelatedByIdRef2ScheduledForDeletion = unserialize(serialize($tCitoyensRelatedByIdRef2ToDelete));

        foreach ($tCitoyensRelatedByIdRef2ToDelete as $tCitoyenRelatedByIdRef2Removed) {
            $tCitoyenRelatedByIdRef2Removed->setTValeurReferentielRelatedByIdRef2(null);
        }

        $this->collTCitoyensRelatedByIdRef2 = null;
        foreach ($tCitoyensRelatedByIdRef2 as $tCitoyenRelatedByIdRef2) {
            $this->addTCitoyenRelatedByIdRef2($tCitoyenRelatedByIdRef2);
        }

        $this->collTCitoyensRelatedByIdRef2 = $tCitoyensRelatedByIdRef2;
        $this->collTCitoyensRelatedByIdRef2Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TCitoyen objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TCitoyen objects.
     * @throws PropelException
     */
    public function countTCitoyensRelatedByIdRef2(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTCitoyensRelatedByIdRef2Partial && !$this->isNew();
        if (null === $this->collTCitoyensRelatedByIdRef2 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTCitoyensRelatedByIdRef2) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTCitoyensRelatedByIdRef2());
            }
            $query = TCitoyenQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTValeurReferentielRelatedByIdRef2($this)
                ->count($con);
        }

        return count($this->collTCitoyensRelatedByIdRef2);
    }

    /**
     * Method called to associate a TCitoyen object to this object
     * through the TCitoyen foreign key attribute.
     *
     * @param    TCitoyen $l TCitoyen
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function addTCitoyenRelatedByIdRef2(TCitoyen $l)
    {
        if ($this->collTCitoyensRelatedByIdRef2 === null) {
            $this->initTCitoyensRelatedByIdRef2();
            $this->collTCitoyensRelatedByIdRef2Partial = true;
        }
        if (!in_array($l, $this->collTCitoyensRelatedByIdRef2->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTCitoyenRelatedByIdRef2($l);
        }

        return $this;
    }

    /**
     * @param	TCitoyenRelatedByIdRef2 $tCitoyenRelatedByIdRef2 The tCitoyenRelatedByIdRef2 object to add.
     */
    protected function doAddTCitoyenRelatedByIdRef2($tCitoyenRelatedByIdRef2)
    {
        $this->collTCitoyensRelatedByIdRef2[]= $tCitoyenRelatedByIdRef2;
        $tCitoyenRelatedByIdRef2->setTValeurReferentielRelatedByIdRef2($this);
    }

    /**
     * @param	TCitoyenRelatedByIdRef2 $tCitoyenRelatedByIdRef2 The tCitoyenRelatedByIdRef2 object to remove.
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function removeTCitoyenRelatedByIdRef2($tCitoyenRelatedByIdRef2)
    {
        if ($this->getTCitoyensRelatedByIdRef2()->contains($tCitoyenRelatedByIdRef2)) {
            $this->collTCitoyensRelatedByIdRef2->remove($this->collTCitoyensRelatedByIdRef2->search($tCitoyenRelatedByIdRef2));
            if (null === $this->tCitoyensRelatedByIdRef2ScheduledForDeletion) {
                $this->tCitoyensRelatedByIdRef2ScheduledForDeletion = clone $this->collTCitoyensRelatedByIdRef2;
                $this->tCitoyensRelatedByIdRef2ScheduledForDeletion->clear();
            }
            $this->tCitoyensRelatedByIdRef2ScheduledForDeletion[]= $tCitoyenRelatedByIdRef2;
            $tCitoyenRelatedByIdRef2->setTValeurReferentielRelatedByIdRef2(null);
        }

        return $this;
    }

    /**
     * Clears out the collTCitoyensRelatedByIdRef3 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TValeurReferentiel The current object (for fluent API support)
     * @see        addTCitoyensRelatedByIdRef3()
     */
    public function clearTCitoyensRelatedByIdRef3()
    {
        $this->collTCitoyensRelatedByIdRef3 = null; // important to set this to null since that means it is uninitialized
        $this->collTCitoyensRelatedByIdRef3Partial = null;

        return $this;
    }

    /**
     * reset is the collTCitoyensRelatedByIdRef3 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTCitoyensRelatedByIdRef3($v = true)
    {
        $this->collTCitoyensRelatedByIdRef3Partial = $v;
    }

    /**
     * Initializes the collTCitoyensRelatedByIdRef3 collection.
     *
     * By default this just sets the collTCitoyensRelatedByIdRef3 collection to an empty array (like clearcollTCitoyensRelatedByIdRef3());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTCitoyensRelatedByIdRef3($overrideExisting = true)
    {
        if (null !== $this->collTCitoyensRelatedByIdRef3 && !$overrideExisting) {
            return;
        }
        $this->collTCitoyensRelatedByIdRef3 = new PropelObjectCollection();
        $this->collTCitoyensRelatedByIdRef3->setModel('TCitoyen');
    }

    /**
     * Gets an array of TCitoyen objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TValeurReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TCitoyen[] List of TCitoyen objects
     * @throws PropelException
     */
    public function getTCitoyensRelatedByIdRef3($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTCitoyensRelatedByIdRef3Partial && !$this->isNew();
        if (null === $this->collTCitoyensRelatedByIdRef3 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTCitoyensRelatedByIdRef3) {
                // return empty collection
                $this->initTCitoyensRelatedByIdRef3();
            } else {
                $collTCitoyensRelatedByIdRef3 = TCitoyenQuery::create(null, $criteria)
                    ->filterByTValeurReferentielRelatedByIdRef3($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTCitoyensRelatedByIdRef3Partial && count($collTCitoyensRelatedByIdRef3)) {
                      $this->initTCitoyensRelatedByIdRef3(false);

                      foreach($collTCitoyensRelatedByIdRef3 as $obj) {
                        if (false == $this->collTCitoyensRelatedByIdRef3->contains($obj)) {
                          $this->collTCitoyensRelatedByIdRef3->append($obj);
                        }
                      }

                      $this->collTCitoyensRelatedByIdRef3Partial = true;
                    }

                    $collTCitoyensRelatedByIdRef3->getInternalIterator()->rewind();
                    return $collTCitoyensRelatedByIdRef3;
                }

                if($partial && $this->collTCitoyensRelatedByIdRef3) {
                    foreach($this->collTCitoyensRelatedByIdRef3 as $obj) {
                        if($obj->isNew()) {
                            $collTCitoyensRelatedByIdRef3[] = $obj;
                        }
                    }
                }

                $this->collTCitoyensRelatedByIdRef3 = $collTCitoyensRelatedByIdRef3;
                $this->collTCitoyensRelatedByIdRef3Partial = false;
            }
        }

        return $this->collTCitoyensRelatedByIdRef3;
    }

    /**
     * Sets a collection of TCitoyenRelatedByIdRef3 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tCitoyensRelatedByIdRef3 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setTCitoyensRelatedByIdRef3(PropelCollection $tCitoyensRelatedByIdRef3, PropelPDO $con = null)
    {
        $tCitoyensRelatedByIdRef3ToDelete = $this->getTCitoyensRelatedByIdRef3(new Criteria(), $con)->diff($tCitoyensRelatedByIdRef3);

        $this->tCitoyensRelatedByIdRef3ScheduledForDeletion = unserialize(serialize($tCitoyensRelatedByIdRef3ToDelete));

        foreach ($tCitoyensRelatedByIdRef3ToDelete as $tCitoyenRelatedByIdRef3Removed) {
            $tCitoyenRelatedByIdRef3Removed->setTValeurReferentielRelatedByIdRef3(null);
        }

        $this->collTCitoyensRelatedByIdRef3 = null;
        foreach ($tCitoyensRelatedByIdRef3 as $tCitoyenRelatedByIdRef3) {
            $this->addTCitoyenRelatedByIdRef3($tCitoyenRelatedByIdRef3);
        }

        $this->collTCitoyensRelatedByIdRef3 = $tCitoyensRelatedByIdRef3;
        $this->collTCitoyensRelatedByIdRef3Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TCitoyen objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TCitoyen objects.
     * @throws PropelException
     */
    public function countTCitoyensRelatedByIdRef3(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTCitoyensRelatedByIdRef3Partial && !$this->isNew();
        if (null === $this->collTCitoyensRelatedByIdRef3 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTCitoyensRelatedByIdRef3) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTCitoyensRelatedByIdRef3());
            }
            $query = TCitoyenQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTValeurReferentielRelatedByIdRef3($this)
                ->count($con);
        }

        return count($this->collTCitoyensRelatedByIdRef3);
    }

    /**
     * Method called to associate a TCitoyen object to this object
     * through the TCitoyen foreign key attribute.
     *
     * @param    TCitoyen $l TCitoyen
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function addTCitoyenRelatedByIdRef3(TCitoyen $l)
    {
        if ($this->collTCitoyensRelatedByIdRef3 === null) {
            $this->initTCitoyensRelatedByIdRef3();
            $this->collTCitoyensRelatedByIdRef3Partial = true;
        }
        if (!in_array($l, $this->collTCitoyensRelatedByIdRef3->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTCitoyenRelatedByIdRef3($l);
        }

        return $this;
    }

    /**
     * @param	TCitoyenRelatedByIdRef3 $tCitoyenRelatedByIdRef3 The tCitoyenRelatedByIdRef3 object to add.
     */
    protected function doAddTCitoyenRelatedByIdRef3($tCitoyenRelatedByIdRef3)
    {
        $this->collTCitoyensRelatedByIdRef3[]= $tCitoyenRelatedByIdRef3;
        $tCitoyenRelatedByIdRef3->setTValeurReferentielRelatedByIdRef3($this);
    }

    /**
     * @param	TCitoyenRelatedByIdRef3 $tCitoyenRelatedByIdRef3 The tCitoyenRelatedByIdRef3 object to remove.
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function removeTCitoyenRelatedByIdRef3($tCitoyenRelatedByIdRef3)
    {
        if ($this->getTCitoyensRelatedByIdRef3()->contains($tCitoyenRelatedByIdRef3)) {
            $this->collTCitoyensRelatedByIdRef3->remove($this->collTCitoyensRelatedByIdRef3->search($tCitoyenRelatedByIdRef3));
            if (null === $this->tCitoyensRelatedByIdRef3ScheduledForDeletion) {
                $this->tCitoyensRelatedByIdRef3ScheduledForDeletion = clone $this->collTCitoyensRelatedByIdRef3;
                $this->tCitoyensRelatedByIdRef3ScheduledForDeletion->clear();
            }
            $this->tCitoyensRelatedByIdRef3ScheduledForDeletion[]= $tCitoyenRelatedByIdRef3;
            $tCitoyenRelatedByIdRef3->setTValeurReferentielRelatedByIdRef3(null);
        }

        return $this;
    }

    /**
     * Clears out the collTRendezVouss collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TValeurReferentiel The current object (for fluent API support)
     * @see        addTRendezVouss()
     */
    public function clearTRendezVouss()
    {
        $this->collTRendezVouss = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVouss collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVouss($v = true)
    {
        $this->collTRendezVoussPartial = $v;
    }

    /**
     * Initializes the collTRendezVouss collection.
     *
     * By default this just sets the collTRendezVouss collection to an empty array (like clearcollTRendezVouss());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVouss($overrideExisting = true)
    {
        if (null !== $this->collTRendezVouss && !$overrideExisting) {
            return;
        }
        $this->collTRendezVouss = new PropelObjectCollection();
        $this->collTRendezVouss->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TValeurReferentiel is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVouss($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                // return empty collection
                $this->initTRendezVouss();
            } else {
                $collTRendezVouss = TRendezVousQuery::create(null, $criteria)
                    ->filterByTValeurReferentiel($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussPartial && count($collTRendezVouss)) {
                      $this->initTRendezVouss(false);

                      foreach($collTRendezVouss as $obj) {
                        if (false == $this->collTRendezVouss->contains($obj)) {
                          $this->collTRendezVouss->append($obj);
                        }
                      }

                      $this->collTRendezVoussPartial = true;
                    }

                    $collTRendezVouss->getInternalIterator()->rewind();
                    return $collTRendezVouss;
                }

                if($partial && $this->collTRendezVouss) {
                    foreach($this->collTRendezVouss as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVouss[] = $obj;
                        }
                    }
                }

                $this->collTRendezVouss = $collTRendezVouss;
                $this->collTRendezVoussPartial = false;
            }
        }

        return $this->collTRendezVouss;
    }

    /**
     * Sets a collection of TRendezVous objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVouss A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function setTRendezVouss(PropelCollection $tRendezVouss, PropelPDO $con = null)
    {
        $tRendezVoussToDelete = $this->getTRendezVouss(new Criteria(), $con)->diff($tRendezVouss);

        $this->tRendezVoussScheduledForDeletion = unserialize(serialize($tRendezVoussToDelete));

        foreach ($tRendezVoussToDelete as $tRendezVousRemoved) {
            $tRendezVousRemoved->setTValeurReferentiel(null);
        }

        $this->collTRendezVouss = null;
        foreach ($tRendezVouss as $tRendezVous) {
            $this->addTRendezVous($tRendezVous);
        }

        $this->collTRendezVouss = $tRendezVouss;
        $this->collTRendezVoussPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVouss(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVouss());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTValeurReferentiel($this)
                ->count($con);
        }

        return count($this->collTRendezVouss);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function addTRendezVous(TRendezVous $l)
    {
        if ($this->collTRendezVouss === null) {
            $this->initTRendezVouss();
            $this->collTRendezVoussPartial = true;
        }
        if (!in_array($l, $this->collTRendezVouss->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVous($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to add.
     */
    protected function doAddTRendezVous($tRendezVous)
    {
        $this->collTRendezVouss[]= $tRendezVous;
        $tRendezVous->setTValeurReferentiel($this);
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to remove.
     * @return TValeurReferentiel The current object (for fluent API support)
     */
    public function removeTRendezVous($tRendezVous)
    {
        if ($this->getTRendezVouss()->contains($tRendezVous)) {
            $this->collTRendezVouss->remove($this->collTRendezVouss->search($tRendezVous));
            if (null === $this->tRendezVoussScheduledForDeletion) {
                $this->tRendezVoussScheduledForDeletion = clone $this->collTRendezVouss;
                $this->tRendezVoussScheduledForDeletion->clear();
            }
            $this->tRendezVoussScheduledForDeletion[]= $tRendezVous;
            $tRendezVous->setTValeurReferentiel(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAccueil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAccueil', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAnnulation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAnnulation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentConfirmation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentConfirmation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentRessource($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentRessource', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentTeleoperateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentTeleoperateur', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TValeurReferentiel is new, it will return
     * an empty collection; or if this TValeurReferentiel has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TValeurReferentiel.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_valeur_referentiel = null;
        $this->code_libelle_valeur_referentiel = null;
        $this->id_referentiel = null;
        $this->id_organisation = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTCitoyensRelatedByIdRef1) {
                foreach ($this->collTCitoyensRelatedByIdRef1 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTCitoyensRelatedByIdRef2) {
                foreach ($this->collTCitoyensRelatedByIdRef2 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTCitoyensRelatedByIdRef3) {
                foreach ($this->collTCitoyensRelatedByIdRef3 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVouss) {
                foreach ($this->collTRendezVouss as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraduction instanceof Persistent) {
              $this->aTTraduction->clearAllReferences($deep);
            }
            if ($this->aTOrganisation instanceof Persistent) {
              $this->aTOrganisation->clearAllReferences($deep);
            }
            if ($this->aTReferentiel instanceof Persistent) {
              $this->aTReferentiel->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTCitoyensRelatedByIdRef1 instanceof PropelCollection) {
            $this->collTCitoyensRelatedByIdRef1->clearIterator();
        }
        $this->collTCitoyensRelatedByIdRef1 = null;
        if ($this->collTCitoyensRelatedByIdRef2 instanceof PropelCollection) {
            $this->collTCitoyensRelatedByIdRef2->clearIterator();
        }
        $this->collTCitoyensRelatedByIdRef2 = null;
        if ($this->collTCitoyensRelatedByIdRef3 instanceof PropelCollection) {
            $this->collTCitoyensRelatedByIdRef3->clearIterator();
        }
        $this->collTCitoyensRelatedByIdRef3 = null;
        if ($this->collTRendezVouss instanceof PropelCollection) {
            $this->collTRendezVouss->clearIterator();
        }
        $this->collTRendezVouss = null;
        $this->aTTraduction = null;
        $this->aTOrganisation = null;
        $this->aTReferentiel = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TValeurReferentielPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
