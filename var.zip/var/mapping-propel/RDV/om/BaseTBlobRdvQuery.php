<?php


/**
 * Base class that represents a query for the 'T_BLOB_RDV' table.
 *
 *
 *
 * @method TBlobRdvQuery orderByIdRendezVous($order = Criteria::ASC) Order by the ID_RENDEZ_VOUS column
 * @method TBlobRdvQuery orderByIdBlob($order = Criteria::ASC) Order by the ID_BLOB column
 *
 * @method TBlobRdvQuery groupByIdRendezVous() Group by the ID_RENDEZ_VOUS column
 * @method TBlobRdvQuery groupByIdBlob() Group by the ID_BLOB column
 *
 * @method TBlobRdvQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TBlobRdvQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TBlobRdvQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TBlobRdvQuery leftJoinTBlob($relationAlias = null) Adds a LEFT JOIN clause to the query using the TBlob relation
 * @method TBlobRdvQuery rightJoinTBlob($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TBlob relation
 * @method TBlobRdvQuery innerJoinTBlob($relationAlias = null) Adds a INNER JOIN clause to the query using the TBlob relation
 *
 * @method TBlobRdvQuery leftJoinTRendezVous($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRendezVous relation
 * @method TBlobRdvQuery rightJoinTRendezVous($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRendezVous relation
 * @method TBlobRdvQuery innerJoinTRendezVous($relationAlias = null) Adds a INNER JOIN clause to the query using the TRendezVous relation
 *
 * @method TBlobRdv findOne(PropelPDO $con = null) Return the first TBlobRdv matching the query
 * @method TBlobRdv findOneOrCreate(PropelPDO $con = null) Return the first TBlobRdv matching the query, or a new TBlobRdv object populated from the query conditions when no match is found
 *
 * @method TBlobRdv findOneByIdRendezVous(int $ID_RENDEZ_VOUS) Return the first TBlobRdv filtered by the ID_RENDEZ_VOUS column
 * @method TBlobRdv findOneByIdBlob(int $ID_BLOB) Return the first TBlobRdv filtered by the ID_BLOB column
 *
 * @method array findByIdRendezVous(int $ID_RENDEZ_VOUS) Return TBlobRdv objects filtered by the ID_RENDEZ_VOUS column
 * @method array findByIdBlob(int $ID_BLOB) Return TBlobRdv objects filtered by the ID_BLOB column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTBlobRdvQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTBlobRdvQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TBlobRdv', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TBlobRdvQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TBlobRdvQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TBlobRdvQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TBlobRdvQuery) {
            return $criteria;
        }
        $query = new TBlobRdvQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array $key Primary key to use for the query
                         A Primary key composition: [$ID_RENDEZ_VOUS, $ID_BLOB]
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TBlobRdv|TBlobRdv[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TBlobRdvPeer::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1]))))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TBlobRdvPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TBlobRdv A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_RENDEZ_VOUS`, `ID_BLOB` FROM `T_BLOB_RDV` WHERE `ID_RENDEZ_VOUS` = :p0 AND `ID_BLOB` = :p1';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_INT);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TBlobRdv();
            $obj->hydrate($row);
            TBlobRdvPeer::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TBlobRdv|TBlobRdv[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TBlobRdv[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TBlobRdvQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(TBlobRdvPeer::ID_RENDEZ_VOUS, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(TBlobRdvPeer::ID_BLOB, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TBlobRdvQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(TBlobRdvPeer::ID_RENDEZ_VOUS, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(TBlobRdvPeer::ID_BLOB, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the ID_RENDEZ_VOUS column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRendezVous(1234); // WHERE ID_RENDEZ_VOUS = 1234
     * $query->filterByIdRendezVous(array(12, 34)); // WHERE ID_RENDEZ_VOUS IN (12, 34)
     * $query->filterByIdRendezVous(array('min' => 12)); // WHERE ID_RENDEZ_VOUS >= 12
     * $query->filterByIdRendezVous(array('max' => 12)); // WHERE ID_RENDEZ_VOUS <= 12
     * </code>
     *
     * @see       filterByTRendezVous()
     *
     * @param     mixed $idRendezVous The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TBlobRdvQuery The current query, for fluid interface
     */
    public function filterByIdRendezVous($idRendezVous = null, $comparison = null)
    {
        if (is_array($idRendezVous)) {
            $useMinMax = false;
            if (isset($idRendezVous['min'])) {
                $this->addUsingAlias(TBlobRdvPeer::ID_RENDEZ_VOUS, $idRendezVous['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRendezVous['max'])) {
                $this->addUsingAlias(TBlobRdvPeer::ID_RENDEZ_VOUS, $idRendezVous['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TBlobRdvPeer::ID_RENDEZ_VOUS, $idRendezVous, $comparison);
    }

    /**
     * Filter the query on the ID_BLOB column
     *
     * Example usage:
     * <code>
     * $query->filterByIdBlob(1234); // WHERE ID_BLOB = 1234
     * $query->filterByIdBlob(array(12, 34)); // WHERE ID_BLOB IN (12, 34)
     * $query->filterByIdBlob(array('min' => 12)); // WHERE ID_BLOB >= 12
     * $query->filterByIdBlob(array('max' => 12)); // WHERE ID_BLOB <= 12
     * </code>
     *
     * @see       filterByTBlob()
     *
     * @param     mixed $idBlob The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TBlobRdvQuery The current query, for fluid interface
     */
    public function filterByIdBlob($idBlob = null, $comparison = null)
    {
        if (is_array($idBlob)) {
            $useMinMax = false;
            if (isset($idBlob['min'])) {
                $this->addUsingAlias(TBlobRdvPeer::ID_BLOB, $idBlob['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idBlob['max'])) {
                $this->addUsingAlias(TBlobRdvPeer::ID_BLOB, $idBlob['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TBlobRdvPeer::ID_BLOB, $idBlob, $comparison);
    }

    /**
     * Filter the query by a related TBlob object
     *
     * @param   TBlob|PropelObjectCollection $tBlob The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TBlobRdvQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTBlob($tBlob, $comparison = null)
    {
        if ($tBlob instanceof TBlob) {
            return $this
                ->addUsingAlias(TBlobRdvPeer::ID_BLOB, $tBlob->getIdBlob(), $comparison);
        } elseif ($tBlob instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TBlobRdvPeer::ID_BLOB, $tBlob->toKeyValue('PrimaryKey', 'IdBlob'), $comparison);
        } else {
            throw new PropelException('filterByTBlob() only accepts arguments of type TBlob or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TBlob relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TBlobRdvQuery The current query, for fluid interface
     */
    public function joinTBlob($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TBlob');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TBlob');
        }

        return $this;
    }

    /**
     * Use the TBlob relation TBlob object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TBlobQuery A secondary query class using the current class as primary query
     */
    public function useTBlobQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTBlob($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TBlob', 'TBlobQuery');
    }

    /**
     * Filter the query by a related TRendezVous object
     *
     * @param   TRendezVous|PropelObjectCollection $tRendezVous The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TBlobRdvQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRendezVous($tRendezVous, $comparison = null)
    {
        if ($tRendezVous instanceof TRendezVous) {
            return $this
                ->addUsingAlias(TBlobRdvPeer::ID_RENDEZ_VOUS, $tRendezVous->getIdRendezVous(), $comparison);
        } elseif ($tRendezVous instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TBlobRdvPeer::ID_RENDEZ_VOUS, $tRendezVous->toKeyValue('PrimaryKey', 'IdRendezVous'), $comparison);
        } else {
            throw new PropelException('filterByTRendezVous() only accepts arguments of type TRendezVous or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRendezVous relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TBlobRdvQuery The current query, for fluid interface
     */
    public function joinTRendezVous($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRendezVous');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRendezVous');
        }

        return $this;
    }

    /**
     * Use the TRendezVous relation TRendezVous object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRendezVousQuery A secondary query class using the current class as primary query
     */
    public function useTRendezVousQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRendezVous($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRendezVous', 'TRendezVousQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TBlobRdv $tBlobRdv Object to remove from the list of results
     *
     * @return TBlobRdvQuery The current query, for fluid interface
     */
    public function prune($tBlobRdv = null)
    {
        if ($tBlobRdv) {
            $this->addCond('pruneCond0', $this->getAliasedColName(TBlobRdvPeer::ID_RENDEZ_VOUS), $tBlobRdv->getIdRendezVous(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(TBlobRdvPeer::ID_BLOB), $tBlobRdv->getIdBlob(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

}
