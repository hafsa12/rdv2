<?php


/**
 * Base class that represents a row from the 'T_RENDEZ_VOUS' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTRendezVous extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TRendezVousPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TRendezVousPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_rendez_vous field.
     * @var        int
     */
    protected $id_rendez_vous;

    /**
     * The value for the date_creation field.
     * @var        string
     */
    protected $date_creation;

    /**
     * The value for the date_confirmation field.
     * @var        string
     */
    protected $date_confirmation;

    /**
     * The value for the date_annulation field.
     * @var        string
     */
    protected $date_annulation;

    /**
     * The value for the motif_annulation field.
     * @var        string
     */
    protected $motif_annulation;

    /**
     * The value for the date_rdv field.
     * @var        string
     */
    protected $date_rdv;

    /**
     * The value for the date_fin_rdv field.
     * @var        string
     */
    protected $date_fin_rdv;

    /**
     * The value for the code_rdv field.
     * @var        string
     */
    protected $code_rdv;

    /**
     * The value for the etat_rdv field.
     * @var        string
     */
    protected $etat_rdv;

    /**
     * The value for the mode_prise_rdv field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $mode_prise_rdv;

    /**
     * The value for the type_prise_rdv field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $type_prise_rdv;

    /**
     * The value for the id_citoyen field.
     * @var        int
     */
    protected $id_citoyen;

    /**
     * The value for the id_agent_accueil field.
     * @var        int
     */
    protected $id_agent_accueil;

    /**
     * The value for the id_etablissement field.
     * @var        int
     */
    protected $id_etablissement;

    /**
     * The value for the id_prestation field.
     * @var        int
     */
    protected $id_prestation;

    /**
     * The value for the id_agent_ressource field.
     * @var        int
     */
    protected $id_agent_ressource;

    /**
     * The value for the id_agent_teleoperateur field.
     * @var        int
     */
    protected $id_agent_teleoperateur;

    /**
     * The value for the id_agent_confirmation field.
     * @var        int
     */
    protected $id_agent_confirmation;

    /**
     * The value for the id_agent_annulation field.
     * @var        int
     */
    protected $id_agent_annulation;

    /**
     * The value for the id_referent field.
     * @var        int
     */
    protected $id_referent;

    /**
     * The value for the tag_gateway field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $tag_gateway;

    /**
     * The value for the id_utilisateur field.
     * @var        string
     */
    protected $id_utilisateur;

    /**
     * The value for the etat_acquittement field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $etat_acquittement;

    /**
     * The value for the date_acquittement field.
     * @var        string
     */
    protected $date_acquittement;

    /**
     * The value for the champ_supp_presta field.
     * @var        string
     */
    protected $champ_supp_presta;

    /**
     * The value for the id_chef_ressource field.
     * @var        int
     */
    protected $id_chef_ressource;

    /**
     * The value for the partage_recap field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $partage_recap;

    /**
     * The value for the nature_session field.
     * @var        string
     */
    protected $nature_session;

    /**
     * The value for the lieu_rdv field.
     * @var        string
     */
    protected $lieu_rdv;

    /**
     * The value for the lien_rdv field.
     * @var        string
     */
    protected $lien_rdv;

    /**
     * The value for the nombre_participant field.
     * @var        int
     */
    protected $nombre_participant;

    /**
     * The value for the commentaire field.
     * @var        string
     */
    protected $commentaire;

    /**
     * The value for the id_valeur_referentiel field.
     * @var        int
     */
    protected $id_valeur_referentiel;

    /**
     * @var        TCitoyen
     */
    protected $aTCitoyen;

    /**
     * @var        TAgent
     */
    protected $aTAgentRelatedByIdAgentAccueil;

    /**
     * @var        TAgent
     */
    protected $aTAgentRelatedByIdAgentAnnulation;

    /**
     * @var        TAgent
     */
    protected $aTAgentRelatedByIdAgentConfirmation;

    /**
     * @var        TAgent
     */
    protected $aTAgentRelatedByIdAgentRessource;

    /**
     * @var        TAgent
     */
    protected $aTAgentRelatedByIdAgentTeleoperateur;

    /**
     * @var        TValeurReferentiel
     */
    protected $aTValeurReferentiel;

    /**
     * @var        TEtablissement
     */
    protected $aTEtablissement;

    /**
     * @var        TPrestation
     */
    protected $aTPrestation;

    /**
     * @var        TReferent
     */
    protected $aTReferent;

    /**
     * @var        PropelObjectCollection|TBlobRdv[] Collection to store aggregation of TBlobRdv objects.
     */
    protected $collTBlobRdvs;
    protected $collTBlobRdvsPartial;

    /**
     * @var        PropelObjectCollection|TParticipant[] Collection to store aggregation of TParticipant objects.
     */
    protected $collTParticipants;
    protected $collTParticipantsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tBlobRdvsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParticipantsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->mode_prise_rdv = '0';
        $this->type_prise_rdv = '0';
        $this->tag_gateway = '0';
        $this->etat_acquittement = 0;
        $this->partage_recap = '0';
    }

    /**
     * Initializes internal state of BaseTRendezVous object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_rendez_vous] column value.
     *
     * @return int
     */
    public function getIdRendezVous()
    {
        return $this->id_rendez_vous;
    }

    /**
     * Get the [optionally formatted] temporal [date_creation] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateCreation($format = 'Y-m-d H:i:s')
    {
        if ($this->date_creation === null) {
            return null;
        }

        if ($this->date_creation === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_creation);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_creation, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_confirmation] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateConfirmation($format = '%x')
    {
        if ($this->date_confirmation === null) {
            return null;
        }

        if ($this->date_confirmation === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_confirmation);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_confirmation, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_annulation] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateAnnulation($format = '%x')
    {
        if ($this->date_annulation === null) {
            return null;
        }

        if ($this->date_annulation === '0000-00-00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_annulation);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_annulation, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [motif_annulation] column value.
     *
     * @return string
     */
    public function getMotifAnnulation()
    {
        return $this->motif_annulation;
    }

    /**
     * Get the [optionally formatted] temporal [date_rdv] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateRdv($format = 'Y-m-d H:i:s')
    {
        if ($this->date_rdv === null) {
            return null;
        }

        if ($this->date_rdv === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_rdv);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_rdv, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [optionally formatted] temporal [date_fin_rdv] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateFinRdv($format = 'Y-m-d H:i:s')
    {
        if ($this->date_fin_rdv === null) {
            return null;
        }

        if ($this->date_fin_rdv === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_fin_rdv);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_fin_rdv, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [code_rdv] column value.
     *
     * @return string
     */
    public function getCodeRdv()
    {
        return $this->code_rdv;
    }

    /**
     * Get the [etat_rdv] column value.
     *
     * @return string
     */
    public function getEtatRdv()
    {
        return $this->etat_rdv;
    }

    /**
     * Get the [mode_prise_rdv] column value.
     *
     * @return string
     */
    public function getModePriseRdv()
    {
        return $this->mode_prise_rdv;
    }

    /**
     * Get the [type_prise_rdv] column value.
     *
     * @return string
     */
    public function getTypePriseRdv()
    {
        return $this->type_prise_rdv;
    }

    /**
     * Get the [id_citoyen] column value.
     *
     * @return int
     */
    public function getIdCitoyen()
    {
        return $this->id_citoyen;
    }

    /**
     * Get the [id_agent_accueil] column value.
     *
     * @return int
     */
    public function getIdAgentAccueil()
    {
        return $this->id_agent_accueil;
    }

    /**
     * Get the [id_etablissement] column value.
     *
     * @return int
     */
    public function getIdEtablissement()
    {
        return $this->id_etablissement;
    }

    /**
     * Get the [id_prestation] column value.
     *
     * @return int
     */
    public function getIdPrestation()
    {
        return $this->id_prestation;
    }

    /**
     * Get the [id_agent_ressource] column value.
     *
     * @return int
     */
    public function getIdAgentRessource()
    {
        return $this->id_agent_ressource;
    }

    /**
     * Get the [id_agent_teleoperateur] column value.
     *
     * @return int
     */
    public function getIdAgentTeleoperateur()
    {
        return $this->id_agent_teleoperateur;
    }

    /**
     * Get the [id_agent_confirmation] column value.
     *
     * @return int
     */
    public function getIdAgentConfirmation()
    {
        return $this->id_agent_confirmation;
    }

    /**
     * Get the [id_agent_annulation] column value.
     *
     * @return int
     */
    public function getIdAgentAnnulation()
    {
        return $this->id_agent_annulation;
    }

    /**
     * Get the [id_referent] column value.
     *
     * @return int
     */
    public function getIdReferent()
    {
        return $this->id_referent;
    }

    /**
     * Get the [tag_gateway] column value.
     *
     * @return string
     */
    public function getTagGateway()
    {
        return $this->tag_gateway;
    }

    /**
     * Get the [id_utilisateur] column value.
     *
     * @return string
     */
    public function getIdUtilisateur()
    {
        return $this->id_utilisateur;
    }

    /**
     * Get the [etat_acquittement] column value.
     *
     * @return int
     */
    public function getEtatAcquittement()
    {
        return $this->etat_acquittement;
    }

    /**
     * Get the [optionally formatted] temporal [date_acquittement] column value.
     *
     *
     * @param string $format The date/time format string (either date()-style or strftime()-style).
     *				 If format is null, then the raw DateTime object will be returned.
     * @return mixed Formatted date/time value as string or DateTime object (if format is null), null if column is null, and 0 if column value is 0000-00-00 00:00:00
     * @throws PropelException - if unable to parse/validate the date/time value.
     */
    public function getDateAcquittement($format = 'Y-m-d H:i:s')
    {
        if ($this->date_acquittement === null) {
            return null;
        }

        if ($this->date_acquittement === '0000-00-00 00:00:00') {
            // while technically this is not a default value of null,
            // this seems to be closest in meaning.
            return null;
        }

        try {
            $dt = new DateTime($this->date_acquittement);
        } catch (Exception $x) {
            throw new PropelException("Internally stored date/time/timestamp value could not be converted to DateTime: " . var_export($this->date_acquittement, true), $x);
        }

        if ($format === null) {
            // Because propel.useDateTimeClass is true, we return a DateTime object.
            return $dt;
        }

        if (strpos($format, '%') !== false) {
            return strftime($format, $dt->format('U'));
        }

        return $dt->format($format);

    }

    /**
     * Get the [champ_supp_presta] column value.
     *
     * @return string
     */
    public function getChampSuppPresta()
    {
        return $this->champ_supp_presta;
    }

    /**
     * Get the [id_chef_ressource] column value.
     *
     * @return int
     */
    public function getIdChefRessource()
    {
        return $this->id_chef_ressource;
    }

    /**
     * Get the [partage_recap] column value.
     *
     * @return string
     */
    public function getPartageRecap()
    {
        return $this->partage_recap;
    }

    /**
     * Get the [nature_session] column value.
     *
     * @return string
     */
    public function getNatureSession()
    {
        return $this->nature_session;
    }

    /**
     * Get the [lieu_rdv] column value.
     *
     * @return string
     */
    public function getLieuRdv()
    {
        return $this->lieu_rdv;
    }

    /**
     * Get the [lien_rdv] column value.
     *
     * @return string
     */
    public function getLienRdv()
    {
        return $this->lien_rdv;
    }

    /**
     * Get the [nombre_participant] column value.
     *
     * @return int
     */
    public function getNombreParticipant()
    {
        return $this->nombre_participant;
    }

    /**
     * Get the [commentaire] column value.
     *
     * @return string
     */
    public function getCommentaire()
    {
        return $this->commentaire;
    }

    /**
     * Get the [id_valeur_referentiel] column value.
     *
     * @return int
     */
    public function getIdValeurReferentiel()
    {
        return $this->id_valeur_referentiel;
    }

    /**
     * Set the value of [id_rendez_vous] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdRendezVous($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_rendez_vous !== $v) {
            $this->id_rendez_vous = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_RENDEZ_VOUS;
        }


        return $this;
    } // setIdRendezVous()

    /**
     * Sets the value of [date_creation] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setDateCreation($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_creation !== null || $dt !== null) {
            $currentDateAsString = ($this->date_creation !== null && $tmpDt = new DateTime($this->date_creation)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_creation = $newDateAsString;
                $this->modifiedColumns[] = TRendezVousPeer::DATE_CREATION;
            }
        } // if either are not null


        return $this;
    } // setDateCreation()

    /**
     * Sets the value of [date_confirmation] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setDateConfirmation($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_confirmation !== null || $dt !== null) {
            $currentDateAsString = ($this->date_confirmation !== null && $tmpDt = new DateTime($this->date_confirmation)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_confirmation = $newDateAsString;
                $this->modifiedColumns[] = TRendezVousPeer::DATE_CONFIRMATION;
            }
        } // if either are not null


        return $this;
    } // setDateConfirmation()

    /**
     * Sets the value of [date_annulation] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setDateAnnulation($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_annulation !== null || $dt !== null) {
            $currentDateAsString = ($this->date_annulation !== null && $tmpDt = new DateTime($this->date_annulation)) ? $tmpDt->format('Y-m-d') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_annulation = $newDateAsString;
                $this->modifiedColumns[] = TRendezVousPeer::DATE_ANNULATION;
            }
        } // if either are not null


        return $this;
    } // setDateAnnulation()

    /**
     * Set the value of [motif_annulation] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setMotifAnnulation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->motif_annulation !== $v) {
            $this->motif_annulation = $v;
            $this->modifiedColumns[] = TRendezVousPeer::MOTIF_ANNULATION;
        }


        return $this;
    } // setMotifAnnulation()

    /**
     * Sets the value of [date_rdv] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setDateRdv($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_rdv !== null || $dt !== null) {
            $currentDateAsString = ($this->date_rdv !== null && $tmpDt = new DateTime($this->date_rdv)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_rdv = $newDateAsString;
                $this->modifiedColumns[] = TRendezVousPeer::DATE_RDV;
            }
        } // if either are not null


        return $this;
    } // setDateRdv()

    /**
     * Sets the value of [date_fin_rdv] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setDateFinRdv($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_fin_rdv !== null || $dt !== null) {
            $currentDateAsString = ($this->date_fin_rdv !== null && $tmpDt = new DateTime($this->date_fin_rdv)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_fin_rdv = $newDateAsString;
                $this->modifiedColumns[] = TRendezVousPeer::DATE_FIN_RDV;
            }
        } // if either are not null


        return $this;
    } // setDateFinRdv()

    /**
     * Set the value of [code_rdv] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setCodeRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->code_rdv !== $v) {
            $this->code_rdv = $v;
            $this->modifiedColumns[] = TRendezVousPeer::CODE_RDV;
        }


        return $this;
    } // setCodeRdv()

    /**
     * Set the value of [etat_rdv] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setEtatRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->etat_rdv !== $v) {
            $this->etat_rdv = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ETAT_RDV;
        }


        return $this;
    } // setEtatRdv()

    /**
     * Set the value of [mode_prise_rdv] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setModePriseRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->mode_prise_rdv !== $v) {
            $this->mode_prise_rdv = $v;
            $this->modifiedColumns[] = TRendezVousPeer::MODE_PRISE_RDV;
        }


        return $this;
    } // setModePriseRdv()

    /**
     * Set the value of [type_prise_rdv] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setTypePriseRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->type_prise_rdv !== $v) {
            $this->type_prise_rdv = $v;
            $this->modifiedColumns[] = TRendezVousPeer::TYPE_PRISE_RDV;
        }


        return $this;
    } // setTypePriseRdv()

    /**
     * Set the value of [id_citoyen] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdCitoyen($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_citoyen !== $v) {
            $this->id_citoyen = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_CITOYEN;
        }

        if ($this->aTCitoyen !== null && $this->aTCitoyen->getIdCitoyen() !== $v) {
            $this->aTCitoyen = null;
        }


        return $this;
    } // setIdCitoyen()

    /**
     * Set the value of [id_agent_accueil] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdAgentAccueil($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_agent_accueil !== $v) {
            $this->id_agent_accueil = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_AGENT_ACCUEIL;
        }

        if ($this->aTAgentRelatedByIdAgentAccueil !== null && $this->aTAgentRelatedByIdAgentAccueil->getIdAgent() !== $v) {
            $this->aTAgentRelatedByIdAgentAccueil = null;
        }


        return $this;
    } // setIdAgentAccueil()

    /**
     * Set the value of [id_etablissement] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_etablissement !== $v) {
            $this->id_etablissement = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_ETABLISSEMENT;
        }

        if ($this->aTEtablissement !== null && $this->aTEtablissement->getIdEtablissement() !== $v) {
            $this->aTEtablissement = null;
        }


        return $this;
    } // setIdEtablissement()

    /**
     * Set the value of [id_prestation] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdPrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_prestation !== $v) {
            $this->id_prestation = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_PRESTATION;
        }

        if ($this->aTPrestation !== null && $this->aTPrestation->getIdPrestation() !== $v) {
            $this->aTPrestation = null;
        }


        return $this;
    } // setIdPrestation()

    /**
     * Set the value of [id_agent_ressource] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdAgentRessource($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_agent_ressource !== $v) {
            $this->id_agent_ressource = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_AGENT_RESSOURCE;
        }

        if ($this->aTAgentRelatedByIdAgentRessource !== null && $this->aTAgentRelatedByIdAgentRessource->getIdAgent() !== $v) {
            $this->aTAgentRelatedByIdAgentRessource = null;
        }


        return $this;
    } // setIdAgentRessource()

    /**
     * Set the value of [id_agent_teleoperateur] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdAgentTeleoperateur($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_agent_teleoperateur !== $v) {
            $this->id_agent_teleoperateur = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_AGENT_TELEOPERATEUR;
        }

        if ($this->aTAgentRelatedByIdAgentTeleoperateur !== null && $this->aTAgentRelatedByIdAgentTeleoperateur->getIdAgent() !== $v) {
            $this->aTAgentRelatedByIdAgentTeleoperateur = null;
        }


        return $this;
    } // setIdAgentTeleoperateur()

    /**
     * Set the value of [id_agent_confirmation] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdAgentConfirmation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_agent_confirmation !== $v) {
            $this->id_agent_confirmation = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_AGENT_CONFIRMATION;
        }

        if ($this->aTAgentRelatedByIdAgentConfirmation !== null && $this->aTAgentRelatedByIdAgentConfirmation->getIdAgent() !== $v) {
            $this->aTAgentRelatedByIdAgentConfirmation = null;
        }


        return $this;
    } // setIdAgentConfirmation()

    /**
     * Set the value of [id_agent_annulation] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdAgentAnnulation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_agent_annulation !== $v) {
            $this->id_agent_annulation = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_AGENT_ANNULATION;
        }

        if ($this->aTAgentRelatedByIdAgentAnnulation !== null && $this->aTAgentRelatedByIdAgentAnnulation->getIdAgent() !== $v) {
            $this->aTAgentRelatedByIdAgentAnnulation = null;
        }


        return $this;
    } // setIdAgentAnnulation()

    /**
     * Set the value of [id_referent] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdReferent($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_referent !== $v) {
            $this->id_referent = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_REFERENT;
        }

        if ($this->aTReferent !== null && $this->aTReferent->getIdReferent() !== $v) {
            $this->aTReferent = null;
        }


        return $this;
    } // setIdReferent()

    /**
     * Set the value of [tag_gateway] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setTagGateway($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->tag_gateway !== $v) {
            $this->tag_gateway = $v;
            $this->modifiedColumns[] = TRendezVousPeer::TAG_GATEWAY;
        }


        return $this;
    } // setTagGateway()

    /**
     * Set the value of [id_utilisateur] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdUtilisateur($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->id_utilisateur !== $v) {
            $this->id_utilisateur = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_UTILISATEUR;
        }


        return $this;
    } // setIdUtilisateur()

    /**
     * Set the value of [etat_acquittement] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setEtatAcquittement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->etat_acquittement !== $v) {
            $this->etat_acquittement = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ETAT_ACQUITTEMENT;
        }


        return $this;
    } // setEtatAcquittement()

    /**
     * Sets the value of [date_acquittement] column to a normalized version of the date/time value specified.
     *
     * @param mixed $v string, integer (timestamp), or DateTime value.
     *               Empty strings are treated as null.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setDateAcquittement($v)
    {
        $dt = PropelDateTime::newInstance($v, null, 'DateTime');
        if ($this->date_acquittement !== null || $dt !== null) {
            $currentDateAsString = ($this->date_acquittement !== null && $tmpDt = new DateTime($this->date_acquittement)) ? $tmpDt->format('Y-m-d H:i:s') : null;
            $newDateAsString = $dt ? $dt->format('Y-m-d H:i:s') : null;
            if ($currentDateAsString !== $newDateAsString) {
                $this->date_acquittement = $newDateAsString;
                $this->modifiedColumns[] = TRendezVousPeer::DATE_ACQUITTEMENT;
            }
        } // if either are not null


        return $this;
    } // setDateAcquittement()

    /**
     * Set the value of [champ_supp_presta] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setChampSuppPresta($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->champ_supp_presta !== $v) {
            $this->champ_supp_presta = $v;
            $this->modifiedColumns[] = TRendezVousPeer::CHAMP_SUPP_PRESTA;
        }


        return $this;
    } // setChampSuppPresta()

    /**
     * Set the value of [id_chef_ressource] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdChefRessource($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_chef_ressource !== $v) {
            $this->id_chef_ressource = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_CHEF_RESSOURCE;
        }


        return $this;
    } // setIdChefRessource()

    /**
     * Set the value of [partage_recap] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setPartageRecap($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->partage_recap !== $v) {
            $this->partage_recap = $v;
            $this->modifiedColumns[] = TRendezVousPeer::PARTAGE_RECAP;
        }


        return $this;
    } // setPartageRecap()

    /**
     * Set the value of [nature_session] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setNatureSession($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->nature_session !== $v) {
            $this->nature_session = $v;
            $this->modifiedColumns[] = TRendezVousPeer::NATURE_SESSION;
        }


        return $this;
    } // setNatureSession()

    /**
     * Set the value of [lieu_rdv] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setLieuRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->lieu_rdv !== $v) {
            $this->lieu_rdv = $v;
            $this->modifiedColumns[] = TRendezVousPeer::LIEU_RDV;
        }


        return $this;
    } // setLieuRdv()

    /**
     * Set the value of [lien_rdv] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setLienRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->lien_rdv !== $v) {
            $this->lien_rdv = $v;
            $this->modifiedColumns[] = TRendezVousPeer::LIEN_RDV;
        }


        return $this;
    } // setLienRdv()

    /**
     * Set the value of [nombre_participant] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setNombreParticipant($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->nombre_participant !== $v) {
            $this->nombre_participant = $v;
            $this->modifiedColumns[] = TRendezVousPeer::NOMBRE_PARTICIPANT;
        }


        return $this;
    } // setNombreParticipant()

    /**
     * Set the value of [commentaire] column.
     *
     * @param string $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setCommentaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->commentaire !== $v) {
            $this->commentaire = $v;
            $this->modifiedColumns[] = TRendezVousPeer::COMMENTAIRE;
        }


        return $this;
    } // setCommentaire()

    /**
     * Set the value of [id_valeur_referentiel] column.
     *
     * @param int $v new value
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setIdValeurReferentiel($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_valeur_referentiel !== $v) {
            $this->id_valeur_referentiel = $v;
            $this->modifiedColumns[] = TRendezVousPeer::ID_VALEUR_REFERENTIEL;
        }

        if ($this->aTValeurReferentiel !== null && $this->aTValeurReferentiel->getIdValeurReferentiel() !== $v) {
            $this->aTValeurReferentiel = null;
        }


        return $this;
    } // setIdValeurReferentiel()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->mode_prise_rdv !== '0') {
                return false;
            }

            if ($this->type_prise_rdv !== '0') {
                return false;
            }

            if ($this->tag_gateway !== '0') {
                return false;
            }

            if ($this->etat_acquittement !== 0) {
                return false;
            }

            if ($this->partage_recap !== '0') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_rendez_vous = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->date_creation = ($row[$startcol + 1] !== null) ? (string) $row[$startcol + 1] : null;
            $this->date_confirmation = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->date_annulation = ($row[$startcol + 3] !== null) ? (string) $row[$startcol + 3] : null;
            $this->motif_annulation = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->date_rdv = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->date_fin_rdv = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->code_rdv = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->etat_rdv = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->mode_prise_rdv = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->type_prise_rdv = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->id_citoyen = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->id_agent_accueil = ($row[$startcol + 12] !== null) ? (int) $row[$startcol + 12] : null;
            $this->id_etablissement = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->id_prestation = ($row[$startcol + 14] !== null) ? (int) $row[$startcol + 14] : null;
            $this->id_agent_ressource = ($row[$startcol + 15] !== null) ? (int) $row[$startcol + 15] : null;
            $this->id_agent_teleoperateur = ($row[$startcol + 16] !== null) ? (int) $row[$startcol + 16] : null;
            $this->id_agent_confirmation = ($row[$startcol + 17] !== null) ? (int) $row[$startcol + 17] : null;
            $this->id_agent_annulation = ($row[$startcol + 18] !== null) ? (int) $row[$startcol + 18] : null;
            $this->id_referent = ($row[$startcol + 19] !== null) ? (int) $row[$startcol + 19] : null;
            $this->tag_gateway = ($row[$startcol + 20] !== null) ? (string) $row[$startcol + 20] : null;
            $this->id_utilisateur = ($row[$startcol + 21] !== null) ? (string) $row[$startcol + 21] : null;
            $this->etat_acquittement = ($row[$startcol + 22] !== null) ? (int) $row[$startcol + 22] : null;
            $this->date_acquittement = ($row[$startcol + 23] !== null) ? (string) $row[$startcol + 23] : null;
            $this->champ_supp_presta = ($row[$startcol + 24] !== null) ? (string) $row[$startcol + 24] : null;
            $this->id_chef_ressource = ($row[$startcol + 25] !== null) ? (int) $row[$startcol + 25] : null;
            $this->partage_recap = ($row[$startcol + 26] !== null) ? (string) $row[$startcol + 26] : null;
            $this->nature_session = ($row[$startcol + 27] !== null) ? (string) $row[$startcol + 27] : null;
            $this->lieu_rdv = ($row[$startcol + 28] !== null) ? (string) $row[$startcol + 28] : null;
            $this->lien_rdv = ($row[$startcol + 29] !== null) ? (string) $row[$startcol + 29] : null;
            $this->nombre_participant = ($row[$startcol + 30] !== null) ? (int) $row[$startcol + 30] : null;
            $this->commentaire = ($row[$startcol + 31] !== null) ? (string) $row[$startcol + 31] : null;
            $this->id_valeur_referentiel = ($row[$startcol + 32] !== null) ? (int) $row[$startcol + 32] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 33; // 33 = TRendezVousPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TRendezVous object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTCitoyen !== null && $this->id_citoyen !== $this->aTCitoyen->getIdCitoyen()) {
            $this->aTCitoyen = null;
        }
        if ($this->aTAgentRelatedByIdAgentAccueil !== null && $this->id_agent_accueil !== $this->aTAgentRelatedByIdAgentAccueil->getIdAgent()) {
            $this->aTAgentRelatedByIdAgentAccueil = null;
        }
        if ($this->aTEtablissement !== null && $this->id_etablissement !== $this->aTEtablissement->getIdEtablissement()) {
            $this->aTEtablissement = null;
        }
        if ($this->aTPrestation !== null && $this->id_prestation !== $this->aTPrestation->getIdPrestation()) {
            $this->aTPrestation = null;
        }
        if ($this->aTAgentRelatedByIdAgentRessource !== null && $this->id_agent_ressource !== $this->aTAgentRelatedByIdAgentRessource->getIdAgent()) {
            $this->aTAgentRelatedByIdAgentRessource = null;
        }
        if ($this->aTAgentRelatedByIdAgentTeleoperateur !== null && $this->id_agent_teleoperateur !== $this->aTAgentRelatedByIdAgentTeleoperateur->getIdAgent()) {
            $this->aTAgentRelatedByIdAgentTeleoperateur = null;
        }
        if ($this->aTAgentRelatedByIdAgentConfirmation !== null && $this->id_agent_confirmation !== $this->aTAgentRelatedByIdAgentConfirmation->getIdAgent()) {
            $this->aTAgentRelatedByIdAgentConfirmation = null;
        }
        if ($this->aTAgentRelatedByIdAgentAnnulation !== null && $this->id_agent_annulation !== $this->aTAgentRelatedByIdAgentAnnulation->getIdAgent()) {
            $this->aTAgentRelatedByIdAgentAnnulation = null;
        }
        if ($this->aTReferent !== null && $this->id_referent !== $this->aTReferent->getIdReferent()) {
            $this->aTReferent = null;
        }
        if ($this->aTValeurReferentiel !== null && $this->id_valeur_referentiel !== $this->aTValeurReferentiel->getIdValeurReferentiel()) {
            $this->aTValeurReferentiel = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TRendezVousPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTCitoyen = null;
            $this->aTAgentRelatedByIdAgentAccueil = null;
            $this->aTAgentRelatedByIdAgentAnnulation = null;
            $this->aTAgentRelatedByIdAgentConfirmation = null;
            $this->aTAgentRelatedByIdAgentRessource = null;
            $this->aTAgentRelatedByIdAgentTeleoperateur = null;
            $this->aTValeurReferentiel = null;
            $this->aTEtablissement = null;
            $this->aTPrestation = null;
            $this->aTReferent = null;
            $this->collTBlobRdvs = null;

            $this->collTParticipants = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TRendezVousQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TRendezVousPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TRendezVousPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTCitoyen !== null) {
                if ($this->aTCitoyen->isModified() || $this->aTCitoyen->isNew()) {
                    $affectedRows += $this->aTCitoyen->save($con);
                }
                $this->setTCitoyen($this->aTCitoyen);
            }

            if ($this->aTAgentRelatedByIdAgentAccueil !== null) {
                if ($this->aTAgentRelatedByIdAgentAccueil->isModified() || $this->aTAgentRelatedByIdAgentAccueil->isNew()) {
                    $affectedRows += $this->aTAgentRelatedByIdAgentAccueil->save($con);
                }
                $this->setTAgentRelatedByIdAgentAccueil($this->aTAgentRelatedByIdAgentAccueil);
            }

            if ($this->aTAgentRelatedByIdAgentAnnulation !== null) {
                if ($this->aTAgentRelatedByIdAgentAnnulation->isModified() || $this->aTAgentRelatedByIdAgentAnnulation->isNew()) {
                    $affectedRows += $this->aTAgentRelatedByIdAgentAnnulation->save($con);
                }
                $this->setTAgentRelatedByIdAgentAnnulation($this->aTAgentRelatedByIdAgentAnnulation);
            }

            if ($this->aTAgentRelatedByIdAgentConfirmation !== null) {
                if ($this->aTAgentRelatedByIdAgentConfirmation->isModified() || $this->aTAgentRelatedByIdAgentConfirmation->isNew()) {
                    $affectedRows += $this->aTAgentRelatedByIdAgentConfirmation->save($con);
                }
                $this->setTAgentRelatedByIdAgentConfirmation($this->aTAgentRelatedByIdAgentConfirmation);
            }

            if ($this->aTAgentRelatedByIdAgentRessource !== null) {
                if ($this->aTAgentRelatedByIdAgentRessource->isModified() || $this->aTAgentRelatedByIdAgentRessource->isNew()) {
                    $affectedRows += $this->aTAgentRelatedByIdAgentRessource->save($con);
                }
                $this->setTAgentRelatedByIdAgentRessource($this->aTAgentRelatedByIdAgentRessource);
            }

            if ($this->aTAgentRelatedByIdAgentTeleoperateur !== null) {
                if ($this->aTAgentRelatedByIdAgentTeleoperateur->isModified() || $this->aTAgentRelatedByIdAgentTeleoperateur->isNew()) {
                    $affectedRows += $this->aTAgentRelatedByIdAgentTeleoperateur->save($con);
                }
                $this->setTAgentRelatedByIdAgentTeleoperateur($this->aTAgentRelatedByIdAgentTeleoperateur);
            }

            if ($this->aTValeurReferentiel !== null) {
                if ($this->aTValeurReferentiel->isModified() || $this->aTValeurReferentiel->isNew()) {
                    $affectedRows += $this->aTValeurReferentiel->save($con);
                }
                $this->setTValeurReferentiel($this->aTValeurReferentiel);
            }

            if ($this->aTEtablissement !== null) {
                if ($this->aTEtablissement->isModified() || $this->aTEtablissement->isNew()) {
                    $affectedRows += $this->aTEtablissement->save($con);
                }
                $this->setTEtablissement($this->aTEtablissement);
            }

            if ($this->aTPrestation !== null) {
                if ($this->aTPrestation->isModified() || $this->aTPrestation->isNew()) {
                    $affectedRows += $this->aTPrestation->save($con);
                }
                $this->setTPrestation($this->aTPrestation);
            }

            if ($this->aTReferent !== null) {
                if ($this->aTReferent->isModified() || $this->aTReferent->isNew()) {
                    $affectedRows += $this->aTReferent->save($con);
                }
                $this->setTReferent($this->aTReferent);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tBlobRdvsScheduledForDeletion !== null) {
                if (!$this->tBlobRdvsScheduledForDeletion->isEmpty()) {
                    TBlobRdvQuery::create()
                        ->filterByPrimaryKeys($this->tBlobRdvsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tBlobRdvsScheduledForDeletion = null;
                }
            }

            if ($this->collTBlobRdvs !== null) {
                foreach ($this->collTBlobRdvs as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParticipantsScheduledForDeletion !== null) {
                if (!$this->tParticipantsScheduledForDeletion->isEmpty()) {
                    TParticipantQuery::create()
                        ->filterByPrimaryKeys($this->tParticipantsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tParticipantsScheduledForDeletion = null;
                }
            }

            if ($this->collTParticipants !== null) {
                foreach ($this->collTParticipants as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TRendezVousPeer::ID_RENDEZ_VOUS;
        if (null !== $this->id_rendez_vous) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TRendezVousPeer::ID_RENDEZ_VOUS . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TRendezVousPeer::ID_RENDEZ_VOUS)) {
            $modifiedColumns[':p' . $index++]  = '`ID_RENDEZ_VOUS`';
        }
        if ($this->isColumnModified(TRendezVousPeer::DATE_CREATION)) {
            $modifiedColumns[':p' . $index++]  = '`DATE_CREATION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::DATE_CONFIRMATION)) {
            $modifiedColumns[':p' . $index++]  = '`DATE_CONFIRMATION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::DATE_ANNULATION)) {
            $modifiedColumns[':p' . $index++]  = '`DATE_ANNULATION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::MOTIF_ANNULATION)) {
            $modifiedColumns[':p' . $index++]  = '`MOTIF_ANNULATION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::DATE_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`DATE_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::DATE_FIN_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`DATE_FIN_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::CODE_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ETAT_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`ETAT_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::MODE_PRISE_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`MODE_PRISE_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::TYPE_PRISE_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`TYPE_PRISE_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_CITOYEN)) {
            $modifiedColumns[':p' . $index++]  = '`ID_CITOYEN`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_ACCUEIL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_AGENT_ACCUEIL`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PRESTATION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_RESSOURCE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_AGENT_RESSOURCE`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_TELEOPERATEUR)) {
            $modifiedColumns[':p' . $index++]  = '`ID_AGENT_TELEOPERATEUR`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_CONFIRMATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_AGENT_CONFIRMATION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_ANNULATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_AGENT_ANNULATION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_REFERENT)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REFERENT`';
        }
        if ($this->isColumnModified(TRendezVousPeer::TAG_GATEWAY)) {
            $modifiedColumns[':p' . $index++]  = '`TAG_GATEWAY`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_UTILISATEUR)) {
            $modifiedColumns[':p' . $index++]  = '`ID_UTILISATEUR`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ETAT_ACQUITTEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`ETAT_ACQUITTEMENT`';
        }
        if ($this->isColumnModified(TRendezVousPeer::DATE_ACQUITTEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`DATE_ACQUITTEMENT`';
        }
        if ($this->isColumnModified(TRendezVousPeer::CHAMP_SUPP_PRESTA)) {
            $modifiedColumns[':p' . $index++]  = '`CHAMP_SUPP_PRESTA`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_CHEF_RESSOURCE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_CHEF_RESSOURCE`';
        }
        if ($this->isColumnModified(TRendezVousPeer::PARTAGE_RECAP)) {
            $modifiedColumns[':p' . $index++]  = '`PARTAGE_RECAP`';
        }
        if ($this->isColumnModified(TRendezVousPeer::NATURE_SESSION)) {
            $modifiedColumns[':p' . $index++]  = '`NATURE_SESSION`';
        }
        if ($this->isColumnModified(TRendezVousPeer::LIEU_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`LIEU_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::LIEN_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`LIEN_RDV`';
        }
        if ($this->isColumnModified(TRendezVousPeer::NOMBRE_PARTICIPANT)) {
            $modifiedColumns[':p' . $index++]  = '`NOMBRE_PARTICIPANT`';
        }
        if ($this->isColumnModified(TRendezVousPeer::COMMENTAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`COMMENTAIRE`';
        }
        if ($this->isColumnModified(TRendezVousPeer::ID_VALEUR_REFERENTIEL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_VALEUR_REFERENTIEL`';
        }

        $sql = sprintf(
            'INSERT INTO `T_RENDEZ_VOUS` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_RENDEZ_VOUS`':
                        $stmt->bindValue($identifier, $this->id_rendez_vous, PDO::PARAM_INT);
                        break;
                    case '`DATE_CREATION`':
                        $stmt->bindValue($identifier, $this->date_creation, PDO::PARAM_STR);
                        break;
                    case '`DATE_CONFIRMATION`':
                        $stmt->bindValue($identifier, $this->date_confirmation, PDO::PARAM_STR);
                        break;
                    case '`DATE_ANNULATION`':
                        $stmt->bindValue($identifier, $this->date_annulation, PDO::PARAM_STR);
                        break;
                    case '`MOTIF_ANNULATION`':
                        $stmt->bindValue($identifier, $this->motif_annulation, PDO::PARAM_STR);
                        break;
                    case '`DATE_RDV`':
                        $stmt->bindValue($identifier, $this->date_rdv, PDO::PARAM_STR);
                        break;
                    case '`DATE_FIN_RDV`':
                        $stmt->bindValue($identifier, $this->date_fin_rdv, PDO::PARAM_STR);
                        break;
                    case '`CODE_RDV`':
                        $stmt->bindValue($identifier, $this->code_rdv, PDO::PARAM_STR);
                        break;
                    case '`ETAT_RDV`':
                        $stmt->bindValue($identifier, $this->etat_rdv, PDO::PARAM_STR);
                        break;
                    case '`MODE_PRISE_RDV`':
                        $stmt->bindValue($identifier, $this->mode_prise_rdv, PDO::PARAM_STR);
                        break;
                    case '`TYPE_PRISE_RDV`':
                        $stmt->bindValue($identifier, $this->type_prise_rdv, PDO::PARAM_STR);
                        break;
                    case '`ID_CITOYEN`':
                        $stmt->bindValue($identifier, $this->id_citoyen, PDO::PARAM_INT);
                        break;
                    case '`ID_AGENT_ACCUEIL`':
                        $stmt->bindValue($identifier, $this->id_agent_accueil, PDO::PARAM_INT);
                        break;
                    case '`ID_ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->id_etablissement, PDO::PARAM_INT);
                        break;
                    case '`ID_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_prestation, PDO::PARAM_INT);
                        break;
                    case '`ID_AGENT_RESSOURCE`':
                        $stmt->bindValue($identifier, $this->id_agent_ressource, PDO::PARAM_INT);
                        break;
                    case '`ID_AGENT_TELEOPERATEUR`':
                        $stmt->bindValue($identifier, $this->id_agent_teleoperateur, PDO::PARAM_INT);
                        break;
                    case '`ID_AGENT_CONFIRMATION`':
                        $stmt->bindValue($identifier, $this->id_agent_confirmation, PDO::PARAM_INT);
                        break;
                    case '`ID_AGENT_ANNULATION`':
                        $stmt->bindValue($identifier, $this->id_agent_annulation, PDO::PARAM_INT);
                        break;
                    case '`ID_REFERENT`':
                        $stmt->bindValue($identifier, $this->id_referent, PDO::PARAM_INT);
                        break;
                    case '`TAG_GATEWAY`':
                        $stmt->bindValue($identifier, $this->tag_gateway, PDO::PARAM_STR);
                        break;
                    case '`ID_UTILISATEUR`':
                        $stmt->bindValue($identifier, $this->id_utilisateur, PDO::PARAM_STR);
                        break;
                    case '`ETAT_ACQUITTEMENT`':
                        $stmt->bindValue($identifier, $this->etat_acquittement, PDO::PARAM_INT);
                        break;
                    case '`DATE_ACQUITTEMENT`':
                        $stmt->bindValue($identifier, $this->date_acquittement, PDO::PARAM_STR);
                        break;
                    case '`CHAMP_SUPP_PRESTA`':
                        $stmt->bindValue($identifier, $this->champ_supp_presta, PDO::PARAM_STR);
                        break;
                    case '`ID_CHEF_RESSOURCE`':
                        $stmt->bindValue($identifier, $this->id_chef_ressource, PDO::PARAM_INT);
                        break;
                    case '`PARTAGE_RECAP`':
                        $stmt->bindValue($identifier, $this->partage_recap, PDO::PARAM_STR);
                        break;
                    case '`NATURE_SESSION`':
                        $stmt->bindValue($identifier, $this->nature_session, PDO::PARAM_STR);
                        break;
                    case '`LIEU_RDV`':
                        $stmt->bindValue($identifier, $this->lieu_rdv, PDO::PARAM_STR);
                        break;
                    case '`LIEN_RDV`':
                        $stmt->bindValue($identifier, $this->lien_rdv, PDO::PARAM_STR);
                        break;
                    case '`NOMBRE_PARTICIPANT`':
                        $stmt->bindValue($identifier, $this->nombre_participant, PDO::PARAM_INT);
                        break;
                    case '`COMMENTAIRE`':
                        $stmt->bindValue($identifier, $this->commentaire, PDO::PARAM_STR);
                        break;
                    case '`ID_VALEUR_REFERENTIEL`':
                        $stmt->bindValue($identifier, $this->id_valeur_referentiel, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdRendezVous($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTCitoyen !== null) {
                if (!$this->aTCitoyen->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTCitoyen->getValidationFailures());
                }
            }

            if ($this->aTAgentRelatedByIdAgentAccueil !== null) {
                if (!$this->aTAgentRelatedByIdAgentAccueil->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTAgentRelatedByIdAgentAccueil->getValidationFailures());
                }
            }

            if ($this->aTAgentRelatedByIdAgentAnnulation !== null) {
                if (!$this->aTAgentRelatedByIdAgentAnnulation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTAgentRelatedByIdAgentAnnulation->getValidationFailures());
                }
            }

            if ($this->aTAgentRelatedByIdAgentConfirmation !== null) {
                if (!$this->aTAgentRelatedByIdAgentConfirmation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTAgentRelatedByIdAgentConfirmation->getValidationFailures());
                }
            }

            if ($this->aTAgentRelatedByIdAgentRessource !== null) {
                if (!$this->aTAgentRelatedByIdAgentRessource->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTAgentRelatedByIdAgentRessource->getValidationFailures());
                }
            }

            if ($this->aTAgentRelatedByIdAgentTeleoperateur !== null) {
                if (!$this->aTAgentRelatedByIdAgentTeleoperateur->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTAgentRelatedByIdAgentTeleoperateur->getValidationFailures());
                }
            }

            if ($this->aTValeurReferentiel !== null) {
                if (!$this->aTValeurReferentiel->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTValeurReferentiel->getValidationFailures());
                }
            }

            if ($this->aTEtablissement !== null) {
                if (!$this->aTEtablissement->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTEtablissement->getValidationFailures());
                }
            }

            if ($this->aTPrestation !== null) {
                if (!$this->aTPrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTPrestation->getValidationFailures());
                }
            }

            if ($this->aTReferent !== null) {
                if (!$this->aTReferent->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTReferent->getValidationFailures());
                }
            }


            if (($retval = TRendezVousPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTBlobRdvs !== null) {
                    foreach ($this->collTBlobRdvs as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParticipants !== null) {
                    foreach ($this->collTParticipants as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TRendezVousPeer::DATABASE_NAME);

        if ($this->isColumnModified(TRendezVousPeer::ID_RENDEZ_VOUS)) $criteria->add(TRendezVousPeer::ID_RENDEZ_VOUS, $this->id_rendez_vous);
        if ($this->isColumnModified(TRendezVousPeer::DATE_CREATION)) $criteria->add(TRendezVousPeer::DATE_CREATION, $this->date_creation);
        if ($this->isColumnModified(TRendezVousPeer::DATE_CONFIRMATION)) $criteria->add(TRendezVousPeer::DATE_CONFIRMATION, $this->date_confirmation);
        if ($this->isColumnModified(TRendezVousPeer::DATE_ANNULATION)) $criteria->add(TRendezVousPeer::DATE_ANNULATION, $this->date_annulation);
        if ($this->isColumnModified(TRendezVousPeer::MOTIF_ANNULATION)) $criteria->add(TRendezVousPeer::MOTIF_ANNULATION, $this->motif_annulation);
        if ($this->isColumnModified(TRendezVousPeer::DATE_RDV)) $criteria->add(TRendezVousPeer::DATE_RDV, $this->date_rdv);
        if ($this->isColumnModified(TRendezVousPeer::DATE_FIN_RDV)) $criteria->add(TRendezVousPeer::DATE_FIN_RDV, $this->date_fin_rdv);
        if ($this->isColumnModified(TRendezVousPeer::CODE_RDV)) $criteria->add(TRendezVousPeer::CODE_RDV, $this->code_rdv);
        if ($this->isColumnModified(TRendezVousPeer::ETAT_RDV)) $criteria->add(TRendezVousPeer::ETAT_RDV, $this->etat_rdv);
        if ($this->isColumnModified(TRendezVousPeer::MODE_PRISE_RDV)) $criteria->add(TRendezVousPeer::MODE_PRISE_RDV, $this->mode_prise_rdv);
        if ($this->isColumnModified(TRendezVousPeer::TYPE_PRISE_RDV)) $criteria->add(TRendezVousPeer::TYPE_PRISE_RDV, $this->type_prise_rdv);
        if ($this->isColumnModified(TRendezVousPeer::ID_CITOYEN)) $criteria->add(TRendezVousPeer::ID_CITOYEN, $this->id_citoyen);
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_ACCUEIL)) $criteria->add(TRendezVousPeer::ID_AGENT_ACCUEIL, $this->id_agent_accueil);
        if ($this->isColumnModified(TRendezVousPeer::ID_ETABLISSEMENT)) $criteria->add(TRendezVousPeer::ID_ETABLISSEMENT, $this->id_etablissement);
        if ($this->isColumnModified(TRendezVousPeer::ID_PRESTATION)) $criteria->add(TRendezVousPeer::ID_PRESTATION, $this->id_prestation);
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_RESSOURCE)) $criteria->add(TRendezVousPeer::ID_AGENT_RESSOURCE, $this->id_agent_ressource);
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_TELEOPERATEUR)) $criteria->add(TRendezVousPeer::ID_AGENT_TELEOPERATEUR, $this->id_agent_teleoperateur);
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_CONFIRMATION)) $criteria->add(TRendezVousPeer::ID_AGENT_CONFIRMATION, $this->id_agent_confirmation);
        if ($this->isColumnModified(TRendezVousPeer::ID_AGENT_ANNULATION)) $criteria->add(TRendezVousPeer::ID_AGENT_ANNULATION, $this->id_agent_annulation);
        if ($this->isColumnModified(TRendezVousPeer::ID_REFERENT)) $criteria->add(TRendezVousPeer::ID_REFERENT, $this->id_referent);
        if ($this->isColumnModified(TRendezVousPeer::TAG_GATEWAY)) $criteria->add(TRendezVousPeer::TAG_GATEWAY, $this->tag_gateway);
        if ($this->isColumnModified(TRendezVousPeer::ID_UTILISATEUR)) $criteria->add(TRendezVousPeer::ID_UTILISATEUR, $this->id_utilisateur);
        if ($this->isColumnModified(TRendezVousPeer::ETAT_ACQUITTEMENT)) $criteria->add(TRendezVousPeer::ETAT_ACQUITTEMENT, $this->etat_acquittement);
        if ($this->isColumnModified(TRendezVousPeer::DATE_ACQUITTEMENT)) $criteria->add(TRendezVousPeer::DATE_ACQUITTEMENT, $this->date_acquittement);
        if ($this->isColumnModified(TRendezVousPeer::CHAMP_SUPP_PRESTA)) $criteria->add(TRendezVousPeer::CHAMP_SUPP_PRESTA, $this->champ_supp_presta);
        if ($this->isColumnModified(TRendezVousPeer::ID_CHEF_RESSOURCE)) $criteria->add(TRendezVousPeer::ID_CHEF_RESSOURCE, $this->id_chef_ressource);
        if ($this->isColumnModified(TRendezVousPeer::PARTAGE_RECAP)) $criteria->add(TRendezVousPeer::PARTAGE_RECAP, $this->partage_recap);
        if ($this->isColumnModified(TRendezVousPeer::NATURE_SESSION)) $criteria->add(TRendezVousPeer::NATURE_SESSION, $this->nature_session);
        if ($this->isColumnModified(TRendezVousPeer::LIEU_RDV)) $criteria->add(TRendezVousPeer::LIEU_RDV, $this->lieu_rdv);
        if ($this->isColumnModified(TRendezVousPeer::LIEN_RDV)) $criteria->add(TRendezVousPeer::LIEN_RDV, $this->lien_rdv);
        if ($this->isColumnModified(TRendezVousPeer::NOMBRE_PARTICIPANT)) $criteria->add(TRendezVousPeer::NOMBRE_PARTICIPANT, $this->nombre_participant);
        if ($this->isColumnModified(TRendezVousPeer::COMMENTAIRE)) $criteria->add(TRendezVousPeer::COMMENTAIRE, $this->commentaire);
        if ($this->isColumnModified(TRendezVousPeer::ID_VALEUR_REFERENTIEL)) $criteria->add(TRendezVousPeer::ID_VALEUR_REFERENTIEL, $this->id_valeur_referentiel);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TRendezVousPeer::DATABASE_NAME);
        $criteria->add(TRendezVousPeer::ID_RENDEZ_VOUS, $this->id_rendez_vous);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdRendezVous();
    }

    /**
     * Generic method to set the primary key (id_rendez_vous column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdRendezVous($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdRendezVous();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TRendezVous (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setDateCreation($this->getDateCreation());
        $copyObj->setDateConfirmation($this->getDateConfirmation());
        $copyObj->setDateAnnulation($this->getDateAnnulation());
        $copyObj->setMotifAnnulation($this->getMotifAnnulation());
        $copyObj->setDateRdv($this->getDateRdv());
        $copyObj->setDateFinRdv($this->getDateFinRdv());
        $copyObj->setCodeRdv($this->getCodeRdv());
        $copyObj->setEtatRdv($this->getEtatRdv());
        $copyObj->setModePriseRdv($this->getModePriseRdv());
        $copyObj->setTypePriseRdv($this->getTypePriseRdv());
        $copyObj->setIdCitoyen($this->getIdCitoyen());
        $copyObj->setIdAgentAccueil($this->getIdAgentAccueil());
        $copyObj->setIdEtablissement($this->getIdEtablissement());
        $copyObj->setIdPrestation($this->getIdPrestation());
        $copyObj->setIdAgentRessource($this->getIdAgentRessource());
        $copyObj->setIdAgentTeleoperateur($this->getIdAgentTeleoperateur());
        $copyObj->setIdAgentConfirmation($this->getIdAgentConfirmation());
        $copyObj->setIdAgentAnnulation($this->getIdAgentAnnulation());
        $copyObj->setIdReferent($this->getIdReferent());
        $copyObj->setTagGateway($this->getTagGateway());
        $copyObj->setIdUtilisateur($this->getIdUtilisateur());
        $copyObj->setEtatAcquittement($this->getEtatAcquittement());
        $copyObj->setDateAcquittement($this->getDateAcquittement());
        $copyObj->setChampSuppPresta($this->getChampSuppPresta());
        $copyObj->setIdChefRessource($this->getIdChefRessource());
        $copyObj->setPartageRecap($this->getPartageRecap());
        $copyObj->setNatureSession($this->getNatureSession());
        $copyObj->setLieuRdv($this->getLieuRdv());
        $copyObj->setLienRdv($this->getLienRdv());
        $copyObj->setNombreParticipant($this->getNombreParticipant());
        $copyObj->setCommentaire($this->getCommentaire());
        $copyObj->setIdValeurReferentiel($this->getIdValeurReferentiel());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTBlobRdvs() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTBlobRdv($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParticipants() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParticipant($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdRendezVous(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TRendezVous Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TRendezVousPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TRendezVousPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TCitoyen object.
     *
     * @param             TCitoyen $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTCitoyen(TCitoyen $v = null)
    {
        if ($v === null) {
            $this->setIdCitoyen(NULL);
        } else {
            $this->setIdCitoyen($v->getIdCitoyen());
        }

        $this->aTCitoyen = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TCitoyen object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVous($this);
        }


        return $this;
    }


    /**
     * Get the associated TCitoyen object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TCitoyen The associated TCitoyen object.
     * @throws PropelException
     */
    public function getTCitoyen(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTCitoyen === null && ($this->id_citoyen !== null) && $doQuery) {
            $this->aTCitoyen = TCitoyenQuery::create()->findPk($this->id_citoyen, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTCitoyen->addTRendezVouss($this);
             */
        }

        return $this->aTCitoyen;
    }

    /**
     * Declares an association between this object and a TAgent object.
     *
     * @param             TAgent $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTAgentRelatedByIdAgentAccueil(TAgent $v = null)
    {
        if ($v === null) {
            $this->setIdAgentAccueil(NULL);
        } else {
            $this->setIdAgentAccueil($v->getIdAgent());
        }

        $this->aTAgentRelatedByIdAgentAccueil = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TAgent object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVousRelatedByIdAgentAccueil($this);
        }


        return $this;
    }


    /**
     * Get the associated TAgent object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TAgent The associated TAgent object.
     * @throws PropelException
     */
    public function getTAgentRelatedByIdAgentAccueil(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTAgentRelatedByIdAgentAccueil === null && ($this->id_agent_accueil !== null) && $doQuery) {
            $this->aTAgentRelatedByIdAgentAccueil = TAgentQuery::create()->findPk($this->id_agent_accueil, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTAgentRelatedByIdAgentAccueil->addTRendezVoussRelatedByIdAgentAccueil($this);
             */
        }

        return $this->aTAgentRelatedByIdAgentAccueil;
    }

    /**
     * Declares an association between this object and a TAgent object.
     *
     * @param             TAgent $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTAgentRelatedByIdAgentAnnulation(TAgent $v = null)
    {
        if ($v === null) {
            $this->setIdAgentAnnulation(NULL);
        } else {
            $this->setIdAgentAnnulation($v->getIdAgent());
        }

        $this->aTAgentRelatedByIdAgentAnnulation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TAgent object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVousRelatedByIdAgentAnnulation($this);
        }


        return $this;
    }


    /**
     * Get the associated TAgent object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TAgent The associated TAgent object.
     * @throws PropelException
     */
    public function getTAgentRelatedByIdAgentAnnulation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTAgentRelatedByIdAgentAnnulation === null && ($this->id_agent_annulation !== null) && $doQuery) {
            $this->aTAgentRelatedByIdAgentAnnulation = TAgentQuery::create()->findPk($this->id_agent_annulation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTAgentRelatedByIdAgentAnnulation->addTRendezVoussRelatedByIdAgentAnnulation($this);
             */
        }

        return $this->aTAgentRelatedByIdAgentAnnulation;
    }

    /**
     * Declares an association between this object and a TAgent object.
     *
     * @param             TAgent $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTAgentRelatedByIdAgentConfirmation(TAgent $v = null)
    {
        if ($v === null) {
            $this->setIdAgentConfirmation(NULL);
        } else {
            $this->setIdAgentConfirmation($v->getIdAgent());
        }

        $this->aTAgentRelatedByIdAgentConfirmation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TAgent object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVousRelatedByIdAgentConfirmation($this);
        }


        return $this;
    }


    /**
     * Get the associated TAgent object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TAgent The associated TAgent object.
     * @throws PropelException
     */
    public function getTAgentRelatedByIdAgentConfirmation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTAgentRelatedByIdAgentConfirmation === null && ($this->id_agent_confirmation !== null) && $doQuery) {
            $this->aTAgentRelatedByIdAgentConfirmation = TAgentQuery::create()->findPk($this->id_agent_confirmation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTAgentRelatedByIdAgentConfirmation->addTRendezVoussRelatedByIdAgentConfirmation($this);
             */
        }

        return $this->aTAgentRelatedByIdAgentConfirmation;
    }

    /**
     * Declares an association between this object and a TAgent object.
     *
     * @param             TAgent $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTAgentRelatedByIdAgentRessource(TAgent $v = null)
    {
        if ($v === null) {
            $this->setIdAgentRessource(NULL);
        } else {
            $this->setIdAgentRessource($v->getIdAgent());
        }

        $this->aTAgentRelatedByIdAgentRessource = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TAgent object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVousRelatedByIdAgentRessource($this);
        }


        return $this;
    }


    /**
     * Get the associated TAgent object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TAgent The associated TAgent object.
     * @throws PropelException
     */
    public function getTAgentRelatedByIdAgentRessource(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTAgentRelatedByIdAgentRessource === null && ($this->id_agent_ressource !== null) && $doQuery) {
            $this->aTAgentRelatedByIdAgentRessource = TAgentQuery::create()->findPk($this->id_agent_ressource, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTAgentRelatedByIdAgentRessource->addTRendezVoussRelatedByIdAgentRessource($this);
             */
        }

        return $this->aTAgentRelatedByIdAgentRessource;
    }

    /**
     * Declares an association between this object and a TAgent object.
     *
     * @param             TAgent $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTAgentRelatedByIdAgentTeleoperateur(TAgent $v = null)
    {
        if ($v === null) {
            $this->setIdAgentTeleoperateur(NULL);
        } else {
            $this->setIdAgentTeleoperateur($v->getIdAgent());
        }

        $this->aTAgentRelatedByIdAgentTeleoperateur = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TAgent object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVousRelatedByIdAgentTeleoperateur($this);
        }


        return $this;
    }


    /**
     * Get the associated TAgent object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TAgent The associated TAgent object.
     * @throws PropelException
     */
    public function getTAgentRelatedByIdAgentTeleoperateur(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTAgentRelatedByIdAgentTeleoperateur === null && ($this->id_agent_teleoperateur !== null) && $doQuery) {
            $this->aTAgentRelatedByIdAgentTeleoperateur = TAgentQuery::create()->findPk($this->id_agent_teleoperateur, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTAgentRelatedByIdAgentTeleoperateur->addTRendezVoussRelatedByIdAgentTeleoperateur($this);
             */
        }

        return $this->aTAgentRelatedByIdAgentTeleoperateur;
    }

    /**
     * Declares an association between this object and a TValeurReferentiel object.
     *
     * @param             TValeurReferentiel $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTValeurReferentiel(TValeurReferentiel $v = null)
    {
        if ($v === null) {
            $this->setIdValeurReferentiel(NULL);
        } else {
            $this->setIdValeurReferentiel($v->getIdValeurReferentiel());
        }

        $this->aTValeurReferentiel = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TValeurReferentiel object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVous($this);
        }


        return $this;
    }


    /**
     * Get the associated TValeurReferentiel object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TValeurReferentiel The associated TValeurReferentiel object.
     * @throws PropelException
     */
    public function getTValeurReferentiel(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTValeurReferentiel === null && ($this->id_valeur_referentiel !== null) && $doQuery) {
            $this->aTValeurReferentiel = TValeurReferentielQuery::create()->findPk($this->id_valeur_referentiel, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTValeurReferentiel->addTRendezVouss($this);
             */
        }

        return $this->aTValeurReferentiel;
    }

    /**
     * Declares an association between this object and a TEtablissement object.
     *
     * @param             TEtablissement $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTEtablissement(TEtablissement $v = null)
    {
        if ($v === null) {
            $this->setIdEtablissement(NULL);
        } else {
            $this->setIdEtablissement($v->getIdEtablissement());
        }

        $this->aTEtablissement = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TEtablissement object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVous($this);
        }


        return $this;
    }


    /**
     * Get the associated TEtablissement object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TEtablissement The associated TEtablissement object.
     * @throws PropelException
     */
    public function getTEtablissement(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTEtablissement === null && ($this->id_etablissement !== null) && $doQuery) {
            $this->aTEtablissement = TEtablissementQuery::create()->findPk($this->id_etablissement, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTEtablissement->addTRendezVouss($this);
             */
        }

        return $this->aTEtablissement;
    }

    /**
     * Declares an association between this object and a TPrestation object.
     *
     * @param             TPrestation $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTPrestation(TPrestation $v = null)
    {
        if ($v === null) {
            $this->setIdPrestation(NULL);
        } else {
            $this->setIdPrestation($v->getIdPrestation());
        }

        $this->aTPrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TPrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVous($this);
        }


        return $this;
    }


    /**
     * Get the associated TPrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TPrestation The associated TPrestation object.
     * @throws PropelException
     */
    public function getTPrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTPrestation === null && ($this->id_prestation !== null) && $doQuery) {
            $this->aTPrestation = TPrestationQuery::create()->findPk($this->id_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTPrestation->addTRendezVouss($this);
             */
        }

        return $this->aTPrestation;
    }

    /**
     * Declares an association between this object and a TReferent object.
     *
     * @param             TReferent $v
     * @return TRendezVous The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTReferent(TReferent $v = null)
    {
        if ($v === null) {
            $this->setIdReferent(NULL);
        } else {
            $this->setIdReferent($v->getIdReferent());
        }

        $this->aTReferent = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TReferent object, it will not be re-added.
        if ($v !== null) {
            $v->addTRendezVous($this);
        }


        return $this;
    }


    /**
     * Get the associated TReferent object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TReferent The associated TReferent object.
     * @throws PropelException
     */
    public function getTReferent(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTReferent === null && ($this->id_referent !== null) && $doQuery) {
            $this->aTReferent = TReferentQuery::create()->findPk($this->id_referent, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTReferent->addTRendezVouss($this);
             */
        }

        return $this->aTReferent;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TBlobRdv' == $relationName) {
            $this->initTBlobRdvs();
        }
        if ('TParticipant' == $relationName) {
            $this->initTParticipants();
        }
    }

    /**
     * Clears out the collTBlobRdvs collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TRendezVous The current object (for fluent API support)
     * @see        addTBlobRdvs()
     */
    public function clearTBlobRdvs()
    {
        $this->collTBlobRdvs = null; // important to set this to null since that means it is uninitialized
        $this->collTBlobRdvsPartial = null;

        return $this;
    }

    /**
     * reset is the collTBlobRdvs collection loaded partially
     *
     * @return void
     */
    public function resetPartialTBlobRdvs($v = true)
    {
        $this->collTBlobRdvsPartial = $v;
    }

    /**
     * Initializes the collTBlobRdvs collection.
     *
     * By default this just sets the collTBlobRdvs collection to an empty array (like clearcollTBlobRdvs());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTBlobRdvs($overrideExisting = true)
    {
        if (null !== $this->collTBlobRdvs && !$overrideExisting) {
            return;
        }
        $this->collTBlobRdvs = new PropelObjectCollection();
        $this->collTBlobRdvs->setModel('TBlobRdv');
    }

    /**
     * Gets an array of TBlobRdv objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TRendezVous is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TBlobRdv[] List of TBlobRdv objects
     * @throws PropelException
     */
    public function getTBlobRdvs($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTBlobRdvsPartial && !$this->isNew();
        if (null === $this->collTBlobRdvs || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTBlobRdvs) {
                // return empty collection
                $this->initTBlobRdvs();
            } else {
                $collTBlobRdvs = TBlobRdvQuery::create(null, $criteria)
                    ->filterByTRendezVous($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTBlobRdvsPartial && count($collTBlobRdvs)) {
                      $this->initTBlobRdvs(false);

                      foreach($collTBlobRdvs as $obj) {
                        if (false == $this->collTBlobRdvs->contains($obj)) {
                          $this->collTBlobRdvs->append($obj);
                        }
                      }

                      $this->collTBlobRdvsPartial = true;
                    }

                    $collTBlobRdvs->getInternalIterator()->rewind();
                    return $collTBlobRdvs;
                }

                if($partial && $this->collTBlobRdvs) {
                    foreach($this->collTBlobRdvs as $obj) {
                        if($obj->isNew()) {
                            $collTBlobRdvs[] = $obj;
                        }
                    }
                }

                $this->collTBlobRdvs = $collTBlobRdvs;
                $this->collTBlobRdvsPartial = false;
            }
        }

        return $this->collTBlobRdvs;
    }

    /**
     * Sets a collection of TBlobRdv objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tBlobRdvs A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setTBlobRdvs(PropelCollection $tBlobRdvs, PropelPDO $con = null)
    {
        $tBlobRdvsToDelete = $this->getTBlobRdvs(new Criteria(), $con)->diff($tBlobRdvs);

        $this->tBlobRdvsScheduledForDeletion = unserialize(serialize($tBlobRdvsToDelete));

        foreach ($tBlobRdvsToDelete as $tBlobRdvRemoved) {
            $tBlobRdvRemoved->setTRendezVous(null);
        }

        $this->collTBlobRdvs = null;
        foreach ($tBlobRdvs as $tBlobRdv) {
            $this->addTBlobRdv($tBlobRdv);
        }

        $this->collTBlobRdvs = $tBlobRdvs;
        $this->collTBlobRdvsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TBlobRdv objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TBlobRdv objects.
     * @throws PropelException
     */
    public function countTBlobRdvs(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTBlobRdvsPartial && !$this->isNew();
        if (null === $this->collTBlobRdvs || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTBlobRdvs) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTBlobRdvs());
            }
            $query = TBlobRdvQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTRendezVous($this)
                ->count($con);
        }

        return count($this->collTBlobRdvs);
    }

    /**
     * Method called to associate a TBlobRdv object to this object
     * through the TBlobRdv foreign key attribute.
     *
     * @param    TBlobRdv $l TBlobRdv
     * @return TRendezVous The current object (for fluent API support)
     */
    public function addTBlobRdv(TBlobRdv $l)
    {
        if ($this->collTBlobRdvs === null) {
            $this->initTBlobRdvs();
            $this->collTBlobRdvsPartial = true;
        }
        if (!in_array($l, $this->collTBlobRdvs->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTBlobRdv($l);
        }

        return $this;
    }

    /**
     * @param	TBlobRdv $tBlobRdv The tBlobRdv object to add.
     */
    protected function doAddTBlobRdv($tBlobRdv)
    {
        $this->collTBlobRdvs[]= $tBlobRdv;
        $tBlobRdv->setTRendezVous($this);
    }

    /**
     * @param	TBlobRdv $tBlobRdv The tBlobRdv object to remove.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function removeTBlobRdv($tBlobRdv)
    {
        if ($this->getTBlobRdvs()->contains($tBlobRdv)) {
            $this->collTBlobRdvs->remove($this->collTBlobRdvs->search($tBlobRdv));
            if (null === $this->tBlobRdvsScheduledForDeletion) {
                $this->tBlobRdvsScheduledForDeletion = clone $this->collTBlobRdvs;
                $this->tBlobRdvsScheduledForDeletion->clear();
            }
            $this->tBlobRdvsScheduledForDeletion[]= clone $tBlobRdv;
            $tBlobRdv->setTRendezVous(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TRendezVous is new, it will return
     * an empty collection; or if this TRendezVous has previously
     * been saved, it will retrieve related TBlobRdvs from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TRendezVous.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TBlobRdv[] List of TBlobRdv objects
     */
    public function getTBlobRdvsJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TBlobRdvQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTBlobRdvs($query, $con);
    }

    /**
     * Clears out the collTParticipants collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TRendezVous The current object (for fluent API support)
     * @see        addTParticipants()
     */
    public function clearTParticipants()
    {
        $this->collTParticipants = null; // important to set this to null since that means it is uninitialized
        $this->collTParticipantsPartial = null;

        return $this;
    }

    /**
     * reset is the collTParticipants collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParticipants($v = true)
    {
        $this->collTParticipantsPartial = $v;
    }

    /**
     * Initializes the collTParticipants collection.
     *
     * By default this just sets the collTParticipants collection to an empty array (like clearcollTParticipants());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParticipants($overrideExisting = true)
    {
        if (null !== $this->collTParticipants && !$overrideExisting) {
            return;
        }
        $this->collTParticipants = new PropelObjectCollection();
        $this->collTParticipants->setModel('TParticipant');
    }

    /**
     * Gets an array of TParticipant objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TRendezVous is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParticipant[] List of TParticipant objects
     * @throws PropelException
     */
    public function getTParticipants($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParticipantsPartial && !$this->isNew();
        if (null === $this->collTParticipants || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParticipants) {
                // return empty collection
                $this->initTParticipants();
            } else {
                $collTParticipants = TParticipantQuery::create(null, $criteria)
                    ->filterByTRendezVous($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParticipantsPartial && count($collTParticipants)) {
                      $this->initTParticipants(false);

                      foreach($collTParticipants as $obj) {
                        if (false == $this->collTParticipants->contains($obj)) {
                          $this->collTParticipants->append($obj);
                        }
                      }

                      $this->collTParticipantsPartial = true;
                    }

                    $collTParticipants->getInternalIterator()->rewind();
                    return $collTParticipants;
                }

                if($partial && $this->collTParticipants) {
                    foreach($this->collTParticipants as $obj) {
                        if($obj->isNew()) {
                            $collTParticipants[] = $obj;
                        }
                    }
                }

                $this->collTParticipants = $collTParticipants;
                $this->collTParticipantsPartial = false;
            }
        }

        return $this->collTParticipants;
    }

    /**
     * Sets a collection of TParticipant objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParticipants A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TRendezVous The current object (for fluent API support)
     */
    public function setTParticipants(PropelCollection $tParticipants, PropelPDO $con = null)
    {
        $tParticipantsToDelete = $this->getTParticipants(new Criteria(), $con)->diff($tParticipants);

        $this->tParticipantsScheduledForDeletion = unserialize(serialize($tParticipantsToDelete));

        foreach ($tParticipantsToDelete as $tParticipantRemoved) {
            $tParticipantRemoved->setTRendezVous(null);
        }

        $this->collTParticipants = null;
        foreach ($tParticipants as $tParticipant) {
            $this->addTParticipant($tParticipant);
        }

        $this->collTParticipants = $tParticipants;
        $this->collTParticipantsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TParticipant objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParticipant objects.
     * @throws PropelException
     */
    public function countTParticipants(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParticipantsPartial && !$this->isNew();
        if (null === $this->collTParticipants || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParticipants) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParticipants());
            }
            $query = TParticipantQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTRendezVous($this)
                ->count($con);
        }

        return count($this->collTParticipants);
    }

    /**
     * Method called to associate a TParticipant object to this object
     * through the TParticipant foreign key attribute.
     *
     * @param    TParticipant $l TParticipant
     * @return TRendezVous The current object (for fluent API support)
     */
    public function addTParticipant(TParticipant $l)
    {
        if ($this->collTParticipants === null) {
            $this->initTParticipants();
            $this->collTParticipantsPartial = true;
        }
        if (!in_array($l, $this->collTParticipants->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParticipant($l);
        }

        return $this;
    }

    /**
     * @param	TParticipant $tParticipant The tParticipant object to add.
     */
    protected function doAddTParticipant($tParticipant)
    {
        $this->collTParticipants[]= $tParticipant;
        $tParticipant->setTRendezVous($this);
    }

    /**
     * @param	TParticipant $tParticipant The tParticipant object to remove.
     * @return TRendezVous The current object (for fluent API support)
     */
    public function removeTParticipant($tParticipant)
    {
        if ($this->getTParticipants()->contains($tParticipant)) {
            $this->collTParticipants->remove($this->collTParticipants->search($tParticipant));
            if (null === $this->tParticipantsScheduledForDeletion) {
                $this->tParticipantsScheduledForDeletion = clone $this->collTParticipants;
                $this->tParticipantsScheduledForDeletion->clear();
            }
            $this->tParticipantsScheduledForDeletion[]= clone $tParticipant;
            $tParticipant->setTRendezVous(null);
        }

        return $this;
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_rendez_vous = null;
        $this->date_creation = null;
        $this->date_confirmation = null;
        $this->date_annulation = null;
        $this->motif_annulation = null;
        $this->date_rdv = null;
        $this->date_fin_rdv = null;
        $this->code_rdv = null;
        $this->etat_rdv = null;
        $this->mode_prise_rdv = null;
        $this->type_prise_rdv = null;
        $this->id_citoyen = null;
        $this->id_agent_accueil = null;
        $this->id_etablissement = null;
        $this->id_prestation = null;
        $this->id_agent_ressource = null;
        $this->id_agent_teleoperateur = null;
        $this->id_agent_confirmation = null;
        $this->id_agent_annulation = null;
        $this->id_referent = null;
        $this->tag_gateway = null;
        $this->id_utilisateur = null;
        $this->etat_acquittement = null;
        $this->date_acquittement = null;
        $this->champ_supp_presta = null;
        $this->id_chef_ressource = null;
        $this->partage_recap = null;
        $this->nature_session = null;
        $this->lieu_rdv = null;
        $this->lien_rdv = null;
        $this->nombre_participant = null;
        $this->commentaire = null;
        $this->id_valeur_referentiel = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTBlobRdvs) {
                foreach ($this->collTBlobRdvs as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParticipants) {
                foreach ($this->collTParticipants as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTCitoyen instanceof Persistent) {
              $this->aTCitoyen->clearAllReferences($deep);
            }
            if ($this->aTAgentRelatedByIdAgentAccueil instanceof Persistent) {
              $this->aTAgentRelatedByIdAgentAccueil->clearAllReferences($deep);
            }
            if ($this->aTAgentRelatedByIdAgentAnnulation instanceof Persistent) {
              $this->aTAgentRelatedByIdAgentAnnulation->clearAllReferences($deep);
            }
            if ($this->aTAgentRelatedByIdAgentConfirmation instanceof Persistent) {
              $this->aTAgentRelatedByIdAgentConfirmation->clearAllReferences($deep);
            }
            if ($this->aTAgentRelatedByIdAgentRessource instanceof Persistent) {
              $this->aTAgentRelatedByIdAgentRessource->clearAllReferences($deep);
            }
            if ($this->aTAgentRelatedByIdAgentTeleoperateur instanceof Persistent) {
              $this->aTAgentRelatedByIdAgentTeleoperateur->clearAllReferences($deep);
            }
            if ($this->aTValeurReferentiel instanceof Persistent) {
              $this->aTValeurReferentiel->clearAllReferences($deep);
            }
            if ($this->aTEtablissement instanceof Persistent) {
              $this->aTEtablissement->clearAllReferences($deep);
            }
            if ($this->aTPrestation instanceof Persistent) {
              $this->aTPrestation->clearAllReferences($deep);
            }
            if ($this->aTReferent instanceof Persistent) {
              $this->aTReferent->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTBlobRdvs instanceof PropelCollection) {
            $this->collTBlobRdvs->clearIterator();
        }
        $this->collTBlobRdvs = null;
        if ($this->collTParticipants instanceof PropelCollection) {
            $this->collTParticipants->clearIterator();
        }
        $this->collTParticipants = null;
        $this->aTCitoyen = null;
        $this->aTAgentRelatedByIdAgentAccueil = null;
        $this->aTAgentRelatedByIdAgentAnnulation = null;
        $this->aTAgentRelatedByIdAgentConfirmation = null;
        $this->aTAgentRelatedByIdAgentRessource = null;
        $this->aTAgentRelatedByIdAgentTeleoperateur = null;
        $this->aTValeurReferentiel = null;
        $this->aTEtablissement = null;
        $this->aTPrestation = null;
        $this->aTReferent = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TRendezVousPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
