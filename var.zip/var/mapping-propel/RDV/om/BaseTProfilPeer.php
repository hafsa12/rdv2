<?php


/**
 * Base static class for performing query and update operations on the 'T_PROFIL' table.
 *
 *
 *
 * @package propel.generator.RDV.om
 */
abstract class BaseTProfilPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'RDV';

    /** the table name for this class */
    const TABLE_NAME = 'T_PROFIL';

    /** the related Propel class for this table */
    const OM_CLASS = 'TProfil';

    /** the related TableMap class for this table */
    const TM_CLASS = 'TProfilTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 28;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 28;

    /** the column name for the ID_PROFIL field */
    const ID_PROFIL = 'T_PROFIL.ID_PROFIL';

    /** the column name for the ID_ORGANISATION field */
    const ID_ORGANISATION = 'T_PROFIL.ID_ORGANISATION';

    /** the column name for the CODE_LIBELLE_PROFIL field */
    const CODE_LIBELLE_PROFIL = 'T_PROFIL.CODE_LIBELLE_PROFIL';

    /** the column name for the ID_TYPE_PROFIL field */
    const ID_TYPE_PROFIL = 'T_PROFIL.ID_TYPE_PROFIL';

    /** the column name for the ORGANISATION field */
    const ORGANISATION = 'T_PROFIL.ORGANISATION';

    /** the column name for the ETABLISSEMENT field */
    const ETABLISSEMENT = 'T_PROFIL.ETABLISSEMENT';

    /** the column name for the REFERENTIEL_TYPE_PRESTATION field */
    const REFERENTIEL_TYPE_PRESTATION = 'T_PROFIL.REFERENTIEL_TYPE_PRESTATION';

    /** the column name for the PARAMETRAGE_PRESTATION field */
    const PARAMETRAGE_PRESTATION = 'T_PROFIL.PARAMETRAGE_PRESTATION';

    /** the column name for the NIVEAU_1 field */
    const NIVEAU_1 = 'T_PROFIL.NIVEAU_1';

    /** the column name for the NIVEAU_2 field */
    const NIVEAU_2 = 'T_PROFIL.NIVEAU_2';

    /** the column name for the NIVEAU_3 field */
    const NIVEAU_3 = 'T_PROFIL.NIVEAU_3';

    /** the column name for the JOURS_FERIES field */
    const JOURS_FERIES = 'T_PROFIL.JOURS_FERIES';

    /** the column name for the AGENDA field */
    const AGENDA = 'T_PROFIL.AGENDA';

    /** the column name for the JOURS_INDISPONIBILITES field */
    const JOURS_INDISPONIBILITES = 'T_PROFIL.JOURS_INDISPONIBILITES';

    /** the column name for the UTILISATEURS field */
    const UTILISATEURS = 'T_PROFIL.UTILISATEURS';

    /** the column name for the PROFILS field */
    const PROFILS = 'T_PROFIL.PROFILS';

    /** the column name for the GESTIONS_DES_RENDEZ_VOUS field */
    const GESTIONS_DES_RENDEZ_VOUS = 'T_PROFIL.GESTIONS_DES_RENDEZ_VOUS';

    /** the column name for the RAPPORT_NBR_RDV field */
    const RAPPORT_NBR_RDV = 'T_PROFIL.RAPPORT_NBR_RDV';

    /** the column name for the RAPPORT_DELAI_OBTENTION field */
    const RAPPORT_DELAI_OBTENTION = 'T_PROFIL.RAPPORT_DELAI_OBTENTION';

    /** the column name for the RAPPORT_ACTIVITE field */
    const RAPPORT_ACTIVITE = 'T_PROFIL.RAPPORT_ACTIVITE';

    /** the column name for the PERFORMANCE_GLOBALE field */
    const PERFORMANCE_GLOBALE = 'T_PROFIL.PERFORMANCE_GLOBALE';

    /** the column name for the REFERENTIEL_PRESTATION field */
    const REFERENTIEL_PRESTATION = 'T_PROFIL.REFERENTIEL_PRESTATION';

    /** the column name for the RECHERCHE_ETENDUE_RDV field */
    const RECHERCHE_ETENDUE_RDV = 'T_PROFIL.RECHERCHE_ETENDUE_RDV';

    /** the column name for the ALERT_RAPPORT_HEBDO field */
    const ALERT_RAPPORT_HEBDO = 'T_PROFIL.ALERT_RAPPORT_HEBDO';

    /** the column name for the ALERT_RAPPORT_MENS field */
    const ALERT_RAPPORT_MENS = 'T_PROFIL.ALERT_RAPPORT_MENS';

    /** the column name for the MODIF_DUREE_RDV field */
    const MODIF_DUREE_RDV = 'T_PROFIL.MODIF_DUREE_RDV';

    /** the column name for the AFFECTATION_RDV field */
    const AFFECTATION_RDV = 'T_PROFIL.AFFECTATION_RDV';

    /** the column name for the ANNULATION_RDV field */
    const ANNULATION_RDV = 'T_PROFIL.ANNULATION_RDV';

    /** The enumerated values for the ORGANISATION field */
    const ORGANISATION_0 = '0';
    const ORGANISATION_1 = '1';

    /** The enumerated values for the ETABLISSEMENT field */
    const ETABLISSEMENT_0 = '0';
    const ETABLISSEMENT_1 = '1';

    /** The enumerated values for the REFERENTIEL_TYPE_PRESTATION field */
    const REFERENTIEL_TYPE_PRESTATION_0 = '0';
    const REFERENTIEL_TYPE_PRESTATION_1 = '1';

    /** The enumerated values for the PARAMETRAGE_PRESTATION field */
    const PARAMETRAGE_PRESTATION_0 = '0';
    const PARAMETRAGE_PRESTATION_1 = '1';

    /** The enumerated values for the NIVEAU_1 field */
    const NIVEAU_1_0 = '0';
    const NIVEAU_1_1 = '1';

    /** The enumerated values for the NIVEAU_2 field */
    const NIVEAU_2_0 = '0';
    const NIVEAU_2_1 = '1';

    /** The enumerated values for the NIVEAU_3 field */
    const NIVEAU_3_0 = '0';
    const NIVEAU_3_1 = '1';

    /** The enumerated values for the JOURS_FERIES field */
    const JOURS_FERIES_0 = '0';
    const JOURS_FERIES_1 = '1';

    /** The enumerated values for the AGENDA field */
    const AGENDA_0 = '0';
    const AGENDA_1 = '1';

    /** The enumerated values for the JOURS_INDISPONIBILITES field */
    const JOURS_INDISPONIBILITES_0 = '0';
    const JOURS_INDISPONIBILITES_1 = '1';

    /** The enumerated values for the UTILISATEURS field */
    const UTILISATEURS_0 = '0';
    const UTILISATEURS_1 = '1';

    /** The enumerated values for the PROFILS field */
    const PROFILS_0 = '0';
    const PROFILS_1 = '1';

    /** The enumerated values for the GESTIONS_DES_RENDEZ_VOUS field */
    const GESTIONS_DES_RENDEZ_VOUS_0 = '0';
    const GESTIONS_DES_RENDEZ_VOUS_1 = '1';

    /** The enumerated values for the RAPPORT_NBR_RDV field */
    const RAPPORT_NBR_RDV_0 = '0';
    const RAPPORT_NBR_RDV_1 = '1';

    /** The enumerated values for the RAPPORT_DELAI_OBTENTION field */
    const RAPPORT_DELAI_OBTENTION_0 = '0';
    const RAPPORT_DELAI_OBTENTION_1 = '1';

    /** The enumerated values for the RAPPORT_ACTIVITE field */
    const RAPPORT_ACTIVITE_0 = '0';
    const RAPPORT_ACTIVITE_1 = '1';

    /** The enumerated values for the PERFORMANCE_GLOBALE field */
    const PERFORMANCE_GLOBALE_0 = '0';
    const PERFORMANCE_GLOBALE_1 = '1';

    /** The enumerated values for the REFERENTIEL_PRESTATION field */
    const REFERENTIEL_PRESTATION_0 = '0';
    const REFERENTIEL_PRESTATION_1 = '1';

    /** The enumerated values for the RECHERCHE_ETENDUE_RDV field */
    const RECHERCHE_ETENDUE_RDV_0 = '0';
    const RECHERCHE_ETENDUE_RDV_1 = '1';

    /** The enumerated values for the ALERT_RAPPORT_HEBDO field */
    const ALERT_RAPPORT_HEBDO_0 = '0';
    const ALERT_RAPPORT_HEBDO_1 = '1';

    /** The enumerated values for the ALERT_RAPPORT_MENS field */
    const ALERT_RAPPORT_MENS_0 = '0';
    const ALERT_RAPPORT_MENS_1 = '1';

    /** The enumerated values for the MODIF_DUREE_RDV field */
    const MODIF_DUREE_RDV_0 = '0';
    const MODIF_DUREE_RDV_1 = '1';

    /** The enumerated values for the AFFECTATION_RDV field */
    const AFFECTATION_RDV_0 = '0';
    const AFFECTATION_RDV_1 = '1';

    /** The enumerated values for the ANNULATION_RDV field */
    const ANNULATION_RDV_0 = '0';
    const ANNULATION_RDV_1 = '1';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identiy map to hold any loaded instances of TProfil objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array TProfil[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. TProfilPeer::$fieldNames[TProfilPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('IdProfil', 'IdOrganisation', 'CodeLibelleProfil', 'IdTypeProfil', 'Organisation', 'Etablissement', 'ReferentielTypePrestation', 'ParametragePrestation', 'Niveau1', 'Niveau2', 'Niveau3', 'JoursFeries', 'Agenda', 'JoursIndisponibilites', 'Utilisateurs', 'Profils', 'GestionsDesRendezVous', 'RapportNbrRdv', 'RapportDelaiObtention', 'RapportActivite', 'PerformanceGlobale', 'ReferentielPrestation', 'RechercheEtendueRdv', 'AlertRapportHebdo', 'AlertRapportMens', 'ModifDureeRdv', 'AffectationRdv', 'AnnulationRdv', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idProfil', 'idOrganisation', 'codeLibelleProfil', 'idTypeProfil', 'organisation', 'etablissement', 'referentielTypePrestation', 'parametragePrestation', 'niveau1', 'niveau2', 'niveau3', 'joursFeries', 'agenda', 'joursIndisponibilites', 'utilisateurs', 'profils', 'gestionsDesRendezVous', 'rapportNbrRdv', 'rapportDelaiObtention', 'rapportActivite', 'performanceGlobale', 'referentielPrestation', 'rechercheEtendueRdv', 'alertRapportHebdo', 'alertRapportMens', 'modifDureeRdv', 'affectationRdv', 'annulationRdv', ),
        BasePeer::TYPE_COLNAME => array (TProfilPeer::ID_PROFIL, TProfilPeer::ID_ORGANISATION, TProfilPeer::CODE_LIBELLE_PROFIL, TProfilPeer::ID_TYPE_PROFIL, TProfilPeer::ORGANISATION, TProfilPeer::ETABLISSEMENT, TProfilPeer::REFERENTIEL_TYPE_PRESTATION, TProfilPeer::PARAMETRAGE_PRESTATION, TProfilPeer::NIVEAU_1, TProfilPeer::NIVEAU_2, TProfilPeer::NIVEAU_3, TProfilPeer::JOURS_FERIES, TProfilPeer::AGENDA, TProfilPeer::JOURS_INDISPONIBILITES, TProfilPeer::UTILISATEURS, TProfilPeer::PROFILS, TProfilPeer::GESTIONS_DES_RENDEZ_VOUS, TProfilPeer::RAPPORT_NBR_RDV, TProfilPeer::RAPPORT_DELAI_OBTENTION, TProfilPeer::RAPPORT_ACTIVITE, TProfilPeer::PERFORMANCE_GLOBALE, TProfilPeer::REFERENTIEL_PRESTATION, TProfilPeer::RECHERCHE_ETENDUE_RDV, TProfilPeer::ALERT_RAPPORT_HEBDO, TProfilPeer::ALERT_RAPPORT_MENS, TProfilPeer::MODIF_DUREE_RDV, TProfilPeer::AFFECTATION_RDV, TProfilPeer::ANNULATION_RDV, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_PROFIL', 'ID_ORGANISATION', 'CODE_LIBELLE_PROFIL', 'ID_TYPE_PROFIL', 'ORGANISATION', 'ETABLISSEMENT', 'REFERENTIEL_TYPE_PRESTATION', 'PARAMETRAGE_PRESTATION', 'NIVEAU_1', 'NIVEAU_2', 'NIVEAU_3', 'JOURS_FERIES', 'AGENDA', 'JOURS_INDISPONIBILITES', 'UTILISATEURS', 'PROFILS', 'GESTIONS_DES_RENDEZ_VOUS', 'RAPPORT_NBR_RDV', 'RAPPORT_DELAI_OBTENTION', 'RAPPORT_ACTIVITE', 'PERFORMANCE_GLOBALE', 'REFERENTIEL_PRESTATION', 'RECHERCHE_ETENDUE_RDV', 'ALERT_RAPPORT_HEBDO', 'ALERT_RAPPORT_MENS', 'MODIF_DUREE_RDV', 'AFFECTATION_RDV', 'ANNULATION_RDV', ),
        BasePeer::TYPE_FIELDNAME => array ('ID_PROFIL', 'ID_ORGANISATION', 'CODE_LIBELLE_PROFIL', 'ID_TYPE_PROFIL', 'ORGANISATION', 'ETABLISSEMENT', 'REFERENTIEL_TYPE_PRESTATION', 'PARAMETRAGE_PRESTATION', 'NIVEAU_1', 'NIVEAU_2', 'NIVEAU_3', 'JOURS_FERIES', 'AGENDA', 'JOURS_INDISPONIBILITES', 'UTILISATEURS', 'PROFILS', 'GESTIONS_DES_RENDEZ_VOUS', 'RAPPORT_NBR_RDV', 'RAPPORT_DELAI_OBTENTION', 'RAPPORT_ACTIVITE', 'PERFORMANCE_GLOBALE', 'REFERENTIEL_PRESTATION', 'RECHERCHE_ETENDUE_RDV', 'ALERT_RAPPORT_HEBDO', 'ALERT_RAPPORT_MENS', 'MODIF_DUREE_RDV', 'AFFECTATION_RDV', 'ANNULATION_RDV', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. TProfilPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('IdProfil' => 0, 'IdOrganisation' => 1, 'CodeLibelleProfil' => 2, 'IdTypeProfil' => 3, 'Organisation' => 4, 'Etablissement' => 5, 'ReferentielTypePrestation' => 6, 'ParametragePrestation' => 7, 'Niveau1' => 8, 'Niveau2' => 9, 'Niveau3' => 10, 'JoursFeries' => 11, 'Agenda' => 12, 'JoursIndisponibilites' => 13, 'Utilisateurs' => 14, 'Profils' => 15, 'GestionsDesRendezVous' => 16, 'RapportNbrRdv' => 17, 'RapportDelaiObtention' => 18, 'RapportActivite' => 19, 'PerformanceGlobale' => 20, 'ReferentielPrestation' => 21, 'RechercheEtendueRdv' => 22, 'AlertRapportHebdo' => 23, 'AlertRapportMens' => 24, 'ModifDureeRdv' => 25, 'AffectationRdv' => 26, 'AnnulationRdv' => 27, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idProfil' => 0, 'idOrganisation' => 1, 'codeLibelleProfil' => 2, 'idTypeProfil' => 3, 'organisation' => 4, 'etablissement' => 5, 'referentielTypePrestation' => 6, 'parametragePrestation' => 7, 'niveau1' => 8, 'niveau2' => 9, 'niveau3' => 10, 'joursFeries' => 11, 'agenda' => 12, 'joursIndisponibilites' => 13, 'utilisateurs' => 14, 'profils' => 15, 'gestionsDesRendezVous' => 16, 'rapportNbrRdv' => 17, 'rapportDelaiObtention' => 18, 'rapportActivite' => 19, 'performanceGlobale' => 20, 'referentielPrestation' => 21, 'rechercheEtendueRdv' => 22, 'alertRapportHebdo' => 23, 'alertRapportMens' => 24, 'modifDureeRdv' => 25, 'affectationRdv' => 26, 'annulationRdv' => 27, ),
        BasePeer::TYPE_COLNAME => array (TProfilPeer::ID_PROFIL => 0, TProfilPeer::ID_ORGANISATION => 1, TProfilPeer::CODE_LIBELLE_PROFIL => 2, TProfilPeer::ID_TYPE_PROFIL => 3, TProfilPeer::ORGANISATION => 4, TProfilPeer::ETABLISSEMENT => 5, TProfilPeer::REFERENTIEL_TYPE_PRESTATION => 6, TProfilPeer::PARAMETRAGE_PRESTATION => 7, TProfilPeer::NIVEAU_1 => 8, TProfilPeer::NIVEAU_2 => 9, TProfilPeer::NIVEAU_3 => 10, TProfilPeer::JOURS_FERIES => 11, TProfilPeer::AGENDA => 12, TProfilPeer::JOURS_INDISPONIBILITES => 13, TProfilPeer::UTILISATEURS => 14, TProfilPeer::PROFILS => 15, TProfilPeer::GESTIONS_DES_RENDEZ_VOUS => 16, TProfilPeer::RAPPORT_NBR_RDV => 17, TProfilPeer::RAPPORT_DELAI_OBTENTION => 18, TProfilPeer::RAPPORT_ACTIVITE => 19, TProfilPeer::PERFORMANCE_GLOBALE => 20, TProfilPeer::REFERENTIEL_PRESTATION => 21, TProfilPeer::RECHERCHE_ETENDUE_RDV => 22, TProfilPeer::ALERT_RAPPORT_HEBDO => 23, TProfilPeer::ALERT_RAPPORT_MENS => 24, TProfilPeer::MODIF_DUREE_RDV => 25, TProfilPeer::AFFECTATION_RDV => 26, TProfilPeer::ANNULATION_RDV => 27, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_PROFIL' => 0, 'ID_ORGANISATION' => 1, 'CODE_LIBELLE_PROFIL' => 2, 'ID_TYPE_PROFIL' => 3, 'ORGANISATION' => 4, 'ETABLISSEMENT' => 5, 'REFERENTIEL_TYPE_PRESTATION' => 6, 'PARAMETRAGE_PRESTATION' => 7, 'NIVEAU_1' => 8, 'NIVEAU_2' => 9, 'NIVEAU_3' => 10, 'JOURS_FERIES' => 11, 'AGENDA' => 12, 'JOURS_INDISPONIBILITES' => 13, 'UTILISATEURS' => 14, 'PROFILS' => 15, 'GESTIONS_DES_RENDEZ_VOUS' => 16, 'RAPPORT_NBR_RDV' => 17, 'RAPPORT_DELAI_OBTENTION' => 18, 'RAPPORT_ACTIVITE' => 19, 'PERFORMANCE_GLOBALE' => 20, 'REFERENTIEL_PRESTATION' => 21, 'RECHERCHE_ETENDUE_RDV' => 22, 'ALERT_RAPPORT_HEBDO' => 23, 'ALERT_RAPPORT_MENS' => 24, 'MODIF_DUREE_RDV' => 25, 'AFFECTATION_RDV' => 26, 'ANNULATION_RDV' => 27, ),
        BasePeer::TYPE_FIELDNAME => array ('ID_PROFIL' => 0, 'ID_ORGANISATION' => 1, 'CODE_LIBELLE_PROFIL' => 2, 'ID_TYPE_PROFIL' => 3, 'ORGANISATION' => 4, 'ETABLISSEMENT' => 5, 'REFERENTIEL_TYPE_PRESTATION' => 6, 'PARAMETRAGE_PRESTATION' => 7, 'NIVEAU_1' => 8, 'NIVEAU_2' => 9, 'NIVEAU_3' => 10, 'JOURS_FERIES' => 11, 'AGENDA' => 12, 'JOURS_INDISPONIBILITES' => 13, 'UTILISATEURS' => 14, 'PROFILS' => 15, 'GESTIONS_DES_RENDEZ_VOUS' => 16, 'RAPPORT_NBR_RDV' => 17, 'RAPPORT_DELAI_OBTENTION' => 18, 'RAPPORT_ACTIVITE' => 19, 'PERFORMANCE_GLOBALE' => 20, 'REFERENTIEL_PRESTATION' => 21, 'RECHERCHE_ETENDUE_RDV' => 22, 'ALERT_RAPPORT_HEBDO' => 23, 'ALERT_RAPPORT_MENS' => 24, 'MODIF_DUREE_RDV' => 25, 'AFFECTATION_RDV' => 26, 'ANNULATION_RDV' => 27, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, )
    );

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
        TProfilPeer::ORGANISATION => array(
            TProfilPeer::ORGANISATION_0,
            TProfilPeer::ORGANISATION_1,
        ),
        TProfilPeer::ETABLISSEMENT => array(
            TProfilPeer::ETABLISSEMENT_0,
            TProfilPeer::ETABLISSEMENT_1,
        ),
        TProfilPeer::REFERENTIEL_TYPE_PRESTATION => array(
            TProfilPeer::REFERENTIEL_TYPE_PRESTATION_0,
            TProfilPeer::REFERENTIEL_TYPE_PRESTATION_1,
        ),
        TProfilPeer::PARAMETRAGE_PRESTATION => array(
            TProfilPeer::PARAMETRAGE_PRESTATION_0,
            TProfilPeer::PARAMETRAGE_PRESTATION_1,
        ),
        TProfilPeer::NIVEAU_1 => array(
            TProfilPeer::NIVEAU_1_0,
            TProfilPeer::NIVEAU_1_1,
        ),
        TProfilPeer::NIVEAU_2 => array(
            TProfilPeer::NIVEAU_2_0,
            TProfilPeer::NIVEAU_2_1,
        ),
        TProfilPeer::NIVEAU_3 => array(
            TProfilPeer::NIVEAU_3_0,
            TProfilPeer::NIVEAU_3_1,
        ),
        TProfilPeer::JOURS_FERIES => array(
            TProfilPeer::JOURS_FERIES_0,
            TProfilPeer::JOURS_FERIES_1,
        ),
        TProfilPeer::AGENDA => array(
            TProfilPeer::AGENDA_0,
            TProfilPeer::AGENDA_1,
        ),
        TProfilPeer::JOURS_INDISPONIBILITES => array(
            TProfilPeer::JOURS_INDISPONIBILITES_0,
            TProfilPeer::JOURS_INDISPONIBILITES_1,
        ),
        TProfilPeer::UTILISATEURS => array(
            TProfilPeer::UTILISATEURS_0,
            TProfilPeer::UTILISATEURS_1,
        ),
        TProfilPeer::PROFILS => array(
            TProfilPeer::PROFILS_0,
            TProfilPeer::PROFILS_1,
        ),
        TProfilPeer::GESTIONS_DES_RENDEZ_VOUS => array(
            TProfilPeer::GESTIONS_DES_RENDEZ_VOUS_0,
            TProfilPeer::GESTIONS_DES_RENDEZ_VOUS_1,
        ),
        TProfilPeer::RAPPORT_NBR_RDV => array(
            TProfilPeer::RAPPORT_NBR_RDV_0,
            TProfilPeer::RAPPORT_NBR_RDV_1,
        ),
        TProfilPeer::RAPPORT_DELAI_OBTENTION => array(
            TProfilPeer::RAPPORT_DELAI_OBTENTION_0,
            TProfilPeer::RAPPORT_DELAI_OBTENTION_1,
        ),
        TProfilPeer::RAPPORT_ACTIVITE => array(
            TProfilPeer::RAPPORT_ACTIVITE_0,
            TProfilPeer::RAPPORT_ACTIVITE_1,
        ),
        TProfilPeer::PERFORMANCE_GLOBALE => array(
            TProfilPeer::PERFORMANCE_GLOBALE_0,
            TProfilPeer::PERFORMANCE_GLOBALE_1,
        ),
        TProfilPeer::REFERENTIEL_PRESTATION => array(
            TProfilPeer::REFERENTIEL_PRESTATION_0,
            TProfilPeer::REFERENTIEL_PRESTATION_1,
        ),
        TProfilPeer::RECHERCHE_ETENDUE_RDV => array(
            TProfilPeer::RECHERCHE_ETENDUE_RDV_0,
            TProfilPeer::RECHERCHE_ETENDUE_RDV_1,
        ),
        TProfilPeer::ALERT_RAPPORT_HEBDO => array(
            TProfilPeer::ALERT_RAPPORT_HEBDO_0,
            TProfilPeer::ALERT_RAPPORT_HEBDO_1,
        ),
        TProfilPeer::ALERT_RAPPORT_MENS => array(
            TProfilPeer::ALERT_RAPPORT_MENS_0,
            TProfilPeer::ALERT_RAPPORT_MENS_1,
        ),
        TProfilPeer::MODIF_DUREE_RDV => array(
            TProfilPeer::MODIF_DUREE_RDV_0,
            TProfilPeer::MODIF_DUREE_RDV_1,
        ),
        TProfilPeer::AFFECTATION_RDV => array(
            TProfilPeer::AFFECTATION_RDV_0,
            TProfilPeer::AFFECTATION_RDV_1,
        ),
        TProfilPeer::ANNULATION_RDV => array(
            TProfilPeer::ANNULATION_RDV_0,
            TProfilPeer::ANNULATION_RDV_1,
        ),
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = TProfilPeer::getFieldNames($toType);
        $key = isset(TProfilPeer::$fieldKeys[$fromType][$name]) ? TProfilPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(TProfilPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, TProfilPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return TProfilPeer::$fieldNames[$type];
    }

    /**
     * Gets the list of values for all ENUM columns
     * @return array
     */
    public static function getValueSets()
    {
      return TProfilPeer::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM column
     *
     * @param string $colname The ENUM column name.
     *
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = TProfilPeer::getValueSets();

        if (!isset($valueSets[$colname])) {
            throw new PropelException(sprintf('Column "%s" has no ValueSet.', $colname));
        }

        return $valueSets[$colname];
    }

    /**
     * Gets the SQL value for the ENUM column value
     *
     * @param string $colname ENUM column name.
     * @param string $enumVal ENUM value.
     *
     * @return int            SQL value
     */
    public static function getSqlValueForEnum($colname, $enumVal)
    {
        $values = TProfilPeer::getValueSet($colname);
        if (!in_array($enumVal, $values)) {
            throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $colname));
        }
        return array_search($enumVal, $values);
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. TProfilPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(TProfilPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(TProfilPeer::ID_PROFIL);
            $criteria->addSelectColumn(TProfilPeer::ID_ORGANISATION);
            $criteria->addSelectColumn(TProfilPeer::CODE_LIBELLE_PROFIL);
            $criteria->addSelectColumn(TProfilPeer::ID_TYPE_PROFIL);
            $criteria->addSelectColumn(TProfilPeer::ORGANISATION);
            $criteria->addSelectColumn(TProfilPeer::ETABLISSEMENT);
            $criteria->addSelectColumn(TProfilPeer::REFERENTIEL_TYPE_PRESTATION);
            $criteria->addSelectColumn(TProfilPeer::PARAMETRAGE_PRESTATION);
            $criteria->addSelectColumn(TProfilPeer::NIVEAU_1);
            $criteria->addSelectColumn(TProfilPeer::NIVEAU_2);
            $criteria->addSelectColumn(TProfilPeer::NIVEAU_3);
            $criteria->addSelectColumn(TProfilPeer::JOURS_FERIES);
            $criteria->addSelectColumn(TProfilPeer::AGENDA);
            $criteria->addSelectColumn(TProfilPeer::JOURS_INDISPONIBILITES);
            $criteria->addSelectColumn(TProfilPeer::UTILISATEURS);
            $criteria->addSelectColumn(TProfilPeer::PROFILS);
            $criteria->addSelectColumn(TProfilPeer::GESTIONS_DES_RENDEZ_VOUS);
            $criteria->addSelectColumn(TProfilPeer::RAPPORT_NBR_RDV);
            $criteria->addSelectColumn(TProfilPeer::RAPPORT_DELAI_OBTENTION);
            $criteria->addSelectColumn(TProfilPeer::RAPPORT_ACTIVITE);
            $criteria->addSelectColumn(TProfilPeer::PERFORMANCE_GLOBALE);
            $criteria->addSelectColumn(TProfilPeer::REFERENTIEL_PRESTATION);
            $criteria->addSelectColumn(TProfilPeer::RECHERCHE_ETENDUE_RDV);
            $criteria->addSelectColumn(TProfilPeer::ALERT_RAPPORT_HEBDO);
            $criteria->addSelectColumn(TProfilPeer::ALERT_RAPPORT_MENS);
            $criteria->addSelectColumn(TProfilPeer::MODIF_DUREE_RDV);
            $criteria->addSelectColumn(TProfilPeer::AFFECTATION_RDV);
            $criteria->addSelectColumn(TProfilPeer::ANNULATION_RDV);
        } else {
            $criteria->addSelectColumn($alias . '.ID_PROFIL');
            $criteria->addSelectColumn($alias . '.ID_ORGANISATION');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_PROFIL');
            $criteria->addSelectColumn($alias . '.ID_TYPE_PROFIL');
            $criteria->addSelectColumn($alias . '.ORGANISATION');
            $criteria->addSelectColumn($alias . '.ETABLISSEMENT');
            $criteria->addSelectColumn($alias . '.REFERENTIEL_TYPE_PRESTATION');
            $criteria->addSelectColumn($alias . '.PARAMETRAGE_PRESTATION');
            $criteria->addSelectColumn($alias . '.NIVEAU_1');
            $criteria->addSelectColumn($alias . '.NIVEAU_2');
            $criteria->addSelectColumn($alias . '.NIVEAU_3');
            $criteria->addSelectColumn($alias . '.JOURS_FERIES');
            $criteria->addSelectColumn($alias . '.AGENDA');
            $criteria->addSelectColumn($alias . '.JOURS_INDISPONIBILITES');
            $criteria->addSelectColumn($alias . '.UTILISATEURS');
            $criteria->addSelectColumn($alias . '.PROFILS');
            $criteria->addSelectColumn($alias . '.GESTIONS_DES_RENDEZ_VOUS');
            $criteria->addSelectColumn($alias . '.RAPPORT_NBR_RDV');
            $criteria->addSelectColumn($alias . '.RAPPORT_DELAI_OBTENTION');
            $criteria->addSelectColumn($alias . '.RAPPORT_ACTIVITE');
            $criteria->addSelectColumn($alias . '.PERFORMANCE_GLOBALE');
            $criteria->addSelectColumn($alias . '.REFERENTIEL_PRESTATION');
            $criteria->addSelectColumn($alias . '.RECHERCHE_ETENDUE_RDV');
            $criteria->addSelectColumn($alias . '.ALERT_RAPPORT_HEBDO');
            $criteria->addSelectColumn($alias . '.ALERT_RAPPORT_MENS');
            $criteria->addSelectColumn($alias . '.MODIF_DUREE_RDV');
            $criteria->addSelectColumn($alias . '.AFFECTATION_RDV');
            $criteria->addSelectColumn($alias . '.ANNULATION_RDV');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(TProfilPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return                 TProfil
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = TProfilPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return TProfilPeer::populateObjects(TProfilPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            TProfilPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param      TProfil $obj A TProfil object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getIdProfil();
            } // if key === null
            TProfilPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A TProfil object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof TProfil) {
                $key = (string) $value->getIdProfil();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or TProfil object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(TProfilPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return   TProfil Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(TProfilPeer::$instances[$key])) {
                return TProfilPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references)
      {
        foreach (TProfilPeer::$instances as $instance)
        {
          $instance->clearAllReferences(true);
        }
      }
        TProfilPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to T_PROFIL
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = TProfilPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = TProfilPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                TProfilPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (TProfil object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = TProfilPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = TProfilPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + TProfilPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = TProfilPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            TProfilPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraduction table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraduction(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTypeProfil table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTypeProfil(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TProfil objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TProfil objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraduction(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TProfilPeer::DATABASE_NAME);
        }

        TProfilPeer::addSelectColumns($criteria);
        $startcol = TProfilPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TProfilPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TProfilPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TProfilPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TProfil) to $obj2 (TTraduction)
                $obj2->addTProfil($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TProfil objects pre-filled with their TOrganisation objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TProfil objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TProfilPeer::DATABASE_NAME);
        }

        TProfilPeer::addSelectColumns($criteria);
        $startcol = TProfilPeer::NUM_HYDRATE_COLUMNS;
        TOrganisationPeer::addSelectColumns($criteria);

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TProfilPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TProfilPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TProfilPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TOrganisationPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TOrganisationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TOrganisationPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TProfil) to $obj2 (TOrganisation)
                $obj2->addTProfil($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TProfil objects pre-filled with their TTypeProfil objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TProfil objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTypeProfil(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TProfilPeer::DATABASE_NAME);
        }

        TProfilPeer::addSelectColumns($criteria);
        $startcol = TProfilPeer::NUM_HYDRATE_COLUMNS;
        TTypeProfilPeer::addSelectColumns($criteria);

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TProfilPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TProfilPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TProfilPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTypeProfilPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTypeProfilPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTypeProfilPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTypeProfilPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TProfil) to $obj2 (TTypeProfil)
                $obj2->addTProfil($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of TProfil objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TProfil objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TProfilPeer::DATABASE_NAME);
        }

        TProfilPeer::addSelectColumns($criteria);
        $startcol2 = TProfilPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TTypeProfilPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTypeProfilPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TProfilPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TProfilPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TProfilPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined TTraduction rows

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (TProfil) to the collection in $obj2 (TTraduction)
                $obj2->addTProfil($obj1);
            } // if joined row not null

            // Add objects for joined TOrganisation rows

            $key3 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = TOrganisationPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = TOrganisationPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TOrganisationPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (TProfil) to the collection in $obj3 (TOrganisation)
                $obj3->addTProfil($obj1);
            } // if joined row not null

            // Add objects for joined TTypeProfil rows

            $key4 = TTypeProfilPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = TTypeProfilPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = TTypeProfilPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTypeProfilPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (TProfil) to the collection in $obj4 (TTypeProfil)
                $obj4->addTProfil($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraduction table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraduction(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TOrganisation table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTOrganisation(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTypeProfil table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTypeProfil(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TProfilPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TProfil objects pre-filled with all related objects except TTraduction.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TProfil objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraduction(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TProfilPeer::DATABASE_NAME);
        }

        TProfilPeer::addSelectColumns($criteria);
        $startcol2 = TProfilPeer::NUM_HYDRATE_COLUMNS;

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        TTypeProfilPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTypeProfilPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TProfilPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TProfilPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TProfilPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TOrganisation rows

                $key2 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TOrganisationPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TOrganisationPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TOrganisationPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TProfil) to the collection in $obj2 (TOrganisation)
                $obj2->addTProfil($obj1);

            } // if joined row is not null

                // Add objects for joined TTypeProfil rows

                $key3 = TTypeProfilPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTypeProfilPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTypeProfilPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTypeProfilPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TProfil) to the collection in $obj3 (TTypeProfil)
                $obj3->addTProfil($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TProfil objects pre-filled with all related objects except TOrganisation.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TProfil objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTOrganisation(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TProfilPeer::DATABASE_NAME);
        }

        TProfilPeer::addSelectColumns($criteria);
        $startcol2 = TProfilPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTypeProfilPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTypeProfilPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_TYPE_PROFIL, TTypeProfilPeer::ID_TYPE_PROFIL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TProfilPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TProfilPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TProfilPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TProfil) to the collection in $obj2 (TTraduction)
                $obj2->addTProfil($obj1);

            } // if joined row is not null

                // Add objects for joined TTypeProfil rows

                $key3 = TTypeProfilPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTypeProfilPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTypeProfilPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTypeProfilPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TProfil) to the collection in $obj3 (TTypeProfil)
                $obj3->addTProfil($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TProfil objects pre-filled with all related objects except TTypeProfil.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TProfil objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTypeProfil(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TProfilPeer::DATABASE_NAME);
        }

        TProfilPeer::addSelectColumns($criteria);
        $startcol2 = TProfilPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TOrganisationPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TOrganisationPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TProfilPeer::CODE_LIBELLE_PROFIL, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TProfilPeer::ID_ORGANISATION, TOrganisationPeer::ID_ORGANISATION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TProfilPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TProfilPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TProfilPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TProfilPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TProfil) to the collection in $obj2 (TTraduction)
                $obj2->addTProfil($obj1);

            } // if joined row is not null

                // Add objects for joined TOrganisation rows

                $key3 = TOrganisationPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TOrganisationPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TOrganisationPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TOrganisationPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TProfil) to the collection in $obj3 (TOrganisation)
                $obj3->addTProfil($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(TProfilPeer::DATABASE_NAME)->getTable(TProfilPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseTProfilPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseTProfilPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new TProfilTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return TProfilPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a TProfil or Criteria object.
     *
     * @param      mixed $values Criteria or TProfil object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from TProfil object
        }

        if ($criteria->containsKey(TProfilPeer::ID_PROFIL) && $criteria->keyContainsValue(TProfilPeer::ID_PROFIL) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.TProfilPeer::ID_PROFIL.')');
        }


        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a TProfil or Criteria object.
     *
     * @param      mixed $values Criteria or TProfil object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(TProfilPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(TProfilPeer::ID_PROFIL);
            $value = $criteria->remove(TProfilPeer::ID_PROFIL);
            if ($value) {
                $selectCriteria->add(TProfilPeer::ID_PROFIL, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(TProfilPeer::TABLE_NAME);
            }

        } else { // $values is TProfil object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the T_PROFIL table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(TProfilPeer::TABLE_NAME, $con, TProfilPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            TProfilPeer::clearInstancePool();
            TProfilPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a TProfil or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or TProfil object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            TProfilPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof TProfil) { // it's a model object
            // invalidate the cache for this single object
            TProfilPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(TProfilPeer::DATABASE_NAME);
            $criteria->add(TProfilPeer::ID_PROFIL, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                TProfilPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(TProfilPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            TProfilPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given TProfil object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param      TProfil $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(TProfilPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(TProfilPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(TProfilPeer::DATABASE_NAME, TProfilPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param      int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return TProfil
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = TProfilPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(TProfilPeer::DATABASE_NAME);
        $criteria->add(TProfilPeer::ID_PROFIL, $pk);

        $v = TProfilPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return TProfil[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(TProfilPeer::DATABASE_NAME);
            $criteria->add(TProfilPeer::ID_PROFIL, $pks, Criteria::IN);
            $objs = TProfilPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseTProfilPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseTProfilPeer::buildTableMap();

