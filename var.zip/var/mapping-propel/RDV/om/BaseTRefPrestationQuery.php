<?php


/**
 * Base class that represents a query for the 'T_REF_PRESTATION' table.
 *
 *
 *
 * @method TRefPrestationQuery orderByIdRefPrestation($order = Criteria::ASC) Order by the ID_REF_PRESTATION column
 * @method TRefPrestationQuery orderByIdOrganisation($order = Criteria::ASC) Order by the ID_ORGANISATION column
 * @method TRefPrestationQuery orderByCodeLibelle($order = Criteria::ASC) Order by the CODE_LIBELLE column
 * @method TRefPrestationQuery orderByDureeRdv($order = Criteria::ASC) Order by the DUREE_RDV column
 * @method TRefPrestationQuery orderByIdParametreForm($order = Criteria::ASC) Order by the ID_PARAMETRE_FORM column
 * @method TRefPrestationQuery orderByCodeAide($order = Criteria::ASC) Order by the CODE_AIDE column
 *
 * @method TRefPrestationQuery groupByIdRefPrestation() Group by the ID_REF_PRESTATION column
 * @method TRefPrestationQuery groupByIdOrganisation() Group by the ID_ORGANISATION column
 * @method TRefPrestationQuery groupByCodeLibelle() Group by the CODE_LIBELLE column
 * @method TRefPrestationQuery groupByDureeRdv() Group by the DUREE_RDV column
 * @method TRefPrestationQuery groupByIdParametreForm() Group by the ID_PARAMETRE_FORM column
 * @method TRefPrestationQuery groupByCodeAide() Group by the CODE_AIDE column
 *
 * @method TRefPrestationQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TRefPrestationQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TRefPrestationQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TRefPrestationQuery leftJoinTTraductionRelatedByCodeAide($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeAide relation
 * @method TRefPrestationQuery rightJoinTTraductionRelatedByCodeAide($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeAide relation
 * @method TRefPrestationQuery innerJoinTTraductionRelatedByCodeAide($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeAide relation
 *
 * @method TRefPrestationQuery leftJoinTTraductionRelatedByCodeLibelle($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionRelatedByCodeLibelle relation
 * @method TRefPrestationQuery rightJoinTTraductionRelatedByCodeLibelle($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionRelatedByCodeLibelle relation
 * @method TRefPrestationQuery innerJoinTTraductionRelatedByCodeLibelle($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionRelatedByCodeLibelle relation
 *
 * @method TRefPrestationQuery leftJoinTOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisation relation
 * @method TRefPrestationQuery rightJoinTOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisation relation
 * @method TRefPrestationQuery innerJoinTOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisation relation
 *
 * @method TRefPrestationQuery leftJoinTParametreForm($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreForm relation
 * @method TRefPrestationQuery rightJoinTParametreForm($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreForm relation
 * @method TRefPrestationQuery innerJoinTParametreForm($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreForm relation
 *
 * @method TRefPrestationQuery leftJoinTParametragePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametragePrestation relation
 * @method TRefPrestationQuery rightJoinTParametragePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametragePrestation relation
 * @method TRefPrestationQuery innerJoinTParametragePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametragePrestation relation
 *
 * @method TRefPrestationQuery leftJoinTPrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestation relation
 * @method TRefPrestationQuery rightJoinTPrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestation relation
 * @method TRefPrestationQuery innerJoinTPrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestation relation
 *
 * @method TRefPrestation findOne(PropelPDO $con = null) Return the first TRefPrestation matching the query
 * @method TRefPrestation findOneOrCreate(PropelPDO $con = null) Return the first TRefPrestation matching the query, or a new TRefPrestation object populated from the query conditions when no match is found
 *
 * @method TRefPrestation findOneByIdOrganisation(int $ID_ORGANISATION) Return the first TRefPrestation filtered by the ID_ORGANISATION column
 * @method TRefPrestation findOneByCodeLibelle(int $CODE_LIBELLE) Return the first TRefPrestation filtered by the CODE_LIBELLE column
 * @method TRefPrestation findOneByDureeRdv(int $DUREE_RDV) Return the first TRefPrestation filtered by the DUREE_RDV column
 * @method TRefPrestation findOneByIdParametreForm(int $ID_PARAMETRE_FORM) Return the first TRefPrestation filtered by the ID_PARAMETRE_FORM column
 * @method TRefPrestation findOneByCodeAide(int $CODE_AIDE) Return the first TRefPrestation filtered by the CODE_AIDE column
 *
 * @method array findByIdRefPrestation(int $ID_REF_PRESTATION) Return TRefPrestation objects filtered by the ID_REF_PRESTATION column
 * @method array findByIdOrganisation(int $ID_ORGANISATION) Return TRefPrestation objects filtered by the ID_ORGANISATION column
 * @method array findByCodeLibelle(int $CODE_LIBELLE) Return TRefPrestation objects filtered by the CODE_LIBELLE column
 * @method array findByDureeRdv(int $DUREE_RDV) Return TRefPrestation objects filtered by the DUREE_RDV column
 * @method array findByIdParametreForm(int $ID_PARAMETRE_FORM) Return TRefPrestation objects filtered by the ID_PARAMETRE_FORM column
 * @method array findByCodeAide(int $CODE_AIDE) Return TRefPrestation objects filtered by the CODE_AIDE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTRefPrestationQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTRefPrestationQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TRefPrestation', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TRefPrestationQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TRefPrestationQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TRefPrestationQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TRefPrestationQuery) {
            return $criteria;
        }
        $query = new TRefPrestationQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TRefPrestation|TRefPrestation[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TRefPrestationPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TRefPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TRefPrestation A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdRefPrestation($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TRefPrestation A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_REF_PRESTATION`, `ID_ORGANISATION`, `CODE_LIBELLE`, `DUREE_RDV`, `ID_PARAMETRE_FORM`, `CODE_AIDE` FROM `T_REF_PRESTATION` WHERE `ID_REF_PRESTATION` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TRefPrestation();
            $obj->hydrate($row);
            TRefPrestationPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TRefPrestation|TRefPrestation[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TRefPrestation[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_REF_PRESTATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdRefPrestation(1234); // WHERE ID_REF_PRESTATION = 1234
     * $query->filterByIdRefPrestation(array(12, 34)); // WHERE ID_REF_PRESTATION IN (12, 34)
     * $query->filterByIdRefPrestation(array('min' => 12)); // WHERE ID_REF_PRESTATION >= 12
     * $query->filterByIdRefPrestation(array('max' => 12)); // WHERE ID_REF_PRESTATION <= 12
     * </code>
     *
     * @param     mixed $idRefPrestation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByIdRefPrestation($idRefPrestation = null, $comparison = null)
    {
        if (is_array($idRefPrestation)) {
            $useMinMax = false;
            if (isset($idRefPrestation['min'])) {
                $this->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $idRefPrestation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idRefPrestation['max'])) {
                $this->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $idRefPrestation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $idRefPrestation, $comparison);
    }

    /**
     * Filter the query on the ID_ORGANISATION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdOrganisation(1234); // WHERE ID_ORGANISATION = 1234
     * $query->filterByIdOrganisation(array(12, 34)); // WHERE ID_ORGANISATION IN (12, 34)
     * $query->filterByIdOrganisation(array('min' => 12)); // WHERE ID_ORGANISATION >= 12
     * $query->filterByIdOrganisation(array('max' => 12)); // WHERE ID_ORGANISATION <= 12
     * </code>
     *
     * @see       filterByTOrganisation()
     *
     * @param     mixed $idOrganisation The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByIdOrganisation($idOrganisation = null, $comparison = null)
    {
        if (is_array($idOrganisation)) {
            $useMinMax = false;
            if (isset($idOrganisation['min'])) {
                $this->addUsingAlias(TRefPrestationPeer::ID_ORGANISATION, $idOrganisation['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idOrganisation['max'])) {
                $this->addUsingAlias(TRefPrestationPeer::ID_ORGANISATION, $idOrganisation['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRefPrestationPeer::ID_ORGANISATION, $idOrganisation, $comparison);
    }

    /**
     * Filter the query on the CODE_LIBELLE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeLibelle(1234); // WHERE CODE_LIBELLE = 1234
     * $query->filterByCodeLibelle(array(12, 34)); // WHERE CODE_LIBELLE IN (12, 34)
     * $query->filterByCodeLibelle(array('min' => 12)); // WHERE CODE_LIBELLE >= 12
     * $query->filterByCodeLibelle(array('max' => 12)); // WHERE CODE_LIBELLE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeLibelle()
     *
     * @param     mixed $codeLibelle The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByCodeLibelle($codeLibelle = null, $comparison = null)
    {
        if (is_array($codeLibelle)) {
            $useMinMax = false;
            if (isset($codeLibelle['min'])) {
                $this->addUsingAlias(TRefPrestationPeer::CODE_LIBELLE, $codeLibelle['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeLibelle['max'])) {
                $this->addUsingAlias(TRefPrestationPeer::CODE_LIBELLE, $codeLibelle['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRefPrestationPeer::CODE_LIBELLE, $codeLibelle, $comparison);
    }

    /**
     * Filter the query on the DUREE_RDV column
     *
     * Example usage:
     * <code>
     * $query->filterByDureeRdv(1234); // WHERE DUREE_RDV = 1234
     * $query->filterByDureeRdv(array(12, 34)); // WHERE DUREE_RDV IN (12, 34)
     * $query->filterByDureeRdv(array('min' => 12)); // WHERE DUREE_RDV >= 12
     * $query->filterByDureeRdv(array('max' => 12)); // WHERE DUREE_RDV <= 12
     * </code>
     *
     * @param     mixed $dureeRdv The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByDureeRdv($dureeRdv = null, $comparison = null)
    {
        if (is_array($dureeRdv)) {
            $useMinMax = false;
            if (isset($dureeRdv['min'])) {
                $this->addUsingAlias(TRefPrestationPeer::DUREE_RDV, $dureeRdv['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($dureeRdv['max'])) {
                $this->addUsingAlias(TRefPrestationPeer::DUREE_RDV, $dureeRdv['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRefPrestationPeer::DUREE_RDV, $dureeRdv, $comparison);
    }

    /**
     * Filter the query on the ID_PARAMETRE_FORM column
     *
     * Example usage:
     * <code>
     * $query->filterByIdParametreForm(1234); // WHERE ID_PARAMETRE_FORM = 1234
     * $query->filterByIdParametreForm(array(12, 34)); // WHERE ID_PARAMETRE_FORM IN (12, 34)
     * $query->filterByIdParametreForm(array('min' => 12)); // WHERE ID_PARAMETRE_FORM >= 12
     * $query->filterByIdParametreForm(array('max' => 12)); // WHERE ID_PARAMETRE_FORM <= 12
     * </code>
     *
     * @see       filterByTParametreForm()
     *
     * @param     mixed $idParametreForm The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByIdParametreForm($idParametreForm = null, $comparison = null)
    {
        if (is_array($idParametreForm)) {
            $useMinMax = false;
            if (isset($idParametreForm['min'])) {
                $this->addUsingAlias(TRefPrestationPeer::ID_PARAMETRE_FORM, $idParametreForm['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idParametreForm['max'])) {
                $this->addUsingAlias(TRefPrestationPeer::ID_PARAMETRE_FORM, $idParametreForm['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRefPrestationPeer::ID_PARAMETRE_FORM, $idParametreForm, $comparison);
    }

    /**
     * Filter the query on the CODE_AIDE column
     *
     * Example usage:
     * <code>
     * $query->filterByCodeAide(1234); // WHERE CODE_AIDE = 1234
     * $query->filterByCodeAide(array(12, 34)); // WHERE CODE_AIDE IN (12, 34)
     * $query->filterByCodeAide(array('min' => 12)); // WHERE CODE_AIDE >= 12
     * $query->filterByCodeAide(array('max' => 12)); // WHERE CODE_AIDE <= 12
     * </code>
     *
     * @see       filterByTTraductionRelatedByCodeAide()
     *
     * @param     mixed $codeAide The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function filterByCodeAide($codeAide = null, $comparison = null)
    {
        if (is_array($codeAide)) {
            $useMinMax = false;
            if (isset($codeAide['min'])) {
                $this->addUsingAlias(TRefPrestationPeer::CODE_AIDE, $codeAide['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($codeAide['max'])) {
                $this->addUsingAlias(TRefPrestationPeer::CODE_AIDE, $codeAide['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TRefPrestationPeer::CODE_AIDE, $codeAide, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRefPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeAide($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TRefPrestationPeer::CODE_AIDE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRefPrestationPeer::CODE_AIDE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeAide() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeAide relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeAide($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeAide');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeAide');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeAide relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeAideQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeAide($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeAide', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRefPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionRelatedByCodeLibelle($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TRefPrestationPeer::CODE_LIBELLE, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRefPrestationPeer::CODE_LIBELLE, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraductionRelatedByCodeLibelle() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionRelatedByCodeLibelle relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function joinTTraductionRelatedByCodeLibelle($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionRelatedByCodeLibelle');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionRelatedByCodeLibelle');
        }

        return $this;
    }

    /**
     * Use the TTraductionRelatedByCodeLibelle relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionRelatedByCodeLibelleQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraductionRelatedByCodeLibelle($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionRelatedByCodeLibelle', 'TTraductionQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRefPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TRefPrestationPeer::ID_ORGANISATION, $tOrganisation->getIdOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRefPrestationPeer::ID_ORGANISATION, $tOrganisation->toKeyValue('PrimaryKey', 'IdOrganisation'), $comparison);
        } else {
            throw new PropelException('filterByTOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function joinTOrganisation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRefPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreForm($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TRefPrestationPeer::ID_PARAMETRE_FORM, $tParametreForm->getIdParametreForm(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TRefPrestationPeer::ID_PARAMETRE_FORM, $tParametreForm->toKeyValue('PrimaryKey', 'IdParametreForm'), $comparison);
        } else {
            throw new PropelException('filterByTParametreForm() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreForm relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function joinTParametreForm($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreForm');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreForm');
        }

        return $this;
    }

    /**
     * Use the TParametreForm relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreForm($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreForm', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TParametragePrestation object
     *
     * @param   TParametragePrestation|PropelObjectCollection $tParametragePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRefPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametragePrestation($tParametragePrestation, $comparison = null)
    {
        if ($tParametragePrestation instanceof TParametragePrestation) {
            return $this
                ->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $tParametragePrestation->getIdRefPrestation(), $comparison);
        } elseif ($tParametragePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTParametragePrestationQuery()
                ->filterByPrimaryKeys($tParametragePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametragePrestation() only accepts arguments of type TParametragePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametragePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function joinTParametragePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametragePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametragePrestation');
        }

        return $this;
    }

    /**
     * Use the TParametragePrestation relation TParametragePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametragePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTParametragePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTParametragePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametragePrestation', 'TParametragePrestationQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TRefPrestationQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $tPrestation->getIdRefPrestation(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTPrestationQuery()
                ->filterByPrimaryKeys($tPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function joinTPrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTPrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestation', 'TPrestationQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TRefPrestation $tRefPrestation Object to remove from the list of results
     *
     * @return TRefPrestationQuery The current query, for fluid interface
     */
    public function prune($tRefPrestation = null)
    {
        if ($tRefPrestation) {
            $this->addUsingAlias(TRefPrestationPeer::ID_REF_PRESTATION, $tRefPrestation->getIdRefPrestation(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
