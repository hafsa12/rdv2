<?php


/**
 * Base class that represents a query for the 'T_TRADUCTION_LIBELLE' table.
 *
 *
 *
 * @method TTraductionLibelleQuery orderByIdTraduction($order = Criteria::ASC) Order by the ID_TRADUCTION column
 * @method TTraductionLibelleQuery orderByLang($order = Criteria::ASC) Order by the LANG column
 * @method TTraductionLibelleQuery orderByLibelle($order = Criteria::ASC) Order by the LIBELLE column
 *
 * @method TTraductionLibelleQuery groupByIdTraduction() Group by the ID_TRADUCTION column
 * @method TTraductionLibelleQuery groupByLang() Group by the LANG column
 * @method TTraductionLibelleQuery groupByLibelle() Group by the LIBELLE column
 *
 * @method TTraductionLibelleQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TTraductionLibelleQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TTraductionLibelleQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TTraductionLibelleQuery leftJoinTTraduction($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraduction relation
 * @method TTraductionLibelleQuery rightJoinTTraduction($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraduction relation
 * @method TTraductionLibelleQuery innerJoinTTraduction($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraduction relation
 *
 * @method TTraductionLibelle findOne(PropelPDO $con = null) Return the first TTraductionLibelle matching the query
 * @method TTraductionLibelle findOneOrCreate(PropelPDO $con = null) Return the first TTraductionLibelle matching the query, or a new TTraductionLibelle object populated from the query conditions when no match is found
 *
 * @method TTraductionLibelle findOneByIdTraduction(int $ID_TRADUCTION) Return the first TTraductionLibelle filtered by the ID_TRADUCTION column
 * @method TTraductionLibelle findOneByLang(string $LANG) Return the first TTraductionLibelle filtered by the LANG column
 * @method TTraductionLibelle findOneByLibelle(string $LIBELLE) Return the first TTraductionLibelle filtered by the LIBELLE column
 *
 * @method array findByIdTraduction(int $ID_TRADUCTION) Return TTraductionLibelle objects filtered by the ID_TRADUCTION column
 * @method array findByLang(string $LANG) Return TTraductionLibelle objects filtered by the LANG column
 * @method array findByLibelle(string $LIBELLE) Return TTraductionLibelle objects filtered by the LIBELLE column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTTraductionLibelleQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTTraductionLibelleQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TTraductionLibelle', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TTraductionLibelleQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TTraductionLibelleQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TTraductionLibelleQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TTraductionLibelleQuery) {
            return $criteria;
        }
        $query = new TTraductionLibelleQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj = $c->findPk(array(12, 34), $con);
     * </code>
     *
     * @param array $key Primary key to use for the query
                         A Primary key composition: [$ID_TRADUCTION, $LANG]
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TTraductionLibelle|TTraductionLibelle[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TTraductionLibellePeer::getInstanceFromPool(serialize(array((string) $key[0], (string) $key[1]))))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TTraductionLibellePeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TTraductionLibelle A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_TRADUCTION`, `LANG`, `LIBELLE` FROM `T_TRADUCTION_LIBELLE` WHERE `ID_TRADUCTION` = :p0 AND `LANG` = :p1';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key[0], PDO::PARAM_INT);
            $stmt->bindValue(':p1', $key[1], PDO::PARAM_STR);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TTraductionLibelle();
            $obj->hydrate($row);
            TTraductionLibellePeer::addInstanceToPool($obj, serialize(array((string) $key[0], (string) $key[1])));
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TTraductionLibelle|TTraductionLibelle[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(array(12, 56), array(832, 123), array(123, 456)), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TTraductionLibelle[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TTraductionLibelleQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {
        $this->addUsingAlias(TTraductionLibellePeer::ID_TRADUCTION, $key[0], Criteria::EQUAL);
        $this->addUsingAlias(TTraductionLibellePeer::LANG, $key[1], Criteria::EQUAL);

        return $this;
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TTraductionLibelleQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {
        if (empty($keys)) {
            return $this->add(null, '1<>1', Criteria::CUSTOM);
        }
        foreach ($keys as $key) {
            $cton0 = $this->getNewCriterion(TTraductionLibellePeer::ID_TRADUCTION, $key[0], Criteria::EQUAL);
            $cton1 = $this->getNewCriterion(TTraductionLibellePeer::LANG, $key[1], Criteria::EQUAL);
            $cton0->addAnd($cton1);
            $this->addOr($cton0);
        }

        return $this;
    }

    /**
     * Filter the query on the ID_TRADUCTION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdTraduction(1234); // WHERE ID_TRADUCTION = 1234
     * $query->filterByIdTraduction(array(12, 34)); // WHERE ID_TRADUCTION IN (12, 34)
     * $query->filterByIdTraduction(array('min' => 12)); // WHERE ID_TRADUCTION >= 12
     * $query->filterByIdTraduction(array('max' => 12)); // WHERE ID_TRADUCTION <= 12
     * </code>
     *
     * @see       filterByTTraduction()
     *
     * @param     mixed $idTraduction The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TTraductionLibelleQuery The current query, for fluid interface
     */
    public function filterByIdTraduction($idTraduction = null, $comparison = null)
    {
        if (is_array($idTraduction)) {
            $useMinMax = false;
            if (isset($idTraduction['min'])) {
                $this->addUsingAlias(TTraductionLibellePeer::ID_TRADUCTION, $idTraduction['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idTraduction['max'])) {
                $this->addUsingAlias(TTraductionLibellePeer::ID_TRADUCTION, $idTraduction['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TTraductionLibellePeer::ID_TRADUCTION, $idTraduction, $comparison);
    }

    /**
     * Filter the query on the LANG column
     *
     * Example usage:
     * <code>
     * $query->filterByLang('fooValue');   // WHERE LANG = 'fooValue'
     * $query->filterByLang('%fooValue%'); // WHERE LANG LIKE '%fooValue%'
     * </code>
     *
     * @param     string $lang The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TTraductionLibelleQuery The current query, for fluid interface
     */
    public function filterByLang($lang = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($lang)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $lang)) {
                $lang = str_replace('*', '%', $lang);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TTraductionLibellePeer::LANG, $lang, $comparison);
    }

    /**
     * Filter the query on the LIBELLE column
     *
     * Example usage:
     * <code>
     * $query->filterByLibelle('fooValue');   // WHERE LIBELLE = 'fooValue'
     * $query->filterByLibelle('%fooValue%'); // WHERE LIBELLE LIKE '%fooValue%'
     * </code>
     *
     * @param     string $libelle The value to use as filter.
     *              Accepts wildcards (* and % trigger a LIKE)
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TTraductionLibelleQuery The current query, for fluid interface
     */
    public function filterByLibelle($libelle = null, $comparison = null)
    {
        if (null === $comparison) {
            if (is_array($libelle)) {
                $comparison = Criteria::IN;
            } elseif (preg_match('/[\%\*]/', $libelle)) {
                $libelle = str_replace('*', '%', $libelle);
                $comparison = Criteria::LIKE;
            }
        }

        return $this->addUsingAlias(TTraductionLibellePeer::LIBELLE, $libelle, $comparison);
    }

    /**
     * Filter the query by a related TTraduction object
     *
     * @param   TTraduction|PropelObjectCollection $tTraduction The related object(s) to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionLibelleQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraduction($tTraduction, $comparison = null)
    {
        if ($tTraduction instanceof TTraduction) {
            return $this
                ->addUsingAlias(TTraductionLibellePeer::ID_TRADUCTION, $tTraduction->getIdTraduction(), $comparison);
        } elseif ($tTraduction instanceof PropelObjectCollection) {
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }

            return $this
                ->addUsingAlias(TTraductionLibellePeer::ID_TRADUCTION, $tTraduction->toKeyValue('PrimaryKey', 'IdTraduction'), $comparison);
        } else {
            throw new PropelException('filterByTTraduction() only accepts arguments of type TTraduction or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraduction relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionLibelleQuery The current query, for fluid interface
     */
    public function joinTTraduction($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraduction');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraduction');
        }

        return $this;
    }

    /**
     * Use the TTraduction relation TTraduction object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraduction($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraduction', 'TTraductionQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TTraductionLibelle $tTraductionLibelle Object to remove from the list of results
     *
     * @return TTraductionLibelleQuery The current query, for fluid interface
     */
    public function prune($tTraductionLibelle = null)
    {
        if ($tTraductionLibelle) {
            $this->addCond('pruneCond0', $this->getAliasedColName(TTraductionLibellePeer::ID_TRADUCTION), $tTraductionLibelle->getIdTraduction(), Criteria::NOT_EQUAL);
            $this->addCond('pruneCond1', $this->getAliasedColName(TTraductionLibellePeer::LANG), $tTraductionLibelle->getLang(), Criteria::NOT_EQUAL);
            $this->combine(array('pruneCond0', 'pruneCond1'), Criteria::LOGICAL_OR);
        }

        return $this;
    }

}
