<?php


/**
 * Base class that represents a row from the 'T_PIECE_PRESTATION' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPiecePrestation extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TPiecePrestationPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TPiecePrestationPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_piece field.
     * @var        int
     */
    protected $id_piece;

    /**
     * The value for the id_prestation field.
     * @var        int
     */
    protected $id_prestation;

    /**
     * The value for the code_libelle_piece field.
     * @var        int
     */
    protected $code_libelle_piece;

    /**
     * The value for the id_blob_piece field.
     * @var        int
     */
    protected $id_blob_piece;

    /**
     * The value for the obligatoire field.
     * Note: this column has a database default value of: '1'
     * @var        string
     */
    protected $obligatoire;

    /**
     * @var        TTraduction
     */
    protected $aTTraduction;

    /**
     * @var        TBlob
     */
    protected $aTBlob;

    /**
     * @var        TPrestation
     */
    protected $aTPrestation;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->obligatoire = '1';
    }

    /**
     * Initializes internal state of BaseTPiecePrestation object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_piece] column value.
     *
     * @return int
     */
    public function getIdPiece()
    {
        return $this->id_piece;
    }

    /**
     * Get the [id_prestation] column value.
     *
     * @return int
     */
    public function getIdPrestation()
    {
        return $this->id_prestation;
    }

    /**
     * Get the [code_libelle_piece] column value.
     *
     * @return int
     */
    public function getCodeLibellePiece()
    {
        return $this->code_libelle_piece;
    }

    /**
     * Get the [id_blob_piece] column value.
     *
     * @return int
     */
    public function getIdBlobPiece()
    {
        return $this->id_blob_piece;
    }

    /**
     * Get the [obligatoire] column value.
     *
     * @return string
     */
    public function getObligatoire()
    {
        return $this->obligatoire;
    }

    /**
     * Set the value of [id_piece] column.
     *
     * @param int $v new value
     * @return TPiecePrestation The current object (for fluent API support)
     */
    public function setIdPiece($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_piece !== $v) {
            $this->id_piece = $v;
            $this->modifiedColumns[] = TPiecePrestationPeer::ID_PIECE;
        }


        return $this;
    } // setIdPiece()

    /**
     * Set the value of [id_prestation] column.
     *
     * @param int $v new value
     * @return TPiecePrestation The current object (for fluent API support)
     */
    public function setIdPrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_prestation !== $v) {
            $this->id_prestation = $v;
            $this->modifiedColumns[] = TPiecePrestationPeer::ID_PRESTATION;
        }

        if ($this->aTPrestation !== null && $this->aTPrestation->getIdPrestation() !== $v) {
            $this->aTPrestation = null;
        }


        return $this;
    } // setIdPrestation()

    /**
     * Set the value of [code_libelle_piece] column.
     *
     * @param int $v new value
     * @return TPiecePrestation The current object (for fluent API support)
     */
    public function setCodeLibellePiece($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_piece !== $v) {
            $this->code_libelle_piece = $v;
            $this->modifiedColumns[] = TPiecePrestationPeer::CODE_LIBELLE_PIECE;
        }

        if ($this->aTTraduction !== null && $this->aTTraduction->getIdTraduction() !== $v) {
            $this->aTTraduction = null;
        }


        return $this;
    } // setCodeLibellePiece()

    /**
     * Set the value of [id_blob_piece] column.
     *
     * @param int $v new value
     * @return TPiecePrestation The current object (for fluent API support)
     */
    public function setIdBlobPiece($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_blob_piece !== $v) {
            $this->id_blob_piece = $v;
            $this->modifiedColumns[] = TPiecePrestationPeer::ID_BLOB_PIECE;
        }

        if ($this->aTBlob !== null && $this->aTBlob->getIdBlob() !== $v) {
            $this->aTBlob = null;
        }


        return $this;
    } // setIdBlobPiece()

    /**
     * Set the value of [obligatoire] column.
     *
     * @param string $v new value
     * @return TPiecePrestation The current object (for fluent API support)
     */
    public function setObligatoire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire !== $v) {
            $this->obligatoire = $v;
            $this->modifiedColumns[] = TPiecePrestationPeer::OBLIGATOIRE;
        }


        return $this;
    } // setObligatoire()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->obligatoire !== '1') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_piece = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->id_prestation = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->code_libelle_piece = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->id_blob_piece = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->obligatoire = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 5; // 5 = TPiecePrestationPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TPiecePrestation object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTPrestation !== null && $this->id_prestation !== $this->aTPrestation->getIdPrestation()) {
            $this->aTPrestation = null;
        }
        if ($this->aTTraduction !== null && $this->code_libelle_piece !== $this->aTTraduction->getIdTraduction()) {
            $this->aTTraduction = null;
        }
        if ($this->aTBlob !== null && $this->id_blob_piece !== $this->aTBlob->getIdBlob()) {
            $this->aTBlob = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPiecePrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TPiecePrestationPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraduction = null;
            $this->aTBlob = null;
            $this->aTPrestation = null;
        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPiecePrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TPiecePrestationQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPiecePrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TPiecePrestationPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if ($this->aTTraduction->isModified() || $this->aTTraduction->isNew()) {
                    $affectedRows += $this->aTTraduction->save($con);
                }
                $this->setTTraduction($this->aTTraduction);
            }

            if ($this->aTBlob !== null) {
                if ($this->aTBlob->isModified() || $this->aTBlob->isNew()) {
                    $affectedRows += $this->aTBlob->save($con);
                }
                $this->setTBlob($this->aTBlob);
            }

            if ($this->aTPrestation !== null) {
                if ($this->aTPrestation->isModified() || $this->aTPrestation->isNew()) {
                    $affectedRows += $this->aTPrestation->save($con);
                }
                $this->setTPrestation($this->aTPrestation);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TPiecePrestationPeer::ID_PIECE;
        if (null !== $this->id_piece) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TPiecePrestationPeer::ID_PIECE . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TPiecePrestationPeer::ID_PIECE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PIECE`';
        }
        if ($this->isColumnModified(TPiecePrestationPeer::ID_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PRESTATION`';
        }
        if ($this->isColumnModified(TPiecePrestationPeer::CODE_LIBELLE_PIECE)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_PIECE`';
        }
        if ($this->isColumnModified(TPiecePrestationPeer::ID_BLOB_PIECE)) {
            $modifiedColumns[':p' . $index++]  = '`ID_BLOB_PIECE`';
        }
        if ($this->isColumnModified(TPiecePrestationPeer::OBLIGATOIRE)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE`';
        }

        $sql = sprintf(
            'INSERT INTO `T_PIECE_PRESTATION` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_PIECE`':
                        $stmt->bindValue($identifier, $this->id_piece, PDO::PARAM_INT);
                        break;
                    case '`ID_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_prestation, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_PIECE`':
                        $stmt->bindValue($identifier, $this->code_libelle_piece, PDO::PARAM_INT);
                        break;
                    case '`ID_BLOB_PIECE`':
                        $stmt->bindValue($identifier, $this->id_blob_piece, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE`':
                        $stmt->bindValue($identifier, $this->obligatoire, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdPiece($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if (!$this->aTTraduction->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraduction->getValidationFailures());
                }
            }

            if ($this->aTBlob !== null) {
                if (!$this->aTBlob->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTBlob->getValidationFailures());
                }
            }

            if ($this->aTPrestation !== null) {
                if (!$this->aTPrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTPrestation->getValidationFailures());
                }
            }


            if (($retval = TPiecePrestationPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }



            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TPiecePrestationPeer::DATABASE_NAME);

        if ($this->isColumnModified(TPiecePrestationPeer::ID_PIECE)) $criteria->add(TPiecePrestationPeer::ID_PIECE, $this->id_piece);
        if ($this->isColumnModified(TPiecePrestationPeer::ID_PRESTATION)) $criteria->add(TPiecePrestationPeer::ID_PRESTATION, $this->id_prestation);
        if ($this->isColumnModified(TPiecePrestationPeer::CODE_LIBELLE_PIECE)) $criteria->add(TPiecePrestationPeer::CODE_LIBELLE_PIECE, $this->code_libelle_piece);
        if ($this->isColumnModified(TPiecePrestationPeer::ID_BLOB_PIECE)) $criteria->add(TPiecePrestationPeer::ID_BLOB_PIECE, $this->id_blob_piece);
        if ($this->isColumnModified(TPiecePrestationPeer::OBLIGATOIRE)) $criteria->add(TPiecePrestationPeer::OBLIGATOIRE, $this->obligatoire);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TPiecePrestationPeer::DATABASE_NAME);
        $criteria->add(TPiecePrestationPeer::ID_PIECE, $this->id_piece);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdPiece();
    }

    /**
     * Generic method to set the primary key (id_piece column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdPiece($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdPiece();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TPiecePrestation (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setIdPrestation($this->getIdPrestation());
        $copyObj->setCodeLibellePiece($this->getCodeLibellePiece());
        $copyObj->setIdBlobPiece($this->getIdBlobPiece());
        $copyObj->setObligatoire($this->getObligatoire());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdPiece(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TPiecePrestation Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TPiecePrestationPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TPiecePrestationPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TPiecePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraduction(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibellePiece(NULL);
        } else {
            $this->setCodeLibellePiece($v->getIdTraduction());
        }

        $this->aTTraduction = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTPiecePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraduction(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraduction === null && ($this->code_libelle_piece !== null) && $doQuery) {
            $this->aTTraduction = TTraductionQuery::create()->findPk($this->code_libelle_piece, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraduction->addTPiecePrestations($this);
             */
        }

        return $this->aTTraduction;
    }

    /**
     * Declares an association between this object and a TBlob object.
     *
     * @param             TBlob $v
     * @return TPiecePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTBlob(TBlob $v = null)
    {
        if ($v === null) {
            $this->setIdBlobPiece(NULL);
        } else {
            $this->setIdBlobPiece($v->getIdBlob());
        }

        $this->aTBlob = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TBlob object, it will not be re-added.
        if ($v !== null) {
            $v->addTPiecePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TBlob object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TBlob The associated TBlob object.
     * @throws PropelException
     */
    public function getTBlob(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTBlob === null && ($this->id_blob_piece !== null) && $doQuery) {
            $this->aTBlob = TBlobQuery::create()->findPk($this->id_blob_piece, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTBlob->addTPiecePrestations($this);
             */
        }

        return $this->aTBlob;
    }

    /**
     * Declares an association between this object and a TPrestation object.
     *
     * @param             TPrestation $v
     * @return TPiecePrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTPrestation(TPrestation $v = null)
    {
        if ($v === null) {
            $this->setIdPrestation(NULL);
        } else {
            $this->setIdPrestation($v->getIdPrestation());
        }

        $this->aTPrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TPrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTPiecePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TPrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TPrestation The associated TPrestation object.
     * @throws PropelException
     */
    public function getTPrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTPrestation === null && ($this->id_prestation !== null) && $doQuery) {
            $this->aTPrestation = TPrestationQuery::create()->findPk($this->id_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTPrestation->addTPiecePrestations($this);
             */
        }

        return $this->aTPrestation;
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_piece = null;
        $this->id_prestation = null;
        $this->code_libelle_piece = null;
        $this->id_blob_piece = null;
        $this->obligatoire = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->aTTraduction instanceof Persistent) {
              $this->aTTraduction->clearAllReferences($deep);
            }
            if ($this->aTBlob instanceof Persistent) {
              $this->aTBlob->clearAllReferences($deep);
            }
            if ($this->aTPrestation instanceof Persistent) {
              $this->aTPrestation->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        $this->aTTraduction = null;
        $this->aTBlob = null;
        $this->aTPrestation = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TPiecePrestationPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
