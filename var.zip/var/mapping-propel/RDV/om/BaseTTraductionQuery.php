<?php


/**
 * Base class that represents a query for the 'T_TRADUCTION' table.
 *
 *
 *
 * @method TTraductionQuery orderByIdTraduction($order = Criteria::ASC) Order by the ID_TRADUCTION column
 *
 * @method TTraductionQuery groupByIdTraduction() Group by the ID_TRADUCTION column
 *
 * @method TTraductionQuery leftJoin($relation) Adds a LEFT JOIN clause to the query
 * @method TTraductionQuery rightJoin($relation) Adds a RIGHT JOIN clause to the query
 * @method TTraductionQuery innerJoin($relation) Adds a INNER JOIN clause to the query
 *
 * @method TTraductionQuery leftJoinTAgentRelatedByCodeNomUtilisateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByCodeNomUtilisateur relation
 * @method TTraductionQuery rightJoinTAgentRelatedByCodeNomUtilisateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByCodeNomUtilisateur relation
 * @method TTraductionQuery innerJoinTAgentRelatedByCodeNomUtilisateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByCodeNomUtilisateur relation
 *
 * @method TTraductionQuery leftJoinTAgentRelatedByCodePrenomUtilisateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByCodePrenomUtilisateur relation
 * @method TTraductionQuery rightJoinTAgentRelatedByCodePrenomUtilisateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByCodePrenomUtilisateur relation
 * @method TTraductionQuery innerJoinTAgentRelatedByCodePrenomUtilisateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByCodePrenomUtilisateur relation
 *
 * @method TTraductionQuery leftJoinTAgentRelatedByCodeUtilisateur($relationAlias = null) Adds a LEFT JOIN clause to the query using the TAgentRelatedByCodeUtilisateur relation
 * @method TTraductionQuery rightJoinTAgentRelatedByCodeUtilisateur($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TAgentRelatedByCodeUtilisateur relation
 * @method TTraductionQuery innerJoinTAgentRelatedByCodeUtilisateur($relationAlias = null) Adds a INNER JOIN clause to the query using the TAgentRelatedByCodeUtilisateur relation
 *
 * @method TTraductionQuery leftJoinTChampsSupp($relationAlias = null) Adds a LEFT JOIN clause to the query using the TChampsSupp relation
 * @method TTraductionQuery rightJoinTChampsSupp($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TChampsSupp relation
 * @method TTraductionQuery innerJoinTChampsSupp($relationAlias = null) Adds a INNER JOIN clause to the query using the TChampsSupp relation
 *
 * @method TTraductionQuery leftJoinTEntite($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEntite relation
 * @method TTraductionQuery rightJoinTEntite($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEntite relation
 * @method TTraductionQuery innerJoinTEntite($relationAlias = null) Adds a INNER JOIN clause to the query using the TEntite relation
 *
 * @method TTraductionQuery leftJoinTEtablissementRelatedByCodeAdresseEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissementRelatedByCodeAdresseEtablissement relation
 * @method TTraductionQuery rightJoinTEtablissementRelatedByCodeAdresseEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissementRelatedByCodeAdresseEtablissement relation
 * @method TTraductionQuery innerJoinTEtablissementRelatedByCodeAdresseEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissementRelatedByCodeAdresseEtablissement relation
 *
 * @method TTraductionQuery leftJoinTEtablissementRelatedByCodeDenominationEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissementRelatedByCodeDenominationEtablissement relation
 * @method TTraductionQuery rightJoinTEtablissementRelatedByCodeDenominationEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissementRelatedByCodeDenominationEtablissement relation
 * @method TTraductionQuery innerJoinTEtablissementRelatedByCodeDenominationEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissementRelatedByCodeDenominationEtablissement relation
 *
 * @method TTraductionQuery leftJoinTEtablissementRelatedByCodeDescriptionEtablissement($relationAlias = null) Adds a LEFT JOIN clause to the query using the TEtablissementRelatedByCodeDescriptionEtablissement relation
 * @method TTraductionQuery rightJoinTEtablissementRelatedByCodeDescriptionEtablissement($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TEtablissementRelatedByCodeDescriptionEtablissement relation
 * @method TTraductionQuery innerJoinTEtablissementRelatedByCodeDescriptionEtablissement($relationAlias = null) Adds a INNER JOIN clause to the query using the TEtablissementRelatedByCodeDescriptionEtablissement relation
 *
 * @method TTraductionQuery leftJoinTGroupe($relationAlias = null) Adds a LEFT JOIN clause to the query using the TGroupe relation
 * @method TTraductionQuery rightJoinTGroupe($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TGroupe relation
 * @method TTraductionQuery innerJoinTGroupe($relationAlias = null) Adds a INNER JOIN clause to the query using the TGroupe relation
 *
 * @method TTraductionQuery leftJoinTJourFerie($relationAlias = null) Adds a LEFT JOIN clause to the query using the TJourFerie relation
 * @method TTraductionQuery rightJoinTJourFerie($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TJourFerie relation
 * @method TTraductionQuery innerJoinTJourFerie($relationAlias = null) Adds a INNER JOIN clause to the query using the TJourFerie relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeAdresseOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeAdresseOrganisation relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeAdresseOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeAdresseOrganisation relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeAdresseOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeAdresseOrganisation relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeDenominationOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeDenominationOrganisation relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeDenominationOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeDenominationOrganisation relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeDenominationOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeDenominationOrganisation relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeDescriptionOrganisation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeDescriptionOrganisation relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeDescriptionOrganisation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeDescriptionOrganisation relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeDescriptionOrganisation($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeDescriptionOrganisation relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeLibelleLien1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien1 relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeLibelleLien1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien1 relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeLibelleLien1($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien1 relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeLibelleLien2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien2 relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeLibelleLien2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien2 relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeLibelleLien2($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien2 relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeLibelleLien3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien3 relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeLibelleLien3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien3 relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeLibelleLien3($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien3 relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeMessageBienvenue($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeMessageBienvenue relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeMessageBienvenue($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeMessageBienvenue relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeMessageBienvenue($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeMessageBienvenue relation
 *
 * @method TTraductionQuery leftJoinTOrganisationRelatedByCodeTitreBienvenue($relationAlias = null) Adds a LEFT JOIN clause to the query using the TOrganisationRelatedByCodeTitreBienvenue relation
 * @method TTraductionQuery rightJoinTOrganisationRelatedByCodeTitreBienvenue($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TOrganisationRelatedByCodeTitreBienvenue relation
 * @method TTraductionQuery innerJoinTOrganisationRelatedByCodeTitreBienvenue($relationAlias = null) Adds a INNER JOIN clause to the query using the TOrganisationRelatedByCodeTitreBienvenue relation
 *
 * @method TTraductionQuery leftJoinTParametragePrestationRelatedByCodeCommentaire($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametragePrestationRelatedByCodeCommentaire relation
 * @method TTraductionQuery rightJoinTParametragePrestationRelatedByCodeCommentaire($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametragePrestationRelatedByCodeCommentaire relation
 * @method TTraductionQuery innerJoinTParametragePrestationRelatedByCodeCommentaire($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametragePrestationRelatedByCodeCommentaire relation
 *
 * @method TTraductionQuery leftJoinTParametragePrestationRelatedByCodeAide($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametragePrestationRelatedByCodeAide relation
 * @method TTraductionQuery rightJoinTParametragePrestationRelatedByCodeAide($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametragePrestationRelatedByCodeAide relation
 * @method TTraductionQuery innerJoinTParametragePrestationRelatedByCodeAide($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametragePrestationRelatedByCodeAide relation
 *
 * @method TTraductionQuery leftJoinTParametreFormRelatedByCodeCommentaire($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreFormRelatedByCodeCommentaire relation
 * @method TTraductionQuery rightJoinTParametreFormRelatedByCodeCommentaire($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreFormRelatedByCodeCommentaire relation
 * @method TTraductionQuery innerJoinTParametreFormRelatedByCodeCommentaire($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreFormRelatedByCodeCommentaire relation
 *
 * @method TTraductionQuery leftJoinTParametreFormRelatedByCodeLibelleRef1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef1 relation
 * @method TTraductionQuery rightJoinTParametreFormRelatedByCodeLibelleRef1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef1 relation
 * @method TTraductionQuery innerJoinTParametreFormRelatedByCodeLibelleRef1($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef1 relation
 *
 * @method TTraductionQuery leftJoinTParametreFormRelatedByCodeLibelleRef2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef2 relation
 * @method TTraductionQuery rightJoinTParametreFormRelatedByCodeLibelleRef2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef2 relation
 * @method TTraductionQuery innerJoinTParametreFormRelatedByCodeLibelleRef2($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef2 relation
 *
 * @method TTraductionQuery leftJoinTParametreFormRelatedByCodeLibelleRef3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef3 relation
 * @method TTraductionQuery rightJoinTParametreFormRelatedByCodeLibelleRef3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef3 relation
 * @method TTraductionQuery innerJoinTParametreFormRelatedByCodeLibelleRef3($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef3 relation
 *
 * @method TTraductionQuery leftJoinTParametreFormRelatedByCodeLibelleText1($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText1 relation
 * @method TTraductionQuery rightJoinTParametreFormRelatedByCodeLibelleText1($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText1 relation
 * @method TTraductionQuery innerJoinTParametreFormRelatedByCodeLibelleText1($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText1 relation
 *
 * @method TTraductionQuery leftJoinTParametreFormRelatedByCodeLibelleText2($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText2 relation
 * @method TTraductionQuery rightJoinTParametreFormRelatedByCodeLibelleText2($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText2 relation
 * @method TTraductionQuery innerJoinTParametreFormRelatedByCodeLibelleText2($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText2 relation
 *
 * @method TTraductionQuery leftJoinTParametreFormRelatedByCodeLibelleText3($relationAlias = null) Adds a LEFT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText3 relation
 * @method TTraductionQuery rightJoinTParametreFormRelatedByCodeLibelleText3($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText3 relation
 * @method TTraductionQuery innerJoinTParametreFormRelatedByCodeLibelleText3($relationAlias = null) Adds a INNER JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText3 relation
 *
 * @method TTraductionQuery leftJoinTPieceParamPresta($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPieceParamPresta relation
 * @method TTraductionQuery rightJoinTPieceParamPresta($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPieceParamPresta relation
 * @method TTraductionQuery innerJoinTPieceParamPresta($relationAlias = null) Adds a INNER JOIN clause to the query using the TPieceParamPresta relation
 *
 * @method TTraductionQuery leftJoinTPiecePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPiecePrestation relation
 * @method TTraductionQuery rightJoinTPiecePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPiecePrestation relation
 * @method TTraductionQuery innerJoinTPiecePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPiecePrestation relation
 *
 * @method TTraductionQuery leftJoinTPrestationRelatedByCodeCommentaire($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestationRelatedByCodeCommentaire relation
 * @method TTraductionQuery rightJoinTPrestationRelatedByCodeCommentaire($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestationRelatedByCodeCommentaire relation
 * @method TTraductionQuery innerJoinTPrestationRelatedByCodeCommentaire($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestationRelatedByCodeCommentaire relation
 *
 * @method TTraductionQuery leftJoinTPrestationRelatedByCodeLibellePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TPrestationRelatedByCodeLibellePrestation relation
 * @method TTraductionQuery rightJoinTPrestationRelatedByCodeLibellePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TPrestationRelatedByCodeLibellePrestation relation
 * @method TTraductionQuery innerJoinTPrestationRelatedByCodeLibellePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TPrestationRelatedByCodeLibellePrestation relation
 *
 * @method TTraductionQuery leftJoinTProfil($relationAlias = null) Adds a LEFT JOIN clause to the query using the TProfil relation
 * @method TTraductionQuery rightJoinTProfil($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TProfil relation
 * @method TTraductionQuery innerJoinTProfil($relationAlias = null) Adds a INNER JOIN clause to the query using the TProfil relation
 *
 * @method TTraductionQuery leftJoinTReferentRelatedByCodeNomReferent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferentRelatedByCodeNomReferent relation
 * @method TTraductionQuery rightJoinTReferentRelatedByCodeNomReferent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferentRelatedByCodeNomReferent relation
 * @method TTraductionQuery innerJoinTReferentRelatedByCodeNomReferent($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferentRelatedByCodeNomReferent relation
 *
 * @method TTraductionQuery leftJoinTReferentRelatedByCodePrenomReferent($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferentRelatedByCodePrenomReferent relation
 * @method TTraductionQuery rightJoinTReferentRelatedByCodePrenomReferent($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferentRelatedByCodePrenomReferent relation
 * @method TTraductionQuery innerJoinTReferentRelatedByCodePrenomReferent($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferentRelatedByCodePrenomReferent relation
 *
 * @method TTraductionQuery leftJoinTReferentiel($relationAlias = null) Adds a LEFT JOIN clause to the query using the TReferentiel relation
 * @method TTraductionQuery rightJoinTReferentiel($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TReferentiel relation
 * @method TTraductionQuery innerJoinTReferentiel($relationAlias = null) Adds a INNER JOIN clause to the query using the TReferentiel relation
 *
 * @method TTraductionQuery leftJoinTRefPrestationRelatedByCodeAide($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefPrestationRelatedByCodeAide relation
 * @method TTraductionQuery rightJoinTRefPrestationRelatedByCodeAide($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefPrestationRelatedByCodeAide relation
 * @method TTraductionQuery innerJoinTRefPrestationRelatedByCodeAide($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefPrestationRelatedByCodeAide relation
 *
 * @method TTraductionQuery leftJoinTRefPrestationRelatedByCodeLibelle($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefPrestationRelatedByCodeLibelle relation
 * @method TTraductionQuery rightJoinTRefPrestationRelatedByCodeLibelle($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefPrestationRelatedByCodeLibelle relation
 * @method TTraductionQuery innerJoinTRefPrestationRelatedByCodeLibelle($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefPrestationRelatedByCodeLibelle relation
 *
 * @method TTraductionQuery leftJoinTRefTypePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TRefTypePrestation relation
 * @method TTraductionQuery rightJoinTRefTypePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TRefTypePrestation relation
 * @method TTraductionQuery innerJoinTRefTypePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TRefTypePrestation relation
 *
 * @method TTraductionQuery leftJoinTTraductionLibelle($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTraductionLibelle relation
 * @method TTraductionQuery rightJoinTTraductionLibelle($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTraductionLibelle relation
 * @method TTraductionQuery innerJoinTTraductionLibelle($relationAlias = null) Adds a INNER JOIN clause to the query using the TTraductionLibelle relation
 *
 * @method TTraductionQuery leftJoinTTypePrestation($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTypePrestation relation
 * @method TTraductionQuery rightJoinTTypePrestation($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTypePrestation relation
 * @method TTraductionQuery innerJoinTTypePrestation($relationAlias = null) Adds a INNER JOIN clause to the query using the TTypePrestation relation
 *
 * @method TTraductionQuery leftJoinTTypeProfil($relationAlias = null) Adds a LEFT JOIN clause to the query using the TTypeProfil relation
 * @method TTraductionQuery rightJoinTTypeProfil($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TTypeProfil relation
 * @method TTraductionQuery innerJoinTTypeProfil($relationAlias = null) Adds a INNER JOIN clause to the query using the TTypeProfil relation
 *
 * @method TTraductionQuery leftJoinTValeurReferentiel($relationAlias = null) Adds a LEFT JOIN clause to the query using the TValeurReferentiel relation
 * @method TTraductionQuery rightJoinTValeurReferentiel($relationAlias = null) Adds a RIGHT JOIN clause to the query using the TValeurReferentiel relation
 * @method TTraductionQuery innerJoinTValeurReferentiel($relationAlias = null) Adds a INNER JOIN clause to the query using the TValeurReferentiel relation
 *
 * @method TTraduction findOne(PropelPDO $con = null) Return the first TTraduction matching the query
 * @method TTraduction findOneOrCreate(PropelPDO $con = null) Return the first TTraduction matching the query, or a new TTraduction object populated from the query conditions when no match is found
 *
 *
 * @method array findByIdTraduction(int $ID_TRADUCTION) Return TTraduction objects filtered by the ID_TRADUCTION column
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTTraductionQuery extends ModelCriteria
{
    /**
     * Initializes internal state of BaseTTraductionQuery object.
     *
     * @param     string $dbName The dabase name
     * @param     string $modelName The phpName of a model, e.g. 'Book'
     * @param     string $modelAlias The alias for the model in this query, e.g. 'b'
     */
    public function __construct($dbName = 'RDV', $modelName = 'TTraduction', $modelAlias = null)
    {
        parent::__construct($dbName, $modelName, $modelAlias);
    }

    /**
     * Returns a new TTraductionQuery object.
     *
     * @param     string $modelAlias The alias of a model in the query
     * @param   TTraductionQuery|Criteria $criteria Optional Criteria to build the query from
     *
     * @return TTraductionQuery
     */
    public static function create($modelAlias = null, $criteria = null)
    {
        if ($criteria instanceof TTraductionQuery) {
            return $criteria;
        }
        $query = new TTraductionQuery();
        if (null !== $modelAlias) {
            $query->setModelAlias($modelAlias);
        }
        if ($criteria instanceof Criteria) {
            $query->mergeWith($criteria);
        }

        return $query;
    }

    /**
     * Find object by primary key.
     * Propel uses the instance pool to skip the database if the object exists.
     * Go fast if the query is untouched.
     *
     * <code>
     * $obj  = $c->findPk(12, $con);
     * </code>
     *
     * @param mixed $key Primary key to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return   TTraduction|TTraduction[]|mixed the result, formatted by the current formatter
     */
    public function findPk($key, $con = null)
    {
        if ($key === null) {
            return null;
        }
        if ((null !== ($obj = TTraductionPeer::getInstanceFromPool((string) $key))) && !$this->formatter) {
            // the object is alredy in the instance pool
            return $obj;
        }
        if ($con === null) {
            $con = Propel::getConnection(TTraductionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        if ($this->formatter || $this->modelAlias || $this->with || $this->select
         || $this->selectColumns || $this->asColumns || $this->selectModifiers
         || $this->map || $this->having || $this->joins) {
            return $this->findPkComplex($key, $con);
        } else {
            return $this->findPkSimple($key, $con);
        }
    }

    /**
     * Alias of findPk to use instance pooling
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TTraduction A model object, or null if the key is not found
     * @throws PropelException
     */
     public function findOneByIdTraduction($key, $con = null)
     {
        return $this->findPk($key, $con);
     }

    /**
     * Find object by primary key using raw SQL to go fast.
     * Bypass doSelect() and the object formatter by using generated code.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return                 TTraduction A model object, or null if the key is not found
     * @throws PropelException
     */
    protected function findPkSimple($key, $con)
    {
        $sql = 'SELECT `ID_TRADUCTION` FROM `T_TRADUCTION` WHERE `ID_TRADUCTION` = :p0';
        try {
            $stmt = $con->prepare($sql);
            $stmt->bindValue(':p0', $key, PDO::PARAM_INT);
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute SELECT statement [%s]', $sql), $e);
        }
        $obj = null;
        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $obj = new TTraduction();
            $obj->hydrate($row);
            TTraductionPeer::addInstanceToPool($obj, (string) $key);
        }
        $stmt->closeCursor();

        return $obj;
    }

    /**
     * Find object by primary key.
     *
     * @param     mixed $key Primary key to use for the query
     * @param     PropelPDO $con A connection object
     *
     * @return TTraduction|TTraduction[]|mixed the result, formatted by the current formatter
     */
    protected function findPkComplex($key, $con)
    {
        // As the query uses a PK condition, no limit(1) is necessary.
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKey($key)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->formatOne($stmt);
    }

    /**
     * Find objects by primary key
     * <code>
     * $objs = $c->findPks(array(12, 56, 832), $con);
     * </code>
     * @param     array $keys Primary keys to use for the query
     * @param     PropelPDO $con an optional connection object
     *
     * @return PropelObjectCollection|TTraduction[]|mixed the list of results, formatted by the current formatter
     */
    public function findPks($keys, $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection($this->getDbName(), Propel::CONNECTION_READ);
        }
        $this->basePreSelect($con);
        $criteria = $this->isKeepQuery() ? clone $this : $this;
        $stmt = $criteria
            ->filterByPrimaryKeys($keys)
            ->doSelect($con);

        return $criteria->getFormatter()->init($criteria)->format($stmt);
    }

    /**
     * Filter the query by primary key
     *
     * @param     mixed $key Primary key to use for the query
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKey($key)
    {

        return $this->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $key, Criteria::EQUAL);
    }

    /**
     * Filter the query by a list of primary keys
     *
     * @param     array $keys The list of primary key to use for the query
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function filterByPrimaryKeys($keys)
    {

        return $this->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $keys, Criteria::IN);
    }

    /**
     * Filter the query on the ID_TRADUCTION column
     *
     * Example usage:
     * <code>
     * $query->filterByIdTraduction(1234); // WHERE ID_TRADUCTION = 1234
     * $query->filterByIdTraduction(array(12, 34)); // WHERE ID_TRADUCTION IN (12, 34)
     * $query->filterByIdTraduction(array('min' => 12)); // WHERE ID_TRADUCTION >= 12
     * $query->filterByIdTraduction(array('max' => 12)); // WHERE ID_TRADUCTION <= 12
     * </code>
     *
     * @param     mixed $idTraduction The value to use as filter.
     *              Use scalar values for equality.
     *              Use array values for in_array() equivalent.
     *              Use associative array('min' => $minValue, 'max' => $maxValue) for intervals.
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function filterByIdTraduction($idTraduction = null, $comparison = null)
    {
        if (is_array($idTraduction)) {
            $useMinMax = false;
            if (isset($idTraduction['min'])) {
                $this->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $idTraduction['min'], Criteria::GREATER_EQUAL);
                $useMinMax = true;
            }
            if (isset($idTraduction['max'])) {
                $this->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $idTraduction['max'], Criteria::LESS_EQUAL);
                $useMinMax = true;
            }
            if ($useMinMax) {
                return $this;
            }
            if (null === $comparison) {
                $comparison = Criteria::IN;
            }
        }

        return $this->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $idTraduction, $comparison);
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByCodeNomUtilisateur($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tAgent->getCodeNomUtilisateur(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentRelatedByCodeNomUtilisateurQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentRelatedByCodeNomUtilisateur() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByCodeNomUtilisateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByCodeNomUtilisateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByCodeNomUtilisateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByCodeNomUtilisateur');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByCodeNomUtilisateur relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByCodeNomUtilisateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByCodeNomUtilisateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByCodeNomUtilisateur', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByCodePrenomUtilisateur($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tAgent->getCodePrenomUtilisateur(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentRelatedByCodePrenomUtilisateurQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentRelatedByCodePrenomUtilisateur() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByCodePrenomUtilisateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByCodePrenomUtilisateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByCodePrenomUtilisateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByCodePrenomUtilisateur');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByCodePrenomUtilisateur relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByCodePrenomUtilisateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByCodePrenomUtilisateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByCodePrenomUtilisateur', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TAgent object
     *
     * @param   TAgent|PropelObjectCollection $tAgent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTAgentRelatedByCodeUtilisateur($tAgent, $comparison = null)
    {
        if ($tAgent instanceof TAgent) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tAgent->getCodeUtilisateur(), $comparison);
        } elseif ($tAgent instanceof PropelObjectCollection) {
            return $this
                ->useTAgentRelatedByCodeUtilisateurQuery()
                ->filterByPrimaryKeys($tAgent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTAgentRelatedByCodeUtilisateur() only accepts arguments of type TAgent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TAgentRelatedByCodeUtilisateur relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTAgentRelatedByCodeUtilisateur($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TAgentRelatedByCodeUtilisateur');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TAgentRelatedByCodeUtilisateur');
        }

        return $this;
    }

    /**
     * Use the TAgentRelatedByCodeUtilisateur relation TAgent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TAgentQuery A secondary query class using the current class as primary query
     */
    public function useTAgentRelatedByCodeUtilisateurQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTAgentRelatedByCodeUtilisateur($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TAgentRelatedByCodeUtilisateur', 'TAgentQuery');
    }

    /**
     * Filter the query by a related TChampsSupp object
     *
     * @param   TChampsSupp|PropelObjectCollection $tChampsSupp  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTChampsSupp($tChampsSupp, $comparison = null)
    {
        if ($tChampsSupp instanceof TChampsSupp) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tChampsSupp->getCodeLibelle(), $comparison);
        } elseif ($tChampsSupp instanceof PropelObjectCollection) {
            return $this
                ->useTChampsSuppQuery()
                ->filterByPrimaryKeys($tChampsSupp->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTChampsSupp() only accepts arguments of type TChampsSupp or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TChampsSupp relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTChampsSupp($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TChampsSupp');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TChampsSupp');
        }

        return $this;
    }

    /**
     * Use the TChampsSupp relation TChampsSupp object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TChampsSuppQuery A secondary query class using the current class as primary query
     */
    public function useTChampsSuppQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTChampsSupp($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TChampsSupp', 'TChampsSuppQuery');
    }

    /**
     * Filter the query by a related TEntite object
     *
     * @param   TEntite|PropelObjectCollection $tEntite  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEntite($tEntite, $comparison = null)
    {
        if ($tEntite instanceof TEntite) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tEntite->getCodeLibelle(), $comparison);
        } elseif ($tEntite instanceof PropelObjectCollection) {
            return $this
                ->useTEntiteQuery()
                ->filterByPrimaryKeys($tEntite->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTEntite() only accepts arguments of type TEntite or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEntite relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTEntite($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEntite');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEntite');
        }

        return $this;
    }

    /**
     * Use the TEntite relation TEntite object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEntiteQuery A secondary query class using the current class as primary query
     */
    public function useTEntiteQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEntite($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEntite', 'TEntiteQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissementRelatedByCodeAdresseEtablissement($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tEtablissement->getCodeAdresseEtablissement(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            return $this
                ->useTEtablissementRelatedByCodeAdresseEtablissementQuery()
                ->filterByPrimaryKeys($tEtablissement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTEtablissementRelatedByCodeAdresseEtablissement() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissementRelatedByCodeAdresseEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTEtablissementRelatedByCodeAdresseEtablissement($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissementRelatedByCodeAdresseEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissementRelatedByCodeAdresseEtablissement');
        }

        return $this;
    }

    /**
     * Use the TEtablissementRelatedByCodeAdresseEtablissement relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementRelatedByCodeAdresseEtablissementQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEtablissementRelatedByCodeAdresseEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissementRelatedByCodeAdresseEtablissement', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissementRelatedByCodeDenominationEtablissement($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tEtablissement->getCodeDenominationEtablissement(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            return $this
                ->useTEtablissementRelatedByCodeDenominationEtablissementQuery()
                ->filterByPrimaryKeys($tEtablissement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTEtablissementRelatedByCodeDenominationEtablissement() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissementRelatedByCodeDenominationEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTEtablissementRelatedByCodeDenominationEtablissement($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissementRelatedByCodeDenominationEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissementRelatedByCodeDenominationEtablissement');
        }

        return $this;
    }

    /**
     * Use the TEtablissementRelatedByCodeDenominationEtablissement relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementRelatedByCodeDenominationEtablissementQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEtablissementRelatedByCodeDenominationEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissementRelatedByCodeDenominationEtablissement', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TEtablissement object
     *
     * @param   TEtablissement|PropelObjectCollection $tEtablissement  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTEtablissementRelatedByCodeDescriptionEtablissement($tEtablissement, $comparison = null)
    {
        if ($tEtablissement instanceof TEtablissement) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tEtablissement->getCodeDescriptionEtablissement(), $comparison);
        } elseif ($tEtablissement instanceof PropelObjectCollection) {
            return $this
                ->useTEtablissementRelatedByCodeDescriptionEtablissementQuery()
                ->filterByPrimaryKeys($tEtablissement->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTEtablissementRelatedByCodeDescriptionEtablissement() only accepts arguments of type TEtablissement or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TEtablissementRelatedByCodeDescriptionEtablissement relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTEtablissementRelatedByCodeDescriptionEtablissement($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TEtablissementRelatedByCodeDescriptionEtablissement');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TEtablissementRelatedByCodeDescriptionEtablissement');
        }

        return $this;
    }

    /**
     * Use the TEtablissementRelatedByCodeDescriptionEtablissement relation TEtablissement object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TEtablissementQuery A secondary query class using the current class as primary query
     */
    public function useTEtablissementRelatedByCodeDescriptionEtablissementQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTEtablissementRelatedByCodeDescriptionEtablissement($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TEtablissementRelatedByCodeDescriptionEtablissement', 'TEtablissementQuery');
    }

    /**
     * Filter the query by a related TGroupe object
     *
     * @param   TGroupe|PropelObjectCollection $tGroupe  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTGroupe($tGroupe, $comparison = null)
    {
        if ($tGroupe instanceof TGroupe) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tGroupe->getCodeLibelle(), $comparison);
        } elseif ($tGroupe instanceof PropelObjectCollection) {
            return $this
                ->useTGroupeQuery()
                ->filterByPrimaryKeys($tGroupe->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTGroupe() only accepts arguments of type TGroupe or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TGroupe relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTGroupe($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TGroupe');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TGroupe');
        }

        return $this;
    }

    /**
     * Use the TGroupe relation TGroupe object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TGroupeQuery A secondary query class using the current class as primary query
     */
    public function useTGroupeQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTGroupe($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TGroupe', 'TGroupeQuery');
    }

    /**
     * Filter the query by a related TJourFerie object
     *
     * @param   TJourFerie|PropelObjectCollection $tJourFerie  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTJourFerie($tJourFerie, $comparison = null)
    {
        if ($tJourFerie instanceof TJourFerie) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tJourFerie->getCodeLibelleJourFerie(), $comparison);
        } elseif ($tJourFerie instanceof PropelObjectCollection) {
            return $this
                ->useTJourFerieQuery()
                ->filterByPrimaryKeys($tJourFerie->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTJourFerie() only accepts arguments of type TJourFerie or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TJourFerie relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTJourFerie($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TJourFerie');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TJourFerie');
        }

        return $this;
    }

    /**
     * Use the TJourFerie relation TJourFerie object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TJourFerieQuery A secondary query class using the current class as primary query
     */
    public function useTJourFerieQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTJourFerie($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TJourFerie', 'TJourFerieQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeAdresseOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeAdresseOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeAdresseOrganisationQuery()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeAdresseOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeAdresseOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeAdresseOrganisation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeAdresseOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeAdresseOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeAdresseOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeAdresseOrganisationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeAdresseOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeAdresseOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeDenominationOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeDenominationOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeDenominationOrganisationQuery()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeDenominationOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeDenominationOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeDenominationOrganisation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeDenominationOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeDenominationOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeDenominationOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeDenominationOrganisationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeDenominationOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeDenominationOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeDescriptionOrganisation($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeDescriptionOrganisation(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeDescriptionOrganisationQuery()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeDescriptionOrganisation() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeDescriptionOrganisation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeDescriptionOrganisation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeDescriptionOrganisation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeDescriptionOrganisation');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeDescriptionOrganisation relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeDescriptionOrganisationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeDescriptionOrganisation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeDescriptionOrganisation', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeLibelleLien1($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeLibelleLien1(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeLibelleLien1Query()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeLibelleLien1() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeLibelleLien1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeLibelleLien1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeLibelleLien1');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeLibelleLien1 relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeLibelleLien1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeLibelleLien1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeLibelleLien1', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeLibelleLien2($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeLibelleLien2(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeLibelleLien2Query()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeLibelleLien2() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeLibelleLien2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeLibelleLien2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeLibelleLien2');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeLibelleLien2 relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeLibelleLien2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeLibelleLien2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeLibelleLien2', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeLibelleLien3($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeLibelleLien3(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeLibelleLien3Query()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeLibelleLien3() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeLibelleLien3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeLibelleLien3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeLibelleLien3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeLibelleLien3');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeLibelleLien3 relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeLibelleLien3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeLibelleLien3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeLibelleLien3', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeMessageBienvenue($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeMessageBienvenue(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeMessageBienvenueQuery()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeMessageBienvenue() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeMessageBienvenue relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeMessageBienvenue($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeMessageBienvenue');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeMessageBienvenue');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeMessageBienvenue relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeMessageBienvenueQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeMessageBienvenue($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeMessageBienvenue', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TOrganisation object
     *
     * @param   TOrganisation|PropelObjectCollection $tOrganisation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTOrganisationRelatedByCodeTitreBienvenue($tOrganisation, $comparison = null)
    {
        if ($tOrganisation instanceof TOrganisation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tOrganisation->getCodeTitreBienvenue(), $comparison);
        } elseif ($tOrganisation instanceof PropelObjectCollection) {
            return $this
                ->useTOrganisationRelatedByCodeTitreBienvenueQuery()
                ->filterByPrimaryKeys($tOrganisation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTOrganisationRelatedByCodeTitreBienvenue() only accepts arguments of type TOrganisation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TOrganisationRelatedByCodeTitreBienvenue relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTOrganisationRelatedByCodeTitreBienvenue($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TOrganisationRelatedByCodeTitreBienvenue');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TOrganisationRelatedByCodeTitreBienvenue');
        }

        return $this;
    }

    /**
     * Use the TOrganisationRelatedByCodeTitreBienvenue relation TOrganisation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TOrganisationQuery A secondary query class using the current class as primary query
     */
    public function useTOrganisationRelatedByCodeTitreBienvenueQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTOrganisationRelatedByCodeTitreBienvenue($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TOrganisationRelatedByCodeTitreBienvenue', 'TOrganisationQuery');
    }

    /**
     * Filter the query by a related TParametragePrestation object
     *
     * @param   TParametragePrestation|PropelObjectCollection $tParametragePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametragePrestationRelatedByCodeCommentaire($tParametragePrestation, $comparison = null)
    {
        if ($tParametragePrestation instanceof TParametragePrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametragePrestation->getCodeCommentaire(), $comparison);
        } elseif ($tParametragePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTParametragePrestationRelatedByCodeCommentaireQuery()
                ->filterByPrimaryKeys($tParametragePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametragePrestationRelatedByCodeCommentaire() only accepts arguments of type TParametragePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametragePrestationRelatedByCodeCommentaire relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametragePrestationRelatedByCodeCommentaire($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametragePrestationRelatedByCodeCommentaire');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametragePrestationRelatedByCodeCommentaire');
        }

        return $this;
    }

    /**
     * Use the TParametragePrestationRelatedByCodeCommentaire relation TParametragePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametragePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTParametragePrestationRelatedByCodeCommentaireQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametragePrestationRelatedByCodeCommentaire($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametragePrestationRelatedByCodeCommentaire', 'TParametragePrestationQuery');
    }

    /**
     * Filter the query by a related TParametragePrestation object
     *
     * @param   TParametragePrestation|PropelObjectCollection $tParametragePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametragePrestationRelatedByCodeAide($tParametragePrestation, $comparison = null)
    {
        if ($tParametragePrestation instanceof TParametragePrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametragePrestation->getCodeAide(), $comparison);
        } elseif ($tParametragePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTParametragePrestationRelatedByCodeAideQuery()
                ->filterByPrimaryKeys($tParametragePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametragePrestationRelatedByCodeAide() only accepts arguments of type TParametragePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametragePrestationRelatedByCodeAide relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametragePrestationRelatedByCodeAide($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametragePrestationRelatedByCodeAide');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametragePrestationRelatedByCodeAide');
        }

        return $this;
    }

    /**
     * Use the TParametragePrestationRelatedByCodeAide relation TParametragePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametragePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTParametragePrestationRelatedByCodeAideQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametragePrestationRelatedByCodeAide($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametragePrestationRelatedByCodeAide', 'TParametragePrestationQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreFormRelatedByCodeCommentaire($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametreForm->getCodeCommentaire(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            return $this
                ->useTParametreFormRelatedByCodeCommentaireQuery()
                ->filterByPrimaryKeys($tParametreForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametreFormRelatedByCodeCommentaire() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreFormRelatedByCodeCommentaire relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametreFormRelatedByCodeCommentaire($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreFormRelatedByCodeCommentaire');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreFormRelatedByCodeCommentaire');
        }

        return $this;
    }

    /**
     * Use the TParametreFormRelatedByCodeCommentaire relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormRelatedByCodeCommentaireQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreFormRelatedByCodeCommentaire($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreFormRelatedByCodeCommentaire', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreFormRelatedByCodeLibelleRef1($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametreForm->getCodeLibelleRef1(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            return $this
                ->useTParametreFormRelatedByCodeLibelleRef1Query()
                ->filterByPrimaryKeys($tParametreForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametreFormRelatedByCodeLibelleRef1() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametreFormRelatedByCodeLibelleRef1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreFormRelatedByCodeLibelleRef1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreFormRelatedByCodeLibelleRef1');
        }

        return $this;
    }

    /**
     * Use the TParametreFormRelatedByCodeLibelleRef1 relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormRelatedByCodeLibelleRef1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreFormRelatedByCodeLibelleRef1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreFormRelatedByCodeLibelleRef1', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreFormRelatedByCodeLibelleRef2($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametreForm->getCodeLibelleRef2(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            return $this
                ->useTParametreFormRelatedByCodeLibelleRef2Query()
                ->filterByPrimaryKeys($tParametreForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametreFormRelatedByCodeLibelleRef2() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametreFormRelatedByCodeLibelleRef2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreFormRelatedByCodeLibelleRef2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreFormRelatedByCodeLibelleRef2');
        }

        return $this;
    }

    /**
     * Use the TParametreFormRelatedByCodeLibelleRef2 relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormRelatedByCodeLibelleRef2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreFormRelatedByCodeLibelleRef2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreFormRelatedByCodeLibelleRef2', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreFormRelatedByCodeLibelleRef3($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametreForm->getCodeLibelleRef3(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            return $this
                ->useTParametreFormRelatedByCodeLibelleRef3Query()
                ->filterByPrimaryKeys($tParametreForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametreFormRelatedByCodeLibelleRef3() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreFormRelatedByCodeLibelleRef3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametreFormRelatedByCodeLibelleRef3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreFormRelatedByCodeLibelleRef3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreFormRelatedByCodeLibelleRef3');
        }

        return $this;
    }

    /**
     * Use the TParametreFormRelatedByCodeLibelleRef3 relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormRelatedByCodeLibelleRef3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreFormRelatedByCodeLibelleRef3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreFormRelatedByCodeLibelleRef3', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreFormRelatedByCodeLibelleText1($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametreForm->getCodeLibelleText1(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            return $this
                ->useTParametreFormRelatedByCodeLibelleText1Query()
                ->filterByPrimaryKeys($tParametreForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametreFormRelatedByCodeLibelleText1() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText1 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametreFormRelatedByCodeLibelleText1($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreFormRelatedByCodeLibelleText1');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreFormRelatedByCodeLibelleText1');
        }

        return $this;
    }

    /**
     * Use the TParametreFormRelatedByCodeLibelleText1 relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormRelatedByCodeLibelleText1Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreFormRelatedByCodeLibelleText1($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreFormRelatedByCodeLibelleText1', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreFormRelatedByCodeLibelleText2($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametreForm->getCodeLibelleText2(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            return $this
                ->useTParametreFormRelatedByCodeLibelleText2Query()
                ->filterByPrimaryKeys($tParametreForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametreFormRelatedByCodeLibelleText2() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText2 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametreFormRelatedByCodeLibelleText2($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreFormRelatedByCodeLibelleText2');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreFormRelatedByCodeLibelleText2');
        }

        return $this;
    }

    /**
     * Use the TParametreFormRelatedByCodeLibelleText2 relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormRelatedByCodeLibelleText2Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreFormRelatedByCodeLibelleText2($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreFormRelatedByCodeLibelleText2', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TParametreForm object
     *
     * @param   TParametreForm|PropelObjectCollection $tParametreForm  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTParametreFormRelatedByCodeLibelleText3($tParametreForm, $comparison = null)
    {
        if ($tParametreForm instanceof TParametreForm) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tParametreForm->getCodeLibelleText3(), $comparison);
        } elseif ($tParametreForm instanceof PropelObjectCollection) {
            return $this
                ->useTParametreFormRelatedByCodeLibelleText3Query()
                ->filterByPrimaryKeys($tParametreForm->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTParametreFormRelatedByCodeLibelleText3() only accepts arguments of type TParametreForm or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TParametreFormRelatedByCodeLibelleText3 relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTParametreFormRelatedByCodeLibelleText3($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TParametreFormRelatedByCodeLibelleText3');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TParametreFormRelatedByCodeLibelleText3');
        }

        return $this;
    }

    /**
     * Use the TParametreFormRelatedByCodeLibelleText3 relation TParametreForm object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TParametreFormQuery A secondary query class using the current class as primary query
     */
    public function useTParametreFormRelatedByCodeLibelleText3Query($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTParametreFormRelatedByCodeLibelleText3($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TParametreFormRelatedByCodeLibelleText3', 'TParametreFormQuery');
    }

    /**
     * Filter the query by a related TPieceParamPresta object
     *
     * @param   TPieceParamPresta|PropelObjectCollection $tPieceParamPresta  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPieceParamPresta($tPieceParamPresta, $comparison = null)
    {
        if ($tPieceParamPresta instanceof TPieceParamPresta) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tPieceParamPresta->getCodeLibellePiece(), $comparison);
        } elseif ($tPieceParamPresta instanceof PropelObjectCollection) {
            return $this
                ->useTPieceParamPrestaQuery()
                ->filterByPrimaryKeys($tPieceParamPresta->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPieceParamPresta() only accepts arguments of type TPieceParamPresta or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPieceParamPresta relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTPieceParamPresta($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPieceParamPresta');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPieceParamPresta');
        }

        return $this;
    }

    /**
     * Use the TPieceParamPresta relation TPieceParamPresta object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPieceParamPrestaQuery A secondary query class using the current class as primary query
     */
    public function useTPieceParamPrestaQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPieceParamPresta($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPieceParamPresta', 'TPieceParamPrestaQuery');
    }

    /**
     * Filter the query by a related TPiecePrestation object
     *
     * @param   TPiecePrestation|PropelObjectCollection $tPiecePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPiecePrestation($tPiecePrestation, $comparison = null)
    {
        if ($tPiecePrestation instanceof TPiecePrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tPiecePrestation->getCodeLibellePiece(), $comparison);
        } elseif ($tPiecePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTPiecePrestationQuery()
                ->filterByPrimaryKeys($tPiecePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPiecePrestation() only accepts arguments of type TPiecePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPiecePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTPiecePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPiecePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPiecePrestation');
        }

        return $this;
    }

    /**
     * Use the TPiecePrestation relation TPiecePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPiecePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPiecePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTPiecePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPiecePrestation', 'TPiecePrestationQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestationRelatedByCodeCommentaire($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tPrestation->getCodeCommentaire(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTPrestationRelatedByCodeCommentaireQuery()
                ->filterByPrimaryKeys($tPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPrestationRelatedByCodeCommentaire() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestationRelatedByCodeCommentaire relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTPrestationRelatedByCodeCommentaire($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestationRelatedByCodeCommentaire');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestationRelatedByCodeCommentaire');
        }

        return $this;
    }

    /**
     * Use the TPrestationRelatedByCodeCommentaire relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationRelatedByCodeCommentaireQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTPrestationRelatedByCodeCommentaire($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestationRelatedByCodeCommentaire', 'TPrestationQuery');
    }

    /**
     * Filter the query by a related TPrestation object
     *
     * @param   TPrestation|PropelObjectCollection $tPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTPrestationRelatedByCodeLibellePrestation($tPrestation, $comparison = null)
    {
        if ($tPrestation instanceof TPrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tPrestation->getCodeLibellePrestation(), $comparison);
        } elseif ($tPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTPrestationRelatedByCodeLibellePrestationQuery()
                ->filterByPrimaryKeys($tPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTPrestationRelatedByCodeLibellePrestation() only accepts arguments of type TPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TPrestationRelatedByCodeLibellePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTPrestationRelatedByCodeLibellePrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TPrestationRelatedByCodeLibellePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TPrestationRelatedByCodeLibellePrestation');
        }

        return $this;
    }

    /**
     * Use the TPrestationRelatedByCodeLibellePrestation relation TPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTPrestationRelatedByCodeLibellePrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTPrestationRelatedByCodeLibellePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TPrestationRelatedByCodeLibellePrestation', 'TPrestationQuery');
    }

    /**
     * Filter the query by a related TProfil object
     *
     * @param   TProfil|PropelObjectCollection $tProfil  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTProfil($tProfil, $comparison = null)
    {
        if ($tProfil instanceof TProfil) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tProfil->getCodeLibelleProfil(), $comparison);
        } elseif ($tProfil instanceof PropelObjectCollection) {
            return $this
                ->useTProfilQuery()
                ->filterByPrimaryKeys($tProfil->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTProfil() only accepts arguments of type TProfil or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TProfil relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTProfil($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TProfil');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TProfil');
        }

        return $this;
    }

    /**
     * Use the TProfil relation TProfil object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TProfilQuery A secondary query class using the current class as primary query
     */
    public function useTProfilQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTProfil($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TProfil', 'TProfilQuery');
    }

    /**
     * Filter the query by a related TReferent object
     *
     * @param   TReferent|PropelObjectCollection $tReferent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferentRelatedByCodeNomReferent($tReferent, $comparison = null)
    {
        if ($tReferent instanceof TReferent) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tReferent->getCodeNomReferent(), $comparison);
        } elseif ($tReferent instanceof PropelObjectCollection) {
            return $this
                ->useTReferentRelatedByCodeNomReferentQuery()
                ->filterByPrimaryKeys($tReferent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTReferentRelatedByCodeNomReferent() only accepts arguments of type TReferent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferentRelatedByCodeNomReferent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTReferentRelatedByCodeNomReferent($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferentRelatedByCodeNomReferent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferentRelatedByCodeNomReferent');
        }

        return $this;
    }

    /**
     * Use the TReferentRelatedByCodeNomReferent relation TReferent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentQuery A secondary query class using the current class as primary query
     */
    public function useTReferentRelatedByCodeNomReferentQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTReferentRelatedByCodeNomReferent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferentRelatedByCodeNomReferent', 'TReferentQuery');
    }

    /**
     * Filter the query by a related TReferent object
     *
     * @param   TReferent|PropelObjectCollection $tReferent  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferentRelatedByCodePrenomReferent($tReferent, $comparison = null)
    {
        if ($tReferent instanceof TReferent) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tReferent->getCodePrenomReferent(), $comparison);
        } elseif ($tReferent instanceof PropelObjectCollection) {
            return $this
                ->useTReferentRelatedByCodePrenomReferentQuery()
                ->filterByPrimaryKeys($tReferent->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTReferentRelatedByCodePrenomReferent() only accepts arguments of type TReferent or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferentRelatedByCodePrenomReferent relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTReferentRelatedByCodePrenomReferent($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferentRelatedByCodePrenomReferent');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferentRelatedByCodePrenomReferent');
        }

        return $this;
    }

    /**
     * Use the TReferentRelatedByCodePrenomReferent relation TReferent object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentQuery A secondary query class using the current class as primary query
     */
    public function useTReferentRelatedByCodePrenomReferentQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTReferentRelatedByCodePrenomReferent($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferentRelatedByCodePrenomReferent', 'TReferentQuery');
    }

    /**
     * Filter the query by a related TReferentiel object
     *
     * @param   TReferentiel|PropelObjectCollection $tReferentiel  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTReferentiel($tReferentiel, $comparison = null)
    {
        if ($tReferentiel instanceof TReferentiel) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tReferentiel->getCodeLibelleReferentiel(), $comparison);
        } elseif ($tReferentiel instanceof PropelObjectCollection) {
            return $this
                ->useTReferentielQuery()
                ->filterByPrimaryKeys($tReferentiel->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTReferentiel() only accepts arguments of type TReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TReferentiel relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTReferentiel($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TReferentiel');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TReferentiel');
        }

        return $this;
    }

    /**
     * Use the TReferentiel relation TReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTReferentielQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTReferentiel($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TReferentiel', 'TReferentielQuery');
    }

    /**
     * Filter the query by a related TRefPrestation object
     *
     * @param   TRefPrestation|PropelObjectCollection $tRefPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefPrestationRelatedByCodeAide($tRefPrestation, $comparison = null)
    {
        if ($tRefPrestation instanceof TRefPrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tRefPrestation->getCodeAide(), $comparison);
        } elseif ($tRefPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTRefPrestationRelatedByCodeAideQuery()
                ->filterByPrimaryKeys($tRefPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRefPrestationRelatedByCodeAide() only accepts arguments of type TRefPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefPrestationRelatedByCodeAide relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTRefPrestationRelatedByCodeAide($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefPrestationRelatedByCodeAide');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefPrestationRelatedByCodeAide');
        }

        return $this;
    }

    /**
     * Use the TRefPrestationRelatedByCodeAide relation TRefPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefPrestationRelatedByCodeAideQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRefPrestationRelatedByCodeAide($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefPrestationRelatedByCodeAide', 'TRefPrestationQuery');
    }

    /**
     * Filter the query by a related TRefPrestation object
     *
     * @param   TRefPrestation|PropelObjectCollection $tRefPrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefPrestationRelatedByCodeLibelle($tRefPrestation, $comparison = null)
    {
        if ($tRefPrestation instanceof TRefPrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tRefPrestation->getCodeLibelle(), $comparison);
        } elseif ($tRefPrestation instanceof PropelObjectCollection) {
            return $this
                ->useTRefPrestationRelatedByCodeLibelleQuery()
                ->filterByPrimaryKeys($tRefPrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRefPrestationRelatedByCodeLibelle() only accepts arguments of type TRefPrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefPrestationRelatedByCodeLibelle relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTRefPrestationRelatedByCodeLibelle($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefPrestationRelatedByCodeLibelle');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefPrestationRelatedByCodeLibelle');
        }

        return $this;
    }

    /**
     * Use the TRefPrestationRelatedByCodeLibelle relation TRefPrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefPrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefPrestationRelatedByCodeLibelleQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRefPrestationRelatedByCodeLibelle($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefPrestationRelatedByCodeLibelle', 'TRefPrestationQuery');
    }

    /**
     * Filter the query by a related TRefTypePrestation object
     *
     * @param   TRefTypePrestation|PropelObjectCollection $tRefTypePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTRefTypePrestation($tRefTypePrestation, $comparison = null)
    {
        if ($tRefTypePrestation instanceof TRefTypePrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tRefTypePrestation->getCodeLibelle(), $comparison);
        } elseif ($tRefTypePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTRefTypePrestationQuery()
                ->filterByPrimaryKeys($tRefTypePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTRefTypePrestation() only accepts arguments of type TRefTypePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TRefTypePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTRefTypePrestation($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TRefTypePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TRefTypePrestation');
        }

        return $this;
    }

    /**
     * Use the TRefTypePrestation relation TRefTypePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TRefTypePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTRefTypePrestationQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTRefTypePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TRefTypePrestation', 'TRefTypePrestationQuery');
    }

    /**
     * Filter the query by a related TTraductionLibelle object
     *
     * @param   TTraductionLibelle|PropelObjectCollection $tTraductionLibelle  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTraductionLibelle($tTraductionLibelle, $comparison = null)
    {
        if ($tTraductionLibelle instanceof TTraductionLibelle) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tTraductionLibelle->getIdTraduction(), $comparison);
        } elseif ($tTraductionLibelle instanceof PropelObjectCollection) {
            return $this
                ->useTTraductionLibelleQuery()
                ->filterByPrimaryKeys($tTraductionLibelle->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTTraductionLibelle() only accepts arguments of type TTraductionLibelle or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTraductionLibelle relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTTraductionLibelle($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTraductionLibelle');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTraductionLibelle');
        }

        return $this;
    }

    /**
     * Use the TTraductionLibelle relation TTraductionLibelle object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTraductionLibelleQuery A secondary query class using the current class as primary query
     */
    public function useTTraductionLibelleQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTraductionLibelle($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTraductionLibelle', 'TTraductionLibelleQuery');
    }

    /**
     * Filter the query by a related TTypePrestation object
     *
     * @param   TTypePrestation|PropelObjectCollection $tTypePrestation  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTypePrestation($tTypePrestation, $comparison = null)
    {
        if ($tTypePrestation instanceof TTypePrestation) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tTypePrestation->getCodeLibelleTypePrestation(), $comparison);
        } elseif ($tTypePrestation instanceof PropelObjectCollection) {
            return $this
                ->useTTypePrestationQuery()
                ->filterByPrimaryKeys($tTypePrestation->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTTypePrestation() only accepts arguments of type TTypePrestation or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTypePrestation relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTTypePrestation($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTypePrestation');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTypePrestation');
        }

        return $this;
    }

    /**
     * Use the TTypePrestation relation TTypePrestation object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTypePrestationQuery A secondary query class using the current class as primary query
     */
    public function useTTypePrestationQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTTypePrestation($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTypePrestation', 'TTypePrestationQuery');
    }

    /**
     * Filter the query by a related TTypeProfil object
     *
     * @param   TTypeProfil|PropelObjectCollection $tTypeProfil  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTTypeProfil($tTypeProfil, $comparison = null)
    {
        if ($tTypeProfil instanceof TTypeProfil) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tTypeProfil->getCodeLibelleTypeProfil(), $comparison);
        } elseif ($tTypeProfil instanceof PropelObjectCollection) {
            return $this
                ->useTTypeProfilQuery()
                ->filterByPrimaryKeys($tTypeProfil->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTTypeProfil() only accepts arguments of type TTypeProfil or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TTypeProfil relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTTypeProfil($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TTypeProfil');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TTypeProfil');
        }

        return $this;
    }

    /**
     * Use the TTypeProfil relation TTypeProfil object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TTypeProfilQuery A secondary query class using the current class as primary query
     */
    public function useTTypeProfilQuery($relationAlias = null, $joinType = Criteria::INNER_JOIN)
    {
        return $this
            ->joinTTypeProfil($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TTypeProfil', 'TTypeProfilQuery');
    }

    /**
     * Filter the query by a related TValeurReferentiel object
     *
     * @param   TValeurReferentiel|PropelObjectCollection $tValeurReferentiel  the related object to use as filter
     * @param     string $comparison Operator to use for the column comparison, defaults to Criteria::EQUAL
     *
     * @return                 TTraductionQuery The current query, for fluid interface
     * @throws PropelException - if the provided filter is invalid.
     */
    public function filterByTValeurReferentiel($tValeurReferentiel, $comparison = null)
    {
        if ($tValeurReferentiel instanceof TValeurReferentiel) {
            return $this
                ->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tValeurReferentiel->getCodeLibelleValeurReferentiel(), $comparison);
        } elseif ($tValeurReferentiel instanceof PropelObjectCollection) {
            return $this
                ->useTValeurReferentielQuery()
                ->filterByPrimaryKeys($tValeurReferentiel->getPrimaryKeys())
                ->endUse();
        } else {
            throw new PropelException('filterByTValeurReferentiel() only accepts arguments of type TValeurReferentiel or PropelCollection');
        }
    }

    /**
     * Adds a JOIN clause to the query using the TValeurReferentiel relation
     *
     * @param     string $relationAlias optional alias for the relation
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function joinTValeurReferentiel($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        $tableMap = $this->getTableMap();
        $relationMap = $tableMap->getRelation('TValeurReferentiel');

        // create a ModelJoin object for this join
        $join = new ModelJoin();
        $join->setJoinType($joinType);
        $join->setRelationMap($relationMap, $this->useAliasInSQL ? $this->getModelAlias() : null, $relationAlias);
        if ($previousJoin = $this->getPreviousJoin()) {
            $join->setPreviousJoin($previousJoin);
        }

        // add the ModelJoin to the current object
        if ($relationAlias) {
            $this->addAlias($relationAlias, $relationMap->getRightTable()->getName());
            $this->addJoinObject($join, $relationAlias);
        } else {
            $this->addJoinObject($join, 'TValeurReferentiel');
        }

        return $this;
    }

    /**
     * Use the TValeurReferentiel relation TValeurReferentiel object
     *
     * @see       useQuery()
     *
     * @param     string $relationAlias optional alias for the relation,
     *                                   to be used as main alias in the secondary query
     * @param     string $joinType Accepted values are null, 'left join', 'right join', 'inner join'
     *
     * @return   TValeurReferentielQuery A secondary query class using the current class as primary query
     */
    public function useTValeurReferentielQuery($relationAlias = null, $joinType = Criteria::LEFT_JOIN)
    {
        return $this
            ->joinTValeurReferentiel($relationAlias, $joinType)
            ->useQuery($relationAlias ? $relationAlias : 'TValeurReferentiel', 'TValeurReferentielQuery');
    }

    /**
     * Exclude object from result
     *
     * @param   TTraduction $tTraduction Object to remove from the list of results
     *
     * @return TTraductionQuery The current query, for fluid interface
     */
    public function prune($tTraduction = null)
    {
        if ($tTraduction) {
            $this->addUsingAlias(TTraductionPeer::ID_TRADUCTION, $tTraduction->getIdTraduction(), Criteria::NOT_EQUAL);
        }

        return $this;
    }

}
