<?php


/**
 * Base class that represents a row from the 'T_PRESTATION' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTPrestation extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TPrestationPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TPrestationPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_prestation field.
     * @var        int
     */
    protected $id_prestation;

    /**
     * The value for the id_ref_prestation field.
     * @var        int
     */
    protected $id_ref_prestation;

    /**
     * The value for the code_libelle_prestation field.
     * @var        int
     */
    protected $code_libelle_prestation;

    /**
     * The value for the id_type_prestation field.
     * @var        int
     */
    protected $id_type_prestation;

    /**
     * The value for the rdv_similaire field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $rdv_similaire;

    /**
     * The value for the nb_jour_rdv_similaire field.
     * @var        int
     */
    protected $nb_jour_rdv_similaire;

    /**
     * The value for the delai_min field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $delai_min;

    /**
     * The value for the periodicite field.
     * Note: this column has a database default value of: 0
     * @var        int
     */
    protected $periodicite;

    /**
     * The value for the ressource_visible field.
     * Note: this column has a database default value of: '1'
     * @var        string
     */
    protected $ressource_visible;

    /**
     * The value for the ressource_obligatoire field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $ressource_obligatoire;

    /**
     * The value for the id_parametre_form field.
     * @var        int
     */
    protected $id_parametre_form;

    /**
     * The value for the code_commentaire field.
     * @var        int
     */
    protected $code_commentaire;

    /**
     * The value for the referent_visible field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $referent_visible;

    /**
     * The value for the id_parametrage_prestation field.
     * @var        int
     */
    protected $id_parametrage_prestation;

    /**
     * The value for the id_champs_supp_1 field.
     * @var        int
     */
    protected $id_champs_supp_1;

    /**
     * The value for the id_champs_supp_2 field.
     * @var        int
     */
    protected $id_champs_supp_2;

    /**
     * The value for the id_champs_supp_3 field.
     * @var        int
     */
    protected $id_champs_supp_3;

    /**
     * The value for the visioconference field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $visioconference;

    /**
     * The value for the rdv_groupe field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $rdv_groupe;

    /**
     * The value for the nombre_max_participants field.
     * @var        int
     */
    protected $nombre_max_participants;

    /**
     * The value for the type_session field.
     * @var        string
     */
    protected $type_session;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeCommentaire;

    /**
     * @var        TTraduction
     */
    protected $aTTraductionRelatedByCodeLibellePrestation;

    /**
     * @var        TParametragePrestation
     */
    protected $aTParametragePrestation;

    /**
     * @var        TParametreForm
     */
    protected $aTParametreForm;

    /**
     * @var        TRefPrestation
     */
    protected $aTRefPrestation;

    /**
     * @var        TTypePrestation
     */
    protected $aTTypePrestation;

    /**
     * @var        TChampsSupp
     */
    protected $aTChampsSuppRelatedByIdChampsSupp1;

    /**
     * @var        TChampsSupp
     */
    protected $aTChampsSuppRelatedByIdChampsSupp2;

    /**
     * @var        TChampsSupp
     */
    protected $aTChampsSuppRelatedByIdChampsSupp3;

    /**
     * @var        PropelObjectCollection|TAgenda[] Collection to store aggregation of TAgenda objects.
     */
    protected $collTAgendas;
    protected $collTAgendasPartial;

    /**
     * @var        PropelObjectCollection|TAgent[] Collection to store aggregation of TAgent objects.
     */
    protected $collTAgents;
    protected $collTAgentsPartial;

    /**
     * @var        PropelObjectCollection|TAgentPrestation[] Collection to store aggregation of TAgentPrestation objects.
     */
    protected $collTAgentPrestations;
    protected $collTAgentPrestationsPartial;

    /**
     * @var        PropelObjectCollection|TDelaiObtention[] Collection to store aggregation of TDelaiObtention objects.
     */
    protected $collTDelaiObtentions;
    protected $collTDelaiObtentionsPartial;

    /**
     * @var        PropelObjectCollection|TPiecePrestation[] Collection to store aggregation of TPiecePrestation objects.
     */
    protected $collTPiecePrestations;
    protected $collTPiecePrestationsPartial;

    /**
     * @var        PropelObjectCollection|TRendezVous[] Collection to store aggregation of TRendezVous objects.
     */
    protected $collTRendezVouss;
    protected $collTRendezVoussPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgendasScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentPrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tDelaiObtentionsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPiecePrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRendezVoussScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->rdv_similaire = '0';
        $this->delai_min = 0;
        $this->periodicite = 0;
        $this->ressource_visible = '1';
        $this->ressource_obligatoire = '0';
        $this->referent_visible = '0';
        $this->visioconference = '0';
        $this->rdv_groupe = '0';
    }

    /**
     * Initializes internal state of BaseTPrestation object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_prestation] column value.
     *
     * @return int
     */
    public function getIdPrestation()
    {
        return $this->id_prestation;
    }

    /**
     * Get the [id_ref_prestation] column value.
     *
     * @return int
     */
    public function getIdRefPrestation()
    {
        return $this->id_ref_prestation;
    }

    /**
     * Get the [code_libelle_prestation] column value.
     *
     * @return int
     */
    public function getCodeLibellePrestation()
    {
        return $this->code_libelle_prestation;
    }

    /**
     * Get the [id_type_prestation] column value.
     *
     * @return int
     */
    public function getIdTypePrestation()
    {
        return $this->id_type_prestation;
    }

    /**
     * Get the [rdv_similaire] column value.
     *
     * @return string
     */
    public function getRdvSimilaire()
    {
        return $this->rdv_similaire;
    }

    /**
     * Get the [nb_jour_rdv_similaire] column value.
     *
     * @return int
     */
    public function getNbJourRdvSimilaire()
    {
        return $this->nb_jour_rdv_similaire;
    }

    /**
     * Get the [delai_min] column value.
     *
     * @return int
     */
    public function getDelaiMin()
    {
        return $this->delai_min;
    }

    /**
     * Get the [periodicite] column value.
     *
     * @return int
     */
    public function getPeriodicite()
    {
        return $this->periodicite;
    }

    /**
     * Get the [ressource_visible] column value.
     *
     * @return string
     */
    public function getRessourceVisible()
    {
        return $this->ressource_visible;
    }

    /**
     * Get the [ressource_obligatoire] column value.
     *
     * @return string
     */
    public function getRessourceObligatoire()
    {
        return $this->ressource_obligatoire;
    }

    /**
     * Get the [id_parametre_form] column value.
     *
     * @return int
     */
    public function getIdParametreForm()
    {
        return $this->id_parametre_form;
    }

    /**
     * Get the [code_commentaire] column value.
     *
     * @return int
     */
    public function getCodeCommentaire()
    {
        return $this->code_commentaire;
    }

    /**
     * Get the [referent_visible] column value.
     *
     * @return string
     */
    public function getReferentVisible()
    {
        return $this->referent_visible;
    }

    /**
     * Get the [id_parametrage_prestation] column value.
     *
     * @return int
     */
    public function getIdParametragePrestation()
    {
        return $this->id_parametrage_prestation;
    }

    /**
     * Get the [id_champs_supp_1] column value.
     *
     * @return int
     */
    public function getIdChampsSupp1()
    {
        return $this->id_champs_supp_1;
    }

    /**
     * Get the [id_champs_supp_2] column value.
     *
     * @return int
     */
    public function getIdChampsSupp2()
    {
        return $this->id_champs_supp_2;
    }

    /**
     * Get the [id_champs_supp_3] column value.
     *
     * @return int
     */
    public function getIdChampsSupp3()
    {
        return $this->id_champs_supp_3;
    }

    /**
     * Get the [visioconference] column value.
     *
     * @return string
     */
    public function getVisioconference()
    {
        return $this->visioconference;
    }

    /**
     * Get the [rdv_groupe] column value.
     *
     * @return string
     */
    public function getRdvGroupe()
    {
        return $this->rdv_groupe;
    }

    /**
     * Get the [nombre_max_participants] column value.
     *
     * @return int
     */
    public function getNombreMaxParticipants()
    {
        return $this->nombre_max_participants;
    }

    /**
     * Get the [type_session] column value.
     *
     * @return string
     */
    public function getTypeSession()
    {
        return $this->type_session;
    }

    /**
     * Set the value of [id_prestation] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdPrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_prestation !== $v) {
            $this->id_prestation = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_PRESTATION;
        }


        return $this;
    } // setIdPrestation()

    /**
     * Set the value of [id_ref_prestation] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdRefPrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_ref_prestation !== $v) {
            $this->id_ref_prestation = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_REF_PRESTATION;
        }

        if ($this->aTRefPrestation !== null && $this->aTRefPrestation->getIdRefPrestation() !== $v) {
            $this->aTRefPrestation = null;
        }


        return $this;
    } // setIdRefPrestation()

    /**
     * Set the value of [code_libelle_prestation] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setCodeLibellePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_prestation !== $v) {
            $this->code_libelle_prestation = $v;
            $this->modifiedColumns[] = TPrestationPeer::CODE_LIBELLE_PRESTATION;
        }

        if ($this->aTTraductionRelatedByCodeLibellePrestation !== null && $this->aTTraductionRelatedByCodeLibellePrestation->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeLibellePrestation = null;
        }


        return $this;
    } // setCodeLibellePrestation()

    /**
     * Set the value of [id_type_prestation] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdTypePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_type_prestation !== $v) {
            $this->id_type_prestation = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_TYPE_PRESTATION;
        }

        if ($this->aTTypePrestation !== null && $this->aTTypePrestation->getIdTypePrestation() !== $v) {
            $this->aTTypePrestation = null;
        }


        return $this;
    } // setIdTypePrestation()

    /**
     * Set the value of [rdv_similaire] column.
     *
     * @param string $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setRdvSimilaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->rdv_similaire !== $v) {
            $this->rdv_similaire = $v;
            $this->modifiedColumns[] = TPrestationPeer::RDV_SIMILAIRE;
        }


        return $this;
    } // setRdvSimilaire()

    /**
     * Set the value of [nb_jour_rdv_similaire] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setNbJourRdvSimilaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->nb_jour_rdv_similaire !== $v) {
            $this->nb_jour_rdv_similaire = $v;
            $this->modifiedColumns[] = TPrestationPeer::NB_JOUR_RDV_SIMILAIRE;
        }


        return $this;
    } // setNbJourRdvSimilaire()

    /**
     * Set the value of [delai_min] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setDelaiMin($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->delai_min !== $v) {
            $this->delai_min = $v;
            $this->modifiedColumns[] = TPrestationPeer::DELAI_MIN;
        }


        return $this;
    } // setDelaiMin()

    /**
     * Set the value of [periodicite] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setPeriodicite($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->periodicite !== $v) {
            $this->periodicite = $v;
            $this->modifiedColumns[] = TPrestationPeer::PERIODICITE;
        }


        return $this;
    } // setPeriodicite()

    /**
     * Set the value of [ressource_visible] column.
     *
     * @param string $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setRessourceVisible($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ressource_visible !== $v) {
            $this->ressource_visible = $v;
            $this->modifiedColumns[] = TPrestationPeer::RESSOURCE_VISIBLE;
        }


        return $this;
    } // setRessourceVisible()

    /**
     * Set the value of [ressource_obligatoire] column.
     *
     * @param string $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setRessourceObligatoire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->ressource_obligatoire !== $v) {
            $this->ressource_obligatoire = $v;
            $this->modifiedColumns[] = TPrestationPeer::RESSOURCE_OBLIGATOIRE;
        }


        return $this;
    } // setRessourceObligatoire()

    /**
     * Set the value of [id_parametre_form] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdParametreForm($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_parametre_form !== $v) {
            $this->id_parametre_form = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_PARAMETRE_FORM;
        }

        if ($this->aTParametreForm !== null && $this->aTParametreForm->getIdParametreForm() !== $v) {
            $this->aTParametreForm = null;
        }


        return $this;
    } // setIdParametreForm()

    /**
     * Set the value of [code_commentaire] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setCodeCommentaire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_commentaire !== $v) {
            $this->code_commentaire = $v;
            $this->modifiedColumns[] = TPrestationPeer::CODE_COMMENTAIRE;
        }

        if ($this->aTTraductionRelatedByCodeCommentaire !== null && $this->aTTraductionRelatedByCodeCommentaire->getIdTraduction() !== $v) {
            $this->aTTraductionRelatedByCodeCommentaire = null;
        }


        return $this;
    } // setCodeCommentaire()

    /**
     * Set the value of [referent_visible] column.
     *
     * @param string $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setReferentVisible($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->referent_visible !== $v) {
            $this->referent_visible = $v;
            $this->modifiedColumns[] = TPrestationPeer::REFERENT_VISIBLE;
        }


        return $this;
    } // setReferentVisible()

    /**
     * Set the value of [id_parametrage_prestation] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdParametragePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_parametrage_prestation !== $v) {
            $this->id_parametrage_prestation = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_PARAMETRAGE_PRESTATION;
        }

        if ($this->aTParametragePrestation !== null && $this->aTParametragePrestation->getIdParametragePrestation() !== $v) {
            $this->aTParametragePrestation = null;
        }


        return $this;
    } // setIdParametragePrestation()

    /**
     * Set the value of [id_champs_supp_1] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdChampsSupp1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_champs_supp_1 !== $v) {
            $this->id_champs_supp_1 = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_CHAMPS_SUPP_1;
        }

        if ($this->aTChampsSuppRelatedByIdChampsSupp1 !== null && $this->aTChampsSuppRelatedByIdChampsSupp1->getIdChampsSupp() !== $v) {
            $this->aTChampsSuppRelatedByIdChampsSupp1 = null;
        }


        return $this;
    } // setIdChampsSupp1()

    /**
     * Set the value of [id_champs_supp_2] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdChampsSupp2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_champs_supp_2 !== $v) {
            $this->id_champs_supp_2 = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_CHAMPS_SUPP_2;
        }

        if ($this->aTChampsSuppRelatedByIdChampsSupp2 !== null && $this->aTChampsSuppRelatedByIdChampsSupp2->getIdChampsSupp() !== $v) {
            $this->aTChampsSuppRelatedByIdChampsSupp2 = null;
        }


        return $this;
    } // setIdChampsSupp2()

    /**
     * Set the value of [id_champs_supp_3] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setIdChampsSupp3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_champs_supp_3 !== $v) {
            $this->id_champs_supp_3 = $v;
            $this->modifiedColumns[] = TPrestationPeer::ID_CHAMPS_SUPP_3;
        }

        if ($this->aTChampsSuppRelatedByIdChampsSupp3 !== null && $this->aTChampsSuppRelatedByIdChampsSupp3->getIdChampsSupp() !== $v) {
            $this->aTChampsSuppRelatedByIdChampsSupp3 = null;
        }


        return $this;
    } // setIdChampsSupp3()

    /**
     * Set the value of [visioconference] column.
     *
     * @param string $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setVisioconference($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->visioconference !== $v) {
            $this->visioconference = $v;
            $this->modifiedColumns[] = TPrestationPeer::VISIOCONFERENCE;
        }


        return $this;
    } // setVisioconference()

    /**
     * Set the value of [rdv_groupe] column.
     *
     * @param string $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setRdvGroupe($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->rdv_groupe !== $v) {
            $this->rdv_groupe = $v;
            $this->modifiedColumns[] = TPrestationPeer::RDV_GROUPE;
        }


        return $this;
    } // setRdvGroupe()

    /**
     * Set the value of [nombre_max_participants] column.
     *
     * @param int $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setNombreMaxParticipants($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->nombre_max_participants !== $v) {
            $this->nombre_max_participants = $v;
            $this->modifiedColumns[] = TPrestationPeer::NOMBRE_MAX_PARTICIPANTS;
        }


        return $this;
    } // setNombreMaxParticipants()

    /**
     * Set the value of [type_session] column.
     *
     * @param string $v new value
     * @return TPrestation The current object (for fluent API support)
     */
    public function setTypeSession($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->type_session !== $v) {
            $this->type_session = $v;
            $this->modifiedColumns[] = TPrestationPeer::TYPE_SESSION;
        }


        return $this;
    } // setTypeSession()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->rdv_similaire !== '0') {
                return false;
            }

            if ($this->delai_min !== 0) {
                return false;
            }

            if ($this->periodicite !== 0) {
                return false;
            }

            if ($this->ressource_visible !== '1') {
                return false;
            }

            if ($this->ressource_obligatoire !== '0') {
                return false;
            }

            if ($this->referent_visible !== '0') {
                return false;
            }

            if ($this->visioconference !== '0') {
                return false;
            }

            if ($this->rdv_groupe !== '0') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_prestation = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->id_ref_prestation = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->code_libelle_prestation = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->id_type_prestation = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->rdv_similaire = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->nb_jour_rdv_similaire = ($row[$startcol + 5] !== null) ? (int) $row[$startcol + 5] : null;
            $this->delai_min = ($row[$startcol + 6] !== null) ? (int) $row[$startcol + 6] : null;
            $this->periodicite = ($row[$startcol + 7] !== null) ? (int) $row[$startcol + 7] : null;
            $this->ressource_visible = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->ressource_obligatoire = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->id_parametre_form = ($row[$startcol + 10] !== null) ? (int) $row[$startcol + 10] : null;
            $this->code_commentaire = ($row[$startcol + 11] !== null) ? (int) $row[$startcol + 11] : null;
            $this->referent_visible = ($row[$startcol + 12] !== null) ? (string) $row[$startcol + 12] : null;
            $this->id_parametrage_prestation = ($row[$startcol + 13] !== null) ? (int) $row[$startcol + 13] : null;
            $this->id_champs_supp_1 = ($row[$startcol + 14] !== null) ? (int) $row[$startcol + 14] : null;
            $this->id_champs_supp_2 = ($row[$startcol + 15] !== null) ? (int) $row[$startcol + 15] : null;
            $this->id_champs_supp_3 = ($row[$startcol + 16] !== null) ? (int) $row[$startcol + 16] : null;
            $this->visioconference = ($row[$startcol + 17] !== null) ? (string) $row[$startcol + 17] : null;
            $this->rdv_groupe = ($row[$startcol + 18] !== null) ? (string) $row[$startcol + 18] : null;
            $this->nombre_max_participants = ($row[$startcol + 19] !== null) ? (int) $row[$startcol + 19] : null;
            $this->type_session = ($row[$startcol + 20] !== null) ? (string) $row[$startcol + 20] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 21; // 21 = TPrestationPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TPrestation object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTRefPrestation !== null && $this->id_ref_prestation !== $this->aTRefPrestation->getIdRefPrestation()) {
            $this->aTRefPrestation = null;
        }
        if ($this->aTTraductionRelatedByCodeLibellePrestation !== null && $this->code_libelle_prestation !== $this->aTTraductionRelatedByCodeLibellePrestation->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeLibellePrestation = null;
        }
        if ($this->aTTypePrestation !== null && $this->id_type_prestation !== $this->aTTypePrestation->getIdTypePrestation()) {
            $this->aTTypePrestation = null;
        }
        if ($this->aTParametreForm !== null && $this->id_parametre_form !== $this->aTParametreForm->getIdParametreForm()) {
            $this->aTParametreForm = null;
        }
        if ($this->aTTraductionRelatedByCodeCommentaire !== null && $this->code_commentaire !== $this->aTTraductionRelatedByCodeCommentaire->getIdTraduction()) {
            $this->aTTraductionRelatedByCodeCommentaire = null;
        }
        if ($this->aTParametragePrestation !== null && $this->id_parametrage_prestation !== $this->aTParametragePrestation->getIdParametragePrestation()) {
            $this->aTParametragePrestation = null;
        }
        if ($this->aTChampsSuppRelatedByIdChampsSupp1 !== null && $this->id_champs_supp_1 !== $this->aTChampsSuppRelatedByIdChampsSupp1->getIdChampsSupp()) {
            $this->aTChampsSuppRelatedByIdChampsSupp1 = null;
        }
        if ($this->aTChampsSuppRelatedByIdChampsSupp2 !== null && $this->id_champs_supp_2 !== $this->aTChampsSuppRelatedByIdChampsSupp2->getIdChampsSupp()) {
            $this->aTChampsSuppRelatedByIdChampsSupp2 = null;
        }
        if ($this->aTChampsSuppRelatedByIdChampsSupp3 !== null && $this->id_champs_supp_3 !== $this->aTChampsSuppRelatedByIdChampsSupp3->getIdChampsSupp()) {
            $this->aTChampsSuppRelatedByIdChampsSupp3 = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TPrestationPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraductionRelatedByCodeCommentaire = null;
            $this->aTTraductionRelatedByCodeLibellePrestation = null;
            $this->aTParametragePrestation = null;
            $this->aTParametreForm = null;
            $this->aTRefPrestation = null;
            $this->aTTypePrestation = null;
            $this->aTChampsSuppRelatedByIdChampsSupp1 = null;
            $this->aTChampsSuppRelatedByIdChampsSupp2 = null;
            $this->aTChampsSuppRelatedByIdChampsSupp3 = null;
            $this->collTAgendas = null;

            $this->collTAgents = null;

            $this->collTAgentPrestations = null;

            $this->collTDelaiObtentions = null;

            $this->collTPiecePrestations = null;

            $this->collTRendezVouss = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TPrestationQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TPrestationPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TPrestationPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeCommentaire !== null) {
                if ($this->aTTraductionRelatedByCodeCommentaire->isModified() || $this->aTTraductionRelatedByCodeCommentaire->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeCommentaire->save($con);
                }
                $this->setTTraductionRelatedByCodeCommentaire($this->aTTraductionRelatedByCodeCommentaire);
            }

            if ($this->aTTraductionRelatedByCodeLibellePrestation !== null) {
                if ($this->aTTraductionRelatedByCodeLibellePrestation->isModified() || $this->aTTraductionRelatedByCodeLibellePrestation->isNew()) {
                    $affectedRows += $this->aTTraductionRelatedByCodeLibellePrestation->save($con);
                }
                $this->setTTraductionRelatedByCodeLibellePrestation($this->aTTraductionRelatedByCodeLibellePrestation);
            }

            if ($this->aTParametragePrestation !== null) {
                if ($this->aTParametragePrestation->isModified() || $this->aTParametragePrestation->isNew()) {
                    $affectedRows += $this->aTParametragePrestation->save($con);
                }
                $this->setTParametragePrestation($this->aTParametragePrestation);
            }

            if ($this->aTParametreForm !== null) {
                if ($this->aTParametreForm->isModified() || $this->aTParametreForm->isNew()) {
                    $affectedRows += $this->aTParametreForm->save($con);
                }
                $this->setTParametreForm($this->aTParametreForm);
            }

            if ($this->aTRefPrestation !== null) {
                if ($this->aTRefPrestation->isModified() || $this->aTRefPrestation->isNew()) {
                    $affectedRows += $this->aTRefPrestation->save($con);
                }
                $this->setTRefPrestation($this->aTRefPrestation);
            }

            if ($this->aTTypePrestation !== null) {
                if ($this->aTTypePrestation->isModified() || $this->aTTypePrestation->isNew()) {
                    $affectedRows += $this->aTTypePrestation->save($con);
                }
                $this->setTTypePrestation($this->aTTypePrestation);
            }

            if ($this->aTChampsSuppRelatedByIdChampsSupp1 !== null) {
                if ($this->aTChampsSuppRelatedByIdChampsSupp1->isModified() || $this->aTChampsSuppRelatedByIdChampsSupp1->isNew()) {
                    $affectedRows += $this->aTChampsSuppRelatedByIdChampsSupp1->save($con);
                }
                $this->setTChampsSuppRelatedByIdChampsSupp1($this->aTChampsSuppRelatedByIdChampsSupp1);
            }

            if ($this->aTChampsSuppRelatedByIdChampsSupp2 !== null) {
                if ($this->aTChampsSuppRelatedByIdChampsSupp2->isModified() || $this->aTChampsSuppRelatedByIdChampsSupp2->isNew()) {
                    $affectedRows += $this->aTChampsSuppRelatedByIdChampsSupp2->save($con);
                }
                $this->setTChampsSuppRelatedByIdChampsSupp2($this->aTChampsSuppRelatedByIdChampsSupp2);
            }

            if ($this->aTChampsSuppRelatedByIdChampsSupp3 !== null) {
                if ($this->aTChampsSuppRelatedByIdChampsSupp3->isModified() || $this->aTChampsSuppRelatedByIdChampsSupp3->isNew()) {
                    $affectedRows += $this->aTChampsSuppRelatedByIdChampsSupp3->save($con);
                }
                $this->setTChampsSuppRelatedByIdChampsSupp3($this->aTChampsSuppRelatedByIdChampsSupp3);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tAgendasScheduledForDeletion !== null) {
                if (!$this->tAgendasScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgendasScheduledForDeletion as $tAgenda) {
                        // need to save related object because we set the relation to null
                        $tAgenda->save($con);
                    }
                    $this->tAgendasScheduledForDeletion = null;
                }
            }

            if ($this->collTAgendas !== null) {
                foreach ($this->collTAgendas as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentsScheduledForDeletion !== null) {
                if (!$this->tAgentsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgentsScheduledForDeletion as $tAgent) {
                        // need to save related object because we set the relation to null
                        $tAgent->save($con);
                    }
                    $this->tAgentsScheduledForDeletion = null;
                }
            }

            if ($this->collTAgents !== null) {
                foreach ($this->collTAgents as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentPrestationsScheduledForDeletion !== null) {
                if (!$this->tAgentPrestationsScheduledForDeletion->isEmpty()) {
                    TAgentPrestationQuery::create()
                        ->filterByPrimaryKeys($this->tAgentPrestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tAgentPrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentPrestations !== null) {
                foreach ($this->collTAgentPrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tDelaiObtentionsScheduledForDeletion !== null) {
                if (!$this->tDelaiObtentionsScheduledForDeletion->isEmpty()) {
                    TDelaiObtentionQuery::create()
                        ->filterByPrimaryKeys($this->tDelaiObtentionsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tDelaiObtentionsScheduledForDeletion = null;
                }
            }

            if ($this->collTDelaiObtentions !== null) {
                foreach ($this->collTDelaiObtentions as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPiecePrestationsScheduledForDeletion !== null) {
                if (!$this->tPiecePrestationsScheduledForDeletion->isEmpty()) {
                    TPiecePrestationQuery::create()
                        ->filterByPrimaryKeys($this->tPiecePrestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tPiecePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTPiecePrestations !== null) {
                foreach ($this->collTPiecePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRendezVoussScheduledForDeletion !== null) {
                if (!$this->tRendezVoussScheduledForDeletion->isEmpty()) {
                    TRendezVousQuery::create()
                        ->filterByPrimaryKeys($this->tRendezVoussScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tRendezVoussScheduledForDeletion = null;
                }
            }

            if ($this->collTRendezVouss !== null) {
                foreach ($this->collTRendezVouss as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TPrestationPeer::ID_PRESTATION;
        if (null !== $this->id_prestation) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TPrestationPeer::ID_PRESTATION . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TPrestationPeer::ID_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PRESTATION`';
        }
        if ($this->isColumnModified(TPrestationPeer::ID_REF_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_REF_PRESTATION`';
        }
        if ($this->isColumnModified(TPrestationPeer::CODE_LIBELLE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_PRESTATION`';
        }
        if ($this->isColumnModified(TPrestationPeer::ID_TYPE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_TYPE_PRESTATION`';
        }
        if ($this->isColumnModified(TPrestationPeer::RDV_SIMILAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`RDV_SIMILAIRE`';
        }
        if ($this->isColumnModified(TPrestationPeer::NB_JOUR_RDV_SIMILAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`NB_JOUR_RDV_SIMILAIRE`';
        }
        if ($this->isColumnModified(TPrestationPeer::DELAI_MIN)) {
            $modifiedColumns[':p' . $index++]  = '`DELAI_MIN`';
        }
        if ($this->isColumnModified(TPrestationPeer::PERIODICITE)) {
            $modifiedColumns[':p' . $index++]  = '`PERIODICITE`';
        }
        if ($this->isColumnModified(TPrestationPeer::RESSOURCE_VISIBLE)) {
            $modifiedColumns[':p' . $index++]  = '`RESSOURCE_VISIBLE`';
        }
        if ($this->isColumnModified(TPrestationPeer::RESSOURCE_OBLIGATOIRE)) {
            $modifiedColumns[':p' . $index++]  = '`RESSOURCE_OBLIGATOIRE`';
        }
        if ($this->isColumnModified(TPrestationPeer::ID_PARAMETRE_FORM)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PARAMETRE_FORM`';
        }
        if ($this->isColumnModified(TPrestationPeer::CODE_COMMENTAIRE)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_COMMENTAIRE`';
        }
        if ($this->isColumnModified(TPrestationPeer::REFERENT_VISIBLE)) {
            $modifiedColumns[':p' . $index++]  = '`REFERENT_VISIBLE`';
        }
        if ($this->isColumnModified(TPrestationPeer::ID_PARAMETRAGE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PARAMETRAGE_PRESTATION`';
        }
        if ($this->isColumnModified(TPrestationPeer::ID_CHAMPS_SUPP_1)) {
            $modifiedColumns[':p' . $index++]  = '`ID_CHAMPS_SUPP_1`';
        }
        if ($this->isColumnModified(TPrestationPeer::ID_CHAMPS_SUPP_2)) {
            $modifiedColumns[':p' . $index++]  = '`ID_CHAMPS_SUPP_2`';
        }
        if ($this->isColumnModified(TPrestationPeer::ID_CHAMPS_SUPP_3)) {
            $modifiedColumns[':p' . $index++]  = '`ID_CHAMPS_SUPP_3`';
        }
        if ($this->isColumnModified(TPrestationPeer::VISIOCONFERENCE)) {
            $modifiedColumns[':p' . $index++]  = '`VISIOCONFERENCE`';
        }
        if ($this->isColumnModified(TPrestationPeer::RDV_GROUPE)) {
            $modifiedColumns[':p' . $index++]  = '`RDV_GROUPE`';
        }
        if ($this->isColumnModified(TPrestationPeer::NOMBRE_MAX_PARTICIPANTS)) {
            $modifiedColumns[':p' . $index++]  = '`NOMBRE_MAX_PARTICIPANTS`';
        }
        if ($this->isColumnModified(TPrestationPeer::TYPE_SESSION)) {
            $modifiedColumns[':p' . $index++]  = '`TYPE_SESSION`';
        }

        $sql = sprintf(
            'INSERT INTO `T_PRESTATION` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_prestation, PDO::PARAM_INT);
                        break;
                    case '`ID_REF_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_ref_prestation, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->code_libelle_prestation, PDO::PARAM_INT);
                        break;
                    case '`ID_TYPE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_type_prestation, PDO::PARAM_INT);
                        break;
                    case '`RDV_SIMILAIRE`':
                        $stmt->bindValue($identifier, $this->rdv_similaire, PDO::PARAM_STR);
                        break;
                    case '`NB_JOUR_RDV_SIMILAIRE`':
                        $stmt->bindValue($identifier, $this->nb_jour_rdv_similaire, PDO::PARAM_INT);
                        break;
                    case '`DELAI_MIN`':
                        $stmt->bindValue($identifier, $this->delai_min, PDO::PARAM_INT);
                        break;
                    case '`PERIODICITE`':
                        $stmt->bindValue($identifier, $this->periodicite, PDO::PARAM_INT);
                        break;
                    case '`RESSOURCE_VISIBLE`':
                        $stmt->bindValue($identifier, $this->ressource_visible, PDO::PARAM_STR);
                        break;
                    case '`RESSOURCE_OBLIGATOIRE`':
                        $stmt->bindValue($identifier, $this->ressource_obligatoire, PDO::PARAM_STR);
                        break;
                    case '`ID_PARAMETRE_FORM`':
                        $stmt->bindValue($identifier, $this->id_parametre_form, PDO::PARAM_INT);
                        break;
                    case '`CODE_COMMENTAIRE`':
                        $stmt->bindValue($identifier, $this->code_commentaire, PDO::PARAM_INT);
                        break;
                    case '`REFERENT_VISIBLE`':
                        $stmt->bindValue($identifier, $this->referent_visible, PDO::PARAM_STR);
                        break;
                    case '`ID_PARAMETRAGE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->id_parametrage_prestation, PDO::PARAM_INT);
                        break;
                    case '`ID_CHAMPS_SUPP_1`':
                        $stmt->bindValue($identifier, $this->id_champs_supp_1, PDO::PARAM_INT);
                        break;
                    case '`ID_CHAMPS_SUPP_2`':
                        $stmt->bindValue($identifier, $this->id_champs_supp_2, PDO::PARAM_INT);
                        break;
                    case '`ID_CHAMPS_SUPP_3`':
                        $stmt->bindValue($identifier, $this->id_champs_supp_3, PDO::PARAM_INT);
                        break;
                    case '`VISIOCONFERENCE`':
                        $stmt->bindValue($identifier, $this->visioconference, PDO::PARAM_STR);
                        break;
                    case '`RDV_GROUPE`':
                        $stmt->bindValue($identifier, $this->rdv_groupe, PDO::PARAM_STR);
                        break;
                    case '`NOMBRE_MAX_PARTICIPANTS`':
                        $stmt->bindValue($identifier, $this->nombre_max_participants, PDO::PARAM_INT);
                        break;
                    case '`TYPE_SESSION`':
                        $stmt->bindValue($identifier, $this->type_session, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdPrestation($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraductionRelatedByCodeCommentaire !== null) {
                if (!$this->aTTraductionRelatedByCodeCommentaire->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeCommentaire->getValidationFailures());
                }
            }

            if ($this->aTTraductionRelatedByCodeLibellePrestation !== null) {
                if (!$this->aTTraductionRelatedByCodeLibellePrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraductionRelatedByCodeLibellePrestation->getValidationFailures());
                }
            }

            if ($this->aTParametragePrestation !== null) {
                if (!$this->aTParametragePrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTParametragePrestation->getValidationFailures());
                }
            }

            if ($this->aTParametreForm !== null) {
                if (!$this->aTParametreForm->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTParametreForm->getValidationFailures());
                }
            }

            if ($this->aTRefPrestation !== null) {
                if (!$this->aTRefPrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTRefPrestation->getValidationFailures());
                }
            }

            if ($this->aTTypePrestation !== null) {
                if (!$this->aTTypePrestation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTypePrestation->getValidationFailures());
                }
            }

            if ($this->aTChampsSuppRelatedByIdChampsSupp1 !== null) {
                if (!$this->aTChampsSuppRelatedByIdChampsSupp1->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTChampsSuppRelatedByIdChampsSupp1->getValidationFailures());
                }
            }

            if ($this->aTChampsSuppRelatedByIdChampsSupp2 !== null) {
                if (!$this->aTChampsSuppRelatedByIdChampsSupp2->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTChampsSuppRelatedByIdChampsSupp2->getValidationFailures());
                }
            }

            if ($this->aTChampsSuppRelatedByIdChampsSupp3 !== null) {
                if (!$this->aTChampsSuppRelatedByIdChampsSupp3->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTChampsSuppRelatedByIdChampsSupp3->getValidationFailures());
                }
            }


            if (($retval = TPrestationPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTAgendas !== null) {
                    foreach ($this->collTAgendas as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgents !== null) {
                    foreach ($this->collTAgents as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgentPrestations !== null) {
                    foreach ($this->collTAgentPrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTDelaiObtentions !== null) {
                    foreach ($this->collTDelaiObtentions as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPiecePrestations !== null) {
                    foreach ($this->collTPiecePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRendezVouss !== null) {
                    foreach ($this->collTRendezVouss as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TPrestationPeer::DATABASE_NAME);

        if ($this->isColumnModified(TPrestationPeer::ID_PRESTATION)) $criteria->add(TPrestationPeer::ID_PRESTATION, $this->id_prestation);
        if ($this->isColumnModified(TPrestationPeer::ID_REF_PRESTATION)) $criteria->add(TPrestationPeer::ID_REF_PRESTATION, $this->id_ref_prestation);
        if ($this->isColumnModified(TPrestationPeer::CODE_LIBELLE_PRESTATION)) $criteria->add(TPrestationPeer::CODE_LIBELLE_PRESTATION, $this->code_libelle_prestation);
        if ($this->isColumnModified(TPrestationPeer::ID_TYPE_PRESTATION)) $criteria->add(TPrestationPeer::ID_TYPE_PRESTATION, $this->id_type_prestation);
        if ($this->isColumnModified(TPrestationPeer::RDV_SIMILAIRE)) $criteria->add(TPrestationPeer::RDV_SIMILAIRE, $this->rdv_similaire);
        if ($this->isColumnModified(TPrestationPeer::NB_JOUR_RDV_SIMILAIRE)) $criteria->add(TPrestationPeer::NB_JOUR_RDV_SIMILAIRE, $this->nb_jour_rdv_similaire);
        if ($this->isColumnModified(TPrestationPeer::DELAI_MIN)) $criteria->add(TPrestationPeer::DELAI_MIN, $this->delai_min);
        if ($this->isColumnModified(TPrestationPeer::PERIODICITE)) $criteria->add(TPrestationPeer::PERIODICITE, $this->periodicite);
        if ($this->isColumnModified(TPrestationPeer::RESSOURCE_VISIBLE)) $criteria->add(TPrestationPeer::RESSOURCE_VISIBLE, $this->ressource_visible);
        if ($this->isColumnModified(TPrestationPeer::RESSOURCE_OBLIGATOIRE)) $criteria->add(TPrestationPeer::RESSOURCE_OBLIGATOIRE, $this->ressource_obligatoire);
        if ($this->isColumnModified(TPrestationPeer::ID_PARAMETRE_FORM)) $criteria->add(TPrestationPeer::ID_PARAMETRE_FORM, $this->id_parametre_form);
        if ($this->isColumnModified(TPrestationPeer::CODE_COMMENTAIRE)) $criteria->add(TPrestationPeer::CODE_COMMENTAIRE, $this->code_commentaire);
        if ($this->isColumnModified(TPrestationPeer::REFERENT_VISIBLE)) $criteria->add(TPrestationPeer::REFERENT_VISIBLE, $this->referent_visible);
        if ($this->isColumnModified(TPrestationPeer::ID_PARAMETRAGE_PRESTATION)) $criteria->add(TPrestationPeer::ID_PARAMETRAGE_PRESTATION, $this->id_parametrage_prestation);
        if ($this->isColumnModified(TPrestationPeer::ID_CHAMPS_SUPP_1)) $criteria->add(TPrestationPeer::ID_CHAMPS_SUPP_1, $this->id_champs_supp_1);
        if ($this->isColumnModified(TPrestationPeer::ID_CHAMPS_SUPP_2)) $criteria->add(TPrestationPeer::ID_CHAMPS_SUPP_2, $this->id_champs_supp_2);
        if ($this->isColumnModified(TPrestationPeer::ID_CHAMPS_SUPP_3)) $criteria->add(TPrestationPeer::ID_CHAMPS_SUPP_3, $this->id_champs_supp_3);
        if ($this->isColumnModified(TPrestationPeer::VISIOCONFERENCE)) $criteria->add(TPrestationPeer::VISIOCONFERENCE, $this->visioconference);
        if ($this->isColumnModified(TPrestationPeer::RDV_GROUPE)) $criteria->add(TPrestationPeer::RDV_GROUPE, $this->rdv_groupe);
        if ($this->isColumnModified(TPrestationPeer::NOMBRE_MAX_PARTICIPANTS)) $criteria->add(TPrestationPeer::NOMBRE_MAX_PARTICIPANTS, $this->nombre_max_participants);
        if ($this->isColumnModified(TPrestationPeer::TYPE_SESSION)) $criteria->add(TPrestationPeer::TYPE_SESSION, $this->type_session);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TPrestationPeer::DATABASE_NAME);
        $criteria->add(TPrestationPeer::ID_PRESTATION, $this->id_prestation);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdPrestation();
    }

    /**
     * Generic method to set the primary key (id_prestation column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdPrestation($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdPrestation();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TPrestation (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setIdRefPrestation($this->getIdRefPrestation());
        $copyObj->setCodeLibellePrestation($this->getCodeLibellePrestation());
        $copyObj->setIdTypePrestation($this->getIdTypePrestation());
        $copyObj->setRdvSimilaire($this->getRdvSimilaire());
        $copyObj->setNbJourRdvSimilaire($this->getNbJourRdvSimilaire());
        $copyObj->setDelaiMin($this->getDelaiMin());
        $copyObj->setPeriodicite($this->getPeriodicite());
        $copyObj->setRessourceVisible($this->getRessourceVisible());
        $copyObj->setRessourceObligatoire($this->getRessourceObligatoire());
        $copyObj->setIdParametreForm($this->getIdParametreForm());
        $copyObj->setCodeCommentaire($this->getCodeCommentaire());
        $copyObj->setReferentVisible($this->getReferentVisible());
        $copyObj->setIdParametragePrestation($this->getIdParametragePrestation());
        $copyObj->setIdChampsSupp1($this->getIdChampsSupp1());
        $copyObj->setIdChampsSupp2($this->getIdChampsSupp2());
        $copyObj->setIdChampsSupp3($this->getIdChampsSupp3());
        $copyObj->setVisioconference($this->getVisioconference());
        $copyObj->setRdvGroupe($this->getRdvGroupe());
        $copyObj->setNombreMaxParticipants($this->getNombreMaxParticipants());
        $copyObj->setTypeSession($this->getTypeSession());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTAgendas() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgenda($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgents() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgent($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgentPrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentPrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTDelaiObtentions() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTDelaiObtention($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPiecePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPiecePrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRendezVouss() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRendezVous($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdPrestation(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TPrestation Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TPrestationPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TPrestationPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeCommentaire(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeCommentaire(NULL);
        } else {
            $this->setCodeCommentaire($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeCommentaire = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestationRelatedByCodeCommentaire($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeCommentaire(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeCommentaire === null && ($this->code_commentaire !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeCommentaire = TTraductionQuery::create()->findPk($this->code_commentaire, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeCommentaire->addTPrestationsRelatedByCodeCommentaire($this);
             */
        }

        return $this->aTTraductionRelatedByCodeCommentaire;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraductionRelatedByCodeLibellePrestation(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibellePrestation(NULL);
        } else {
            $this->setCodeLibellePrestation($v->getIdTraduction());
        }

        $this->aTTraductionRelatedByCodeLibellePrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestationRelatedByCodeLibellePrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraductionRelatedByCodeLibellePrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraductionRelatedByCodeLibellePrestation === null && ($this->code_libelle_prestation !== null) && $doQuery) {
            $this->aTTraductionRelatedByCodeLibellePrestation = TTraductionQuery::create()->findPk($this->code_libelle_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraductionRelatedByCodeLibellePrestation->addTPrestationsRelatedByCodeLibellePrestation($this);
             */
        }

        return $this->aTTraductionRelatedByCodeLibellePrestation;
    }

    /**
     * Declares an association between this object and a TParametragePrestation object.
     *
     * @param             TParametragePrestation $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTParametragePrestation(TParametragePrestation $v = null)
    {
        if ($v === null) {
            $this->setIdParametragePrestation(NULL);
        } else {
            $this->setIdParametragePrestation($v->getIdParametragePrestation());
        }

        $this->aTParametragePrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TParametragePrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TParametragePrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TParametragePrestation The associated TParametragePrestation object.
     * @throws PropelException
     */
    public function getTParametragePrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTParametragePrestation === null && ($this->id_parametrage_prestation !== null) && $doQuery) {
            $this->aTParametragePrestation = TParametragePrestationQuery::create()->findPk($this->id_parametrage_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTParametragePrestation->addTPrestations($this);
             */
        }

        return $this->aTParametragePrestation;
    }

    /**
     * Declares an association between this object and a TParametreForm object.
     *
     * @param             TParametreForm $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTParametreForm(TParametreForm $v = null)
    {
        if ($v === null) {
            $this->setIdParametreForm(NULL);
        } else {
            $this->setIdParametreForm($v->getIdParametreForm());
        }

        $this->aTParametreForm = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TParametreForm object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TParametreForm object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TParametreForm The associated TParametreForm object.
     * @throws PropelException
     */
    public function getTParametreForm(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTParametreForm === null && ($this->id_parametre_form !== null) && $doQuery) {
            $this->aTParametreForm = TParametreFormQuery::create()->findPk($this->id_parametre_form, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTParametreForm->addTPrestations($this);
             */
        }

        return $this->aTParametreForm;
    }

    /**
     * Declares an association between this object and a TRefPrestation object.
     *
     * @param             TRefPrestation $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTRefPrestation(TRefPrestation $v = null)
    {
        if ($v === null) {
            $this->setIdRefPrestation(NULL);
        } else {
            $this->setIdRefPrestation($v->getIdRefPrestation());
        }

        $this->aTRefPrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TRefPrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TRefPrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TRefPrestation The associated TRefPrestation object.
     * @throws PropelException
     */
    public function getTRefPrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTRefPrestation === null && ($this->id_ref_prestation !== null) && $doQuery) {
            $this->aTRefPrestation = TRefPrestationQuery::create()->findPk($this->id_ref_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTRefPrestation->addTPrestations($this);
             */
        }

        return $this->aTRefPrestation;
    }

    /**
     * Declares an association between this object and a TTypePrestation object.
     *
     * @param             TTypePrestation $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTypePrestation(TTypePrestation $v = null)
    {
        if ($v === null) {
            $this->setIdTypePrestation(NULL);
        } else {
            $this->setIdTypePrestation($v->getIdTypePrestation());
        }

        $this->aTTypePrestation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTypePrestation object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestation($this);
        }


        return $this;
    }


    /**
     * Get the associated TTypePrestation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTypePrestation The associated TTypePrestation object.
     * @throws PropelException
     */
    public function getTTypePrestation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTypePrestation === null && ($this->id_type_prestation !== null) && $doQuery) {
            $this->aTTypePrestation = TTypePrestationQuery::create()->findPk($this->id_type_prestation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTypePrestation->addTPrestations($this);
             */
        }

        return $this->aTTypePrestation;
    }

    /**
     * Declares an association between this object and a TChampsSupp object.
     *
     * @param             TChampsSupp $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTChampsSuppRelatedByIdChampsSupp1(TChampsSupp $v = null)
    {
        if ($v === null) {
            $this->setIdChampsSupp1(NULL);
        } else {
            $this->setIdChampsSupp1($v->getIdChampsSupp());
        }

        $this->aTChampsSuppRelatedByIdChampsSupp1 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TChampsSupp object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestationRelatedByIdChampsSupp1($this);
        }


        return $this;
    }


    /**
     * Get the associated TChampsSupp object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TChampsSupp The associated TChampsSupp object.
     * @throws PropelException
     */
    public function getTChampsSuppRelatedByIdChampsSupp1(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTChampsSuppRelatedByIdChampsSupp1 === null && ($this->id_champs_supp_1 !== null) && $doQuery) {
            $this->aTChampsSuppRelatedByIdChampsSupp1 = TChampsSuppQuery::create()->findPk($this->id_champs_supp_1, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTChampsSuppRelatedByIdChampsSupp1->addTPrestationsRelatedByIdChampsSupp1($this);
             */
        }

        return $this->aTChampsSuppRelatedByIdChampsSupp1;
    }

    /**
     * Declares an association between this object and a TChampsSupp object.
     *
     * @param             TChampsSupp $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTChampsSuppRelatedByIdChampsSupp2(TChampsSupp $v = null)
    {
        if ($v === null) {
            $this->setIdChampsSupp2(NULL);
        } else {
            $this->setIdChampsSupp2($v->getIdChampsSupp());
        }

        $this->aTChampsSuppRelatedByIdChampsSupp2 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TChampsSupp object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestationRelatedByIdChampsSupp2($this);
        }


        return $this;
    }


    /**
     * Get the associated TChampsSupp object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TChampsSupp The associated TChampsSupp object.
     * @throws PropelException
     */
    public function getTChampsSuppRelatedByIdChampsSupp2(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTChampsSuppRelatedByIdChampsSupp2 === null && ($this->id_champs_supp_2 !== null) && $doQuery) {
            $this->aTChampsSuppRelatedByIdChampsSupp2 = TChampsSuppQuery::create()->findPk($this->id_champs_supp_2, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTChampsSuppRelatedByIdChampsSupp2->addTPrestationsRelatedByIdChampsSupp2($this);
             */
        }

        return $this->aTChampsSuppRelatedByIdChampsSupp2;
    }

    /**
     * Declares an association between this object and a TChampsSupp object.
     *
     * @param             TChampsSupp $v
     * @return TPrestation The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTChampsSuppRelatedByIdChampsSupp3(TChampsSupp $v = null)
    {
        if ($v === null) {
            $this->setIdChampsSupp3(NULL);
        } else {
            $this->setIdChampsSupp3($v->getIdChampsSupp());
        }

        $this->aTChampsSuppRelatedByIdChampsSupp3 = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TChampsSupp object, it will not be re-added.
        if ($v !== null) {
            $v->addTPrestationRelatedByIdChampsSupp3($this);
        }


        return $this;
    }


    /**
     * Get the associated TChampsSupp object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TChampsSupp The associated TChampsSupp object.
     * @throws PropelException
     */
    public function getTChampsSuppRelatedByIdChampsSupp3(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTChampsSuppRelatedByIdChampsSupp3 === null && ($this->id_champs_supp_3 !== null) && $doQuery) {
            $this->aTChampsSuppRelatedByIdChampsSupp3 = TChampsSuppQuery::create()->findPk($this->id_champs_supp_3, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTChampsSuppRelatedByIdChampsSupp3->addTPrestationsRelatedByIdChampsSupp3($this);
             */
        }

        return $this->aTChampsSuppRelatedByIdChampsSupp3;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TAgenda' == $relationName) {
            $this->initTAgendas();
        }
        if ('TAgent' == $relationName) {
            $this->initTAgents();
        }
        if ('TAgentPrestation' == $relationName) {
            $this->initTAgentPrestations();
        }
        if ('TDelaiObtention' == $relationName) {
            $this->initTDelaiObtentions();
        }
        if ('TPiecePrestation' == $relationName) {
            $this->initTPiecePrestations();
        }
        if ('TRendezVous' == $relationName) {
            $this->initTRendezVouss();
        }
    }

    /**
     * Clears out the collTAgendas collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TPrestation The current object (for fluent API support)
     * @see        addTAgendas()
     */
    public function clearTAgendas()
    {
        $this->collTAgendas = null; // important to set this to null since that means it is uninitialized
        $this->collTAgendasPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgendas collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgendas($v = true)
    {
        $this->collTAgendasPartial = $v;
    }

    /**
     * Initializes the collTAgendas collection.
     *
     * By default this just sets the collTAgendas collection to an empty array (like clearcollTAgendas());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgendas($overrideExisting = true)
    {
        if (null !== $this->collTAgendas && !$overrideExisting) {
            return;
        }
        $this->collTAgendas = new PropelObjectCollection();
        $this->collTAgendas->setModel('TAgenda');
    }

    /**
     * Gets an array of TAgenda objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TPrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgenda[] List of TAgenda objects
     * @throws PropelException
     */
    public function getTAgendas($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgendasPartial && !$this->isNew();
        if (null === $this->collTAgendas || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgendas) {
                // return empty collection
                $this->initTAgendas();
            } else {
                $collTAgendas = TAgendaQuery::create(null, $criteria)
                    ->filterByTPrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgendasPartial && count($collTAgendas)) {
                      $this->initTAgendas(false);

                      foreach($collTAgendas as $obj) {
                        if (false == $this->collTAgendas->contains($obj)) {
                          $this->collTAgendas->append($obj);
                        }
                      }

                      $this->collTAgendasPartial = true;
                    }

                    $collTAgendas->getInternalIterator()->rewind();
                    return $collTAgendas;
                }

                if($partial && $this->collTAgendas) {
                    foreach($this->collTAgendas as $obj) {
                        if($obj->isNew()) {
                            $collTAgendas[] = $obj;
                        }
                    }
                }

                $this->collTAgendas = $collTAgendas;
                $this->collTAgendasPartial = false;
            }
        }

        return $this->collTAgendas;
    }

    /**
     * Sets a collection of TAgenda objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgendas A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TPrestation The current object (for fluent API support)
     */
    public function setTAgendas(PropelCollection $tAgendas, PropelPDO $con = null)
    {
        $tAgendasToDelete = $this->getTAgendas(new Criteria(), $con)->diff($tAgendas);

        $this->tAgendasScheduledForDeletion = unserialize(serialize($tAgendasToDelete));

        foreach ($tAgendasToDelete as $tAgendaRemoved) {
            $tAgendaRemoved->setTPrestation(null);
        }

        $this->collTAgendas = null;
        foreach ($tAgendas as $tAgenda) {
            $this->addTAgenda($tAgenda);
        }

        $this->collTAgendas = $tAgendas;
        $this->collTAgendasPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgenda objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgenda objects.
     * @throws PropelException
     */
    public function countTAgendas(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgendasPartial && !$this->isNew();
        if (null === $this->collTAgendas || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgendas) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgendas());
            }
            $query = TAgendaQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTPrestation($this)
                ->count($con);
        }

        return count($this->collTAgendas);
    }

    /**
     * Method called to associate a TAgenda object to this object
     * through the TAgenda foreign key attribute.
     *
     * @param    TAgenda $l TAgenda
     * @return TPrestation The current object (for fluent API support)
     */
    public function addTAgenda(TAgenda $l)
    {
        if ($this->collTAgendas === null) {
            $this->initTAgendas();
            $this->collTAgendasPartial = true;
        }
        if (!in_array($l, $this->collTAgendas->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgenda($l);
        }

        return $this;
    }

    /**
     * @param	TAgenda $tAgenda The tAgenda object to add.
     */
    protected function doAddTAgenda($tAgenda)
    {
        $this->collTAgendas[]= $tAgenda;
        $tAgenda->setTPrestation($this);
    }

    /**
     * @param	TAgenda $tAgenda The tAgenda object to remove.
     * @return TPrestation The current object (for fluent API support)
     */
    public function removeTAgenda($tAgenda)
    {
        if ($this->getTAgendas()->contains($tAgenda)) {
            $this->collTAgendas->remove($this->collTAgendas->search($tAgenda));
            if (null === $this->tAgendasScheduledForDeletion) {
                $this->tAgendasScheduledForDeletion = clone $this->collTAgendas;
                $this->tAgendasScheduledForDeletion->clear();
            }
            $this->tAgendasScheduledForDeletion[]= $tAgenda;
            $tAgenda->setTPrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgendas from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgenda[] List of TAgenda objects
     */
    public function getTAgendasJoinTAgent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgendaQuery::create(null, $criteria);
        $query->joinWith('TAgent', $join_behavior);

        return $this->getTAgendas($query, $con);
    }

    /**
     * Clears out the collTAgents collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TPrestation The current object (for fluent API support)
     * @see        addTAgents()
     */
    public function clearTAgents()
    {
        $this->collTAgents = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentsPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgents collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgents($v = true)
    {
        $this->collTAgentsPartial = $v;
    }

    /**
     * Initializes the collTAgents collection.
     *
     * By default this just sets the collTAgents collection to an empty array (like clearcollTAgents());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgents($overrideExisting = true)
    {
        if (null !== $this->collTAgents && !$overrideExisting) {
            return;
        }
        $this->collTAgents = new PropelObjectCollection();
        $this->collTAgents->setModel('TAgent');
    }

    /**
     * Gets an array of TAgent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TPrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     * @throws PropelException
     */
    public function getTAgents($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsPartial && !$this->isNew();
        if (null === $this->collTAgents || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgents) {
                // return empty collection
                $this->initTAgents();
            } else {
                $collTAgents = TAgentQuery::create(null, $criteria)
                    ->filterByTPrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentsPartial && count($collTAgents)) {
                      $this->initTAgents(false);

                      foreach($collTAgents as $obj) {
                        if (false == $this->collTAgents->contains($obj)) {
                          $this->collTAgents->append($obj);
                        }
                      }

                      $this->collTAgentsPartial = true;
                    }

                    $collTAgents->getInternalIterator()->rewind();
                    return $collTAgents;
                }

                if($partial && $this->collTAgents) {
                    foreach($this->collTAgents as $obj) {
                        if($obj->isNew()) {
                            $collTAgents[] = $obj;
                        }
                    }
                }

                $this->collTAgents = $collTAgents;
                $this->collTAgentsPartial = false;
            }
        }

        return $this->collTAgents;
    }

    /**
     * Sets a collection of TAgent objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgents A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TPrestation The current object (for fluent API support)
     */
    public function setTAgents(PropelCollection $tAgents, PropelPDO $con = null)
    {
        $tAgentsToDelete = $this->getTAgents(new Criteria(), $con)->diff($tAgents);

        $this->tAgentsScheduledForDeletion = unserialize(serialize($tAgentsToDelete));

        foreach ($tAgentsToDelete as $tAgentRemoved) {
            $tAgentRemoved->setTPrestation(null);
        }

        $this->collTAgents = null;
        foreach ($tAgents as $tAgent) {
            $this->addTAgent($tAgent);
        }

        $this->collTAgents = $tAgents;
        $this->collTAgentsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgent objects.
     * @throws PropelException
     */
    public function countTAgents(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsPartial && !$this->isNew();
        if (null === $this->collTAgents || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgents) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgents());
            }
            $query = TAgentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTPrestation($this)
                ->count($con);
        }

        return count($this->collTAgents);
    }

    /**
     * Method called to associate a TAgent object to this object
     * through the TAgent foreign key attribute.
     *
     * @param    TAgent $l TAgent
     * @return TPrestation The current object (for fluent API support)
     */
    public function addTAgent(TAgent $l)
    {
        if ($this->collTAgents === null) {
            $this->initTAgents();
            $this->collTAgentsPartial = true;
        }
        if (!in_array($l, $this->collTAgents->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgent($l);
        }

        return $this;
    }

    /**
     * @param	TAgent $tAgent The tAgent object to add.
     */
    protected function doAddTAgent($tAgent)
    {
        $this->collTAgents[]= $tAgent;
        $tAgent->setTPrestation($this);
    }

    /**
     * @param	TAgent $tAgent The tAgent object to remove.
     * @return TPrestation The current object (for fluent API support)
     */
    public function removeTAgent($tAgent)
    {
        if ($this->getTAgents()->contains($tAgent)) {
            $this->collTAgents->remove($this->collTAgents->search($tAgent));
            if (null === $this->tAgentsScheduledForDeletion) {
                $this->tAgentsScheduledForDeletion = clone $this->collTAgents;
                $this->tAgentsScheduledForDeletion->clear();
            }
            $this->tAgentsScheduledForDeletion[]= $tAgent;
            $tAgent->setTPrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTTraductionRelatedByCodeNomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeNomUtilisateur', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTTraductionRelatedByCodePrenomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodePrenomUtilisateur', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTEtablissementRelatedByIdEtablissementAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementAttache', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTEtablissementRelatedByIdEtablissementGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementGere', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTOrganisationRelatedByIdOrganisationAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationAttache', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTOrganisationRelatedByIdOrganisationGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationGere', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTProfil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TProfil', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTTraductionRelatedByCodeUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeUtilisateur', $join_behavior);

        return $this->getTAgents($query, $con);
    }

    /**
     * Clears out the collTAgentPrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TPrestation The current object (for fluent API support)
     * @see        addTAgentPrestations()
     */
    public function clearTAgentPrestations()
    {
        $this->collTAgentPrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentPrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentPrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentPrestations($v = true)
    {
        $this->collTAgentPrestationsPartial = $v;
    }

    /**
     * Initializes the collTAgentPrestations collection.
     *
     * By default this just sets the collTAgentPrestations collection to an empty array (like clearcollTAgentPrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentPrestations($overrideExisting = true)
    {
        if (null !== $this->collTAgentPrestations && !$overrideExisting) {
            return;
        }
        $this->collTAgentPrestations = new PropelObjectCollection();
        $this->collTAgentPrestations->setModel('TAgentPrestation');
    }

    /**
     * Gets an array of TAgentPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TPrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgentPrestation[] List of TAgentPrestation objects
     * @throws PropelException
     */
    public function getTAgentPrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentPrestationsPartial && !$this->isNew();
        if (null === $this->collTAgentPrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentPrestations) {
                // return empty collection
                $this->initTAgentPrestations();
            } else {
                $collTAgentPrestations = TAgentPrestationQuery::create(null, $criteria)
                    ->filterByTPrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentPrestationsPartial && count($collTAgentPrestations)) {
                      $this->initTAgentPrestations(false);

                      foreach($collTAgentPrestations as $obj) {
                        if (false == $this->collTAgentPrestations->contains($obj)) {
                          $this->collTAgentPrestations->append($obj);
                        }
                      }

                      $this->collTAgentPrestationsPartial = true;
                    }

                    $collTAgentPrestations->getInternalIterator()->rewind();
                    return $collTAgentPrestations;
                }

                if($partial && $this->collTAgentPrestations) {
                    foreach($this->collTAgentPrestations as $obj) {
                        if($obj->isNew()) {
                            $collTAgentPrestations[] = $obj;
                        }
                    }
                }

                $this->collTAgentPrestations = $collTAgentPrestations;
                $this->collTAgentPrestationsPartial = false;
            }
        }

        return $this->collTAgentPrestations;
    }

    /**
     * Sets a collection of TAgentPrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentPrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TPrestation The current object (for fluent API support)
     */
    public function setTAgentPrestations(PropelCollection $tAgentPrestations, PropelPDO $con = null)
    {
        $tAgentPrestationsToDelete = $this->getTAgentPrestations(new Criteria(), $con)->diff($tAgentPrestations);

        $this->tAgentPrestationsScheduledForDeletion = unserialize(serialize($tAgentPrestationsToDelete));

        foreach ($tAgentPrestationsToDelete as $tAgentPrestationRemoved) {
            $tAgentPrestationRemoved->setTPrestation(null);
        }

        $this->collTAgentPrestations = null;
        foreach ($tAgentPrestations as $tAgentPrestation) {
            $this->addTAgentPrestation($tAgentPrestation);
        }

        $this->collTAgentPrestations = $tAgentPrestations;
        $this->collTAgentPrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgentPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgentPrestation objects.
     * @throws PropelException
     */
    public function countTAgentPrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentPrestationsPartial && !$this->isNew();
        if (null === $this->collTAgentPrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentPrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentPrestations());
            }
            $query = TAgentPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTPrestation($this)
                ->count($con);
        }

        return count($this->collTAgentPrestations);
    }

    /**
     * Method called to associate a TAgentPrestation object to this object
     * through the TAgentPrestation foreign key attribute.
     *
     * @param    TAgentPrestation $l TAgentPrestation
     * @return TPrestation The current object (for fluent API support)
     */
    public function addTAgentPrestation(TAgentPrestation $l)
    {
        if ($this->collTAgentPrestations === null) {
            $this->initTAgentPrestations();
            $this->collTAgentPrestationsPartial = true;
        }
        if (!in_array($l, $this->collTAgentPrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentPrestation($l);
        }

        return $this;
    }

    /**
     * @param	TAgentPrestation $tAgentPrestation The tAgentPrestation object to add.
     */
    protected function doAddTAgentPrestation($tAgentPrestation)
    {
        $this->collTAgentPrestations[]= $tAgentPrestation;
        $tAgentPrestation->setTPrestation($this);
    }

    /**
     * @param	TAgentPrestation $tAgentPrestation The tAgentPrestation object to remove.
     * @return TPrestation The current object (for fluent API support)
     */
    public function removeTAgentPrestation($tAgentPrestation)
    {
        if ($this->getTAgentPrestations()->contains($tAgentPrestation)) {
            $this->collTAgentPrestations->remove($this->collTAgentPrestations->search($tAgentPrestation));
            if (null === $this->tAgentPrestationsScheduledForDeletion) {
                $this->tAgentPrestationsScheduledForDeletion = clone $this->collTAgentPrestations;
                $this->tAgentPrestationsScheduledForDeletion->clear();
            }
            $this->tAgentPrestationsScheduledForDeletion[]= clone $tAgentPrestation;
            $tAgentPrestation->setTPrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TAgentPrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgentPrestation[] List of TAgentPrestation objects
     */
    public function getTAgentPrestationsJoinTAgent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentPrestationQuery::create(null, $criteria);
        $query->joinWith('TAgent', $join_behavior);

        return $this->getTAgentPrestations($query, $con);
    }

    /**
     * Clears out the collTDelaiObtentions collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TPrestation The current object (for fluent API support)
     * @see        addTDelaiObtentions()
     */
    public function clearTDelaiObtentions()
    {
        $this->collTDelaiObtentions = null; // important to set this to null since that means it is uninitialized
        $this->collTDelaiObtentionsPartial = null;

        return $this;
    }

    /**
     * reset is the collTDelaiObtentions collection loaded partially
     *
     * @return void
     */
    public function resetPartialTDelaiObtentions($v = true)
    {
        $this->collTDelaiObtentionsPartial = $v;
    }

    /**
     * Initializes the collTDelaiObtentions collection.
     *
     * By default this just sets the collTDelaiObtentions collection to an empty array (like clearcollTDelaiObtentions());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTDelaiObtentions($overrideExisting = true)
    {
        if (null !== $this->collTDelaiObtentions && !$overrideExisting) {
            return;
        }
        $this->collTDelaiObtentions = new PropelObjectCollection();
        $this->collTDelaiObtentions->setModel('TDelaiObtention');
    }

    /**
     * Gets an array of TDelaiObtention objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TPrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TDelaiObtention[] List of TDelaiObtention objects
     * @throws PropelException
     */
    public function getTDelaiObtentions($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTDelaiObtentionsPartial && !$this->isNew();
        if (null === $this->collTDelaiObtentions || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTDelaiObtentions) {
                // return empty collection
                $this->initTDelaiObtentions();
            } else {
                $collTDelaiObtentions = TDelaiObtentionQuery::create(null, $criteria)
                    ->filterByTPrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTDelaiObtentionsPartial && count($collTDelaiObtentions)) {
                      $this->initTDelaiObtentions(false);

                      foreach($collTDelaiObtentions as $obj) {
                        if (false == $this->collTDelaiObtentions->contains($obj)) {
                          $this->collTDelaiObtentions->append($obj);
                        }
                      }

                      $this->collTDelaiObtentionsPartial = true;
                    }

                    $collTDelaiObtentions->getInternalIterator()->rewind();
                    return $collTDelaiObtentions;
                }

                if($partial && $this->collTDelaiObtentions) {
                    foreach($this->collTDelaiObtentions as $obj) {
                        if($obj->isNew()) {
                            $collTDelaiObtentions[] = $obj;
                        }
                    }
                }

                $this->collTDelaiObtentions = $collTDelaiObtentions;
                $this->collTDelaiObtentionsPartial = false;
            }
        }

        return $this->collTDelaiObtentions;
    }

    /**
     * Sets a collection of TDelaiObtention objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tDelaiObtentions A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TPrestation The current object (for fluent API support)
     */
    public function setTDelaiObtentions(PropelCollection $tDelaiObtentions, PropelPDO $con = null)
    {
        $tDelaiObtentionsToDelete = $this->getTDelaiObtentions(new Criteria(), $con)->diff($tDelaiObtentions);

        $this->tDelaiObtentionsScheduledForDeletion = unserialize(serialize($tDelaiObtentionsToDelete));

        foreach ($tDelaiObtentionsToDelete as $tDelaiObtentionRemoved) {
            $tDelaiObtentionRemoved->setTPrestation(null);
        }

        $this->collTDelaiObtentions = null;
        foreach ($tDelaiObtentions as $tDelaiObtention) {
            $this->addTDelaiObtention($tDelaiObtention);
        }

        $this->collTDelaiObtentions = $tDelaiObtentions;
        $this->collTDelaiObtentionsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TDelaiObtention objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TDelaiObtention objects.
     * @throws PropelException
     */
    public function countTDelaiObtentions(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTDelaiObtentionsPartial && !$this->isNew();
        if (null === $this->collTDelaiObtentions || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTDelaiObtentions) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTDelaiObtentions());
            }
            $query = TDelaiObtentionQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTPrestation($this)
                ->count($con);
        }

        return count($this->collTDelaiObtentions);
    }

    /**
     * Method called to associate a TDelaiObtention object to this object
     * through the TDelaiObtention foreign key attribute.
     *
     * @param    TDelaiObtention $l TDelaiObtention
     * @return TPrestation The current object (for fluent API support)
     */
    public function addTDelaiObtention(TDelaiObtention $l)
    {
        if ($this->collTDelaiObtentions === null) {
            $this->initTDelaiObtentions();
            $this->collTDelaiObtentionsPartial = true;
        }
        if (!in_array($l, $this->collTDelaiObtentions->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTDelaiObtention($l);
        }

        return $this;
    }

    /**
     * @param	TDelaiObtention $tDelaiObtention The tDelaiObtention object to add.
     */
    protected function doAddTDelaiObtention($tDelaiObtention)
    {
        $this->collTDelaiObtentions[]= $tDelaiObtention;
        $tDelaiObtention->setTPrestation($this);
    }

    /**
     * @param	TDelaiObtention $tDelaiObtention The tDelaiObtention object to remove.
     * @return TPrestation The current object (for fluent API support)
     */
    public function removeTDelaiObtention($tDelaiObtention)
    {
        if ($this->getTDelaiObtentions()->contains($tDelaiObtention)) {
            $this->collTDelaiObtentions->remove($this->collTDelaiObtentions->search($tDelaiObtention));
            if (null === $this->tDelaiObtentionsScheduledForDeletion) {
                $this->tDelaiObtentionsScheduledForDeletion = clone $this->collTDelaiObtentions;
                $this->tDelaiObtentionsScheduledForDeletion->clear();
            }
            $this->tDelaiObtentionsScheduledForDeletion[]= clone $tDelaiObtention;
            $tDelaiObtention->setTPrestation(null);
        }

        return $this;
    }

    /**
     * Clears out the collTPiecePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TPrestation The current object (for fluent API support)
     * @see        addTPiecePrestations()
     */
    public function clearTPiecePrestations()
    {
        $this->collTPiecePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTPiecePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTPiecePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPiecePrestations($v = true)
    {
        $this->collTPiecePrestationsPartial = $v;
    }

    /**
     * Initializes the collTPiecePrestations collection.
     *
     * By default this just sets the collTPiecePrestations collection to an empty array (like clearcollTPiecePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPiecePrestations($overrideExisting = true)
    {
        if (null !== $this->collTPiecePrestations && !$overrideExisting) {
            return;
        }
        $this->collTPiecePrestations = new PropelObjectCollection();
        $this->collTPiecePrestations->setModel('TPiecePrestation');
    }

    /**
     * Gets an array of TPiecePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TPrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPiecePrestation[] List of TPiecePrestation objects
     * @throws PropelException
     */
    public function getTPiecePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPiecePrestationsPartial && !$this->isNew();
        if (null === $this->collTPiecePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPiecePrestations) {
                // return empty collection
                $this->initTPiecePrestations();
            } else {
                $collTPiecePrestations = TPiecePrestationQuery::create(null, $criteria)
                    ->filterByTPrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPiecePrestationsPartial && count($collTPiecePrestations)) {
                      $this->initTPiecePrestations(false);

                      foreach($collTPiecePrestations as $obj) {
                        if (false == $this->collTPiecePrestations->contains($obj)) {
                          $this->collTPiecePrestations->append($obj);
                        }
                      }

                      $this->collTPiecePrestationsPartial = true;
                    }

                    $collTPiecePrestations->getInternalIterator()->rewind();
                    return $collTPiecePrestations;
                }

                if($partial && $this->collTPiecePrestations) {
                    foreach($this->collTPiecePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTPiecePrestations[] = $obj;
                        }
                    }
                }

                $this->collTPiecePrestations = $collTPiecePrestations;
                $this->collTPiecePrestationsPartial = false;
            }
        }

        return $this->collTPiecePrestations;
    }

    /**
     * Sets a collection of TPiecePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPiecePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TPrestation The current object (for fluent API support)
     */
    public function setTPiecePrestations(PropelCollection $tPiecePrestations, PropelPDO $con = null)
    {
        $tPiecePrestationsToDelete = $this->getTPiecePrestations(new Criteria(), $con)->diff($tPiecePrestations);

        $this->tPiecePrestationsScheduledForDeletion = unserialize(serialize($tPiecePrestationsToDelete));

        foreach ($tPiecePrestationsToDelete as $tPiecePrestationRemoved) {
            $tPiecePrestationRemoved->setTPrestation(null);
        }

        $this->collTPiecePrestations = null;
        foreach ($tPiecePrestations as $tPiecePrestation) {
            $this->addTPiecePrestation($tPiecePrestation);
        }

        $this->collTPiecePrestations = $tPiecePrestations;
        $this->collTPiecePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPiecePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPiecePrestation objects.
     * @throws PropelException
     */
    public function countTPiecePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPiecePrestationsPartial && !$this->isNew();
        if (null === $this->collTPiecePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPiecePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPiecePrestations());
            }
            $query = TPiecePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTPrestation($this)
                ->count($con);
        }

        return count($this->collTPiecePrestations);
    }

    /**
     * Method called to associate a TPiecePrestation object to this object
     * through the TPiecePrestation foreign key attribute.
     *
     * @param    TPiecePrestation $l TPiecePrestation
     * @return TPrestation The current object (for fluent API support)
     */
    public function addTPiecePrestation(TPiecePrestation $l)
    {
        if ($this->collTPiecePrestations === null) {
            $this->initTPiecePrestations();
            $this->collTPiecePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTPiecePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPiecePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TPiecePrestation $tPiecePrestation The tPiecePrestation object to add.
     */
    protected function doAddTPiecePrestation($tPiecePrestation)
    {
        $this->collTPiecePrestations[]= $tPiecePrestation;
        $tPiecePrestation->setTPrestation($this);
    }

    /**
     * @param	TPiecePrestation $tPiecePrestation The tPiecePrestation object to remove.
     * @return TPrestation The current object (for fluent API support)
     */
    public function removeTPiecePrestation($tPiecePrestation)
    {
        if ($this->getTPiecePrestations()->contains($tPiecePrestation)) {
            $this->collTPiecePrestations->remove($this->collTPiecePrestations->search($tPiecePrestation));
            if (null === $this->tPiecePrestationsScheduledForDeletion) {
                $this->tPiecePrestationsScheduledForDeletion = clone $this->collTPiecePrestations;
                $this->tPiecePrestationsScheduledForDeletion->clear();
            }
            $this->tPiecePrestationsScheduledForDeletion[]= clone $tPiecePrestation;
            $tPiecePrestation->setTPrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TPiecePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPiecePrestation[] List of TPiecePrestation objects
     */
    public function getTPiecePrestationsJoinTTraduction($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPiecePrestationQuery::create(null, $criteria);
        $query->joinWith('TTraduction', $join_behavior);

        return $this->getTPiecePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TPiecePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPiecePrestation[] List of TPiecePrestation objects
     */
    public function getTPiecePrestationsJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPiecePrestationQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTPiecePrestations($query, $con);
    }

    /**
     * Clears out the collTRendezVouss collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TPrestation The current object (for fluent API support)
     * @see        addTRendezVouss()
     */
    public function clearTRendezVouss()
    {
        $this->collTRendezVouss = null; // important to set this to null since that means it is uninitialized
        $this->collTRendezVoussPartial = null;

        return $this;
    }

    /**
     * reset is the collTRendezVouss collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRendezVouss($v = true)
    {
        $this->collTRendezVoussPartial = $v;
    }

    /**
     * Initializes the collTRendezVouss collection.
     *
     * By default this just sets the collTRendezVouss collection to an empty array (like clearcollTRendezVouss());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRendezVouss($overrideExisting = true)
    {
        if (null !== $this->collTRendezVouss && !$overrideExisting) {
            return;
        }
        $this->collTRendezVouss = new PropelObjectCollection();
        $this->collTRendezVouss->setModel('TRendezVous');
    }

    /**
     * Gets an array of TRendezVous objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TPrestation is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     * @throws PropelException
     */
    public function getTRendezVouss($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                // return empty collection
                $this->initTRendezVouss();
            } else {
                $collTRendezVouss = TRendezVousQuery::create(null, $criteria)
                    ->filterByTPrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRendezVoussPartial && count($collTRendezVouss)) {
                      $this->initTRendezVouss(false);

                      foreach($collTRendezVouss as $obj) {
                        if (false == $this->collTRendezVouss->contains($obj)) {
                          $this->collTRendezVouss->append($obj);
                        }
                      }

                      $this->collTRendezVoussPartial = true;
                    }

                    $collTRendezVouss->getInternalIterator()->rewind();
                    return $collTRendezVouss;
                }

                if($partial && $this->collTRendezVouss) {
                    foreach($this->collTRendezVouss as $obj) {
                        if($obj->isNew()) {
                            $collTRendezVouss[] = $obj;
                        }
                    }
                }

                $this->collTRendezVouss = $collTRendezVouss;
                $this->collTRendezVoussPartial = false;
            }
        }

        return $this->collTRendezVouss;
    }

    /**
     * Sets a collection of TRendezVous objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRendezVouss A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TPrestation The current object (for fluent API support)
     */
    public function setTRendezVouss(PropelCollection $tRendezVouss, PropelPDO $con = null)
    {
        $tRendezVoussToDelete = $this->getTRendezVouss(new Criteria(), $con)->diff($tRendezVouss);

        $this->tRendezVoussScheduledForDeletion = unserialize(serialize($tRendezVoussToDelete));

        foreach ($tRendezVoussToDelete as $tRendezVousRemoved) {
            $tRendezVousRemoved->setTPrestation(null);
        }

        $this->collTRendezVouss = null;
        foreach ($tRendezVouss as $tRendezVous) {
            $this->addTRendezVous($tRendezVous);
        }

        $this->collTRendezVouss = $tRendezVouss;
        $this->collTRendezVoussPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRendezVous objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRendezVous objects.
     * @throws PropelException
     */
    public function countTRendezVouss(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRendezVoussPartial && !$this->isNew();
        if (null === $this->collTRendezVouss || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRendezVouss) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRendezVouss());
            }
            $query = TRendezVousQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTPrestation($this)
                ->count($con);
        }

        return count($this->collTRendezVouss);
    }

    /**
     * Method called to associate a TRendezVous object to this object
     * through the TRendezVous foreign key attribute.
     *
     * @param    TRendezVous $l TRendezVous
     * @return TPrestation The current object (for fluent API support)
     */
    public function addTRendezVous(TRendezVous $l)
    {
        if ($this->collTRendezVouss === null) {
            $this->initTRendezVouss();
            $this->collTRendezVoussPartial = true;
        }
        if (!in_array($l, $this->collTRendezVouss->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRendezVous($l);
        }

        return $this;
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to add.
     */
    protected function doAddTRendezVous($tRendezVous)
    {
        $this->collTRendezVouss[]= $tRendezVous;
        $tRendezVous->setTPrestation($this);
    }

    /**
     * @param	TRendezVous $tRendezVous The tRendezVous object to remove.
     * @return TPrestation The current object (for fluent API support)
     */
    public function removeTRendezVous($tRendezVous)
    {
        if ($this->getTRendezVouss()->contains($tRendezVous)) {
            $this->collTRendezVouss->remove($this->collTRendezVouss->search($tRendezVous));
            if (null === $this->tRendezVoussScheduledForDeletion) {
                $this->tRendezVoussScheduledForDeletion = clone $this->collTRendezVouss;
                $this->tRendezVoussScheduledForDeletion->clear();
            }
            $this->tRendezVoussScheduledForDeletion[]= clone $tRendezVous;
            $tRendezVous->setTPrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTCitoyen($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TCitoyen', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAccueil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAccueil', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentAnnulation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentAnnulation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentConfirmation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentConfirmation', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentRessource($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentRessource', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTAgentRelatedByIdAgentTeleoperateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TAgentRelatedByIdAgentTeleoperateur', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTValeurReferentiel($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TValeurReferentiel', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TPrestation is new, it will return
     * an empty collection; or if this TPrestation has previously
     * been saved, it will retrieve related TRendezVouss from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TPrestation.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRendezVous[] List of TRendezVous objects
     */
    public function getTRendezVoussJoinTReferent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRendezVousQuery::create(null, $criteria);
        $query->joinWith('TReferent', $join_behavior);

        return $this->getTRendezVouss($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_prestation = null;
        $this->id_ref_prestation = null;
        $this->code_libelle_prestation = null;
        $this->id_type_prestation = null;
        $this->rdv_similaire = null;
        $this->nb_jour_rdv_similaire = null;
        $this->delai_min = null;
        $this->periodicite = null;
        $this->ressource_visible = null;
        $this->ressource_obligatoire = null;
        $this->id_parametre_form = null;
        $this->code_commentaire = null;
        $this->referent_visible = null;
        $this->id_parametrage_prestation = null;
        $this->id_champs_supp_1 = null;
        $this->id_champs_supp_2 = null;
        $this->id_champs_supp_3 = null;
        $this->visioconference = null;
        $this->rdv_groupe = null;
        $this->nombre_max_participants = null;
        $this->type_session = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTAgendas) {
                foreach ($this->collTAgendas as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgents) {
                foreach ($this->collTAgents as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgentPrestations) {
                foreach ($this->collTAgentPrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTDelaiObtentions) {
                foreach ($this->collTDelaiObtentions as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPiecePrestations) {
                foreach ($this->collTPiecePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRendezVouss) {
                foreach ($this->collTRendezVouss as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraductionRelatedByCodeCommentaire instanceof Persistent) {
              $this->aTTraductionRelatedByCodeCommentaire->clearAllReferences($deep);
            }
            if ($this->aTTraductionRelatedByCodeLibellePrestation instanceof Persistent) {
              $this->aTTraductionRelatedByCodeLibellePrestation->clearAllReferences($deep);
            }
            if ($this->aTParametragePrestation instanceof Persistent) {
              $this->aTParametragePrestation->clearAllReferences($deep);
            }
            if ($this->aTParametreForm instanceof Persistent) {
              $this->aTParametreForm->clearAllReferences($deep);
            }
            if ($this->aTRefPrestation instanceof Persistent) {
              $this->aTRefPrestation->clearAllReferences($deep);
            }
            if ($this->aTTypePrestation instanceof Persistent) {
              $this->aTTypePrestation->clearAllReferences($deep);
            }
            if ($this->aTChampsSuppRelatedByIdChampsSupp1 instanceof Persistent) {
              $this->aTChampsSuppRelatedByIdChampsSupp1->clearAllReferences($deep);
            }
            if ($this->aTChampsSuppRelatedByIdChampsSupp2 instanceof Persistent) {
              $this->aTChampsSuppRelatedByIdChampsSupp2->clearAllReferences($deep);
            }
            if ($this->aTChampsSuppRelatedByIdChampsSupp3 instanceof Persistent) {
              $this->aTChampsSuppRelatedByIdChampsSupp3->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTAgendas instanceof PropelCollection) {
            $this->collTAgendas->clearIterator();
        }
        $this->collTAgendas = null;
        if ($this->collTAgents instanceof PropelCollection) {
            $this->collTAgents->clearIterator();
        }
        $this->collTAgents = null;
        if ($this->collTAgentPrestations instanceof PropelCollection) {
            $this->collTAgentPrestations->clearIterator();
        }
        $this->collTAgentPrestations = null;
        if ($this->collTDelaiObtentions instanceof PropelCollection) {
            $this->collTDelaiObtentions->clearIterator();
        }
        $this->collTDelaiObtentions = null;
        if ($this->collTPiecePrestations instanceof PropelCollection) {
            $this->collTPiecePrestations->clearIterator();
        }
        $this->collTPiecePrestations = null;
        if ($this->collTRendezVouss instanceof PropelCollection) {
            $this->collTRendezVouss->clearIterator();
        }
        $this->collTRendezVouss = null;
        $this->aTTraductionRelatedByCodeCommentaire = null;
        $this->aTTraductionRelatedByCodeLibellePrestation = null;
        $this->aTParametragePrestation = null;
        $this->aTParametreForm = null;
        $this->aTRefPrestation = null;
        $this->aTTypePrestation = null;
        $this->aTChampsSuppRelatedByIdChampsSupp1 = null;
        $this->aTChampsSuppRelatedByIdChampsSupp2 = null;
        $this->aTChampsSuppRelatedByIdChampsSupp3 = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TPrestationPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
