<?php


/**
 * Base class that represents a row from the 'T_CHAMPS_SUPP' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTChampsSupp extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TChampsSuppPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TChampsSuppPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_champs_supp field.
     * @var        int
     */
    protected $id_champs_supp;

    /**
     * The value for the id_organisation field.
     * @var        int
     */
    protected $id_organisation;

    /**
     * The value for the code_champs field.
     * @var        string
     */
    protected $code_champs;

    /**
     * The value for the code_libelle field.
     * @var        int
     */
    protected $code_libelle;

    /**
     * The value for the obligatoire field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $obligatoire;

    /**
     * The value for the champs_type field.
     * Note: this column has a database default value of: 'TEXT'
     * @var        string
     */
    protected $champs_type;

    /**
     * The value for the value_liste field.
     * @var        string
     */
    protected $value_liste;

    /**
     * @var        TTraduction
     */
    protected $aTTraduction;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisation;

    /**
     * @var        PropelObjectCollection|TPrestation[] Collection to store aggregation of TPrestation objects.
     */
    protected $collTPrestationsRelatedByIdChampsSupp3;
    protected $collTPrestationsRelatedByIdChampsSupp3Partial;

    /**
     * @var        PropelObjectCollection|TPrestation[] Collection to store aggregation of TPrestation objects.
     */
    protected $collTPrestationsRelatedByIdChampsSupp1;
    protected $collTPrestationsRelatedByIdChampsSupp1Partial;

    /**
     * @var        PropelObjectCollection|TPrestation[] Collection to store aggregation of TPrestation objects.
     */
    protected $collTPrestationsRelatedByIdChampsSupp2;
    protected $collTPrestationsRelatedByIdChampsSupp2Partial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->obligatoire = '0';
        $this->champs_type = 'TEXT';
    }

    /**
     * Initializes internal state of BaseTChampsSupp object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_champs_supp] column value.
     *
     * @return int
     */
    public function getIdChampsSupp()
    {
        return $this->id_champs_supp;
    }

    /**
     * Get the [id_organisation] column value.
     *
     * @return int
     */
    public function getIdOrganisation()
    {
        return $this->id_organisation;
    }

    /**
     * Get the [code_champs] column value.
     *
     * @return string
     */
    public function getCodeChamps()
    {
        return $this->code_champs;
    }

    /**
     * Get the [code_libelle] column value.
     *
     * @return int
     */
    public function getCodeLibelle()
    {
        return $this->code_libelle;
    }

    /**
     * Get the [obligatoire] column value.
     *
     * @return string
     */
    public function getObligatoire()
    {
        return $this->obligatoire;
    }

    /**
     * Get the [champs_type] column value.
     *
     * @return string
     */
    public function getChampsType()
    {
        return $this->champs_type;
    }

    /**
     * Get the [value_liste] column value.
     *
     * @return string
     */
    public function getValueListe()
    {
        return $this->value_liste;
    }

    /**
     * Set the value of [id_champs_supp] column.
     *
     * @param int $v new value
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setIdChampsSupp($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_champs_supp !== $v) {
            $this->id_champs_supp = $v;
            $this->modifiedColumns[] = TChampsSuppPeer::ID_CHAMPS_SUPP;
        }


        return $this;
    } // setIdChampsSupp()

    /**
     * Set the value of [id_organisation] column.
     *
     * @param int $v new value
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setIdOrganisation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation !== $v) {
            $this->id_organisation = $v;
            $this->modifiedColumns[] = TChampsSuppPeer::ID_ORGANISATION;
        }

        if ($this->aTOrganisation !== null && $this->aTOrganisation->getIdOrganisation() !== $v) {
            $this->aTOrganisation = null;
        }


        return $this;
    } // setIdOrganisation()

    /**
     * Set the value of [code_champs] column.
     *
     * @param string $v new value
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setCodeChamps($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->code_champs !== $v) {
            $this->code_champs = $v;
            $this->modifiedColumns[] = TChampsSuppPeer::CODE_CHAMPS;
        }


        return $this;
    } // setCodeChamps()

    /**
     * Set the value of [code_libelle] column.
     *
     * @param int $v new value
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setCodeLibelle($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle !== $v) {
            $this->code_libelle = $v;
            $this->modifiedColumns[] = TChampsSuppPeer::CODE_LIBELLE;
        }

        if ($this->aTTraduction !== null && $this->aTTraduction->getIdTraduction() !== $v) {
            $this->aTTraduction = null;
        }


        return $this;
    } // setCodeLibelle()

    /**
     * Set the value of [obligatoire] column.
     *
     * @param string $v new value
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setObligatoire($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->obligatoire !== $v) {
            $this->obligatoire = $v;
            $this->modifiedColumns[] = TChampsSuppPeer::OBLIGATOIRE;
        }


        return $this;
    } // setObligatoire()

    /**
     * Set the value of [champs_type] column.
     *
     * @param string $v new value
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setChampsType($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->champs_type !== $v) {
            $this->champs_type = $v;
            $this->modifiedColumns[] = TChampsSuppPeer::CHAMPS_TYPE;
        }


        return $this;
    } // setChampsType()

    /**
     * Set the value of [value_liste] column.
     *
     * @param string $v new value
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setValueListe($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->value_liste !== $v) {
            $this->value_liste = $v;
            $this->modifiedColumns[] = TChampsSuppPeer::VALUE_LISTE;
        }


        return $this;
    } // setValueListe()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->obligatoire !== '0') {
                return false;
            }

            if ($this->champs_type !== 'TEXT') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_champs_supp = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->id_organisation = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->code_champs = ($row[$startcol + 2] !== null) ? (string) $row[$startcol + 2] : null;
            $this->code_libelle = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->obligatoire = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->champs_type = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->value_liste = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 7; // 7 = TChampsSuppPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TChampsSupp object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTOrganisation !== null && $this->id_organisation !== $this->aTOrganisation->getIdOrganisation()) {
            $this->aTOrganisation = null;
        }
        if ($this->aTTraduction !== null && $this->code_libelle !== $this->aTTraduction->getIdTraduction()) {
            $this->aTTraduction = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TChampsSuppPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TChampsSuppPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraduction = null;
            $this->aTOrganisation = null;
            $this->collTPrestationsRelatedByIdChampsSupp3 = null;

            $this->collTPrestationsRelatedByIdChampsSupp1 = null;

            $this->collTPrestationsRelatedByIdChampsSupp2 = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TChampsSuppPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TChampsSuppQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TChampsSuppPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TChampsSuppPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if ($this->aTTraduction->isModified() || $this->aTTraduction->isNew()) {
                    $affectedRows += $this->aTTraduction->save($con);
                }
                $this->setTTraduction($this->aTTraduction);
            }

            if ($this->aTOrganisation !== null) {
                if ($this->aTOrganisation->isModified() || $this->aTOrganisation->isNew()) {
                    $affectedRows += $this->aTOrganisation->save($con);
                }
                $this->setTOrganisation($this->aTOrganisation);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion !== null) {
                if (!$this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion as $tPrestationRelatedByIdChampsSupp3) {
                        // need to save related object because we set the relation to null
                        $tPrestationRelatedByIdChampsSupp3->save($con);
                    }
                    $this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion = null;
                }
            }

            if ($this->collTPrestationsRelatedByIdChampsSupp3 !== null) {
                foreach ($this->collTPrestationsRelatedByIdChampsSupp3 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion !== null) {
                if (!$this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion as $tPrestationRelatedByIdChampsSupp1) {
                        // need to save related object because we set the relation to null
                        $tPrestationRelatedByIdChampsSupp1->save($con);
                    }
                    $this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion = null;
                }
            }

            if ($this->collTPrestationsRelatedByIdChampsSupp1 !== null) {
                foreach ($this->collTPrestationsRelatedByIdChampsSupp1 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion !== null) {
                if (!$this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion as $tPrestationRelatedByIdChampsSupp2) {
                        // need to save related object because we set the relation to null
                        $tPrestationRelatedByIdChampsSupp2->save($con);
                    }
                    $this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion = null;
                }
            }

            if ($this->collTPrestationsRelatedByIdChampsSupp2 !== null) {
                foreach ($this->collTPrestationsRelatedByIdChampsSupp2 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TChampsSuppPeer::ID_CHAMPS_SUPP;
        if (null !== $this->id_champs_supp) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TChampsSuppPeer::ID_CHAMPS_SUPP . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TChampsSuppPeer::ID_CHAMPS_SUPP)) {
            $modifiedColumns[':p' . $index++]  = '`ID_CHAMPS_SUPP`';
        }
        if ($this->isColumnModified(TChampsSuppPeer::ID_ORGANISATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION`';
        }
        if ($this->isColumnModified(TChampsSuppPeer::CODE_CHAMPS)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_CHAMPS`';
        }
        if ($this->isColumnModified(TChampsSuppPeer::CODE_LIBELLE)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE`';
        }
        if ($this->isColumnModified(TChampsSuppPeer::OBLIGATOIRE)) {
            $modifiedColumns[':p' . $index++]  = '`OBLIGATOIRE`';
        }
        if ($this->isColumnModified(TChampsSuppPeer::CHAMPS_TYPE)) {
            $modifiedColumns[':p' . $index++]  = '`CHAMPS_TYPE`';
        }
        if ($this->isColumnModified(TChampsSuppPeer::VALUE_LISTE)) {
            $modifiedColumns[':p' . $index++]  = '`VALUE_LISTE`';
        }

        $sql = sprintf(
            'INSERT INTO `T_CHAMPS_SUPP` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_CHAMPS_SUPP`':
                        $stmt->bindValue($identifier, $this->id_champs_supp, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION`':
                        $stmt->bindValue($identifier, $this->id_organisation, PDO::PARAM_INT);
                        break;
                    case '`CODE_CHAMPS`':
                        $stmt->bindValue($identifier, $this->code_champs, PDO::PARAM_STR);
                        break;
                    case '`CODE_LIBELLE`':
                        $stmt->bindValue($identifier, $this->code_libelle, PDO::PARAM_INT);
                        break;
                    case '`OBLIGATOIRE`':
                        $stmt->bindValue($identifier, $this->obligatoire, PDO::PARAM_STR);
                        break;
                    case '`CHAMPS_TYPE`':
                        $stmt->bindValue($identifier, $this->champs_type, PDO::PARAM_STR);
                        break;
                    case '`VALUE_LISTE`':
                        $stmt->bindValue($identifier, $this->value_liste, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdChampsSupp($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if (!$this->aTTraduction->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraduction->getValidationFailures());
                }
            }

            if ($this->aTOrganisation !== null) {
                if (!$this->aTOrganisation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisation->getValidationFailures());
                }
            }


            if (($retval = TChampsSuppPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTPrestationsRelatedByIdChampsSupp3 !== null) {
                    foreach ($this->collTPrestationsRelatedByIdChampsSupp3 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPrestationsRelatedByIdChampsSupp1 !== null) {
                    foreach ($this->collTPrestationsRelatedByIdChampsSupp1 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPrestationsRelatedByIdChampsSupp2 !== null) {
                    foreach ($this->collTPrestationsRelatedByIdChampsSupp2 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TChampsSuppPeer::DATABASE_NAME);

        if ($this->isColumnModified(TChampsSuppPeer::ID_CHAMPS_SUPP)) $criteria->add(TChampsSuppPeer::ID_CHAMPS_SUPP, $this->id_champs_supp);
        if ($this->isColumnModified(TChampsSuppPeer::ID_ORGANISATION)) $criteria->add(TChampsSuppPeer::ID_ORGANISATION, $this->id_organisation);
        if ($this->isColumnModified(TChampsSuppPeer::CODE_CHAMPS)) $criteria->add(TChampsSuppPeer::CODE_CHAMPS, $this->code_champs);
        if ($this->isColumnModified(TChampsSuppPeer::CODE_LIBELLE)) $criteria->add(TChampsSuppPeer::CODE_LIBELLE, $this->code_libelle);
        if ($this->isColumnModified(TChampsSuppPeer::OBLIGATOIRE)) $criteria->add(TChampsSuppPeer::OBLIGATOIRE, $this->obligatoire);
        if ($this->isColumnModified(TChampsSuppPeer::CHAMPS_TYPE)) $criteria->add(TChampsSuppPeer::CHAMPS_TYPE, $this->champs_type);
        if ($this->isColumnModified(TChampsSuppPeer::VALUE_LISTE)) $criteria->add(TChampsSuppPeer::VALUE_LISTE, $this->value_liste);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TChampsSuppPeer::DATABASE_NAME);
        $criteria->add(TChampsSuppPeer::ID_CHAMPS_SUPP, $this->id_champs_supp);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdChampsSupp();
    }

    /**
     * Generic method to set the primary key (id_champs_supp column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdChampsSupp($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdChampsSupp();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TChampsSupp (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setIdOrganisation($this->getIdOrganisation());
        $copyObj->setCodeChamps($this->getCodeChamps());
        $copyObj->setCodeLibelle($this->getCodeLibelle());
        $copyObj->setObligatoire($this->getObligatoire());
        $copyObj->setChampsType($this->getChampsType());
        $copyObj->setValueListe($this->getValueListe());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTPrestationsRelatedByIdChampsSupp3() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPrestationRelatedByIdChampsSupp3($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPrestationsRelatedByIdChampsSupp1() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPrestationRelatedByIdChampsSupp1($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPrestationsRelatedByIdChampsSupp2() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPrestationRelatedByIdChampsSupp2($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdChampsSupp(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TChampsSupp Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TChampsSuppPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TChampsSuppPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TChampsSupp The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraduction(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelle(NULL);
        } else {
            $this->setCodeLibelle($v->getIdTraduction());
        }

        $this->aTTraduction = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTChampsSupp($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraduction(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraduction === null && ($this->code_libelle !== null) && $doQuery) {
            $this->aTTraduction = TTraductionQuery::create()->findPk($this->code_libelle, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraduction->addTChampsSupps($this);
             */
        }

        return $this->aTTraduction;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TChampsSupp The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisation(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisation(NULL);
        } else {
            $this->setIdOrganisation($v->getIdOrganisation());
        }

        $this->aTOrganisation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTChampsSupp($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisation === null && ($this->id_organisation !== null) && $doQuery) {
            $this->aTOrganisation = TOrganisationQuery::create()->findPk($this->id_organisation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisation->addTChampsSupps($this);
             */
        }

        return $this->aTOrganisation;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TPrestationRelatedByIdChampsSupp3' == $relationName) {
            $this->initTPrestationsRelatedByIdChampsSupp3();
        }
        if ('TPrestationRelatedByIdChampsSupp1' == $relationName) {
            $this->initTPrestationsRelatedByIdChampsSupp1();
        }
        if ('TPrestationRelatedByIdChampsSupp2' == $relationName) {
            $this->initTPrestationsRelatedByIdChampsSupp2();
        }
    }

    /**
     * Clears out the collTPrestationsRelatedByIdChampsSupp3 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TChampsSupp The current object (for fluent API support)
     * @see        addTPrestationsRelatedByIdChampsSupp3()
     */
    public function clearTPrestationsRelatedByIdChampsSupp3()
    {
        $this->collTPrestationsRelatedByIdChampsSupp3 = null; // important to set this to null since that means it is uninitialized
        $this->collTPrestationsRelatedByIdChampsSupp3Partial = null;

        return $this;
    }

    /**
     * reset is the collTPrestationsRelatedByIdChampsSupp3 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPrestationsRelatedByIdChampsSupp3($v = true)
    {
        $this->collTPrestationsRelatedByIdChampsSupp3Partial = $v;
    }

    /**
     * Initializes the collTPrestationsRelatedByIdChampsSupp3 collection.
     *
     * By default this just sets the collTPrestationsRelatedByIdChampsSupp3 collection to an empty array (like clearcollTPrestationsRelatedByIdChampsSupp3());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPrestationsRelatedByIdChampsSupp3($overrideExisting = true)
    {
        if (null !== $this->collTPrestationsRelatedByIdChampsSupp3 && !$overrideExisting) {
            return;
        }
        $this->collTPrestationsRelatedByIdChampsSupp3 = new PropelObjectCollection();
        $this->collTPrestationsRelatedByIdChampsSupp3->setModel('TPrestation');
    }

    /**
     * Gets an array of TPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TChampsSupp is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     * @throws PropelException
     */
    public function getTPrestationsRelatedByIdChampsSupp3($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByIdChampsSupp3Partial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByIdChampsSupp3 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByIdChampsSupp3) {
                // return empty collection
                $this->initTPrestationsRelatedByIdChampsSupp3();
            } else {
                $collTPrestationsRelatedByIdChampsSupp3 = TPrestationQuery::create(null, $criteria)
                    ->filterByTChampsSuppRelatedByIdChampsSupp3($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPrestationsRelatedByIdChampsSupp3Partial && count($collTPrestationsRelatedByIdChampsSupp3)) {
                      $this->initTPrestationsRelatedByIdChampsSupp3(false);

                      foreach($collTPrestationsRelatedByIdChampsSupp3 as $obj) {
                        if (false == $this->collTPrestationsRelatedByIdChampsSupp3->contains($obj)) {
                          $this->collTPrestationsRelatedByIdChampsSupp3->append($obj);
                        }
                      }

                      $this->collTPrestationsRelatedByIdChampsSupp3Partial = true;
                    }

                    $collTPrestationsRelatedByIdChampsSupp3->getInternalIterator()->rewind();
                    return $collTPrestationsRelatedByIdChampsSupp3;
                }

                if($partial && $this->collTPrestationsRelatedByIdChampsSupp3) {
                    foreach($this->collTPrestationsRelatedByIdChampsSupp3 as $obj) {
                        if($obj->isNew()) {
                            $collTPrestationsRelatedByIdChampsSupp3[] = $obj;
                        }
                    }
                }

                $this->collTPrestationsRelatedByIdChampsSupp3 = $collTPrestationsRelatedByIdChampsSupp3;
                $this->collTPrestationsRelatedByIdChampsSupp3Partial = false;
            }
        }

        return $this->collTPrestationsRelatedByIdChampsSupp3;
    }

    /**
     * Sets a collection of TPrestationRelatedByIdChampsSupp3 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPrestationsRelatedByIdChampsSupp3 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setTPrestationsRelatedByIdChampsSupp3(PropelCollection $tPrestationsRelatedByIdChampsSupp3, PropelPDO $con = null)
    {
        $tPrestationsRelatedByIdChampsSupp3ToDelete = $this->getTPrestationsRelatedByIdChampsSupp3(new Criteria(), $con)->diff($tPrestationsRelatedByIdChampsSupp3);

        $this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion = unserialize(serialize($tPrestationsRelatedByIdChampsSupp3ToDelete));

        foreach ($tPrestationsRelatedByIdChampsSupp3ToDelete as $tPrestationRelatedByIdChampsSupp3Removed) {
            $tPrestationRelatedByIdChampsSupp3Removed->setTChampsSuppRelatedByIdChampsSupp3(null);
        }

        $this->collTPrestationsRelatedByIdChampsSupp3 = null;
        foreach ($tPrestationsRelatedByIdChampsSupp3 as $tPrestationRelatedByIdChampsSupp3) {
            $this->addTPrestationRelatedByIdChampsSupp3($tPrestationRelatedByIdChampsSupp3);
        }

        $this->collTPrestationsRelatedByIdChampsSupp3 = $tPrestationsRelatedByIdChampsSupp3;
        $this->collTPrestationsRelatedByIdChampsSupp3Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPrestation objects.
     * @throws PropelException
     */
    public function countTPrestationsRelatedByIdChampsSupp3(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByIdChampsSupp3Partial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByIdChampsSupp3 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByIdChampsSupp3) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPrestationsRelatedByIdChampsSupp3());
            }
            $query = TPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTChampsSuppRelatedByIdChampsSupp3($this)
                ->count($con);
        }

        return count($this->collTPrestationsRelatedByIdChampsSupp3);
    }

    /**
     * Method called to associate a TPrestation object to this object
     * through the TPrestation foreign key attribute.
     *
     * @param    TPrestation $l TPrestation
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function addTPrestationRelatedByIdChampsSupp3(TPrestation $l)
    {
        if ($this->collTPrestationsRelatedByIdChampsSupp3 === null) {
            $this->initTPrestationsRelatedByIdChampsSupp3();
            $this->collTPrestationsRelatedByIdChampsSupp3Partial = true;
        }
        if (!in_array($l, $this->collTPrestationsRelatedByIdChampsSupp3->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPrestationRelatedByIdChampsSupp3($l);
        }

        return $this;
    }

    /**
     * @param	TPrestationRelatedByIdChampsSupp3 $tPrestationRelatedByIdChampsSupp3 The tPrestationRelatedByIdChampsSupp3 object to add.
     */
    protected function doAddTPrestationRelatedByIdChampsSupp3($tPrestationRelatedByIdChampsSupp3)
    {
        $this->collTPrestationsRelatedByIdChampsSupp3[]= $tPrestationRelatedByIdChampsSupp3;
        $tPrestationRelatedByIdChampsSupp3->setTChampsSuppRelatedByIdChampsSupp3($this);
    }

    /**
     * @param	TPrestationRelatedByIdChampsSupp3 $tPrestationRelatedByIdChampsSupp3 The tPrestationRelatedByIdChampsSupp3 object to remove.
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function removeTPrestationRelatedByIdChampsSupp3($tPrestationRelatedByIdChampsSupp3)
    {
        if ($this->getTPrestationsRelatedByIdChampsSupp3()->contains($tPrestationRelatedByIdChampsSupp3)) {
            $this->collTPrestationsRelatedByIdChampsSupp3->remove($this->collTPrestationsRelatedByIdChampsSupp3->search($tPrestationRelatedByIdChampsSupp3));
            if (null === $this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion) {
                $this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion = clone $this->collTPrestationsRelatedByIdChampsSupp3;
                $this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion->clear();
            }
            $this->tPrestationsRelatedByIdChampsSupp3ScheduledForDeletion[]= $tPrestationRelatedByIdChampsSupp3;
            $tPrestationRelatedByIdChampsSupp3->setTChampsSuppRelatedByIdChampsSupp3(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp3JoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp3JoinTTraductionRelatedByCodeLibellePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibellePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp3JoinTParametragePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametragePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp3JoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp3JoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp3JoinTTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTypePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp3($query, $con);
    }

    /**
     * Clears out the collTPrestationsRelatedByIdChampsSupp1 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TChampsSupp The current object (for fluent API support)
     * @see        addTPrestationsRelatedByIdChampsSupp1()
     */
    public function clearTPrestationsRelatedByIdChampsSupp1()
    {
        $this->collTPrestationsRelatedByIdChampsSupp1 = null; // important to set this to null since that means it is uninitialized
        $this->collTPrestationsRelatedByIdChampsSupp1Partial = null;

        return $this;
    }

    /**
     * reset is the collTPrestationsRelatedByIdChampsSupp1 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPrestationsRelatedByIdChampsSupp1($v = true)
    {
        $this->collTPrestationsRelatedByIdChampsSupp1Partial = $v;
    }

    /**
     * Initializes the collTPrestationsRelatedByIdChampsSupp1 collection.
     *
     * By default this just sets the collTPrestationsRelatedByIdChampsSupp1 collection to an empty array (like clearcollTPrestationsRelatedByIdChampsSupp1());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPrestationsRelatedByIdChampsSupp1($overrideExisting = true)
    {
        if (null !== $this->collTPrestationsRelatedByIdChampsSupp1 && !$overrideExisting) {
            return;
        }
        $this->collTPrestationsRelatedByIdChampsSupp1 = new PropelObjectCollection();
        $this->collTPrestationsRelatedByIdChampsSupp1->setModel('TPrestation');
    }

    /**
     * Gets an array of TPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TChampsSupp is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     * @throws PropelException
     */
    public function getTPrestationsRelatedByIdChampsSupp1($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByIdChampsSupp1Partial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByIdChampsSupp1 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByIdChampsSupp1) {
                // return empty collection
                $this->initTPrestationsRelatedByIdChampsSupp1();
            } else {
                $collTPrestationsRelatedByIdChampsSupp1 = TPrestationQuery::create(null, $criteria)
                    ->filterByTChampsSuppRelatedByIdChampsSupp1($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPrestationsRelatedByIdChampsSupp1Partial && count($collTPrestationsRelatedByIdChampsSupp1)) {
                      $this->initTPrestationsRelatedByIdChampsSupp1(false);

                      foreach($collTPrestationsRelatedByIdChampsSupp1 as $obj) {
                        if (false == $this->collTPrestationsRelatedByIdChampsSupp1->contains($obj)) {
                          $this->collTPrestationsRelatedByIdChampsSupp1->append($obj);
                        }
                      }

                      $this->collTPrestationsRelatedByIdChampsSupp1Partial = true;
                    }

                    $collTPrestationsRelatedByIdChampsSupp1->getInternalIterator()->rewind();
                    return $collTPrestationsRelatedByIdChampsSupp1;
                }

                if($partial && $this->collTPrestationsRelatedByIdChampsSupp1) {
                    foreach($this->collTPrestationsRelatedByIdChampsSupp1 as $obj) {
                        if($obj->isNew()) {
                            $collTPrestationsRelatedByIdChampsSupp1[] = $obj;
                        }
                    }
                }

                $this->collTPrestationsRelatedByIdChampsSupp1 = $collTPrestationsRelatedByIdChampsSupp1;
                $this->collTPrestationsRelatedByIdChampsSupp1Partial = false;
            }
        }

        return $this->collTPrestationsRelatedByIdChampsSupp1;
    }

    /**
     * Sets a collection of TPrestationRelatedByIdChampsSupp1 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPrestationsRelatedByIdChampsSupp1 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setTPrestationsRelatedByIdChampsSupp1(PropelCollection $tPrestationsRelatedByIdChampsSupp1, PropelPDO $con = null)
    {
        $tPrestationsRelatedByIdChampsSupp1ToDelete = $this->getTPrestationsRelatedByIdChampsSupp1(new Criteria(), $con)->diff($tPrestationsRelatedByIdChampsSupp1);

        $this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion = unserialize(serialize($tPrestationsRelatedByIdChampsSupp1ToDelete));

        foreach ($tPrestationsRelatedByIdChampsSupp1ToDelete as $tPrestationRelatedByIdChampsSupp1Removed) {
            $tPrestationRelatedByIdChampsSupp1Removed->setTChampsSuppRelatedByIdChampsSupp1(null);
        }

        $this->collTPrestationsRelatedByIdChampsSupp1 = null;
        foreach ($tPrestationsRelatedByIdChampsSupp1 as $tPrestationRelatedByIdChampsSupp1) {
            $this->addTPrestationRelatedByIdChampsSupp1($tPrestationRelatedByIdChampsSupp1);
        }

        $this->collTPrestationsRelatedByIdChampsSupp1 = $tPrestationsRelatedByIdChampsSupp1;
        $this->collTPrestationsRelatedByIdChampsSupp1Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPrestation objects.
     * @throws PropelException
     */
    public function countTPrestationsRelatedByIdChampsSupp1(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByIdChampsSupp1Partial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByIdChampsSupp1 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByIdChampsSupp1) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPrestationsRelatedByIdChampsSupp1());
            }
            $query = TPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTChampsSuppRelatedByIdChampsSupp1($this)
                ->count($con);
        }

        return count($this->collTPrestationsRelatedByIdChampsSupp1);
    }

    /**
     * Method called to associate a TPrestation object to this object
     * through the TPrestation foreign key attribute.
     *
     * @param    TPrestation $l TPrestation
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function addTPrestationRelatedByIdChampsSupp1(TPrestation $l)
    {
        if ($this->collTPrestationsRelatedByIdChampsSupp1 === null) {
            $this->initTPrestationsRelatedByIdChampsSupp1();
            $this->collTPrestationsRelatedByIdChampsSupp1Partial = true;
        }
        if (!in_array($l, $this->collTPrestationsRelatedByIdChampsSupp1->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPrestationRelatedByIdChampsSupp1($l);
        }

        return $this;
    }

    /**
     * @param	TPrestationRelatedByIdChampsSupp1 $tPrestationRelatedByIdChampsSupp1 The tPrestationRelatedByIdChampsSupp1 object to add.
     */
    protected function doAddTPrestationRelatedByIdChampsSupp1($tPrestationRelatedByIdChampsSupp1)
    {
        $this->collTPrestationsRelatedByIdChampsSupp1[]= $tPrestationRelatedByIdChampsSupp1;
        $tPrestationRelatedByIdChampsSupp1->setTChampsSuppRelatedByIdChampsSupp1($this);
    }

    /**
     * @param	TPrestationRelatedByIdChampsSupp1 $tPrestationRelatedByIdChampsSupp1 The tPrestationRelatedByIdChampsSupp1 object to remove.
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function removeTPrestationRelatedByIdChampsSupp1($tPrestationRelatedByIdChampsSupp1)
    {
        if ($this->getTPrestationsRelatedByIdChampsSupp1()->contains($tPrestationRelatedByIdChampsSupp1)) {
            $this->collTPrestationsRelatedByIdChampsSupp1->remove($this->collTPrestationsRelatedByIdChampsSupp1->search($tPrestationRelatedByIdChampsSupp1));
            if (null === $this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion) {
                $this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion = clone $this->collTPrestationsRelatedByIdChampsSupp1;
                $this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion->clear();
            }
            $this->tPrestationsRelatedByIdChampsSupp1ScheduledForDeletion[]= $tPrestationRelatedByIdChampsSupp1;
            $tPrestationRelatedByIdChampsSupp1->setTChampsSuppRelatedByIdChampsSupp1(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp1JoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp1JoinTTraductionRelatedByCodeLibellePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibellePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp1JoinTParametragePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametragePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp1JoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp1JoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp1JoinTTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTypePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp1($query, $con);
    }

    /**
     * Clears out the collTPrestationsRelatedByIdChampsSupp2 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TChampsSupp The current object (for fluent API support)
     * @see        addTPrestationsRelatedByIdChampsSupp2()
     */
    public function clearTPrestationsRelatedByIdChampsSupp2()
    {
        $this->collTPrestationsRelatedByIdChampsSupp2 = null; // important to set this to null since that means it is uninitialized
        $this->collTPrestationsRelatedByIdChampsSupp2Partial = null;

        return $this;
    }

    /**
     * reset is the collTPrestationsRelatedByIdChampsSupp2 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPrestationsRelatedByIdChampsSupp2($v = true)
    {
        $this->collTPrestationsRelatedByIdChampsSupp2Partial = $v;
    }

    /**
     * Initializes the collTPrestationsRelatedByIdChampsSupp2 collection.
     *
     * By default this just sets the collTPrestationsRelatedByIdChampsSupp2 collection to an empty array (like clearcollTPrestationsRelatedByIdChampsSupp2());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPrestationsRelatedByIdChampsSupp2($overrideExisting = true)
    {
        if (null !== $this->collTPrestationsRelatedByIdChampsSupp2 && !$overrideExisting) {
            return;
        }
        $this->collTPrestationsRelatedByIdChampsSupp2 = new PropelObjectCollection();
        $this->collTPrestationsRelatedByIdChampsSupp2->setModel('TPrestation');
    }

    /**
     * Gets an array of TPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TChampsSupp is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     * @throws PropelException
     */
    public function getTPrestationsRelatedByIdChampsSupp2($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByIdChampsSupp2Partial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByIdChampsSupp2 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByIdChampsSupp2) {
                // return empty collection
                $this->initTPrestationsRelatedByIdChampsSupp2();
            } else {
                $collTPrestationsRelatedByIdChampsSupp2 = TPrestationQuery::create(null, $criteria)
                    ->filterByTChampsSuppRelatedByIdChampsSupp2($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPrestationsRelatedByIdChampsSupp2Partial && count($collTPrestationsRelatedByIdChampsSupp2)) {
                      $this->initTPrestationsRelatedByIdChampsSupp2(false);

                      foreach($collTPrestationsRelatedByIdChampsSupp2 as $obj) {
                        if (false == $this->collTPrestationsRelatedByIdChampsSupp2->contains($obj)) {
                          $this->collTPrestationsRelatedByIdChampsSupp2->append($obj);
                        }
                      }

                      $this->collTPrestationsRelatedByIdChampsSupp2Partial = true;
                    }

                    $collTPrestationsRelatedByIdChampsSupp2->getInternalIterator()->rewind();
                    return $collTPrestationsRelatedByIdChampsSupp2;
                }

                if($partial && $this->collTPrestationsRelatedByIdChampsSupp2) {
                    foreach($this->collTPrestationsRelatedByIdChampsSupp2 as $obj) {
                        if($obj->isNew()) {
                            $collTPrestationsRelatedByIdChampsSupp2[] = $obj;
                        }
                    }
                }

                $this->collTPrestationsRelatedByIdChampsSupp2 = $collTPrestationsRelatedByIdChampsSupp2;
                $this->collTPrestationsRelatedByIdChampsSupp2Partial = false;
            }
        }

        return $this->collTPrestationsRelatedByIdChampsSupp2;
    }

    /**
     * Sets a collection of TPrestationRelatedByIdChampsSupp2 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPrestationsRelatedByIdChampsSupp2 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function setTPrestationsRelatedByIdChampsSupp2(PropelCollection $tPrestationsRelatedByIdChampsSupp2, PropelPDO $con = null)
    {
        $tPrestationsRelatedByIdChampsSupp2ToDelete = $this->getTPrestationsRelatedByIdChampsSupp2(new Criteria(), $con)->diff($tPrestationsRelatedByIdChampsSupp2);

        $this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion = unserialize(serialize($tPrestationsRelatedByIdChampsSupp2ToDelete));

        foreach ($tPrestationsRelatedByIdChampsSupp2ToDelete as $tPrestationRelatedByIdChampsSupp2Removed) {
            $tPrestationRelatedByIdChampsSupp2Removed->setTChampsSuppRelatedByIdChampsSupp2(null);
        }

        $this->collTPrestationsRelatedByIdChampsSupp2 = null;
        foreach ($tPrestationsRelatedByIdChampsSupp2 as $tPrestationRelatedByIdChampsSupp2) {
            $this->addTPrestationRelatedByIdChampsSupp2($tPrestationRelatedByIdChampsSupp2);
        }

        $this->collTPrestationsRelatedByIdChampsSupp2 = $tPrestationsRelatedByIdChampsSupp2;
        $this->collTPrestationsRelatedByIdChampsSupp2Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPrestation objects.
     * @throws PropelException
     */
    public function countTPrestationsRelatedByIdChampsSupp2(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByIdChampsSupp2Partial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByIdChampsSupp2 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByIdChampsSupp2) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPrestationsRelatedByIdChampsSupp2());
            }
            $query = TPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTChampsSuppRelatedByIdChampsSupp2($this)
                ->count($con);
        }

        return count($this->collTPrestationsRelatedByIdChampsSupp2);
    }

    /**
     * Method called to associate a TPrestation object to this object
     * through the TPrestation foreign key attribute.
     *
     * @param    TPrestation $l TPrestation
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function addTPrestationRelatedByIdChampsSupp2(TPrestation $l)
    {
        if ($this->collTPrestationsRelatedByIdChampsSupp2 === null) {
            $this->initTPrestationsRelatedByIdChampsSupp2();
            $this->collTPrestationsRelatedByIdChampsSupp2Partial = true;
        }
        if (!in_array($l, $this->collTPrestationsRelatedByIdChampsSupp2->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPrestationRelatedByIdChampsSupp2($l);
        }

        return $this;
    }

    /**
     * @param	TPrestationRelatedByIdChampsSupp2 $tPrestationRelatedByIdChampsSupp2 The tPrestationRelatedByIdChampsSupp2 object to add.
     */
    protected function doAddTPrestationRelatedByIdChampsSupp2($tPrestationRelatedByIdChampsSupp2)
    {
        $this->collTPrestationsRelatedByIdChampsSupp2[]= $tPrestationRelatedByIdChampsSupp2;
        $tPrestationRelatedByIdChampsSupp2->setTChampsSuppRelatedByIdChampsSupp2($this);
    }

    /**
     * @param	TPrestationRelatedByIdChampsSupp2 $tPrestationRelatedByIdChampsSupp2 The tPrestationRelatedByIdChampsSupp2 object to remove.
     * @return TChampsSupp The current object (for fluent API support)
     */
    public function removeTPrestationRelatedByIdChampsSupp2($tPrestationRelatedByIdChampsSupp2)
    {
        if ($this->getTPrestationsRelatedByIdChampsSupp2()->contains($tPrestationRelatedByIdChampsSupp2)) {
            $this->collTPrestationsRelatedByIdChampsSupp2->remove($this->collTPrestationsRelatedByIdChampsSupp2->search($tPrestationRelatedByIdChampsSupp2));
            if (null === $this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion) {
                $this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion = clone $this->collTPrestationsRelatedByIdChampsSupp2;
                $this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion->clear();
            }
            $this->tPrestationsRelatedByIdChampsSupp2ScheduledForDeletion[]= $tPrestationRelatedByIdChampsSupp2;
            $tPrestationRelatedByIdChampsSupp2->setTChampsSuppRelatedByIdChampsSupp2(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp2JoinTTraductionRelatedByCodeCommentaire($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeCommentaire', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp2JoinTTraductionRelatedByCodeLibellePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeLibellePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp2JoinTParametragePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametragePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp2JoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp2JoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TChampsSupp is new, it will return
     * an empty collection; or if this TChampsSupp has previously
     * been saved, it will retrieve related TPrestationsRelatedByIdChampsSupp2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TChampsSupp.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByIdChampsSupp2JoinTTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTypePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByIdChampsSupp2($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_champs_supp = null;
        $this->id_organisation = null;
        $this->code_champs = null;
        $this->code_libelle = null;
        $this->obligatoire = null;
        $this->champs_type = null;
        $this->value_liste = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTPrestationsRelatedByIdChampsSupp3) {
                foreach ($this->collTPrestationsRelatedByIdChampsSupp3 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPrestationsRelatedByIdChampsSupp1) {
                foreach ($this->collTPrestationsRelatedByIdChampsSupp1 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPrestationsRelatedByIdChampsSupp2) {
                foreach ($this->collTPrestationsRelatedByIdChampsSupp2 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraduction instanceof Persistent) {
              $this->aTTraduction->clearAllReferences($deep);
            }
            if ($this->aTOrganisation instanceof Persistent) {
              $this->aTOrganisation->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTPrestationsRelatedByIdChampsSupp3 instanceof PropelCollection) {
            $this->collTPrestationsRelatedByIdChampsSupp3->clearIterator();
        }
        $this->collTPrestationsRelatedByIdChampsSupp3 = null;
        if ($this->collTPrestationsRelatedByIdChampsSupp1 instanceof PropelCollection) {
            $this->collTPrestationsRelatedByIdChampsSupp1->clearIterator();
        }
        $this->collTPrestationsRelatedByIdChampsSupp1 = null;
        if ($this->collTPrestationsRelatedByIdChampsSupp2 instanceof PropelCollection) {
            $this->collTPrestationsRelatedByIdChampsSupp2->clearIterator();
        }
        $this->collTPrestationsRelatedByIdChampsSupp2 = null;
        $this->aTTraduction = null;
        $this->aTOrganisation = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TChampsSuppPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
