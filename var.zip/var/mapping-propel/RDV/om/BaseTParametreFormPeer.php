<?php


/**
 * Base static class for performing query and update operations on the 'T_PARAMETRE_FORM' table.
 *
 *
 *
 * @package propel.generator.RDV.om
 */
abstract class BaseTParametreFormPeer
{

    /** the default database name for this class */
    const DATABASE_NAME = 'RDV';

    /** the table name for this class */
    const TABLE_NAME = 'T_PARAMETRE_FORM';

    /** the related Propel class for this table */
    const OM_CLASS = 'TParametreForm';

    /** the related TableMap class for this table */
    const TM_CLASS = 'TParametreFormTableMap';

    /** The total number of columns. */
    const NUM_COLUMNS = 53;

    /** The number of lazy-loaded columns. */
    const NUM_LAZY_LOAD_COLUMNS = 0;

    /** The number of columns to hydrate (NUM_COLUMNS - NUM_LAZY_LOAD_COLUMNS) */
    const NUM_HYDRATE_COLUMNS = 53;

    /** the column name for the ID_PARAMETRE_FORM field */
    const ID_PARAMETRE_FORM = 'T_PARAMETRE_FORM.ID_PARAMETRE_FORM';

    /** the column name for the RDV_SIMILAIRE field */
    const RDV_SIMILAIRE = 'T_PARAMETRE_FORM.RDV_SIMILAIRE';

    /** the column name for the NB_JOUR_RDV_SIMILAIRE field */
    const NB_JOUR_RDV_SIMILAIRE = 'T_PARAMETRE_FORM.NB_JOUR_RDV_SIMILAIRE';

    /** the column name for the DELAI_MIN field */
    const DELAI_MIN = 'T_PARAMETRE_FORM.DELAI_MIN';

    /** the column name for the RESSOURCE_VISIBLE field */
    const RESSOURCE_VISIBLE = 'T_PARAMETRE_FORM.RESSOURCE_VISIBLE';

    /** the column name for the RESSOURCE_OBLIGATOIRE field */
    const RESSOURCE_OBLIGATOIRE = 'T_PARAMETRE_FORM.RESSOURCE_OBLIGATOIRE';

    /** the column name for the CODE_COMMENTAIRE field */
    const CODE_COMMENTAIRE = 'T_PARAMETRE_FORM.CODE_COMMENTAIRE';

    /** the column name for the REFERENT_VISIBLE field */
    const REFERENT_VISIBLE = 'T_PARAMETRE_FORM.REFERENT_VISIBLE';

    /** the column name for the TEXT_1_ACTIF field */
    const TEXT_1_ACTIF = 'T_PARAMETRE_FORM.TEXT_1_ACTIF';

    /** the column name for the CODE_LIBELLE_TEXT_1 field */
    const CODE_LIBELLE_TEXT_1 = 'T_PARAMETRE_FORM.CODE_LIBELLE_TEXT_1';

    /** the column name for the OBLIGATOIRE_TEXT_1 field */
    const OBLIGATOIRE_TEXT_1 = 'T_PARAMETRE_FORM.OBLIGATOIRE_TEXT_1';

    /** the column name for the TEXT_2_ACTIF field */
    const TEXT_2_ACTIF = 'T_PARAMETRE_FORM.TEXT_2_ACTIF';

    /** the column name for the CODE_LIBELLE_TEXT_2 field */
    const CODE_LIBELLE_TEXT_2 = 'T_PARAMETRE_FORM.CODE_LIBELLE_TEXT_2';

    /** the column name for the OBLIGATOIRE_TEXT_2 field */
    const OBLIGATOIRE_TEXT_2 = 'T_PARAMETRE_FORM.OBLIGATOIRE_TEXT_2';

    /** the column name for the TEXT_3_ACTIF field */
    const TEXT_3_ACTIF = 'T_PARAMETRE_FORM.TEXT_3_ACTIF';

    /** the column name for the CODE_LIBELLE_TEXT_3 field */
    const CODE_LIBELLE_TEXT_3 = 'T_PARAMETRE_FORM.CODE_LIBELLE_TEXT_3';

    /** the column name for the OBLIGATOIRE_TEXT_3 field */
    const OBLIGATOIRE_TEXT_3 = 'T_PARAMETRE_FORM.OBLIGATOIRE_TEXT_3';

    /** the column name for the REF_1_ACTIF field */
    const REF_1_ACTIF = 'T_PARAMETRE_FORM.REF_1_ACTIF';

    /** the column name for the ID_REF_1 field */
    const ID_REF_1 = 'T_PARAMETRE_FORM.ID_REF_1';

    /** the column name for the CODE_LIBELLE_REF_1 field */
    const CODE_LIBELLE_REF_1 = 'T_PARAMETRE_FORM.CODE_LIBELLE_REF_1';

    /** the column name for the OBLIGATOIRE_REF_1 field */
    const OBLIGATOIRE_REF_1 = 'T_PARAMETRE_FORM.OBLIGATOIRE_REF_1';

    /** the column name for the REF_2_ACTIF field */
    const REF_2_ACTIF = 'T_PARAMETRE_FORM.REF_2_ACTIF';

    /** the column name for the ID_REF_2 field */
    const ID_REF_2 = 'T_PARAMETRE_FORM.ID_REF_2';

    /** the column name for the CODE_LIBELLE_REF_2 field */
    const CODE_LIBELLE_REF_2 = 'T_PARAMETRE_FORM.CODE_LIBELLE_REF_2';

    /** the column name for the OBLIGATOIRE_REF_2 field */
    const OBLIGATOIRE_REF_2 = 'T_PARAMETRE_FORM.OBLIGATOIRE_REF_2';

    /** the column name for the REF_3_ACTIF field */
    const REF_3_ACTIF = 'T_PARAMETRE_FORM.REF_3_ACTIF';

    /** the column name for the ID_REF_3 field */
    const ID_REF_3 = 'T_PARAMETRE_FORM.ID_REF_3';

    /** the column name for the CODE_LIBELLE_REF_3 field */
    const CODE_LIBELLE_REF_3 = 'T_PARAMETRE_FORM.CODE_LIBELLE_REF_3';

    /** the column name for the OBLIGATOIRE_REF_3 field */
    const OBLIGATOIRE_REF_3 = 'T_PARAMETRE_FORM.OBLIGATOIRE_REF_3';

    /** the column name for the OBLIGATOIRE_NOM field */
    const OBLIGATOIRE_NOM = 'T_PARAMETRE_FORM.OBLIGATOIRE_NOM';

    /** the column name for the OBLIGATOIRE_PRENOM field */
    const OBLIGATOIRE_PRENOM = 'T_PARAMETRE_FORM.OBLIGATOIRE_PRENOM';

    /** the column name for the OBLIGATOIRE_DATE_NAISSANCE field */
    const OBLIGATOIRE_DATE_NAISSANCE = 'T_PARAMETRE_FORM.OBLIGATOIRE_DATE_NAISSANCE';

    /** the column name for the OBLIGATOIRE_EMAIL field */
    const OBLIGATOIRE_EMAIL = 'T_PARAMETRE_FORM.OBLIGATOIRE_EMAIL';

    /** the column name for the OBLIGATOIRE_IDENTIFIANT field */
    const OBLIGATOIRE_IDENTIFIANT = 'T_PARAMETRE_FORM.OBLIGATOIRE_IDENTIFIANT';

    /** the column name for the OBLIGATOIRE_TELEPHONE field */
    const OBLIGATOIRE_TELEPHONE = 'T_PARAMETRE_FORM.OBLIGATOIRE_TELEPHONE';

    /** the column name for the OBLIGATOIRE_RAISON_SOCIAL field */
    const OBLIGATOIRE_RAISON_SOCIAL = 'T_PARAMETRE_FORM.OBLIGATOIRE_RAISON_SOCIAL';

    /** the column name for the OBLIGATOIRE_ADRESSE field */
    const OBLIGATOIRE_ADRESSE = 'T_PARAMETRE_FORM.OBLIGATOIRE_ADRESSE';

    /** the column name for the OBLIGATOIRE_FAX field */
    const OBLIGATOIRE_FAX = 'T_PARAMETRE_FORM.OBLIGATOIRE_FAX';

    /** the column name for the VISIBLE_NOM field */
    const VISIBLE_NOM = 'T_PARAMETRE_FORM.VISIBLE_NOM';

    /** the column name for the VISIBLE_PRENOM field */
    const VISIBLE_PRENOM = 'T_PARAMETRE_FORM.VISIBLE_PRENOM';

    /** the column name for the VISIBLE_DATE_NAISSANCE field */
    const VISIBLE_DATE_NAISSANCE = 'T_PARAMETRE_FORM.VISIBLE_DATE_NAISSANCE';

    /** the column name for the VISIBLE_EMAIL field */
    const VISIBLE_EMAIL = 'T_PARAMETRE_FORM.VISIBLE_EMAIL';

    /** the column name for the VISIBLE_IDENTIFIANT field */
    const VISIBLE_IDENTIFIANT = 'T_PARAMETRE_FORM.VISIBLE_IDENTIFIANT';

    /** the column name for the VISIBLE_TELEPHONE field */
    const VISIBLE_TELEPHONE = 'T_PARAMETRE_FORM.VISIBLE_TELEPHONE';

    /** the column name for the VISIBLE_RAISON_SOCIAL field */
    const VISIBLE_RAISON_SOCIAL = 'T_PARAMETRE_FORM.VISIBLE_RAISON_SOCIAL';

    /** the column name for the VISIBLE_ADRESSE field */
    const VISIBLE_ADRESSE = 'T_PARAMETRE_FORM.VISIBLE_ADRESSE';

    /** the column name for the VISIBLE_FAX field */
    const VISIBLE_FAX = 'T_PARAMETRE_FORM.VISIBLE_FAX';

    /** the column name for the TEXT_1_TYPE field */
    const TEXT_1_TYPE = 'T_PARAMETRE_FORM.TEXT_1_TYPE';

    /** the column name for the TEXT_2_TYPE field */
    const TEXT_2_TYPE = 'T_PARAMETRE_FORM.TEXT_2_TYPE';

    /** the column name for the TEXT_3_TYPE field */
    const TEXT_3_TYPE = 'T_PARAMETRE_FORM.TEXT_3_TYPE';

    /** the column name for the TEXT_1_LISTE field */
    const TEXT_1_LISTE = 'T_PARAMETRE_FORM.TEXT_1_LISTE';

    /** the column name for the TEXT_2_LISTE field */
    const TEXT_2_LISTE = 'T_PARAMETRE_FORM.TEXT_2_LISTE';

    /** the column name for the TEXT_3_LISTE field */
    const TEXT_3_LISTE = 'T_PARAMETRE_FORM.TEXT_3_LISTE';

    /** The enumerated values for the RDV_SIMILAIRE field */
    const RDV_SIMILAIRE_0 = '0';
    const RDV_SIMILAIRE_1 = '1';

    /** The enumerated values for the RESSOURCE_VISIBLE field */
    const RESSOURCE_VISIBLE_0 = '0';
    const RESSOURCE_VISIBLE_1 = '1';

    /** The enumerated values for the RESSOURCE_OBLIGATOIRE field */
    const RESSOURCE_OBLIGATOIRE_0 = '0';
    const RESSOURCE_OBLIGATOIRE_1 = '1';

    /** The enumerated values for the REFERENT_VISIBLE field */
    const REFERENT_VISIBLE_0 = '0';
    const REFERENT_VISIBLE_1 = '1';

    /** The enumerated values for the TEXT_1_ACTIF field */
    const TEXT_1_ACTIF_0 = '0';
    const TEXT_1_ACTIF_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_TEXT_1 field */
    const OBLIGATOIRE_TEXT_1_0 = '0';
    const OBLIGATOIRE_TEXT_1_1 = '1';

    /** The enumerated values for the TEXT_2_ACTIF field */
    const TEXT_2_ACTIF_0 = '0';
    const TEXT_2_ACTIF_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_TEXT_2 field */
    const OBLIGATOIRE_TEXT_2_0 = '0';
    const OBLIGATOIRE_TEXT_2_1 = '1';

    /** The enumerated values for the TEXT_3_ACTIF field */
    const TEXT_3_ACTIF_0 = '0';
    const TEXT_3_ACTIF_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_TEXT_3 field */
    const OBLIGATOIRE_TEXT_3_0 = '0';
    const OBLIGATOIRE_TEXT_3_1 = '1';

    /** The enumerated values for the REF_1_ACTIF field */
    const REF_1_ACTIF_0 = '0';
    const REF_1_ACTIF_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_REF_1 field */
    const OBLIGATOIRE_REF_1_0 = '0';
    const OBLIGATOIRE_REF_1_1 = '1';

    /** The enumerated values for the REF_2_ACTIF field */
    const REF_2_ACTIF_0 = '0';
    const REF_2_ACTIF_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_REF_2 field */
    const OBLIGATOIRE_REF_2_0 = '0';
    const OBLIGATOIRE_REF_2_1 = '1';

    /** The enumerated values for the REF_3_ACTIF field */
    const REF_3_ACTIF_0 = '0';
    const REF_3_ACTIF_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_REF_3 field */
    const OBLIGATOIRE_REF_3_0 = '0';
    const OBLIGATOIRE_REF_3_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_NOM field */
    const OBLIGATOIRE_NOM_0 = '0';
    const OBLIGATOIRE_NOM_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_PRENOM field */
    const OBLIGATOIRE_PRENOM_0 = '0';
    const OBLIGATOIRE_PRENOM_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_DATE_NAISSANCE field */
    const OBLIGATOIRE_DATE_NAISSANCE_0 = '0';
    const OBLIGATOIRE_DATE_NAISSANCE_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_EMAIL field */
    const OBLIGATOIRE_EMAIL_0 = '0';
    const OBLIGATOIRE_EMAIL_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_IDENTIFIANT field */
    const OBLIGATOIRE_IDENTIFIANT_0 = '0';
    const OBLIGATOIRE_IDENTIFIANT_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_TELEPHONE field */
    const OBLIGATOIRE_TELEPHONE_0 = '0';
    const OBLIGATOIRE_TELEPHONE_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_RAISON_SOCIAL field */
    const OBLIGATOIRE_RAISON_SOCIAL_0 = '0';
    const OBLIGATOIRE_RAISON_SOCIAL_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_ADRESSE field */
    const OBLIGATOIRE_ADRESSE_0 = '0';
    const OBLIGATOIRE_ADRESSE_1 = '1';

    /** The enumerated values for the OBLIGATOIRE_FAX field */
    const OBLIGATOIRE_FAX_0 = '0';
    const OBLIGATOIRE_FAX_1 = '1';

    /** The enumerated values for the VISIBLE_NOM field */
    const VISIBLE_NOM_0 = '0';
    const VISIBLE_NOM_1 = '1';

    /** The enumerated values for the VISIBLE_PRENOM field */
    const VISIBLE_PRENOM_0 = '0';
    const VISIBLE_PRENOM_1 = '1';

    /** The enumerated values for the VISIBLE_DATE_NAISSANCE field */
    const VISIBLE_DATE_NAISSANCE_0 = '0';
    const VISIBLE_DATE_NAISSANCE_1 = '1';

    /** The enumerated values for the VISIBLE_EMAIL field */
    const VISIBLE_EMAIL_0 = '0';
    const VISIBLE_EMAIL_1 = '1';

    /** The enumerated values for the VISIBLE_IDENTIFIANT field */
    const VISIBLE_IDENTIFIANT_0 = '0';
    const VISIBLE_IDENTIFIANT_1 = '1';

    /** The enumerated values for the VISIBLE_TELEPHONE field */
    const VISIBLE_TELEPHONE_0 = '0';
    const VISIBLE_TELEPHONE_1 = '1';

    /** The enumerated values for the VISIBLE_RAISON_SOCIAL field */
    const VISIBLE_RAISON_SOCIAL_0 = '0';
    const VISIBLE_RAISON_SOCIAL_1 = '1';

    /** The enumerated values for the VISIBLE_ADRESSE field */
    const VISIBLE_ADRESSE_0 = '0';
    const VISIBLE_ADRESSE_1 = '1';

    /** The enumerated values for the VISIBLE_FAX field */
    const VISIBLE_FAX_0 = '0';
    const VISIBLE_FAX_1 = '1';

    /** The enumerated values for the TEXT_1_TYPE field */
    const TEXT_1_TYPE_TEXT = 'TEXT';
    const TEXT_1_TYPE_NUMERIC = 'NUMERIC';
    const TEXT_1_TYPE_LISTE = 'LISTE';
    const TEXT_1_TYPE_MULTICHOIX = 'MULTICHOIX';

    /** The enumerated values for the TEXT_2_TYPE field */
    const TEXT_2_TYPE_TEXT = 'TEXT';
    const TEXT_2_TYPE_NUMERIC = 'NUMERIC';
    const TEXT_2_TYPE_LISTE = 'LISTE';
    const TEXT_2_TYPE_MULTICHOIX = 'MULTICHOIX';

    /** The enumerated values for the TEXT_3_TYPE field */
    const TEXT_3_TYPE_TEXT = 'TEXT';
    const TEXT_3_TYPE_NUMERIC = 'NUMERIC';
    const TEXT_3_TYPE_LISTE = 'LISTE';
    const TEXT_3_TYPE_MULTICHOIX = 'MULTICHOIX';

    /** The default string format for model objects of the related table **/
    const DEFAULT_STRING_FORMAT = 'YAML';

    /**
     * An identiy map to hold any loaded instances of TParametreForm objects.
     * This must be public so that other peer classes can access this when hydrating from JOIN
     * queries.
     * @var        array TParametreForm[]
     */
    public static $instances = array();


    /**
     * holds an array of fieldnames
     *
     * first dimension keys are the type constants
     * e.g. TParametreFormPeer::$fieldNames[TParametreFormPeer::TYPE_PHPNAME][0] = 'Id'
     */
    protected static $fieldNames = array (
        BasePeer::TYPE_PHPNAME => array ('IdParametreForm', 'RdvSimilaire', 'NbJourRdvSimilaire', 'DelaiMin', 'RessourceVisible', 'RessourceObligatoire', 'CodeCommentaire', 'ReferentVisible', 'Text1Actif', 'CodeLibelleText1', 'ObligatoireText1', 'Text2Actif', 'CodeLibelleText2', 'ObligatoireText2', 'Text3Actif', 'CodeLibelleText3', 'ObligatoireText3', 'Ref1Actif', 'IdRef1', 'CodeLibelleRef1', 'ObligatoireRef1', 'Ref2Actif', 'IdRef2', 'CodeLibelleRef2', 'ObligatoireRef2', 'Ref3Actif', 'IdRef3', 'CodeLibelleRef3', 'ObligatoireRef3', 'ObligatoireNom', 'ObligatoirePrenom', 'ObligatoireDateNaissance', 'ObligatoireEmail', 'ObligatoireIdentifiant', 'ObligatoireTelephone', 'ObligatoireRaisonSocial', 'ObligatoireAdresse', 'ObligatoireFax', 'VisibleNom', 'VisiblePrenom', 'VisibleDateNaissance', 'VisibleEmail', 'VisibleIdentifiant', 'VisibleTelephone', 'VisibleRaisonSocial', 'VisibleAdresse', 'VisibleFax', 'Text1Type', 'Text2Type', 'Text3Type', 'Text1Liste', 'Text2Liste', 'Text3Liste', ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idParametreForm', 'rdvSimilaire', 'nbJourRdvSimilaire', 'delaiMin', 'ressourceVisible', 'ressourceObligatoire', 'codeCommentaire', 'referentVisible', 'text1Actif', 'codeLibelleText1', 'obligatoireText1', 'text2Actif', 'codeLibelleText2', 'obligatoireText2', 'text3Actif', 'codeLibelleText3', 'obligatoireText3', 'ref1Actif', 'idRef1', 'codeLibelleRef1', 'obligatoireRef1', 'ref2Actif', 'idRef2', 'codeLibelleRef2', 'obligatoireRef2', 'ref3Actif', 'idRef3', 'codeLibelleRef3', 'obligatoireRef3', 'obligatoireNom', 'obligatoirePrenom', 'obligatoireDateNaissance', 'obligatoireEmail', 'obligatoireIdentifiant', 'obligatoireTelephone', 'obligatoireRaisonSocial', 'obligatoireAdresse', 'obligatoireFax', 'visibleNom', 'visiblePrenom', 'visibleDateNaissance', 'visibleEmail', 'visibleIdentifiant', 'visibleTelephone', 'visibleRaisonSocial', 'visibleAdresse', 'visibleFax', 'text1Type', 'text2Type', 'text3Type', 'text1Liste', 'text2Liste', 'text3Liste', ),
        BasePeer::TYPE_COLNAME => array (TParametreFormPeer::ID_PARAMETRE_FORM, TParametreFormPeer::RDV_SIMILAIRE, TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE, TParametreFormPeer::DELAI_MIN, TParametreFormPeer::RESSOURCE_VISIBLE, TParametreFormPeer::RESSOURCE_OBLIGATOIRE, TParametreFormPeer::CODE_COMMENTAIRE, TParametreFormPeer::REFERENT_VISIBLE, TParametreFormPeer::TEXT_1_ACTIF, TParametreFormPeer::CODE_LIBELLE_TEXT_1, TParametreFormPeer::OBLIGATOIRE_TEXT_1, TParametreFormPeer::TEXT_2_ACTIF, TParametreFormPeer::CODE_LIBELLE_TEXT_2, TParametreFormPeer::OBLIGATOIRE_TEXT_2, TParametreFormPeer::TEXT_3_ACTIF, TParametreFormPeer::CODE_LIBELLE_TEXT_3, TParametreFormPeer::OBLIGATOIRE_TEXT_3, TParametreFormPeer::REF_1_ACTIF, TParametreFormPeer::ID_REF_1, TParametreFormPeer::CODE_LIBELLE_REF_1, TParametreFormPeer::OBLIGATOIRE_REF_1, TParametreFormPeer::REF_2_ACTIF, TParametreFormPeer::ID_REF_2, TParametreFormPeer::CODE_LIBELLE_REF_2, TParametreFormPeer::OBLIGATOIRE_REF_2, TParametreFormPeer::REF_3_ACTIF, TParametreFormPeer::ID_REF_3, TParametreFormPeer::CODE_LIBELLE_REF_3, TParametreFormPeer::OBLIGATOIRE_REF_3, TParametreFormPeer::OBLIGATOIRE_NOM, TParametreFormPeer::OBLIGATOIRE_PRENOM, TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE, TParametreFormPeer::OBLIGATOIRE_EMAIL, TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT, TParametreFormPeer::OBLIGATOIRE_TELEPHONE, TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL, TParametreFormPeer::OBLIGATOIRE_ADRESSE, TParametreFormPeer::OBLIGATOIRE_FAX, TParametreFormPeer::VISIBLE_NOM, TParametreFormPeer::VISIBLE_PRENOM, TParametreFormPeer::VISIBLE_DATE_NAISSANCE, TParametreFormPeer::VISIBLE_EMAIL, TParametreFormPeer::VISIBLE_IDENTIFIANT, TParametreFormPeer::VISIBLE_TELEPHONE, TParametreFormPeer::VISIBLE_RAISON_SOCIAL, TParametreFormPeer::VISIBLE_ADRESSE, TParametreFormPeer::VISIBLE_FAX, TParametreFormPeer::TEXT_1_TYPE, TParametreFormPeer::TEXT_2_TYPE, TParametreFormPeer::TEXT_3_TYPE, TParametreFormPeer::TEXT_1_LISTE, TParametreFormPeer::TEXT_2_LISTE, TParametreFormPeer::TEXT_3_LISTE, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_PARAMETRE_FORM', 'RDV_SIMILAIRE', 'NB_JOUR_RDV_SIMILAIRE', 'DELAI_MIN', 'RESSOURCE_VISIBLE', 'RESSOURCE_OBLIGATOIRE', 'CODE_COMMENTAIRE', 'REFERENT_VISIBLE', 'TEXT_1_ACTIF', 'CODE_LIBELLE_TEXT_1', 'OBLIGATOIRE_TEXT_1', 'TEXT_2_ACTIF', 'CODE_LIBELLE_TEXT_2', 'OBLIGATOIRE_TEXT_2', 'TEXT_3_ACTIF', 'CODE_LIBELLE_TEXT_3', 'OBLIGATOIRE_TEXT_3', 'REF_1_ACTIF', 'ID_REF_1', 'CODE_LIBELLE_REF_1', 'OBLIGATOIRE_REF_1', 'REF_2_ACTIF', 'ID_REF_2', 'CODE_LIBELLE_REF_2', 'OBLIGATOIRE_REF_2', 'REF_3_ACTIF', 'ID_REF_3', 'CODE_LIBELLE_REF_3', 'OBLIGATOIRE_REF_3', 'OBLIGATOIRE_NOM', 'OBLIGATOIRE_PRENOM', 'OBLIGATOIRE_DATE_NAISSANCE', 'OBLIGATOIRE_EMAIL', 'OBLIGATOIRE_IDENTIFIANT', 'OBLIGATOIRE_TELEPHONE', 'OBLIGATOIRE_RAISON_SOCIAL', 'OBLIGATOIRE_ADRESSE', 'OBLIGATOIRE_FAX', 'VISIBLE_NOM', 'VISIBLE_PRENOM', 'VISIBLE_DATE_NAISSANCE', 'VISIBLE_EMAIL', 'VISIBLE_IDENTIFIANT', 'VISIBLE_TELEPHONE', 'VISIBLE_RAISON_SOCIAL', 'VISIBLE_ADRESSE', 'VISIBLE_FAX', 'TEXT_1_TYPE', 'TEXT_2_TYPE', 'TEXT_3_TYPE', 'TEXT_1_LISTE', 'TEXT_2_LISTE', 'TEXT_3_LISTE', ),
        BasePeer::TYPE_FIELDNAME => array ('ID_PARAMETRE_FORM', 'RDV_SIMILAIRE', 'NB_JOUR_RDV_SIMILAIRE', 'DELAI_MIN', 'RESSOURCE_VISIBLE', 'RESSOURCE_OBLIGATOIRE', 'CODE_COMMENTAIRE', 'REFERENT_VISIBLE', 'TEXT_1_ACTIF', 'CODE_LIBELLE_TEXT_1', 'OBLIGATOIRE_TEXT_1', 'TEXT_2_ACTIF', 'CODE_LIBELLE_TEXT_2', 'OBLIGATOIRE_TEXT_2', 'TEXT_3_ACTIF', 'CODE_LIBELLE_TEXT_3', 'OBLIGATOIRE_TEXT_3', 'REF_1_ACTIF', 'ID_REF_1', 'CODE_LIBELLE_REF_1', 'OBLIGATOIRE_REF_1', 'REF_2_ACTIF', 'ID_REF_2', 'CODE_LIBELLE_REF_2', 'OBLIGATOIRE_REF_2', 'REF_3_ACTIF', 'ID_REF_3', 'CODE_LIBELLE_REF_3', 'OBLIGATOIRE_REF_3', 'OBLIGATOIRE_NOM', 'OBLIGATOIRE_PRENOM', 'OBLIGATOIRE_DATE_NAISSANCE', 'OBLIGATOIRE_EMAIL', 'OBLIGATOIRE_IDENTIFIANT', 'OBLIGATOIRE_TELEPHONE', 'OBLIGATOIRE_RAISON_SOCIAL', 'OBLIGATOIRE_ADRESSE', 'OBLIGATOIRE_FAX', 'VISIBLE_NOM', 'VISIBLE_PRENOM', 'VISIBLE_DATE_NAISSANCE', 'VISIBLE_EMAIL', 'VISIBLE_IDENTIFIANT', 'VISIBLE_TELEPHONE', 'VISIBLE_RAISON_SOCIAL', 'VISIBLE_ADRESSE', 'VISIBLE_FAX', 'TEXT_1_TYPE', 'TEXT_2_TYPE', 'TEXT_3_TYPE', 'TEXT_1_LISTE', 'TEXT_2_LISTE', 'TEXT_3_LISTE', ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, )
    );

    /**
     * holds an array of keys for quick access to the fieldnames array
     *
     * first dimension keys are the type constants
     * e.g. TParametreFormPeer::$fieldNames[BasePeer::TYPE_PHPNAME]['Id'] = 0
     */
    protected static $fieldKeys = array (
        BasePeer::TYPE_PHPNAME => array ('IdParametreForm' => 0, 'RdvSimilaire' => 1, 'NbJourRdvSimilaire' => 2, 'DelaiMin' => 3, 'RessourceVisible' => 4, 'RessourceObligatoire' => 5, 'CodeCommentaire' => 6, 'ReferentVisible' => 7, 'Text1Actif' => 8, 'CodeLibelleText1' => 9, 'ObligatoireText1' => 10, 'Text2Actif' => 11, 'CodeLibelleText2' => 12, 'ObligatoireText2' => 13, 'Text3Actif' => 14, 'CodeLibelleText3' => 15, 'ObligatoireText3' => 16, 'Ref1Actif' => 17, 'IdRef1' => 18, 'CodeLibelleRef1' => 19, 'ObligatoireRef1' => 20, 'Ref2Actif' => 21, 'IdRef2' => 22, 'CodeLibelleRef2' => 23, 'ObligatoireRef2' => 24, 'Ref3Actif' => 25, 'IdRef3' => 26, 'CodeLibelleRef3' => 27, 'ObligatoireRef3' => 28, 'ObligatoireNom' => 29, 'ObligatoirePrenom' => 30, 'ObligatoireDateNaissance' => 31, 'ObligatoireEmail' => 32, 'ObligatoireIdentifiant' => 33, 'ObligatoireTelephone' => 34, 'ObligatoireRaisonSocial' => 35, 'ObligatoireAdresse' => 36, 'ObligatoireFax' => 37, 'VisibleNom' => 38, 'VisiblePrenom' => 39, 'VisibleDateNaissance' => 40, 'VisibleEmail' => 41, 'VisibleIdentifiant' => 42, 'VisibleTelephone' => 43, 'VisibleRaisonSocial' => 44, 'VisibleAdresse' => 45, 'VisibleFax' => 46, 'Text1Type' => 47, 'Text2Type' => 48, 'Text3Type' => 49, 'Text1Liste' => 50, 'Text2Liste' => 51, 'Text3Liste' => 52, ),
        BasePeer::TYPE_STUDLYPHPNAME => array ('idParametreForm' => 0, 'rdvSimilaire' => 1, 'nbJourRdvSimilaire' => 2, 'delaiMin' => 3, 'ressourceVisible' => 4, 'ressourceObligatoire' => 5, 'codeCommentaire' => 6, 'referentVisible' => 7, 'text1Actif' => 8, 'codeLibelleText1' => 9, 'obligatoireText1' => 10, 'text2Actif' => 11, 'codeLibelleText2' => 12, 'obligatoireText2' => 13, 'text3Actif' => 14, 'codeLibelleText3' => 15, 'obligatoireText3' => 16, 'ref1Actif' => 17, 'idRef1' => 18, 'codeLibelleRef1' => 19, 'obligatoireRef1' => 20, 'ref2Actif' => 21, 'idRef2' => 22, 'codeLibelleRef2' => 23, 'obligatoireRef2' => 24, 'ref3Actif' => 25, 'idRef3' => 26, 'codeLibelleRef3' => 27, 'obligatoireRef3' => 28, 'obligatoireNom' => 29, 'obligatoirePrenom' => 30, 'obligatoireDateNaissance' => 31, 'obligatoireEmail' => 32, 'obligatoireIdentifiant' => 33, 'obligatoireTelephone' => 34, 'obligatoireRaisonSocial' => 35, 'obligatoireAdresse' => 36, 'obligatoireFax' => 37, 'visibleNom' => 38, 'visiblePrenom' => 39, 'visibleDateNaissance' => 40, 'visibleEmail' => 41, 'visibleIdentifiant' => 42, 'visibleTelephone' => 43, 'visibleRaisonSocial' => 44, 'visibleAdresse' => 45, 'visibleFax' => 46, 'text1Type' => 47, 'text2Type' => 48, 'text3Type' => 49, 'text1Liste' => 50, 'text2Liste' => 51, 'text3Liste' => 52, ),
        BasePeer::TYPE_COLNAME => array (TParametreFormPeer::ID_PARAMETRE_FORM => 0, TParametreFormPeer::RDV_SIMILAIRE => 1, TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE => 2, TParametreFormPeer::DELAI_MIN => 3, TParametreFormPeer::RESSOURCE_VISIBLE => 4, TParametreFormPeer::RESSOURCE_OBLIGATOIRE => 5, TParametreFormPeer::CODE_COMMENTAIRE => 6, TParametreFormPeer::REFERENT_VISIBLE => 7, TParametreFormPeer::TEXT_1_ACTIF => 8, TParametreFormPeer::CODE_LIBELLE_TEXT_1 => 9, TParametreFormPeer::OBLIGATOIRE_TEXT_1 => 10, TParametreFormPeer::TEXT_2_ACTIF => 11, TParametreFormPeer::CODE_LIBELLE_TEXT_2 => 12, TParametreFormPeer::OBLIGATOIRE_TEXT_2 => 13, TParametreFormPeer::TEXT_3_ACTIF => 14, TParametreFormPeer::CODE_LIBELLE_TEXT_3 => 15, TParametreFormPeer::OBLIGATOIRE_TEXT_3 => 16, TParametreFormPeer::REF_1_ACTIF => 17, TParametreFormPeer::ID_REF_1 => 18, TParametreFormPeer::CODE_LIBELLE_REF_1 => 19, TParametreFormPeer::OBLIGATOIRE_REF_1 => 20, TParametreFormPeer::REF_2_ACTIF => 21, TParametreFormPeer::ID_REF_2 => 22, TParametreFormPeer::CODE_LIBELLE_REF_2 => 23, TParametreFormPeer::OBLIGATOIRE_REF_2 => 24, TParametreFormPeer::REF_3_ACTIF => 25, TParametreFormPeer::ID_REF_3 => 26, TParametreFormPeer::CODE_LIBELLE_REF_3 => 27, TParametreFormPeer::OBLIGATOIRE_REF_3 => 28, TParametreFormPeer::OBLIGATOIRE_NOM => 29, TParametreFormPeer::OBLIGATOIRE_PRENOM => 30, TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE => 31, TParametreFormPeer::OBLIGATOIRE_EMAIL => 32, TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT => 33, TParametreFormPeer::OBLIGATOIRE_TELEPHONE => 34, TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL => 35, TParametreFormPeer::OBLIGATOIRE_ADRESSE => 36, TParametreFormPeer::OBLIGATOIRE_FAX => 37, TParametreFormPeer::VISIBLE_NOM => 38, TParametreFormPeer::VISIBLE_PRENOM => 39, TParametreFormPeer::VISIBLE_DATE_NAISSANCE => 40, TParametreFormPeer::VISIBLE_EMAIL => 41, TParametreFormPeer::VISIBLE_IDENTIFIANT => 42, TParametreFormPeer::VISIBLE_TELEPHONE => 43, TParametreFormPeer::VISIBLE_RAISON_SOCIAL => 44, TParametreFormPeer::VISIBLE_ADRESSE => 45, TParametreFormPeer::VISIBLE_FAX => 46, TParametreFormPeer::TEXT_1_TYPE => 47, TParametreFormPeer::TEXT_2_TYPE => 48, TParametreFormPeer::TEXT_3_TYPE => 49, TParametreFormPeer::TEXT_1_LISTE => 50, TParametreFormPeer::TEXT_2_LISTE => 51, TParametreFormPeer::TEXT_3_LISTE => 52, ),
        BasePeer::TYPE_RAW_COLNAME => array ('ID_PARAMETRE_FORM' => 0, 'RDV_SIMILAIRE' => 1, 'NB_JOUR_RDV_SIMILAIRE' => 2, 'DELAI_MIN' => 3, 'RESSOURCE_VISIBLE' => 4, 'RESSOURCE_OBLIGATOIRE' => 5, 'CODE_COMMENTAIRE' => 6, 'REFERENT_VISIBLE' => 7, 'TEXT_1_ACTIF' => 8, 'CODE_LIBELLE_TEXT_1' => 9, 'OBLIGATOIRE_TEXT_1' => 10, 'TEXT_2_ACTIF' => 11, 'CODE_LIBELLE_TEXT_2' => 12, 'OBLIGATOIRE_TEXT_2' => 13, 'TEXT_3_ACTIF' => 14, 'CODE_LIBELLE_TEXT_3' => 15, 'OBLIGATOIRE_TEXT_3' => 16, 'REF_1_ACTIF' => 17, 'ID_REF_1' => 18, 'CODE_LIBELLE_REF_1' => 19, 'OBLIGATOIRE_REF_1' => 20, 'REF_2_ACTIF' => 21, 'ID_REF_2' => 22, 'CODE_LIBELLE_REF_2' => 23, 'OBLIGATOIRE_REF_2' => 24, 'REF_3_ACTIF' => 25, 'ID_REF_3' => 26, 'CODE_LIBELLE_REF_3' => 27, 'OBLIGATOIRE_REF_3' => 28, 'OBLIGATOIRE_NOM' => 29, 'OBLIGATOIRE_PRENOM' => 30, 'OBLIGATOIRE_DATE_NAISSANCE' => 31, 'OBLIGATOIRE_EMAIL' => 32, 'OBLIGATOIRE_IDENTIFIANT' => 33, 'OBLIGATOIRE_TELEPHONE' => 34, 'OBLIGATOIRE_RAISON_SOCIAL' => 35, 'OBLIGATOIRE_ADRESSE' => 36, 'OBLIGATOIRE_FAX' => 37, 'VISIBLE_NOM' => 38, 'VISIBLE_PRENOM' => 39, 'VISIBLE_DATE_NAISSANCE' => 40, 'VISIBLE_EMAIL' => 41, 'VISIBLE_IDENTIFIANT' => 42, 'VISIBLE_TELEPHONE' => 43, 'VISIBLE_RAISON_SOCIAL' => 44, 'VISIBLE_ADRESSE' => 45, 'VISIBLE_FAX' => 46, 'TEXT_1_TYPE' => 47, 'TEXT_2_TYPE' => 48, 'TEXT_3_TYPE' => 49, 'TEXT_1_LISTE' => 50, 'TEXT_2_LISTE' => 51, 'TEXT_3_LISTE' => 52, ),
        BasePeer::TYPE_FIELDNAME => array ('ID_PARAMETRE_FORM' => 0, 'RDV_SIMILAIRE' => 1, 'NB_JOUR_RDV_SIMILAIRE' => 2, 'DELAI_MIN' => 3, 'RESSOURCE_VISIBLE' => 4, 'RESSOURCE_OBLIGATOIRE' => 5, 'CODE_COMMENTAIRE' => 6, 'REFERENT_VISIBLE' => 7, 'TEXT_1_ACTIF' => 8, 'CODE_LIBELLE_TEXT_1' => 9, 'OBLIGATOIRE_TEXT_1' => 10, 'TEXT_2_ACTIF' => 11, 'CODE_LIBELLE_TEXT_2' => 12, 'OBLIGATOIRE_TEXT_2' => 13, 'TEXT_3_ACTIF' => 14, 'CODE_LIBELLE_TEXT_3' => 15, 'OBLIGATOIRE_TEXT_3' => 16, 'REF_1_ACTIF' => 17, 'ID_REF_1' => 18, 'CODE_LIBELLE_REF_1' => 19, 'OBLIGATOIRE_REF_1' => 20, 'REF_2_ACTIF' => 21, 'ID_REF_2' => 22, 'CODE_LIBELLE_REF_2' => 23, 'OBLIGATOIRE_REF_2' => 24, 'REF_3_ACTIF' => 25, 'ID_REF_3' => 26, 'CODE_LIBELLE_REF_3' => 27, 'OBLIGATOIRE_REF_3' => 28, 'OBLIGATOIRE_NOM' => 29, 'OBLIGATOIRE_PRENOM' => 30, 'OBLIGATOIRE_DATE_NAISSANCE' => 31, 'OBLIGATOIRE_EMAIL' => 32, 'OBLIGATOIRE_IDENTIFIANT' => 33, 'OBLIGATOIRE_TELEPHONE' => 34, 'OBLIGATOIRE_RAISON_SOCIAL' => 35, 'OBLIGATOIRE_ADRESSE' => 36, 'OBLIGATOIRE_FAX' => 37, 'VISIBLE_NOM' => 38, 'VISIBLE_PRENOM' => 39, 'VISIBLE_DATE_NAISSANCE' => 40, 'VISIBLE_EMAIL' => 41, 'VISIBLE_IDENTIFIANT' => 42, 'VISIBLE_TELEPHONE' => 43, 'VISIBLE_RAISON_SOCIAL' => 44, 'VISIBLE_ADRESSE' => 45, 'VISIBLE_FAX' => 46, 'TEXT_1_TYPE' => 47, 'TEXT_2_TYPE' => 48, 'TEXT_3_TYPE' => 49, 'TEXT_1_LISTE' => 50, 'TEXT_2_LISTE' => 51, 'TEXT_3_LISTE' => 52, ),
        BasePeer::TYPE_NUM => array (0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, )
    );

    /** The enumerated values for this table */
    protected static $enumValueSets = array(
        TParametreFormPeer::RDV_SIMILAIRE => array(
            TParametreFormPeer::RDV_SIMILAIRE_0,
            TParametreFormPeer::RDV_SIMILAIRE_1,
        ),
        TParametreFormPeer::RESSOURCE_VISIBLE => array(
            TParametreFormPeer::RESSOURCE_VISIBLE_0,
            TParametreFormPeer::RESSOURCE_VISIBLE_1,
        ),
        TParametreFormPeer::RESSOURCE_OBLIGATOIRE => array(
            TParametreFormPeer::RESSOURCE_OBLIGATOIRE_0,
            TParametreFormPeer::RESSOURCE_OBLIGATOIRE_1,
        ),
        TParametreFormPeer::REFERENT_VISIBLE => array(
            TParametreFormPeer::REFERENT_VISIBLE_0,
            TParametreFormPeer::REFERENT_VISIBLE_1,
        ),
        TParametreFormPeer::TEXT_1_ACTIF => array(
            TParametreFormPeer::TEXT_1_ACTIF_0,
            TParametreFormPeer::TEXT_1_ACTIF_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_TEXT_1 => array(
            TParametreFormPeer::OBLIGATOIRE_TEXT_1_0,
            TParametreFormPeer::OBLIGATOIRE_TEXT_1_1,
        ),
        TParametreFormPeer::TEXT_2_ACTIF => array(
            TParametreFormPeer::TEXT_2_ACTIF_0,
            TParametreFormPeer::TEXT_2_ACTIF_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_TEXT_2 => array(
            TParametreFormPeer::OBLIGATOIRE_TEXT_2_0,
            TParametreFormPeer::OBLIGATOIRE_TEXT_2_1,
        ),
        TParametreFormPeer::TEXT_3_ACTIF => array(
            TParametreFormPeer::TEXT_3_ACTIF_0,
            TParametreFormPeer::TEXT_3_ACTIF_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_TEXT_3 => array(
            TParametreFormPeer::OBLIGATOIRE_TEXT_3_0,
            TParametreFormPeer::OBLIGATOIRE_TEXT_3_1,
        ),
        TParametreFormPeer::REF_1_ACTIF => array(
            TParametreFormPeer::REF_1_ACTIF_0,
            TParametreFormPeer::REF_1_ACTIF_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_REF_1 => array(
            TParametreFormPeer::OBLIGATOIRE_REF_1_0,
            TParametreFormPeer::OBLIGATOIRE_REF_1_1,
        ),
        TParametreFormPeer::REF_2_ACTIF => array(
            TParametreFormPeer::REF_2_ACTIF_0,
            TParametreFormPeer::REF_2_ACTIF_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_REF_2 => array(
            TParametreFormPeer::OBLIGATOIRE_REF_2_0,
            TParametreFormPeer::OBLIGATOIRE_REF_2_1,
        ),
        TParametreFormPeer::REF_3_ACTIF => array(
            TParametreFormPeer::REF_3_ACTIF_0,
            TParametreFormPeer::REF_3_ACTIF_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_REF_3 => array(
            TParametreFormPeer::OBLIGATOIRE_REF_3_0,
            TParametreFormPeer::OBLIGATOIRE_REF_3_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_NOM => array(
            TParametreFormPeer::OBLIGATOIRE_NOM_0,
            TParametreFormPeer::OBLIGATOIRE_NOM_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_PRENOM => array(
            TParametreFormPeer::OBLIGATOIRE_PRENOM_0,
            TParametreFormPeer::OBLIGATOIRE_PRENOM_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE => array(
            TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE_0,
            TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_EMAIL => array(
            TParametreFormPeer::OBLIGATOIRE_EMAIL_0,
            TParametreFormPeer::OBLIGATOIRE_EMAIL_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT => array(
            TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT_0,
            TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_TELEPHONE => array(
            TParametreFormPeer::OBLIGATOIRE_TELEPHONE_0,
            TParametreFormPeer::OBLIGATOIRE_TELEPHONE_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL => array(
            TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL_0,
            TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_ADRESSE => array(
            TParametreFormPeer::OBLIGATOIRE_ADRESSE_0,
            TParametreFormPeer::OBLIGATOIRE_ADRESSE_1,
        ),
        TParametreFormPeer::OBLIGATOIRE_FAX => array(
            TParametreFormPeer::OBLIGATOIRE_FAX_0,
            TParametreFormPeer::OBLIGATOIRE_FAX_1,
        ),
        TParametreFormPeer::VISIBLE_NOM => array(
            TParametreFormPeer::VISIBLE_NOM_0,
            TParametreFormPeer::VISIBLE_NOM_1,
        ),
        TParametreFormPeer::VISIBLE_PRENOM => array(
            TParametreFormPeer::VISIBLE_PRENOM_0,
            TParametreFormPeer::VISIBLE_PRENOM_1,
        ),
        TParametreFormPeer::VISIBLE_DATE_NAISSANCE => array(
            TParametreFormPeer::VISIBLE_DATE_NAISSANCE_0,
            TParametreFormPeer::VISIBLE_DATE_NAISSANCE_1,
        ),
        TParametreFormPeer::VISIBLE_EMAIL => array(
            TParametreFormPeer::VISIBLE_EMAIL_0,
            TParametreFormPeer::VISIBLE_EMAIL_1,
        ),
        TParametreFormPeer::VISIBLE_IDENTIFIANT => array(
            TParametreFormPeer::VISIBLE_IDENTIFIANT_0,
            TParametreFormPeer::VISIBLE_IDENTIFIANT_1,
        ),
        TParametreFormPeer::VISIBLE_TELEPHONE => array(
            TParametreFormPeer::VISIBLE_TELEPHONE_0,
            TParametreFormPeer::VISIBLE_TELEPHONE_1,
        ),
        TParametreFormPeer::VISIBLE_RAISON_SOCIAL => array(
            TParametreFormPeer::VISIBLE_RAISON_SOCIAL_0,
            TParametreFormPeer::VISIBLE_RAISON_SOCIAL_1,
        ),
        TParametreFormPeer::VISIBLE_ADRESSE => array(
            TParametreFormPeer::VISIBLE_ADRESSE_0,
            TParametreFormPeer::VISIBLE_ADRESSE_1,
        ),
        TParametreFormPeer::VISIBLE_FAX => array(
            TParametreFormPeer::VISIBLE_FAX_0,
            TParametreFormPeer::VISIBLE_FAX_1,
        ),
        TParametreFormPeer::TEXT_1_TYPE => array(
            TParametreFormPeer::TEXT_1_TYPE_TEXT,
            TParametreFormPeer::TEXT_1_TYPE_NUMERIC,
            TParametreFormPeer::TEXT_1_TYPE_LISTE,
            TParametreFormPeer::TEXT_1_TYPE_MULTICHOIX,
        ),
        TParametreFormPeer::TEXT_2_TYPE => array(
            TParametreFormPeer::TEXT_2_TYPE_TEXT,
            TParametreFormPeer::TEXT_2_TYPE_NUMERIC,
            TParametreFormPeer::TEXT_2_TYPE_LISTE,
            TParametreFormPeer::TEXT_2_TYPE_MULTICHOIX,
        ),
        TParametreFormPeer::TEXT_3_TYPE => array(
            TParametreFormPeer::TEXT_3_TYPE_TEXT,
            TParametreFormPeer::TEXT_3_TYPE_NUMERIC,
            TParametreFormPeer::TEXT_3_TYPE_LISTE,
            TParametreFormPeer::TEXT_3_TYPE_MULTICHOIX,
        ),
    );

    /**
     * Translates a fieldname to another type
     *
     * @param      string $name field name
     * @param      string $fromType One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                         BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @param      string $toType   One of the class type constants
     * @return string          translated name of the field.
     * @throws PropelException - if the specified name could not be found in the fieldname mappings.
     */
    public static function translateFieldName($name, $fromType, $toType)
    {
        $toNames = TParametreFormPeer::getFieldNames($toType);
        $key = isset(TParametreFormPeer::$fieldKeys[$fromType][$name]) ? TParametreFormPeer::$fieldKeys[$fromType][$name] : null;
        if ($key === null) {
            throw new PropelException("'$name' could not be found in the field names of type '$fromType'. These are: " . print_r(TParametreFormPeer::$fieldKeys[$fromType], true));
        }

        return $toNames[$key];
    }

    /**
     * Returns an array of field names.
     *
     * @param      string $type The type of fieldnames to return:
     *                      One of the class type constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME
     *                      BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM
     * @return array           A list of field names
     * @throws PropelException - if the type is not valid.
     */
    public static function getFieldNames($type = BasePeer::TYPE_PHPNAME)
    {
        if (!array_key_exists($type, TParametreFormPeer::$fieldNames)) {
            throw new PropelException('Method getFieldNames() expects the parameter $type to be one of the class constants BasePeer::TYPE_PHPNAME, BasePeer::TYPE_STUDLYPHPNAME, BasePeer::TYPE_COLNAME, BasePeer::TYPE_FIELDNAME, BasePeer::TYPE_NUM. ' . $type . ' was given.');
        }

        return TParametreFormPeer::$fieldNames[$type];
    }

    /**
     * Gets the list of values for all ENUM columns
     * @return array
     */
    public static function getValueSets()
    {
      return TParametreFormPeer::$enumValueSets;
    }

    /**
     * Gets the list of values for an ENUM column
     *
     * @param string $colname The ENUM column name.
     *
     * @return array list of possible values for the column
     */
    public static function getValueSet($colname)
    {
        $valueSets = TParametreFormPeer::getValueSets();

        if (!isset($valueSets[$colname])) {
            throw new PropelException(sprintf('Column "%s" has no ValueSet.', $colname));
        }

        return $valueSets[$colname];
    }

    /**
     * Gets the SQL value for the ENUM column value
     *
     * @param string $colname ENUM column name.
     * @param string $enumVal ENUM value.
     *
     * @return int            SQL value
     */
    public static function getSqlValueForEnum($colname, $enumVal)
    {
        $values = TParametreFormPeer::getValueSet($colname);
        if (!in_array($enumVal, $values)) {
            throw new PropelException(sprintf('Value "%s" is not accepted in this enumerated column', $colname));
        }
        return array_search($enumVal, $values);
    }

    /**
     * Convenience method which changes table.column to alias.column.
     *
     * Using this method you can maintain SQL abstraction while using column aliases.
     * <code>
     *		$c->addAlias("alias1", TablePeer::TABLE_NAME);
     *		$c->addJoin(TablePeer::alias("alias1", TablePeer::PRIMARY_KEY_COLUMN), TablePeer::PRIMARY_KEY_COLUMN);
     * </code>
     * @param      string $alias The alias for the current table.
     * @param      string $column The column name for current table. (i.e. TParametreFormPeer::COLUMN_NAME).
     * @return string
     */
    public static function alias($alias, $column)
    {
        return str_replace(TParametreFormPeer::TABLE_NAME.'.', $alias.'.', $column);
    }

    /**
     * Add all the columns needed to create a new object.
     *
     * Note: any columns that were marked with lazyLoad="true" in the
     * XML schema will not be added to the select list and only loaded
     * on demand.
     *
     * @param      Criteria $criteria object containing the columns to add.
     * @param      string   $alias    optional table alias
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function addSelectColumns(Criteria $criteria, $alias = null)
    {
        if (null === $alias) {
            $criteria->addSelectColumn(TParametreFormPeer::ID_PARAMETRE_FORM);
            $criteria->addSelectColumn(TParametreFormPeer::RDV_SIMILAIRE);
            $criteria->addSelectColumn(TParametreFormPeer::NB_JOUR_RDV_SIMILAIRE);
            $criteria->addSelectColumn(TParametreFormPeer::DELAI_MIN);
            $criteria->addSelectColumn(TParametreFormPeer::RESSOURCE_VISIBLE);
            $criteria->addSelectColumn(TParametreFormPeer::RESSOURCE_OBLIGATOIRE);
            $criteria->addSelectColumn(TParametreFormPeer::CODE_COMMENTAIRE);
            $criteria->addSelectColumn(TParametreFormPeer::REFERENT_VISIBLE);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_1_ACTIF);
            $criteria->addSelectColumn(TParametreFormPeer::CODE_LIBELLE_TEXT_1);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_TEXT_1);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_2_ACTIF);
            $criteria->addSelectColumn(TParametreFormPeer::CODE_LIBELLE_TEXT_2);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_TEXT_2);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_3_ACTIF);
            $criteria->addSelectColumn(TParametreFormPeer::CODE_LIBELLE_TEXT_3);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_TEXT_3);
            $criteria->addSelectColumn(TParametreFormPeer::REF_1_ACTIF);
            $criteria->addSelectColumn(TParametreFormPeer::ID_REF_1);
            $criteria->addSelectColumn(TParametreFormPeer::CODE_LIBELLE_REF_1);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_REF_1);
            $criteria->addSelectColumn(TParametreFormPeer::REF_2_ACTIF);
            $criteria->addSelectColumn(TParametreFormPeer::ID_REF_2);
            $criteria->addSelectColumn(TParametreFormPeer::CODE_LIBELLE_REF_2);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_REF_2);
            $criteria->addSelectColumn(TParametreFormPeer::REF_3_ACTIF);
            $criteria->addSelectColumn(TParametreFormPeer::ID_REF_3);
            $criteria->addSelectColumn(TParametreFormPeer::CODE_LIBELLE_REF_3);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_REF_3);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_NOM);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_PRENOM);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_DATE_NAISSANCE);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_EMAIL);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_IDENTIFIANT);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_TELEPHONE);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_RAISON_SOCIAL);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_ADRESSE);
            $criteria->addSelectColumn(TParametreFormPeer::OBLIGATOIRE_FAX);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_NOM);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_PRENOM);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_DATE_NAISSANCE);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_EMAIL);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_IDENTIFIANT);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_TELEPHONE);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_RAISON_SOCIAL);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_ADRESSE);
            $criteria->addSelectColumn(TParametreFormPeer::VISIBLE_FAX);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_1_TYPE);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_2_TYPE);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_3_TYPE);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_1_LISTE);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_2_LISTE);
            $criteria->addSelectColumn(TParametreFormPeer::TEXT_3_LISTE);
        } else {
            $criteria->addSelectColumn($alias . '.ID_PARAMETRE_FORM');
            $criteria->addSelectColumn($alias . '.RDV_SIMILAIRE');
            $criteria->addSelectColumn($alias . '.NB_JOUR_RDV_SIMILAIRE');
            $criteria->addSelectColumn($alias . '.DELAI_MIN');
            $criteria->addSelectColumn($alias . '.RESSOURCE_VISIBLE');
            $criteria->addSelectColumn($alias . '.RESSOURCE_OBLIGATOIRE');
            $criteria->addSelectColumn($alias . '.CODE_COMMENTAIRE');
            $criteria->addSelectColumn($alias . '.REFERENT_VISIBLE');
            $criteria->addSelectColumn($alias . '.TEXT_1_ACTIF');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_TEXT_1');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_TEXT_1');
            $criteria->addSelectColumn($alias . '.TEXT_2_ACTIF');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_TEXT_2');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_TEXT_2');
            $criteria->addSelectColumn($alias . '.TEXT_3_ACTIF');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_TEXT_3');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_TEXT_3');
            $criteria->addSelectColumn($alias . '.REF_1_ACTIF');
            $criteria->addSelectColumn($alias . '.ID_REF_1');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_REF_1');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_REF_1');
            $criteria->addSelectColumn($alias . '.REF_2_ACTIF');
            $criteria->addSelectColumn($alias . '.ID_REF_2');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_REF_2');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_REF_2');
            $criteria->addSelectColumn($alias . '.REF_3_ACTIF');
            $criteria->addSelectColumn($alias . '.ID_REF_3');
            $criteria->addSelectColumn($alias . '.CODE_LIBELLE_REF_3');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_REF_3');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_NOM');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_PRENOM');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_DATE_NAISSANCE');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_EMAIL');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_IDENTIFIANT');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_TELEPHONE');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_RAISON_SOCIAL');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_ADRESSE');
            $criteria->addSelectColumn($alias . '.OBLIGATOIRE_FAX');
            $criteria->addSelectColumn($alias . '.VISIBLE_NOM');
            $criteria->addSelectColumn($alias . '.VISIBLE_PRENOM');
            $criteria->addSelectColumn($alias . '.VISIBLE_DATE_NAISSANCE');
            $criteria->addSelectColumn($alias . '.VISIBLE_EMAIL');
            $criteria->addSelectColumn($alias . '.VISIBLE_IDENTIFIANT');
            $criteria->addSelectColumn($alias . '.VISIBLE_TELEPHONE');
            $criteria->addSelectColumn($alias . '.VISIBLE_RAISON_SOCIAL');
            $criteria->addSelectColumn($alias . '.VISIBLE_ADRESSE');
            $criteria->addSelectColumn($alias . '.VISIBLE_FAX');
            $criteria->addSelectColumn($alias . '.TEXT_1_TYPE');
            $criteria->addSelectColumn($alias . '.TEXT_2_TYPE');
            $criteria->addSelectColumn($alias . '.TEXT_3_TYPE');
            $criteria->addSelectColumn($alias . '.TEXT_1_LISTE');
            $criteria->addSelectColumn($alias . '.TEXT_2_LISTE');
            $criteria->addSelectColumn($alias . '.TEXT_3_LISTE');
        }
    }

    /**
     * Returns the number of rows matching criteria.
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @return int Number of matching rows.
     */
    public static function doCount(Criteria $criteria, $distinct = false, PropelPDO $con = null)
    {
        // we may modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME); // Set the correct dbName

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }
        // BasePeer returns a PDOStatement
        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }
    /**
     * Selects one object from the DB.
     *
     * @param      Criteria $criteria object used to create the SELECT statement.
     * @param      PropelPDO $con
     * @return                 TParametreForm
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectOne(Criteria $criteria, PropelPDO $con = null)
    {
        $critcopy = clone $criteria;
        $critcopy->setLimit(1);
        $objects = TParametreFormPeer::doSelect($critcopy, $con);
        if ($objects) {
            return $objects[0];
        }

        return null;
    }
    /**
     * Selects several row from the DB.
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con
     * @return array           Array of selected Objects
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelect(Criteria $criteria, PropelPDO $con = null)
    {
        return TParametreFormPeer::populateObjects(TParametreFormPeer::doSelectStmt($criteria, $con));
    }
    /**
     * Prepares the Criteria object and uses the parent doSelect() method to execute a PDOStatement.
     *
     * Use this method directly if you want to work with an executed statement directly (for example
     * to perform your own object hydration).
     *
     * @param      Criteria $criteria The Criteria object used to build the SELECT statement.
     * @param      PropelPDO $con The connection to use
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return PDOStatement The executed PDOStatement object.
     * @see        BasePeer::doSelect()
     */
    public static function doSelectStmt(Criteria $criteria, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        if (!$criteria->hasSelectClause()) {
            $criteria = clone $criteria;
            TParametreFormPeer::addSelectColumns($criteria);
        }

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        // BasePeer returns a PDOStatement
        return BasePeer::doSelect($criteria, $con);
    }
    /**
     * Adds an object to the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doSelect*()
     * methods in your stub classes -- you may need to explicitly add objects
     * to the cache in order to ensure that the same objects are always returned by doSelect*()
     * and retrieveByPK*() calls.
     *
     * @param      TParametreForm $obj A TParametreForm object.
     * @param      string $key (optional) key to use for instance map (for performance boost if key was already calculated externally).
     */
    public static function addInstanceToPool($obj, $key = null)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if ($key === null) {
                $key = (string) $obj->getIdParametreForm();
            } // if key === null
            TParametreFormPeer::$instances[$key] = $obj;
        }
    }

    /**
     * Removes an object from the instance pool.
     *
     * Propel keeps cached copies of objects in an instance pool when they are retrieved
     * from the database.  In some cases -- especially when you override doDelete
     * methods in your stub classes -- you may need to explicitly remove objects
     * from the cache in order to prevent returning objects that no longer exist.
     *
     * @param      mixed $value A TParametreForm object or a primary key value.
     *
     * @return void
     * @throws PropelException - if the value is invalid.
     */
    public static function removeInstanceFromPool($value)
    {
        if (Propel::isInstancePoolingEnabled() && $value !== null) {
            if (is_object($value) && $value instanceof TParametreForm) {
                $key = (string) $value->getIdParametreForm();
            } elseif (is_scalar($value)) {
                // assume we've been passed a primary key
                $key = (string) $value;
            } else {
                $e = new PropelException("Invalid value passed to removeInstanceFromPool().  Expected primary key or TParametreForm object; got " . (is_object($value) ? get_class($value) . ' object.' : var_export($value,true)));
                throw $e;
            }

            unset(TParametreFormPeer::$instances[$key]);
        }
    } // removeInstanceFromPool()

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      string $key The key (@see getPrimaryKeyHash()) for this instance.
     * @return   TParametreForm Found object or null if 1) no instance exists for specified key or 2) instance pooling has been disabled.
     * @see        getPrimaryKeyHash()
     */
    public static function getInstanceFromPool($key)
    {
        if (Propel::isInstancePoolingEnabled()) {
            if (isset(TParametreFormPeer::$instances[$key])) {
                return TParametreFormPeer::$instances[$key];
            }
        }

        return null; // just to be explicit
    }

    /**
     * Clear the instance pool.
     *
     * @return void
     */
    public static function clearInstancePool($and_clear_all_references = false)
    {
      if ($and_clear_all_references)
      {
        foreach (TParametreFormPeer::$instances as $instance)
        {
          $instance->clearAllReferences(true);
        }
      }
        TParametreFormPeer::$instances = array();
    }

    /**
     * Method to invalidate the instance pool of all tables related to T_PARAMETRE_FORM
     * by a foreign key with ON DELETE CASCADE
     */
    public static function clearRelatedInstancePool()
    {
    }

    /**
     * Retrieves a string version of the primary key from the DB resultset row that can be used to uniquely identify a row in this table.
     *
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, a serialize()d version of the primary key will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return string A string version of PK or null if the components of primary key in result array are all null.
     */
    public static function getPrimaryKeyHashFromRow($row, $startcol = 0)
    {
        // If the PK cannot be derived from the row, return null.
        if ($row[$startcol] === null) {
            return null;
        }

        return (string) $row[$startcol];
    }

    /**
     * Retrieves the primary key from the DB resultset row
     * For tables with a single-column primary key, that simple pkey value will be returned.  For tables with
     * a multi-column primary key, an array of the primary key columns will be returned.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @return mixed The primary key of the row
     */
    public static function getPrimaryKeyFromRow($row, $startcol = 0)
    {

        return (int) $row[$startcol];
    }

    /**
     * The returned array will contain objects of the default type or
     * objects that inherit from the default.
     *
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function populateObjects(PDOStatement $stmt)
    {
        $results = array();

        // set the class once to avoid overhead in the loop
        $cls = TParametreFormPeer::getOMClass();
        // populate the object(s)
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj = TParametreFormPeer::getInstanceFromPool($key))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj->hydrate($row, 0, true); // rehydrate
                $results[] = $obj;
            } else {
                $obj = new $cls();
                $obj->hydrate($row);
                $results[] = $obj;
                TParametreFormPeer::addInstanceToPool($obj, $key);
            } // if key exists
        }
        $stmt->closeCursor();

        return $results;
    }
    /**
     * Populates an object of the default type or an object that inherit from the default.
     *
     * @param      array $row PropelPDO resultset row.
     * @param      int $startcol The 0-based offset for reading from the resultset row.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     * @return array (TParametreForm object, last column rank)
     */
    public static function populateObject($row, $startcol = 0)
    {
        $key = TParametreFormPeer::getPrimaryKeyHashFromRow($row, $startcol);
        if (null !== ($obj = TParametreFormPeer::getInstanceFromPool($key))) {
            // We no longer rehydrate the object, since this can cause data loss.
            // See http://www.propelorm.org/ticket/509
            // $obj->hydrate($row, $startcol, true); // rehydrate
            $col = $startcol + TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        } else {
            $cls = TParametreFormPeer::OM_CLASS;
            $obj = new $cls();
            $col = $obj->hydrate($row, $startcol);
            TParametreFormPeer::addInstanceToPool($obj, $key);
        }

        return array($obj, $col);
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeCommentaire table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeCommentaire(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleRef1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleRef1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleRef2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleRef2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleRef3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleRef3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleText1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleText1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleText2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleText2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleText3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTTraductionRelatedByCodeLibelleText3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferentielRelatedByIdRef1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTReferentielRelatedByIdRef1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferentielRelatedByIdRef2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTReferentielRelatedByIdRef2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferentielRelatedByIdRef3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinTReferentielRelatedByIdRef3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeCommentaire(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeCommentaire($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleRef1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeLibelleRef1($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleRef2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeLibelleRef2($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleRef3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeLibelleRef3($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleText1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeLibelleText1($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleText2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeLibelleText2($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TTraduction objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTTraductionRelatedByCodeLibelleText3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TTraductionPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeLibelleText3($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TReferentiel objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTReferentielRelatedByIdRef1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TReferentielPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TReferentiel objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTReferentielRelatedByIdRef2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TReferentielPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with their TReferentiel objects.
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinTReferentielRelatedByIdRef3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol = TParametreFormPeer::NUM_HYDRATE_COLUMNS;
        TReferentielPeer::addSelectColumns($criteria);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {

                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if $obj1 already loaded

            $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol);
            if ($key2 !== null) {
                $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 already loaded

                // Add the $obj1 (TParametreForm) to $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row was not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining all related tables
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAll(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY won't ever affect the count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }

    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAll(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol10 = $startcol9 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol11 = $startcol10 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol12 = $startcol11 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

            // Add objects for joined TTraduction rows

            $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
            if ($key2 !== null) {
                $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                if (!$obj2) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if obj2 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeCommentaire($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
            if ($key3 !== null) {
                $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                if (!$obj3) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if obj3 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TTraduction)
                $obj3->addTParametreFormRelatedByCodeLibelleRef1($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key4 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol4);
            if ($key4 !== null) {
                $obj4 = TTraductionPeer::getInstanceFromPool($key4);
                if (!$obj4) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTraductionPeer::addInstanceToPool($obj4, $key4);
                } // if obj4 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TTraduction)
                $obj4->addTParametreFormRelatedByCodeLibelleRef2($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key5 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol5);
            if ($key5 !== null) {
                $obj5 = TTraductionPeer::getInstanceFromPool($key5);
                if (!$obj5) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTraductionPeer::addInstanceToPool($obj5, $key5);
                } // if obj5 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj5 (TTraduction)
                $obj5->addTParametreFormRelatedByCodeLibelleRef3($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key6 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol6);
            if ($key6 !== null) {
                $obj6 = TTraductionPeer::getInstanceFromPool($key6);
                if (!$obj6) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTraductionPeer::addInstanceToPool($obj6, $key6);
                } // if obj6 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj6 (TTraduction)
                $obj6->addTParametreFormRelatedByCodeLibelleText1($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key7 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol7);
            if ($key7 !== null) {
                $obj7 = TTraductionPeer::getInstanceFromPool($key7);
                if (!$obj7) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTraductionPeer::addInstanceToPool($obj7, $key7);
                } // if obj7 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj7 (TTraduction)
                $obj7->addTParametreFormRelatedByCodeLibelleText2($obj1);
            } // if joined row not null

            // Add objects for joined TTraduction rows

            $key8 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol8);
            if ($key8 !== null) {
                $obj8 = TTraductionPeer::getInstanceFromPool($key8);
                if (!$obj8) {

                    $cls = TTraductionPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TTraductionPeer::addInstanceToPool($obj8, $key8);
                } // if obj8 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj8 (TTraduction)
                $obj8->addTParametreFormRelatedByCodeLibelleText3($obj1);
            } // if joined row not null

            // Add objects for joined TReferentiel rows

            $key9 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol9);
            if ($key9 !== null) {
                $obj9 = TReferentielPeer::getInstanceFromPool($key9);
                if (!$obj9) {

                    $cls = TReferentielPeer::getOMClass();

                    $obj9 = new $cls();
                    $obj9->hydrate($row, $startcol9);
                    TReferentielPeer::addInstanceToPool($obj9, $key9);
                } // if obj9 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj9 (TReferentiel)
                $obj9->addTParametreFormRelatedByIdRef1($obj1);
            } // if joined row not null

            // Add objects for joined TReferentiel rows

            $key10 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol10);
            if ($key10 !== null) {
                $obj10 = TReferentielPeer::getInstanceFromPool($key10);
                if (!$obj10) {

                    $cls = TReferentielPeer::getOMClass();

                    $obj10 = new $cls();
                    $obj10->hydrate($row, $startcol10);
                    TReferentielPeer::addInstanceToPool($obj10, $key10);
                } // if obj10 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj10 (TReferentiel)
                $obj10->addTParametreFormRelatedByIdRef2($obj1);
            } // if joined row not null

            // Add objects for joined TReferentiel rows

            $key11 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol11);
            if ($key11 !== null) {
                $obj11 = TReferentielPeer::getInstanceFromPool($key11);
                if (!$obj11) {

                    $cls = TReferentielPeer::getOMClass();

                    $obj11 = new $cls();
                    $obj11->hydrate($row, $startcol11);
                    TReferentielPeer::addInstanceToPool($obj11, $key11);
                } // if obj11 loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj11 (TReferentiel)
                $obj11->addTParametreFormRelatedByIdRef3($obj1);
            } // if joined row not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeCommentaire table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeCommentaire(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleRef1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleRef1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleRef2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleRef2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleRef3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleRef3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleText1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleText1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleText2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleText2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TTraductionRelatedByCodeLibelleText3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTTraductionRelatedByCodeLibelleText3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferentielRelatedByIdRef1 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTReferentielRelatedByIdRef1(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferentielRelatedByIdRef2 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTReferentielRelatedByIdRef2(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Returns the number of rows matching criteria, joining the related TReferentielRelatedByIdRef3 table
     *
     * @param      Criteria $criteria
     * @param      boolean $distinct Whether to select only distinct columns; deprecated: use Criteria->setDistinct() instead.
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return int Number of matching rows.
     */
    public static function doCountJoinAllExceptTReferentielRelatedByIdRef3(Criteria $criteria, $distinct = false, PropelPDO $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        // we're going to modify criteria, so copy it first
        $criteria = clone $criteria;

        // We need to set the primary table name, since in the case that there are no WHERE columns
        // it will be impossible for the BasePeer::createSelectSql() method to determine which
        // tables go into the FROM clause.
        $criteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);

        if ($distinct && !in_array(Criteria::DISTINCT, $criteria->getSelectModifiers())) {
            $criteria->setDistinct();
        }

        if (!$criteria->hasSelectClause()) {
            TParametreFormPeer::addSelectColumns($criteria);
        }

        $criteria->clearOrderByColumns(); // ORDER BY should not affect count

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $stmt = BasePeer::doCount($criteria, $con);

        if ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $count = (int) $row[0];
        } else {
            $count = 0; // no rows returned; we infer that means 0 matches.
        }
        $stmt->closeCursor();

        return $count;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TTraductionRelatedByCodeCommentaire.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeCommentaire(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TReferentiel rows

                $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key3 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TReferentiel)
                $obj3->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key4 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TReferentielPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TReferentiel)
                $obj4->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleRef1.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleRef1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TReferentiel rows

                $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key3 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TReferentiel)
                $obj3->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key4 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TReferentielPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TReferentiel)
                $obj4->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleRef2.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleRef2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TReferentiel rows

                $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key3 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TReferentiel)
                $obj3->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key4 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TReferentielPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TReferentiel)
                $obj4->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleRef3.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleRef3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TReferentiel rows

                $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key3 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TReferentiel)
                $obj3->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key4 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TReferentielPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TReferentiel)
                $obj4->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleText1.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleText1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TReferentiel rows

                $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key3 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TReferentiel)
                $obj3->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key4 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TReferentielPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TReferentiel)
                $obj4->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleText2.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleText2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TReferentiel rows

                $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key3 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TReferentiel)
                $obj3->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key4 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TReferentielPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TReferentiel)
                $obj4->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TTraductionRelatedByCodeLibelleText3.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTTraductionRelatedByCodeLibelleText3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        TReferentielPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TReferentielPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::ID_REF_1, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_2, TReferentielPeer::ID_REFERENTIEL, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::ID_REF_3, TReferentielPeer::ID_REFERENTIEL, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TReferentiel rows

                $key2 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TReferentielPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TReferentielPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TReferentiel)
                $obj2->addTParametreFormRelatedByIdRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key3 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TReferentielPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TReferentielPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TReferentiel)
                $obj3->addTParametreFormRelatedByIdRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TReferentiel rows

                $key4 = TReferentielPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TReferentielPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TReferentielPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TReferentielPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TReferentiel)
                $obj4->addTParametreFormRelatedByIdRef3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TReferentielRelatedByIdRef1.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTReferentielRelatedByIdRef1(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TTraduction)
                $obj3->addTParametreFormRelatedByCodeLibelleRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key4 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TTraductionPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTraductionPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TTraduction)
                $obj4->addTParametreFormRelatedByCodeLibelleRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key5 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TTraductionPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTraductionPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj5 (TTraduction)
                $obj5->addTParametreFormRelatedByCodeLibelleRef3($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key6 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTraductionPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTraductionPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj6 (TTraduction)
                $obj6->addTParametreFormRelatedByCodeLibelleText1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key7 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTraductionPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTraductionPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj7 (TTraduction)
                $obj7->addTParametreFormRelatedByCodeLibelleText2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key8 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TTraductionPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TTraductionPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj8 (TTraduction)
                $obj8->addTParametreFormRelatedByCodeLibelleText3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TReferentielRelatedByIdRef2.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTReferentielRelatedByIdRef2(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TTraduction)
                $obj3->addTParametreFormRelatedByCodeLibelleRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key4 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TTraductionPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTraductionPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TTraduction)
                $obj4->addTParametreFormRelatedByCodeLibelleRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key5 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TTraductionPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTraductionPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj5 (TTraduction)
                $obj5->addTParametreFormRelatedByCodeLibelleRef3($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key6 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTraductionPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTraductionPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj6 (TTraduction)
                $obj6->addTParametreFormRelatedByCodeLibelleText1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key7 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTraductionPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTraductionPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj7 (TTraduction)
                $obj7->addTParametreFormRelatedByCodeLibelleText2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key8 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TTraductionPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TTraductionPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj8 (TTraduction)
                $obj8->addTParametreFormRelatedByCodeLibelleText3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }


    /**
     * Selects a collection of TParametreForm objects pre-filled with all related objects except TReferentielRelatedByIdRef3.
     *
     * @param      Criteria  $criteria
     * @param      PropelPDO $con
     * @param      String    $join_behavior the type of joins to use, defaults to Criteria::LEFT_JOIN
     * @return array           Array of TParametreForm objects.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doSelectJoinAllExceptTReferentielRelatedByIdRef3(Criteria $criteria, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $criteria = clone $criteria;

        // Set the correct dbName if it has not been overridden
        // $criteria->getDbName() will return the same object if not set to another value
        // so == check is okay and faster
        if ($criteria->getDbName() == Propel::getDefaultDB()) {
            $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);
        }

        TParametreFormPeer::addSelectColumns($criteria);
        $startcol2 = TParametreFormPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol3 = $startcol2 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol4 = $startcol3 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol5 = $startcol4 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol6 = $startcol5 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol7 = $startcol6 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol8 = $startcol7 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        TTraductionPeer::addSelectColumns($criteria);
        $startcol9 = $startcol8 + TTraductionPeer::NUM_HYDRATE_COLUMNS;

        $criteria->addJoin(TParametreFormPeer::CODE_COMMENTAIRE, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_REF_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_1, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_2, TTraductionPeer::ID_TRADUCTION, $join_behavior);

        $criteria->addJoin(TParametreFormPeer::CODE_LIBELLE_TEXT_3, TTraductionPeer::ID_TRADUCTION, $join_behavior);


        $stmt = BasePeer::doSelect($criteria, $con);
        $results = array();

        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            $key1 = TParametreFormPeer::getPrimaryKeyHashFromRow($row, 0);
            if (null !== ($obj1 = TParametreFormPeer::getInstanceFromPool($key1))) {
                // We no longer rehydrate the object, since this can cause data loss.
                // See http://www.propelorm.org/ticket/509
                // $obj1->hydrate($row, 0, true); // rehydrate
            } else {
                $cls = TParametreFormPeer::getOMClass();

                $obj1 = new $cls();
                $obj1->hydrate($row);
                TParametreFormPeer::addInstanceToPool($obj1, $key1);
            } // if obj1 already loaded

                // Add objects for joined TTraduction rows

                $key2 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol2);
                if ($key2 !== null) {
                    $obj2 = TTraductionPeer::getInstanceFromPool($key2);
                    if (!$obj2) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj2 = new $cls();
                    $obj2->hydrate($row, $startcol2);
                    TTraductionPeer::addInstanceToPool($obj2, $key2);
                } // if $obj2 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj2 (TTraduction)
                $obj2->addTParametreFormRelatedByCodeCommentaire($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key3 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol3);
                if ($key3 !== null) {
                    $obj3 = TTraductionPeer::getInstanceFromPool($key3);
                    if (!$obj3) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj3 = new $cls();
                    $obj3->hydrate($row, $startcol3);
                    TTraductionPeer::addInstanceToPool($obj3, $key3);
                } // if $obj3 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj3 (TTraduction)
                $obj3->addTParametreFormRelatedByCodeLibelleRef1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key4 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol4);
                if ($key4 !== null) {
                    $obj4 = TTraductionPeer::getInstanceFromPool($key4);
                    if (!$obj4) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj4 = new $cls();
                    $obj4->hydrate($row, $startcol4);
                    TTraductionPeer::addInstanceToPool($obj4, $key4);
                } // if $obj4 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj4 (TTraduction)
                $obj4->addTParametreFormRelatedByCodeLibelleRef2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key5 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol5);
                if ($key5 !== null) {
                    $obj5 = TTraductionPeer::getInstanceFromPool($key5);
                    if (!$obj5) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj5 = new $cls();
                    $obj5->hydrate($row, $startcol5);
                    TTraductionPeer::addInstanceToPool($obj5, $key5);
                } // if $obj5 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj5 (TTraduction)
                $obj5->addTParametreFormRelatedByCodeLibelleRef3($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key6 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol6);
                if ($key6 !== null) {
                    $obj6 = TTraductionPeer::getInstanceFromPool($key6);
                    if (!$obj6) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj6 = new $cls();
                    $obj6->hydrate($row, $startcol6);
                    TTraductionPeer::addInstanceToPool($obj6, $key6);
                } // if $obj6 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj6 (TTraduction)
                $obj6->addTParametreFormRelatedByCodeLibelleText1($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key7 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol7);
                if ($key7 !== null) {
                    $obj7 = TTraductionPeer::getInstanceFromPool($key7);
                    if (!$obj7) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj7 = new $cls();
                    $obj7->hydrate($row, $startcol7);
                    TTraductionPeer::addInstanceToPool($obj7, $key7);
                } // if $obj7 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj7 (TTraduction)
                $obj7->addTParametreFormRelatedByCodeLibelleText2($obj1);

            } // if joined row is not null

                // Add objects for joined TTraduction rows

                $key8 = TTraductionPeer::getPrimaryKeyHashFromRow($row, $startcol8);
                if ($key8 !== null) {
                    $obj8 = TTraductionPeer::getInstanceFromPool($key8);
                    if (!$obj8) {

                        $cls = TTraductionPeer::getOMClass();

                    $obj8 = new $cls();
                    $obj8->hydrate($row, $startcol8);
                    TTraductionPeer::addInstanceToPool($obj8, $key8);
                } // if $obj8 already loaded

                // Add the $obj1 (TParametreForm) to the collection in $obj8 (TTraduction)
                $obj8->addTParametreFormRelatedByCodeLibelleText3($obj1);

            } // if joined row is not null

            $results[] = $obj1;
        }
        $stmt->closeCursor();

        return $results;
    }

    /**
     * Returns the TableMap related to this peer.
     * This method is not needed for general use but a specific application could have a need.
     * @return TableMap
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function getTableMap()
    {
        return Propel::getDatabaseMap(TParametreFormPeer::DATABASE_NAME)->getTable(TParametreFormPeer::TABLE_NAME);
    }

    /**
     * Add a TableMap instance to the database for this peer class.
     */
    public static function buildTableMap()
    {
      $dbMap = Propel::getDatabaseMap(BaseTParametreFormPeer::DATABASE_NAME);
      if (!$dbMap->hasTable(BaseTParametreFormPeer::TABLE_NAME)) {
        $dbMap->addTableObject(new TParametreFormTableMap());
      }
    }

    /**
     * The class that the Peer will make instances of.
     *
     *
     * @return string ClassName
     */
    public static function getOMClass($row = 0, $colnum = 0)
    {
        return TParametreFormPeer::OM_CLASS;
    }

    /**
     * Performs an INSERT on the database, given a TParametreForm or Criteria object.
     *
     * @param      mixed $values Criteria or TParametreForm object containing data that is used to create the INSERT statement.
     * @param      PropelPDO $con the PropelPDO connection to use
     * @return mixed           The new primary key.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doInsert($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity
        } else {
            $criteria = $values->buildCriteria(); // build Criteria from TParametreForm object
        }

        if ($criteria->containsKey(TParametreFormPeer::ID_PARAMETRE_FORM) && $criteria->keyContainsValue(TParametreFormPeer::ID_PARAMETRE_FORM) ) {
            throw new PropelException('Cannot insert a value for auto-increment primary key ('.TParametreFormPeer::ID_PARAMETRE_FORM.')');
        }


        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        try {
            // use transaction because $criteria could contain info
            // for more than one table (I guess, conceivably)
            $con->beginTransaction();
            $pk = BasePeer::doInsert($criteria, $con);
            $con->commit();
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }

        return $pk;
    }

    /**
     * Performs an UPDATE on the database, given a TParametreForm or Criteria object.
     *
     * @param      mixed $values Criteria or TParametreForm object containing data that is used to create the UPDATE statement.
     * @param      PropelPDO $con The connection to use (specify PropelPDO connection object to exert more control over transactions).
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function doUpdate($values, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $selectCriteria = new Criteria(TParametreFormPeer::DATABASE_NAME);

        if ($values instanceof Criteria) {
            $criteria = clone $values; // rename for clarity

            $comparison = $criteria->getComparison(TParametreFormPeer::ID_PARAMETRE_FORM);
            $value = $criteria->remove(TParametreFormPeer::ID_PARAMETRE_FORM);
            if ($value) {
                $selectCriteria->add(TParametreFormPeer::ID_PARAMETRE_FORM, $value, $comparison);
            } else {
                $selectCriteria->setPrimaryTableName(TParametreFormPeer::TABLE_NAME);
            }

        } else { // $values is TParametreForm object
            $criteria = $values->buildCriteria(); // gets full criteria
            $selectCriteria = $values->buildPkeyCriteria(); // gets criteria w/ primary key(s)
        }

        // set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        return BasePeer::doUpdate($selectCriteria, $criteria, $con);
    }

    /**
     * Deletes all rows from the T_PARAMETRE_FORM table.
     *
     * @param      PropelPDO $con the connection to use
     * @return int             The number of affected rows (if supported by underlying database driver).
     * @throws PropelException
     */
    public static function doDeleteAll(PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }
        $affectedRows = 0; // initialize var to track total num of affected rows
        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();
            $affectedRows += BasePeer::doDeleteAll(TParametreFormPeer::TABLE_NAME, $con, TParametreFormPeer::DATABASE_NAME);
            // Because this db requires some delete cascade/set null emulation, we have to
            // clear the cached instance *after* the emulation has happened (since
            // instances get re-added by the select statement contained therein).
            TParametreFormPeer::clearInstancePool();
            TParametreFormPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs a DELETE on the database, given a TParametreForm or Criteria object OR a primary key value.
     *
     * @param      mixed $values Criteria or TParametreForm object or primary key or array of primary keys
     *              which is used to create the DELETE statement
     * @param      PropelPDO $con the connection to use
     * @return int The number of affected rows (if supported by underlying database driver).  This includes CASCADE-related rows
     *				if supported by native driver or if emulated using Propel.
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
     public static function doDelete($values, PropelPDO $con = null)
     {
        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        if ($values instanceof Criteria) {
            // invalidate the cache for all objects of this type, since we have no
            // way of knowing (without running a query) what objects should be invalidated
            // from the cache based on this Criteria.
            TParametreFormPeer::clearInstancePool();
            // rename for clarity
            $criteria = clone $values;
        } elseif ($values instanceof TParametreForm) { // it's a model object
            // invalidate the cache for this single object
            TParametreFormPeer::removeInstanceFromPool($values);
            // create criteria based on pk values
            $criteria = $values->buildPkeyCriteria();
        } else { // it's a primary key, or an array of pks
            $criteria = new Criteria(TParametreFormPeer::DATABASE_NAME);
            $criteria->add(TParametreFormPeer::ID_PARAMETRE_FORM, (array) $values, Criteria::IN);
            // invalidate the cache for this object(s)
            foreach ((array) $values as $singleval) {
                TParametreFormPeer::removeInstanceFromPool($singleval);
            }
        }

        // Set the correct dbName
        $criteria->setDbName(TParametreFormPeer::DATABASE_NAME);

        $affectedRows = 0; // initialize var to track total num of affected rows

        try {
            // use transaction because $criteria could contain info
            // for more than one table or we could emulating ON DELETE CASCADE, etc.
            $con->beginTransaction();

            $affectedRows += BasePeer::doDelete($criteria, $con);
            TParametreFormPeer::clearRelatedInstancePool();
            $con->commit();

            return $affectedRows;
        } catch (PropelException $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Validates all modified columns of given TParametreForm object.
     * If parameter $columns is either a single column name or an array of column names
     * than only those columns are validated.
     *
     * NOTICE: This does not apply to primary or foreign keys for now.
     *
     * @param      TParametreForm $obj The object to validate.
     * @param      mixed $cols Column name or array of column names.
     *
     * @return mixed TRUE if all columns are valid or the error message of the first invalid column.
     */
    public static function doValidate($obj, $cols = null)
    {
        $columns = array();

        if ($cols) {
            $dbMap = Propel::getDatabaseMap(TParametreFormPeer::DATABASE_NAME);
            $tableMap = $dbMap->getTable(TParametreFormPeer::TABLE_NAME);

            if (! is_array($cols)) {
                $cols = array($cols);
            }

            foreach ($cols as $colName) {
                if ($tableMap->hasColumn($colName)) {
                    $get = 'get' . $tableMap->getColumn($colName)->getPhpName();
                    $columns[$colName] = $obj->$get();
                }
            }
        } else {

        }

        return BasePeer::doValidate(TParametreFormPeer::DATABASE_NAME, TParametreFormPeer::TABLE_NAME, $columns);
    }

    /**
     * Retrieve a single object by pkey.
     *
     * @param      int $pk the primary key.
     * @param      PropelPDO $con the connection to use
     * @return TParametreForm
     */
    public static function retrieveByPK($pk, PropelPDO $con = null)
    {

        if (null !== ($obj = TParametreFormPeer::getInstanceFromPool((string) $pk))) {
            return $obj;
        }

        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $criteria = new Criteria(TParametreFormPeer::DATABASE_NAME);
        $criteria->add(TParametreFormPeer::ID_PARAMETRE_FORM, $pk);

        $v = TParametreFormPeer::doSelect($criteria, $con);

        return !empty($v) > 0 ? $v[0] : null;
    }

    /**
     * Retrieve multiple objects by pkey.
     *
     * @param      array $pks List of primary keys
     * @param      PropelPDO $con the connection to use
     * @return TParametreForm[]
     * @throws PropelException Any exceptions caught during processing will be
     *		 rethrown wrapped into a PropelException.
     */
    public static function retrieveByPKs($pks, PropelPDO $con = null)
    {
        if ($con === null) {
            $con = Propel::getConnection(TParametreFormPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        $objs = null;
        if (empty($pks)) {
            $objs = array();
        } else {
            $criteria = new Criteria(TParametreFormPeer::DATABASE_NAME);
            $criteria->add(TParametreFormPeer::ID_PARAMETRE_FORM, $pks, Criteria::IN);
            $objs = TParametreFormPeer::doSelect($criteria, $con);
        }

        return $objs;
    }

} // BaseTParametreFormPeer

// This is the static code needed to register the TableMap for this table with the main Propel class.
//
BaseTParametreFormPeer::buildTableMap();

