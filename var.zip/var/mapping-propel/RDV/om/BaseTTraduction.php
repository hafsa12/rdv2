<?php


/**
 * Base class that represents a row from the 'T_TRADUCTION' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTTraduction extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TTraductionPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TTraductionPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_traduction field.
     * @var        int
     */
    protected $id_traduction;

    /**
     * @var        PropelObjectCollection|TAgent[] Collection to store aggregation of TAgent objects.
     */
    protected $collTAgentsRelatedByCodeNomUtilisateur;
    protected $collTAgentsRelatedByCodeNomUtilisateurPartial;

    /**
     * @var        PropelObjectCollection|TAgent[] Collection to store aggregation of TAgent objects.
     */
    protected $collTAgentsRelatedByCodePrenomUtilisateur;
    protected $collTAgentsRelatedByCodePrenomUtilisateurPartial;

    /**
     * @var        PropelObjectCollection|TAgent[] Collection to store aggregation of TAgent objects.
     */
    protected $collTAgentsRelatedByCodeUtilisateur;
    protected $collTAgentsRelatedByCodeUtilisateurPartial;

    /**
     * @var        PropelObjectCollection|TChampsSupp[] Collection to store aggregation of TChampsSupp objects.
     */
    protected $collTChampsSupps;
    protected $collTChampsSuppsPartial;

    /**
     * @var        PropelObjectCollection|TEntite[] Collection to store aggregation of TEntite objects.
     */
    protected $collTEntites;
    protected $collTEntitesPartial;

    /**
     * @var        PropelObjectCollection|TEtablissement[] Collection to store aggregation of TEtablissement objects.
     */
    protected $collTEtablissementsRelatedByCodeAdresseEtablissement;
    protected $collTEtablissementsRelatedByCodeAdresseEtablissementPartial;

    /**
     * @var        PropelObjectCollection|TEtablissement[] Collection to store aggregation of TEtablissement objects.
     */
    protected $collTEtablissementsRelatedByCodeDenominationEtablissement;
    protected $collTEtablissementsRelatedByCodeDenominationEtablissementPartial;

    /**
     * @var        PropelObjectCollection|TEtablissement[] Collection to store aggregation of TEtablissement objects.
     */
    protected $collTEtablissementsRelatedByCodeDescriptionEtablissement;
    protected $collTEtablissementsRelatedByCodeDescriptionEtablissementPartial;

    /**
     * @var        PropelObjectCollection|TGroupe[] Collection to store aggregation of TGroupe objects.
     */
    protected $collTGroupes;
    protected $collTGroupesPartial;

    /**
     * @var        PropelObjectCollection|TJourFerie[] Collection to store aggregation of TJourFerie objects.
     */
    protected $collTJourFeries;
    protected $collTJourFeriesPartial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeAdresseOrganisation;
    protected $collTOrganisationsRelatedByCodeAdresseOrganisationPartial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeDenominationOrganisation;
    protected $collTOrganisationsRelatedByCodeDenominationOrganisationPartial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeDescriptionOrganisation;
    protected $collTOrganisationsRelatedByCodeDescriptionOrganisationPartial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeLibelleLien1;
    protected $collTOrganisationsRelatedByCodeLibelleLien1Partial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeLibelleLien2;
    protected $collTOrganisationsRelatedByCodeLibelleLien2Partial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeLibelleLien3;
    protected $collTOrganisationsRelatedByCodeLibelleLien3Partial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeMessageBienvenue;
    protected $collTOrganisationsRelatedByCodeMessageBienvenuePartial;

    /**
     * @var        PropelObjectCollection|TOrganisation[] Collection to store aggregation of TOrganisation objects.
     */
    protected $collTOrganisationsRelatedByCodeTitreBienvenue;
    protected $collTOrganisationsRelatedByCodeTitreBienvenuePartial;

    /**
     * @var        PropelObjectCollection|TParametragePrestation[] Collection to store aggregation of TParametragePrestation objects.
     */
    protected $collTParametragePrestationsRelatedByCodeCommentaire;
    protected $collTParametragePrestationsRelatedByCodeCommentairePartial;

    /**
     * @var        PropelObjectCollection|TParametragePrestation[] Collection to store aggregation of TParametragePrestation objects.
     */
    protected $collTParametragePrestationsRelatedByCodeAide;
    protected $collTParametragePrestationsRelatedByCodeAidePartial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByCodeCommentaire;
    protected $collTParametreFormsRelatedByCodeCommentairePartial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByCodeLibelleRef1;
    protected $collTParametreFormsRelatedByCodeLibelleRef1Partial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByCodeLibelleRef2;
    protected $collTParametreFormsRelatedByCodeLibelleRef2Partial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByCodeLibelleRef3;
    protected $collTParametreFormsRelatedByCodeLibelleRef3Partial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByCodeLibelleText1;
    protected $collTParametreFormsRelatedByCodeLibelleText1Partial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByCodeLibelleText2;
    protected $collTParametreFormsRelatedByCodeLibelleText2Partial;

    /**
     * @var        PropelObjectCollection|TParametreForm[] Collection to store aggregation of TParametreForm objects.
     */
    protected $collTParametreFormsRelatedByCodeLibelleText3;
    protected $collTParametreFormsRelatedByCodeLibelleText3Partial;

    /**
     * @var        PropelObjectCollection|TPieceParamPresta[] Collection to store aggregation of TPieceParamPresta objects.
     */
    protected $collTPieceParamPrestas;
    protected $collTPieceParamPrestasPartial;

    /**
     * @var        PropelObjectCollection|TPiecePrestation[] Collection to store aggregation of TPiecePrestation objects.
     */
    protected $collTPiecePrestations;
    protected $collTPiecePrestationsPartial;

    /**
     * @var        PropelObjectCollection|TPrestation[] Collection to store aggregation of TPrestation objects.
     */
    protected $collTPrestationsRelatedByCodeCommentaire;
    protected $collTPrestationsRelatedByCodeCommentairePartial;

    /**
     * @var        PropelObjectCollection|TPrestation[] Collection to store aggregation of TPrestation objects.
     */
    protected $collTPrestationsRelatedByCodeLibellePrestation;
    protected $collTPrestationsRelatedByCodeLibellePrestationPartial;

    /**
     * @var        PropelObjectCollection|TProfil[] Collection to store aggregation of TProfil objects.
     */
    protected $collTProfils;
    protected $collTProfilsPartial;

    /**
     * @var        PropelObjectCollection|TReferent[] Collection to store aggregation of TReferent objects.
     */
    protected $collTReferentsRelatedByCodeNomReferent;
    protected $collTReferentsRelatedByCodeNomReferentPartial;

    /**
     * @var        PropelObjectCollection|TReferent[] Collection to store aggregation of TReferent objects.
     */
    protected $collTReferentsRelatedByCodePrenomReferent;
    protected $collTReferentsRelatedByCodePrenomReferentPartial;

    /**
     * @var        PropelObjectCollection|TReferentiel[] Collection to store aggregation of TReferentiel objects.
     */
    protected $collTReferentiels;
    protected $collTReferentielsPartial;

    /**
     * @var        PropelObjectCollection|TRefPrestation[] Collection to store aggregation of TRefPrestation objects.
     */
    protected $collTRefPrestationsRelatedByCodeAide;
    protected $collTRefPrestationsRelatedByCodeAidePartial;

    /**
     * @var        PropelObjectCollection|TRefPrestation[] Collection to store aggregation of TRefPrestation objects.
     */
    protected $collTRefPrestationsRelatedByCodeLibelle;
    protected $collTRefPrestationsRelatedByCodeLibellePartial;

    /**
     * @var        PropelObjectCollection|TRefTypePrestation[] Collection to store aggregation of TRefTypePrestation objects.
     */
    protected $collTRefTypePrestations;
    protected $collTRefTypePrestationsPartial;

    /**
     * @var        PropelObjectCollection|TTraductionLibelle[] Collection to store aggregation of TTraductionLibelle objects.
     */
    protected $collTTraductionLibelles;
    protected $collTTraductionLibellesPartial;

    /**
     * @var        PropelObjectCollection|TTypeEtab[] Collection to store aggregation of TTypeEtab objects.
     */
    protected $collTTypeEtabsRelatedByCodeLibelle;
    protected $collTTypeEtabsRelatedByCodeLibellePartial;

    /**
     * @var        PropelObjectCollection|TTypeEtab[] Collection to store aggregation of TTypeEtab objects.
     */
    protected $collTTypeEtabsRelatedByCodeLibelleEtab;
    protected $collTTypeEtabsRelatedByCodeLibelleEtabPartial;

    /**
     * @var        PropelObjectCollection|TTypePrestation[] Collection to store aggregation of TTypePrestation objects.
     */
    protected $collTTypePrestations;
    protected $collTTypePrestationsPartial;

    /**
     * @var        PropelObjectCollection|TTypeProfil[] Collection to store aggregation of TTypeProfil objects.
     */
    protected $collTTypeProfils;
    protected $collTTypeProfilsPartial;

    /**
     * @var        PropelObjectCollection|TValeurReferentiel[] Collection to store aggregation of TValeurReferentiel objects.
     */
    protected $collTValeurReferentiels;
    protected $collTValeurReferentielsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentsRelatedByCodeUtilisateurScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tChampsSuppsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tEntitesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tGroupesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tJourFeriesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametragePrestationsRelatedByCodeAideScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByCodeCommentaireScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPieceParamPrestasScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPiecePrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPrestationsRelatedByCodeCommentaireScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tProfilsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tReferentsRelatedByCodeNomReferentScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tReferentsRelatedByCodePrenomReferentScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tReferentielsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRefPrestationsRelatedByCodeAideScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRefPrestationsRelatedByCodeLibelleScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tRefTypePrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tTraductionLibellesScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tTypeEtabsRelatedByCodeLibelleScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tTypePrestationsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tTypeProfilsScheduledForDeletion = null;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tValeurReferentielsScheduledForDeletion = null;

    /**
     * Get the [id_traduction] column value.
     *
     * @return int
     */
    public function getIdTraduction()
    {
        return $this->id_traduction;
    }

    /**
     * Set the value of [id_traduction] column.
     *
     * @param int $v new value
     * @return TTraduction The current object (for fluent API support)
     */
    public function setIdTraduction($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_traduction !== $v) {
            $this->id_traduction = $v;
            $this->modifiedColumns[] = TTraductionPeer::ID_TRADUCTION;
        }


        return $this;
    } // setIdTraduction()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_traduction = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 1; // 1 = TTraductionPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TTraduction object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TTraductionPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TTraductionPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->collTAgentsRelatedByCodeNomUtilisateur = null;

            $this->collTAgentsRelatedByCodePrenomUtilisateur = null;

            $this->collTAgentsRelatedByCodeUtilisateur = null;

            $this->collTChampsSupps = null;

            $this->collTEntites = null;

            $this->collTEtablissementsRelatedByCodeAdresseEtablissement = null;

            $this->collTEtablissementsRelatedByCodeDenominationEtablissement = null;

            $this->collTEtablissementsRelatedByCodeDescriptionEtablissement = null;

            $this->collTGroupes = null;

            $this->collTJourFeries = null;

            $this->collTOrganisationsRelatedByCodeAdresseOrganisation = null;

            $this->collTOrganisationsRelatedByCodeDenominationOrganisation = null;

            $this->collTOrganisationsRelatedByCodeDescriptionOrganisation = null;

            $this->collTOrganisationsRelatedByCodeLibelleLien1 = null;

            $this->collTOrganisationsRelatedByCodeLibelleLien2 = null;

            $this->collTOrganisationsRelatedByCodeLibelleLien3 = null;

            $this->collTOrganisationsRelatedByCodeMessageBienvenue = null;

            $this->collTOrganisationsRelatedByCodeTitreBienvenue = null;

            $this->collTParametragePrestationsRelatedByCodeCommentaire = null;

            $this->collTParametragePrestationsRelatedByCodeAide = null;

            $this->collTParametreFormsRelatedByCodeCommentaire = null;

            $this->collTParametreFormsRelatedByCodeLibelleRef1 = null;

            $this->collTParametreFormsRelatedByCodeLibelleRef2 = null;

            $this->collTParametreFormsRelatedByCodeLibelleRef3 = null;

            $this->collTParametreFormsRelatedByCodeLibelleText1 = null;

            $this->collTParametreFormsRelatedByCodeLibelleText2 = null;

            $this->collTParametreFormsRelatedByCodeLibelleText3 = null;

            $this->collTPieceParamPrestas = null;

            $this->collTPiecePrestations = null;

            $this->collTPrestationsRelatedByCodeCommentaire = null;

            $this->collTPrestationsRelatedByCodeLibellePrestation = null;

            $this->collTProfils = null;

            $this->collTReferentsRelatedByCodeNomReferent = null;

            $this->collTReferentsRelatedByCodePrenomReferent = null;

            $this->collTReferentiels = null;

            $this->collTRefPrestationsRelatedByCodeAide = null;

            $this->collTRefPrestationsRelatedByCodeLibelle = null;

            $this->collTRefTypePrestations = null;

            $this->collTTraductionLibelles = null;

            $this->collTTypeEtabsRelatedByCodeLibelle = null;

            $this->collTTypeEtabsRelatedByCodeLibelleEtab = null;

            $this->collTTypePrestations = null;

            $this->collTTypeProfils = null;

            $this->collTValeurReferentiels = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TTraductionPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TTraductionQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TTraductionPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TTraductionPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion !== null) {
                if (!$this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion as $tAgentRelatedByCodeNomUtilisateur) {
                        // need to save related object because we set the relation to null
                        $tAgentRelatedByCodeNomUtilisateur->save($con);
                    }
                    $this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentsRelatedByCodeNomUtilisateur !== null) {
                foreach ($this->collTAgentsRelatedByCodeNomUtilisateur as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion !== null) {
                if (!$this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion as $tAgentRelatedByCodePrenomUtilisateur) {
                        // need to save related object because we set the relation to null
                        $tAgentRelatedByCodePrenomUtilisateur->save($con);
                    }
                    $this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentsRelatedByCodePrenomUtilisateur !== null) {
                foreach ($this->collTAgentsRelatedByCodePrenomUtilisateur as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion !== null) {
                if (!$this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion as $tAgentRelatedByCodeUtilisateur) {
                        // need to save related object because we set the relation to null
                        $tAgentRelatedByCodeUtilisateur->save($con);
                    }
                    $this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion = null;
                }
            }

            if ($this->collTAgentsRelatedByCodeUtilisateur !== null) {
                foreach ($this->collTAgentsRelatedByCodeUtilisateur as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tChampsSuppsScheduledForDeletion !== null) {
                if (!$this->tChampsSuppsScheduledForDeletion->isEmpty()) {
                    TChampsSuppQuery::create()
                        ->filterByPrimaryKeys($this->tChampsSuppsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tChampsSuppsScheduledForDeletion = null;
                }
            }

            if ($this->collTChampsSupps !== null) {
                foreach ($this->collTChampsSupps as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tEntitesScheduledForDeletion !== null) {
                if (!$this->tEntitesScheduledForDeletion->isEmpty()) {
                    foreach ($this->tEntitesScheduledForDeletion as $tEntite) {
                        // need to save related object because we set the relation to null
                        $tEntite->save($con);
                    }
                    $this->tEntitesScheduledForDeletion = null;
                }
            }

            if ($this->collTEntites !== null) {
                foreach ($this->collTEntites as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion !== null) {
                if (!$this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion->isEmpty()) {
                    foreach ($this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion as $tEtablissementRelatedByCodeAdresseEtablissement) {
                        // need to save related object because we set the relation to null
                        $tEtablissementRelatedByCodeAdresseEtablissement->save($con);
                    }
                    $this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion = null;
                }
            }

            if ($this->collTEtablissementsRelatedByCodeAdresseEtablissement !== null) {
                foreach ($this->collTEtablissementsRelatedByCodeAdresseEtablissement as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion !== null) {
                if (!$this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion->isEmpty()) {
                    foreach ($this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion as $tEtablissementRelatedByCodeDenominationEtablissement) {
                        // need to save related object because we set the relation to null
                        $tEtablissementRelatedByCodeDenominationEtablissement->save($con);
                    }
                    $this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion = null;
                }
            }

            if ($this->collTEtablissementsRelatedByCodeDenominationEtablissement !== null) {
                foreach ($this->collTEtablissementsRelatedByCodeDenominationEtablissement as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion !== null) {
                if (!$this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion->isEmpty()) {
                    foreach ($this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion as $tEtablissementRelatedByCodeDescriptionEtablissement) {
                        // need to save related object because we set the relation to null
                        $tEtablissementRelatedByCodeDescriptionEtablissement->save($con);
                    }
                    $this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion = null;
                }
            }

            if ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement !== null) {
                foreach ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tGroupesScheduledForDeletion !== null) {
                if (!$this->tGroupesScheduledForDeletion->isEmpty()) {
                    foreach ($this->tGroupesScheduledForDeletion as $tGroupe) {
                        // need to save related object because we set the relation to null
                        $tGroupe->save($con);
                    }
                    $this->tGroupesScheduledForDeletion = null;
                }
            }

            if ($this->collTGroupes !== null) {
                foreach ($this->collTGroupes as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tJourFeriesScheduledForDeletion !== null) {
                if (!$this->tJourFeriesScheduledForDeletion->isEmpty()) {
                    foreach ($this->tJourFeriesScheduledForDeletion as $tJourFerie) {
                        // need to save related object because we set the relation to null
                        $tJourFerie->save($con);
                    }
                    $this->tJourFeriesScheduledForDeletion = null;
                }
            }

            if ($this->collTJourFeries !== null) {
                foreach ($this->collTJourFeries as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion as $tOrganisationRelatedByCodeAdresseOrganisation) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeAdresseOrganisation->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeAdresseOrganisation !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeAdresseOrganisation as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion as $tOrganisationRelatedByCodeDenominationOrganisation) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeDenominationOrganisation->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeDenominationOrganisation !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeDenominationOrganisation as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion as $tOrganisationRelatedByCodeDescriptionOrganisation) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeDescriptionOrganisation->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion as $tOrganisationRelatedByCodeLibelleLien1) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeLibelleLien1->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeLibelleLien1 !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeLibelleLien1 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion as $tOrganisationRelatedByCodeLibelleLien2) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeLibelleLien2->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeLibelleLien2 !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeLibelleLien2 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion as $tOrganisationRelatedByCodeLibelleLien3) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeLibelleLien3->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeLibelleLien3 !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeLibelleLien3 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion as $tOrganisationRelatedByCodeMessageBienvenue) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeMessageBienvenue->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeMessageBienvenue !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeMessageBienvenue as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion !== null) {
                if (!$this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion->isEmpty()) {
                    foreach ($this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion as $tOrganisationRelatedByCodeTitreBienvenue) {
                        // need to save related object because we set the relation to null
                        $tOrganisationRelatedByCodeTitreBienvenue->save($con);
                    }
                    $this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion = null;
                }
            }

            if ($this->collTOrganisationsRelatedByCodeTitreBienvenue !== null) {
                foreach ($this->collTOrganisationsRelatedByCodeTitreBienvenue as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion !== null) {
                if (!$this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion as $tParametragePrestationRelatedByCodeCommentaire) {
                        // need to save related object because we set the relation to null
                        $tParametragePrestationRelatedByCodeCommentaire->save($con);
                    }
                    $this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion = null;
                }
            }

            if ($this->collTParametragePrestationsRelatedByCodeCommentaire !== null) {
                foreach ($this->collTParametragePrestationsRelatedByCodeCommentaire as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion !== null) {
                if (!$this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion as $tParametragePrestationRelatedByCodeAide) {
                        // need to save related object because we set the relation to null
                        $tParametragePrestationRelatedByCodeAide->save($con);
                    }
                    $this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion = null;
                }
            }

            if ($this->collTParametragePrestationsRelatedByCodeAide !== null) {
                foreach ($this->collTParametragePrestationsRelatedByCodeAide as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion as $tParametreFormRelatedByCodeCommentaire) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByCodeCommentaire->save($con);
                    }
                    $this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByCodeCommentaire !== null) {
                foreach ($this->collTParametreFormsRelatedByCodeCommentaire as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion as $tParametreFormRelatedByCodeLibelleRef1) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByCodeLibelleRef1->save($con);
                    }
                    $this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByCodeLibelleRef1 !== null) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleRef1 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion as $tParametreFormRelatedByCodeLibelleRef2) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByCodeLibelleRef2->save($con);
                    }
                    $this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByCodeLibelleRef2 !== null) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleRef2 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion as $tParametreFormRelatedByCodeLibelleRef3) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByCodeLibelleRef3->save($con);
                    }
                    $this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByCodeLibelleRef3 !== null) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleRef3 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion as $tParametreFormRelatedByCodeLibelleText1) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByCodeLibelleText1->save($con);
                    }
                    $this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByCodeLibelleText1 !== null) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleText1 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion as $tParametreFormRelatedByCodeLibelleText2) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByCodeLibelleText2->save($con);
                    }
                    $this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByCodeLibelleText2 !== null) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleText2 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion !== null) {
                if (!$this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion->isEmpty()) {
                    foreach ($this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion as $tParametreFormRelatedByCodeLibelleText3) {
                        // need to save related object because we set the relation to null
                        $tParametreFormRelatedByCodeLibelleText3->save($con);
                    }
                    $this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion = null;
                }
            }

            if ($this->collTParametreFormsRelatedByCodeLibelleText3 !== null) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleText3 as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPieceParamPrestasScheduledForDeletion !== null) {
                if (!$this->tPieceParamPrestasScheduledForDeletion->isEmpty()) {
                    TPieceParamPrestaQuery::create()
                        ->filterByPrimaryKeys($this->tPieceParamPrestasScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tPieceParamPrestasScheduledForDeletion = null;
                }
            }

            if ($this->collTPieceParamPrestas !== null) {
                foreach ($this->collTPieceParamPrestas as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPiecePrestationsScheduledForDeletion !== null) {
                if (!$this->tPiecePrestationsScheduledForDeletion->isEmpty()) {
                    TPiecePrestationQuery::create()
                        ->filterByPrimaryKeys($this->tPiecePrestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tPiecePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTPiecePrestations !== null) {
                foreach ($this->collTPiecePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion !== null) {
                if (!$this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion->isEmpty()) {
                    foreach ($this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion as $tPrestationRelatedByCodeCommentaire) {
                        // need to save related object because we set the relation to null
                        $tPrestationRelatedByCodeCommentaire->save($con);
                    }
                    $this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion = null;
                }
            }

            if ($this->collTPrestationsRelatedByCodeCommentaire !== null) {
                foreach ($this->collTPrestationsRelatedByCodeCommentaire as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion !== null) {
                if (!$this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion->isEmpty()) {
                    foreach ($this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion as $tPrestationRelatedByCodeLibellePrestation) {
                        // need to save related object because we set the relation to null
                        $tPrestationRelatedByCodeLibellePrestation->save($con);
                    }
                    $this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion = null;
                }
            }

            if ($this->collTPrestationsRelatedByCodeLibellePrestation !== null) {
                foreach ($this->collTPrestationsRelatedByCodeLibellePrestation as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tProfilsScheduledForDeletion !== null) {
                if (!$this->tProfilsScheduledForDeletion->isEmpty()) {
                    TProfilQuery::create()
                        ->filterByPrimaryKeys($this->tProfilsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tProfilsScheduledForDeletion = null;
                }
            }

            if ($this->collTProfils !== null) {
                foreach ($this->collTProfils as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tReferentsRelatedByCodeNomReferentScheduledForDeletion !== null) {
                if (!$this->tReferentsRelatedByCodeNomReferentScheduledForDeletion->isEmpty()) {
                    TReferentQuery::create()
                        ->filterByPrimaryKeys($this->tReferentsRelatedByCodeNomReferentScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tReferentsRelatedByCodeNomReferentScheduledForDeletion = null;
                }
            }

            if ($this->collTReferentsRelatedByCodeNomReferent !== null) {
                foreach ($this->collTReferentsRelatedByCodeNomReferent as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion !== null) {
                if (!$this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion->isEmpty()) {
                    TReferentQuery::create()
                        ->filterByPrimaryKeys($this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion = null;
                }
            }

            if ($this->collTReferentsRelatedByCodePrenomReferent !== null) {
                foreach ($this->collTReferentsRelatedByCodePrenomReferent as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tReferentielsScheduledForDeletion !== null) {
                if (!$this->tReferentielsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tReferentielsScheduledForDeletion as $tReferentiel) {
                        // need to save related object because we set the relation to null
                        $tReferentiel->save($con);
                    }
                    $this->tReferentielsScheduledForDeletion = null;
                }
            }

            if ($this->collTReferentiels !== null) {
                foreach ($this->collTReferentiels as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRefPrestationsRelatedByCodeAideScheduledForDeletion !== null) {
                if (!$this->tRefPrestationsRelatedByCodeAideScheduledForDeletion->isEmpty()) {
                    TRefPrestationQuery::create()
                        ->filterByPrimaryKeys($this->tRefPrestationsRelatedByCodeAideScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tRefPrestationsRelatedByCodeAideScheduledForDeletion = null;
                }
            }

            if ($this->collTRefPrestationsRelatedByCodeAide !== null) {
                foreach ($this->collTRefPrestationsRelatedByCodeAide as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion !== null) {
                if (!$this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion->isEmpty()) {
                    TRefPrestationQuery::create()
                        ->filterByPrimaryKeys($this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion = null;
                }
            }

            if ($this->collTRefPrestationsRelatedByCodeLibelle !== null) {
                foreach ($this->collTRefPrestationsRelatedByCodeLibelle as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tRefTypePrestationsScheduledForDeletion !== null) {
                if (!$this->tRefTypePrestationsScheduledForDeletion->isEmpty()) {
                    TRefTypePrestationQuery::create()
                        ->filterByPrimaryKeys($this->tRefTypePrestationsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tRefTypePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTRefTypePrestations !== null) {
                foreach ($this->collTRefTypePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tTraductionLibellesScheduledForDeletion !== null) {
                if (!$this->tTraductionLibellesScheduledForDeletion->isEmpty()) {
                    TTraductionLibelleQuery::create()
                        ->filterByPrimaryKeys($this->tTraductionLibellesScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tTraductionLibellesScheduledForDeletion = null;
                }
            }

            if ($this->collTTraductionLibelles !== null) {
                foreach ($this->collTTraductionLibelles as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion !== null) {
                if (!$this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion->isEmpty()) {
                    TTypeEtabQuery::create()
                        ->filterByPrimaryKeys($this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion = null;
                }
            }

            if ($this->collTTypeEtabsRelatedByCodeLibelle !== null) {
                foreach ($this->collTTypeEtabsRelatedByCodeLibelle as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion !== null) {
                if (!$this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion->isEmpty()) {
                    TTypeEtabQuery::create()
                        ->filterByPrimaryKeys($this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion = null;
                }
            }

            if ($this->collTTypeEtabsRelatedByCodeLibelleEtab !== null) {
                foreach ($this->collTTypeEtabsRelatedByCodeLibelleEtab as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tTypePrestationsScheduledForDeletion !== null) {
                if (!$this->tTypePrestationsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tTypePrestationsScheduledForDeletion as $tTypePrestation) {
                        // need to save related object because we set the relation to null
                        $tTypePrestation->save($con);
                    }
                    $this->tTypePrestationsScheduledForDeletion = null;
                }
            }

            if ($this->collTTypePrestations !== null) {
                foreach ($this->collTTypePrestations as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tTypeProfilsScheduledForDeletion !== null) {
                if (!$this->tTypeProfilsScheduledForDeletion->isEmpty()) {
                    TTypeProfilQuery::create()
                        ->filterByPrimaryKeys($this->tTypeProfilsScheduledForDeletion->getPrimaryKeys(false))
                        ->delete($con);
                    $this->tTypeProfilsScheduledForDeletion = null;
                }
            }

            if ($this->collTTypeProfils !== null) {
                foreach ($this->collTTypeProfils as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            if ($this->tValeurReferentielsScheduledForDeletion !== null) {
                if (!$this->tValeurReferentielsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tValeurReferentielsScheduledForDeletion as $tValeurReferentiel) {
                        // need to save related object because we set the relation to null
                        $tValeurReferentiel->save($con);
                    }
                    $this->tValeurReferentielsScheduledForDeletion = null;
                }
            }

            if ($this->collTValeurReferentiels !== null) {
                foreach ($this->collTValeurReferentiels as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TTraductionPeer::ID_TRADUCTION;
        if (null !== $this->id_traduction) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TTraductionPeer::ID_TRADUCTION . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TTraductionPeer::ID_TRADUCTION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_TRADUCTION`';
        }

        $sql = sprintf(
            'INSERT INTO `T_TRADUCTION` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_TRADUCTION`':
                        $stmt->bindValue($identifier, $this->id_traduction, PDO::PARAM_INT);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdTraduction($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            if (($retval = TTraductionPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTAgentsRelatedByCodeNomUtilisateur !== null) {
                    foreach ($this->collTAgentsRelatedByCodeNomUtilisateur as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgentsRelatedByCodePrenomUtilisateur !== null) {
                    foreach ($this->collTAgentsRelatedByCodePrenomUtilisateur as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTAgentsRelatedByCodeUtilisateur !== null) {
                    foreach ($this->collTAgentsRelatedByCodeUtilisateur as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTChampsSupps !== null) {
                    foreach ($this->collTChampsSupps as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTEntites !== null) {
                    foreach ($this->collTEntites as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTEtablissementsRelatedByCodeAdresseEtablissement !== null) {
                    foreach ($this->collTEtablissementsRelatedByCodeAdresseEtablissement as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTEtablissementsRelatedByCodeDenominationEtablissement !== null) {
                    foreach ($this->collTEtablissementsRelatedByCodeDenominationEtablissement as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement !== null) {
                    foreach ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTGroupes !== null) {
                    foreach ($this->collTGroupes as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTJourFeries !== null) {
                    foreach ($this->collTJourFeries as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeAdresseOrganisation !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeAdresseOrganisation as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeDenominationOrganisation !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeDenominationOrganisation as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeLibelleLien1 !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeLibelleLien1 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeLibelleLien2 !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeLibelleLien2 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeLibelleLien3 !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeLibelleLien3 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeMessageBienvenue !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeMessageBienvenue as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTOrganisationsRelatedByCodeTitreBienvenue !== null) {
                    foreach ($this->collTOrganisationsRelatedByCodeTitreBienvenue as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametragePrestationsRelatedByCodeCommentaire !== null) {
                    foreach ($this->collTParametragePrestationsRelatedByCodeCommentaire as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametragePrestationsRelatedByCodeAide !== null) {
                    foreach ($this->collTParametragePrestationsRelatedByCodeAide as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByCodeCommentaire !== null) {
                    foreach ($this->collTParametreFormsRelatedByCodeCommentaire as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByCodeLibelleRef1 !== null) {
                    foreach ($this->collTParametreFormsRelatedByCodeLibelleRef1 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByCodeLibelleRef2 !== null) {
                    foreach ($this->collTParametreFormsRelatedByCodeLibelleRef2 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByCodeLibelleRef3 !== null) {
                    foreach ($this->collTParametreFormsRelatedByCodeLibelleRef3 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByCodeLibelleText1 !== null) {
                    foreach ($this->collTParametreFormsRelatedByCodeLibelleText1 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByCodeLibelleText2 !== null) {
                    foreach ($this->collTParametreFormsRelatedByCodeLibelleText2 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTParametreFormsRelatedByCodeLibelleText3 !== null) {
                    foreach ($this->collTParametreFormsRelatedByCodeLibelleText3 as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPieceParamPrestas !== null) {
                    foreach ($this->collTPieceParamPrestas as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPiecePrestations !== null) {
                    foreach ($this->collTPiecePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPrestationsRelatedByCodeCommentaire !== null) {
                    foreach ($this->collTPrestationsRelatedByCodeCommentaire as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTPrestationsRelatedByCodeLibellePrestation !== null) {
                    foreach ($this->collTPrestationsRelatedByCodeLibellePrestation as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTProfils !== null) {
                    foreach ($this->collTProfils as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTReferentsRelatedByCodeNomReferent !== null) {
                    foreach ($this->collTReferentsRelatedByCodeNomReferent as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTReferentsRelatedByCodePrenomReferent !== null) {
                    foreach ($this->collTReferentsRelatedByCodePrenomReferent as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTReferentiels !== null) {
                    foreach ($this->collTReferentiels as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRefPrestationsRelatedByCodeAide !== null) {
                    foreach ($this->collTRefPrestationsRelatedByCodeAide as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRefPrestationsRelatedByCodeLibelle !== null) {
                    foreach ($this->collTRefPrestationsRelatedByCodeLibelle as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTRefTypePrestations !== null) {
                    foreach ($this->collTRefTypePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTTraductionLibelles !== null) {
                    foreach ($this->collTTraductionLibelles as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTTypeEtabsRelatedByCodeLibelle !== null) {
                    foreach ($this->collTTypeEtabsRelatedByCodeLibelle as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTTypeEtabsRelatedByCodeLibelleEtab !== null) {
                    foreach ($this->collTTypeEtabsRelatedByCodeLibelleEtab as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTTypePrestations !== null) {
                    foreach ($this->collTTypePrestations as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTTypeProfils !== null) {
                    foreach ($this->collTTypeProfils as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }

                if ($this->collTValeurReferentiels !== null) {
                    foreach ($this->collTValeurReferentiels as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TTraductionPeer::DATABASE_NAME);

        if ($this->isColumnModified(TTraductionPeer::ID_TRADUCTION)) $criteria->add(TTraductionPeer::ID_TRADUCTION, $this->id_traduction);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TTraductionPeer::DATABASE_NAME);
        $criteria->add(TTraductionPeer::ID_TRADUCTION, $this->id_traduction);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdTraduction();
    }

    /**
     * Generic method to set the primary key (id_traduction column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdTraduction($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdTraduction();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TTraduction (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTAgentsRelatedByCodeNomUtilisateur() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentRelatedByCodeNomUtilisateur($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgentsRelatedByCodePrenomUtilisateur() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentRelatedByCodePrenomUtilisateur($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTAgentsRelatedByCodeUtilisateur() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgentRelatedByCodeUtilisateur($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTChampsSupps() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTChampsSupp($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTEntites() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTEntite($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTEtablissementsRelatedByCodeAdresseEtablissement() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTEtablissementRelatedByCodeAdresseEtablissement($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTEtablissementsRelatedByCodeDenominationEtablissement() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTEtablissementRelatedByCodeDenominationEtablissement($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTEtablissementsRelatedByCodeDescriptionEtablissement() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTEtablissementRelatedByCodeDescriptionEtablissement($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTGroupes() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTGroupe($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTJourFeries() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTJourFerie($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeAdresseOrganisation() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeAdresseOrganisation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeDenominationOrganisation() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeDenominationOrganisation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeDescriptionOrganisation() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeDescriptionOrganisation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeLibelleLien1() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeLibelleLien1($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeLibelleLien2() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeLibelleLien2($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeLibelleLien3() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeLibelleLien3($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeMessageBienvenue() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeMessageBienvenue($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTOrganisationsRelatedByCodeTitreBienvenue() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTOrganisationRelatedByCodeTitreBienvenue($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametragePrestationsRelatedByCodeCommentaire() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametragePrestationRelatedByCodeCommentaire($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametragePrestationsRelatedByCodeAide() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametragePrestationRelatedByCodeAide($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByCodeCommentaire() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByCodeCommentaire($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByCodeLibelleRef1() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByCodeLibelleRef1($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByCodeLibelleRef2() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByCodeLibelleRef2($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByCodeLibelleRef3() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByCodeLibelleRef3($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByCodeLibelleText1() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByCodeLibelleText1($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByCodeLibelleText2() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByCodeLibelleText2($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTParametreFormsRelatedByCodeLibelleText3() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTParametreFormRelatedByCodeLibelleText3($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPieceParamPrestas() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPieceParamPresta($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPiecePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPiecePrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPrestationsRelatedByCodeCommentaire() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPrestationRelatedByCodeCommentaire($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTPrestationsRelatedByCodeLibellePrestation() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTPrestationRelatedByCodeLibellePrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTProfils() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTProfil($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTReferentsRelatedByCodeNomReferent() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTReferentRelatedByCodeNomReferent($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTReferentsRelatedByCodePrenomReferent() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTReferentRelatedByCodePrenomReferent($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTReferentiels() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTReferentiel($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRefPrestationsRelatedByCodeAide() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRefPrestationRelatedByCodeAide($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRefPrestationsRelatedByCodeLibelle() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRefPrestationRelatedByCodeLibelle($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTRefTypePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTRefTypePrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTTraductionLibelles() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTTraductionLibelle($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTTypeEtabsRelatedByCodeLibelle() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTTypeEtabRelatedByCodeLibelle($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTTypeEtabsRelatedByCodeLibelleEtab() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTTypeEtabRelatedByCodeLibelleEtab($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTTypePrestations() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTTypePrestation($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTTypeProfils() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTTypeProfil($relObj->copy($deepCopy));
                }
            }

            foreach ($this->getTValeurReferentiels() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTValeurReferentiel($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdTraduction(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TTraduction Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TTraductionPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TTraductionPeer();
        }

        return self::$peer;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TAgentRelatedByCodeNomUtilisateur' == $relationName) {
            $this->initTAgentsRelatedByCodeNomUtilisateur();
        }
        if ('TAgentRelatedByCodePrenomUtilisateur' == $relationName) {
            $this->initTAgentsRelatedByCodePrenomUtilisateur();
        }
        if ('TAgentRelatedByCodeUtilisateur' == $relationName) {
            $this->initTAgentsRelatedByCodeUtilisateur();
        }
        if ('TChampsSupp' == $relationName) {
            $this->initTChampsSupps();
        }
        if ('TEntite' == $relationName) {
            $this->initTEntites();
        }
        if ('TEtablissementRelatedByCodeAdresseEtablissement' == $relationName) {
            $this->initTEtablissementsRelatedByCodeAdresseEtablissement();
        }
        if ('TEtablissementRelatedByCodeDenominationEtablissement' == $relationName) {
            $this->initTEtablissementsRelatedByCodeDenominationEtablissement();
        }
        if ('TEtablissementRelatedByCodeDescriptionEtablissement' == $relationName) {
            $this->initTEtablissementsRelatedByCodeDescriptionEtablissement();
        }
        if ('TGroupe' == $relationName) {
            $this->initTGroupes();
        }
        if ('TJourFerie' == $relationName) {
            $this->initTJourFeries();
        }
        if ('TOrganisationRelatedByCodeAdresseOrganisation' == $relationName) {
            $this->initTOrganisationsRelatedByCodeAdresseOrganisation();
        }
        if ('TOrganisationRelatedByCodeDenominationOrganisation' == $relationName) {
            $this->initTOrganisationsRelatedByCodeDenominationOrganisation();
        }
        if ('TOrganisationRelatedByCodeDescriptionOrganisation' == $relationName) {
            $this->initTOrganisationsRelatedByCodeDescriptionOrganisation();
        }
        if ('TOrganisationRelatedByCodeLibelleLien1' == $relationName) {
            $this->initTOrganisationsRelatedByCodeLibelleLien1();
        }
        if ('TOrganisationRelatedByCodeLibelleLien2' == $relationName) {
            $this->initTOrganisationsRelatedByCodeLibelleLien2();
        }
        if ('TOrganisationRelatedByCodeLibelleLien3' == $relationName) {
            $this->initTOrganisationsRelatedByCodeLibelleLien3();
        }
        if ('TOrganisationRelatedByCodeMessageBienvenue' == $relationName) {
            $this->initTOrganisationsRelatedByCodeMessageBienvenue();
        }
        if ('TOrganisationRelatedByCodeTitreBienvenue' == $relationName) {
            $this->initTOrganisationsRelatedByCodeTitreBienvenue();
        }
        if ('TParametragePrestationRelatedByCodeCommentaire' == $relationName) {
            $this->initTParametragePrestationsRelatedByCodeCommentaire();
        }
        if ('TParametragePrestationRelatedByCodeAide' == $relationName) {
            $this->initTParametragePrestationsRelatedByCodeAide();
        }
        if ('TParametreFormRelatedByCodeCommentaire' == $relationName) {
            $this->initTParametreFormsRelatedByCodeCommentaire();
        }
        if ('TParametreFormRelatedByCodeLibelleRef1' == $relationName) {
            $this->initTParametreFormsRelatedByCodeLibelleRef1();
        }
        if ('TParametreFormRelatedByCodeLibelleRef2' == $relationName) {
            $this->initTParametreFormsRelatedByCodeLibelleRef2();
        }
        if ('TParametreFormRelatedByCodeLibelleRef3' == $relationName) {
            $this->initTParametreFormsRelatedByCodeLibelleRef3();
        }
        if ('TParametreFormRelatedByCodeLibelleText1' == $relationName) {
            $this->initTParametreFormsRelatedByCodeLibelleText1();
        }
        if ('TParametreFormRelatedByCodeLibelleText2' == $relationName) {
            $this->initTParametreFormsRelatedByCodeLibelleText2();
        }
        if ('TParametreFormRelatedByCodeLibelleText3' == $relationName) {
            $this->initTParametreFormsRelatedByCodeLibelleText3();
        }
        if ('TPieceParamPresta' == $relationName) {
            $this->initTPieceParamPrestas();
        }
        if ('TPiecePrestation' == $relationName) {
            $this->initTPiecePrestations();
        }
        if ('TPrestationRelatedByCodeCommentaire' == $relationName) {
            $this->initTPrestationsRelatedByCodeCommentaire();
        }
        if ('TPrestationRelatedByCodeLibellePrestation' == $relationName) {
            $this->initTPrestationsRelatedByCodeLibellePrestation();
        }
        if ('TProfil' == $relationName) {
            $this->initTProfils();
        }
        if ('TReferentRelatedByCodeNomReferent' == $relationName) {
            $this->initTReferentsRelatedByCodeNomReferent();
        }
        if ('TReferentRelatedByCodePrenomReferent' == $relationName) {
            $this->initTReferentsRelatedByCodePrenomReferent();
        }
        if ('TReferentiel' == $relationName) {
            $this->initTReferentiels();
        }
        if ('TRefPrestationRelatedByCodeAide' == $relationName) {
            $this->initTRefPrestationsRelatedByCodeAide();
        }
        if ('TRefPrestationRelatedByCodeLibelle' == $relationName) {
            $this->initTRefPrestationsRelatedByCodeLibelle();
        }
        if ('TRefTypePrestation' == $relationName) {
            $this->initTRefTypePrestations();
        }
        if ('TTraductionLibelle' == $relationName) {
            $this->initTTraductionLibelles();
        }
        if ('TTypeEtabRelatedByCodeLibelle' == $relationName) {
            $this->initTTypeEtabsRelatedByCodeLibelle();
        }
        if ('TTypeEtabRelatedByCodeLibelleEtab' == $relationName) {
            $this->initTTypeEtabsRelatedByCodeLibelleEtab();
        }
        if ('TTypePrestation' == $relationName) {
            $this->initTTypePrestations();
        }
        if ('TTypeProfil' == $relationName) {
            $this->initTTypeProfils();
        }
        if ('TValeurReferentiel' == $relationName) {
            $this->initTValeurReferentiels();
        }
    }

    /**
     * Clears out the collTAgentsRelatedByCodeNomUtilisateur collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTAgentsRelatedByCodeNomUtilisateur()
     */
    public function clearTAgentsRelatedByCodeNomUtilisateur()
    {
        $this->collTAgentsRelatedByCodeNomUtilisateur = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentsRelatedByCodeNomUtilisateurPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentsRelatedByCodeNomUtilisateur collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentsRelatedByCodeNomUtilisateur($v = true)
    {
        $this->collTAgentsRelatedByCodeNomUtilisateurPartial = $v;
    }

    /**
     * Initializes the collTAgentsRelatedByCodeNomUtilisateur collection.
     *
     * By default this just sets the collTAgentsRelatedByCodeNomUtilisateur collection to an empty array (like clearcollTAgentsRelatedByCodeNomUtilisateur());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentsRelatedByCodeNomUtilisateur($overrideExisting = true)
    {
        if (null !== $this->collTAgentsRelatedByCodeNomUtilisateur && !$overrideExisting) {
            return;
        }
        $this->collTAgentsRelatedByCodeNomUtilisateur = new PropelObjectCollection();
        $this->collTAgentsRelatedByCodeNomUtilisateur->setModel('TAgent');
    }

    /**
     * Gets an array of TAgent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     * @throws PropelException
     */
    public function getTAgentsRelatedByCodeNomUtilisateur($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByCodeNomUtilisateurPartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByCodeNomUtilisateur || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByCodeNomUtilisateur) {
                // return empty collection
                $this->initTAgentsRelatedByCodeNomUtilisateur();
            } else {
                $collTAgentsRelatedByCodeNomUtilisateur = TAgentQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeNomUtilisateur($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentsRelatedByCodeNomUtilisateurPartial && count($collTAgentsRelatedByCodeNomUtilisateur)) {
                      $this->initTAgentsRelatedByCodeNomUtilisateur(false);

                      foreach($collTAgentsRelatedByCodeNomUtilisateur as $obj) {
                        if (false == $this->collTAgentsRelatedByCodeNomUtilisateur->contains($obj)) {
                          $this->collTAgentsRelatedByCodeNomUtilisateur->append($obj);
                        }
                      }

                      $this->collTAgentsRelatedByCodeNomUtilisateurPartial = true;
                    }

                    $collTAgentsRelatedByCodeNomUtilisateur->getInternalIterator()->rewind();
                    return $collTAgentsRelatedByCodeNomUtilisateur;
                }

                if($partial && $this->collTAgentsRelatedByCodeNomUtilisateur) {
                    foreach($this->collTAgentsRelatedByCodeNomUtilisateur as $obj) {
                        if($obj->isNew()) {
                            $collTAgentsRelatedByCodeNomUtilisateur[] = $obj;
                        }
                    }
                }

                $this->collTAgentsRelatedByCodeNomUtilisateur = $collTAgentsRelatedByCodeNomUtilisateur;
                $this->collTAgentsRelatedByCodeNomUtilisateurPartial = false;
            }
        }

        return $this->collTAgentsRelatedByCodeNomUtilisateur;
    }

    /**
     * Sets a collection of TAgentRelatedByCodeNomUtilisateur objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentsRelatedByCodeNomUtilisateur A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTAgentsRelatedByCodeNomUtilisateur(PropelCollection $tAgentsRelatedByCodeNomUtilisateur, PropelPDO $con = null)
    {
        $tAgentsRelatedByCodeNomUtilisateurToDelete = $this->getTAgentsRelatedByCodeNomUtilisateur(new Criteria(), $con)->diff($tAgentsRelatedByCodeNomUtilisateur);

        $this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion = unserialize(serialize($tAgentsRelatedByCodeNomUtilisateurToDelete));

        foreach ($tAgentsRelatedByCodeNomUtilisateurToDelete as $tAgentRelatedByCodeNomUtilisateurRemoved) {
            $tAgentRelatedByCodeNomUtilisateurRemoved->setTTraductionRelatedByCodeNomUtilisateur(null);
        }

        $this->collTAgentsRelatedByCodeNomUtilisateur = null;
        foreach ($tAgentsRelatedByCodeNomUtilisateur as $tAgentRelatedByCodeNomUtilisateur) {
            $this->addTAgentRelatedByCodeNomUtilisateur($tAgentRelatedByCodeNomUtilisateur);
        }

        $this->collTAgentsRelatedByCodeNomUtilisateur = $tAgentsRelatedByCodeNomUtilisateur;
        $this->collTAgentsRelatedByCodeNomUtilisateurPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgent objects.
     * @throws PropelException
     */
    public function countTAgentsRelatedByCodeNomUtilisateur(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByCodeNomUtilisateurPartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByCodeNomUtilisateur || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByCodeNomUtilisateur) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentsRelatedByCodeNomUtilisateur());
            }
            $query = TAgentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeNomUtilisateur($this)
                ->count($con);
        }

        return count($this->collTAgentsRelatedByCodeNomUtilisateur);
    }

    /**
     * Method called to associate a TAgent object to this object
     * through the TAgent foreign key attribute.
     *
     * @param    TAgent $l TAgent
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTAgentRelatedByCodeNomUtilisateur(TAgent $l)
    {
        if ($this->collTAgentsRelatedByCodeNomUtilisateur === null) {
            $this->initTAgentsRelatedByCodeNomUtilisateur();
            $this->collTAgentsRelatedByCodeNomUtilisateurPartial = true;
        }
        if (!in_array($l, $this->collTAgentsRelatedByCodeNomUtilisateur->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentRelatedByCodeNomUtilisateur($l);
        }

        return $this;
    }

    /**
     * @param	TAgentRelatedByCodeNomUtilisateur $tAgentRelatedByCodeNomUtilisateur The tAgentRelatedByCodeNomUtilisateur object to add.
     */
    protected function doAddTAgentRelatedByCodeNomUtilisateur($tAgentRelatedByCodeNomUtilisateur)
    {
        $this->collTAgentsRelatedByCodeNomUtilisateur[]= $tAgentRelatedByCodeNomUtilisateur;
        $tAgentRelatedByCodeNomUtilisateur->setTTraductionRelatedByCodeNomUtilisateur($this);
    }

    /**
     * @param	TAgentRelatedByCodeNomUtilisateur $tAgentRelatedByCodeNomUtilisateur The tAgentRelatedByCodeNomUtilisateur object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTAgentRelatedByCodeNomUtilisateur($tAgentRelatedByCodeNomUtilisateur)
    {
        if ($this->getTAgentsRelatedByCodeNomUtilisateur()->contains($tAgentRelatedByCodeNomUtilisateur)) {
            $this->collTAgentsRelatedByCodeNomUtilisateur->remove($this->collTAgentsRelatedByCodeNomUtilisateur->search($tAgentRelatedByCodeNomUtilisateur));
            if (null === $this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion) {
                $this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion = clone $this->collTAgentsRelatedByCodeNomUtilisateur;
                $this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion->clear();
            }
            $this->tAgentsRelatedByCodeNomUtilisateurScheduledForDeletion[]= $tAgentRelatedByCodeNomUtilisateur;
            $tAgentRelatedByCodeNomUtilisateur->setTTraductionRelatedByCodeNomUtilisateur(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeNomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeNomUtilisateurJoinTEtablissementRelatedByIdEtablissementAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementAttache', $join_behavior);

        return $this->getTAgentsRelatedByCodeNomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeNomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeNomUtilisateurJoinTEtablissementRelatedByIdEtablissementGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementGere', $join_behavior);

        return $this->getTAgentsRelatedByCodeNomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeNomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeNomUtilisateurJoinTOrganisationRelatedByIdOrganisationAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationAttache', $join_behavior);

        return $this->getTAgentsRelatedByCodeNomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeNomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeNomUtilisateurJoinTOrganisationRelatedByIdOrganisationGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationGere', $join_behavior);

        return $this->getTAgentsRelatedByCodeNomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeNomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeNomUtilisateurJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgentsRelatedByCodeNomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeNomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeNomUtilisateurJoinTProfil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TProfil', $join_behavior);

        return $this->getTAgentsRelatedByCodeNomUtilisateur($query, $con);
    }

    /**
     * Clears out the collTAgentsRelatedByCodePrenomUtilisateur collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTAgentsRelatedByCodePrenomUtilisateur()
     */
    public function clearTAgentsRelatedByCodePrenomUtilisateur()
    {
        $this->collTAgentsRelatedByCodePrenomUtilisateur = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentsRelatedByCodePrenomUtilisateurPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentsRelatedByCodePrenomUtilisateur collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentsRelatedByCodePrenomUtilisateur($v = true)
    {
        $this->collTAgentsRelatedByCodePrenomUtilisateurPartial = $v;
    }

    /**
     * Initializes the collTAgentsRelatedByCodePrenomUtilisateur collection.
     *
     * By default this just sets the collTAgentsRelatedByCodePrenomUtilisateur collection to an empty array (like clearcollTAgentsRelatedByCodePrenomUtilisateur());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentsRelatedByCodePrenomUtilisateur($overrideExisting = true)
    {
        if (null !== $this->collTAgentsRelatedByCodePrenomUtilisateur && !$overrideExisting) {
            return;
        }
        $this->collTAgentsRelatedByCodePrenomUtilisateur = new PropelObjectCollection();
        $this->collTAgentsRelatedByCodePrenomUtilisateur->setModel('TAgent');
    }

    /**
     * Gets an array of TAgent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     * @throws PropelException
     */
    public function getTAgentsRelatedByCodePrenomUtilisateur($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByCodePrenomUtilisateurPartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByCodePrenomUtilisateur || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByCodePrenomUtilisateur) {
                // return empty collection
                $this->initTAgentsRelatedByCodePrenomUtilisateur();
            } else {
                $collTAgentsRelatedByCodePrenomUtilisateur = TAgentQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodePrenomUtilisateur($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentsRelatedByCodePrenomUtilisateurPartial && count($collTAgentsRelatedByCodePrenomUtilisateur)) {
                      $this->initTAgentsRelatedByCodePrenomUtilisateur(false);

                      foreach($collTAgentsRelatedByCodePrenomUtilisateur as $obj) {
                        if (false == $this->collTAgentsRelatedByCodePrenomUtilisateur->contains($obj)) {
                          $this->collTAgentsRelatedByCodePrenomUtilisateur->append($obj);
                        }
                      }

                      $this->collTAgentsRelatedByCodePrenomUtilisateurPartial = true;
                    }

                    $collTAgentsRelatedByCodePrenomUtilisateur->getInternalIterator()->rewind();
                    return $collTAgentsRelatedByCodePrenomUtilisateur;
                }

                if($partial && $this->collTAgentsRelatedByCodePrenomUtilisateur) {
                    foreach($this->collTAgentsRelatedByCodePrenomUtilisateur as $obj) {
                        if($obj->isNew()) {
                            $collTAgentsRelatedByCodePrenomUtilisateur[] = $obj;
                        }
                    }
                }

                $this->collTAgentsRelatedByCodePrenomUtilisateur = $collTAgentsRelatedByCodePrenomUtilisateur;
                $this->collTAgentsRelatedByCodePrenomUtilisateurPartial = false;
            }
        }

        return $this->collTAgentsRelatedByCodePrenomUtilisateur;
    }

    /**
     * Sets a collection of TAgentRelatedByCodePrenomUtilisateur objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentsRelatedByCodePrenomUtilisateur A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTAgentsRelatedByCodePrenomUtilisateur(PropelCollection $tAgentsRelatedByCodePrenomUtilisateur, PropelPDO $con = null)
    {
        $tAgentsRelatedByCodePrenomUtilisateurToDelete = $this->getTAgentsRelatedByCodePrenomUtilisateur(new Criteria(), $con)->diff($tAgentsRelatedByCodePrenomUtilisateur);

        $this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion = unserialize(serialize($tAgentsRelatedByCodePrenomUtilisateurToDelete));

        foreach ($tAgentsRelatedByCodePrenomUtilisateurToDelete as $tAgentRelatedByCodePrenomUtilisateurRemoved) {
            $tAgentRelatedByCodePrenomUtilisateurRemoved->setTTraductionRelatedByCodePrenomUtilisateur(null);
        }

        $this->collTAgentsRelatedByCodePrenomUtilisateur = null;
        foreach ($tAgentsRelatedByCodePrenomUtilisateur as $tAgentRelatedByCodePrenomUtilisateur) {
            $this->addTAgentRelatedByCodePrenomUtilisateur($tAgentRelatedByCodePrenomUtilisateur);
        }

        $this->collTAgentsRelatedByCodePrenomUtilisateur = $tAgentsRelatedByCodePrenomUtilisateur;
        $this->collTAgentsRelatedByCodePrenomUtilisateurPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgent objects.
     * @throws PropelException
     */
    public function countTAgentsRelatedByCodePrenomUtilisateur(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByCodePrenomUtilisateurPartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByCodePrenomUtilisateur || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByCodePrenomUtilisateur) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentsRelatedByCodePrenomUtilisateur());
            }
            $query = TAgentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodePrenomUtilisateur($this)
                ->count($con);
        }

        return count($this->collTAgentsRelatedByCodePrenomUtilisateur);
    }

    /**
     * Method called to associate a TAgent object to this object
     * through the TAgent foreign key attribute.
     *
     * @param    TAgent $l TAgent
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTAgentRelatedByCodePrenomUtilisateur(TAgent $l)
    {
        if ($this->collTAgentsRelatedByCodePrenomUtilisateur === null) {
            $this->initTAgentsRelatedByCodePrenomUtilisateur();
            $this->collTAgentsRelatedByCodePrenomUtilisateurPartial = true;
        }
        if (!in_array($l, $this->collTAgentsRelatedByCodePrenomUtilisateur->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentRelatedByCodePrenomUtilisateur($l);
        }

        return $this;
    }

    /**
     * @param	TAgentRelatedByCodePrenomUtilisateur $tAgentRelatedByCodePrenomUtilisateur The tAgentRelatedByCodePrenomUtilisateur object to add.
     */
    protected function doAddTAgentRelatedByCodePrenomUtilisateur($tAgentRelatedByCodePrenomUtilisateur)
    {
        $this->collTAgentsRelatedByCodePrenomUtilisateur[]= $tAgentRelatedByCodePrenomUtilisateur;
        $tAgentRelatedByCodePrenomUtilisateur->setTTraductionRelatedByCodePrenomUtilisateur($this);
    }

    /**
     * @param	TAgentRelatedByCodePrenomUtilisateur $tAgentRelatedByCodePrenomUtilisateur The tAgentRelatedByCodePrenomUtilisateur object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTAgentRelatedByCodePrenomUtilisateur($tAgentRelatedByCodePrenomUtilisateur)
    {
        if ($this->getTAgentsRelatedByCodePrenomUtilisateur()->contains($tAgentRelatedByCodePrenomUtilisateur)) {
            $this->collTAgentsRelatedByCodePrenomUtilisateur->remove($this->collTAgentsRelatedByCodePrenomUtilisateur->search($tAgentRelatedByCodePrenomUtilisateur));
            if (null === $this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion) {
                $this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion = clone $this->collTAgentsRelatedByCodePrenomUtilisateur;
                $this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion->clear();
            }
            $this->tAgentsRelatedByCodePrenomUtilisateurScheduledForDeletion[]= $tAgentRelatedByCodePrenomUtilisateur;
            $tAgentRelatedByCodePrenomUtilisateur->setTTraductionRelatedByCodePrenomUtilisateur(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodePrenomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodePrenomUtilisateurJoinTEtablissementRelatedByIdEtablissementAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementAttache', $join_behavior);

        return $this->getTAgentsRelatedByCodePrenomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodePrenomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodePrenomUtilisateurJoinTEtablissementRelatedByIdEtablissementGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementGere', $join_behavior);

        return $this->getTAgentsRelatedByCodePrenomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodePrenomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodePrenomUtilisateurJoinTOrganisationRelatedByIdOrganisationAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationAttache', $join_behavior);

        return $this->getTAgentsRelatedByCodePrenomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodePrenomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodePrenomUtilisateurJoinTOrganisationRelatedByIdOrganisationGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationGere', $join_behavior);

        return $this->getTAgentsRelatedByCodePrenomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodePrenomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodePrenomUtilisateurJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgentsRelatedByCodePrenomUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodePrenomUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodePrenomUtilisateurJoinTProfil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TProfil', $join_behavior);

        return $this->getTAgentsRelatedByCodePrenomUtilisateur($query, $con);
    }

    /**
     * Clears out the collTAgentsRelatedByCodeUtilisateur collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTAgentsRelatedByCodeUtilisateur()
     */
    public function clearTAgentsRelatedByCodeUtilisateur()
    {
        $this->collTAgentsRelatedByCodeUtilisateur = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentsRelatedByCodeUtilisateurPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgentsRelatedByCodeUtilisateur collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgentsRelatedByCodeUtilisateur($v = true)
    {
        $this->collTAgentsRelatedByCodeUtilisateurPartial = $v;
    }

    /**
     * Initializes the collTAgentsRelatedByCodeUtilisateur collection.
     *
     * By default this just sets the collTAgentsRelatedByCodeUtilisateur collection to an empty array (like clearcollTAgentsRelatedByCodeUtilisateur());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgentsRelatedByCodeUtilisateur($overrideExisting = true)
    {
        if (null !== $this->collTAgentsRelatedByCodeUtilisateur && !$overrideExisting) {
            return;
        }
        $this->collTAgentsRelatedByCodeUtilisateur = new PropelObjectCollection();
        $this->collTAgentsRelatedByCodeUtilisateur->setModel('TAgent');
    }

    /**
     * Gets an array of TAgent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     * @throws PropelException
     */
    public function getTAgentsRelatedByCodeUtilisateur($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByCodeUtilisateurPartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByCodeUtilisateur || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByCodeUtilisateur) {
                // return empty collection
                $this->initTAgentsRelatedByCodeUtilisateur();
            } else {
                $collTAgentsRelatedByCodeUtilisateur = TAgentQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeUtilisateur($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentsRelatedByCodeUtilisateurPartial && count($collTAgentsRelatedByCodeUtilisateur)) {
                      $this->initTAgentsRelatedByCodeUtilisateur(false);

                      foreach($collTAgentsRelatedByCodeUtilisateur as $obj) {
                        if (false == $this->collTAgentsRelatedByCodeUtilisateur->contains($obj)) {
                          $this->collTAgentsRelatedByCodeUtilisateur->append($obj);
                        }
                      }

                      $this->collTAgentsRelatedByCodeUtilisateurPartial = true;
                    }

                    $collTAgentsRelatedByCodeUtilisateur->getInternalIterator()->rewind();
                    return $collTAgentsRelatedByCodeUtilisateur;
                }

                if($partial && $this->collTAgentsRelatedByCodeUtilisateur) {
                    foreach($this->collTAgentsRelatedByCodeUtilisateur as $obj) {
                        if($obj->isNew()) {
                            $collTAgentsRelatedByCodeUtilisateur[] = $obj;
                        }
                    }
                }

                $this->collTAgentsRelatedByCodeUtilisateur = $collTAgentsRelatedByCodeUtilisateur;
                $this->collTAgentsRelatedByCodeUtilisateurPartial = false;
            }
        }

        return $this->collTAgentsRelatedByCodeUtilisateur;
    }

    /**
     * Sets a collection of TAgentRelatedByCodeUtilisateur objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgentsRelatedByCodeUtilisateur A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTAgentsRelatedByCodeUtilisateur(PropelCollection $tAgentsRelatedByCodeUtilisateur, PropelPDO $con = null)
    {
        $tAgentsRelatedByCodeUtilisateurToDelete = $this->getTAgentsRelatedByCodeUtilisateur(new Criteria(), $con)->diff($tAgentsRelatedByCodeUtilisateur);

        $this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion = unserialize(serialize($tAgentsRelatedByCodeUtilisateurToDelete));

        foreach ($tAgentsRelatedByCodeUtilisateurToDelete as $tAgentRelatedByCodeUtilisateurRemoved) {
            $tAgentRelatedByCodeUtilisateurRemoved->setTTraductionRelatedByCodeUtilisateur(null);
        }

        $this->collTAgentsRelatedByCodeUtilisateur = null;
        foreach ($tAgentsRelatedByCodeUtilisateur as $tAgentRelatedByCodeUtilisateur) {
            $this->addTAgentRelatedByCodeUtilisateur($tAgentRelatedByCodeUtilisateur);
        }

        $this->collTAgentsRelatedByCodeUtilisateur = $tAgentsRelatedByCodeUtilisateur;
        $this->collTAgentsRelatedByCodeUtilisateurPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgent objects.
     * @throws PropelException
     */
    public function countTAgentsRelatedByCodeUtilisateur(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsRelatedByCodeUtilisateurPartial && !$this->isNew();
        if (null === $this->collTAgentsRelatedByCodeUtilisateur || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgentsRelatedByCodeUtilisateur) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgentsRelatedByCodeUtilisateur());
            }
            $query = TAgentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeUtilisateur($this)
                ->count($con);
        }

        return count($this->collTAgentsRelatedByCodeUtilisateur);
    }

    /**
     * Method called to associate a TAgent object to this object
     * through the TAgent foreign key attribute.
     *
     * @param    TAgent $l TAgent
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTAgentRelatedByCodeUtilisateur(TAgent $l)
    {
        if ($this->collTAgentsRelatedByCodeUtilisateur === null) {
            $this->initTAgentsRelatedByCodeUtilisateur();
            $this->collTAgentsRelatedByCodeUtilisateurPartial = true;
        }
        if (!in_array($l, $this->collTAgentsRelatedByCodeUtilisateur->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgentRelatedByCodeUtilisateur($l);
        }

        return $this;
    }

    /**
     * @param	TAgentRelatedByCodeUtilisateur $tAgentRelatedByCodeUtilisateur The tAgentRelatedByCodeUtilisateur object to add.
     */
    protected function doAddTAgentRelatedByCodeUtilisateur($tAgentRelatedByCodeUtilisateur)
    {
        $this->collTAgentsRelatedByCodeUtilisateur[]= $tAgentRelatedByCodeUtilisateur;
        $tAgentRelatedByCodeUtilisateur->setTTraductionRelatedByCodeUtilisateur($this);
    }

    /**
     * @param	TAgentRelatedByCodeUtilisateur $tAgentRelatedByCodeUtilisateur The tAgentRelatedByCodeUtilisateur object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTAgentRelatedByCodeUtilisateur($tAgentRelatedByCodeUtilisateur)
    {
        if ($this->getTAgentsRelatedByCodeUtilisateur()->contains($tAgentRelatedByCodeUtilisateur)) {
            $this->collTAgentsRelatedByCodeUtilisateur->remove($this->collTAgentsRelatedByCodeUtilisateur->search($tAgentRelatedByCodeUtilisateur));
            if (null === $this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion) {
                $this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion = clone $this->collTAgentsRelatedByCodeUtilisateur;
                $this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion->clear();
            }
            $this->tAgentsRelatedByCodeUtilisateurScheduledForDeletion[]= $tAgentRelatedByCodeUtilisateur;
            $tAgentRelatedByCodeUtilisateur->setTTraductionRelatedByCodeUtilisateur(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeUtilisateurJoinTEtablissementRelatedByIdEtablissementAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementAttache', $join_behavior);

        return $this->getTAgentsRelatedByCodeUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeUtilisateurJoinTEtablissementRelatedByIdEtablissementGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementGere', $join_behavior);

        return $this->getTAgentsRelatedByCodeUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeUtilisateurJoinTOrganisationRelatedByIdOrganisationAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationAttache', $join_behavior);

        return $this->getTAgentsRelatedByCodeUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeUtilisateurJoinTOrganisationRelatedByIdOrganisationGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationGere', $join_behavior);

        return $this->getTAgentsRelatedByCodeUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeUtilisateurJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgentsRelatedByCodeUtilisateur($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TAgentsRelatedByCodeUtilisateur from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsRelatedByCodeUtilisateurJoinTProfil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TProfil', $join_behavior);

        return $this->getTAgentsRelatedByCodeUtilisateur($query, $con);
    }

    /**
     * Clears out the collTChampsSupps collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTChampsSupps()
     */
    public function clearTChampsSupps()
    {
        $this->collTChampsSupps = null; // important to set this to null since that means it is uninitialized
        $this->collTChampsSuppsPartial = null;

        return $this;
    }

    /**
     * reset is the collTChampsSupps collection loaded partially
     *
     * @return void
     */
    public function resetPartialTChampsSupps($v = true)
    {
        $this->collTChampsSuppsPartial = $v;
    }

    /**
     * Initializes the collTChampsSupps collection.
     *
     * By default this just sets the collTChampsSupps collection to an empty array (like clearcollTChampsSupps());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTChampsSupps($overrideExisting = true)
    {
        if (null !== $this->collTChampsSupps && !$overrideExisting) {
            return;
        }
        $this->collTChampsSupps = new PropelObjectCollection();
        $this->collTChampsSupps->setModel('TChampsSupp');
    }

    /**
     * Gets an array of TChampsSupp objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TChampsSupp[] List of TChampsSupp objects
     * @throws PropelException
     */
    public function getTChampsSupps($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTChampsSuppsPartial && !$this->isNew();
        if (null === $this->collTChampsSupps || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTChampsSupps) {
                // return empty collection
                $this->initTChampsSupps();
            } else {
                $collTChampsSupps = TChampsSuppQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTChampsSuppsPartial && count($collTChampsSupps)) {
                      $this->initTChampsSupps(false);

                      foreach($collTChampsSupps as $obj) {
                        if (false == $this->collTChampsSupps->contains($obj)) {
                          $this->collTChampsSupps->append($obj);
                        }
                      }

                      $this->collTChampsSuppsPartial = true;
                    }

                    $collTChampsSupps->getInternalIterator()->rewind();
                    return $collTChampsSupps;
                }

                if($partial && $this->collTChampsSupps) {
                    foreach($this->collTChampsSupps as $obj) {
                        if($obj->isNew()) {
                            $collTChampsSupps[] = $obj;
                        }
                    }
                }

                $this->collTChampsSupps = $collTChampsSupps;
                $this->collTChampsSuppsPartial = false;
            }
        }

        return $this->collTChampsSupps;
    }

    /**
     * Sets a collection of TChampsSupp objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tChampsSupps A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTChampsSupps(PropelCollection $tChampsSupps, PropelPDO $con = null)
    {
        $tChampsSuppsToDelete = $this->getTChampsSupps(new Criteria(), $con)->diff($tChampsSupps);

        $this->tChampsSuppsScheduledForDeletion = unserialize(serialize($tChampsSuppsToDelete));

        foreach ($tChampsSuppsToDelete as $tChampsSuppRemoved) {
            $tChampsSuppRemoved->setTTraduction(null);
        }

        $this->collTChampsSupps = null;
        foreach ($tChampsSupps as $tChampsSupp) {
            $this->addTChampsSupp($tChampsSupp);
        }

        $this->collTChampsSupps = $tChampsSupps;
        $this->collTChampsSuppsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TChampsSupp objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TChampsSupp objects.
     * @throws PropelException
     */
    public function countTChampsSupps(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTChampsSuppsPartial && !$this->isNew();
        if (null === $this->collTChampsSupps || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTChampsSupps) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTChampsSupps());
            }
            $query = TChampsSuppQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTChampsSupps);
    }

    /**
     * Method called to associate a TChampsSupp object to this object
     * through the TChampsSupp foreign key attribute.
     *
     * @param    TChampsSupp $l TChampsSupp
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTChampsSupp(TChampsSupp $l)
    {
        if ($this->collTChampsSupps === null) {
            $this->initTChampsSupps();
            $this->collTChampsSuppsPartial = true;
        }
        if (!in_array($l, $this->collTChampsSupps->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTChampsSupp($l);
        }

        return $this;
    }

    /**
     * @param	TChampsSupp $tChampsSupp The tChampsSupp object to add.
     */
    protected function doAddTChampsSupp($tChampsSupp)
    {
        $this->collTChampsSupps[]= $tChampsSupp;
        $tChampsSupp->setTTraduction($this);
    }

    /**
     * @param	TChampsSupp $tChampsSupp The tChampsSupp object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTChampsSupp($tChampsSupp)
    {
        if ($this->getTChampsSupps()->contains($tChampsSupp)) {
            $this->collTChampsSupps->remove($this->collTChampsSupps->search($tChampsSupp));
            if (null === $this->tChampsSuppsScheduledForDeletion) {
                $this->tChampsSuppsScheduledForDeletion = clone $this->collTChampsSupps;
                $this->tChampsSuppsScheduledForDeletion->clear();
            }
            $this->tChampsSuppsScheduledForDeletion[]= clone $tChampsSupp;
            $tChampsSupp->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TChampsSupps from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TChampsSupp[] List of TChampsSupp objects
     */
    public function getTChampsSuppsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TChampsSuppQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTChampsSupps($query, $con);
    }

    /**
     * Clears out the collTEntites collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTEntites()
     */
    public function clearTEntites()
    {
        $this->collTEntites = null; // important to set this to null since that means it is uninitialized
        $this->collTEntitesPartial = null;

        return $this;
    }

    /**
     * reset is the collTEntites collection loaded partially
     *
     * @return void
     */
    public function resetPartialTEntites($v = true)
    {
        $this->collTEntitesPartial = $v;
    }

    /**
     * Initializes the collTEntites collection.
     *
     * By default this just sets the collTEntites collection to an empty array (like clearcollTEntites());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTEntites($overrideExisting = true)
    {
        if (null !== $this->collTEntites && !$overrideExisting) {
            return;
        }
        $this->collTEntites = new PropelObjectCollection();
        $this->collTEntites->setModel('TEntite');
    }

    /**
     * Gets an array of TEntite objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TEntite[] List of TEntite objects
     * @throws PropelException
     */
    public function getTEntites($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTEntitesPartial && !$this->isNew();
        if (null === $this->collTEntites || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTEntites) {
                // return empty collection
                $this->initTEntites();
            } else {
                $collTEntites = TEntiteQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTEntitesPartial && count($collTEntites)) {
                      $this->initTEntites(false);

                      foreach($collTEntites as $obj) {
                        if (false == $this->collTEntites->contains($obj)) {
                          $this->collTEntites->append($obj);
                        }
                      }

                      $this->collTEntitesPartial = true;
                    }

                    $collTEntites->getInternalIterator()->rewind();
                    return $collTEntites;
                }

                if($partial && $this->collTEntites) {
                    foreach($this->collTEntites as $obj) {
                        if($obj->isNew()) {
                            $collTEntites[] = $obj;
                        }
                    }
                }

                $this->collTEntites = $collTEntites;
                $this->collTEntitesPartial = false;
            }
        }

        return $this->collTEntites;
    }

    /**
     * Sets a collection of TEntite objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tEntites A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTEntites(PropelCollection $tEntites, PropelPDO $con = null)
    {
        $tEntitesToDelete = $this->getTEntites(new Criteria(), $con)->diff($tEntites);

        $this->tEntitesScheduledForDeletion = unserialize(serialize($tEntitesToDelete));

        foreach ($tEntitesToDelete as $tEntiteRemoved) {
            $tEntiteRemoved->setTTraduction(null);
        }

        $this->collTEntites = null;
        foreach ($tEntites as $tEntite) {
            $this->addTEntite($tEntite);
        }

        $this->collTEntites = $tEntites;
        $this->collTEntitesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TEntite objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TEntite objects.
     * @throws PropelException
     */
    public function countTEntites(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTEntitesPartial && !$this->isNew();
        if (null === $this->collTEntites || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTEntites) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTEntites());
            }
            $query = TEntiteQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTEntites);
    }

    /**
     * Method called to associate a TEntite object to this object
     * through the TEntite foreign key attribute.
     *
     * @param    TEntite $l TEntite
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTEntite(TEntite $l)
    {
        if ($this->collTEntites === null) {
            $this->initTEntites();
            $this->collTEntitesPartial = true;
        }
        if (!in_array($l, $this->collTEntites->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTEntite($l);
        }

        return $this;
    }

    /**
     * @param	TEntite $tEntite The tEntite object to add.
     */
    protected function doAddTEntite($tEntite)
    {
        $this->collTEntites[]= $tEntite;
        $tEntite->setTTraduction($this);
    }

    /**
     * @param	TEntite $tEntite The tEntite object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTEntite($tEntite)
    {
        if ($this->getTEntites()->contains($tEntite)) {
            $this->collTEntites->remove($this->collTEntites->search($tEntite));
            if (null === $this->tEntitesScheduledForDeletion) {
                $this->tEntitesScheduledForDeletion = clone $this->collTEntites;
                $this->tEntitesScheduledForDeletion->clear();
            }
            $this->tEntitesScheduledForDeletion[]= $tEntite;
            $tEntite->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEntites from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEntite[] List of TEntite objects
     */
    public function getTEntitesJoinTEntiteRelatedByIdEntiteParent($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEntiteQuery::create(null, $criteria);
        $query->joinWith('TEntiteRelatedByIdEntiteParent', $join_behavior);

        return $this->getTEntites($query, $con);
    }

    /**
     * Clears out the collTEtablissementsRelatedByCodeAdresseEtablissement collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTEtablissementsRelatedByCodeAdresseEtablissement()
     */
    public function clearTEtablissementsRelatedByCodeAdresseEtablissement()
    {
        $this->collTEtablissementsRelatedByCodeAdresseEtablissement = null; // important to set this to null since that means it is uninitialized
        $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial = null;

        return $this;
    }

    /**
     * reset is the collTEtablissementsRelatedByCodeAdresseEtablissement collection loaded partially
     *
     * @return void
     */
    public function resetPartialTEtablissementsRelatedByCodeAdresseEtablissement($v = true)
    {
        $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial = $v;
    }

    /**
     * Initializes the collTEtablissementsRelatedByCodeAdresseEtablissement collection.
     *
     * By default this just sets the collTEtablissementsRelatedByCodeAdresseEtablissement collection to an empty array (like clearcollTEtablissementsRelatedByCodeAdresseEtablissement());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTEtablissementsRelatedByCodeAdresseEtablissement($overrideExisting = true)
    {
        if (null !== $this->collTEtablissementsRelatedByCodeAdresseEtablissement && !$overrideExisting) {
            return;
        }
        $this->collTEtablissementsRelatedByCodeAdresseEtablissement = new PropelObjectCollection();
        $this->collTEtablissementsRelatedByCodeAdresseEtablissement->setModel('TEtablissement');
    }

    /**
     * Gets an array of TEtablissement objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     * @throws PropelException
     */
    public function getTEtablissementsRelatedByCodeAdresseEtablissement($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial && !$this->isNew();
        if (null === $this->collTEtablissementsRelatedByCodeAdresseEtablissement || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTEtablissementsRelatedByCodeAdresseEtablissement) {
                // return empty collection
                $this->initTEtablissementsRelatedByCodeAdresseEtablissement();
            } else {
                $collTEtablissementsRelatedByCodeAdresseEtablissement = TEtablissementQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeAdresseEtablissement($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial && count($collTEtablissementsRelatedByCodeAdresseEtablissement)) {
                      $this->initTEtablissementsRelatedByCodeAdresseEtablissement(false);

                      foreach($collTEtablissementsRelatedByCodeAdresseEtablissement as $obj) {
                        if (false == $this->collTEtablissementsRelatedByCodeAdresseEtablissement->contains($obj)) {
                          $this->collTEtablissementsRelatedByCodeAdresseEtablissement->append($obj);
                        }
                      }

                      $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial = true;
                    }

                    $collTEtablissementsRelatedByCodeAdresseEtablissement->getInternalIterator()->rewind();
                    return $collTEtablissementsRelatedByCodeAdresseEtablissement;
                }

                if($partial && $this->collTEtablissementsRelatedByCodeAdresseEtablissement) {
                    foreach($this->collTEtablissementsRelatedByCodeAdresseEtablissement as $obj) {
                        if($obj->isNew()) {
                            $collTEtablissementsRelatedByCodeAdresseEtablissement[] = $obj;
                        }
                    }
                }

                $this->collTEtablissementsRelatedByCodeAdresseEtablissement = $collTEtablissementsRelatedByCodeAdresseEtablissement;
                $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial = false;
            }
        }

        return $this->collTEtablissementsRelatedByCodeAdresseEtablissement;
    }

    /**
     * Sets a collection of TEtablissementRelatedByCodeAdresseEtablissement objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tEtablissementsRelatedByCodeAdresseEtablissement A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTEtablissementsRelatedByCodeAdresseEtablissement(PropelCollection $tEtablissementsRelatedByCodeAdresseEtablissement, PropelPDO $con = null)
    {
        $tEtablissementsRelatedByCodeAdresseEtablissementToDelete = $this->getTEtablissementsRelatedByCodeAdresseEtablissement(new Criteria(), $con)->diff($tEtablissementsRelatedByCodeAdresseEtablissement);

        $this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion = unserialize(serialize($tEtablissementsRelatedByCodeAdresseEtablissementToDelete));

        foreach ($tEtablissementsRelatedByCodeAdresseEtablissementToDelete as $tEtablissementRelatedByCodeAdresseEtablissementRemoved) {
            $tEtablissementRelatedByCodeAdresseEtablissementRemoved->setTTraductionRelatedByCodeAdresseEtablissement(null);
        }

        $this->collTEtablissementsRelatedByCodeAdresseEtablissement = null;
        foreach ($tEtablissementsRelatedByCodeAdresseEtablissement as $tEtablissementRelatedByCodeAdresseEtablissement) {
            $this->addTEtablissementRelatedByCodeAdresseEtablissement($tEtablissementRelatedByCodeAdresseEtablissement);
        }

        $this->collTEtablissementsRelatedByCodeAdresseEtablissement = $tEtablissementsRelatedByCodeAdresseEtablissement;
        $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TEtablissement objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TEtablissement objects.
     * @throws PropelException
     */
    public function countTEtablissementsRelatedByCodeAdresseEtablissement(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial && !$this->isNew();
        if (null === $this->collTEtablissementsRelatedByCodeAdresseEtablissement || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTEtablissementsRelatedByCodeAdresseEtablissement) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTEtablissementsRelatedByCodeAdresseEtablissement());
            }
            $query = TEtablissementQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeAdresseEtablissement($this)
                ->count($con);
        }

        return count($this->collTEtablissementsRelatedByCodeAdresseEtablissement);
    }

    /**
     * Method called to associate a TEtablissement object to this object
     * through the TEtablissement foreign key attribute.
     *
     * @param    TEtablissement $l TEtablissement
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTEtablissementRelatedByCodeAdresseEtablissement(TEtablissement $l)
    {
        if ($this->collTEtablissementsRelatedByCodeAdresseEtablissement === null) {
            $this->initTEtablissementsRelatedByCodeAdresseEtablissement();
            $this->collTEtablissementsRelatedByCodeAdresseEtablissementPartial = true;
        }
        if (!in_array($l, $this->collTEtablissementsRelatedByCodeAdresseEtablissement->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTEtablissementRelatedByCodeAdresseEtablissement($l);
        }

        return $this;
    }

    /**
     * @param	TEtablissementRelatedByCodeAdresseEtablissement $tEtablissementRelatedByCodeAdresseEtablissement The tEtablissementRelatedByCodeAdresseEtablissement object to add.
     */
    protected function doAddTEtablissementRelatedByCodeAdresseEtablissement($tEtablissementRelatedByCodeAdresseEtablissement)
    {
        $this->collTEtablissementsRelatedByCodeAdresseEtablissement[]= $tEtablissementRelatedByCodeAdresseEtablissement;
        $tEtablissementRelatedByCodeAdresseEtablissement->setTTraductionRelatedByCodeAdresseEtablissement($this);
    }

    /**
     * @param	TEtablissementRelatedByCodeAdresseEtablissement $tEtablissementRelatedByCodeAdresseEtablissement The tEtablissementRelatedByCodeAdresseEtablissement object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTEtablissementRelatedByCodeAdresseEtablissement($tEtablissementRelatedByCodeAdresseEtablissement)
    {
        if ($this->getTEtablissementsRelatedByCodeAdresseEtablissement()->contains($tEtablissementRelatedByCodeAdresseEtablissement)) {
            $this->collTEtablissementsRelatedByCodeAdresseEtablissement->remove($this->collTEtablissementsRelatedByCodeAdresseEtablissement->search($tEtablissementRelatedByCodeAdresseEtablissement));
            if (null === $this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion) {
                $this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion = clone $this->collTEtablissementsRelatedByCodeAdresseEtablissement;
                $this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion->clear();
            }
            $this->tEtablissementsRelatedByCodeAdresseEtablissementScheduledForDeletion[]= $tEtablissementRelatedByCodeAdresseEtablissement;
            $tEtablissementRelatedByCodeAdresseEtablissement->setTTraductionRelatedByCodeAdresseEtablissement(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeAdresseEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeAdresseEtablissementJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeAdresseEtablissement($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeAdresseEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeAdresseEtablissementJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeAdresseEtablissement($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeAdresseEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeAdresseEtablissementJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeAdresseEtablissement($query, $con);
    }

    /**
     * Clears out the collTEtablissementsRelatedByCodeDenominationEtablissement collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTEtablissementsRelatedByCodeDenominationEtablissement()
     */
    public function clearTEtablissementsRelatedByCodeDenominationEtablissement()
    {
        $this->collTEtablissementsRelatedByCodeDenominationEtablissement = null; // important to set this to null since that means it is uninitialized
        $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial = null;

        return $this;
    }

    /**
     * reset is the collTEtablissementsRelatedByCodeDenominationEtablissement collection loaded partially
     *
     * @return void
     */
    public function resetPartialTEtablissementsRelatedByCodeDenominationEtablissement($v = true)
    {
        $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial = $v;
    }

    /**
     * Initializes the collTEtablissementsRelatedByCodeDenominationEtablissement collection.
     *
     * By default this just sets the collTEtablissementsRelatedByCodeDenominationEtablissement collection to an empty array (like clearcollTEtablissementsRelatedByCodeDenominationEtablissement());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTEtablissementsRelatedByCodeDenominationEtablissement($overrideExisting = true)
    {
        if (null !== $this->collTEtablissementsRelatedByCodeDenominationEtablissement && !$overrideExisting) {
            return;
        }
        $this->collTEtablissementsRelatedByCodeDenominationEtablissement = new PropelObjectCollection();
        $this->collTEtablissementsRelatedByCodeDenominationEtablissement->setModel('TEtablissement');
    }

    /**
     * Gets an array of TEtablissement objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     * @throws PropelException
     */
    public function getTEtablissementsRelatedByCodeDenominationEtablissement($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial && !$this->isNew();
        if (null === $this->collTEtablissementsRelatedByCodeDenominationEtablissement || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTEtablissementsRelatedByCodeDenominationEtablissement) {
                // return empty collection
                $this->initTEtablissementsRelatedByCodeDenominationEtablissement();
            } else {
                $collTEtablissementsRelatedByCodeDenominationEtablissement = TEtablissementQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeDenominationEtablissement($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial && count($collTEtablissementsRelatedByCodeDenominationEtablissement)) {
                      $this->initTEtablissementsRelatedByCodeDenominationEtablissement(false);

                      foreach($collTEtablissementsRelatedByCodeDenominationEtablissement as $obj) {
                        if (false == $this->collTEtablissementsRelatedByCodeDenominationEtablissement->contains($obj)) {
                          $this->collTEtablissementsRelatedByCodeDenominationEtablissement->append($obj);
                        }
                      }

                      $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial = true;
                    }

                    $collTEtablissementsRelatedByCodeDenominationEtablissement->getInternalIterator()->rewind();
                    return $collTEtablissementsRelatedByCodeDenominationEtablissement;
                }

                if($partial && $this->collTEtablissementsRelatedByCodeDenominationEtablissement) {
                    foreach($this->collTEtablissementsRelatedByCodeDenominationEtablissement as $obj) {
                        if($obj->isNew()) {
                            $collTEtablissementsRelatedByCodeDenominationEtablissement[] = $obj;
                        }
                    }
                }

                $this->collTEtablissementsRelatedByCodeDenominationEtablissement = $collTEtablissementsRelatedByCodeDenominationEtablissement;
                $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial = false;
            }
        }

        return $this->collTEtablissementsRelatedByCodeDenominationEtablissement;
    }

    /**
     * Sets a collection of TEtablissementRelatedByCodeDenominationEtablissement objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tEtablissementsRelatedByCodeDenominationEtablissement A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTEtablissementsRelatedByCodeDenominationEtablissement(PropelCollection $tEtablissementsRelatedByCodeDenominationEtablissement, PropelPDO $con = null)
    {
        $tEtablissementsRelatedByCodeDenominationEtablissementToDelete = $this->getTEtablissementsRelatedByCodeDenominationEtablissement(new Criteria(), $con)->diff($tEtablissementsRelatedByCodeDenominationEtablissement);

        $this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion = unserialize(serialize($tEtablissementsRelatedByCodeDenominationEtablissementToDelete));

        foreach ($tEtablissementsRelatedByCodeDenominationEtablissementToDelete as $tEtablissementRelatedByCodeDenominationEtablissementRemoved) {
            $tEtablissementRelatedByCodeDenominationEtablissementRemoved->setTTraductionRelatedByCodeDenominationEtablissement(null);
        }

        $this->collTEtablissementsRelatedByCodeDenominationEtablissement = null;
        foreach ($tEtablissementsRelatedByCodeDenominationEtablissement as $tEtablissementRelatedByCodeDenominationEtablissement) {
            $this->addTEtablissementRelatedByCodeDenominationEtablissement($tEtablissementRelatedByCodeDenominationEtablissement);
        }

        $this->collTEtablissementsRelatedByCodeDenominationEtablissement = $tEtablissementsRelatedByCodeDenominationEtablissement;
        $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TEtablissement objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TEtablissement objects.
     * @throws PropelException
     */
    public function countTEtablissementsRelatedByCodeDenominationEtablissement(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial && !$this->isNew();
        if (null === $this->collTEtablissementsRelatedByCodeDenominationEtablissement || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTEtablissementsRelatedByCodeDenominationEtablissement) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTEtablissementsRelatedByCodeDenominationEtablissement());
            }
            $query = TEtablissementQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeDenominationEtablissement($this)
                ->count($con);
        }

        return count($this->collTEtablissementsRelatedByCodeDenominationEtablissement);
    }

    /**
     * Method called to associate a TEtablissement object to this object
     * through the TEtablissement foreign key attribute.
     *
     * @param    TEtablissement $l TEtablissement
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTEtablissementRelatedByCodeDenominationEtablissement(TEtablissement $l)
    {
        if ($this->collTEtablissementsRelatedByCodeDenominationEtablissement === null) {
            $this->initTEtablissementsRelatedByCodeDenominationEtablissement();
            $this->collTEtablissementsRelatedByCodeDenominationEtablissementPartial = true;
        }
        if (!in_array($l, $this->collTEtablissementsRelatedByCodeDenominationEtablissement->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTEtablissementRelatedByCodeDenominationEtablissement($l);
        }

        return $this;
    }

    /**
     * @param	TEtablissementRelatedByCodeDenominationEtablissement $tEtablissementRelatedByCodeDenominationEtablissement The tEtablissementRelatedByCodeDenominationEtablissement object to add.
     */
    protected function doAddTEtablissementRelatedByCodeDenominationEtablissement($tEtablissementRelatedByCodeDenominationEtablissement)
    {
        $this->collTEtablissementsRelatedByCodeDenominationEtablissement[]= $tEtablissementRelatedByCodeDenominationEtablissement;
        $tEtablissementRelatedByCodeDenominationEtablissement->setTTraductionRelatedByCodeDenominationEtablissement($this);
    }

    /**
     * @param	TEtablissementRelatedByCodeDenominationEtablissement $tEtablissementRelatedByCodeDenominationEtablissement The tEtablissementRelatedByCodeDenominationEtablissement object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTEtablissementRelatedByCodeDenominationEtablissement($tEtablissementRelatedByCodeDenominationEtablissement)
    {
        if ($this->getTEtablissementsRelatedByCodeDenominationEtablissement()->contains($tEtablissementRelatedByCodeDenominationEtablissement)) {
            $this->collTEtablissementsRelatedByCodeDenominationEtablissement->remove($this->collTEtablissementsRelatedByCodeDenominationEtablissement->search($tEtablissementRelatedByCodeDenominationEtablissement));
            if (null === $this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion) {
                $this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion = clone $this->collTEtablissementsRelatedByCodeDenominationEtablissement;
                $this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion->clear();
            }
            $this->tEtablissementsRelatedByCodeDenominationEtablissementScheduledForDeletion[]= $tEtablissementRelatedByCodeDenominationEtablissement;
            $tEtablissementRelatedByCodeDenominationEtablissement->setTTraductionRelatedByCodeDenominationEtablissement(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeDenominationEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeDenominationEtablissementJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeDenominationEtablissement($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeDenominationEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeDenominationEtablissementJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeDenominationEtablissement($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeDenominationEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeDenominationEtablissementJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeDenominationEtablissement($query, $con);
    }

    /**
     * Clears out the collTEtablissementsRelatedByCodeDescriptionEtablissement collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTEtablissementsRelatedByCodeDescriptionEtablissement()
     */
    public function clearTEtablissementsRelatedByCodeDescriptionEtablissement()
    {
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissement = null; // important to set this to null since that means it is uninitialized
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial = null;

        return $this;
    }

    /**
     * reset is the collTEtablissementsRelatedByCodeDescriptionEtablissement collection loaded partially
     *
     * @return void
     */
    public function resetPartialTEtablissementsRelatedByCodeDescriptionEtablissement($v = true)
    {
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial = $v;
    }

    /**
     * Initializes the collTEtablissementsRelatedByCodeDescriptionEtablissement collection.
     *
     * By default this just sets the collTEtablissementsRelatedByCodeDescriptionEtablissement collection to an empty array (like clearcollTEtablissementsRelatedByCodeDescriptionEtablissement());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTEtablissementsRelatedByCodeDescriptionEtablissement($overrideExisting = true)
    {
        if (null !== $this->collTEtablissementsRelatedByCodeDescriptionEtablissement && !$overrideExisting) {
            return;
        }
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissement = new PropelObjectCollection();
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissement->setModel('TEtablissement');
    }

    /**
     * Gets an array of TEtablissement objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     * @throws PropelException
     */
    public function getTEtablissementsRelatedByCodeDescriptionEtablissement($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial && !$this->isNew();
        if (null === $this->collTEtablissementsRelatedByCodeDescriptionEtablissement || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTEtablissementsRelatedByCodeDescriptionEtablissement) {
                // return empty collection
                $this->initTEtablissementsRelatedByCodeDescriptionEtablissement();
            } else {
                $collTEtablissementsRelatedByCodeDescriptionEtablissement = TEtablissementQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeDescriptionEtablissement($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial && count($collTEtablissementsRelatedByCodeDescriptionEtablissement)) {
                      $this->initTEtablissementsRelatedByCodeDescriptionEtablissement(false);

                      foreach($collTEtablissementsRelatedByCodeDescriptionEtablissement as $obj) {
                        if (false == $this->collTEtablissementsRelatedByCodeDescriptionEtablissement->contains($obj)) {
                          $this->collTEtablissementsRelatedByCodeDescriptionEtablissement->append($obj);
                        }
                      }

                      $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial = true;
                    }

                    $collTEtablissementsRelatedByCodeDescriptionEtablissement->getInternalIterator()->rewind();
                    return $collTEtablissementsRelatedByCodeDescriptionEtablissement;
                }

                if($partial && $this->collTEtablissementsRelatedByCodeDescriptionEtablissement) {
                    foreach($this->collTEtablissementsRelatedByCodeDescriptionEtablissement as $obj) {
                        if($obj->isNew()) {
                            $collTEtablissementsRelatedByCodeDescriptionEtablissement[] = $obj;
                        }
                    }
                }

                $this->collTEtablissementsRelatedByCodeDescriptionEtablissement = $collTEtablissementsRelatedByCodeDescriptionEtablissement;
                $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial = false;
            }
        }

        return $this->collTEtablissementsRelatedByCodeDescriptionEtablissement;
    }

    /**
     * Sets a collection of TEtablissementRelatedByCodeDescriptionEtablissement objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tEtablissementsRelatedByCodeDescriptionEtablissement A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTEtablissementsRelatedByCodeDescriptionEtablissement(PropelCollection $tEtablissementsRelatedByCodeDescriptionEtablissement, PropelPDO $con = null)
    {
        $tEtablissementsRelatedByCodeDescriptionEtablissementToDelete = $this->getTEtablissementsRelatedByCodeDescriptionEtablissement(new Criteria(), $con)->diff($tEtablissementsRelatedByCodeDescriptionEtablissement);

        $this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion = unserialize(serialize($tEtablissementsRelatedByCodeDescriptionEtablissementToDelete));

        foreach ($tEtablissementsRelatedByCodeDescriptionEtablissementToDelete as $tEtablissementRelatedByCodeDescriptionEtablissementRemoved) {
            $tEtablissementRelatedByCodeDescriptionEtablissementRemoved->setTTraductionRelatedByCodeDescriptionEtablissement(null);
        }

        $this->collTEtablissementsRelatedByCodeDescriptionEtablissement = null;
        foreach ($tEtablissementsRelatedByCodeDescriptionEtablissement as $tEtablissementRelatedByCodeDescriptionEtablissement) {
            $this->addTEtablissementRelatedByCodeDescriptionEtablissement($tEtablissementRelatedByCodeDescriptionEtablissement);
        }

        $this->collTEtablissementsRelatedByCodeDescriptionEtablissement = $tEtablissementsRelatedByCodeDescriptionEtablissement;
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TEtablissement objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TEtablissement objects.
     * @throws PropelException
     */
    public function countTEtablissementsRelatedByCodeDescriptionEtablissement(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial && !$this->isNew();
        if (null === $this->collTEtablissementsRelatedByCodeDescriptionEtablissement || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTEtablissementsRelatedByCodeDescriptionEtablissement) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTEtablissementsRelatedByCodeDescriptionEtablissement());
            }
            $query = TEtablissementQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeDescriptionEtablissement($this)
                ->count($con);
        }

        return count($this->collTEtablissementsRelatedByCodeDescriptionEtablissement);
    }

    /**
     * Method called to associate a TEtablissement object to this object
     * through the TEtablissement foreign key attribute.
     *
     * @param    TEtablissement $l TEtablissement
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTEtablissementRelatedByCodeDescriptionEtablissement(TEtablissement $l)
    {
        if ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement === null) {
            $this->initTEtablissementsRelatedByCodeDescriptionEtablissement();
            $this->collTEtablissementsRelatedByCodeDescriptionEtablissementPartial = true;
        }
        if (!in_array($l, $this->collTEtablissementsRelatedByCodeDescriptionEtablissement->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTEtablissementRelatedByCodeDescriptionEtablissement($l);
        }

        return $this;
    }

    /**
     * @param	TEtablissementRelatedByCodeDescriptionEtablissement $tEtablissementRelatedByCodeDescriptionEtablissement The tEtablissementRelatedByCodeDescriptionEtablissement object to add.
     */
    protected function doAddTEtablissementRelatedByCodeDescriptionEtablissement($tEtablissementRelatedByCodeDescriptionEtablissement)
    {
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissement[]= $tEtablissementRelatedByCodeDescriptionEtablissement;
        $tEtablissementRelatedByCodeDescriptionEtablissement->setTTraductionRelatedByCodeDescriptionEtablissement($this);
    }

    /**
     * @param	TEtablissementRelatedByCodeDescriptionEtablissement $tEtablissementRelatedByCodeDescriptionEtablissement The tEtablissementRelatedByCodeDescriptionEtablissement object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTEtablissementRelatedByCodeDescriptionEtablissement($tEtablissementRelatedByCodeDescriptionEtablissement)
    {
        if ($this->getTEtablissementsRelatedByCodeDescriptionEtablissement()->contains($tEtablissementRelatedByCodeDescriptionEtablissement)) {
            $this->collTEtablissementsRelatedByCodeDescriptionEtablissement->remove($this->collTEtablissementsRelatedByCodeDescriptionEtablissement->search($tEtablissementRelatedByCodeDescriptionEtablissement));
            if (null === $this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion) {
                $this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion = clone $this->collTEtablissementsRelatedByCodeDescriptionEtablissement;
                $this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion->clear();
            }
            $this->tEtablissementsRelatedByCodeDescriptionEtablissementScheduledForDeletion[]= $tEtablissementRelatedByCodeDescriptionEtablissement;
            $tEtablissementRelatedByCodeDescriptionEtablissement->setTTraductionRelatedByCodeDescriptionEtablissement(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeDescriptionEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeDescriptionEtablissementJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeDescriptionEtablissement($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeDescriptionEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeDescriptionEtablissementJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeDescriptionEtablissement($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TEtablissementsRelatedByCodeDescriptionEtablissement from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TEtablissement[] List of TEtablissement objects
     */
    public function getTEtablissementsRelatedByCodeDescriptionEtablissementJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TEtablissementQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTEtablissementsRelatedByCodeDescriptionEtablissement($query, $con);
    }

    /**
     * Clears out the collTGroupes collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTGroupes()
     */
    public function clearTGroupes()
    {
        $this->collTGroupes = null; // important to set this to null since that means it is uninitialized
        $this->collTGroupesPartial = null;

        return $this;
    }

    /**
     * reset is the collTGroupes collection loaded partially
     *
     * @return void
     */
    public function resetPartialTGroupes($v = true)
    {
        $this->collTGroupesPartial = $v;
    }

    /**
     * Initializes the collTGroupes collection.
     *
     * By default this just sets the collTGroupes collection to an empty array (like clearcollTGroupes());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTGroupes($overrideExisting = true)
    {
        if (null !== $this->collTGroupes && !$overrideExisting) {
            return;
        }
        $this->collTGroupes = new PropelObjectCollection();
        $this->collTGroupes->setModel('TGroupe');
    }

    /**
     * Gets an array of TGroupe objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TGroupe[] List of TGroupe objects
     * @throws PropelException
     */
    public function getTGroupes($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTGroupesPartial && !$this->isNew();
        if (null === $this->collTGroupes || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTGroupes) {
                // return empty collection
                $this->initTGroupes();
            } else {
                $collTGroupes = TGroupeQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTGroupesPartial && count($collTGroupes)) {
                      $this->initTGroupes(false);

                      foreach($collTGroupes as $obj) {
                        if (false == $this->collTGroupes->contains($obj)) {
                          $this->collTGroupes->append($obj);
                        }
                      }

                      $this->collTGroupesPartial = true;
                    }

                    $collTGroupes->getInternalIterator()->rewind();
                    return $collTGroupes;
                }

                if($partial && $this->collTGroupes) {
                    foreach($this->collTGroupes as $obj) {
                        if($obj->isNew()) {
                            $collTGroupes[] = $obj;
                        }
                    }
                }

                $this->collTGroupes = $collTGroupes;
                $this->collTGroupesPartial = false;
            }
        }

        return $this->collTGroupes;
    }

    /**
     * Sets a collection of TGroupe objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tGroupes A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTGroupes(PropelCollection $tGroupes, PropelPDO $con = null)
    {
        $tGroupesToDelete = $this->getTGroupes(new Criteria(), $con)->diff($tGroupes);

        $this->tGroupesScheduledForDeletion = unserialize(serialize($tGroupesToDelete));

        foreach ($tGroupesToDelete as $tGroupeRemoved) {
            $tGroupeRemoved->setTTraduction(null);
        }

        $this->collTGroupes = null;
        foreach ($tGroupes as $tGroupe) {
            $this->addTGroupe($tGroupe);
        }

        $this->collTGroupes = $tGroupes;
        $this->collTGroupesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TGroupe objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TGroupe objects.
     * @throws PropelException
     */
    public function countTGroupes(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTGroupesPartial && !$this->isNew();
        if (null === $this->collTGroupes || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTGroupes) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTGroupes());
            }
            $query = TGroupeQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTGroupes);
    }

    /**
     * Method called to associate a TGroupe object to this object
     * through the TGroupe foreign key attribute.
     *
     * @param    TGroupe $l TGroupe
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTGroupe(TGroupe $l)
    {
        if ($this->collTGroupes === null) {
            $this->initTGroupes();
            $this->collTGroupesPartial = true;
        }
        if (!in_array($l, $this->collTGroupes->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTGroupe($l);
        }

        return $this;
    }

    /**
     * @param	TGroupe $tGroupe The tGroupe object to add.
     */
    protected function doAddTGroupe($tGroupe)
    {
        $this->collTGroupes[]= $tGroupe;
        $tGroupe->setTTraduction($this);
    }

    /**
     * @param	TGroupe $tGroupe The tGroupe object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTGroupe($tGroupe)
    {
        if ($this->getTGroupes()->contains($tGroupe)) {
            $this->collTGroupes->remove($this->collTGroupes->search($tGroupe));
            if (null === $this->tGroupesScheduledForDeletion) {
                $this->tGroupesScheduledForDeletion = clone $this->collTGroupes;
                $this->tGroupesScheduledForDeletion->clear();
            }
            $this->tGroupesScheduledForDeletion[]= $tGroupe;
            $tGroupe->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TGroupes from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TGroupe[] List of TGroupe objects
     */
    public function getTGroupesJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TGroupeQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTGroupes($query, $con);
    }

    /**
     * Clears out the collTJourFeries collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTJourFeries()
     */
    public function clearTJourFeries()
    {
        $this->collTJourFeries = null; // important to set this to null since that means it is uninitialized
        $this->collTJourFeriesPartial = null;

        return $this;
    }

    /**
     * reset is the collTJourFeries collection loaded partially
     *
     * @return void
     */
    public function resetPartialTJourFeries($v = true)
    {
        $this->collTJourFeriesPartial = $v;
    }

    /**
     * Initializes the collTJourFeries collection.
     *
     * By default this just sets the collTJourFeries collection to an empty array (like clearcollTJourFeries());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTJourFeries($overrideExisting = true)
    {
        if (null !== $this->collTJourFeries && !$overrideExisting) {
            return;
        }
        $this->collTJourFeries = new PropelObjectCollection();
        $this->collTJourFeries->setModel('TJourFerie');
    }

    /**
     * Gets an array of TJourFerie objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TJourFerie[] List of TJourFerie objects
     * @throws PropelException
     */
    public function getTJourFeries($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTJourFeriesPartial && !$this->isNew();
        if (null === $this->collTJourFeries || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTJourFeries) {
                // return empty collection
                $this->initTJourFeries();
            } else {
                $collTJourFeries = TJourFerieQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTJourFeriesPartial && count($collTJourFeries)) {
                      $this->initTJourFeries(false);

                      foreach($collTJourFeries as $obj) {
                        if (false == $this->collTJourFeries->contains($obj)) {
                          $this->collTJourFeries->append($obj);
                        }
                      }

                      $this->collTJourFeriesPartial = true;
                    }

                    $collTJourFeries->getInternalIterator()->rewind();
                    return $collTJourFeries;
                }

                if($partial && $this->collTJourFeries) {
                    foreach($this->collTJourFeries as $obj) {
                        if($obj->isNew()) {
                            $collTJourFeries[] = $obj;
                        }
                    }
                }

                $this->collTJourFeries = $collTJourFeries;
                $this->collTJourFeriesPartial = false;
            }
        }

        return $this->collTJourFeries;
    }

    /**
     * Sets a collection of TJourFerie objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tJourFeries A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTJourFeries(PropelCollection $tJourFeries, PropelPDO $con = null)
    {
        $tJourFeriesToDelete = $this->getTJourFeries(new Criteria(), $con)->diff($tJourFeries);

        $this->tJourFeriesScheduledForDeletion = unserialize(serialize($tJourFeriesToDelete));

        foreach ($tJourFeriesToDelete as $tJourFerieRemoved) {
            $tJourFerieRemoved->setTTraduction(null);
        }

        $this->collTJourFeries = null;
        foreach ($tJourFeries as $tJourFerie) {
            $this->addTJourFerie($tJourFerie);
        }

        $this->collTJourFeries = $tJourFeries;
        $this->collTJourFeriesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TJourFerie objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TJourFerie objects.
     * @throws PropelException
     */
    public function countTJourFeries(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTJourFeriesPartial && !$this->isNew();
        if (null === $this->collTJourFeries || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTJourFeries) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTJourFeries());
            }
            $query = TJourFerieQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTJourFeries);
    }

    /**
     * Method called to associate a TJourFerie object to this object
     * through the TJourFerie foreign key attribute.
     *
     * @param    TJourFerie $l TJourFerie
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTJourFerie(TJourFerie $l)
    {
        if ($this->collTJourFeries === null) {
            $this->initTJourFeries();
            $this->collTJourFeriesPartial = true;
        }
        if (!in_array($l, $this->collTJourFeries->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTJourFerie($l);
        }

        return $this;
    }

    /**
     * @param	TJourFerie $tJourFerie The tJourFerie object to add.
     */
    protected function doAddTJourFerie($tJourFerie)
    {
        $this->collTJourFeries[]= $tJourFerie;
        $tJourFerie->setTTraduction($this);
    }

    /**
     * @param	TJourFerie $tJourFerie The tJourFerie object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTJourFerie($tJourFerie)
    {
        if ($this->getTJourFeries()->contains($tJourFerie)) {
            $this->collTJourFeries->remove($this->collTJourFeries->search($tJourFerie));
            if (null === $this->tJourFeriesScheduledForDeletion) {
                $this->tJourFeriesScheduledForDeletion = clone $this->collTJourFeries;
                $this->tJourFeriesScheduledForDeletion->clear();
            }
            $this->tJourFeriesScheduledForDeletion[]= $tJourFerie;
            $tJourFerie->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TJourFeries from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TJourFerie[] List of TJourFerie objects
     */
    public function getTJourFeriesJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TJourFerieQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTJourFeries($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeAdresseOrganisation collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeAdresseOrganisation()
     */
    public function clearTOrganisationsRelatedByCodeAdresseOrganisation()
    {
        $this->collTOrganisationsRelatedByCodeAdresseOrganisation = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeAdresseOrganisation collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeAdresseOrganisation($v = true)
    {
        $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeAdresseOrganisation collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeAdresseOrganisation collection to an empty array (like clearcollTOrganisationsRelatedByCodeAdresseOrganisation());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeAdresseOrganisation($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeAdresseOrganisation && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeAdresseOrganisation = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeAdresseOrganisation->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeAdresseOrganisation($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeAdresseOrganisation || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeAdresseOrganisation) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeAdresseOrganisation();
            } else {
                $collTOrganisationsRelatedByCodeAdresseOrganisation = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeAdresseOrganisation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial && count($collTOrganisationsRelatedByCodeAdresseOrganisation)) {
                      $this->initTOrganisationsRelatedByCodeAdresseOrganisation(false);

                      foreach($collTOrganisationsRelatedByCodeAdresseOrganisation as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeAdresseOrganisation->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeAdresseOrganisation->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial = true;
                    }

                    $collTOrganisationsRelatedByCodeAdresseOrganisation->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeAdresseOrganisation;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeAdresseOrganisation) {
                    foreach($this->collTOrganisationsRelatedByCodeAdresseOrganisation as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeAdresseOrganisation[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeAdresseOrganisation = $collTOrganisationsRelatedByCodeAdresseOrganisation;
                $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeAdresseOrganisation;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeAdresseOrganisation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeAdresseOrganisation A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeAdresseOrganisation(PropelCollection $tOrganisationsRelatedByCodeAdresseOrganisation, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeAdresseOrganisationToDelete = $this->getTOrganisationsRelatedByCodeAdresseOrganisation(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeAdresseOrganisation);

        $this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeAdresseOrganisationToDelete));

        foreach ($tOrganisationsRelatedByCodeAdresseOrganisationToDelete as $tOrganisationRelatedByCodeAdresseOrganisationRemoved) {
            $tOrganisationRelatedByCodeAdresseOrganisationRemoved->setTTraductionRelatedByCodeAdresseOrganisation(null);
        }

        $this->collTOrganisationsRelatedByCodeAdresseOrganisation = null;
        foreach ($tOrganisationsRelatedByCodeAdresseOrganisation as $tOrganisationRelatedByCodeAdresseOrganisation) {
            $this->addTOrganisationRelatedByCodeAdresseOrganisation($tOrganisationRelatedByCodeAdresseOrganisation);
        }

        $this->collTOrganisationsRelatedByCodeAdresseOrganisation = $tOrganisationsRelatedByCodeAdresseOrganisation;
        $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeAdresseOrganisation(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeAdresseOrganisation || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeAdresseOrganisation) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeAdresseOrganisation());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeAdresseOrganisation($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeAdresseOrganisation);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeAdresseOrganisation(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeAdresseOrganisation === null) {
            $this->initTOrganisationsRelatedByCodeAdresseOrganisation();
            $this->collTOrganisationsRelatedByCodeAdresseOrganisationPartial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeAdresseOrganisation->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeAdresseOrganisation($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeAdresseOrganisation $tOrganisationRelatedByCodeAdresseOrganisation The tOrganisationRelatedByCodeAdresseOrganisation object to add.
     */
    protected function doAddTOrganisationRelatedByCodeAdresseOrganisation($tOrganisationRelatedByCodeAdresseOrganisation)
    {
        $this->collTOrganisationsRelatedByCodeAdresseOrganisation[]= $tOrganisationRelatedByCodeAdresseOrganisation;
        $tOrganisationRelatedByCodeAdresseOrganisation->setTTraductionRelatedByCodeAdresseOrganisation($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeAdresseOrganisation $tOrganisationRelatedByCodeAdresseOrganisation The tOrganisationRelatedByCodeAdresseOrganisation object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeAdresseOrganisation($tOrganisationRelatedByCodeAdresseOrganisation)
    {
        if ($this->getTOrganisationsRelatedByCodeAdresseOrganisation()->contains($tOrganisationRelatedByCodeAdresseOrganisation)) {
            $this->collTOrganisationsRelatedByCodeAdresseOrganisation->remove($this->collTOrganisationsRelatedByCodeAdresseOrganisation->search($tOrganisationRelatedByCodeAdresseOrganisation));
            if (null === $this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeAdresseOrganisation;
                $this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeAdresseOrganisationScheduledForDeletion[]= $tOrganisationRelatedByCodeAdresseOrganisation;
            $tOrganisationRelatedByCodeAdresseOrganisation->setTTraductionRelatedByCodeAdresseOrganisation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeAdresseOrganisation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeAdresseOrganisationJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeAdresseOrganisation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeAdresseOrganisation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeAdresseOrganisationJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeAdresseOrganisation($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeDenominationOrganisation collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeDenominationOrganisation()
     */
    public function clearTOrganisationsRelatedByCodeDenominationOrganisation()
    {
        $this->collTOrganisationsRelatedByCodeDenominationOrganisation = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeDenominationOrganisation collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeDenominationOrganisation($v = true)
    {
        $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeDenominationOrganisation collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeDenominationOrganisation collection to an empty array (like clearcollTOrganisationsRelatedByCodeDenominationOrganisation());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeDenominationOrganisation($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeDenominationOrganisation && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeDenominationOrganisation = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeDenominationOrganisation->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeDenominationOrganisation($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeDenominationOrganisation || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeDenominationOrganisation) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeDenominationOrganisation();
            } else {
                $collTOrganisationsRelatedByCodeDenominationOrganisation = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeDenominationOrganisation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial && count($collTOrganisationsRelatedByCodeDenominationOrganisation)) {
                      $this->initTOrganisationsRelatedByCodeDenominationOrganisation(false);

                      foreach($collTOrganisationsRelatedByCodeDenominationOrganisation as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeDenominationOrganisation->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeDenominationOrganisation->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial = true;
                    }

                    $collTOrganisationsRelatedByCodeDenominationOrganisation->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeDenominationOrganisation;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeDenominationOrganisation) {
                    foreach($this->collTOrganisationsRelatedByCodeDenominationOrganisation as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeDenominationOrganisation[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeDenominationOrganisation = $collTOrganisationsRelatedByCodeDenominationOrganisation;
                $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeDenominationOrganisation;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeDenominationOrganisation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeDenominationOrganisation A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeDenominationOrganisation(PropelCollection $tOrganisationsRelatedByCodeDenominationOrganisation, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeDenominationOrganisationToDelete = $this->getTOrganisationsRelatedByCodeDenominationOrganisation(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeDenominationOrganisation);

        $this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeDenominationOrganisationToDelete));

        foreach ($tOrganisationsRelatedByCodeDenominationOrganisationToDelete as $tOrganisationRelatedByCodeDenominationOrganisationRemoved) {
            $tOrganisationRelatedByCodeDenominationOrganisationRemoved->setTTraductionRelatedByCodeDenominationOrganisation(null);
        }

        $this->collTOrganisationsRelatedByCodeDenominationOrganisation = null;
        foreach ($tOrganisationsRelatedByCodeDenominationOrganisation as $tOrganisationRelatedByCodeDenominationOrganisation) {
            $this->addTOrganisationRelatedByCodeDenominationOrganisation($tOrganisationRelatedByCodeDenominationOrganisation);
        }

        $this->collTOrganisationsRelatedByCodeDenominationOrganisation = $tOrganisationsRelatedByCodeDenominationOrganisation;
        $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeDenominationOrganisation(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeDenominationOrganisation || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeDenominationOrganisation) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeDenominationOrganisation());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeDenominationOrganisation($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeDenominationOrganisation);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeDenominationOrganisation(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeDenominationOrganisation === null) {
            $this->initTOrganisationsRelatedByCodeDenominationOrganisation();
            $this->collTOrganisationsRelatedByCodeDenominationOrganisationPartial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeDenominationOrganisation->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeDenominationOrganisation($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeDenominationOrganisation $tOrganisationRelatedByCodeDenominationOrganisation The tOrganisationRelatedByCodeDenominationOrganisation object to add.
     */
    protected function doAddTOrganisationRelatedByCodeDenominationOrganisation($tOrganisationRelatedByCodeDenominationOrganisation)
    {
        $this->collTOrganisationsRelatedByCodeDenominationOrganisation[]= $tOrganisationRelatedByCodeDenominationOrganisation;
        $tOrganisationRelatedByCodeDenominationOrganisation->setTTraductionRelatedByCodeDenominationOrganisation($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeDenominationOrganisation $tOrganisationRelatedByCodeDenominationOrganisation The tOrganisationRelatedByCodeDenominationOrganisation object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeDenominationOrganisation($tOrganisationRelatedByCodeDenominationOrganisation)
    {
        if ($this->getTOrganisationsRelatedByCodeDenominationOrganisation()->contains($tOrganisationRelatedByCodeDenominationOrganisation)) {
            $this->collTOrganisationsRelatedByCodeDenominationOrganisation->remove($this->collTOrganisationsRelatedByCodeDenominationOrganisation->search($tOrganisationRelatedByCodeDenominationOrganisation));
            if (null === $this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeDenominationOrganisation;
                $this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeDenominationOrganisationScheduledForDeletion[]= $tOrganisationRelatedByCodeDenominationOrganisation;
            $tOrganisationRelatedByCodeDenominationOrganisation->setTTraductionRelatedByCodeDenominationOrganisation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeDenominationOrganisation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeDenominationOrganisationJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeDenominationOrganisation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeDenominationOrganisation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeDenominationOrganisationJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeDenominationOrganisation($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeDescriptionOrganisation collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeDescriptionOrganisation()
     */
    public function clearTOrganisationsRelatedByCodeDescriptionOrganisation()
    {
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisation = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeDescriptionOrganisation collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeDescriptionOrganisation($v = true)
    {
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeDescriptionOrganisation collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeDescriptionOrganisation collection to an empty array (like clearcollTOrganisationsRelatedByCodeDescriptionOrganisation());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeDescriptionOrganisation($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeDescriptionOrganisation && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisation = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisation->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeDescriptionOrganisation($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeDescriptionOrganisation || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeDescriptionOrganisation) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeDescriptionOrganisation();
            } else {
                $collTOrganisationsRelatedByCodeDescriptionOrganisation = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeDescriptionOrganisation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial && count($collTOrganisationsRelatedByCodeDescriptionOrganisation)) {
                      $this->initTOrganisationsRelatedByCodeDescriptionOrganisation(false);

                      foreach($collTOrganisationsRelatedByCodeDescriptionOrganisation as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeDescriptionOrganisation->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeDescriptionOrganisation->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial = true;
                    }

                    $collTOrganisationsRelatedByCodeDescriptionOrganisation->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeDescriptionOrganisation;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeDescriptionOrganisation) {
                    foreach($this->collTOrganisationsRelatedByCodeDescriptionOrganisation as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeDescriptionOrganisation[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeDescriptionOrganisation = $collTOrganisationsRelatedByCodeDescriptionOrganisation;
                $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeDescriptionOrganisation;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeDescriptionOrganisation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeDescriptionOrganisation A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeDescriptionOrganisation(PropelCollection $tOrganisationsRelatedByCodeDescriptionOrganisation, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeDescriptionOrganisationToDelete = $this->getTOrganisationsRelatedByCodeDescriptionOrganisation(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeDescriptionOrganisation);

        $this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeDescriptionOrganisationToDelete));

        foreach ($tOrganisationsRelatedByCodeDescriptionOrganisationToDelete as $tOrganisationRelatedByCodeDescriptionOrganisationRemoved) {
            $tOrganisationRelatedByCodeDescriptionOrganisationRemoved->setTTraductionRelatedByCodeDescriptionOrganisation(null);
        }

        $this->collTOrganisationsRelatedByCodeDescriptionOrganisation = null;
        foreach ($tOrganisationsRelatedByCodeDescriptionOrganisation as $tOrganisationRelatedByCodeDescriptionOrganisation) {
            $this->addTOrganisationRelatedByCodeDescriptionOrganisation($tOrganisationRelatedByCodeDescriptionOrganisation);
        }

        $this->collTOrganisationsRelatedByCodeDescriptionOrganisation = $tOrganisationsRelatedByCodeDescriptionOrganisation;
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeDescriptionOrganisation(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeDescriptionOrganisation || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeDescriptionOrganisation) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeDescriptionOrganisation());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeDescriptionOrganisation($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeDescriptionOrganisation);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeDescriptionOrganisation(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation === null) {
            $this->initTOrganisationsRelatedByCodeDescriptionOrganisation();
            $this->collTOrganisationsRelatedByCodeDescriptionOrganisationPartial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeDescriptionOrganisation->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeDescriptionOrganisation($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeDescriptionOrganisation $tOrganisationRelatedByCodeDescriptionOrganisation The tOrganisationRelatedByCodeDescriptionOrganisation object to add.
     */
    protected function doAddTOrganisationRelatedByCodeDescriptionOrganisation($tOrganisationRelatedByCodeDescriptionOrganisation)
    {
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisation[]= $tOrganisationRelatedByCodeDescriptionOrganisation;
        $tOrganisationRelatedByCodeDescriptionOrganisation->setTTraductionRelatedByCodeDescriptionOrganisation($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeDescriptionOrganisation $tOrganisationRelatedByCodeDescriptionOrganisation The tOrganisationRelatedByCodeDescriptionOrganisation object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeDescriptionOrganisation($tOrganisationRelatedByCodeDescriptionOrganisation)
    {
        if ($this->getTOrganisationsRelatedByCodeDescriptionOrganisation()->contains($tOrganisationRelatedByCodeDescriptionOrganisation)) {
            $this->collTOrganisationsRelatedByCodeDescriptionOrganisation->remove($this->collTOrganisationsRelatedByCodeDescriptionOrganisation->search($tOrganisationRelatedByCodeDescriptionOrganisation));
            if (null === $this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeDescriptionOrganisation;
                $this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeDescriptionOrganisationScheduledForDeletion[]= $tOrganisationRelatedByCodeDescriptionOrganisation;
            $tOrganisationRelatedByCodeDescriptionOrganisation->setTTraductionRelatedByCodeDescriptionOrganisation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeDescriptionOrganisation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeDescriptionOrganisationJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeDescriptionOrganisation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeDescriptionOrganisation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeDescriptionOrganisationJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeDescriptionOrganisation($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeLibelleLien1 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeLibelleLien1()
     */
    public function clearTOrganisationsRelatedByCodeLibelleLien1()
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien1 = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeLibelleLien1Partial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeLibelleLien1 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeLibelleLien1($v = true)
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien1Partial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeLibelleLien1 collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeLibelleLien1 collection to an empty array (like clearcollTOrganisationsRelatedByCodeLibelleLien1());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeLibelleLien1($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeLibelleLien1 && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeLibelleLien1 = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeLibelleLien1->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeLibelleLien1($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeLibelleLien1Partial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeLibelleLien1 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeLibelleLien1) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeLibelleLien1();
            } else {
                $collTOrganisationsRelatedByCodeLibelleLien1 = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleLien1($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeLibelleLien1Partial && count($collTOrganisationsRelatedByCodeLibelleLien1)) {
                      $this->initTOrganisationsRelatedByCodeLibelleLien1(false);

                      foreach($collTOrganisationsRelatedByCodeLibelleLien1 as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeLibelleLien1->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeLibelleLien1->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeLibelleLien1Partial = true;
                    }

                    $collTOrganisationsRelatedByCodeLibelleLien1->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeLibelleLien1;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeLibelleLien1) {
                    foreach($this->collTOrganisationsRelatedByCodeLibelleLien1 as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeLibelleLien1[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeLibelleLien1 = $collTOrganisationsRelatedByCodeLibelleLien1;
                $this->collTOrganisationsRelatedByCodeLibelleLien1Partial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeLibelleLien1;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeLibelleLien1 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeLibelleLien1 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeLibelleLien1(PropelCollection $tOrganisationsRelatedByCodeLibelleLien1, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeLibelleLien1ToDelete = $this->getTOrganisationsRelatedByCodeLibelleLien1(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeLibelleLien1);

        $this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeLibelleLien1ToDelete));

        foreach ($tOrganisationsRelatedByCodeLibelleLien1ToDelete as $tOrganisationRelatedByCodeLibelleLien1Removed) {
            $tOrganisationRelatedByCodeLibelleLien1Removed->setTTraductionRelatedByCodeLibelleLien1(null);
        }

        $this->collTOrganisationsRelatedByCodeLibelleLien1 = null;
        foreach ($tOrganisationsRelatedByCodeLibelleLien1 as $tOrganisationRelatedByCodeLibelleLien1) {
            $this->addTOrganisationRelatedByCodeLibelleLien1($tOrganisationRelatedByCodeLibelleLien1);
        }

        $this->collTOrganisationsRelatedByCodeLibelleLien1 = $tOrganisationsRelatedByCodeLibelleLien1;
        $this->collTOrganisationsRelatedByCodeLibelleLien1Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeLibelleLien1(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeLibelleLien1Partial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeLibelleLien1 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeLibelleLien1) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeLibelleLien1());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleLien1($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeLibelleLien1);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeLibelleLien1(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeLibelleLien1 === null) {
            $this->initTOrganisationsRelatedByCodeLibelleLien1();
            $this->collTOrganisationsRelatedByCodeLibelleLien1Partial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeLibelleLien1->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeLibelleLien1($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeLibelleLien1 $tOrganisationRelatedByCodeLibelleLien1 The tOrganisationRelatedByCodeLibelleLien1 object to add.
     */
    protected function doAddTOrganisationRelatedByCodeLibelleLien1($tOrganisationRelatedByCodeLibelleLien1)
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien1[]= $tOrganisationRelatedByCodeLibelleLien1;
        $tOrganisationRelatedByCodeLibelleLien1->setTTraductionRelatedByCodeLibelleLien1($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeLibelleLien1 $tOrganisationRelatedByCodeLibelleLien1 The tOrganisationRelatedByCodeLibelleLien1 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeLibelleLien1($tOrganisationRelatedByCodeLibelleLien1)
    {
        if ($this->getTOrganisationsRelatedByCodeLibelleLien1()->contains($tOrganisationRelatedByCodeLibelleLien1)) {
            $this->collTOrganisationsRelatedByCodeLibelleLien1->remove($this->collTOrganisationsRelatedByCodeLibelleLien1->search($tOrganisationRelatedByCodeLibelleLien1));
            if (null === $this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeLibelleLien1;
                $this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeLibelleLien1ScheduledForDeletion[]= $tOrganisationRelatedByCodeLibelleLien1;
            $tOrganisationRelatedByCodeLibelleLien1->setTTraductionRelatedByCodeLibelleLien1(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeLibelleLien1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeLibelleLien1JoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeLibelleLien1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeLibelleLien1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeLibelleLien1JoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeLibelleLien1($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeLibelleLien2 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeLibelleLien2()
     */
    public function clearTOrganisationsRelatedByCodeLibelleLien2()
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien2 = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeLibelleLien2Partial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeLibelleLien2 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeLibelleLien2($v = true)
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien2Partial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeLibelleLien2 collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeLibelleLien2 collection to an empty array (like clearcollTOrganisationsRelatedByCodeLibelleLien2());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeLibelleLien2($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeLibelleLien2 && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeLibelleLien2 = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeLibelleLien2->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeLibelleLien2($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeLibelleLien2Partial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeLibelleLien2 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeLibelleLien2) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeLibelleLien2();
            } else {
                $collTOrganisationsRelatedByCodeLibelleLien2 = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleLien2($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeLibelleLien2Partial && count($collTOrganisationsRelatedByCodeLibelleLien2)) {
                      $this->initTOrganisationsRelatedByCodeLibelleLien2(false);

                      foreach($collTOrganisationsRelatedByCodeLibelleLien2 as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeLibelleLien2->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeLibelleLien2->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeLibelleLien2Partial = true;
                    }

                    $collTOrganisationsRelatedByCodeLibelleLien2->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeLibelleLien2;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeLibelleLien2) {
                    foreach($this->collTOrganisationsRelatedByCodeLibelleLien2 as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeLibelleLien2[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeLibelleLien2 = $collTOrganisationsRelatedByCodeLibelleLien2;
                $this->collTOrganisationsRelatedByCodeLibelleLien2Partial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeLibelleLien2;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeLibelleLien2 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeLibelleLien2 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeLibelleLien2(PropelCollection $tOrganisationsRelatedByCodeLibelleLien2, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeLibelleLien2ToDelete = $this->getTOrganisationsRelatedByCodeLibelleLien2(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeLibelleLien2);

        $this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeLibelleLien2ToDelete));

        foreach ($tOrganisationsRelatedByCodeLibelleLien2ToDelete as $tOrganisationRelatedByCodeLibelleLien2Removed) {
            $tOrganisationRelatedByCodeLibelleLien2Removed->setTTraductionRelatedByCodeLibelleLien2(null);
        }

        $this->collTOrganisationsRelatedByCodeLibelleLien2 = null;
        foreach ($tOrganisationsRelatedByCodeLibelleLien2 as $tOrganisationRelatedByCodeLibelleLien2) {
            $this->addTOrganisationRelatedByCodeLibelleLien2($tOrganisationRelatedByCodeLibelleLien2);
        }

        $this->collTOrganisationsRelatedByCodeLibelleLien2 = $tOrganisationsRelatedByCodeLibelleLien2;
        $this->collTOrganisationsRelatedByCodeLibelleLien2Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeLibelleLien2(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeLibelleLien2Partial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeLibelleLien2 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeLibelleLien2) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeLibelleLien2());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleLien2($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeLibelleLien2);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeLibelleLien2(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeLibelleLien2 === null) {
            $this->initTOrganisationsRelatedByCodeLibelleLien2();
            $this->collTOrganisationsRelatedByCodeLibelleLien2Partial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeLibelleLien2->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeLibelleLien2($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeLibelleLien2 $tOrganisationRelatedByCodeLibelleLien2 The tOrganisationRelatedByCodeLibelleLien2 object to add.
     */
    protected function doAddTOrganisationRelatedByCodeLibelleLien2($tOrganisationRelatedByCodeLibelleLien2)
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien2[]= $tOrganisationRelatedByCodeLibelleLien2;
        $tOrganisationRelatedByCodeLibelleLien2->setTTraductionRelatedByCodeLibelleLien2($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeLibelleLien2 $tOrganisationRelatedByCodeLibelleLien2 The tOrganisationRelatedByCodeLibelleLien2 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeLibelleLien2($tOrganisationRelatedByCodeLibelleLien2)
    {
        if ($this->getTOrganisationsRelatedByCodeLibelleLien2()->contains($tOrganisationRelatedByCodeLibelleLien2)) {
            $this->collTOrganisationsRelatedByCodeLibelleLien2->remove($this->collTOrganisationsRelatedByCodeLibelleLien2->search($tOrganisationRelatedByCodeLibelleLien2));
            if (null === $this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeLibelleLien2;
                $this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeLibelleLien2ScheduledForDeletion[]= $tOrganisationRelatedByCodeLibelleLien2;
            $tOrganisationRelatedByCodeLibelleLien2->setTTraductionRelatedByCodeLibelleLien2(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeLibelleLien2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeLibelleLien2JoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeLibelleLien2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeLibelleLien2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeLibelleLien2JoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeLibelleLien2($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeLibelleLien3 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeLibelleLien3()
     */
    public function clearTOrganisationsRelatedByCodeLibelleLien3()
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien3 = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeLibelleLien3Partial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeLibelleLien3 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeLibelleLien3($v = true)
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien3Partial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeLibelleLien3 collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeLibelleLien3 collection to an empty array (like clearcollTOrganisationsRelatedByCodeLibelleLien3());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeLibelleLien3($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeLibelleLien3 && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeLibelleLien3 = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeLibelleLien3->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeLibelleLien3($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeLibelleLien3Partial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeLibelleLien3 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeLibelleLien3) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeLibelleLien3();
            } else {
                $collTOrganisationsRelatedByCodeLibelleLien3 = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleLien3($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeLibelleLien3Partial && count($collTOrganisationsRelatedByCodeLibelleLien3)) {
                      $this->initTOrganisationsRelatedByCodeLibelleLien3(false);

                      foreach($collTOrganisationsRelatedByCodeLibelleLien3 as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeLibelleLien3->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeLibelleLien3->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeLibelleLien3Partial = true;
                    }

                    $collTOrganisationsRelatedByCodeLibelleLien3->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeLibelleLien3;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeLibelleLien3) {
                    foreach($this->collTOrganisationsRelatedByCodeLibelleLien3 as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeLibelleLien3[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeLibelleLien3 = $collTOrganisationsRelatedByCodeLibelleLien3;
                $this->collTOrganisationsRelatedByCodeLibelleLien3Partial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeLibelleLien3;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeLibelleLien3 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeLibelleLien3 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeLibelleLien3(PropelCollection $tOrganisationsRelatedByCodeLibelleLien3, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeLibelleLien3ToDelete = $this->getTOrganisationsRelatedByCodeLibelleLien3(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeLibelleLien3);

        $this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeLibelleLien3ToDelete));

        foreach ($tOrganisationsRelatedByCodeLibelleLien3ToDelete as $tOrganisationRelatedByCodeLibelleLien3Removed) {
            $tOrganisationRelatedByCodeLibelleLien3Removed->setTTraductionRelatedByCodeLibelleLien3(null);
        }

        $this->collTOrganisationsRelatedByCodeLibelleLien3 = null;
        foreach ($tOrganisationsRelatedByCodeLibelleLien3 as $tOrganisationRelatedByCodeLibelleLien3) {
            $this->addTOrganisationRelatedByCodeLibelleLien3($tOrganisationRelatedByCodeLibelleLien3);
        }

        $this->collTOrganisationsRelatedByCodeLibelleLien3 = $tOrganisationsRelatedByCodeLibelleLien3;
        $this->collTOrganisationsRelatedByCodeLibelleLien3Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeLibelleLien3(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeLibelleLien3Partial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeLibelleLien3 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeLibelleLien3) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeLibelleLien3());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleLien3($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeLibelleLien3);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeLibelleLien3(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeLibelleLien3 === null) {
            $this->initTOrganisationsRelatedByCodeLibelleLien3();
            $this->collTOrganisationsRelatedByCodeLibelleLien3Partial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeLibelleLien3->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeLibelleLien3($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeLibelleLien3 $tOrganisationRelatedByCodeLibelleLien3 The tOrganisationRelatedByCodeLibelleLien3 object to add.
     */
    protected function doAddTOrganisationRelatedByCodeLibelleLien3($tOrganisationRelatedByCodeLibelleLien3)
    {
        $this->collTOrganisationsRelatedByCodeLibelleLien3[]= $tOrganisationRelatedByCodeLibelleLien3;
        $tOrganisationRelatedByCodeLibelleLien3->setTTraductionRelatedByCodeLibelleLien3($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeLibelleLien3 $tOrganisationRelatedByCodeLibelleLien3 The tOrganisationRelatedByCodeLibelleLien3 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeLibelleLien3($tOrganisationRelatedByCodeLibelleLien3)
    {
        if ($this->getTOrganisationsRelatedByCodeLibelleLien3()->contains($tOrganisationRelatedByCodeLibelleLien3)) {
            $this->collTOrganisationsRelatedByCodeLibelleLien3->remove($this->collTOrganisationsRelatedByCodeLibelleLien3->search($tOrganisationRelatedByCodeLibelleLien3));
            if (null === $this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeLibelleLien3;
                $this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeLibelleLien3ScheduledForDeletion[]= $tOrganisationRelatedByCodeLibelleLien3;
            $tOrganisationRelatedByCodeLibelleLien3->setTTraductionRelatedByCodeLibelleLien3(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeLibelleLien3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeLibelleLien3JoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeLibelleLien3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeLibelleLien3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeLibelleLien3JoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeLibelleLien3($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeMessageBienvenue collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeMessageBienvenue()
     */
    public function clearTOrganisationsRelatedByCodeMessageBienvenue()
    {
        $this->collTOrganisationsRelatedByCodeMessageBienvenue = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeMessageBienvenue collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeMessageBienvenue($v = true)
    {
        $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeMessageBienvenue collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeMessageBienvenue collection to an empty array (like clearcollTOrganisationsRelatedByCodeMessageBienvenue());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeMessageBienvenue($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeMessageBienvenue && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeMessageBienvenue = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeMessageBienvenue->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeMessageBienvenue($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeMessageBienvenue || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeMessageBienvenue) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeMessageBienvenue();
            } else {
                $collTOrganisationsRelatedByCodeMessageBienvenue = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeMessageBienvenue($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial && count($collTOrganisationsRelatedByCodeMessageBienvenue)) {
                      $this->initTOrganisationsRelatedByCodeMessageBienvenue(false);

                      foreach($collTOrganisationsRelatedByCodeMessageBienvenue as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeMessageBienvenue->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeMessageBienvenue->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial = true;
                    }

                    $collTOrganisationsRelatedByCodeMessageBienvenue->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeMessageBienvenue;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeMessageBienvenue) {
                    foreach($this->collTOrganisationsRelatedByCodeMessageBienvenue as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeMessageBienvenue[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeMessageBienvenue = $collTOrganisationsRelatedByCodeMessageBienvenue;
                $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeMessageBienvenue;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeMessageBienvenue objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeMessageBienvenue A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeMessageBienvenue(PropelCollection $tOrganisationsRelatedByCodeMessageBienvenue, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeMessageBienvenueToDelete = $this->getTOrganisationsRelatedByCodeMessageBienvenue(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeMessageBienvenue);

        $this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeMessageBienvenueToDelete));

        foreach ($tOrganisationsRelatedByCodeMessageBienvenueToDelete as $tOrganisationRelatedByCodeMessageBienvenueRemoved) {
            $tOrganisationRelatedByCodeMessageBienvenueRemoved->setTTraductionRelatedByCodeMessageBienvenue(null);
        }

        $this->collTOrganisationsRelatedByCodeMessageBienvenue = null;
        foreach ($tOrganisationsRelatedByCodeMessageBienvenue as $tOrganisationRelatedByCodeMessageBienvenue) {
            $this->addTOrganisationRelatedByCodeMessageBienvenue($tOrganisationRelatedByCodeMessageBienvenue);
        }

        $this->collTOrganisationsRelatedByCodeMessageBienvenue = $tOrganisationsRelatedByCodeMessageBienvenue;
        $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeMessageBienvenue(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeMessageBienvenue || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeMessageBienvenue) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeMessageBienvenue());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeMessageBienvenue($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeMessageBienvenue);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeMessageBienvenue(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeMessageBienvenue === null) {
            $this->initTOrganisationsRelatedByCodeMessageBienvenue();
            $this->collTOrganisationsRelatedByCodeMessageBienvenuePartial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeMessageBienvenue->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeMessageBienvenue($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeMessageBienvenue $tOrganisationRelatedByCodeMessageBienvenue The tOrganisationRelatedByCodeMessageBienvenue object to add.
     */
    protected function doAddTOrganisationRelatedByCodeMessageBienvenue($tOrganisationRelatedByCodeMessageBienvenue)
    {
        $this->collTOrganisationsRelatedByCodeMessageBienvenue[]= $tOrganisationRelatedByCodeMessageBienvenue;
        $tOrganisationRelatedByCodeMessageBienvenue->setTTraductionRelatedByCodeMessageBienvenue($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeMessageBienvenue $tOrganisationRelatedByCodeMessageBienvenue The tOrganisationRelatedByCodeMessageBienvenue object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeMessageBienvenue($tOrganisationRelatedByCodeMessageBienvenue)
    {
        if ($this->getTOrganisationsRelatedByCodeMessageBienvenue()->contains($tOrganisationRelatedByCodeMessageBienvenue)) {
            $this->collTOrganisationsRelatedByCodeMessageBienvenue->remove($this->collTOrganisationsRelatedByCodeMessageBienvenue->search($tOrganisationRelatedByCodeMessageBienvenue));
            if (null === $this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeMessageBienvenue;
                $this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeMessageBienvenueScheduledForDeletion[]= $tOrganisationRelatedByCodeMessageBienvenue;
            $tOrganisationRelatedByCodeMessageBienvenue->setTTraductionRelatedByCodeMessageBienvenue(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeMessageBienvenue from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeMessageBienvenueJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeMessageBienvenue($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeMessageBienvenue from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeMessageBienvenueJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeMessageBienvenue($query, $con);
    }

    /**
     * Clears out the collTOrganisationsRelatedByCodeTitreBienvenue collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTOrganisationsRelatedByCodeTitreBienvenue()
     */
    public function clearTOrganisationsRelatedByCodeTitreBienvenue()
    {
        $this->collTOrganisationsRelatedByCodeTitreBienvenue = null; // important to set this to null since that means it is uninitialized
        $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial = null;

        return $this;
    }

    /**
     * reset is the collTOrganisationsRelatedByCodeTitreBienvenue collection loaded partially
     *
     * @return void
     */
    public function resetPartialTOrganisationsRelatedByCodeTitreBienvenue($v = true)
    {
        $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial = $v;
    }

    /**
     * Initializes the collTOrganisationsRelatedByCodeTitreBienvenue collection.
     *
     * By default this just sets the collTOrganisationsRelatedByCodeTitreBienvenue collection to an empty array (like clearcollTOrganisationsRelatedByCodeTitreBienvenue());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTOrganisationsRelatedByCodeTitreBienvenue($overrideExisting = true)
    {
        if (null !== $this->collTOrganisationsRelatedByCodeTitreBienvenue && !$overrideExisting) {
            return;
        }
        $this->collTOrganisationsRelatedByCodeTitreBienvenue = new PropelObjectCollection();
        $this->collTOrganisationsRelatedByCodeTitreBienvenue->setModel('TOrganisation');
    }

    /**
     * Gets an array of TOrganisation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     * @throws PropelException
     */
    public function getTOrganisationsRelatedByCodeTitreBienvenue($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeTitreBienvenue || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeTitreBienvenue) {
                // return empty collection
                $this->initTOrganisationsRelatedByCodeTitreBienvenue();
            } else {
                $collTOrganisationsRelatedByCodeTitreBienvenue = TOrganisationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeTitreBienvenue($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial && count($collTOrganisationsRelatedByCodeTitreBienvenue)) {
                      $this->initTOrganisationsRelatedByCodeTitreBienvenue(false);

                      foreach($collTOrganisationsRelatedByCodeTitreBienvenue as $obj) {
                        if (false == $this->collTOrganisationsRelatedByCodeTitreBienvenue->contains($obj)) {
                          $this->collTOrganisationsRelatedByCodeTitreBienvenue->append($obj);
                        }
                      }

                      $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial = true;
                    }

                    $collTOrganisationsRelatedByCodeTitreBienvenue->getInternalIterator()->rewind();
                    return $collTOrganisationsRelatedByCodeTitreBienvenue;
                }

                if($partial && $this->collTOrganisationsRelatedByCodeTitreBienvenue) {
                    foreach($this->collTOrganisationsRelatedByCodeTitreBienvenue as $obj) {
                        if($obj->isNew()) {
                            $collTOrganisationsRelatedByCodeTitreBienvenue[] = $obj;
                        }
                    }
                }

                $this->collTOrganisationsRelatedByCodeTitreBienvenue = $collTOrganisationsRelatedByCodeTitreBienvenue;
                $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial = false;
            }
        }

        return $this->collTOrganisationsRelatedByCodeTitreBienvenue;
    }

    /**
     * Sets a collection of TOrganisationRelatedByCodeTitreBienvenue objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tOrganisationsRelatedByCodeTitreBienvenue A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTOrganisationsRelatedByCodeTitreBienvenue(PropelCollection $tOrganisationsRelatedByCodeTitreBienvenue, PropelPDO $con = null)
    {
        $tOrganisationsRelatedByCodeTitreBienvenueToDelete = $this->getTOrganisationsRelatedByCodeTitreBienvenue(new Criteria(), $con)->diff($tOrganisationsRelatedByCodeTitreBienvenue);

        $this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion = unserialize(serialize($tOrganisationsRelatedByCodeTitreBienvenueToDelete));

        foreach ($tOrganisationsRelatedByCodeTitreBienvenueToDelete as $tOrganisationRelatedByCodeTitreBienvenueRemoved) {
            $tOrganisationRelatedByCodeTitreBienvenueRemoved->setTTraductionRelatedByCodeTitreBienvenue(null);
        }

        $this->collTOrganisationsRelatedByCodeTitreBienvenue = null;
        foreach ($tOrganisationsRelatedByCodeTitreBienvenue as $tOrganisationRelatedByCodeTitreBienvenue) {
            $this->addTOrganisationRelatedByCodeTitreBienvenue($tOrganisationRelatedByCodeTitreBienvenue);
        }

        $this->collTOrganisationsRelatedByCodeTitreBienvenue = $tOrganisationsRelatedByCodeTitreBienvenue;
        $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TOrganisation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TOrganisation objects.
     * @throws PropelException
     */
    public function countTOrganisationsRelatedByCodeTitreBienvenue(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial && !$this->isNew();
        if (null === $this->collTOrganisationsRelatedByCodeTitreBienvenue || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTOrganisationsRelatedByCodeTitreBienvenue) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTOrganisationsRelatedByCodeTitreBienvenue());
            }
            $query = TOrganisationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeTitreBienvenue($this)
                ->count($con);
        }

        return count($this->collTOrganisationsRelatedByCodeTitreBienvenue);
    }

    /**
     * Method called to associate a TOrganisation object to this object
     * through the TOrganisation foreign key attribute.
     *
     * @param    TOrganisation $l TOrganisation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTOrganisationRelatedByCodeTitreBienvenue(TOrganisation $l)
    {
        if ($this->collTOrganisationsRelatedByCodeTitreBienvenue === null) {
            $this->initTOrganisationsRelatedByCodeTitreBienvenue();
            $this->collTOrganisationsRelatedByCodeTitreBienvenuePartial = true;
        }
        if (!in_array($l, $this->collTOrganisationsRelatedByCodeTitreBienvenue->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTOrganisationRelatedByCodeTitreBienvenue($l);
        }

        return $this;
    }

    /**
     * @param	TOrganisationRelatedByCodeTitreBienvenue $tOrganisationRelatedByCodeTitreBienvenue The tOrganisationRelatedByCodeTitreBienvenue object to add.
     */
    protected function doAddTOrganisationRelatedByCodeTitreBienvenue($tOrganisationRelatedByCodeTitreBienvenue)
    {
        $this->collTOrganisationsRelatedByCodeTitreBienvenue[]= $tOrganisationRelatedByCodeTitreBienvenue;
        $tOrganisationRelatedByCodeTitreBienvenue->setTTraductionRelatedByCodeTitreBienvenue($this);
    }

    /**
     * @param	TOrganisationRelatedByCodeTitreBienvenue $tOrganisationRelatedByCodeTitreBienvenue The tOrganisationRelatedByCodeTitreBienvenue object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTOrganisationRelatedByCodeTitreBienvenue($tOrganisationRelatedByCodeTitreBienvenue)
    {
        if ($this->getTOrganisationsRelatedByCodeTitreBienvenue()->contains($tOrganisationRelatedByCodeTitreBienvenue)) {
            $this->collTOrganisationsRelatedByCodeTitreBienvenue->remove($this->collTOrganisationsRelatedByCodeTitreBienvenue->search($tOrganisationRelatedByCodeTitreBienvenue));
            if (null === $this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion) {
                $this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion = clone $this->collTOrganisationsRelatedByCodeTitreBienvenue;
                $this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion->clear();
            }
            $this->tOrganisationsRelatedByCodeTitreBienvenueScheduledForDeletion[]= $tOrganisationRelatedByCodeTitreBienvenue;
            $tOrganisationRelatedByCodeTitreBienvenue->setTTraductionRelatedByCodeTitreBienvenue(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeTitreBienvenue from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeTitreBienvenueJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeTitreBienvenue($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TOrganisationsRelatedByCodeTitreBienvenue from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TOrganisation[] List of TOrganisation objects
     */
    public function getTOrganisationsRelatedByCodeTitreBienvenueJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TOrganisationQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTOrganisationsRelatedByCodeTitreBienvenue($query, $con);
    }

    /**
     * Clears out the collTParametragePrestationsRelatedByCodeCommentaire collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametragePrestationsRelatedByCodeCommentaire()
     */
    public function clearTParametragePrestationsRelatedByCodeCommentaire()
    {
        $this->collTParametragePrestationsRelatedByCodeCommentaire = null; // important to set this to null since that means it is uninitialized
        $this->collTParametragePrestationsRelatedByCodeCommentairePartial = null;

        return $this;
    }

    /**
     * reset is the collTParametragePrestationsRelatedByCodeCommentaire collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametragePrestationsRelatedByCodeCommentaire($v = true)
    {
        $this->collTParametragePrestationsRelatedByCodeCommentairePartial = $v;
    }

    /**
     * Initializes the collTParametragePrestationsRelatedByCodeCommentaire collection.
     *
     * By default this just sets the collTParametragePrestationsRelatedByCodeCommentaire collection to an empty array (like clearcollTParametragePrestationsRelatedByCodeCommentaire());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametragePrestationsRelatedByCodeCommentaire($overrideExisting = true)
    {
        if (null !== $this->collTParametragePrestationsRelatedByCodeCommentaire && !$overrideExisting) {
            return;
        }
        $this->collTParametragePrestationsRelatedByCodeCommentaire = new PropelObjectCollection();
        $this->collTParametragePrestationsRelatedByCodeCommentaire->setModel('TParametragePrestation');
    }

    /**
     * Gets an array of TParametragePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     * @throws PropelException
     */
    public function getTParametragePrestationsRelatedByCodeCommentaire($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsRelatedByCodeCommentairePartial && !$this->isNew();
        if (null === $this->collTParametragePrestationsRelatedByCodeCommentaire || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestationsRelatedByCodeCommentaire) {
                // return empty collection
                $this->initTParametragePrestationsRelatedByCodeCommentaire();
            } else {
                $collTParametragePrestationsRelatedByCodeCommentaire = TParametragePrestationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeCommentaire($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametragePrestationsRelatedByCodeCommentairePartial && count($collTParametragePrestationsRelatedByCodeCommentaire)) {
                      $this->initTParametragePrestationsRelatedByCodeCommentaire(false);

                      foreach($collTParametragePrestationsRelatedByCodeCommentaire as $obj) {
                        if (false == $this->collTParametragePrestationsRelatedByCodeCommentaire->contains($obj)) {
                          $this->collTParametragePrestationsRelatedByCodeCommentaire->append($obj);
                        }
                      }

                      $this->collTParametragePrestationsRelatedByCodeCommentairePartial = true;
                    }

                    $collTParametragePrestationsRelatedByCodeCommentaire->getInternalIterator()->rewind();
                    return $collTParametragePrestationsRelatedByCodeCommentaire;
                }

                if($partial && $this->collTParametragePrestationsRelatedByCodeCommentaire) {
                    foreach($this->collTParametragePrestationsRelatedByCodeCommentaire as $obj) {
                        if($obj->isNew()) {
                            $collTParametragePrestationsRelatedByCodeCommentaire[] = $obj;
                        }
                    }
                }

                $this->collTParametragePrestationsRelatedByCodeCommentaire = $collTParametragePrestationsRelatedByCodeCommentaire;
                $this->collTParametragePrestationsRelatedByCodeCommentairePartial = false;
            }
        }

        return $this->collTParametragePrestationsRelatedByCodeCommentaire;
    }

    /**
     * Sets a collection of TParametragePrestationRelatedByCodeCommentaire objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametragePrestationsRelatedByCodeCommentaire A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametragePrestationsRelatedByCodeCommentaire(PropelCollection $tParametragePrestationsRelatedByCodeCommentaire, PropelPDO $con = null)
    {
        $tParametragePrestationsRelatedByCodeCommentaireToDelete = $this->getTParametragePrestationsRelatedByCodeCommentaire(new Criteria(), $con)->diff($tParametragePrestationsRelatedByCodeCommentaire);

        $this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion = unserialize(serialize($tParametragePrestationsRelatedByCodeCommentaireToDelete));

        foreach ($tParametragePrestationsRelatedByCodeCommentaireToDelete as $tParametragePrestationRelatedByCodeCommentaireRemoved) {
            $tParametragePrestationRelatedByCodeCommentaireRemoved->setTTraductionRelatedByCodeCommentaire(null);
        }

        $this->collTParametragePrestationsRelatedByCodeCommentaire = null;
        foreach ($tParametragePrestationsRelatedByCodeCommentaire as $tParametragePrestationRelatedByCodeCommentaire) {
            $this->addTParametragePrestationRelatedByCodeCommentaire($tParametragePrestationRelatedByCodeCommentaire);
        }

        $this->collTParametragePrestationsRelatedByCodeCommentaire = $tParametragePrestationsRelatedByCodeCommentaire;
        $this->collTParametragePrestationsRelatedByCodeCommentairePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametragePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametragePrestation objects.
     * @throws PropelException
     */
    public function countTParametragePrestationsRelatedByCodeCommentaire(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsRelatedByCodeCommentairePartial && !$this->isNew();
        if (null === $this->collTParametragePrestationsRelatedByCodeCommentaire || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestationsRelatedByCodeCommentaire) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametragePrestationsRelatedByCodeCommentaire());
            }
            $query = TParametragePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeCommentaire($this)
                ->count($con);
        }

        return count($this->collTParametragePrestationsRelatedByCodeCommentaire);
    }

    /**
     * Method called to associate a TParametragePrestation object to this object
     * through the TParametragePrestation foreign key attribute.
     *
     * @param    TParametragePrestation $l TParametragePrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametragePrestationRelatedByCodeCommentaire(TParametragePrestation $l)
    {
        if ($this->collTParametragePrestationsRelatedByCodeCommentaire === null) {
            $this->initTParametragePrestationsRelatedByCodeCommentaire();
            $this->collTParametragePrestationsRelatedByCodeCommentairePartial = true;
        }
        if (!in_array($l, $this->collTParametragePrestationsRelatedByCodeCommentaire->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametragePrestationRelatedByCodeCommentaire($l);
        }

        return $this;
    }

    /**
     * @param	TParametragePrestationRelatedByCodeCommentaire $tParametragePrestationRelatedByCodeCommentaire The tParametragePrestationRelatedByCodeCommentaire object to add.
     */
    protected function doAddTParametragePrestationRelatedByCodeCommentaire($tParametragePrestationRelatedByCodeCommentaire)
    {
        $this->collTParametragePrestationsRelatedByCodeCommentaire[]= $tParametragePrestationRelatedByCodeCommentaire;
        $tParametragePrestationRelatedByCodeCommentaire->setTTraductionRelatedByCodeCommentaire($this);
    }

    /**
     * @param	TParametragePrestationRelatedByCodeCommentaire $tParametragePrestationRelatedByCodeCommentaire The tParametragePrestationRelatedByCodeCommentaire object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametragePrestationRelatedByCodeCommentaire($tParametragePrestationRelatedByCodeCommentaire)
    {
        if ($this->getTParametragePrestationsRelatedByCodeCommentaire()->contains($tParametragePrestationRelatedByCodeCommentaire)) {
            $this->collTParametragePrestationsRelatedByCodeCommentaire->remove($this->collTParametragePrestationsRelatedByCodeCommentaire->search($tParametragePrestationRelatedByCodeCommentaire));
            if (null === $this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion) {
                $this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion = clone $this->collTParametragePrestationsRelatedByCodeCommentaire;
                $this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion->clear();
            }
            $this->tParametragePrestationsRelatedByCodeCommentaireScheduledForDeletion[]= $tParametragePrestationRelatedByCodeCommentaire;
            $tParametragePrestationRelatedByCodeCommentaire->setTTraductionRelatedByCodeCommentaire(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeCommentaireJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeCommentaireJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeCommentaireJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeCommentaireJoinTRefTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefTypePrestation', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeCommentaire($query, $con);
    }

    /**
     * Clears out the collTParametragePrestationsRelatedByCodeAide collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametragePrestationsRelatedByCodeAide()
     */
    public function clearTParametragePrestationsRelatedByCodeAide()
    {
        $this->collTParametragePrestationsRelatedByCodeAide = null; // important to set this to null since that means it is uninitialized
        $this->collTParametragePrestationsRelatedByCodeAidePartial = null;

        return $this;
    }

    /**
     * reset is the collTParametragePrestationsRelatedByCodeAide collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametragePrestationsRelatedByCodeAide($v = true)
    {
        $this->collTParametragePrestationsRelatedByCodeAidePartial = $v;
    }

    /**
     * Initializes the collTParametragePrestationsRelatedByCodeAide collection.
     *
     * By default this just sets the collTParametragePrestationsRelatedByCodeAide collection to an empty array (like clearcollTParametragePrestationsRelatedByCodeAide());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametragePrestationsRelatedByCodeAide($overrideExisting = true)
    {
        if (null !== $this->collTParametragePrestationsRelatedByCodeAide && !$overrideExisting) {
            return;
        }
        $this->collTParametragePrestationsRelatedByCodeAide = new PropelObjectCollection();
        $this->collTParametragePrestationsRelatedByCodeAide->setModel('TParametragePrestation');
    }

    /**
     * Gets an array of TParametragePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     * @throws PropelException
     */
    public function getTParametragePrestationsRelatedByCodeAide($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsRelatedByCodeAidePartial && !$this->isNew();
        if (null === $this->collTParametragePrestationsRelatedByCodeAide || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestationsRelatedByCodeAide) {
                // return empty collection
                $this->initTParametragePrestationsRelatedByCodeAide();
            } else {
                $collTParametragePrestationsRelatedByCodeAide = TParametragePrestationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeAide($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametragePrestationsRelatedByCodeAidePartial && count($collTParametragePrestationsRelatedByCodeAide)) {
                      $this->initTParametragePrestationsRelatedByCodeAide(false);

                      foreach($collTParametragePrestationsRelatedByCodeAide as $obj) {
                        if (false == $this->collTParametragePrestationsRelatedByCodeAide->contains($obj)) {
                          $this->collTParametragePrestationsRelatedByCodeAide->append($obj);
                        }
                      }

                      $this->collTParametragePrestationsRelatedByCodeAidePartial = true;
                    }

                    $collTParametragePrestationsRelatedByCodeAide->getInternalIterator()->rewind();
                    return $collTParametragePrestationsRelatedByCodeAide;
                }

                if($partial && $this->collTParametragePrestationsRelatedByCodeAide) {
                    foreach($this->collTParametragePrestationsRelatedByCodeAide as $obj) {
                        if($obj->isNew()) {
                            $collTParametragePrestationsRelatedByCodeAide[] = $obj;
                        }
                    }
                }

                $this->collTParametragePrestationsRelatedByCodeAide = $collTParametragePrestationsRelatedByCodeAide;
                $this->collTParametragePrestationsRelatedByCodeAidePartial = false;
            }
        }

        return $this->collTParametragePrestationsRelatedByCodeAide;
    }

    /**
     * Sets a collection of TParametragePrestationRelatedByCodeAide objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametragePrestationsRelatedByCodeAide A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametragePrestationsRelatedByCodeAide(PropelCollection $tParametragePrestationsRelatedByCodeAide, PropelPDO $con = null)
    {
        $tParametragePrestationsRelatedByCodeAideToDelete = $this->getTParametragePrestationsRelatedByCodeAide(new Criteria(), $con)->diff($tParametragePrestationsRelatedByCodeAide);

        $this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion = unserialize(serialize($tParametragePrestationsRelatedByCodeAideToDelete));

        foreach ($tParametragePrestationsRelatedByCodeAideToDelete as $tParametragePrestationRelatedByCodeAideRemoved) {
            $tParametragePrestationRelatedByCodeAideRemoved->setTTraductionRelatedByCodeAide(null);
        }

        $this->collTParametragePrestationsRelatedByCodeAide = null;
        foreach ($tParametragePrestationsRelatedByCodeAide as $tParametragePrestationRelatedByCodeAide) {
            $this->addTParametragePrestationRelatedByCodeAide($tParametragePrestationRelatedByCodeAide);
        }

        $this->collTParametragePrestationsRelatedByCodeAide = $tParametragePrestationsRelatedByCodeAide;
        $this->collTParametragePrestationsRelatedByCodeAidePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametragePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametragePrestation objects.
     * @throws PropelException
     */
    public function countTParametragePrestationsRelatedByCodeAide(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametragePrestationsRelatedByCodeAidePartial && !$this->isNew();
        if (null === $this->collTParametragePrestationsRelatedByCodeAide || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametragePrestationsRelatedByCodeAide) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametragePrestationsRelatedByCodeAide());
            }
            $query = TParametragePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeAide($this)
                ->count($con);
        }

        return count($this->collTParametragePrestationsRelatedByCodeAide);
    }

    /**
     * Method called to associate a TParametragePrestation object to this object
     * through the TParametragePrestation foreign key attribute.
     *
     * @param    TParametragePrestation $l TParametragePrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametragePrestationRelatedByCodeAide(TParametragePrestation $l)
    {
        if ($this->collTParametragePrestationsRelatedByCodeAide === null) {
            $this->initTParametragePrestationsRelatedByCodeAide();
            $this->collTParametragePrestationsRelatedByCodeAidePartial = true;
        }
        if (!in_array($l, $this->collTParametragePrestationsRelatedByCodeAide->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametragePrestationRelatedByCodeAide($l);
        }

        return $this;
    }

    /**
     * @param	TParametragePrestationRelatedByCodeAide $tParametragePrestationRelatedByCodeAide The tParametragePrestationRelatedByCodeAide object to add.
     */
    protected function doAddTParametragePrestationRelatedByCodeAide($tParametragePrestationRelatedByCodeAide)
    {
        $this->collTParametragePrestationsRelatedByCodeAide[]= $tParametragePrestationRelatedByCodeAide;
        $tParametragePrestationRelatedByCodeAide->setTTraductionRelatedByCodeAide($this);
    }

    /**
     * @param	TParametragePrestationRelatedByCodeAide $tParametragePrestationRelatedByCodeAide The tParametragePrestationRelatedByCodeAide object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametragePrestationRelatedByCodeAide($tParametragePrestationRelatedByCodeAide)
    {
        if ($this->getTParametragePrestationsRelatedByCodeAide()->contains($tParametragePrestationRelatedByCodeAide)) {
            $this->collTParametragePrestationsRelatedByCodeAide->remove($this->collTParametragePrestationsRelatedByCodeAide->search($tParametragePrestationRelatedByCodeAide));
            if (null === $this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion) {
                $this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion = clone $this->collTParametragePrestationsRelatedByCodeAide;
                $this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion->clear();
            }
            $this->tParametragePrestationsRelatedByCodeAideScheduledForDeletion[]= $tParametragePrestationRelatedByCodeAide;
            $tParametragePrestationRelatedByCodeAide->setTTraductionRelatedByCodeAide(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeAide from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeAideJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeAide($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeAide from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeAideJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeAide($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeAide from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeAideJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeAide($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametragePrestationsRelatedByCodeAide from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametragePrestation[] List of TParametragePrestation objects
     */
    public function getTParametragePrestationsRelatedByCodeAideJoinTRefTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametragePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefTypePrestation', $join_behavior);

        return $this->getTParametragePrestationsRelatedByCodeAide($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByCodeCommentaire collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByCodeCommentaire()
     */
    public function clearTParametreFormsRelatedByCodeCommentaire()
    {
        $this->collTParametreFormsRelatedByCodeCommentaire = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByCodeCommentairePartial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByCodeCommentaire collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByCodeCommentaire($v = true)
    {
        $this->collTParametreFormsRelatedByCodeCommentairePartial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByCodeCommentaire collection.
     *
     * By default this just sets the collTParametreFormsRelatedByCodeCommentaire collection to an empty array (like clearcollTParametreFormsRelatedByCodeCommentaire());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByCodeCommentaire($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByCodeCommentaire && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByCodeCommentaire = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByCodeCommentaire->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByCodeCommentaire($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeCommentairePartial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeCommentaire || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeCommentaire) {
                // return empty collection
                $this->initTParametreFormsRelatedByCodeCommentaire();
            } else {
                $collTParametreFormsRelatedByCodeCommentaire = TParametreFormQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeCommentaire($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByCodeCommentairePartial && count($collTParametreFormsRelatedByCodeCommentaire)) {
                      $this->initTParametreFormsRelatedByCodeCommentaire(false);

                      foreach($collTParametreFormsRelatedByCodeCommentaire as $obj) {
                        if (false == $this->collTParametreFormsRelatedByCodeCommentaire->contains($obj)) {
                          $this->collTParametreFormsRelatedByCodeCommentaire->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByCodeCommentairePartial = true;
                    }

                    $collTParametreFormsRelatedByCodeCommentaire->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByCodeCommentaire;
                }

                if($partial && $this->collTParametreFormsRelatedByCodeCommentaire) {
                    foreach($this->collTParametreFormsRelatedByCodeCommentaire as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByCodeCommentaire[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByCodeCommentaire = $collTParametreFormsRelatedByCodeCommentaire;
                $this->collTParametreFormsRelatedByCodeCommentairePartial = false;
            }
        }

        return $this->collTParametreFormsRelatedByCodeCommentaire;
    }

    /**
     * Sets a collection of TParametreFormRelatedByCodeCommentaire objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByCodeCommentaire A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByCodeCommentaire(PropelCollection $tParametreFormsRelatedByCodeCommentaire, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByCodeCommentaireToDelete = $this->getTParametreFormsRelatedByCodeCommentaire(new Criteria(), $con)->diff($tParametreFormsRelatedByCodeCommentaire);

        $this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByCodeCommentaireToDelete));

        foreach ($tParametreFormsRelatedByCodeCommentaireToDelete as $tParametreFormRelatedByCodeCommentaireRemoved) {
            $tParametreFormRelatedByCodeCommentaireRemoved->setTTraductionRelatedByCodeCommentaire(null);
        }

        $this->collTParametreFormsRelatedByCodeCommentaire = null;
        foreach ($tParametreFormsRelatedByCodeCommentaire as $tParametreFormRelatedByCodeCommentaire) {
            $this->addTParametreFormRelatedByCodeCommentaire($tParametreFormRelatedByCodeCommentaire);
        }

        $this->collTParametreFormsRelatedByCodeCommentaire = $tParametreFormsRelatedByCodeCommentaire;
        $this->collTParametreFormsRelatedByCodeCommentairePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByCodeCommentaire(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeCommentairePartial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeCommentaire || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeCommentaire) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByCodeCommentaire());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeCommentaire($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByCodeCommentaire);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByCodeCommentaire(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByCodeCommentaire === null) {
            $this->initTParametreFormsRelatedByCodeCommentaire();
            $this->collTParametreFormsRelatedByCodeCommentairePartial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByCodeCommentaire->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByCodeCommentaire($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByCodeCommentaire $tParametreFormRelatedByCodeCommentaire The tParametreFormRelatedByCodeCommentaire object to add.
     */
    protected function doAddTParametreFormRelatedByCodeCommentaire($tParametreFormRelatedByCodeCommentaire)
    {
        $this->collTParametreFormsRelatedByCodeCommentaire[]= $tParametreFormRelatedByCodeCommentaire;
        $tParametreFormRelatedByCodeCommentaire->setTTraductionRelatedByCodeCommentaire($this);
    }

    /**
     * @param	TParametreFormRelatedByCodeCommentaire $tParametreFormRelatedByCodeCommentaire The tParametreFormRelatedByCodeCommentaire object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByCodeCommentaire($tParametreFormRelatedByCodeCommentaire)
    {
        if ($this->getTParametreFormsRelatedByCodeCommentaire()->contains($tParametreFormRelatedByCodeCommentaire)) {
            $this->collTParametreFormsRelatedByCodeCommentaire->remove($this->collTParametreFormsRelatedByCodeCommentaire->search($tParametreFormRelatedByCodeCommentaire));
            if (null === $this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion) {
                $this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion = clone $this->collTParametreFormsRelatedByCodeCommentaire;
                $this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByCodeCommentaireScheduledForDeletion[]= $tParametreFormRelatedByCodeCommentaire;
            $tParametreFormRelatedByCodeCommentaire->setTTraductionRelatedByCodeCommentaire(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeCommentaireJoinTReferentielRelatedByIdRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeCommentaireJoinTReferentielRelatedByIdRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeCommentaireJoinTReferentielRelatedByIdRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeCommentaire($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByCodeLibelleRef1 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByCodeLibelleRef1()
     */
    public function clearTParametreFormsRelatedByCodeLibelleRef1()
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef1 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByCodeLibelleRef1Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByCodeLibelleRef1 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByCodeLibelleRef1($v = true)
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef1Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByCodeLibelleRef1 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByCodeLibelleRef1 collection to an empty array (like clearcollTParametreFormsRelatedByCodeLibelleRef1());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByCodeLibelleRef1($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByCodeLibelleRef1 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByCodeLibelleRef1 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByCodeLibelleRef1->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByCodeLibelleRef1($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleRef1Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleRef1 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleRef1) {
                // return empty collection
                $this->initTParametreFormsRelatedByCodeLibelleRef1();
            } else {
                $collTParametreFormsRelatedByCodeLibelleRef1 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleRef1($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByCodeLibelleRef1Partial && count($collTParametreFormsRelatedByCodeLibelleRef1)) {
                      $this->initTParametreFormsRelatedByCodeLibelleRef1(false);

                      foreach($collTParametreFormsRelatedByCodeLibelleRef1 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByCodeLibelleRef1->contains($obj)) {
                          $this->collTParametreFormsRelatedByCodeLibelleRef1->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByCodeLibelleRef1Partial = true;
                    }

                    $collTParametreFormsRelatedByCodeLibelleRef1->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByCodeLibelleRef1;
                }

                if($partial && $this->collTParametreFormsRelatedByCodeLibelleRef1) {
                    foreach($this->collTParametreFormsRelatedByCodeLibelleRef1 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByCodeLibelleRef1[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByCodeLibelleRef1 = $collTParametreFormsRelatedByCodeLibelleRef1;
                $this->collTParametreFormsRelatedByCodeLibelleRef1Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByCodeLibelleRef1;
    }

    /**
     * Sets a collection of TParametreFormRelatedByCodeLibelleRef1 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByCodeLibelleRef1 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByCodeLibelleRef1(PropelCollection $tParametreFormsRelatedByCodeLibelleRef1, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByCodeLibelleRef1ToDelete = $this->getTParametreFormsRelatedByCodeLibelleRef1(new Criteria(), $con)->diff($tParametreFormsRelatedByCodeLibelleRef1);

        $this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByCodeLibelleRef1ToDelete));

        foreach ($tParametreFormsRelatedByCodeLibelleRef1ToDelete as $tParametreFormRelatedByCodeLibelleRef1Removed) {
            $tParametreFormRelatedByCodeLibelleRef1Removed->setTTraductionRelatedByCodeLibelleRef1(null);
        }

        $this->collTParametreFormsRelatedByCodeLibelleRef1 = null;
        foreach ($tParametreFormsRelatedByCodeLibelleRef1 as $tParametreFormRelatedByCodeLibelleRef1) {
            $this->addTParametreFormRelatedByCodeLibelleRef1($tParametreFormRelatedByCodeLibelleRef1);
        }

        $this->collTParametreFormsRelatedByCodeLibelleRef1 = $tParametreFormsRelatedByCodeLibelleRef1;
        $this->collTParametreFormsRelatedByCodeLibelleRef1Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByCodeLibelleRef1(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleRef1Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleRef1 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleRef1) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByCodeLibelleRef1());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleRef1($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByCodeLibelleRef1);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByCodeLibelleRef1(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByCodeLibelleRef1 === null) {
            $this->initTParametreFormsRelatedByCodeLibelleRef1();
            $this->collTParametreFormsRelatedByCodeLibelleRef1Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByCodeLibelleRef1->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByCodeLibelleRef1($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleRef1 $tParametreFormRelatedByCodeLibelleRef1 The tParametreFormRelatedByCodeLibelleRef1 object to add.
     */
    protected function doAddTParametreFormRelatedByCodeLibelleRef1($tParametreFormRelatedByCodeLibelleRef1)
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef1[]= $tParametreFormRelatedByCodeLibelleRef1;
        $tParametreFormRelatedByCodeLibelleRef1->setTTraductionRelatedByCodeLibelleRef1($this);
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleRef1 $tParametreFormRelatedByCodeLibelleRef1 The tParametreFormRelatedByCodeLibelleRef1 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByCodeLibelleRef1($tParametreFormRelatedByCodeLibelleRef1)
    {
        if ($this->getTParametreFormsRelatedByCodeLibelleRef1()->contains($tParametreFormRelatedByCodeLibelleRef1)) {
            $this->collTParametreFormsRelatedByCodeLibelleRef1->remove($this->collTParametreFormsRelatedByCodeLibelleRef1->search($tParametreFormRelatedByCodeLibelleRef1));
            if (null === $this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion) {
                $this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion = clone $this->collTParametreFormsRelatedByCodeLibelleRef1;
                $this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByCodeLibelleRef1ScheduledForDeletion[]= $tParametreFormRelatedByCodeLibelleRef1;
            $tParametreFormRelatedByCodeLibelleRef1->setTTraductionRelatedByCodeLibelleRef1(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef1JoinTReferentielRelatedByIdRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef1JoinTReferentielRelatedByIdRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef1JoinTReferentielRelatedByIdRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef1($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByCodeLibelleRef2 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByCodeLibelleRef2()
     */
    public function clearTParametreFormsRelatedByCodeLibelleRef2()
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef2 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByCodeLibelleRef2Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByCodeLibelleRef2 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByCodeLibelleRef2($v = true)
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef2Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByCodeLibelleRef2 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByCodeLibelleRef2 collection to an empty array (like clearcollTParametreFormsRelatedByCodeLibelleRef2());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByCodeLibelleRef2($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByCodeLibelleRef2 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByCodeLibelleRef2 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByCodeLibelleRef2->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByCodeLibelleRef2($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleRef2Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleRef2 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleRef2) {
                // return empty collection
                $this->initTParametreFormsRelatedByCodeLibelleRef2();
            } else {
                $collTParametreFormsRelatedByCodeLibelleRef2 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleRef2($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByCodeLibelleRef2Partial && count($collTParametreFormsRelatedByCodeLibelleRef2)) {
                      $this->initTParametreFormsRelatedByCodeLibelleRef2(false);

                      foreach($collTParametreFormsRelatedByCodeLibelleRef2 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByCodeLibelleRef2->contains($obj)) {
                          $this->collTParametreFormsRelatedByCodeLibelleRef2->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByCodeLibelleRef2Partial = true;
                    }

                    $collTParametreFormsRelatedByCodeLibelleRef2->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByCodeLibelleRef2;
                }

                if($partial && $this->collTParametreFormsRelatedByCodeLibelleRef2) {
                    foreach($this->collTParametreFormsRelatedByCodeLibelleRef2 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByCodeLibelleRef2[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByCodeLibelleRef2 = $collTParametreFormsRelatedByCodeLibelleRef2;
                $this->collTParametreFormsRelatedByCodeLibelleRef2Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByCodeLibelleRef2;
    }

    /**
     * Sets a collection of TParametreFormRelatedByCodeLibelleRef2 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByCodeLibelleRef2 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByCodeLibelleRef2(PropelCollection $tParametreFormsRelatedByCodeLibelleRef2, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByCodeLibelleRef2ToDelete = $this->getTParametreFormsRelatedByCodeLibelleRef2(new Criteria(), $con)->diff($tParametreFormsRelatedByCodeLibelleRef2);

        $this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByCodeLibelleRef2ToDelete));

        foreach ($tParametreFormsRelatedByCodeLibelleRef2ToDelete as $tParametreFormRelatedByCodeLibelleRef2Removed) {
            $tParametreFormRelatedByCodeLibelleRef2Removed->setTTraductionRelatedByCodeLibelleRef2(null);
        }

        $this->collTParametreFormsRelatedByCodeLibelleRef2 = null;
        foreach ($tParametreFormsRelatedByCodeLibelleRef2 as $tParametreFormRelatedByCodeLibelleRef2) {
            $this->addTParametreFormRelatedByCodeLibelleRef2($tParametreFormRelatedByCodeLibelleRef2);
        }

        $this->collTParametreFormsRelatedByCodeLibelleRef2 = $tParametreFormsRelatedByCodeLibelleRef2;
        $this->collTParametreFormsRelatedByCodeLibelleRef2Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByCodeLibelleRef2(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleRef2Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleRef2 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleRef2) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByCodeLibelleRef2());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleRef2($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByCodeLibelleRef2);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByCodeLibelleRef2(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByCodeLibelleRef2 === null) {
            $this->initTParametreFormsRelatedByCodeLibelleRef2();
            $this->collTParametreFormsRelatedByCodeLibelleRef2Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByCodeLibelleRef2->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByCodeLibelleRef2($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleRef2 $tParametreFormRelatedByCodeLibelleRef2 The tParametreFormRelatedByCodeLibelleRef2 object to add.
     */
    protected function doAddTParametreFormRelatedByCodeLibelleRef2($tParametreFormRelatedByCodeLibelleRef2)
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef2[]= $tParametreFormRelatedByCodeLibelleRef2;
        $tParametreFormRelatedByCodeLibelleRef2->setTTraductionRelatedByCodeLibelleRef2($this);
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleRef2 $tParametreFormRelatedByCodeLibelleRef2 The tParametreFormRelatedByCodeLibelleRef2 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByCodeLibelleRef2($tParametreFormRelatedByCodeLibelleRef2)
    {
        if ($this->getTParametreFormsRelatedByCodeLibelleRef2()->contains($tParametreFormRelatedByCodeLibelleRef2)) {
            $this->collTParametreFormsRelatedByCodeLibelleRef2->remove($this->collTParametreFormsRelatedByCodeLibelleRef2->search($tParametreFormRelatedByCodeLibelleRef2));
            if (null === $this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion) {
                $this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion = clone $this->collTParametreFormsRelatedByCodeLibelleRef2;
                $this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByCodeLibelleRef2ScheduledForDeletion[]= $tParametreFormRelatedByCodeLibelleRef2;
            $tParametreFormRelatedByCodeLibelleRef2->setTTraductionRelatedByCodeLibelleRef2(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef2JoinTReferentielRelatedByIdRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef2JoinTReferentielRelatedByIdRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef2JoinTReferentielRelatedByIdRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef2($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByCodeLibelleRef3 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByCodeLibelleRef3()
     */
    public function clearTParametreFormsRelatedByCodeLibelleRef3()
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef3 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByCodeLibelleRef3Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByCodeLibelleRef3 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByCodeLibelleRef3($v = true)
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef3Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByCodeLibelleRef3 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByCodeLibelleRef3 collection to an empty array (like clearcollTParametreFormsRelatedByCodeLibelleRef3());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByCodeLibelleRef3($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByCodeLibelleRef3 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByCodeLibelleRef3 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByCodeLibelleRef3->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByCodeLibelleRef3($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleRef3Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleRef3 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleRef3) {
                // return empty collection
                $this->initTParametreFormsRelatedByCodeLibelleRef3();
            } else {
                $collTParametreFormsRelatedByCodeLibelleRef3 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleRef3($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByCodeLibelleRef3Partial && count($collTParametreFormsRelatedByCodeLibelleRef3)) {
                      $this->initTParametreFormsRelatedByCodeLibelleRef3(false);

                      foreach($collTParametreFormsRelatedByCodeLibelleRef3 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByCodeLibelleRef3->contains($obj)) {
                          $this->collTParametreFormsRelatedByCodeLibelleRef3->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByCodeLibelleRef3Partial = true;
                    }

                    $collTParametreFormsRelatedByCodeLibelleRef3->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByCodeLibelleRef3;
                }

                if($partial && $this->collTParametreFormsRelatedByCodeLibelleRef3) {
                    foreach($this->collTParametreFormsRelatedByCodeLibelleRef3 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByCodeLibelleRef3[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByCodeLibelleRef3 = $collTParametreFormsRelatedByCodeLibelleRef3;
                $this->collTParametreFormsRelatedByCodeLibelleRef3Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByCodeLibelleRef3;
    }

    /**
     * Sets a collection of TParametreFormRelatedByCodeLibelleRef3 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByCodeLibelleRef3 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByCodeLibelleRef3(PropelCollection $tParametreFormsRelatedByCodeLibelleRef3, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByCodeLibelleRef3ToDelete = $this->getTParametreFormsRelatedByCodeLibelleRef3(new Criteria(), $con)->diff($tParametreFormsRelatedByCodeLibelleRef3);

        $this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByCodeLibelleRef3ToDelete));

        foreach ($tParametreFormsRelatedByCodeLibelleRef3ToDelete as $tParametreFormRelatedByCodeLibelleRef3Removed) {
            $tParametreFormRelatedByCodeLibelleRef3Removed->setTTraductionRelatedByCodeLibelleRef3(null);
        }

        $this->collTParametreFormsRelatedByCodeLibelleRef3 = null;
        foreach ($tParametreFormsRelatedByCodeLibelleRef3 as $tParametreFormRelatedByCodeLibelleRef3) {
            $this->addTParametreFormRelatedByCodeLibelleRef3($tParametreFormRelatedByCodeLibelleRef3);
        }

        $this->collTParametreFormsRelatedByCodeLibelleRef3 = $tParametreFormsRelatedByCodeLibelleRef3;
        $this->collTParametreFormsRelatedByCodeLibelleRef3Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByCodeLibelleRef3(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleRef3Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleRef3 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleRef3) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByCodeLibelleRef3());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleRef3($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByCodeLibelleRef3);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByCodeLibelleRef3(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByCodeLibelleRef3 === null) {
            $this->initTParametreFormsRelatedByCodeLibelleRef3();
            $this->collTParametreFormsRelatedByCodeLibelleRef3Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByCodeLibelleRef3->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByCodeLibelleRef3($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleRef3 $tParametreFormRelatedByCodeLibelleRef3 The tParametreFormRelatedByCodeLibelleRef3 object to add.
     */
    protected function doAddTParametreFormRelatedByCodeLibelleRef3($tParametreFormRelatedByCodeLibelleRef3)
    {
        $this->collTParametreFormsRelatedByCodeLibelleRef3[]= $tParametreFormRelatedByCodeLibelleRef3;
        $tParametreFormRelatedByCodeLibelleRef3->setTTraductionRelatedByCodeLibelleRef3($this);
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleRef3 $tParametreFormRelatedByCodeLibelleRef3 The tParametreFormRelatedByCodeLibelleRef3 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByCodeLibelleRef3($tParametreFormRelatedByCodeLibelleRef3)
    {
        if ($this->getTParametreFormsRelatedByCodeLibelleRef3()->contains($tParametreFormRelatedByCodeLibelleRef3)) {
            $this->collTParametreFormsRelatedByCodeLibelleRef3->remove($this->collTParametreFormsRelatedByCodeLibelleRef3->search($tParametreFormRelatedByCodeLibelleRef3));
            if (null === $this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion) {
                $this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion = clone $this->collTParametreFormsRelatedByCodeLibelleRef3;
                $this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByCodeLibelleRef3ScheduledForDeletion[]= $tParametreFormRelatedByCodeLibelleRef3;
            $tParametreFormRelatedByCodeLibelleRef3->setTTraductionRelatedByCodeLibelleRef3(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef3JoinTReferentielRelatedByIdRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef3JoinTReferentielRelatedByIdRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleRef3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleRef3JoinTReferentielRelatedByIdRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleRef3($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByCodeLibelleText1 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByCodeLibelleText1()
     */
    public function clearTParametreFormsRelatedByCodeLibelleText1()
    {
        $this->collTParametreFormsRelatedByCodeLibelleText1 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByCodeLibelleText1Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByCodeLibelleText1 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByCodeLibelleText1($v = true)
    {
        $this->collTParametreFormsRelatedByCodeLibelleText1Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByCodeLibelleText1 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByCodeLibelleText1 collection to an empty array (like clearcollTParametreFormsRelatedByCodeLibelleText1());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByCodeLibelleText1($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByCodeLibelleText1 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByCodeLibelleText1 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByCodeLibelleText1->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByCodeLibelleText1($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleText1Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleText1 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleText1) {
                // return empty collection
                $this->initTParametreFormsRelatedByCodeLibelleText1();
            } else {
                $collTParametreFormsRelatedByCodeLibelleText1 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleText1($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByCodeLibelleText1Partial && count($collTParametreFormsRelatedByCodeLibelleText1)) {
                      $this->initTParametreFormsRelatedByCodeLibelleText1(false);

                      foreach($collTParametreFormsRelatedByCodeLibelleText1 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByCodeLibelleText1->contains($obj)) {
                          $this->collTParametreFormsRelatedByCodeLibelleText1->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByCodeLibelleText1Partial = true;
                    }

                    $collTParametreFormsRelatedByCodeLibelleText1->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByCodeLibelleText1;
                }

                if($partial && $this->collTParametreFormsRelatedByCodeLibelleText1) {
                    foreach($this->collTParametreFormsRelatedByCodeLibelleText1 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByCodeLibelleText1[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByCodeLibelleText1 = $collTParametreFormsRelatedByCodeLibelleText1;
                $this->collTParametreFormsRelatedByCodeLibelleText1Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByCodeLibelleText1;
    }

    /**
     * Sets a collection of TParametreFormRelatedByCodeLibelleText1 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByCodeLibelleText1 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByCodeLibelleText1(PropelCollection $tParametreFormsRelatedByCodeLibelleText1, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByCodeLibelleText1ToDelete = $this->getTParametreFormsRelatedByCodeLibelleText1(new Criteria(), $con)->diff($tParametreFormsRelatedByCodeLibelleText1);

        $this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByCodeLibelleText1ToDelete));

        foreach ($tParametreFormsRelatedByCodeLibelleText1ToDelete as $tParametreFormRelatedByCodeLibelleText1Removed) {
            $tParametreFormRelatedByCodeLibelleText1Removed->setTTraductionRelatedByCodeLibelleText1(null);
        }

        $this->collTParametreFormsRelatedByCodeLibelleText1 = null;
        foreach ($tParametreFormsRelatedByCodeLibelleText1 as $tParametreFormRelatedByCodeLibelleText1) {
            $this->addTParametreFormRelatedByCodeLibelleText1($tParametreFormRelatedByCodeLibelleText1);
        }

        $this->collTParametreFormsRelatedByCodeLibelleText1 = $tParametreFormsRelatedByCodeLibelleText1;
        $this->collTParametreFormsRelatedByCodeLibelleText1Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByCodeLibelleText1(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleText1Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleText1 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleText1) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByCodeLibelleText1());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleText1($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByCodeLibelleText1);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByCodeLibelleText1(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByCodeLibelleText1 === null) {
            $this->initTParametreFormsRelatedByCodeLibelleText1();
            $this->collTParametreFormsRelatedByCodeLibelleText1Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByCodeLibelleText1->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByCodeLibelleText1($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleText1 $tParametreFormRelatedByCodeLibelleText1 The tParametreFormRelatedByCodeLibelleText1 object to add.
     */
    protected function doAddTParametreFormRelatedByCodeLibelleText1($tParametreFormRelatedByCodeLibelleText1)
    {
        $this->collTParametreFormsRelatedByCodeLibelleText1[]= $tParametreFormRelatedByCodeLibelleText1;
        $tParametreFormRelatedByCodeLibelleText1->setTTraductionRelatedByCodeLibelleText1($this);
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleText1 $tParametreFormRelatedByCodeLibelleText1 The tParametreFormRelatedByCodeLibelleText1 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByCodeLibelleText1($tParametreFormRelatedByCodeLibelleText1)
    {
        if ($this->getTParametreFormsRelatedByCodeLibelleText1()->contains($tParametreFormRelatedByCodeLibelleText1)) {
            $this->collTParametreFormsRelatedByCodeLibelleText1->remove($this->collTParametreFormsRelatedByCodeLibelleText1->search($tParametreFormRelatedByCodeLibelleText1));
            if (null === $this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion) {
                $this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion = clone $this->collTParametreFormsRelatedByCodeLibelleText1;
                $this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByCodeLibelleText1ScheduledForDeletion[]= $tParametreFormRelatedByCodeLibelleText1;
            $tParametreFormRelatedByCodeLibelleText1->setTTraductionRelatedByCodeLibelleText1(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText1JoinTReferentielRelatedByIdRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText1JoinTReferentielRelatedByIdRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText1($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText1 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText1JoinTReferentielRelatedByIdRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText1($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByCodeLibelleText2 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByCodeLibelleText2()
     */
    public function clearTParametreFormsRelatedByCodeLibelleText2()
    {
        $this->collTParametreFormsRelatedByCodeLibelleText2 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByCodeLibelleText2Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByCodeLibelleText2 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByCodeLibelleText2($v = true)
    {
        $this->collTParametreFormsRelatedByCodeLibelleText2Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByCodeLibelleText2 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByCodeLibelleText2 collection to an empty array (like clearcollTParametreFormsRelatedByCodeLibelleText2());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByCodeLibelleText2($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByCodeLibelleText2 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByCodeLibelleText2 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByCodeLibelleText2->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByCodeLibelleText2($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleText2Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleText2 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleText2) {
                // return empty collection
                $this->initTParametreFormsRelatedByCodeLibelleText2();
            } else {
                $collTParametreFormsRelatedByCodeLibelleText2 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleText2($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByCodeLibelleText2Partial && count($collTParametreFormsRelatedByCodeLibelleText2)) {
                      $this->initTParametreFormsRelatedByCodeLibelleText2(false);

                      foreach($collTParametreFormsRelatedByCodeLibelleText2 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByCodeLibelleText2->contains($obj)) {
                          $this->collTParametreFormsRelatedByCodeLibelleText2->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByCodeLibelleText2Partial = true;
                    }

                    $collTParametreFormsRelatedByCodeLibelleText2->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByCodeLibelleText2;
                }

                if($partial && $this->collTParametreFormsRelatedByCodeLibelleText2) {
                    foreach($this->collTParametreFormsRelatedByCodeLibelleText2 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByCodeLibelleText2[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByCodeLibelleText2 = $collTParametreFormsRelatedByCodeLibelleText2;
                $this->collTParametreFormsRelatedByCodeLibelleText2Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByCodeLibelleText2;
    }

    /**
     * Sets a collection of TParametreFormRelatedByCodeLibelleText2 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByCodeLibelleText2 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByCodeLibelleText2(PropelCollection $tParametreFormsRelatedByCodeLibelleText2, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByCodeLibelleText2ToDelete = $this->getTParametreFormsRelatedByCodeLibelleText2(new Criteria(), $con)->diff($tParametreFormsRelatedByCodeLibelleText2);

        $this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByCodeLibelleText2ToDelete));

        foreach ($tParametreFormsRelatedByCodeLibelleText2ToDelete as $tParametreFormRelatedByCodeLibelleText2Removed) {
            $tParametreFormRelatedByCodeLibelleText2Removed->setTTraductionRelatedByCodeLibelleText2(null);
        }

        $this->collTParametreFormsRelatedByCodeLibelleText2 = null;
        foreach ($tParametreFormsRelatedByCodeLibelleText2 as $tParametreFormRelatedByCodeLibelleText2) {
            $this->addTParametreFormRelatedByCodeLibelleText2($tParametreFormRelatedByCodeLibelleText2);
        }

        $this->collTParametreFormsRelatedByCodeLibelleText2 = $tParametreFormsRelatedByCodeLibelleText2;
        $this->collTParametreFormsRelatedByCodeLibelleText2Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByCodeLibelleText2(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleText2Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleText2 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleText2) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByCodeLibelleText2());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleText2($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByCodeLibelleText2);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByCodeLibelleText2(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByCodeLibelleText2 === null) {
            $this->initTParametreFormsRelatedByCodeLibelleText2();
            $this->collTParametreFormsRelatedByCodeLibelleText2Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByCodeLibelleText2->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByCodeLibelleText2($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleText2 $tParametreFormRelatedByCodeLibelleText2 The tParametreFormRelatedByCodeLibelleText2 object to add.
     */
    protected function doAddTParametreFormRelatedByCodeLibelleText2($tParametreFormRelatedByCodeLibelleText2)
    {
        $this->collTParametreFormsRelatedByCodeLibelleText2[]= $tParametreFormRelatedByCodeLibelleText2;
        $tParametreFormRelatedByCodeLibelleText2->setTTraductionRelatedByCodeLibelleText2($this);
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleText2 $tParametreFormRelatedByCodeLibelleText2 The tParametreFormRelatedByCodeLibelleText2 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByCodeLibelleText2($tParametreFormRelatedByCodeLibelleText2)
    {
        if ($this->getTParametreFormsRelatedByCodeLibelleText2()->contains($tParametreFormRelatedByCodeLibelleText2)) {
            $this->collTParametreFormsRelatedByCodeLibelleText2->remove($this->collTParametreFormsRelatedByCodeLibelleText2->search($tParametreFormRelatedByCodeLibelleText2));
            if (null === $this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion) {
                $this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion = clone $this->collTParametreFormsRelatedByCodeLibelleText2;
                $this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByCodeLibelleText2ScheduledForDeletion[]= $tParametreFormRelatedByCodeLibelleText2;
            $tParametreFormRelatedByCodeLibelleText2->setTTraductionRelatedByCodeLibelleText2(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText2JoinTReferentielRelatedByIdRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText2JoinTReferentielRelatedByIdRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText2($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText2 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText2JoinTReferentielRelatedByIdRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText2($query, $con);
    }

    /**
     * Clears out the collTParametreFormsRelatedByCodeLibelleText3 collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTParametreFormsRelatedByCodeLibelleText3()
     */
    public function clearTParametreFormsRelatedByCodeLibelleText3()
    {
        $this->collTParametreFormsRelatedByCodeLibelleText3 = null; // important to set this to null since that means it is uninitialized
        $this->collTParametreFormsRelatedByCodeLibelleText3Partial = null;

        return $this;
    }

    /**
     * reset is the collTParametreFormsRelatedByCodeLibelleText3 collection loaded partially
     *
     * @return void
     */
    public function resetPartialTParametreFormsRelatedByCodeLibelleText3($v = true)
    {
        $this->collTParametreFormsRelatedByCodeLibelleText3Partial = $v;
    }

    /**
     * Initializes the collTParametreFormsRelatedByCodeLibelleText3 collection.
     *
     * By default this just sets the collTParametreFormsRelatedByCodeLibelleText3 collection to an empty array (like clearcollTParametreFormsRelatedByCodeLibelleText3());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTParametreFormsRelatedByCodeLibelleText3($overrideExisting = true)
    {
        if (null !== $this->collTParametreFormsRelatedByCodeLibelleText3 && !$overrideExisting) {
            return;
        }
        $this->collTParametreFormsRelatedByCodeLibelleText3 = new PropelObjectCollection();
        $this->collTParametreFormsRelatedByCodeLibelleText3->setModel('TParametreForm');
    }

    /**
     * Gets an array of TParametreForm objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     * @throws PropelException
     */
    public function getTParametreFormsRelatedByCodeLibelleText3($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleText3Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleText3 || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleText3) {
                // return empty collection
                $this->initTParametreFormsRelatedByCodeLibelleText3();
            } else {
                $collTParametreFormsRelatedByCodeLibelleText3 = TParametreFormQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleText3($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTParametreFormsRelatedByCodeLibelleText3Partial && count($collTParametreFormsRelatedByCodeLibelleText3)) {
                      $this->initTParametreFormsRelatedByCodeLibelleText3(false);

                      foreach($collTParametreFormsRelatedByCodeLibelleText3 as $obj) {
                        if (false == $this->collTParametreFormsRelatedByCodeLibelleText3->contains($obj)) {
                          $this->collTParametreFormsRelatedByCodeLibelleText3->append($obj);
                        }
                      }

                      $this->collTParametreFormsRelatedByCodeLibelleText3Partial = true;
                    }

                    $collTParametreFormsRelatedByCodeLibelleText3->getInternalIterator()->rewind();
                    return $collTParametreFormsRelatedByCodeLibelleText3;
                }

                if($partial && $this->collTParametreFormsRelatedByCodeLibelleText3) {
                    foreach($this->collTParametreFormsRelatedByCodeLibelleText3 as $obj) {
                        if($obj->isNew()) {
                            $collTParametreFormsRelatedByCodeLibelleText3[] = $obj;
                        }
                    }
                }

                $this->collTParametreFormsRelatedByCodeLibelleText3 = $collTParametreFormsRelatedByCodeLibelleText3;
                $this->collTParametreFormsRelatedByCodeLibelleText3Partial = false;
            }
        }

        return $this->collTParametreFormsRelatedByCodeLibelleText3;
    }

    /**
     * Sets a collection of TParametreFormRelatedByCodeLibelleText3 objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tParametreFormsRelatedByCodeLibelleText3 A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTParametreFormsRelatedByCodeLibelleText3(PropelCollection $tParametreFormsRelatedByCodeLibelleText3, PropelPDO $con = null)
    {
        $tParametreFormsRelatedByCodeLibelleText3ToDelete = $this->getTParametreFormsRelatedByCodeLibelleText3(new Criteria(), $con)->diff($tParametreFormsRelatedByCodeLibelleText3);

        $this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion = unserialize(serialize($tParametreFormsRelatedByCodeLibelleText3ToDelete));

        foreach ($tParametreFormsRelatedByCodeLibelleText3ToDelete as $tParametreFormRelatedByCodeLibelleText3Removed) {
            $tParametreFormRelatedByCodeLibelleText3Removed->setTTraductionRelatedByCodeLibelleText3(null);
        }

        $this->collTParametreFormsRelatedByCodeLibelleText3 = null;
        foreach ($tParametreFormsRelatedByCodeLibelleText3 as $tParametreFormRelatedByCodeLibelleText3) {
            $this->addTParametreFormRelatedByCodeLibelleText3($tParametreFormRelatedByCodeLibelleText3);
        }

        $this->collTParametreFormsRelatedByCodeLibelleText3 = $tParametreFormsRelatedByCodeLibelleText3;
        $this->collTParametreFormsRelatedByCodeLibelleText3Partial = false;

        return $this;
    }

    /**
     * Returns the number of related TParametreForm objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TParametreForm objects.
     * @throws PropelException
     */
    public function countTParametreFormsRelatedByCodeLibelleText3(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTParametreFormsRelatedByCodeLibelleText3Partial && !$this->isNew();
        if (null === $this->collTParametreFormsRelatedByCodeLibelleText3 || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTParametreFormsRelatedByCodeLibelleText3) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTParametreFormsRelatedByCodeLibelleText3());
            }
            $query = TParametreFormQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleText3($this)
                ->count($con);
        }

        return count($this->collTParametreFormsRelatedByCodeLibelleText3);
    }

    /**
     * Method called to associate a TParametreForm object to this object
     * through the TParametreForm foreign key attribute.
     *
     * @param    TParametreForm $l TParametreForm
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTParametreFormRelatedByCodeLibelleText3(TParametreForm $l)
    {
        if ($this->collTParametreFormsRelatedByCodeLibelleText3 === null) {
            $this->initTParametreFormsRelatedByCodeLibelleText3();
            $this->collTParametreFormsRelatedByCodeLibelleText3Partial = true;
        }
        if (!in_array($l, $this->collTParametreFormsRelatedByCodeLibelleText3->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTParametreFormRelatedByCodeLibelleText3($l);
        }

        return $this;
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleText3 $tParametreFormRelatedByCodeLibelleText3 The tParametreFormRelatedByCodeLibelleText3 object to add.
     */
    protected function doAddTParametreFormRelatedByCodeLibelleText3($tParametreFormRelatedByCodeLibelleText3)
    {
        $this->collTParametreFormsRelatedByCodeLibelleText3[]= $tParametreFormRelatedByCodeLibelleText3;
        $tParametreFormRelatedByCodeLibelleText3->setTTraductionRelatedByCodeLibelleText3($this);
    }

    /**
     * @param	TParametreFormRelatedByCodeLibelleText3 $tParametreFormRelatedByCodeLibelleText3 The tParametreFormRelatedByCodeLibelleText3 object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTParametreFormRelatedByCodeLibelleText3($tParametreFormRelatedByCodeLibelleText3)
    {
        if ($this->getTParametreFormsRelatedByCodeLibelleText3()->contains($tParametreFormRelatedByCodeLibelleText3)) {
            $this->collTParametreFormsRelatedByCodeLibelleText3->remove($this->collTParametreFormsRelatedByCodeLibelleText3->search($tParametreFormRelatedByCodeLibelleText3));
            if (null === $this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion) {
                $this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion = clone $this->collTParametreFormsRelatedByCodeLibelleText3;
                $this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion->clear();
            }
            $this->tParametreFormsRelatedByCodeLibelleText3ScheduledForDeletion[]= $tParametreFormRelatedByCodeLibelleText3;
            $tParametreFormRelatedByCodeLibelleText3->setTTraductionRelatedByCodeLibelleText3(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText3JoinTReferentielRelatedByIdRef1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef1', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText3JoinTReferentielRelatedByIdRef2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef2', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText3($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TParametreFormsRelatedByCodeLibelleText3 from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TParametreForm[] List of TParametreForm objects
     */
    public function getTParametreFormsRelatedByCodeLibelleText3JoinTReferentielRelatedByIdRef3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TParametreFormQuery::create(null, $criteria);
        $query->joinWith('TReferentielRelatedByIdRef3', $join_behavior);

        return $this->getTParametreFormsRelatedByCodeLibelleText3($query, $con);
    }

    /**
     * Clears out the collTPieceParamPrestas collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTPieceParamPrestas()
     */
    public function clearTPieceParamPrestas()
    {
        $this->collTPieceParamPrestas = null; // important to set this to null since that means it is uninitialized
        $this->collTPieceParamPrestasPartial = null;

        return $this;
    }

    /**
     * reset is the collTPieceParamPrestas collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPieceParamPrestas($v = true)
    {
        $this->collTPieceParamPrestasPartial = $v;
    }

    /**
     * Initializes the collTPieceParamPrestas collection.
     *
     * By default this just sets the collTPieceParamPrestas collection to an empty array (like clearcollTPieceParamPrestas());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPieceParamPrestas($overrideExisting = true)
    {
        if (null !== $this->collTPieceParamPrestas && !$overrideExisting) {
            return;
        }
        $this->collTPieceParamPrestas = new PropelObjectCollection();
        $this->collTPieceParamPrestas->setModel('TPieceParamPresta');
    }

    /**
     * Gets an array of TPieceParamPresta objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPieceParamPresta[] List of TPieceParamPresta objects
     * @throws PropelException
     */
    public function getTPieceParamPrestas($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPieceParamPrestasPartial && !$this->isNew();
        if (null === $this->collTPieceParamPrestas || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPieceParamPrestas) {
                // return empty collection
                $this->initTPieceParamPrestas();
            } else {
                $collTPieceParamPrestas = TPieceParamPrestaQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPieceParamPrestasPartial && count($collTPieceParamPrestas)) {
                      $this->initTPieceParamPrestas(false);

                      foreach($collTPieceParamPrestas as $obj) {
                        if (false == $this->collTPieceParamPrestas->contains($obj)) {
                          $this->collTPieceParamPrestas->append($obj);
                        }
                      }

                      $this->collTPieceParamPrestasPartial = true;
                    }

                    $collTPieceParamPrestas->getInternalIterator()->rewind();
                    return $collTPieceParamPrestas;
                }

                if($partial && $this->collTPieceParamPrestas) {
                    foreach($this->collTPieceParamPrestas as $obj) {
                        if($obj->isNew()) {
                            $collTPieceParamPrestas[] = $obj;
                        }
                    }
                }

                $this->collTPieceParamPrestas = $collTPieceParamPrestas;
                $this->collTPieceParamPrestasPartial = false;
            }
        }

        return $this->collTPieceParamPrestas;
    }

    /**
     * Sets a collection of TPieceParamPresta objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPieceParamPrestas A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTPieceParamPrestas(PropelCollection $tPieceParamPrestas, PropelPDO $con = null)
    {
        $tPieceParamPrestasToDelete = $this->getTPieceParamPrestas(new Criteria(), $con)->diff($tPieceParamPrestas);

        $this->tPieceParamPrestasScheduledForDeletion = unserialize(serialize($tPieceParamPrestasToDelete));

        foreach ($tPieceParamPrestasToDelete as $tPieceParamPrestaRemoved) {
            $tPieceParamPrestaRemoved->setTTraduction(null);
        }

        $this->collTPieceParamPrestas = null;
        foreach ($tPieceParamPrestas as $tPieceParamPresta) {
            $this->addTPieceParamPresta($tPieceParamPresta);
        }

        $this->collTPieceParamPrestas = $tPieceParamPrestas;
        $this->collTPieceParamPrestasPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPieceParamPresta objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPieceParamPresta objects.
     * @throws PropelException
     */
    public function countTPieceParamPrestas(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPieceParamPrestasPartial && !$this->isNew();
        if (null === $this->collTPieceParamPrestas || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPieceParamPrestas) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPieceParamPrestas());
            }
            $query = TPieceParamPrestaQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTPieceParamPrestas);
    }

    /**
     * Method called to associate a TPieceParamPresta object to this object
     * through the TPieceParamPresta foreign key attribute.
     *
     * @param    TPieceParamPresta $l TPieceParamPresta
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTPieceParamPresta(TPieceParamPresta $l)
    {
        if ($this->collTPieceParamPrestas === null) {
            $this->initTPieceParamPrestas();
            $this->collTPieceParamPrestasPartial = true;
        }
        if (!in_array($l, $this->collTPieceParamPrestas->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPieceParamPresta($l);
        }

        return $this;
    }

    /**
     * @param	TPieceParamPresta $tPieceParamPresta The tPieceParamPresta object to add.
     */
    protected function doAddTPieceParamPresta($tPieceParamPresta)
    {
        $this->collTPieceParamPrestas[]= $tPieceParamPresta;
        $tPieceParamPresta->setTTraduction($this);
    }

    /**
     * @param	TPieceParamPresta $tPieceParamPresta The tPieceParamPresta object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTPieceParamPresta($tPieceParamPresta)
    {
        if ($this->getTPieceParamPrestas()->contains($tPieceParamPresta)) {
            $this->collTPieceParamPrestas->remove($this->collTPieceParamPrestas->search($tPieceParamPresta));
            if (null === $this->tPieceParamPrestasScheduledForDeletion) {
                $this->tPieceParamPrestasScheduledForDeletion = clone $this->collTPieceParamPrestas;
                $this->tPieceParamPrestasScheduledForDeletion->clear();
            }
            $this->tPieceParamPrestasScheduledForDeletion[]= clone $tPieceParamPresta;
            $tPieceParamPresta->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPieceParamPrestas from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPieceParamPresta[] List of TPieceParamPresta objects
     */
    public function getTPieceParamPrestasJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPieceParamPrestaQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTPieceParamPrestas($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPieceParamPrestas from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPieceParamPresta[] List of TPieceParamPresta objects
     */
    public function getTPieceParamPrestasJoinTParametragePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPieceParamPrestaQuery::create(null, $criteria);
        $query->joinWith('TParametragePrestation', $join_behavior);

        return $this->getTPieceParamPrestas($query, $con);
    }

    /**
     * Clears out the collTPiecePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTPiecePrestations()
     */
    public function clearTPiecePrestations()
    {
        $this->collTPiecePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTPiecePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTPiecePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPiecePrestations($v = true)
    {
        $this->collTPiecePrestationsPartial = $v;
    }

    /**
     * Initializes the collTPiecePrestations collection.
     *
     * By default this just sets the collTPiecePrestations collection to an empty array (like clearcollTPiecePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPiecePrestations($overrideExisting = true)
    {
        if (null !== $this->collTPiecePrestations && !$overrideExisting) {
            return;
        }
        $this->collTPiecePrestations = new PropelObjectCollection();
        $this->collTPiecePrestations->setModel('TPiecePrestation');
    }

    /**
     * Gets an array of TPiecePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPiecePrestation[] List of TPiecePrestation objects
     * @throws PropelException
     */
    public function getTPiecePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPiecePrestationsPartial && !$this->isNew();
        if (null === $this->collTPiecePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPiecePrestations) {
                // return empty collection
                $this->initTPiecePrestations();
            } else {
                $collTPiecePrestations = TPiecePrestationQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPiecePrestationsPartial && count($collTPiecePrestations)) {
                      $this->initTPiecePrestations(false);

                      foreach($collTPiecePrestations as $obj) {
                        if (false == $this->collTPiecePrestations->contains($obj)) {
                          $this->collTPiecePrestations->append($obj);
                        }
                      }

                      $this->collTPiecePrestationsPartial = true;
                    }

                    $collTPiecePrestations->getInternalIterator()->rewind();
                    return $collTPiecePrestations;
                }

                if($partial && $this->collTPiecePrestations) {
                    foreach($this->collTPiecePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTPiecePrestations[] = $obj;
                        }
                    }
                }

                $this->collTPiecePrestations = $collTPiecePrestations;
                $this->collTPiecePrestationsPartial = false;
            }
        }

        return $this->collTPiecePrestations;
    }

    /**
     * Sets a collection of TPiecePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPiecePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTPiecePrestations(PropelCollection $tPiecePrestations, PropelPDO $con = null)
    {
        $tPiecePrestationsToDelete = $this->getTPiecePrestations(new Criteria(), $con)->diff($tPiecePrestations);

        $this->tPiecePrestationsScheduledForDeletion = unserialize(serialize($tPiecePrestationsToDelete));

        foreach ($tPiecePrestationsToDelete as $tPiecePrestationRemoved) {
            $tPiecePrestationRemoved->setTTraduction(null);
        }

        $this->collTPiecePrestations = null;
        foreach ($tPiecePrestations as $tPiecePrestation) {
            $this->addTPiecePrestation($tPiecePrestation);
        }

        $this->collTPiecePrestations = $tPiecePrestations;
        $this->collTPiecePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPiecePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPiecePrestation objects.
     * @throws PropelException
     */
    public function countTPiecePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPiecePrestationsPartial && !$this->isNew();
        if (null === $this->collTPiecePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPiecePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPiecePrestations());
            }
            $query = TPiecePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTPiecePrestations);
    }

    /**
     * Method called to associate a TPiecePrestation object to this object
     * through the TPiecePrestation foreign key attribute.
     *
     * @param    TPiecePrestation $l TPiecePrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTPiecePrestation(TPiecePrestation $l)
    {
        if ($this->collTPiecePrestations === null) {
            $this->initTPiecePrestations();
            $this->collTPiecePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTPiecePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPiecePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TPiecePrestation $tPiecePrestation The tPiecePrestation object to add.
     */
    protected function doAddTPiecePrestation($tPiecePrestation)
    {
        $this->collTPiecePrestations[]= $tPiecePrestation;
        $tPiecePrestation->setTTraduction($this);
    }

    /**
     * @param	TPiecePrestation $tPiecePrestation The tPiecePrestation object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTPiecePrestation($tPiecePrestation)
    {
        if ($this->getTPiecePrestations()->contains($tPiecePrestation)) {
            $this->collTPiecePrestations->remove($this->collTPiecePrestations->search($tPiecePrestation));
            if (null === $this->tPiecePrestationsScheduledForDeletion) {
                $this->tPiecePrestationsScheduledForDeletion = clone $this->collTPiecePrestations;
                $this->tPiecePrestationsScheduledForDeletion->clear();
            }
            $this->tPiecePrestationsScheduledForDeletion[]= clone $tPiecePrestation;
            $tPiecePrestation->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPiecePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPiecePrestation[] List of TPiecePrestation objects
     */
    public function getTPiecePrestationsJoinTBlob($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPiecePrestationQuery::create(null, $criteria);
        $query->joinWith('TBlob', $join_behavior);

        return $this->getTPiecePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPiecePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPiecePrestation[] List of TPiecePrestation objects
     */
    public function getTPiecePrestationsJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPiecePrestationQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTPiecePrestations($query, $con);
    }

    /**
     * Clears out the collTPrestationsRelatedByCodeCommentaire collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTPrestationsRelatedByCodeCommentaire()
     */
    public function clearTPrestationsRelatedByCodeCommentaire()
    {
        $this->collTPrestationsRelatedByCodeCommentaire = null; // important to set this to null since that means it is uninitialized
        $this->collTPrestationsRelatedByCodeCommentairePartial = null;

        return $this;
    }

    /**
     * reset is the collTPrestationsRelatedByCodeCommentaire collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPrestationsRelatedByCodeCommentaire($v = true)
    {
        $this->collTPrestationsRelatedByCodeCommentairePartial = $v;
    }

    /**
     * Initializes the collTPrestationsRelatedByCodeCommentaire collection.
     *
     * By default this just sets the collTPrestationsRelatedByCodeCommentaire collection to an empty array (like clearcollTPrestationsRelatedByCodeCommentaire());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPrestationsRelatedByCodeCommentaire($overrideExisting = true)
    {
        if (null !== $this->collTPrestationsRelatedByCodeCommentaire && !$overrideExisting) {
            return;
        }
        $this->collTPrestationsRelatedByCodeCommentaire = new PropelObjectCollection();
        $this->collTPrestationsRelatedByCodeCommentaire->setModel('TPrestation');
    }

    /**
     * Gets an array of TPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     * @throws PropelException
     */
    public function getTPrestationsRelatedByCodeCommentaire($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByCodeCommentairePartial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByCodeCommentaire || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByCodeCommentaire) {
                // return empty collection
                $this->initTPrestationsRelatedByCodeCommentaire();
            } else {
                $collTPrestationsRelatedByCodeCommentaire = TPrestationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeCommentaire($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPrestationsRelatedByCodeCommentairePartial && count($collTPrestationsRelatedByCodeCommentaire)) {
                      $this->initTPrestationsRelatedByCodeCommentaire(false);

                      foreach($collTPrestationsRelatedByCodeCommentaire as $obj) {
                        if (false == $this->collTPrestationsRelatedByCodeCommentaire->contains($obj)) {
                          $this->collTPrestationsRelatedByCodeCommentaire->append($obj);
                        }
                      }

                      $this->collTPrestationsRelatedByCodeCommentairePartial = true;
                    }

                    $collTPrestationsRelatedByCodeCommentaire->getInternalIterator()->rewind();
                    return $collTPrestationsRelatedByCodeCommentaire;
                }

                if($partial && $this->collTPrestationsRelatedByCodeCommentaire) {
                    foreach($this->collTPrestationsRelatedByCodeCommentaire as $obj) {
                        if($obj->isNew()) {
                            $collTPrestationsRelatedByCodeCommentaire[] = $obj;
                        }
                    }
                }

                $this->collTPrestationsRelatedByCodeCommentaire = $collTPrestationsRelatedByCodeCommentaire;
                $this->collTPrestationsRelatedByCodeCommentairePartial = false;
            }
        }

        return $this->collTPrestationsRelatedByCodeCommentaire;
    }

    /**
     * Sets a collection of TPrestationRelatedByCodeCommentaire objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPrestationsRelatedByCodeCommentaire A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTPrestationsRelatedByCodeCommentaire(PropelCollection $tPrestationsRelatedByCodeCommentaire, PropelPDO $con = null)
    {
        $tPrestationsRelatedByCodeCommentaireToDelete = $this->getTPrestationsRelatedByCodeCommentaire(new Criteria(), $con)->diff($tPrestationsRelatedByCodeCommentaire);

        $this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion = unserialize(serialize($tPrestationsRelatedByCodeCommentaireToDelete));

        foreach ($tPrestationsRelatedByCodeCommentaireToDelete as $tPrestationRelatedByCodeCommentaireRemoved) {
            $tPrestationRelatedByCodeCommentaireRemoved->setTTraductionRelatedByCodeCommentaire(null);
        }

        $this->collTPrestationsRelatedByCodeCommentaire = null;
        foreach ($tPrestationsRelatedByCodeCommentaire as $tPrestationRelatedByCodeCommentaire) {
            $this->addTPrestationRelatedByCodeCommentaire($tPrestationRelatedByCodeCommentaire);
        }

        $this->collTPrestationsRelatedByCodeCommentaire = $tPrestationsRelatedByCodeCommentaire;
        $this->collTPrestationsRelatedByCodeCommentairePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPrestation objects.
     * @throws PropelException
     */
    public function countTPrestationsRelatedByCodeCommentaire(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByCodeCommentairePartial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByCodeCommentaire || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByCodeCommentaire) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPrestationsRelatedByCodeCommentaire());
            }
            $query = TPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeCommentaire($this)
                ->count($con);
        }

        return count($this->collTPrestationsRelatedByCodeCommentaire);
    }

    /**
     * Method called to associate a TPrestation object to this object
     * through the TPrestation foreign key attribute.
     *
     * @param    TPrestation $l TPrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTPrestationRelatedByCodeCommentaire(TPrestation $l)
    {
        if ($this->collTPrestationsRelatedByCodeCommentaire === null) {
            $this->initTPrestationsRelatedByCodeCommentaire();
            $this->collTPrestationsRelatedByCodeCommentairePartial = true;
        }
        if (!in_array($l, $this->collTPrestationsRelatedByCodeCommentaire->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPrestationRelatedByCodeCommentaire($l);
        }

        return $this;
    }

    /**
     * @param	TPrestationRelatedByCodeCommentaire $tPrestationRelatedByCodeCommentaire The tPrestationRelatedByCodeCommentaire object to add.
     */
    protected function doAddTPrestationRelatedByCodeCommentaire($tPrestationRelatedByCodeCommentaire)
    {
        $this->collTPrestationsRelatedByCodeCommentaire[]= $tPrestationRelatedByCodeCommentaire;
        $tPrestationRelatedByCodeCommentaire->setTTraductionRelatedByCodeCommentaire($this);
    }

    /**
     * @param	TPrestationRelatedByCodeCommentaire $tPrestationRelatedByCodeCommentaire The tPrestationRelatedByCodeCommentaire object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTPrestationRelatedByCodeCommentaire($tPrestationRelatedByCodeCommentaire)
    {
        if ($this->getTPrestationsRelatedByCodeCommentaire()->contains($tPrestationRelatedByCodeCommentaire)) {
            $this->collTPrestationsRelatedByCodeCommentaire->remove($this->collTPrestationsRelatedByCodeCommentaire->search($tPrestationRelatedByCodeCommentaire));
            if (null === $this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion) {
                $this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion = clone $this->collTPrestationsRelatedByCodeCommentaire;
                $this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion->clear();
            }
            $this->tPrestationsRelatedByCodeCommentaireScheduledForDeletion[]= $tPrestationRelatedByCodeCommentaire;
            $tPrestationRelatedByCodeCommentaire->setTTraductionRelatedByCodeCommentaire(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeCommentaireJoinTParametragePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametragePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeCommentaireJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTPrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeCommentaireJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTPrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeCommentaireJoinTTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTypePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeCommentaireJoinTChampsSuppRelatedByIdChampsSupp1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp1', $join_behavior);

        return $this->getTPrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeCommentaireJoinTChampsSuppRelatedByIdChampsSupp2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp2', $join_behavior);

        return $this->getTPrestationsRelatedByCodeCommentaire($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeCommentaire from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeCommentaireJoinTChampsSuppRelatedByIdChampsSupp3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp3', $join_behavior);

        return $this->getTPrestationsRelatedByCodeCommentaire($query, $con);
    }

    /**
     * Clears out the collTPrestationsRelatedByCodeLibellePrestation collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTPrestationsRelatedByCodeLibellePrestation()
     */
    public function clearTPrestationsRelatedByCodeLibellePrestation()
    {
        $this->collTPrestationsRelatedByCodeLibellePrestation = null; // important to set this to null since that means it is uninitialized
        $this->collTPrestationsRelatedByCodeLibellePrestationPartial = null;

        return $this;
    }

    /**
     * reset is the collTPrestationsRelatedByCodeLibellePrestation collection loaded partially
     *
     * @return void
     */
    public function resetPartialTPrestationsRelatedByCodeLibellePrestation($v = true)
    {
        $this->collTPrestationsRelatedByCodeLibellePrestationPartial = $v;
    }

    /**
     * Initializes the collTPrestationsRelatedByCodeLibellePrestation collection.
     *
     * By default this just sets the collTPrestationsRelatedByCodeLibellePrestation collection to an empty array (like clearcollTPrestationsRelatedByCodeLibellePrestation());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTPrestationsRelatedByCodeLibellePrestation($overrideExisting = true)
    {
        if (null !== $this->collTPrestationsRelatedByCodeLibellePrestation && !$overrideExisting) {
            return;
        }
        $this->collTPrestationsRelatedByCodeLibellePrestation = new PropelObjectCollection();
        $this->collTPrestationsRelatedByCodeLibellePrestation->setModel('TPrestation');
    }

    /**
     * Gets an array of TPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     * @throws PropelException
     */
    public function getTPrestationsRelatedByCodeLibellePrestation($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByCodeLibellePrestationPartial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByCodeLibellePrestation || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByCodeLibellePrestation) {
                // return empty collection
                $this->initTPrestationsRelatedByCodeLibellePrestation();
            } else {
                $collTPrestationsRelatedByCodeLibellePrestation = TPrestationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibellePrestation($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTPrestationsRelatedByCodeLibellePrestationPartial && count($collTPrestationsRelatedByCodeLibellePrestation)) {
                      $this->initTPrestationsRelatedByCodeLibellePrestation(false);

                      foreach($collTPrestationsRelatedByCodeLibellePrestation as $obj) {
                        if (false == $this->collTPrestationsRelatedByCodeLibellePrestation->contains($obj)) {
                          $this->collTPrestationsRelatedByCodeLibellePrestation->append($obj);
                        }
                      }

                      $this->collTPrestationsRelatedByCodeLibellePrestationPartial = true;
                    }

                    $collTPrestationsRelatedByCodeLibellePrestation->getInternalIterator()->rewind();
                    return $collTPrestationsRelatedByCodeLibellePrestation;
                }

                if($partial && $this->collTPrestationsRelatedByCodeLibellePrestation) {
                    foreach($this->collTPrestationsRelatedByCodeLibellePrestation as $obj) {
                        if($obj->isNew()) {
                            $collTPrestationsRelatedByCodeLibellePrestation[] = $obj;
                        }
                    }
                }

                $this->collTPrestationsRelatedByCodeLibellePrestation = $collTPrestationsRelatedByCodeLibellePrestation;
                $this->collTPrestationsRelatedByCodeLibellePrestationPartial = false;
            }
        }

        return $this->collTPrestationsRelatedByCodeLibellePrestation;
    }

    /**
     * Sets a collection of TPrestationRelatedByCodeLibellePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tPrestationsRelatedByCodeLibellePrestation A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTPrestationsRelatedByCodeLibellePrestation(PropelCollection $tPrestationsRelatedByCodeLibellePrestation, PropelPDO $con = null)
    {
        $tPrestationsRelatedByCodeLibellePrestationToDelete = $this->getTPrestationsRelatedByCodeLibellePrestation(new Criteria(), $con)->diff($tPrestationsRelatedByCodeLibellePrestation);

        $this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion = unserialize(serialize($tPrestationsRelatedByCodeLibellePrestationToDelete));

        foreach ($tPrestationsRelatedByCodeLibellePrestationToDelete as $tPrestationRelatedByCodeLibellePrestationRemoved) {
            $tPrestationRelatedByCodeLibellePrestationRemoved->setTTraductionRelatedByCodeLibellePrestation(null);
        }

        $this->collTPrestationsRelatedByCodeLibellePrestation = null;
        foreach ($tPrestationsRelatedByCodeLibellePrestation as $tPrestationRelatedByCodeLibellePrestation) {
            $this->addTPrestationRelatedByCodeLibellePrestation($tPrestationRelatedByCodeLibellePrestation);
        }

        $this->collTPrestationsRelatedByCodeLibellePrestation = $tPrestationsRelatedByCodeLibellePrestation;
        $this->collTPrestationsRelatedByCodeLibellePrestationPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TPrestation objects.
     * @throws PropelException
     */
    public function countTPrestationsRelatedByCodeLibellePrestation(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTPrestationsRelatedByCodeLibellePrestationPartial && !$this->isNew();
        if (null === $this->collTPrestationsRelatedByCodeLibellePrestation || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTPrestationsRelatedByCodeLibellePrestation) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTPrestationsRelatedByCodeLibellePrestation());
            }
            $query = TPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibellePrestation($this)
                ->count($con);
        }

        return count($this->collTPrestationsRelatedByCodeLibellePrestation);
    }

    /**
     * Method called to associate a TPrestation object to this object
     * through the TPrestation foreign key attribute.
     *
     * @param    TPrestation $l TPrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTPrestationRelatedByCodeLibellePrestation(TPrestation $l)
    {
        if ($this->collTPrestationsRelatedByCodeLibellePrestation === null) {
            $this->initTPrestationsRelatedByCodeLibellePrestation();
            $this->collTPrestationsRelatedByCodeLibellePrestationPartial = true;
        }
        if (!in_array($l, $this->collTPrestationsRelatedByCodeLibellePrestation->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTPrestationRelatedByCodeLibellePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TPrestationRelatedByCodeLibellePrestation $tPrestationRelatedByCodeLibellePrestation The tPrestationRelatedByCodeLibellePrestation object to add.
     */
    protected function doAddTPrestationRelatedByCodeLibellePrestation($tPrestationRelatedByCodeLibellePrestation)
    {
        $this->collTPrestationsRelatedByCodeLibellePrestation[]= $tPrestationRelatedByCodeLibellePrestation;
        $tPrestationRelatedByCodeLibellePrestation->setTTraductionRelatedByCodeLibellePrestation($this);
    }

    /**
     * @param	TPrestationRelatedByCodeLibellePrestation $tPrestationRelatedByCodeLibellePrestation The tPrestationRelatedByCodeLibellePrestation object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTPrestationRelatedByCodeLibellePrestation($tPrestationRelatedByCodeLibellePrestation)
    {
        if ($this->getTPrestationsRelatedByCodeLibellePrestation()->contains($tPrestationRelatedByCodeLibellePrestation)) {
            $this->collTPrestationsRelatedByCodeLibellePrestation->remove($this->collTPrestationsRelatedByCodeLibellePrestation->search($tPrestationRelatedByCodeLibellePrestation));
            if (null === $this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion) {
                $this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion = clone $this->collTPrestationsRelatedByCodeLibellePrestation;
                $this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion->clear();
            }
            $this->tPrestationsRelatedByCodeLibellePrestationScheduledForDeletion[]= $tPrestationRelatedByCodeLibellePrestation;
            $tPrestationRelatedByCodeLibellePrestation->setTTraductionRelatedByCodeLibellePrestation(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeLibellePrestation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeLibellePrestationJoinTParametragePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametragePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByCodeLibellePrestation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeLibellePrestation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeLibellePrestationJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTPrestationsRelatedByCodeLibellePrestation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeLibellePrestation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeLibellePrestationJoinTRefPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TRefPrestation', $join_behavior);

        return $this->getTPrestationsRelatedByCodeLibellePrestation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeLibellePrestation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeLibellePrestationJoinTTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TTypePrestation', $join_behavior);

        return $this->getTPrestationsRelatedByCodeLibellePrestation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeLibellePrestation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeLibellePrestationJoinTChampsSuppRelatedByIdChampsSupp1($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp1', $join_behavior);

        return $this->getTPrestationsRelatedByCodeLibellePrestation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeLibellePrestation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeLibellePrestationJoinTChampsSuppRelatedByIdChampsSupp2($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp2', $join_behavior);

        return $this->getTPrestationsRelatedByCodeLibellePrestation($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TPrestationsRelatedByCodeLibellePrestation from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TPrestation[] List of TPrestation objects
     */
    public function getTPrestationsRelatedByCodeLibellePrestationJoinTChampsSuppRelatedByIdChampsSupp3($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TPrestationQuery::create(null, $criteria);
        $query->joinWith('TChampsSuppRelatedByIdChampsSupp3', $join_behavior);

        return $this->getTPrestationsRelatedByCodeLibellePrestation($query, $con);
    }

    /**
     * Clears out the collTProfils collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTProfils()
     */
    public function clearTProfils()
    {
        $this->collTProfils = null; // important to set this to null since that means it is uninitialized
        $this->collTProfilsPartial = null;

        return $this;
    }

    /**
     * reset is the collTProfils collection loaded partially
     *
     * @return void
     */
    public function resetPartialTProfils($v = true)
    {
        $this->collTProfilsPartial = $v;
    }

    /**
     * Initializes the collTProfils collection.
     *
     * By default this just sets the collTProfils collection to an empty array (like clearcollTProfils());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTProfils($overrideExisting = true)
    {
        if (null !== $this->collTProfils && !$overrideExisting) {
            return;
        }
        $this->collTProfils = new PropelObjectCollection();
        $this->collTProfils->setModel('TProfil');
    }

    /**
     * Gets an array of TProfil objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TProfil[] List of TProfil objects
     * @throws PropelException
     */
    public function getTProfils($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTProfilsPartial && !$this->isNew();
        if (null === $this->collTProfils || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTProfils) {
                // return empty collection
                $this->initTProfils();
            } else {
                $collTProfils = TProfilQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTProfilsPartial && count($collTProfils)) {
                      $this->initTProfils(false);

                      foreach($collTProfils as $obj) {
                        if (false == $this->collTProfils->contains($obj)) {
                          $this->collTProfils->append($obj);
                        }
                      }

                      $this->collTProfilsPartial = true;
                    }

                    $collTProfils->getInternalIterator()->rewind();
                    return $collTProfils;
                }

                if($partial && $this->collTProfils) {
                    foreach($this->collTProfils as $obj) {
                        if($obj->isNew()) {
                            $collTProfils[] = $obj;
                        }
                    }
                }

                $this->collTProfils = $collTProfils;
                $this->collTProfilsPartial = false;
            }
        }

        return $this->collTProfils;
    }

    /**
     * Sets a collection of TProfil objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tProfils A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTProfils(PropelCollection $tProfils, PropelPDO $con = null)
    {
        $tProfilsToDelete = $this->getTProfils(new Criteria(), $con)->diff($tProfils);

        $this->tProfilsScheduledForDeletion = unserialize(serialize($tProfilsToDelete));

        foreach ($tProfilsToDelete as $tProfilRemoved) {
            $tProfilRemoved->setTTraduction(null);
        }

        $this->collTProfils = null;
        foreach ($tProfils as $tProfil) {
            $this->addTProfil($tProfil);
        }

        $this->collTProfils = $tProfils;
        $this->collTProfilsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TProfil objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TProfil objects.
     * @throws PropelException
     */
    public function countTProfils(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTProfilsPartial && !$this->isNew();
        if (null === $this->collTProfils || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTProfils) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTProfils());
            }
            $query = TProfilQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTProfils);
    }

    /**
     * Method called to associate a TProfil object to this object
     * through the TProfil foreign key attribute.
     *
     * @param    TProfil $l TProfil
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTProfil(TProfil $l)
    {
        if ($this->collTProfils === null) {
            $this->initTProfils();
            $this->collTProfilsPartial = true;
        }
        if (!in_array($l, $this->collTProfils->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTProfil($l);
        }

        return $this;
    }

    /**
     * @param	TProfil $tProfil The tProfil object to add.
     */
    protected function doAddTProfil($tProfil)
    {
        $this->collTProfils[]= $tProfil;
        $tProfil->setTTraduction($this);
    }

    /**
     * @param	TProfil $tProfil The tProfil object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTProfil($tProfil)
    {
        if ($this->getTProfils()->contains($tProfil)) {
            $this->collTProfils->remove($this->collTProfils->search($tProfil));
            if (null === $this->tProfilsScheduledForDeletion) {
                $this->tProfilsScheduledForDeletion = clone $this->collTProfils;
                $this->tProfilsScheduledForDeletion->clear();
            }
            $this->tProfilsScheduledForDeletion[]= clone $tProfil;
            $tProfil->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TProfils from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TProfil[] List of TProfil objects
     */
    public function getTProfilsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TProfilQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTProfils($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TProfils from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TProfil[] List of TProfil objects
     */
    public function getTProfilsJoinTTypeProfil($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TProfilQuery::create(null, $criteria);
        $query->joinWith('TTypeProfil', $join_behavior);

        return $this->getTProfils($query, $con);
    }

    /**
     * Clears out the collTReferentsRelatedByCodeNomReferent collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTReferentsRelatedByCodeNomReferent()
     */
    public function clearTReferentsRelatedByCodeNomReferent()
    {
        $this->collTReferentsRelatedByCodeNomReferent = null; // important to set this to null since that means it is uninitialized
        $this->collTReferentsRelatedByCodeNomReferentPartial = null;

        return $this;
    }

    /**
     * reset is the collTReferentsRelatedByCodeNomReferent collection loaded partially
     *
     * @return void
     */
    public function resetPartialTReferentsRelatedByCodeNomReferent($v = true)
    {
        $this->collTReferentsRelatedByCodeNomReferentPartial = $v;
    }

    /**
     * Initializes the collTReferentsRelatedByCodeNomReferent collection.
     *
     * By default this just sets the collTReferentsRelatedByCodeNomReferent collection to an empty array (like clearcollTReferentsRelatedByCodeNomReferent());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTReferentsRelatedByCodeNomReferent($overrideExisting = true)
    {
        if (null !== $this->collTReferentsRelatedByCodeNomReferent && !$overrideExisting) {
            return;
        }
        $this->collTReferentsRelatedByCodeNomReferent = new PropelObjectCollection();
        $this->collTReferentsRelatedByCodeNomReferent->setModel('TReferent');
    }

    /**
     * Gets an array of TReferent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TReferent[] List of TReferent objects
     * @throws PropelException
     */
    public function getTReferentsRelatedByCodeNomReferent($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTReferentsRelatedByCodeNomReferentPartial && !$this->isNew();
        if (null === $this->collTReferentsRelatedByCodeNomReferent || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTReferentsRelatedByCodeNomReferent) {
                // return empty collection
                $this->initTReferentsRelatedByCodeNomReferent();
            } else {
                $collTReferentsRelatedByCodeNomReferent = TReferentQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeNomReferent($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTReferentsRelatedByCodeNomReferentPartial && count($collTReferentsRelatedByCodeNomReferent)) {
                      $this->initTReferentsRelatedByCodeNomReferent(false);

                      foreach($collTReferentsRelatedByCodeNomReferent as $obj) {
                        if (false == $this->collTReferentsRelatedByCodeNomReferent->contains($obj)) {
                          $this->collTReferentsRelatedByCodeNomReferent->append($obj);
                        }
                      }

                      $this->collTReferentsRelatedByCodeNomReferentPartial = true;
                    }

                    $collTReferentsRelatedByCodeNomReferent->getInternalIterator()->rewind();
                    return $collTReferentsRelatedByCodeNomReferent;
                }

                if($partial && $this->collTReferentsRelatedByCodeNomReferent) {
                    foreach($this->collTReferentsRelatedByCodeNomReferent as $obj) {
                        if($obj->isNew()) {
                            $collTReferentsRelatedByCodeNomReferent[] = $obj;
                        }
                    }
                }

                $this->collTReferentsRelatedByCodeNomReferent = $collTReferentsRelatedByCodeNomReferent;
                $this->collTReferentsRelatedByCodeNomReferentPartial = false;
            }
        }

        return $this->collTReferentsRelatedByCodeNomReferent;
    }

    /**
     * Sets a collection of TReferentRelatedByCodeNomReferent objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tReferentsRelatedByCodeNomReferent A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTReferentsRelatedByCodeNomReferent(PropelCollection $tReferentsRelatedByCodeNomReferent, PropelPDO $con = null)
    {
        $tReferentsRelatedByCodeNomReferentToDelete = $this->getTReferentsRelatedByCodeNomReferent(new Criteria(), $con)->diff($tReferentsRelatedByCodeNomReferent);

        $this->tReferentsRelatedByCodeNomReferentScheduledForDeletion = unserialize(serialize($tReferentsRelatedByCodeNomReferentToDelete));

        foreach ($tReferentsRelatedByCodeNomReferentToDelete as $tReferentRelatedByCodeNomReferentRemoved) {
            $tReferentRelatedByCodeNomReferentRemoved->setTTraductionRelatedByCodeNomReferent(null);
        }

        $this->collTReferentsRelatedByCodeNomReferent = null;
        foreach ($tReferentsRelatedByCodeNomReferent as $tReferentRelatedByCodeNomReferent) {
            $this->addTReferentRelatedByCodeNomReferent($tReferentRelatedByCodeNomReferent);
        }

        $this->collTReferentsRelatedByCodeNomReferent = $tReferentsRelatedByCodeNomReferent;
        $this->collTReferentsRelatedByCodeNomReferentPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TReferent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TReferent objects.
     * @throws PropelException
     */
    public function countTReferentsRelatedByCodeNomReferent(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTReferentsRelatedByCodeNomReferentPartial && !$this->isNew();
        if (null === $this->collTReferentsRelatedByCodeNomReferent || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTReferentsRelatedByCodeNomReferent) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTReferentsRelatedByCodeNomReferent());
            }
            $query = TReferentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeNomReferent($this)
                ->count($con);
        }

        return count($this->collTReferentsRelatedByCodeNomReferent);
    }

    /**
     * Method called to associate a TReferent object to this object
     * through the TReferent foreign key attribute.
     *
     * @param    TReferent $l TReferent
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTReferentRelatedByCodeNomReferent(TReferent $l)
    {
        if ($this->collTReferentsRelatedByCodeNomReferent === null) {
            $this->initTReferentsRelatedByCodeNomReferent();
            $this->collTReferentsRelatedByCodeNomReferentPartial = true;
        }
        if (!in_array($l, $this->collTReferentsRelatedByCodeNomReferent->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTReferentRelatedByCodeNomReferent($l);
        }

        return $this;
    }

    /**
     * @param	TReferentRelatedByCodeNomReferent $tReferentRelatedByCodeNomReferent The tReferentRelatedByCodeNomReferent object to add.
     */
    protected function doAddTReferentRelatedByCodeNomReferent($tReferentRelatedByCodeNomReferent)
    {
        $this->collTReferentsRelatedByCodeNomReferent[]= $tReferentRelatedByCodeNomReferent;
        $tReferentRelatedByCodeNomReferent->setTTraductionRelatedByCodeNomReferent($this);
    }

    /**
     * @param	TReferentRelatedByCodeNomReferent $tReferentRelatedByCodeNomReferent The tReferentRelatedByCodeNomReferent object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTReferentRelatedByCodeNomReferent($tReferentRelatedByCodeNomReferent)
    {
        if ($this->getTReferentsRelatedByCodeNomReferent()->contains($tReferentRelatedByCodeNomReferent)) {
            $this->collTReferentsRelatedByCodeNomReferent->remove($this->collTReferentsRelatedByCodeNomReferent->search($tReferentRelatedByCodeNomReferent));
            if (null === $this->tReferentsRelatedByCodeNomReferentScheduledForDeletion) {
                $this->tReferentsRelatedByCodeNomReferentScheduledForDeletion = clone $this->collTReferentsRelatedByCodeNomReferent;
                $this->tReferentsRelatedByCodeNomReferentScheduledForDeletion->clear();
            }
            $this->tReferentsRelatedByCodeNomReferentScheduledForDeletion[]= clone $tReferentRelatedByCodeNomReferent;
            $tReferentRelatedByCodeNomReferent->setTTraductionRelatedByCodeNomReferent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TReferentsRelatedByCodeNomReferent from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TReferent[] List of TReferent objects
     */
    public function getTReferentsRelatedByCodeNomReferentJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TReferentQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTReferentsRelatedByCodeNomReferent($query, $con);
    }

    /**
     * Clears out the collTReferentsRelatedByCodePrenomReferent collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTReferentsRelatedByCodePrenomReferent()
     */
    public function clearTReferentsRelatedByCodePrenomReferent()
    {
        $this->collTReferentsRelatedByCodePrenomReferent = null; // important to set this to null since that means it is uninitialized
        $this->collTReferentsRelatedByCodePrenomReferentPartial = null;

        return $this;
    }

    /**
     * reset is the collTReferentsRelatedByCodePrenomReferent collection loaded partially
     *
     * @return void
     */
    public function resetPartialTReferentsRelatedByCodePrenomReferent($v = true)
    {
        $this->collTReferentsRelatedByCodePrenomReferentPartial = $v;
    }

    /**
     * Initializes the collTReferentsRelatedByCodePrenomReferent collection.
     *
     * By default this just sets the collTReferentsRelatedByCodePrenomReferent collection to an empty array (like clearcollTReferentsRelatedByCodePrenomReferent());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTReferentsRelatedByCodePrenomReferent($overrideExisting = true)
    {
        if (null !== $this->collTReferentsRelatedByCodePrenomReferent && !$overrideExisting) {
            return;
        }
        $this->collTReferentsRelatedByCodePrenomReferent = new PropelObjectCollection();
        $this->collTReferentsRelatedByCodePrenomReferent->setModel('TReferent');
    }

    /**
     * Gets an array of TReferent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TReferent[] List of TReferent objects
     * @throws PropelException
     */
    public function getTReferentsRelatedByCodePrenomReferent($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTReferentsRelatedByCodePrenomReferentPartial && !$this->isNew();
        if (null === $this->collTReferentsRelatedByCodePrenomReferent || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTReferentsRelatedByCodePrenomReferent) {
                // return empty collection
                $this->initTReferentsRelatedByCodePrenomReferent();
            } else {
                $collTReferentsRelatedByCodePrenomReferent = TReferentQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodePrenomReferent($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTReferentsRelatedByCodePrenomReferentPartial && count($collTReferentsRelatedByCodePrenomReferent)) {
                      $this->initTReferentsRelatedByCodePrenomReferent(false);

                      foreach($collTReferentsRelatedByCodePrenomReferent as $obj) {
                        if (false == $this->collTReferentsRelatedByCodePrenomReferent->contains($obj)) {
                          $this->collTReferentsRelatedByCodePrenomReferent->append($obj);
                        }
                      }

                      $this->collTReferentsRelatedByCodePrenomReferentPartial = true;
                    }

                    $collTReferentsRelatedByCodePrenomReferent->getInternalIterator()->rewind();
                    return $collTReferentsRelatedByCodePrenomReferent;
                }

                if($partial && $this->collTReferentsRelatedByCodePrenomReferent) {
                    foreach($this->collTReferentsRelatedByCodePrenomReferent as $obj) {
                        if($obj->isNew()) {
                            $collTReferentsRelatedByCodePrenomReferent[] = $obj;
                        }
                    }
                }

                $this->collTReferentsRelatedByCodePrenomReferent = $collTReferentsRelatedByCodePrenomReferent;
                $this->collTReferentsRelatedByCodePrenomReferentPartial = false;
            }
        }

        return $this->collTReferentsRelatedByCodePrenomReferent;
    }

    /**
     * Sets a collection of TReferentRelatedByCodePrenomReferent objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tReferentsRelatedByCodePrenomReferent A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTReferentsRelatedByCodePrenomReferent(PropelCollection $tReferentsRelatedByCodePrenomReferent, PropelPDO $con = null)
    {
        $tReferentsRelatedByCodePrenomReferentToDelete = $this->getTReferentsRelatedByCodePrenomReferent(new Criteria(), $con)->diff($tReferentsRelatedByCodePrenomReferent);

        $this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion = unserialize(serialize($tReferentsRelatedByCodePrenomReferentToDelete));

        foreach ($tReferentsRelatedByCodePrenomReferentToDelete as $tReferentRelatedByCodePrenomReferentRemoved) {
            $tReferentRelatedByCodePrenomReferentRemoved->setTTraductionRelatedByCodePrenomReferent(null);
        }

        $this->collTReferentsRelatedByCodePrenomReferent = null;
        foreach ($tReferentsRelatedByCodePrenomReferent as $tReferentRelatedByCodePrenomReferent) {
            $this->addTReferentRelatedByCodePrenomReferent($tReferentRelatedByCodePrenomReferent);
        }

        $this->collTReferentsRelatedByCodePrenomReferent = $tReferentsRelatedByCodePrenomReferent;
        $this->collTReferentsRelatedByCodePrenomReferentPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TReferent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TReferent objects.
     * @throws PropelException
     */
    public function countTReferentsRelatedByCodePrenomReferent(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTReferentsRelatedByCodePrenomReferentPartial && !$this->isNew();
        if (null === $this->collTReferentsRelatedByCodePrenomReferent || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTReferentsRelatedByCodePrenomReferent) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTReferentsRelatedByCodePrenomReferent());
            }
            $query = TReferentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodePrenomReferent($this)
                ->count($con);
        }

        return count($this->collTReferentsRelatedByCodePrenomReferent);
    }

    /**
     * Method called to associate a TReferent object to this object
     * through the TReferent foreign key attribute.
     *
     * @param    TReferent $l TReferent
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTReferentRelatedByCodePrenomReferent(TReferent $l)
    {
        if ($this->collTReferentsRelatedByCodePrenomReferent === null) {
            $this->initTReferentsRelatedByCodePrenomReferent();
            $this->collTReferentsRelatedByCodePrenomReferentPartial = true;
        }
        if (!in_array($l, $this->collTReferentsRelatedByCodePrenomReferent->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTReferentRelatedByCodePrenomReferent($l);
        }

        return $this;
    }

    /**
     * @param	TReferentRelatedByCodePrenomReferent $tReferentRelatedByCodePrenomReferent The tReferentRelatedByCodePrenomReferent object to add.
     */
    protected function doAddTReferentRelatedByCodePrenomReferent($tReferentRelatedByCodePrenomReferent)
    {
        $this->collTReferentsRelatedByCodePrenomReferent[]= $tReferentRelatedByCodePrenomReferent;
        $tReferentRelatedByCodePrenomReferent->setTTraductionRelatedByCodePrenomReferent($this);
    }

    /**
     * @param	TReferentRelatedByCodePrenomReferent $tReferentRelatedByCodePrenomReferent The tReferentRelatedByCodePrenomReferent object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTReferentRelatedByCodePrenomReferent($tReferentRelatedByCodePrenomReferent)
    {
        if ($this->getTReferentsRelatedByCodePrenomReferent()->contains($tReferentRelatedByCodePrenomReferent)) {
            $this->collTReferentsRelatedByCodePrenomReferent->remove($this->collTReferentsRelatedByCodePrenomReferent->search($tReferentRelatedByCodePrenomReferent));
            if (null === $this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion) {
                $this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion = clone $this->collTReferentsRelatedByCodePrenomReferent;
                $this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion->clear();
            }
            $this->tReferentsRelatedByCodePrenomReferentScheduledForDeletion[]= clone $tReferentRelatedByCodePrenomReferent;
            $tReferentRelatedByCodePrenomReferent->setTTraductionRelatedByCodePrenomReferent(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TReferentsRelatedByCodePrenomReferent from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TReferent[] List of TReferent objects
     */
    public function getTReferentsRelatedByCodePrenomReferentJoinTEntite($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TReferentQuery::create(null, $criteria);
        $query->joinWith('TEntite', $join_behavior);

        return $this->getTReferentsRelatedByCodePrenomReferent($query, $con);
    }

    /**
     * Clears out the collTReferentiels collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTReferentiels()
     */
    public function clearTReferentiels()
    {
        $this->collTReferentiels = null; // important to set this to null since that means it is uninitialized
        $this->collTReferentielsPartial = null;

        return $this;
    }

    /**
     * reset is the collTReferentiels collection loaded partially
     *
     * @return void
     */
    public function resetPartialTReferentiels($v = true)
    {
        $this->collTReferentielsPartial = $v;
    }

    /**
     * Initializes the collTReferentiels collection.
     *
     * By default this just sets the collTReferentiels collection to an empty array (like clearcollTReferentiels());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTReferentiels($overrideExisting = true)
    {
        if (null !== $this->collTReferentiels && !$overrideExisting) {
            return;
        }
        $this->collTReferentiels = new PropelObjectCollection();
        $this->collTReferentiels->setModel('TReferentiel');
    }

    /**
     * Gets an array of TReferentiel objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TReferentiel[] List of TReferentiel objects
     * @throws PropelException
     */
    public function getTReferentiels($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTReferentielsPartial && !$this->isNew();
        if (null === $this->collTReferentiels || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTReferentiels) {
                // return empty collection
                $this->initTReferentiels();
            } else {
                $collTReferentiels = TReferentielQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTReferentielsPartial && count($collTReferentiels)) {
                      $this->initTReferentiels(false);

                      foreach($collTReferentiels as $obj) {
                        if (false == $this->collTReferentiels->contains($obj)) {
                          $this->collTReferentiels->append($obj);
                        }
                      }

                      $this->collTReferentielsPartial = true;
                    }

                    $collTReferentiels->getInternalIterator()->rewind();
                    return $collTReferentiels;
                }

                if($partial && $this->collTReferentiels) {
                    foreach($this->collTReferentiels as $obj) {
                        if($obj->isNew()) {
                            $collTReferentiels[] = $obj;
                        }
                    }
                }

                $this->collTReferentiels = $collTReferentiels;
                $this->collTReferentielsPartial = false;
            }
        }

        return $this->collTReferentiels;
    }

    /**
     * Sets a collection of TReferentiel objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tReferentiels A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTReferentiels(PropelCollection $tReferentiels, PropelPDO $con = null)
    {
        $tReferentielsToDelete = $this->getTReferentiels(new Criteria(), $con)->diff($tReferentiels);

        $this->tReferentielsScheduledForDeletion = unserialize(serialize($tReferentielsToDelete));

        foreach ($tReferentielsToDelete as $tReferentielRemoved) {
            $tReferentielRemoved->setTTraduction(null);
        }

        $this->collTReferentiels = null;
        foreach ($tReferentiels as $tReferentiel) {
            $this->addTReferentiel($tReferentiel);
        }

        $this->collTReferentiels = $tReferentiels;
        $this->collTReferentielsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TReferentiel objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TReferentiel objects.
     * @throws PropelException
     */
    public function countTReferentiels(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTReferentielsPartial && !$this->isNew();
        if (null === $this->collTReferentiels || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTReferentiels) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTReferentiels());
            }
            $query = TReferentielQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTReferentiels);
    }

    /**
     * Method called to associate a TReferentiel object to this object
     * through the TReferentiel foreign key attribute.
     *
     * @param    TReferentiel $l TReferentiel
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTReferentiel(TReferentiel $l)
    {
        if ($this->collTReferentiels === null) {
            $this->initTReferentiels();
            $this->collTReferentielsPartial = true;
        }
        if (!in_array($l, $this->collTReferentiels->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTReferentiel($l);
        }

        return $this;
    }

    /**
     * @param	TReferentiel $tReferentiel The tReferentiel object to add.
     */
    protected function doAddTReferentiel($tReferentiel)
    {
        $this->collTReferentiels[]= $tReferentiel;
        $tReferentiel->setTTraduction($this);
    }

    /**
     * @param	TReferentiel $tReferentiel The tReferentiel object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTReferentiel($tReferentiel)
    {
        if ($this->getTReferentiels()->contains($tReferentiel)) {
            $this->collTReferentiels->remove($this->collTReferentiels->search($tReferentiel));
            if (null === $this->tReferentielsScheduledForDeletion) {
                $this->tReferentielsScheduledForDeletion = clone $this->collTReferentiels;
                $this->tReferentielsScheduledForDeletion->clear();
            }
            $this->tReferentielsScheduledForDeletion[]= $tReferentiel;
            $tReferentiel->setTTraduction(null);
        }

        return $this;
    }

    /**
     * Clears out the collTRefPrestationsRelatedByCodeAide collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTRefPrestationsRelatedByCodeAide()
     */
    public function clearTRefPrestationsRelatedByCodeAide()
    {
        $this->collTRefPrestationsRelatedByCodeAide = null; // important to set this to null since that means it is uninitialized
        $this->collTRefPrestationsRelatedByCodeAidePartial = null;

        return $this;
    }

    /**
     * reset is the collTRefPrestationsRelatedByCodeAide collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRefPrestationsRelatedByCodeAide($v = true)
    {
        $this->collTRefPrestationsRelatedByCodeAidePartial = $v;
    }

    /**
     * Initializes the collTRefPrestationsRelatedByCodeAide collection.
     *
     * By default this just sets the collTRefPrestationsRelatedByCodeAide collection to an empty array (like clearcollTRefPrestationsRelatedByCodeAide());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRefPrestationsRelatedByCodeAide($overrideExisting = true)
    {
        if (null !== $this->collTRefPrestationsRelatedByCodeAide && !$overrideExisting) {
            return;
        }
        $this->collTRefPrestationsRelatedByCodeAide = new PropelObjectCollection();
        $this->collTRefPrestationsRelatedByCodeAide->setModel('TRefPrestation');
    }

    /**
     * Gets an array of TRefPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     * @throws PropelException
     */
    public function getTRefPrestationsRelatedByCodeAide($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRefPrestationsRelatedByCodeAidePartial && !$this->isNew();
        if (null === $this->collTRefPrestationsRelatedByCodeAide || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRefPrestationsRelatedByCodeAide) {
                // return empty collection
                $this->initTRefPrestationsRelatedByCodeAide();
            } else {
                $collTRefPrestationsRelatedByCodeAide = TRefPrestationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeAide($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRefPrestationsRelatedByCodeAidePartial && count($collTRefPrestationsRelatedByCodeAide)) {
                      $this->initTRefPrestationsRelatedByCodeAide(false);

                      foreach($collTRefPrestationsRelatedByCodeAide as $obj) {
                        if (false == $this->collTRefPrestationsRelatedByCodeAide->contains($obj)) {
                          $this->collTRefPrestationsRelatedByCodeAide->append($obj);
                        }
                      }

                      $this->collTRefPrestationsRelatedByCodeAidePartial = true;
                    }

                    $collTRefPrestationsRelatedByCodeAide->getInternalIterator()->rewind();
                    return $collTRefPrestationsRelatedByCodeAide;
                }

                if($partial && $this->collTRefPrestationsRelatedByCodeAide) {
                    foreach($this->collTRefPrestationsRelatedByCodeAide as $obj) {
                        if($obj->isNew()) {
                            $collTRefPrestationsRelatedByCodeAide[] = $obj;
                        }
                    }
                }

                $this->collTRefPrestationsRelatedByCodeAide = $collTRefPrestationsRelatedByCodeAide;
                $this->collTRefPrestationsRelatedByCodeAidePartial = false;
            }
        }

        return $this->collTRefPrestationsRelatedByCodeAide;
    }

    /**
     * Sets a collection of TRefPrestationRelatedByCodeAide objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRefPrestationsRelatedByCodeAide A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTRefPrestationsRelatedByCodeAide(PropelCollection $tRefPrestationsRelatedByCodeAide, PropelPDO $con = null)
    {
        $tRefPrestationsRelatedByCodeAideToDelete = $this->getTRefPrestationsRelatedByCodeAide(new Criteria(), $con)->diff($tRefPrestationsRelatedByCodeAide);

        $this->tRefPrestationsRelatedByCodeAideScheduledForDeletion = unserialize(serialize($tRefPrestationsRelatedByCodeAideToDelete));

        foreach ($tRefPrestationsRelatedByCodeAideToDelete as $tRefPrestationRelatedByCodeAideRemoved) {
            $tRefPrestationRelatedByCodeAideRemoved->setTTraductionRelatedByCodeAide(null);
        }

        $this->collTRefPrestationsRelatedByCodeAide = null;
        foreach ($tRefPrestationsRelatedByCodeAide as $tRefPrestationRelatedByCodeAide) {
            $this->addTRefPrestationRelatedByCodeAide($tRefPrestationRelatedByCodeAide);
        }

        $this->collTRefPrestationsRelatedByCodeAide = $tRefPrestationsRelatedByCodeAide;
        $this->collTRefPrestationsRelatedByCodeAidePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRefPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRefPrestation objects.
     * @throws PropelException
     */
    public function countTRefPrestationsRelatedByCodeAide(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRefPrestationsRelatedByCodeAidePartial && !$this->isNew();
        if (null === $this->collTRefPrestationsRelatedByCodeAide || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRefPrestationsRelatedByCodeAide) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRefPrestationsRelatedByCodeAide());
            }
            $query = TRefPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeAide($this)
                ->count($con);
        }

        return count($this->collTRefPrestationsRelatedByCodeAide);
    }

    /**
     * Method called to associate a TRefPrestation object to this object
     * through the TRefPrestation foreign key attribute.
     *
     * @param    TRefPrestation $l TRefPrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTRefPrestationRelatedByCodeAide(TRefPrestation $l)
    {
        if ($this->collTRefPrestationsRelatedByCodeAide === null) {
            $this->initTRefPrestationsRelatedByCodeAide();
            $this->collTRefPrestationsRelatedByCodeAidePartial = true;
        }
        if (!in_array($l, $this->collTRefPrestationsRelatedByCodeAide->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRefPrestationRelatedByCodeAide($l);
        }

        return $this;
    }

    /**
     * @param	TRefPrestationRelatedByCodeAide $tRefPrestationRelatedByCodeAide The tRefPrestationRelatedByCodeAide object to add.
     */
    protected function doAddTRefPrestationRelatedByCodeAide($tRefPrestationRelatedByCodeAide)
    {
        $this->collTRefPrestationsRelatedByCodeAide[]= $tRefPrestationRelatedByCodeAide;
        $tRefPrestationRelatedByCodeAide->setTTraductionRelatedByCodeAide($this);
    }

    /**
     * @param	TRefPrestationRelatedByCodeAide $tRefPrestationRelatedByCodeAide The tRefPrestationRelatedByCodeAide object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTRefPrestationRelatedByCodeAide($tRefPrestationRelatedByCodeAide)
    {
        if ($this->getTRefPrestationsRelatedByCodeAide()->contains($tRefPrestationRelatedByCodeAide)) {
            $this->collTRefPrestationsRelatedByCodeAide->remove($this->collTRefPrestationsRelatedByCodeAide->search($tRefPrestationRelatedByCodeAide));
            if (null === $this->tRefPrestationsRelatedByCodeAideScheduledForDeletion) {
                $this->tRefPrestationsRelatedByCodeAideScheduledForDeletion = clone $this->collTRefPrestationsRelatedByCodeAide;
                $this->tRefPrestationsRelatedByCodeAideScheduledForDeletion->clear();
            }
            $this->tRefPrestationsRelatedByCodeAideScheduledForDeletion[]= clone $tRefPrestationRelatedByCodeAide;
            $tRefPrestationRelatedByCodeAide->setTTraductionRelatedByCodeAide(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TRefPrestationsRelatedByCodeAide from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     */
    public function getTRefPrestationsRelatedByCodeAideJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefPrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTRefPrestationsRelatedByCodeAide($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TRefPrestationsRelatedByCodeAide from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     */
    public function getTRefPrestationsRelatedByCodeAideJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTRefPrestationsRelatedByCodeAide($query, $con);
    }

    /**
     * Clears out the collTRefPrestationsRelatedByCodeLibelle collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTRefPrestationsRelatedByCodeLibelle()
     */
    public function clearTRefPrestationsRelatedByCodeLibelle()
    {
        $this->collTRefPrestationsRelatedByCodeLibelle = null; // important to set this to null since that means it is uninitialized
        $this->collTRefPrestationsRelatedByCodeLibellePartial = null;

        return $this;
    }

    /**
     * reset is the collTRefPrestationsRelatedByCodeLibelle collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRefPrestationsRelatedByCodeLibelle($v = true)
    {
        $this->collTRefPrestationsRelatedByCodeLibellePartial = $v;
    }

    /**
     * Initializes the collTRefPrestationsRelatedByCodeLibelle collection.
     *
     * By default this just sets the collTRefPrestationsRelatedByCodeLibelle collection to an empty array (like clearcollTRefPrestationsRelatedByCodeLibelle());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRefPrestationsRelatedByCodeLibelle($overrideExisting = true)
    {
        if (null !== $this->collTRefPrestationsRelatedByCodeLibelle && !$overrideExisting) {
            return;
        }
        $this->collTRefPrestationsRelatedByCodeLibelle = new PropelObjectCollection();
        $this->collTRefPrestationsRelatedByCodeLibelle->setModel('TRefPrestation');
    }

    /**
     * Gets an array of TRefPrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     * @throws PropelException
     */
    public function getTRefPrestationsRelatedByCodeLibelle($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRefPrestationsRelatedByCodeLibellePartial && !$this->isNew();
        if (null === $this->collTRefPrestationsRelatedByCodeLibelle || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRefPrestationsRelatedByCodeLibelle) {
                // return empty collection
                $this->initTRefPrestationsRelatedByCodeLibelle();
            } else {
                $collTRefPrestationsRelatedByCodeLibelle = TRefPrestationQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelle($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRefPrestationsRelatedByCodeLibellePartial && count($collTRefPrestationsRelatedByCodeLibelle)) {
                      $this->initTRefPrestationsRelatedByCodeLibelle(false);

                      foreach($collTRefPrestationsRelatedByCodeLibelle as $obj) {
                        if (false == $this->collTRefPrestationsRelatedByCodeLibelle->contains($obj)) {
                          $this->collTRefPrestationsRelatedByCodeLibelle->append($obj);
                        }
                      }

                      $this->collTRefPrestationsRelatedByCodeLibellePartial = true;
                    }

                    $collTRefPrestationsRelatedByCodeLibelle->getInternalIterator()->rewind();
                    return $collTRefPrestationsRelatedByCodeLibelle;
                }

                if($partial && $this->collTRefPrestationsRelatedByCodeLibelle) {
                    foreach($this->collTRefPrestationsRelatedByCodeLibelle as $obj) {
                        if($obj->isNew()) {
                            $collTRefPrestationsRelatedByCodeLibelle[] = $obj;
                        }
                    }
                }

                $this->collTRefPrestationsRelatedByCodeLibelle = $collTRefPrestationsRelatedByCodeLibelle;
                $this->collTRefPrestationsRelatedByCodeLibellePartial = false;
            }
        }

        return $this->collTRefPrestationsRelatedByCodeLibelle;
    }

    /**
     * Sets a collection of TRefPrestationRelatedByCodeLibelle objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRefPrestationsRelatedByCodeLibelle A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTRefPrestationsRelatedByCodeLibelle(PropelCollection $tRefPrestationsRelatedByCodeLibelle, PropelPDO $con = null)
    {
        $tRefPrestationsRelatedByCodeLibelleToDelete = $this->getTRefPrestationsRelatedByCodeLibelle(new Criteria(), $con)->diff($tRefPrestationsRelatedByCodeLibelle);

        $this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion = unserialize(serialize($tRefPrestationsRelatedByCodeLibelleToDelete));

        foreach ($tRefPrestationsRelatedByCodeLibelleToDelete as $tRefPrestationRelatedByCodeLibelleRemoved) {
            $tRefPrestationRelatedByCodeLibelleRemoved->setTTraductionRelatedByCodeLibelle(null);
        }

        $this->collTRefPrestationsRelatedByCodeLibelle = null;
        foreach ($tRefPrestationsRelatedByCodeLibelle as $tRefPrestationRelatedByCodeLibelle) {
            $this->addTRefPrestationRelatedByCodeLibelle($tRefPrestationRelatedByCodeLibelle);
        }

        $this->collTRefPrestationsRelatedByCodeLibelle = $tRefPrestationsRelatedByCodeLibelle;
        $this->collTRefPrestationsRelatedByCodeLibellePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRefPrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRefPrestation objects.
     * @throws PropelException
     */
    public function countTRefPrestationsRelatedByCodeLibelle(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRefPrestationsRelatedByCodeLibellePartial && !$this->isNew();
        if (null === $this->collTRefPrestationsRelatedByCodeLibelle || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRefPrestationsRelatedByCodeLibelle) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRefPrestationsRelatedByCodeLibelle());
            }
            $query = TRefPrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelle($this)
                ->count($con);
        }

        return count($this->collTRefPrestationsRelatedByCodeLibelle);
    }

    /**
     * Method called to associate a TRefPrestation object to this object
     * through the TRefPrestation foreign key attribute.
     *
     * @param    TRefPrestation $l TRefPrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTRefPrestationRelatedByCodeLibelle(TRefPrestation $l)
    {
        if ($this->collTRefPrestationsRelatedByCodeLibelle === null) {
            $this->initTRefPrestationsRelatedByCodeLibelle();
            $this->collTRefPrestationsRelatedByCodeLibellePartial = true;
        }
        if (!in_array($l, $this->collTRefPrestationsRelatedByCodeLibelle->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRefPrestationRelatedByCodeLibelle($l);
        }

        return $this;
    }

    /**
     * @param	TRefPrestationRelatedByCodeLibelle $tRefPrestationRelatedByCodeLibelle The tRefPrestationRelatedByCodeLibelle object to add.
     */
    protected function doAddTRefPrestationRelatedByCodeLibelle($tRefPrestationRelatedByCodeLibelle)
    {
        $this->collTRefPrestationsRelatedByCodeLibelle[]= $tRefPrestationRelatedByCodeLibelle;
        $tRefPrestationRelatedByCodeLibelle->setTTraductionRelatedByCodeLibelle($this);
    }

    /**
     * @param	TRefPrestationRelatedByCodeLibelle $tRefPrestationRelatedByCodeLibelle The tRefPrestationRelatedByCodeLibelle object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTRefPrestationRelatedByCodeLibelle($tRefPrestationRelatedByCodeLibelle)
    {
        if ($this->getTRefPrestationsRelatedByCodeLibelle()->contains($tRefPrestationRelatedByCodeLibelle)) {
            $this->collTRefPrestationsRelatedByCodeLibelle->remove($this->collTRefPrestationsRelatedByCodeLibelle->search($tRefPrestationRelatedByCodeLibelle));
            if (null === $this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion) {
                $this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion = clone $this->collTRefPrestationsRelatedByCodeLibelle;
                $this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion->clear();
            }
            $this->tRefPrestationsRelatedByCodeLibelleScheduledForDeletion[]= clone $tRefPrestationRelatedByCodeLibelle;
            $tRefPrestationRelatedByCodeLibelle->setTTraductionRelatedByCodeLibelle(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TRefPrestationsRelatedByCodeLibelle from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     */
    public function getTRefPrestationsRelatedByCodeLibelleJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefPrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTRefPrestationsRelatedByCodeLibelle($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TRefPrestationsRelatedByCodeLibelle from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefPrestation[] List of TRefPrestation objects
     */
    public function getTRefPrestationsRelatedByCodeLibelleJoinTParametreForm($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefPrestationQuery::create(null, $criteria);
        $query->joinWith('TParametreForm', $join_behavior);

        return $this->getTRefPrestationsRelatedByCodeLibelle($query, $con);
    }

    /**
     * Clears out the collTRefTypePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTRefTypePrestations()
     */
    public function clearTRefTypePrestations()
    {
        $this->collTRefTypePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTRefTypePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTRefTypePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTRefTypePrestations($v = true)
    {
        $this->collTRefTypePrestationsPartial = $v;
    }

    /**
     * Initializes the collTRefTypePrestations collection.
     *
     * By default this just sets the collTRefTypePrestations collection to an empty array (like clearcollTRefTypePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTRefTypePrestations($overrideExisting = true)
    {
        if (null !== $this->collTRefTypePrestations && !$overrideExisting) {
            return;
        }
        $this->collTRefTypePrestations = new PropelObjectCollection();
        $this->collTRefTypePrestations->setModel('TRefTypePrestation');
    }

    /**
     * Gets an array of TRefTypePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TRefTypePrestation[] List of TRefTypePrestation objects
     * @throws PropelException
     */
    public function getTRefTypePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTRefTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTRefTypePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTRefTypePrestations) {
                // return empty collection
                $this->initTRefTypePrestations();
            } else {
                $collTRefTypePrestations = TRefTypePrestationQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTRefTypePrestationsPartial && count($collTRefTypePrestations)) {
                      $this->initTRefTypePrestations(false);

                      foreach($collTRefTypePrestations as $obj) {
                        if (false == $this->collTRefTypePrestations->contains($obj)) {
                          $this->collTRefTypePrestations->append($obj);
                        }
                      }

                      $this->collTRefTypePrestationsPartial = true;
                    }

                    $collTRefTypePrestations->getInternalIterator()->rewind();
                    return $collTRefTypePrestations;
                }

                if($partial && $this->collTRefTypePrestations) {
                    foreach($this->collTRefTypePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTRefTypePrestations[] = $obj;
                        }
                    }
                }

                $this->collTRefTypePrestations = $collTRefTypePrestations;
                $this->collTRefTypePrestationsPartial = false;
            }
        }

        return $this->collTRefTypePrestations;
    }

    /**
     * Sets a collection of TRefTypePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tRefTypePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTRefTypePrestations(PropelCollection $tRefTypePrestations, PropelPDO $con = null)
    {
        $tRefTypePrestationsToDelete = $this->getTRefTypePrestations(new Criteria(), $con)->diff($tRefTypePrestations);

        $this->tRefTypePrestationsScheduledForDeletion = unserialize(serialize($tRefTypePrestationsToDelete));

        foreach ($tRefTypePrestationsToDelete as $tRefTypePrestationRemoved) {
            $tRefTypePrestationRemoved->setTTraduction(null);
        }

        $this->collTRefTypePrestations = null;
        foreach ($tRefTypePrestations as $tRefTypePrestation) {
            $this->addTRefTypePrestation($tRefTypePrestation);
        }

        $this->collTRefTypePrestations = $tRefTypePrestations;
        $this->collTRefTypePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TRefTypePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TRefTypePrestation objects.
     * @throws PropelException
     */
    public function countTRefTypePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTRefTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTRefTypePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTRefTypePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTRefTypePrestations());
            }
            $query = TRefTypePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTRefTypePrestations);
    }

    /**
     * Method called to associate a TRefTypePrestation object to this object
     * through the TRefTypePrestation foreign key attribute.
     *
     * @param    TRefTypePrestation $l TRefTypePrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTRefTypePrestation(TRefTypePrestation $l)
    {
        if ($this->collTRefTypePrestations === null) {
            $this->initTRefTypePrestations();
            $this->collTRefTypePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTRefTypePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTRefTypePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TRefTypePrestation $tRefTypePrestation The tRefTypePrestation object to add.
     */
    protected function doAddTRefTypePrestation($tRefTypePrestation)
    {
        $this->collTRefTypePrestations[]= $tRefTypePrestation;
        $tRefTypePrestation->setTTraduction($this);
    }

    /**
     * @param	TRefTypePrestation $tRefTypePrestation The tRefTypePrestation object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTRefTypePrestation($tRefTypePrestation)
    {
        if ($this->getTRefTypePrestations()->contains($tRefTypePrestation)) {
            $this->collTRefTypePrestations->remove($this->collTRefTypePrestations->search($tRefTypePrestation));
            if (null === $this->tRefTypePrestationsScheduledForDeletion) {
                $this->tRefTypePrestationsScheduledForDeletion = clone $this->collTRefTypePrestations;
                $this->tRefTypePrestationsScheduledForDeletion->clear();
            }
            $this->tRefTypePrestationsScheduledForDeletion[]= clone $tRefTypePrestation;
            $tRefTypePrestation->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TRefTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefTypePrestation[] List of TRefTypePrestation objects
     */
    public function getTRefTypePrestationsJoinTGroupe($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TGroupe', $join_behavior);

        return $this->getTRefTypePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TRefTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TRefTypePrestation[] List of TRefTypePrestation objects
     */
    public function getTRefTypePrestationsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TRefTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTRefTypePrestations($query, $con);
    }

    /**
     * Clears out the collTTraductionLibelles collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTTraductionLibelles()
     */
    public function clearTTraductionLibelles()
    {
        $this->collTTraductionLibelles = null; // important to set this to null since that means it is uninitialized
        $this->collTTraductionLibellesPartial = null;

        return $this;
    }

    /**
     * reset is the collTTraductionLibelles collection loaded partially
     *
     * @return void
     */
    public function resetPartialTTraductionLibelles($v = true)
    {
        $this->collTTraductionLibellesPartial = $v;
    }

    /**
     * Initializes the collTTraductionLibelles collection.
     *
     * By default this just sets the collTTraductionLibelles collection to an empty array (like clearcollTTraductionLibelles());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTTraductionLibelles($overrideExisting = true)
    {
        if (null !== $this->collTTraductionLibelles && !$overrideExisting) {
            return;
        }
        $this->collTTraductionLibelles = new PropelObjectCollection();
        $this->collTTraductionLibelles->setModel('TTraductionLibelle');
    }

    /**
     * Gets an array of TTraductionLibelle objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TTraductionLibelle[] List of TTraductionLibelle objects
     * @throws PropelException
     */
    public function getTTraductionLibelles($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTTraductionLibellesPartial && !$this->isNew();
        if (null === $this->collTTraductionLibelles || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTTraductionLibelles) {
                // return empty collection
                $this->initTTraductionLibelles();
            } else {
                $collTTraductionLibelles = TTraductionLibelleQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTTraductionLibellesPartial && count($collTTraductionLibelles)) {
                      $this->initTTraductionLibelles(false);

                      foreach($collTTraductionLibelles as $obj) {
                        if (false == $this->collTTraductionLibelles->contains($obj)) {
                          $this->collTTraductionLibelles->append($obj);
                        }
                      }

                      $this->collTTraductionLibellesPartial = true;
                    }

                    $collTTraductionLibelles->getInternalIterator()->rewind();
                    return $collTTraductionLibelles;
                }

                if($partial && $this->collTTraductionLibelles) {
                    foreach($this->collTTraductionLibelles as $obj) {
                        if($obj->isNew()) {
                            $collTTraductionLibelles[] = $obj;
                        }
                    }
                }

                $this->collTTraductionLibelles = $collTTraductionLibelles;
                $this->collTTraductionLibellesPartial = false;
            }
        }

        return $this->collTTraductionLibelles;
    }

    /**
     * Sets a collection of TTraductionLibelle objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tTraductionLibelles A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTTraductionLibelles(PropelCollection $tTraductionLibelles, PropelPDO $con = null)
    {
        $tTraductionLibellesToDelete = $this->getTTraductionLibelles(new Criteria(), $con)->diff($tTraductionLibelles);

        $this->tTraductionLibellesScheduledForDeletion = unserialize(serialize($tTraductionLibellesToDelete));

        foreach ($tTraductionLibellesToDelete as $tTraductionLibelleRemoved) {
            $tTraductionLibelleRemoved->setTTraduction(null);
        }

        $this->collTTraductionLibelles = null;
        foreach ($tTraductionLibelles as $tTraductionLibelle) {
            $this->addTTraductionLibelle($tTraductionLibelle);
        }

        $this->collTTraductionLibelles = $tTraductionLibelles;
        $this->collTTraductionLibellesPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TTraductionLibelle objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TTraductionLibelle objects.
     * @throws PropelException
     */
    public function countTTraductionLibelles(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTTraductionLibellesPartial && !$this->isNew();
        if (null === $this->collTTraductionLibelles || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTTraductionLibelles) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTTraductionLibelles());
            }
            $query = TTraductionLibelleQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTTraductionLibelles);
    }

    /**
     * Method called to associate a TTraductionLibelle object to this object
     * through the TTraductionLibelle foreign key attribute.
     *
     * @param    TTraductionLibelle $l TTraductionLibelle
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTTraductionLibelle(TTraductionLibelle $l)
    {
        if ($this->collTTraductionLibelles === null) {
            $this->initTTraductionLibelles();
            $this->collTTraductionLibellesPartial = true;
        }
        if (!in_array($l, $this->collTTraductionLibelles->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTTraductionLibelle($l);
        }

        return $this;
    }

    /**
     * @param	TTraductionLibelle $tTraductionLibelle The tTraductionLibelle object to add.
     */
    protected function doAddTTraductionLibelle($tTraductionLibelle)
    {
        $this->collTTraductionLibelles[]= $tTraductionLibelle;
        $tTraductionLibelle->setTTraduction($this);
    }

    /**
     * @param	TTraductionLibelle $tTraductionLibelle The tTraductionLibelle object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTTraductionLibelle($tTraductionLibelle)
    {
        if ($this->getTTraductionLibelles()->contains($tTraductionLibelle)) {
            $this->collTTraductionLibelles->remove($this->collTTraductionLibelles->search($tTraductionLibelle));
            if (null === $this->tTraductionLibellesScheduledForDeletion) {
                $this->tTraductionLibellesScheduledForDeletion = clone $this->collTTraductionLibelles;
                $this->tTraductionLibellesScheduledForDeletion->clear();
            }
            $this->tTraductionLibellesScheduledForDeletion[]= clone $tTraductionLibelle;
            $tTraductionLibelle->setTTraduction(null);
        }

        return $this;
    }

    /**
     * Clears out the collTTypeEtabsRelatedByCodeLibelle collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTTypeEtabsRelatedByCodeLibelle()
     */
    public function clearTTypeEtabsRelatedByCodeLibelle()
    {
        $this->collTTypeEtabsRelatedByCodeLibelle = null; // important to set this to null since that means it is uninitialized
        $this->collTTypeEtabsRelatedByCodeLibellePartial = null;

        return $this;
    }

    /**
     * reset is the collTTypeEtabsRelatedByCodeLibelle collection loaded partially
     *
     * @return void
     */
    public function resetPartialTTypeEtabsRelatedByCodeLibelle($v = true)
    {
        $this->collTTypeEtabsRelatedByCodeLibellePartial = $v;
    }

    /**
     * Initializes the collTTypeEtabsRelatedByCodeLibelle collection.
     *
     * By default this just sets the collTTypeEtabsRelatedByCodeLibelle collection to an empty array (like clearcollTTypeEtabsRelatedByCodeLibelle());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTTypeEtabsRelatedByCodeLibelle($overrideExisting = true)
    {
        if (null !== $this->collTTypeEtabsRelatedByCodeLibelle && !$overrideExisting) {
            return;
        }
        $this->collTTypeEtabsRelatedByCodeLibelle = new PropelObjectCollection();
        $this->collTTypeEtabsRelatedByCodeLibelle->setModel('TTypeEtab');
    }

    /**
     * Gets an array of TTypeEtab objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TTypeEtab[] List of TTypeEtab objects
     * @throws PropelException
     */
    public function getTTypeEtabsRelatedByCodeLibelle($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTTypeEtabsRelatedByCodeLibellePartial && !$this->isNew();
        if (null === $this->collTTypeEtabsRelatedByCodeLibelle || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTTypeEtabsRelatedByCodeLibelle) {
                // return empty collection
                $this->initTTypeEtabsRelatedByCodeLibelle();
            } else {
                $collTTypeEtabsRelatedByCodeLibelle = TTypeEtabQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelle($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTTypeEtabsRelatedByCodeLibellePartial && count($collTTypeEtabsRelatedByCodeLibelle)) {
                      $this->initTTypeEtabsRelatedByCodeLibelle(false);

                      foreach($collTTypeEtabsRelatedByCodeLibelle as $obj) {
                        if (false == $this->collTTypeEtabsRelatedByCodeLibelle->contains($obj)) {
                          $this->collTTypeEtabsRelatedByCodeLibelle->append($obj);
                        }
                      }

                      $this->collTTypeEtabsRelatedByCodeLibellePartial = true;
                    }

                    $collTTypeEtabsRelatedByCodeLibelle->getInternalIterator()->rewind();
                    return $collTTypeEtabsRelatedByCodeLibelle;
                }

                if($partial && $this->collTTypeEtabsRelatedByCodeLibelle) {
                    foreach($this->collTTypeEtabsRelatedByCodeLibelle as $obj) {
                        if($obj->isNew()) {
                            $collTTypeEtabsRelatedByCodeLibelle[] = $obj;
                        }
                    }
                }

                $this->collTTypeEtabsRelatedByCodeLibelle = $collTTypeEtabsRelatedByCodeLibelle;
                $this->collTTypeEtabsRelatedByCodeLibellePartial = false;
            }
        }

        return $this->collTTypeEtabsRelatedByCodeLibelle;
    }

    /**
     * Sets a collection of TTypeEtabRelatedByCodeLibelle objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tTypeEtabsRelatedByCodeLibelle A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTTypeEtabsRelatedByCodeLibelle(PropelCollection $tTypeEtabsRelatedByCodeLibelle, PropelPDO $con = null)
    {
        $tTypeEtabsRelatedByCodeLibelleToDelete = $this->getTTypeEtabsRelatedByCodeLibelle(new Criteria(), $con)->diff($tTypeEtabsRelatedByCodeLibelle);

        $this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion = unserialize(serialize($tTypeEtabsRelatedByCodeLibelleToDelete));

        foreach ($tTypeEtabsRelatedByCodeLibelleToDelete as $tTypeEtabRelatedByCodeLibelleRemoved) {
            $tTypeEtabRelatedByCodeLibelleRemoved->setTTraductionRelatedByCodeLibelle(null);
        }

        $this->collTTypeEtabsRelatedByCodeLibelle = null;
        foreach ($tTypeEtabsRelatedByCodeLibelle as $tTypeEtabRelatedByCodeLibelle) {
            $this->addTTypeEtabRelatedByCodeLibelle($tTypeEtabRelatedByCodeLibelle);
        }

        $this->collTTypeEtabsRelatedByCodeLibelle = $tTypeEtabsRelatedByCodeLibelle;
        $this->collTTypeEtabsRelatedByCodeLibellePartial = false;

        return $this;
    }

    /**
     * Returns the number of related TTypeEtab objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TTypeEtab objects.
     * @throws PropelException
     */
    public function countTTypeEtabsRelatedByCodeLibelle(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTTypeEtabsRelatedByCodeLibellePartial && !$this->isNew();
        if (null === $this->collTTypeEtabsRelatedByCodeLibelle || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTTypeEtabsRelatedByCodeLibelle) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTTypeEtabsRelatedByCodeLibelle());
            }
            $query = TTypeEtabQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelle($this)
                ->count($con);
        }

        return count($this->collTTypeEtabsRelatedByCodeLibelle);
    }

    /**
     * Method called to associate a TTypeEtab object to this object
     * through the TTypeEtab foreign key attribute.
     *
     * @param    TTypeEtab $l TTypeEtab
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTTypeEtabRelatedByCodeLibelle(TTypeEtab $l)
    {
        if ($this->collTTypeEtabsRelatedByCodeLibelle === null) {
            $this->initTTypeEtabsRelatedByCodeLibelle();
            $this->collTTypeEtabsRelatedByCodeLibellePartial = true;
        }
        if (!in_array($l, $this->collTTypeEtabsRelatedByCodeLibelle->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTTypeEtabRelatedByCodeLibelle($l);
        }

        return $this;
    }

    /**
     * @param	TTypeEtabRelatedByCodeLibelle $tTypeEtabRelatedByCodeLibelle The tTypeEtabRelatedByCodeLibelle object to add.
     */
    protected function doAddTTypeEtabRelatedByCodeLibelle($tTypeEtabRelatedByCodeLibelle)
    {
        $this->collTTypeEtabsRelatedByCodeLibelle[]= $tTypeEtabRelatedByCodeLibelle;
        $tTypeEtabRelatedByCodeLibelle->setTTraductionRelatedByCodeLibelle($this);
    }

    /**
     * @param	TTypeEtabRelatedByCodeLibelle $tTypeEtabRelatedByCodeLibelle The tTypeEtabRelatedByCodeLibelle object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTTypeEtabRelatedByCodeLibelle($tTypeEtabRelatedByCodeLibelle)
    {
        if ($this->getTTypeEtabsRelatedByCodeLibelle()->contains($tTypeEtabRelatedByCodeLibelle)) {
            $this->collTTypeEtabsRelatedByCodeLibelle->remove($this->collTTypeEtabsRelatedByCodeLibelle->search($tTypeEtabRelatedByCodeLibelle));
            if (null === $this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion) {
                $this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion = clone $this->collTTypeEtabsRelatedByCodeLibelle;
                $this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion->clear();
            }
            $this->tTypeEtabsRelatedByCodeLibelleScheduledForDeletion[]= clone $tTypeEtabRelatedByCodeLibelle;
            $tTypeEtabRelatedByCodeLibelle->setTTraductionRelatedByCodeLibelle(null);
        }

        return $this;
    }

    /**
     * Clears out the collTTypeEtabsRelatedByCodeLibelleEtab collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTTypeEtabsRelatedByCodeLibelleEtab()
     */
    public function clearTTypeEtabsRelatedByCodeLibelleEtab()
    {
        $this->collTTypeEtabsRelatedByCodeLibelleEtab = null; // important to set this to null since that means it is uninitialized
        $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial = null;

        return $this;
    }

    /**
     * reset is the collTTypeEtabsRelatedByCodeLibelleEtab collection loaded partially
     *
     * @return void
     */
    public function resetPartialTTypeEtabsRelatedByCodeLibelleEtab($v = true)
    {
        $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial = $v;
    }

    /**
     * Initializes the collTTypeEtabsRelatedByCodeLibelleEtab collection.
     *
     * By default this just sets the collTTypeEtabsRelatedByCodeLibelleEtab collection to an empty array (like clearcollTTypeEtabsRelatedByCodeLibelleEtab());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTTypeEtabsRelatedByCodeLibelleEtab($overrideExisting = true)
    {
        if (null !== $this->collTTypeEtabsRelatedByCodeLibelleEtab && !$overrideExisting) {
            return;
        }
        $this->collTTypeEtabsRelatedByCodeLibelleEtab = new PropelObjectCollection();
        $this->collTTypeEtabsRelatedByCodeLibelleEtab->setModel('TTypeEtab');
    }

    /**
     * Gets an array of TTypeEtab objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TTypeEtab[] List of TTypeEtab objects
     * @throws PropelException
     */
    public function getTTypeEtabsRelatedByCodeLibelleEtab($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial && !$this->isNew();
        if (null === $this->collTTypeEtabsRelatedByCodeLibelleEtab || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTTypeEtabsRelatedByCodeLibelleEtab) {
                // return empty collection
                $this->initTTypeEtabsRelatedByCodeLibelleEtab();
            } else {
                $collTTypeEtabsRelatedByCodeLibelleEtab = TTypeEtabQuery::create(null, $criteria)
                    ->filterByTTraductionRelatedByCodeLibelleEtab($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial && count($collTTypeEtabsRelatedByCodeLibelleEtab)) {
                      $this->initTTypeEtabsRelatedByCodeLibelleEtab(false);

                      foreach($collTTypeEtabsRelatedByCodeLibelleEtab as $obj) {
                        if (false == $this->collTTypeEtabsRelatedByCodeLibelleEtab->contains($obj)) {
                          $this->collTTypeEtabsRelatedByCodeLibelleEtab->append($obj);
                        }
                      }

                      $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial = true;
                    }

                    $collTTypeEtabsRelatedByCodeLibelleEtab->getInternalIterator()->rewind();
                    return $collTTypeEtabsRelatedByCodeLibelleEtab;
                }

                if($partial && $this->collTTypeEtabsRelatedByCodeLibelleEtab) {
                    foreach($this->collTTypeEtabsRelatedByCodeLibelleEtab as $obj) {
                        if($obj->isNew()) {
                            $collTTypeEtabsRelatedByCodeLibelleEtab[] = $obj;
                        }
                    }
                }

                $this->collTTypeEtabsRelatedByCodeLibelleEtab = $collTTypeEtabsRelatedByCodeLibelleEtab;
                $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial = false;
            }
        }

        return $this->collTTypeEtabsRelatedByCodeLibelleEtab;
    }

    /**
     * Sets a collection of TTypeEtabRelatedByCodeLibelleEtab objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tTypeEtabsRelatedByCodeLibelleEtab A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTTypeEtabsRelatedByCodeLibelleEtab(PropelCollection $tTypeEtabsRelatedByCodeLibelleEtab, PropelPDO $con = null)
    {
        $tTypeEtabsRelatedByCodeLibelleEtabToDelete = $this->getTTypeEtabsRelatedByCodeLibelleEtab(new Criteria(), $con)->diff($tTypeEtabsRelatedByCodeLibelleEtab);

        $this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion = unserialize(serialize($tTypeEtabsRelatedByCodeLibelleEtabToDelete));

        foreach ($tTypeEtabsRelatedByCodeLibelleEtabToDelete as $tTypeEtabRelatedByCodeLibelleEtabRemoved) {
            $tTypeEtabRelatedByCodeLibelleEtabRemoved->setTTraductionRelatedByCodeLibelleEtab(null);
        }

        $this->collTTypeEtabsRelatedByCodeLibelleEtab = null;
        foreach ($tTypeEtabsRelatedByCodeLibelleEtab as $tTypeEtabRelatedByCodeLibelleEtab) {
            $this->addTTypeEtabRelatedByCodeLibelleEtab($tTypeEtabRelatedByCodeLibelleEtab);
        }

        $this->collTTypeEtabsRelatedByCodeLibelleEtab = $tTypeEtabsRelatedByCodeLibelleEtab;
        $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TTypeEtab objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TTypeEtab objects.
     * @throws PropelException
     */
    public function countTTypeEtabsRelatedByCodeLibelleEtab(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial && !$this->isNew();
        if (null === $this->collTTypeEtabsRelatedByCodeLibelleEtab || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTTypeEtabsRelatedByCodeLibelleEtab) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTTypeEtabsRelatedByCodeLibelleEtab());
            }
            $query = TTypeEtabQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraductionRelatedByCodeLibelleEtab($this)
                ->count($con);
        }

        return count($this->collTTypeEtabsRelatedByCodeLibelleEtab);
    }

    /**
     * Method called to associate a TTypeEtab object to this object
     * through the TTypeEtab foreign key attribute.
     *
     * @param    TTypeEtab $l TTypeEtab
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTTypeEtabRelatedByCodeLibelleEtab(TTypeEtab $l)
    {
        if ($this->collTTypeEtabsRelatedByCodeLibelleEtab === null) {
            $this->initTTypeEtabsRelatedByCodeLibelleEtab();
            $this->collTTypeEtabsRelatedByCodeLibelleEtabPartial = true;
        }
        if (!in_array($l, $this->collTTypeEtabsRelatedByCodeLibelleEtab->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTTypeEtabRelatedByCodeLibelleEtab($l);
        }

        return $this;
    }

    /**
     * @param	TTypeEtabRelatedByCodeLibelleEtab $tTypeEtabRelatedByCodeLibelleEtab The tTypeEtabRelatedByCodeLibelleEtab object to add.
     */
    protected function doAddTTypeEtabRelatedByCodeLibelleEtab($tTypeEtabRelatedByCodeLibelleEtab)
    {
        $this->collTTypeEtabsRelatedByCodeLibelleEtab[]= $tTypeEtabRelatedByCodeLibelleEtab;
        $tTypeEtabRelatedByCodeLibelleEtab->setTTraductionRelatedByCodeLibelleEtab($this);
    }

    /**
     * @param	TTypeEtabRelatedByCodeLibelleEtab $tTypeEtabRelatedByCodeLibelleEtab The tTypeEtabRelatedByCodeLibelleEtab object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTTypeEtabRelatedByCodeLibelleEtab($tTypeEtabRelatedByCodeLibelleEtab)
    {
        if ($this->getTTypeEtabsRelatedByCodeLibelleEtab()->contains($tTypeEtabRelatedByCodeLibelleEtab)) {
            $this->collTTypeEtabsRelatedByCodeLibelleEtab->remove($this->collTTypeEtabsRelatedByCodeLibelleEtab->search($tTypeEtabRelatedByCodeLibelleEtab));
            if (null === $this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion) {
                $this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion = clone $this->collTTypeEtabsRelatedByCodeLibelleEtab;
                $this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion->clear();
            }
            $this->tTypeEtabsRelatedByCodeLibelleEtabScheduledForDeletion[]= clone $tTypeEtabRelatedByCodeLibelleEtab;
            $tTypeEtabRelatedByCodeLibelleEtab->setTTraductionRelatedByCodeLibelleEtab(null);
        }

        return $this;
    }

    /**
     * Clears out the collTTypePrestations collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTTypePrestations()
     */
    public function clearTTypePrestations()
    {
        $this->collTTypePrestations = null; // important to set this to null since that means it is uninitialized
        $this->collTTypePrestationsPartial = null;

        return $this;
    }

    /**
     * reset is the collTTypePrestations collection loaded partially
     *
     * @return void
     */
    public function resetPartialTTypePrestations($v = true)
    {
        $this->collTTypePrestationsPartial = $v;
    }

    /**
     * Initializes the collTTypePrestations collection.
     *
     * By default this just sets the collTTypePrestations collection to an empty array (like clearcollTTypePrestations());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTTypePrestations($overrideExisting = true)
    {
        if (null !== $this->collTTypePrestations && !$overrideExisting) {
            return;
        }
        $this->collTTypePrestations = new PropelObjectCollection();
        $this->collTTypePrestations->setModel('TTypePrestation');
    }

    /**
     * Gets an array of TTypePrestation objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     * @throws PropelException
     */
    public function getTTypePrestations($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTTypePrestations || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTTypePrestations) {
                // return empty collection
                $this->initTTypePrestations();
            } else {
                $collTTypePrestations = TTypePrestationQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTTypePrestationsPartial && count($collTTypePrestations)) {
                      $this->initTTypePrestations(false);

                      foreach($collTTypePrestations as $obj) {
                        if (false == $this->collTTypePrestations->contains($obj)) {
                          $this->collTTypePrestations->append($obj);
                        }
                      }

                      $this->collTTypePrestationsPartial = true;
                    }

                    $collTTypePrestations->getInternalIterator()->rewind();
                    return $collTTypePrestations;
                }

                if($partial && $this->collTTypePrestations) {
                    foreach($this->collTTypePrestations as $obj) {
                        if($obj->isNew()) {
                            $collTTypePrestations[] = $obj;
                        }
                    }
                }

                $this->collTTypePrestations = $collTTypePrestations;
                $this->collTTypePrestationsPartial = false;
            }
        }

        return $this->collTTypePrestations;
    }

    /**
     * Sets a collection of TTypePrestation objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tTypePrestations A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTTypePrestations(PropelCollection $tTypePrestations, PropelPDO $con = null)
    {
        $tTypePrestationsToDelete = $this->getTTypePrestations(new Criteria(), $con)->diff($tTypePrestations);

        $this->tTypePrestationsScheduledForDeletion = unserialize(serialize($tTypePrestationsToDelete));

        foreach ($tTypePrestationsToDelete as $tTypePrestationRemoved) {
            $tTypePrestationRemoved->setTTraduction(null);
        }

        $this->collTTypePrestations = null;
        foreach ($tTypePrestations as $tTypePrestation) {
            $this->addTTypePrestation($tTypePrestation);
        }

        $this->collTTypePrestations = $tTypePrestations;
        $this->collTTypePrestationsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TTypePrestation objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TTypePrestation objects.
     * @throws PropelException
     */
    public function countTTypePrestations(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTTypePrestationsPartial && !$this->isNew();
        if (null === $this->collTTypePrestations || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTTypePrestations) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTTypePrestations());
            }
            $query = TTypePrestationQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTTypePrestations);
    }

    /**
     * Method called to associate a TTypePrestation object to this object
     * through the TTypePrestation foreign key attribute.
     *
     * @param    TTypePrestation $l TTypePrestation
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTTypePrestation(TTypePrestation $l)
    {
        if ($this->collTTypePrestations === null) {
            $this->initTTypePrestations();
            $this->collTTypePrestationsPartial = true;
        }
        if (!in_array($l, $this->collTTypePrestations->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTTypePrestation($l);
        }

        return $this;
    }

    /**
     * @param	TTypePrestation $tTypePrestation The tTypePrestation object to add.
     */
    protected function doAddTTypePrestation($tTypePrestation)
    {
        $this->collTTypePrestations[]= $tTypePrestation;
        $tTypePrestation->setTTraduction($this);
    }

    /**
     * @param	TTypePrestation $tTypePrestation The tTypePrestation object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTTypePrestation($tTypePrestation)
    {
        if ($this->getTTypePrestations()->contains($tTypePrestation)) {
            $this->collTTypePrestations->remove($this->collTTypePrestations->search($tTypePrestation));
            if (null === $this->tTypePrestationsScheduledForDeletion) {
                $this->tTypePrestationsScheduledForDeletion = clone $this->collTTypePrestations;
                $this->tTypePrestationsScheduledForDeletion->clear();
            }
            $this->tTypePrestationsScheduledForDeletion[]= $tTypePrestation;
            $tTypePrestation->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     */
    public function getTTypePrestationsJoinTEtablissement($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TEtablissement', $join_behavior);

        return $this->getTTypePrestations($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TTypePrestations from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TTypePrestation[] List of TTypePrestation objects
     */
    public function getTTypePrestationsJoinTRefTypePrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TTypePrestationQuery::create(null, $criteria);
        $query->joinWith('TRefTypePrestation', $join_behavior);

        return $this->getTTypePrestations($query, $con);
    }

    /**
     * Clears out the collTTypeProfils collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTTypeProfils()
     */
    public function clearTTypeProfils()
    {
        $this->collTTypeProfils = null; // important to set this to null since that means it is uninitialized
        $this->collTTypeProfilsPartial = null;

        return $this;
    }

    /**
     * reset is the collTTypeProfils collection loaded partially
     *
     * @return void
     */
    public function resetPartialTTypeProfils($v = true)
    {
        $this->collTTypeProfilsPartial = $v;
    }

    /**
     * Initializes the collTTypeProfils collection.
     *
     * By default this just sets the collTTypeProfils collection to an empty array (like clearcollTTypeProfils());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTTypeProfils($overrideExisting = true)
    {
        if (null !== $this->collTTypeProfils && !$overrideExisting) {
            return;
        }
        $this->collTTypeProfils = new PropelObjectCollection();
        $this->collTTypeProfils->setModel('TTypeProfil');
    }

    /**
     * Gets an array of TTypeProfil objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TTypeProfil[] List of TTypeProfil objects
     * @throws PropelException
     */
    public function getTTypeProfils($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTTypeProfilsPartial && !$this->isNew();
        if (null === $this->collTTypeProfils || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTTypeProfils) {
                // return empty collection
                $this->initTTypeProfils();
            } else {
                $collTTypeProfils = TTypeProfilQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTTypeProfilsPartial && count($collTTypeProfils)) {
                      $this->initTTypeProfils(false);

                      foreach($collTTypeProfils as $obj) {
                        if (false == $this->collTTypeProfils->contains($obj)) {
                          $this->collTTypeProfils->append($obj);
                        }
                      }

                      $this->collTTypeProfilsPartial = true;
                    }

                    $collTTypeProfils->getInternalIterator()->rewind();
                    return $collTTypeProfils;
                }

                if($partial && $this->collTTypeProfils) {
                    foreach($this->collTTypeProfils as $obj) {
                        if($obj->isNew()) {
                            $collTTypeProfils[] = $obj;
                        }
                    }
                }

                $this->collTTypeProfils = $collTTypeProfils;
                $this->collTTypeProfilsPartial = false;
            }
        }

        return $this->collTTypeProfils;
    }

    /**
     * Sets a collection of TTypeProfil objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tTypeProfils A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTTypeProfils(PropelCollection $tTypeProfils, PropelPDO $con = null)
    {
        $tTypeProfilsToDelete = $this->getTTypeProfils(new Criteria(), $con)->diff($tTypeProfils);

        $this->tTypeProfilsScheduledForDeletion = unserialize(serialize($tTypeProfilsToDelete));

        foreach ($tTypeProfilsToDelete as $tTypeProfilRemoved) {
            $tTypeProfilRemoved->setTTraduction(null);
        }

        $this->collTTypeProfils = null;
        foreach ($tTypeProfils as $tTypeProfil) {
            $this->addTTypeProfil($tTypeProfil);
        }

        $this->collTTypeProfils = $tTypeProfils;
        $this->collTTypeProfilsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TTypeProfil objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TTypeProfil objects.
     * @throws PropelException
     */
    public function countTTypeProfils(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTTypeProfilsPartial && !$this->isNew();
        if (null === $this->collTTypeProfils || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTTypeProfils) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTTypeProfils());
            }
            $query = TTypeProfilQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTTypeProfils);
    }

    /**
     * Method called to associate a TTypeProfil object to this object
     * through the TTypeProfil foreign key attribute.
     *
     * @param    TTypeProfil $l TTypeProfil
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTTypeProfil(TTypeProfil $l)
    {
        if ($this->collTTypeProfils === null) {
            $this->initTTypeProfils();
            $this->collTTypeProfilsPartial = true;
        }
        if (!in_array($l, $this->collTTypeProfils->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTTypeProfil($l);
        }

        return $this;
    }

    /**
     * @param	TTypeProfil $tTypeProfil The tTypeProfil object to add.
     */
    protected function doAddTTypeProfil($tTypeProfil)
    {
        $this->collTTypeProfils[]= $tTypeProfil;
        $tTypeProfil->setTTraduction($this);
    }

    /**
     * @param	TTypeProfil $tTypeProfil The tTypeProfil object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTTypeProfil($tTypeProfil)
    {
        if ($this->getTTypeProfils()->contains($tTypeProfil)) {
            $this->collTTypeProfils->remove($this->collTTypeProfils->search($tTypeProfil));
            if (null === $this->tTypeProfilsScheduledForDeletion) {
                $this->tTypeProfilsScheduledForDeletion = clone $this->collTTypeProfils;
                $this->tTypeProfilsScheduledForDeletion->clear();
            }
            $this->tTypeProfilsScheduledForDeletion[]= clone $tTypeProfil;
            $tTypeProfil->setTTraduction(null);
        }

        return $this;
    }

    /**
     * Clears out the collTValeurReferentiels collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TTraduction The current object (for fluent API support)
     * @see        addTValeurReferentiels()
     */
    public function clearTValeurReferentiels()
    {
        $this->collTValeurReferentiels = null; // important to set this to null since that means it is uninitialized
        $this->collTValeurReferentielsPartial = null;

        return $this;
    }

    /**
     * reset is the collTValeurReferentiels collection loaded partially
     *
     * @return void
     */
    public function resetPartialTValeurReferentiels($v = true)
    {
        $this->collTValeurReferentielsPartial = $v;
    }

    /**
     * Initializes the collTValeurReferentiels collection.
     *
     * By default this just sets the collTValeurReferentiels collection to an empty array (like clearcollTValeurReferentiels());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTValeurReferentiels($overrideExisting = true)
    {
        if (null !== $this->collTValeurReferentiels && !$overrideExisting) {
            return;
        }
        $this->collTValeurReferentiels = new PropelObjectCollection();
        $this->collTValeurReferentiels->setModel('TValeurReferentiel');
    }

    /**
     * Gets an array of TValeurReferentiel objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TTraduction is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TValeurReferentiel[] List of TValeurReferentiel objects
     * @throws PropelException
     */
    public function getTValeurReferentiels($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTValeurReferentielsPartial && !$this->isNew();
        if (null === $this->collTValeurReferentiels || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTValeurReferentiels) {
                // return empty collection
                $this->initTValeurReferentiels();
            } else {
                $collTValeurReferentiels = TValeurReferentielQuery::create(null, $criteria)
                    ->filterByTTraduction($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTValeurReferentielsPartial && count($collTValeurReferentiels)) {
                      $this->initTValeurReferentiels(false);

                      foreach($collTValeurReferentiels as $obj) {
                        if (false == $this->collTValeurReferentiels->contains($obj)) {
                          $this->collTValeurReferentiels->append($obj);
                        }
                      }

                      $this->collTValeurReferentielsPartial = true;
                    }

                    $collTValeurReferentiels->getInternalIterator()->rewind();
                    return $collTValeurReferentiels;
                }

                if($partial && $this->collTValeurReferentiels) {
                    foreach($this->collTValeurReferentiels as $obj) {
                        if($obj->isNew()) {
                            $collTValeurReferentiels[] = $obj;
                        }
                    }
                }

                $this->collTValeurReferentiels = $collTValeurReferentiels;
                $this->collTValeurReferentielsPartial = false;
            }
        }

        return $this->collTValeurReferentiels;
    }

    /**
     * Sets a collection of TValeurReferentiel objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tValeurReferentiels A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TTraduction The current object (for fluent API support)
     */
    public function setTValeurReferentiels(PropelCollection $tValeurReferentiels, PropelPDO $con = null)
    {
        $tValeurReferentielsToDelete = $this->getTValeurReferentiels(new Criteria(), $con)->diff($tValeurReferentiels);

        $this->tValeurReferentielsScheduledForDeletion = unserialize(serialize($tValeurReferentielsToDelete));

        foreach ($tValeurReferentielsToDelete as $tValeurReferentielRemoved) {
            $tValeurReferentielRemoved->setTTraduction(null);
        }

        $this->collTValeurReferentiels = null;
        foreach ($tValeurReferentiels as $tValeurReferentiel) {
            $this->addTValeurReferentiel($tValeurReferentiel);
        }

        $this->collTValeurReferentiels = $tValeurReferentiels;
        $this->collTValeurReferentielsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TValeurReferentiel objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TValeurReferentiel objects.
     * @throws PropelException
     */
    public function countTValeurReferentiels(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTValeurReferentielsPartial && !$this->isNew();
        if (null === $this->collTValeurReferentiels || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTValeurReferentiels) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTValeurReferentiels());
            }
            $query = TValeurReferentielQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTTraduction($this)
                ->count($con);
        }

        return count($this->collTValeurReferentiels);
    }

    /**
     * Method called to associate a TValeurReferentiel object to this object
     * through the TValeurReferentiel foreign key attribute.
     *
     * @param    TValeurReferentiel $l TValeurReferentiel
     * @return TTraduction The current object (for fluent API support)
     */
    public function addTValeurReferentiel(TValeurReferentiel $l)
    {
        if ($this->collTValeurReferentiels === null) {
            $this->initTValeurReferentiels();
            $this->collTValeurReferentielsPartial = true;
        }
        if (!in_array($l, $this->collTValeurReferentiels->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTValeurReferentiel($l);
        }

        return $this;
    }

    /**
     * @param	TValeurReferentiel $tValeurReferentiel The tValeurReferentiel object to add.
     */
    protected function doAddTValeurReferentiel($tValeurReferentiel)
    {
        $this->collTValeurReferentiels[]= $tValeurReferentiel;
        $tValeurReferentiel->setTTraduction($this);
    }

    /**
     * @param	TValeurReferentiel $tValeurReferentiel The tValeurReferentiel object to remove.
     * @return TTraduction The current object (for fluent API support)
     */
    public function removeTValeurReferentiel($tValeurReferentiel)
    {
        if ($this->getTValeurReferentiels()->contains($tValeurReferentiel)) {
            $this->collTValeurReferentiels->remove($this->collTValeurReferentiels->search($tValeurReferentiel));
            if (null === $this->tValeurReferentielsScheduledForDeletion) {
                $this->tValeurReferentielsScheduledForDeletion = clone $this->collTValeurReferentiels;
                $this->tValeurReferentielsScheduledForDeletion->clear();
            }
            $this->tValeurReferentielsScheduledForDeletion[]= $tValeurReferentiel;
            $tValeurReferentiel->setTTraduction(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TValeurReferentiels from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TValeurReferentiel[] List of TValeurReferentiel objects
     */
    public function getTValeurReferentielsJoinTOrganisation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TValeurReferentielQuery::create(null, $criteria);
        $query->joinWith('TOrganisation', $join_behavior);

        return $this->getTValeurReferentiels($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TTraduction is new, it will return
     * an empty collection; or if this TTraduction has previously
     * been saved, it will retrieve related TValeurReferentiels from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TTraduction.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TValeurReferentiel[] List of TValeurReferentiel objects
     */
    public function getTValeurReferentielsJoinTReferentiel($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TValeurReferentielQuery::create(null, $criteria);
        $query->joinWith('TReferentiel', $join_behavior);

        return $this->getTValeurReferentiels($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_traduction = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTAgentsRelatedByCodeNomUtilisateur) {
                foreach ($this->collTAgentsRelatedByCodeNomUtilisateur as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgentsRelatedByCodePrenomUtilisateur) {
                foreach ($this->collTAgentsRelatedByCodePrenomUtilisateur as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTAgentsRelatedByCodeUtilisateur) {
                foreach ($this->collTAgentsRelatedByCodeUtilisateur as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTChampsSupps) {
                foreach ($this->collTChampsSupps as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTEntites) {
                foreach ($this->collTEntites as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTEtablissementsRelatedByCodeAdresseEtablissement) {
                foreach ($this->collTEtablissementsRelatedByCodeAdresseEtablissement as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTEtablissementsRelatedByCodeDenominationEtablissement) {
                foreach ($this->collTEtablissementsRelatedByCodeDenominationEtablissement as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement) {
                foreach ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTGroupes) {
                foreach ($this->collTGroupes as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTJourFeries) {
                foreach ($this->collTJourFeries as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeAdresseOrganisation) {
                foreach ($this->collTOrganisationsRelatedByCodeAdresseOrganisation as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeDenominationOrganisation) {
                foreach ($this->collTOrganisationsRelatedByCodeDenominationOrganisation as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation) {
                foreach ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeLibelleLien1) {
                foreach ($this->collTOrganisationsRelatedByCodeLibelleLien1 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeLibelleLien2) {
                foreach ($this->collTOrganisationsRelatedByCodeLibelleLien2 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeLibelleLien3) {
                foreach ($this->collTOrganisationsRelatedByCodeLibelleLien3 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeMessageBienvenue) {
                foreach ($this->collTOrganisationsRelatedByCodeMessageBienvenue as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTOrganisationsRelatedByCodeTitreBienvenue) {
                foreach ($this->collTOrganisationsRelatedByCodeTitreBienvenue as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametragePrestationsRelatedByCodeCommentaire) {
                foreach ($this->collTParametragePrestationsRelatedByCodeCommentaire as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametragePrestationsRelatedByCodeAide) {
                foreach ($this->collTParametragePrestationsRelatedByCodeAide as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByCodeCommentaire) {
                foreach ($this->collTParametreFormsRelatedByCodeCommentaire as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByCodeLibelleRef1) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleRef1 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByCodeLibelleRef2) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleRef2 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByCodeLibelleRef3) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleRef3 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByCodeLibelleText1) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleText1 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByCodeLibelleText2) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleText2 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTParametreFormsRelatedByCodeLibelleText3) {
                foreach ($this->collTParametreFormsRelatedByCodeLibelleText3 as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPieceParamPrestas) {
                foreach ($this->collTPieceParamPrestas as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPiecePrestations) {
                foreach ($this->collTPiecePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPrestationsRelatedByCodeCommentaire) {
                foreach ($this->collTPrestationsRelatedByCodeCommentaire as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTPrestationsRelatedByCodeLibellePrestation) {
                foreach ($this->collTPrestationsRelatedByCodeLibellePrestation as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTProfils) {
                foreach ($this->collTProfils as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTReferentsRelatedByCodeNomReferent) {
                foreach ($this->collTReferentsRelatedByCodeNomReferent as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTReferentsRelatedByCodePrenomReferent) {
                foreach ($this->collTReferentsRelatedByCodePrenomReferent as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTReferentiels) {
                foreach ($this->collTReferentiels as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRefPrestationsRelatedByCodeAide) {
                foreach ($this->collTRefPrestationsRelatedByCodeAide as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRefPrestationsRelatedByCodeLibelle) {
                foreach ($this->collTRefPrestationsRelatedByCodeLibelle as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTRefTypePrestations) {
                foreach ($this->collTRefTypePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTTraductionLibelles) {
                foreach ($this->collTTraductionLibelles as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTTypeEtabsRelatedByCodeLibelle) {
                foreach ($this->collTTypeEtabsRelatedByCodeLibelle as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTTypeEtabsRelatedByCodeLibelleEtab) {
                foreach ($this->collTTypeEtabsRelatedByCodeLibelleEtab as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTTypePrestations) {
                foreach ($this->collTTypePrestations as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTTypeProfils) {
                foreach ($this->collTTypeProfils as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->collTValeurReferentiels) {
                foreach ($this->collTValeurReferentiels as $o) {
                    $o->clearAllReferences($deep);
                }
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTAgentsRelatedByCodeNomUtilisateur instanceof PropelCollection) {
            $this->collTAgentsRelatedByCodeNomUtilisateur->clearIterator();
        }
        $this->collTAgentsRelatedByCodeNomUtilisateur = null;
        if ($this->collTAgentsRelatedByCodePrenomUtilisateur instanceof PropelCollection) {
            $this->collTAgentsRelatedByCodePrenomUtilisateur->clearIterator();
        }
        $this->collTAgentsRelatedByCodePrenomUtilisateur = null;
        if ($this->collTAgentsRelatedByCodeUtilisateur instanceof PropelCollection) {
            $this->collTAgentsRelatedByCodeUtilisateur->clearIterator();
        }
        $this->collTAgentsRelatedByCodeUtilisateur = null;
        if ($this->collTChampsSupps instanceof PropelCollection) {
            $this->collTChampsSupps->clearIterator();
        }
        $this->collTChampsSupps = null;
        if ($this->collTEntites instanceof PropelCollection) {
            $this->collTEntites->clearIterator();
        }
        $this->collTEntites = null;
        if ($this->collTEtablissementsRelatedByCodeAdresseEtablissement instanceof PropelCollection) {
            $this->collTEtablissementsRelatedByCodeAdresseEtablissement->clearIterator();
        }
        $this->collTEtablissementsRelatedByCodeAdresseEtablissement = null;
        if ($this->collTEtablissementsRelatedByCodeDenominationEtablissement instanceof PropelCollection) {
            $this->collTEtablissementsRelatedByCodeDenominationEtablissement->clearIterator();
        }
        $this->collTEtablissementsRelatedByCodeDenominationEtablissement = null;
        if ($this->collTEtablissementsRelatedByCodeDescriptionEtablissement instanceof PropelCollection) {
            $this->collTEtablissementsRelatedByCodeDescriptionEtablissement->clearIterator();
        }
        $this->collTEtablissementsRelatedByCodeDescriptionEtablissement = null;
        if ($this->collTGroupes instanceof PropelCollection) {
            $this->collTGroupes->clearIterator();
        }
        $this->collTGroupes = null;
        if ($this->collTJourFeries instanceof PropelCollection) {
            $this->collTJourFeries->clearIterator();
        }
        $this->collTJourFeries = null;
        if ($this->collTOrganisationsRelatedByCodeAdresseOrganisation instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeAdresseOrganisation->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeAdresseOrganisation = null;
        if ($this->collTOrganisationsRelatedByCodeDenominationOrganisation instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeDenominationOrganisation->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeDenominationOrganisation = null;
        if ($this->collTOrganisationsRelatedByCodeDescriptionOrganisation instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeDescriptionOrganisation->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeDescriptionOrganisation = null;
        if ($this->collTOrganisationsRelatedByCodeLibelleLien1 instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeLibelleLien1->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeLibelleLien1 = null;
        if ($this->collTOrganisationsRelatedByCodeLibelleLien2 instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeLibelleLien2->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeLibelleLien2 = null;
        if ($this->collTOrganisationsRelatedByCodeLibelleLien3 instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeLibelleLien3->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeLibelleLien3 = null;
        if ($this->collTOrganisationsRelatedByCodeMessageBienvenue instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeMessageBienvenue->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeMessageBienvenue = null;
        if ($this->collTOrganisationsRelatedByCodeTitreBienvenue instanceof PropelCollection) {
            $this->collTOrganisationsRelatedByCodeTitreBienvenue->clearIterator();
        }
        $this->collTOrganisationsRelatedByCodeTitreBienvenue = null;
        if ($this->collTParametragePrestationsRelatedByCodeCommentaire instanceof PropelCollection) {
            $this->collTParametragePrestationsRelatedByCodeCommentaire->clearIterator();
        }
        $this->collTParametragePrestationsRelatedByCodeCommentaire = null;
        if ($this->collTParametragePrestationsRelatedByCodeAide instanceof PropelCollection) {
            $this->collTParametragePrestationsRelatedByCodeAide->clearIterator();
        }
        $this->collTParametragePrestationsRelatedByCodeAide = null;
        if ($this->collTParametreFormsRelatedByCodeCommentaire instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByCodeCommentaire->clearIterator();
        }
        $this->collTParametreFormsRelatedByCodeCommentaire = null;
        if ($this->collTParametreFormsRelatedByCodeLibelleRef1 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByCodeLibelleRef1->clearIterator();
        }
        $this->collTParametreFormsRelatedByCodeLibelleRef1 = null;
        if ($this->collTParametreFormsRelatedByCodeLibelleRef2 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByCodeLibelleRef2->clearIterator();
        }
        $this->collTParametreFormsRelatedByCodeLibelleRef2 = null;
        if ($this->collTParametreFormsRelatedByCodeLibelleRef3 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByCodeLibelleRef3->clearIterator();
        }
        $this->collTParametreFormsRelatedByCodeLibelleRef3 = null;
        if ($this->collTParametreFormsRelatedByCodeLibelleText1 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByCodeLibelleText1->clearIterator();
        }
        $this->collTParametreFormsRelatedByCodeLibelleText1 = null;
        if ($this->collTParametreFormsRelatedByCodeLibelleText2 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByCodeLibelleText2->clearIterator();
        }
        $this->collTParametreFormsRelatedByCodeLibelleText2 = null;
        if ($this->collTParametreFormsRelatedByCodeLibelleText3 instanceof PropelCollection) {
            $this->collTParametreFormsRelatedByCodeLibelleText3->clearIterator();
        }
        $this->collTParametreFormsRelatedByCodeLibelleText3 = null;
        if ($this->collTPieceParamPrestas instanceof PropelCollection) {
            $this->collTPieceParamPrestas->clearIterator();
        }
        $this->collTPieceParamPrestas = null;
        if ($this->collTPiecePrestations instanceof PropelCollection) {
            $this->collTPiecePrestations->clearIterator();
        }
        $this->collTPiecePrestations = null;
        if ($this->collTPrestationsRelatedByCodeCommentaire instanceof PropelCollection) {
            $this->collTPrestationsRelatedByCodeCommentaire->clearIterator();
        }
        $this->collTPrestationsRelatedByCodeCommentaire = null;
        if ($this->collTPrestationsRelatedByCodeLibellePrestation instanceof PropelCollection) {
            $this->collTPrestationsRelatedByCodeLibellePrestation->clearIterator();
        }
        $this->collTPrestationsRelatedByCodeLibellePrestation = null;
        if ($this->collTProfils instanceof PropelCollection) {
            $this->collTProfils->clearIterator();
        }
        $this->collTProfils = null;
        if ($this->collTReferentsRelatedByCodeNomReferent instanceof PropelCollection) {
            $this->collTReferentsRelatedByCodeNomReferent->clearIterator();
        }
        $this->collTReferentsRelatedByCodeNomReferent = null;
        if ($this->collTReferentsRelatedByCodePrenomReferent instanceof PropelCollection) {
            $this->collTReferentsRelatedByCodePrenomReferent->clearIterator();
        }
        $this->collTReferentsRelatedByCodePrenomReferent = null;
        if ($this->collTReferentiels instanceof PropelCollection) {
            $this->collTReferentiels->clearIterator();
        }
        $this->collTReferentiels = null;
        if ($this->collTRefPrestationsRelatedByCodeAide instanceof PropelCollection) {
            $this->collTRefPrestationsRelatedByCodeAide->clearIterator();
        }
        $this->collTRefPrestationsRelatedByCodeAide = null;
        if ($this->collTRefPrestationsRelatedByCodeLibelle instanceof PropelCollection) {
            $this->collTRefPrestationsRelatedByCodeLibelle->clearIterator();
        }
        $this->collTRefPrestationsRelatedByCodeLibelle = null;
        if ($this->collTRefTypePrestations instanceof PropelCollection) {
            $this->collTRefTypePrestations->clearIterator();
        }
        $this->collTRefTypePrestations = null;
        if ($this->collTTraductionLibelles instanceof PropelCollection) {
            $this->collTTraductionLibelles->clearIterator();
        }
        $this->collTTraductionLibelles = null;
        if ($this->collTTypeEtabsRelatedByCodeLibelle instanceof PropelCollection) {
            $this->collTTypeEtabsRelatedByCodeLibelle->clearIterator();
        }
        $this->collTTypeEtabsRelatedByCodeLibelle = null;
        if ($this->collTTypeEtabsRelatedByCodeLibelleEtab instanceof PropelCollection) {
            $this->collTTypeEtabsRelatedByCodeLibelleEtab->clearIterator();
        }
        $this->collTTypeEtabsRelatedByCodeLibelleEtab = null;
        if ($this->collTTypePrestations instanceof PropelCollection) {
            $this->collTTypePrestations->clearIterator();
        }
        $this->collTTypePrestations = null;
        if ($this->collTTypeProfils instanceof PropelCollection) {
            $this->collTTypeProfils->clearIterator();
        }
        $this->collTTypeProfils = null;
        if ($this->collTValeurReferentiels instanceof PropelCollection) {
            $this->collTValeurReferentiels->clearIterator();
        }
        $this->collTValeurReferentiels = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TTraductionPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
