<?php


/**
 * Base class that represents a row from the 'T_PROFIL' table.
 *
 *
 *
 * @package    propel.generator.RDV.om
 */
abstract class BaseTProfil extends BaseObject implements Persistent
{
    /**
     * Peer class name
     */
    const PEER = 'TProfilPeer';

    /**
     * The Peer class.
     * Instance provides a convenient way of calling static methods on a class
     * that calling code may not be able to identify.
     * @var        TProfilPeer
     */
    protected static $peer;

    /**
     * The flag var to prevent infinit loop in deep copy
     * @var       boolean
     */
    protected $startCopy = false;

    /**
     * The value for the id_profil field.
     * @var        int
     */
    protected $id_profil;

    /**
     * The value for the id_organisation field.
     * @var        int
     */
    protected $id_organisation;

    /**
     * The value for the code_libelle_profil field.
     * @var        int
     */
    protected $code_libelle_profil;

    /**
     * The value for the id_type_profil field.
     * @var        int
     */
    protected $id_type_profil;

    /**
     * The value for the organisation field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $organisation;

    /**
     * The value for the etablissement field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $etablissement;

    /**
     * The value for the referentiel_type_prestation field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $referentiel_type_prestation;

    /**
     * The value for the parametrage_prestation field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $parametrage_prestation;

    /**
     * The value for the niveau_1 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $niveau_1;

    /**
     * The value for the niveau_2 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $niveau_2;

    /**
     * The value for the niveau_3 field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $niveau_3;

    /**
     * The value for the jours_feries field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $jours_feries;

    /**
     * The value for the agenda field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $agenda;

    /**
     * The value for the jours_indisponibilites field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $jours_indisponibilites;

    /**
     * The value for the utilisateurs field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $utilisateurs;

    /**
     * The value for the profils field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $profils;

    /**
     * The value for the gestions_des_rendez_vous field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $gestions_des_rendez_vous;

    /**
     * The value for the rapport_nbr_rdv field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $rapport_nbr_rdv;

    /**
     * The value for the rapport_delai_obtention field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $rapport_delai_obtention;

    /**
     * The value for the rapport_activite field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $rapport_activite;

    /**
     * The value for the performance_globale field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $performance_globale;

    /**
     * The value for the referentiel_prestation field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $referentiel_prestation;

    /**
     * The value for the recherche_etendue_rdv field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $recherche_etendue_rdv;

    /**
     * The value for the alert_rapport_hebdo field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $alert_rapport_hebdo;

    /**
     * The value for the alert_rapport_mens field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $alert_rapport_mens;

    /**
     * The value for the modif_duree_rdv field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $modif_duree_rdv;

    /**
     * The value for the affectation_rdv field.
     * Note: this column has a database default value of: '0'
     * @var        string
     */
    protected $affectation_rdv;

    /**
     * The value for the annulation_rdv field.
     * Note: this column has a database default value of: '1'
     * @var        string
     */
    protected $annulation_rdv;

    /**
     * @var        TTraduction
     */
    protected $aTTraduction;

    /**
     * @var        TOrganisation
     */
    protected $aTOrganisation;

    /**
     * @var        TTypeProfil
     */
    protected $aTTypeProfil;

    /**
     * @var        PropelObjectCollection|TAgent[] Collection to store aggregation of TAgent objects.
     */
    protected $collTAgents;
    protected $collTAgentsPartial;

    /**
     * Flag to prevent endless save loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInSave = false;

    /**
     * Flag to prevent endless validation loop, if this object is referenced
     * by another object which falls in this transaction.
     * @var        boolean
     */
    protected $alreadyInValidation = false;

    /**
     * Flag to prevent endless clearAllReferences($deep=true) loop, if this object is referenced
     * @var        boolean
     */
    protected $alreadyInClearAllReferencesDeep = false;

    /**
     * An array of objects scheduled for deletion.
     * @var		PropelObjectCollection
     */
    protected $tAgentsScheduledForDeletion = null;

    /**
     * Applies default values to this object.
     * This method should be called from the object's constructor (or
     * equivalent initialization method).
     * @see        __construct()
     */
    public function applyDefaultValues()
    {
        $this->organisation = '0';
        $this->etablissement = '0';
        $this->referentiel_type_prestation = '0';
        $this->parametrage_prestation = '0';
        $this->niveau_1 = '0';
        $this->niveau_2 = '0';
        $this->niveau_3 = '0';
        $this->jours_feries = '0';
        $this->agenda = '0';
        $this->jours_indisponibilites = '0';
        $this->utilisateurs = '0';
        $this->profils = '0';
        $this->gestions_des_rendez_vous = '0';
        $this->rapport_nbr_rdv = '0';
        $this->rapport_delai_obtention = '0';
        $this->rapport_activite = '0';
        $this->performance_globale = '0';
        $this->referentiel_prestation = '0';
        $this->recherche_etendue_rdv = '0';
        $this->alert_rapport_hebdo = '0';
        $this->alert_rapport_mens = '0';
        $this->modif_duree_rdv = '0';
        $this->affectation_rdv = '0';
        $this->annulation_rdv = '1';
    }

    /**
     * Initializes internal state of BaseTProfil object.
     * @see        applyDefaults()
     */
    public function __construct()
    {
        parent::__construct();
        $this->applyDefaultValues();
    }

    /**
     * Get the [id_profil] column value.
     *
     * @return int
     */
    public function getIdProfil()
    {
        return $this->id_profil;
    }

    /**
     * Get the [id_organisation] column value.
     *
     * @return int
     */
    public function getIdOrganisation()
    {
        return $this->id_organisation;
    }

    /**
     * Get the [code_libelle_profil] column value.
     *
     * @return int
     */
    public function getCodeLibelleProfil()
    {
        return $this->code_libelle_profil;
    }

    /**
     * Get the [id_type_profil] column value.
     *
     * @return int
     */
    public function getIdTypeProfil()
    {
        return $this->id_type_profil;
    }

    /**
     * Get the [organisation] column value.
     *
     * @return string
     */
    public function getOrganisation()
    {
        return $this->organisation;
    }

    /**
     * Get the [etablissement] column value.
     *
     * @return string
     */
    public function getEtablissement()
    {
        return $this->etablissement;
    }

    /**
     * Get the [referentiel_type_prestation] column value.
     *
     * @return string
     */
    public function getReferentielTypePrestation()
    {
        return $this->referentiel_type_prestation;
    }

    /**
     * Get the [parametrage_prestation] column value.
     *
     * @return string
     */
    public function getParametragePrestation()
    {
        return $this->parametrage_prestation;
    }

    /**
     * Get the [niveau_1] column value.
     *
     * @return string
     */
    public function getNiveau1()
    {
        return $this->niveau_1;
    }

    /**
     * Get the [niveau_2] column value.
     *
     * @return string
     */
    public function getNiveau2()
    {
        return $this->niveau_2;
    }

    /**
     * Get the [niveau_3] column value.
     *
     * @return string
     */
    public function getNiveau3()
    {
        return $this->niveau_3;
    }

    /**
     * Get the [jours_feries] column value.
     *
     * @return string
     */
    public function getJoursFeries()
    {
        return $this->jours_feries;
    }

    /**
     * Get the [agenda] column value.
     *
     * @return string
     */
    public function getAgenda()
    {
        return $this->agenda;
    }

    /**
     * Get the [jours_indisponibilites] column value.
     *
     * @return string
     */
    public function getJoursIndisponibilites()
    {
        return $this->jours_indisponibilites;
    }

    /**
     * Get the [utilisateurs] column value.
     *
     * @return string
     */
    public function getUtilisateurs()
    {
        return $this->utilisateurs;
    }

    /**
     * Get the [profils] column value.
     *
     * @return string
     */
    public function getProfils()
    {
        return $this->profils;
    }

    /**
     * Get the [gestions_des_rendez_vous] column value.
     *
     * @return string
     */
    public function getGestionsDesRendezVous()
    {
        return $this->gestions_des_rendez_vous;
    }

    /**
     * Get the [rapport_nbr_rdv] column value.
     *
     * @return string
     */
    public function getRapportNbrRdv()
    {
        return $this->rapport_nbr_rdv;
    }

    /**
     * Get the [rapport_delai_obtention] column value.
     *
     * @return string
     */
    public function getRapportDelaiObtention()
    {
        return $this->rapport_delai_obtention;
    }

    /**
     * Get the [rapport_activite] column value.
     *
     * @return string
     */
    public function getRapportActivite()
    {
        return $this->rapport_activite;
    }

    /**
     * Get the [performance_globale] column value.
     *
     * @return string
     */
    public function getPerformanceGlobale()
    {
        return $this->performance_globale;
    }

    /**
     * Get the [referentiel_prestation] column value.
     *
     * @return string
     */
    public function getReferentielPrestation()
    {
        return $this->referentiel_prestation;
    }

    /**
     * Get the [recherche_etendue_rdv] column value.
     *
     * @return string
     */
    public function getRechercheEtendueRdv()
    {
        return $this->recherche_etendue_rdv;
    }

    /**
     * Get the [alert_rapport_hebdo] column value.
     *
     * @return string
     */
    public function getAlertRapportHebdo()
    {
        return $this->alert_rapport_hebdo;
    }

    /**
     * Get the [alert_rapport_mens] column value.
     *
     * @return string
     */
    public function getAlertRapportMens()
    {
        return $this->alert_rapport_mens;
    }

    /**
     * Get the [modif_duree_rdv] column value.
     *
     * @return string
     */
    public function getModifDureeRdv()
    {
        return $this->modif_duree_rdv;
    }

    /**
     * Get the [affectation_rdv] column value.
     *
     * @return string
     */
    public function getAffectationRdv()
    {
        return $this->affectation_rdv;
    }

    /**
     * Get the [annulation_rdv] column value.
     *
     * @return string
     */
    public function getAnnulationRdv()
    {
        return $this->annulation_rdv;
    }

    /**
     * Set the value of [id_profil] column.
     *
     * @param int $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setIdProfil($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_profil !== $v) {
            $this->id_profil = $v;
            $this->modifiedColumns[] = TProfilPeer::ID_PROFIL;
        }


        return $this;
    } // setIdProfil()

    /**
     * Set the value of [id_organisation] column.
     *
     * @param int $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setIdOrganisation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_organisation !== $v) {
            $this->id_organisation = $v;
            $this->modifiedColumns[] = TProfilPeer::ID_ORGANISATION;
        }

        if ($this->aTOrganisation !== null && $this->aTOrganisation->getIdOrganisation() !== $v) {
            $this->aTOrganisation = null;
        }


        return $this;
    } // setIdOrganisation()

    /**
     * Set the value of [code_libelle_profil] column.
     *
     * @param int $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setCodeLibelleProfil($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->code_libelle_profil !== $v) {
            $this->code_libelle_profil = $v;
            $this->modifiedColumns[] = TProfilPeer::CODE_LIBELLE_PROFIL;
        }

        if ($this->aTTraduction !== null && $this->aTTraduction->getIdTraduction() !== $v) {
            $this->aTTraduction = null;
        }


        return $this;
    } // setCodeLibelleProfil()

    /**
     * Set the value of [id_type_profil] column.
     *
     * @param int $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setIdTypeProfil($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (int) $v;
        }

        if ($this->id_type_profil !== $v) {
            $this->id_type_profil = $v;
            $this->modifiedColumns[] = TProfilPeer::ID_TYPE_PROFIL;
        }

        if ($this->aTTypeProfil !== null && $this->aTTypeProfil->getIdTypeProfil() !== $v) {
            $this->aTTypeProfil = null;
        }


        return $this;
    } // setIdTypeProfil()

    /**
     * Set the value of [organisation] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setOrganisation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->organisation !== $v) {
            $this->organisation = $v;
            $this->modifiedColumns[] = TProfilPeer::ORGANISATION;
        }


        return $this;
    } // setOrganisation()

    /**
     * Set the value of [etablissement] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setEtablissement($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->etablissement !== $v) {
            $this->etablissement = $v;
            $this->modifiedColumns[] = TProfilPeer::ETABLISSEMENT;
        }


        return $this;
    } // setEtablissement()

    /**
     * Set the value of [referentiel_type_prestation] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setReferentielTypePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->referentiel_type_prestation !== $v) {
            $this->referentiel_type_prestation = $v;
            $this->modifiedColumns[] = TProfilPeer::REFERENTIEL_TYPE_PRESTATION;
        }


        return $this;
    } // setReferentielTypePrestation()

    /**
     * Set the value of [parametrage_prestation] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setParametragePrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->parametrage_prestation !== $v) {
            $this->parametrage_prestation = $v;
            $this->modifiedColumns[] = TProfilPeer::PARAMETRAGE_PRESTATION;
        }


        return $this;
    } // setParametragePrestation()

    /**
     * Set the value of [niveau_1] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setNiveau1($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->niveau_1 !== $v) {
            $this->niveau_1 = $v;
            $this->modifiedColumns[] = TProfilPeer::NIVEAU_1;
        }


        return $this;
    } // setNiveau1()

    /**
     * Set the value of [niveau_2] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setNiveau2($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->niveau_2 !== $v) {
            $this->niveau_2 = $v;
            $this->modifiedColumns[] = TProfilPeer::NIVEAU_2;
        }


        return $this;
    } // setNiveau2()

    /**
     * Set the value of [niveau_3] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setNiveau3($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->niveau_3 !== $v) {
            $this->niveau_3 = $v;
            $this->modifiedColumns[] = TProfilPeer::NIVEAU_3;
        }


        return $this;
    } // setNiveau3()

    /**
     * Set the value of [jours_feries] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setJoursFeries($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->jours_feries !== $v) {
            $this->jours_feries = $v;
            $this->modifiedColumns[] = TProfilPeer::JOURS_FERIES;
        }


        return $this;
    } // setJoursFeries()

    /**
     * Set the value of [agenda] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setAgenda($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->agenda !== $v) {
            $this->agenda = $v;
            $this->modifiedColumns[] = TProfilPeer::AGENDA;
        }


        return $this;
    } // setAgenda()

    /**
     * Set the value of [jours_indisponibilites] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setJoursIndisponibilites($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->jours_indisponibilites !== $v) {
            $this->jours_indisponibilites = $v;
            $this->modifiedColumns[] = TProfilPeer::JOURS_INDISPONIBILITES;
        }


        return $this;
    } // setJoursIndisponibilites()

    /**
     * Set the value of [utilisateurs] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setUtilisateurs($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->utilisateurs !== $v) {
            $this->utilisateurs = $v;
            $this->modifiedColumns[] = TProfilPeer::UTILISATEURS;
        }


        return $this;
    } // setUtilisateurs()

    /**
     * Set the value of [profils] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setProfils($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->profils !== $v) {
            $this->profils = $v;
            $this->modifiedColumns[] = TProfilPeer::PROFILS;
        }


        return $this;
    } // setProfils()

    /**
     * Set the value of [gestions_des_rendez_vous] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setGestionsDesRendezVous($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->gestions_des_rendez_vous !== $v) {
            $this->gestions_des_rendez_vous = $v;
            $this->modifiedColumns[] = TProfilPeer::GESTIONS_DES_RENDEZ_VOUS;
        }


        return $this;
    } // setGestionsDesRendezVous()

    /**
     * Set the value of [rapport_nbr_rdv] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setRapportNbrRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->rapport_nbr_rdv !== $v) {
            $this->rapport_nbr_rdv = $v;
            $this->modifiedColumns[] = TProfilPeer::RAPPORT_NBR_RDV;
        }


        return $this;
    } // setRapportNbrRdv()

    /**
     * Set the value of [rapport_delai_obtention] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setRapportDelaiObtention($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->rapport_delai_obtention !== $v) {
            $this->rapport_delai_obtention = $v;
            $this->modifiedColumns[] = TProfilPeer::RAPPORT_DELAI_OBTENTION;
        }


        return $this;
    } // setRapportDelaiObtention()

    /**
     * Set the value of [rapport_activite] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setRapportActivite($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->rapport_activite !== $v) {
            $this->rapport_activite = $v;
            $this->modifiedColumns[] = TProfilPeer::RAPPORT_ACTIVITE;
        }


        return $this;
    } // setRapportActivite()

    /**
     * Set the value of [performance_globale] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setPerformanceGlobale($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->performance_globale !== $v) {
            $this->performance_globale = $v;
            $this->modifiedColumns[] = TProfilPeer::PERFORMANCE_GLOBALE;
        }


        return $this;
    } // setPerformanceGlobale()

    /**
     * Set the value of [referentiel_prestation] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setReferentielPrestation($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->referentiel_prestation !== $v) {
            $this->referentiel_prestation = $v;
            $this->modifiedColumns[] = TProfilPeer::REFERENTIEL_PRESTATION;
        }


        return $this;
    } // setReferentielPrestation()

    /**
     * Set the value of [recherche_etendue_rdv] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setRechercheEtendueRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->recherche_etendue_rdv !== $v) {
            $this->recherche_etendue_rdv = $v;
            $this->modifiedColumns[] = TProfilPeer::RECHERCHE_ETENDUE_RDV;
        }


        return $this;
    } // setRechercheEtendueRdv()

    /**
     * Set the value of [alert_rapport_hebdo] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setAlertRapportHebdo($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->alert_rapport_hebdo !== $v) {
            $this->alert_rapport_hebdo = $v;
            $this->modifiedColumns[] = TProfilPeer::ALERT_RAPPORT_HEBDO;
        }


        return $this;
    } // setAlertRapportHebdo()

    /**
     * Set the value of [alert_rapport_mens] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setAlertRapportMens($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->alert_rapport_mens !== $v) {
            $this->alert_rapport_mens = $v;
            $this->modifiedColumns[] = TProfilPeer::ALERT_RAPPORT_MENS;
        }


        return $this;
    } // setAlertRapportMens()

    /**
     * Set the value of [modif_duree_rdv] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setModifDureeRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->modif_duree_rdv !== $v) {
            $this->modif_duree_rdv = $v;
            $this->modifiedColumns[] = TProfilPeer::MODIF_DUREE_RDV;
        }


        return $this;
    } // setModifDureeRdv()

    /**
     * Set the value of [affectation_rdv] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setAffectationRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->affectation_rdv !== $v) {
            $this->affectation_rdv = $v;
            $this->modifiedColumns[] = TProfilPeer::AFFECTATION_RDV;
        }


        return $this;
    } // setAffectationRdv()

    /**
     * Set the value of [annulation_rdv] column.
     *
     * @param string $v new value
     * @return TProfil The current object (for fluent API support)
     */
    public function setAnnulationRdv($v)
    {
        if ($v !== null && is_numeric($v)) {
            $v = (string) $v;
        }

        if ($this->annulation_rdv !== $v) {
            $this->annulation_rdv = $v;
            $this->modifiedColumns[] = TProfilPeer::ANNULATION_RDV;
        }


        return $this;
    } // setAnnulationRdv()

    /**
     * Indicates whether the columns in this object are only set to default values.
     *
     * This method can be used in conjunction with isModified() to indicate whether an object is both
     * modified _and_ has some values set which are non-default.
     *
     * @return boolean Whether the columns in this object are only been set with default values.
     */
    public function hasOnlyDefaultValues()
    {
            if ($this->organisation !== '0') {
                return false;
            }

            if ($this->etablissement !== '0') {
                return false;
            }

            if ($this->referentiel_type_prestation !== '0') {
                return false;
            }

            if ($this->parametrage_prestation !== '0') {
                return false;
            }

            if ($this->niveau_1 !== '0') {
                return false;
            }

            if ($this->niveau_2 !== '0') {
                return false;
            }

            if ($this->niveau_3 !== '0') {
                return false;
            }

            if ($this->jours_feries !== '0') {
                return false;
            }

            if ($this->agenda !== '0') {
                return false;
            }

            if ($this->jours_indisponibilites !== '0') {
                return false;
            }

            if ($this->utilisateurs !== '0') {
                return false;
            }

            if ($this->profils !== '0') {
                return false;
            }

            if ($this->gestions_des_rendez_vous !== '0') {
                return false;
            }

            if ($this->rapport_nbr_rdv !== '0') {
                return false;
            }

            if ($this->rapport_delai_obtention !== '0') {
                return false;
            }

            if ($this->rapport_activite !== '0') {
                return false;
            }

            if ($this->performance_globale !== '0') {
                return false;
            }

            if ($this->referentiel_prestation !== '0') {
                return false;
            }

            if ($this->recherche_etendue_rdv !== '0') {
                return false;
            }

            if ($this->alert_rapport_hebdo !== '0') {
                return false;
            }

            if ($this->alert_rapport_mens !== '0') {
                return false;
            }

            if ($this->modif_duree_rdv !== '0') {
                return false;
            }

            if ($this->affectation_rdv !== '0') {
                return false;
            }

            if ($this->annulation_rdv !== '1') {
                return false;
            }

        // otherwise, everything was equal, so return true
        return true;
    } // hasOnlyDefaultValues()

    /**
     * Hydrates (populates) the object variables with values from the database resultset.
     *
     * An offset (0-based "start column") is specified so that objects can be hydrated
     * with a subset of the columns in the resultset rows.  This is needed, for example,
     * for results of JOIN queries where the resultset row includes columns from two or
     * more tables.
     *
     * @param array $row The row returned by PDOStatement->fetch(PDO::FETCH_NUM)
     * @param int $startcol 0-based offset column which indicates which restultset column to start with.
     * @param boolean $rehydrate Whether this object is being re-hydrated from the database.
     * @return int             next starting column
     * @throws PropelException - Any caught Exception will be rewrapped as a PropelException.
     */
    public function hydrate($row, $startcol = 0, $rehydrate = false)
    {
        try {

            $this->id_profil = ($row[$startcol + 0] !== null) ? (int) $row[$startcol + 0] : null;
            $this->id_organisation = ($row[$startcol + 1] !== null) ? (int) $row[$startcol + 1] : null;
            $this->code_libelle_profil = ($row[$startcol + 2] !== null) ? (int) $row[$startcol + 2] : null;
            $this->id_type_profil = ($row[$startcol + 3] !== null) ? (int) $row[$startcol + 3] : null;
            $this->organisation = ($row[$startcol + 4] !== null) ? (string) $row[$startcol + 4] : null;
            $this->etablissement = ($row[$startcol + 5] !== null) ? (string) $row[$startcol + 5] : null;
            $this->referentiel_type_prestation = ($row[$startcol + 6] !== null) ? (string) $row[$startcol + 6] : null;
            $this->parametrage_prestation = ($row[$startcol + 7] !== null) ? (string) $row[$startcol + 7] : null;
            $this->niveau_1 = ($row[$startcol + 8] !== null) ? (string) $row[$startcol + 8] : null;
            $this->niveau_2 = ($row[$startcol + 9] !== null) ? (string) $row[$startcol + 9] : null;
            $this->niveau_3 = ($row[$startcol + 10] !== null) ? (string) $row[$startcol + 10] : null;
            $this->jours_feries = ($row[$startcol + 11] !== null) ? (string) $row[$startcol + 11] : null;
            $this->agenda = ($row[$startcol + 12] !== null) ? (string) $row[$startcol + 12] : null;
            $this->jours_indisponibilites = ($row[$startcol + 13] !== null) ? (string) $row[$startcol + 13] : null;
            $this->utilisateurs = ($row[$startcol + 14] !== null) ? (string) $row[$startcol + 14] : null;
            $this->profils = ($row[$startcol + 15] !== null) ? (string) $row[$startcol + 15] : null;
            $this->gestions_des_rendez_vous = ($row[$startcol + 16] !== null) ? (string) $row[$startcol + 16] : null;
            $this->rapport_nbr_rdv = ($row[$startcol + 17] !== null) ? (string) $row[$startcol + 17] : null;
            $this->rapport_delai_obtention = ($row[$startcol + 18] !== null) ? (string) $row[$startcol + 18] : null;
            $this->rapport_activite = ($row[$startcol + 19] !== null) ? (string) $row[$startcol + 19] : null;
            $this->performance_globale = ($row[$startcol + 20] !== null) ? (string) $row[$startcol + 20] : null;
            $this->referentiel_prestation = ($row[$startcol + 21] !== null) ? (string) $row[$startcol + 21] : null;
            $this->recherche_etendue_rdv = ($row[$startcol + 22] !== null) ? (string) $row[$startcol + 22] : null;
            $this->alert_rapport_hebdo = ($row[$startcol + 23] !== null) ? (string) $row[$startcol + 23] : null;
            $this->alert_rapport_mens = ($row[$startcol + 24] !== null) ? (string) $row[$startcol + 24] : null;
            $this->modif_duree_rdv = ($row[$startcol + 25] !== null) ? (string) $row[$startcol + 25] : null;
            $this->affectation_rdv = ($row[$startcol + 26] !== null) ? (string) $row[$startcol + 26] : null;
            $this->annulation_rdv = ($row[$startcol + 27] !== null) ? (string) $row[$startcol + 27] : null;
            $this->resetModified();

            $this->setNew(false);

            if ($rehydrate) {
                $this->ensureConsistency();
            }
            $this->postHydrate($row, $startcol, $rehydrate);
            return $startcol + 28; // 28 = TProfilPeer::NUM_HYDRATE_COLUMNS.

        } catch (Exception $e) {
            throw new PropelException("Error populating TProfil object", $e);
        }
    }

    /**
     * Checks and repairs the internal consistency of the object.
     *
     * This method is executed after an already-instantiated object is re-hydrated
     * from the database.  It exists to check any foreign keys to make sure that
     * the objects related to the current object are correct based on foreign key.
     *
     * You can override this method in the stub class, but you should always invoke
     * the base method from the overridden method (i.e. parent::ensureConsistency()),
     * in case your model changes.
     *
     * @throws PropelException
     */
    public function ensureConsistency()
    {

        if ($this->aTOrganisation !== null && $this->id_organisation !== $this->aTOrganisation->getIdOrganisation()) {
            $this->aTOrganisation = null;
        }
        if ($this->aTTraduction !== null && $this->code_libelle_profil !== $this->aTTraduction->getIdTraduction()) {
            $this->aTTraduction = null;
        }
        if ($this->aTTypeProfil !== null && $this->id_type_profil !== $this->aTTypeProfil->getIdTypeProfil()) {
            $this->aTTypeProfil = null;
        }
    } // ensureConsistency

    /**
     * Reloads this object from datastore based on primary key and (optionally) resets all associated objects.
     *
     * This will only work if the object has been saved and has a valid primary key set.
     *
     * @param boolean $deep (optional) Whether to also de-associated any related objects.
     * @param PropelPDO $con (optional) The PropelPDO connection to use.
     * @return void
     * @throws PropelException - if this object is deleted, unsaved or doesn't have pk match in db
     */
    public function reload($deep = false, PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("Cannot reload a deleted object.");
        }

        if ($this->isNew()) {
            throw new PropelException("Cannot reload an unsaved object.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_READ);
        }

        // We don't need to alter the object instance pool; we're just modifying this instance
        // already in the pool.

        $stmt = TProfilPeer::doSelectStmt($this->buildPkeyCriteria(), $con);
        $row = $stmt->fetch(PDO::FETCH_NUM);
        $stmt->closeCursor();
        if (!$row) {
            throw new PropelException('Cannot find matching row in the database to reload object values.');
        }
        $this->hydrate($row, 0, true); // rehydrate

        if ($deep) {  // also de-associate any related objects?

            $this->aTTraduction = null;
            $this->aTOrganisation = null;
            $this->aTTypeProfil = null;
            $this->collTAgents = null;

        } // if (deep)
    }

    /**
     * Removes this object from datastore and sets delete attribute.
     *
     * @param PropelPDO $con
     * @return void
     * @throws PropelException
     * @throws Exception
     * @see        BaseObject::setDeleted()
     * @see        BaseObject::isDeleted()
     */
    public function delete(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("This object has already been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        try {
            $deleteQuery = TProfilQuery::create()
                ->filterByPrimaryKey($this->getPrimaryKey());
            $ret = $this->preDelete($con);
            if ($ret) {
                $deleteQuery->delete($con);
                $this->postDelete($con);
                $con->commit();
                $this->setDeleted(true);
            } else {
                $con->commit();
            }
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Persists this object to the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All modified related objects will also be persisted in the doSave()
     * method.  This method wraps all precipitate database operations in a
     * single transaction.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @throws Exception
     * @see        doSave()
     */
    public function save(PropelPDO $con = null)
    {
        if ($this->isDeleted()) {
            throw new PropelException("You cannot save an object that has been deleted.");
        }

        if ($con === null) {
            $con = Propel::getConnection(TProfilPeer::DATABASE_NAME, Propel::CONNECTION_WRITE);
        }

        $con->beginTransaction();
        $isInsert = $this->isNew();
        try {
            $ret = $this->preSave($con);
            if ($isInsert) {
                $ret = $ret && $this->preInsert($con);
            } else {
                $ret = $ret && $this->preUpdate($con);
            }
            if ($ret) {
                $affectedRows = $this->doSave($con);
                if ($isInsert) {
                    $this->postInsert($con);
                } else {
                    $this->postUpdate($con);
                }
                $this->postSave($con);
                TProfilPeer::addInstanceToPool($this);
            } else {
                $affectedRows = 0;
            }
            $con->commit();

            return $affectedRows;
        } catch (Exception $e) {
            $con->rollBack();
            throw $e;
        }
    }

    /**
     * Performs the work of inserting or updating the row in the database.
     *
     * If the object is new, it inserts it; otherwise an update is performed.
     * All related objects are also updated in this method.
     *
     * @param PropelPDO $con
     * @return int             The number of rows affected by this insert/update and any referring fk objects' save() operations.
     * @throws PropelException
     * @see        save()
     */
    protected function doSave(PropelPDO $con)
    {
        $affectedRows = 0; // initialize var to track total num of affected rows
        if (!$this->alreadyInSave) {
            $this->alreadyInSave = true;

            // We call the save method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if ($this->aTTraduction->isModified() || $this->aTTraduction->isNew()) {
                    $affectedRows += $this->aTTraduction->save($con);
                }
                $this->setTTraduction($this->aTTraduction);
            }

            if ($this->aTOrganisation !== null) {
                if ($this->aTOrganisation->isModified() || $this->aTOrganisation->isNew()) {
                    $affectedRows += $this->aTOrganisation->save($con);
                }
                $this->setTOrganisation($this->aTOrganisation);
            }

            if ($this->aTTypeProfil !== null) {
                if ($this->aTTypeProfil->isModified() || $this->aTTypeProfil->isNew()) {
                    $affectedRows += $this->aTTypeProfil->save($con);
                }
                $this->setTTypeProfil($this->aTTypeProfil);
            }

            if ($this->isNew() || $this->isModified()) {
                // persist changes
                if ($this->isNew()) {
                    $this->doInsert($con);
                } else {
                    $this->doUpdate($con);
                }
                $affectedRows += 1;
                $this->resetModified();
            }

            if ($this->tAgentsScheduledForDeletion !== null) {
                if (!$this->tAgentsScheduledForDeletion->isEmpty()) {
                    foreach ($this->tAgentsScheduledForDeletion as $tAgent) {
                        // need to save related object because we set the relation to null
                        $tAgent->save($con);
                    }
                    $this->tAgentsScheduledForDeletion = null;
                }
            }

            if ($this->collTAgents !== null) {
                foreach ($this->collTAgents as $referrerFK) {
                    if (!$referrerFK->isDeleted() && ($referrerFK->isNew() || $referrerFK->isModified())) {
                        $affectedRows += $referrerFK->save($con);
                    }
                }
            }

            $this->alreadyInSave = false;

        }

        return $affectedRows;
    } // doSave()

    /**
     * Insert the row in the database.
     *
     * @param PropelPDO $con
     *
     * @throws PropelException
     * @see        doSave()
     */
    protected function doInsert(PropelPDO $con)
    {
        $modifiedColumns = array();
        $index = 0;

        $this->modifiedColumns[] = TProfilPeer::ID_PROFIL;
        if (null !== $this->id_profil) {
            throw new PropelException('Cannot insert a value for auto-increment primary key (' . TProfilPeer::ID_PROFIL . ')');
        }

         // check the columns in natural order for more readable SQL queries
        if ($this->isColumnModified(TProfilPeer::ID_PROFIL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_PROFIL`';
        }
        if ($this->isColumnModified(TProfilPeer::ID_ORGANISATION)) {
            $modifiedColumns[':p' . $index++]  = '`ID_ORGANISATION`';
        }
        if ($this->isColumnModified(TProfilPeer::CODE_LIBELLE_PROFIL)) {
            $modifiedColumns[':p' . $index++]  = '`CODE_LIBELLE_PROFIL`';
        }
        if ($this->isColumnModified(TProfilPeer::ID_TYPE_PROFIL)) {
            $modifiedColumns[':p' . $index++]  = '`ID_TYPE_PROFIL`';
        }
        if ($this->isColumnModified(TProfilPeer::ORGANISATION)) {
            $modifiedColumns[':p' . $index++]  = '`ORGANISATION`';
        }
        if ($this->isColumnModified(TProfilPeer::ETABLISSEMENT)) {
            $modifiedColumns[':p' . $index++]  = '`ETABLISSEMENT`';
        }
        if ($this->isColumnModified(TProfilPeer::REFERENTIEL_TYPE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`REFERENTIEL_TYPE_PRESTATION`';
        }
        if ($this->isColumnModified(TProfilPeer::PARAMETRAGE_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`PARAMETRAGE_PRESTATION`';
        }
        if ($this->isColumnModified(TProfilPeer::NIVEAU_1)) {
            $modifiedColumns[':p' . $index++]  = '`NIVEAU_1`';
        }
        if ($this->isColumnModified(TProfilPeer::NIVEAU_2)) {
            $modifiedColumns[':p' . $index++]  = '`NIVEAU_2`';
        }
        if ($this->isColumnModified(TProfilPeer::NIVEAU_3)) {
            $modifiedColumns[':p' . $index++]  = '`NIVEAU_3`';
        }
        if ($this->isColumnModified(TProfilPeer::JOURS_FERIES)) {
            $modifiedColumns[':p' . $index++]  = '`JOURS_FERIES`';
        }
        if ($this->isColumnModified(TProfilPeer::AGENDA)) {
            $modifiedColumns[':p' . $index++]  = '`AGENDA`';
        }
        if ($this->isColumnModified(TProfilPeer::JOURS_INDISPONIBILITES)) {
            $modifiedColumns[':p' . $index++]  = '`JOURS_INDISPONIBILITES`';
        }
        if ($this->isColumnModified(TProfilPeer::UTILISATEURS)) {
            $modifiedColumns[':p' . $index++]  = '`UTILISATEURS`';
        }
        if ($this->isColumnModified(TProfilPeer::PROFILS)) {
            $modifiedColumns[':p' . $index++]  = '`PROFILS`';
        }
        if ($this->isColumnModified(TProfilPeer::GESTIONS_DES_RENDEZ_VOUS)) {
            $modifiedColumns[':p' . $index++]  = '`GESTIONS_DES_RENDEZ_VOUS`';
        }
        if ($this->isColumnModified(TProfilPeer::RAPPORT_NBR_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`RAPPORT_NBR_RDV`';
        }
        if ($this->isColumnModified(TProfilPeer::RAPPORT_DELAI_OBTENTION)) {
            $modifiedColumns[':p' . $index++]  = '`RAPPORT_DELAI_OBTENTION`';
        }
        if ($this->isColumnModified(TProfilPeer::RAPPORT_ACTIVITE)) {
            $modifiedColumns[':p' . $index++]  = '`RAPPORT_ACTIVITE`';
        }
        if ($this->isColumnModified(TProfilPeer::PERFORMANCE_GLOBALE)) {
            $modifiedColumns[':p' . $index++]  = '`PERFORMANCE_GLOBALE`';
        }
        if ($this->isColumnModified(TProfilPeer::REFERENTIEL_PRESTATION)) {
            $modifiedColumns[':p' . $index++]  = '`REFERENTIEL_PRESTATION`';
        }
        if ($this->isColumnModified(TProfilPeer::RECHERCHE_ETENDUE_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`RECHERCHE_ETENDUE_RDV`';
        }
        if ($this->isColumnModified(TProfilPeer::ALERT_RAPPORT_HEBDO)) {
            $modifiedColumns[':p' . $index++]  = '`ALERT_RAPPORT_HEBDO`';
        }
        if ($this->isColumnModified(TProfilPeer::ALERT_RAPPORT_MENS)) {
            $modifiedColumns[':p' . $index++]  = '`ALERT_RAPPORT_MENS`';
        }
        if ($this->isColumnModified(TProfilPeer::MODIF_DUREE_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`MODIF_DUREE_RDV`';
        }
        if ($this->isColumnModified(TProfilPeer::AFFECTATION_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`AFFECTATION_RDV`';
        }
        if ($this->isColumnModified(TProfilPeer::ANNULATION_RDV)) {
            $modifiedColumns[':p' . $index++]  = '`ANNULATION_RDV`';
        }

        $sql = sprintf(
            'INSERT INTO `T_PROFIL` (%s) VALUES (%s)',
            implode(', ', $modifiedColumns),
            implode(', ', array_keys($modifiedColumns))
        );

        try {
            $stmt = $con->prepare($sql);
            foreach ($modifiedColumns as $identifier => $columnName) {
                switch ($columnName) {
                    case '`ID_PROFIL`':
                        $stmt->bindValue($identifier, $this->id_profil, PDO::PARAM_INT);
                        break;
                    case '`ID_ORGANISATION`':
                        $stmt->bindValue($identifier, $this->id_organisation, PDO::PARAM_INT);
                        break;
                    case '`CODE_LIBELLE_PROFIL`':
                        $stmt->bindValue($identifier, $this->code_libelle_profil, PDO::PARAM_INT);
                        break;
                    case '`ID_TYPE_PROFIL`':
                        $stmt->bindValue($identifier, $this->id_type_profil, PDO::PARAM_INT);
                        break;
                    case '`ORGANISATION`':
                        $stmt->bindValue($identifier, $this->organisation, PDO::PARAM_STR);
                        break;
                    case '`ETABLISSEMENT`':
                        $stmt->bindValue($identifier, $this->etablissement, PDO::PARAM_STR);
                        break;
                    case '`REFERENTIEL_TYPE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->referentiel_type_prestation, PDO::PARAM_STR);
                        break;
                    case '`PARAMETRAGE_PRESTATION`':
                        $stmt->bindValue($identifier, $this->parametrage_prestation, PDO::PARAM_STR);
                        break;
                    case '`NIVEAU_1`':
                        $stmt->bindValue($identifier, $this->niveau_1, PDO::PARAM_STR);
                        break;
                    case '`NIVEAU_2`':
                        $stmt->bindValue($identifier, $this->niveau_2, PDO::PARAM_STR);
                        break;
                    case '`NIVEAU_3`':
                        $stmt->bindValue($identifier, $this->niveau_3, PDO::PARAM_STR);
                        break;
                    case '`JOURS_FERIES`':
                        $stmt->bindValue($identifier, $this->jours_feries, PDO::PARAM_STR);
                        break;
                    case '`AGENDA`':
                        $stmt->bindValue($identifier, $this->agenda, PDO::PARAM_STR);
                        break;
                    case '`JOURS_INDISPONIBILITES`':
                        $stmt->bindValue($identifier, $this->jours_indisponibilites, PDO::PARAM_STR);
                        break;
                    case '`UTILISATEURS`':
                        $stmt->bindValue($identifier, $this->utilisateurs, PDO::PARAM_STR);
                        break;
                    case '`PROFILS`':
                        $stmt->bindValue($identifier, $this->profils, PDO::PARAM_STR);
                        break;
                    case '`GESTIONS_DES_RENDEZ_VOUS`':
                        $stmt->bindValue($identifier, $this->gestions_des_rendez_vous, PDO::PARAM_STR);
                        break;
                    case '`RAPPORT_NBR_RDV`':
                        $stmt->bindValue($identifier, $this->rapport_nbr_rdv, PDO::PARAM_STR);
                        break;
                    case '`RAPPORT_DELAI_OBTENTION`':
                        $stmt->bindValue($identifier, $this->rapport_delai_obtention, PDO::PARAM_STR);
                        break;
                    case '`RAPPORT_ACTIVITE`':
                        $stmt->bindValue($identifier, $this->rapport_activite, PDO::PARAM_STR);
                        break;
                    case '`PERFORMANCE_GLOBALE`':
                        $stmt->bindValue($identifier, $this->performance_globale, PDO::PARAM_STR);
                        break;
                    case '`REFERENTIEL_PRESTATION`':
                        $stmt->bindValue($identifier, $this->referentiel_prestation, PDO::PARAM_STR);
                        break;
                    case '`RECHERCHE_ETENDUE_RDV`':
                        $stmt->bindValue($identifier, $this->recherche_etendue_rdv, PDO::PARAM_STR);
                        break;
                    case '`ALERT_RAPPORT_HEBDO`':
                        $stmt->bindValue($identifier, $this->alert_rapport_hebdo, PDO::PARAM_STR);
                        break;
                    case '`ALERT_RAPPORT_MENS`':
                        $stmt->bindValue($identifier, $this->alert_rapport_mens, PDO::PARAM_STR);
                        break;
                    case '`MODIF_DUREE_RDV`':
                        $stmt->bindValue($identifier, $this->modif_duree_rdv, PDO::PARAM_STR);
                        break;
                    case '`AFFECTATION_RDV`':
                        $stmt->bindValue($identifier, $this->affectation_rdv, PDO::PARAM_STR);
                        break;
                    case '`ANNULATION_RDV`':
                        $stmt->bindValue($identifier, $this->annulation_rdv, PDO::PARAM_STR);
                        break;
                }
            }
            $stmt->execute();
        } catch (Exception $e) {
            Propel::log($e->getMessage(), Propel::LOG_ERR);
            throw new PropelException(sprintf('Unable to execute INSERT statement [%s]', $sql), $e);
        }

        try {
            $pk = $con->lastInsertId();
        } catch (Exception $e) {
            throw new PropelException('Unable to get autoincrement id.', $e);
        }
        $this->setIdProfil($pk);

        $this->setNew(false);
    }

    /**
     * Update the row in the database.
     *
     * @param PropelPDO $con
     *
     * @see        doSave()
     */
    protected function doUpdate(PropelPDO $con)
    {
        $selectCriteria = $this->buildPkeyCriteria();
        $valuesCriteria = $this->buildCriteria();
        BasePeer::doUpdate($selectCriteria, $valuesCriteria, $con);
    }

    /**
     * Array of ValidationFailed objects.
     * @var        array ValidationFailed[]
     */
    protected $validationFailures = array();

    /**
     * Gets any ValidationFailed objects that resulted from last call to validate().
     *
     *
     * @return array ValidationFailed[]
     * @see        validate()
     */
    public function getValidationFailures()
    {
        return $this->validationFailures;
    }

    /**
     * Validates the objects modified field values and all objects related to this table.
     *
     * If $columns is either a column name or an array of column names
     * only those columns are validated.
     *
     * @param mixed $columns Column name or an array of column names.
     * @return boolean Whether all columns pass validation.
     * @see        doValidate()
     * @see        getValidationFailures()
     */
    public function validate($columns = null)
    {
        $res = $this->doValidate($columns);
        if ($res === true) {
            $this->validationFailures = array();

            return true;
        }

        $this->validationFailures = $res;

        return false;
    }

    /**
     * This function performs the validation work for complex object models.
     *
     * In addition to checking the current object, all related objects will
     * also be validated.  If all pass then <code>true</code> is returned; otherwise
     * an aggreagated array of ValidationFailed objects will be returned.
     *
     * @param array $columns Array of column names to validate.
     * @return mixed <code>true</code> if all validations pass; array of <code>ValidationFailed</code> objets otherwise.
     */
    protected function doValidate($columns = null)
    {
        if (!$this->alreadyInValidation) {
            $this->alreadyInValidation = true;
            $retval = null;

            $failureMap = array();


            // We call the validate method on the following object(s) if they
            // were passed to this object by their coresponding set
            // method.  This object relates to these object(s) by a
            // foreign key reference.

            if ($this->aTTraduction !== null) {
                if (!$this->aTTraduction->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTraduction->getValidationFailures());
                }
            }

            if ($this->aTOrganisation !== null) {
                if (!$this->aTOrganisation->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTOrganisation->getValidationFailures());
                }
            }

            if ($this->aTTypeProfil !== null) {
                if (!$this->aTTypeProfil->validate($columns)) {
                    $failureMap = array_merge($failureMap, $this->aTTypeProfil->getValidationFailures());
                }
            }


            if (($retval = TProfilPeer::doValidate($this, $columns)) !== true) {
                $failureMap = array_merge($failureMap, $retval);
            }


                if ($this->collTAgents !== null) {
                    foreach ($this->collTAgents as $referrerFK) {
                        if (!$referrerFK->validate($columns)) {
                            $failureMap = array_merge($failureMap, $referrerFK->getValidationFailures());
                        }
                    }
                }


            $this->alreadyInValidation = false;
        }

        return (!empty($failureMap) ? $failureMap : true);
    }

    /**
     * Build a Criteria object containing the values of all modified columns in this object.
     *
     * @return Criteria The Criteria object containing all modified values.
     */
    public function buildCriteria()
    {
        $criteria = new Criteria(TProfilPeer::DATABASE_NAME);

        if ($this->isColumnModified(TProfilPeer::ID_PROFIL)) $criteria->add(TProfilPeer::ID_PROFIL, $this->id_profil);
        if ($this->isColumnModified(TProfilPeer::ID_ORGANISATION)) $criteria->add(TProfilPeer::ID_ORGANISATION, $this->id_organisation);
        if ($this->isColumnModified(TProfilPeer::CODE_LIBELLE_PROFIL)) $criteria->add(TProfilPeer::CODE_LIBELLE_PROFIL, $this->code_libelle_profil);
        if ($this->isColumnModified(TProfilPeer::ID_TYPE_PROFIL)) $criteria->add(TProfilPeer::ID_TYPE_PROFIL, $this->id_type_profil);
        if ($this->isColumnModified(TProfilPeer::ORGANISATION)) $criteria->add(TProfilPeer::ORGANISATION, $this->organisation);
        if ($this->isColumnModified(TProfilPeer::ETABLISSEMENT)) $criteria->add(TProfilPeer::ETABLISSEMENT, $this->etablissement);
        if ($this->isColumnModified(TProfilPeer::REFERENTIEL_TYPE_PRESTATION)) $criteria->add(TProfilPeer::REFERENTIEL_TYPE_PRESTATION, $this->referentiel_type_prestation);
        if ($this->isColumnModified(TProfilPeer::PARAMETRAGE_PRESTATION)) $criteria->add(TProfilPeer::PARAMETRAGE_PRESTATION, $this->parametrage_prestation);
        if ($this->isColumnModified(TProfilPeer::NIVEAU_1)) $criteria->add(TProfilPeer::NIVEAU_1, $this->niveau_1);
        if ($this->isColumnModified(TProfilPeer::NIVEAU_2)) $criteria->add(TProfilPeer::NIVEAU_2, $this->niveau_2);
        if ($this->isColumnModified(TProfilPeer::NIVEAU_3)) $criteria->add(TProfilPeer::NIVEAU_3, $this->niveau_3);
        if ($this->isColumnModified(TProfilPeer::JOURS_FERIES)) $criteria->add(TProfilPeer::JOURS_FERIES, $this->jours_feries);
        if ($this->isColumnModified(TProfilPeer::AGENDA)) $criteria->add(TProfilPeer::AGENDA, $this->agenda);
        if ($this->isColumnModified(TProfilPeer::JOURS_INDISPONIBILITES)) $criteria->add(TProfilPeer::JOURS_INDISPONIBILITES, $this->jours_indisponibilites);
        if ($this->isColumnModified(TProfilPeer::UTILISATEURS)) $criteria->add(TProfilPeer::UTILISATEURS, $this->utilisateurs);
        if ($this->isColumnModified(TProfilPeer::PROFILS)) $criteria->add(TProfilPeer::PROFILS, $this->profils);
        if ($this->isColumnModified(TProfilPeer::GESTIONS_DES_RENDEZ_VOUS)) $criteria->add(TProfilPeer::GESTIONS_DES_RENDEZ_VOUS, $this->gestions_des_rendez_vous);
        if ($this->isColumnModified(TProfilPeer::RAPPORT_NBR_RDV)) $criteria->add(TProfilPeer::RAPPORT_NBR_RDV, $this->rapport_nbr_rdv);
        if ($this->isColumnModified(TProfilPeer::RAPPORT_DELAI_OBTENTION)) $criteria->add(TProfilPeer::RAPPORT_DELAI_OBTENTION, $this->rapport_delai_obtention);
        if ($this->isColumnModified(TProfilPeer::RAPPORT_ACTIVITE)) $criteria->add(TProfilPeer::RAPPORT_ACTIVITE, $this->rapport_activite);
        if ($this->isColumnModified(TProfilPeer::PERFORMANCE_GLOBALE)) $criteria->add(TProfilPeer::PERFORMANCE_GLOBALE, $this->performance_globale);
        if ($this->isColumnModified(TProfilPeer::REFERENTIEL_PRESTATION)) $criteria->add(TProfilPeer::REFERENTIEL_PRESTATION, $this->referentiel_prestation);
        if ($this->isColumnModified(TProfilPeer::RECHERCHE_ETENDUE_RDV)) $criteria->add(TProfilPeer::RECHERCHE_ETENDUE_RDV, $this->recherche_etendue_rdv);
        if ($this->isColumnModified(TProfilPeer::ALERT_RAPPORT_HEBDO)) $criteria->add(TProfilPeer::ALERT_RAPPORT_HEBDO, $this->alert_rapport_hebdo);
        if ($this->isColumnModified(TProfilPeer::ALERT_RAPPORT_MENS)) $criteria->add(TProfilPeer::ALERT_RAPPORT_MENS, $this->alert_rapport_mens);
        if ($this->isColumnModified(TProfilPeer::MODIF_DUREE_RDV)) $criteria->add(TProfilPeer::MODIF_DUREE_RDV, $this->modif_duree_rdv);
        if ($this->isColumnModified(TProfilPeer::AFFECTATION_RDV)) $criteria->add(TProfilPeer::AFFECTATION_RDV, $this->affectation_rdv);
        if ($this->isColumnModified(TProfilPeer::ANNULATION_RDV)) $criteria->add(TProfilPeer::ANNULATION_RDV, $this->annulation_rdv);

        return $criteria;
    }

    /**
     * Builds a Criteria object containing the primary key for this object.
     *
     * Unlike buildCriteria() this method includes the primary key values regardless
     * of whether or not they have been modified.
     *
     * @return Criteria The Criteria object containing value(s) for primary key(s).
     */
    public function buildPkeyCriteria()
    {
        $criteria = new Criteria(TProfilPeer::DATABASE_NAME);
        $criteria->add(TProfilPeer::ID_PROFIL, $this->id_profil);

        return $criteria;
    }

    /**
     * Returns the primary key for this object (row).
     * @return int
     */
    public function getPrimaryKey()
    {
        return $this->getIdProfil();
    }

    /**
     * Generic method to set the primary key (id_profil column).
     *
     * @param  int $key Primary key.
     * @return void
     */
    public function setPrimaryKey($key)
    {
        $this->setIdProfil($key);
    }

    /**
     * Returns true if the primary key for this object is null.
     * @return boolean
     */
    public function isPrimaryKeyNull()
    {

        return null === $this->getIdProfil();
    }

    /**
     * Sets contents of passed object to values from current object.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param object $copyObj An object of TProfil (or compatible) type.
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @param boolean $makeNew Whether to reset autoincrement PKs and make the object new.
     * @throws PropelException
     */
    public function copyInto($copyObj, $deepCopy = false, $makeNew = true)
    {
        $copyObj->setIdOrganisation($this->getIdOrganisation());
        $copyObj->setCodeLibelleProfil($this->getCodeLibelleProfil());
        $copyObj->setIdTypeProfil($this->getIdTypeProfil());
        $copyObj->setOrganisation($this->getOrganisation());
        $copyObj->setEtablissement($this->getEtablissement());
        $copyObj->setReferentielTypePrestation($this->getReferentielTypePrestation());
        $copyObj->setParametragePrestation($this->getParametragePrestation());
        $copyObj->setNiveau1($this->getNiveau1());
        $copyObj->setNiveau2($this->getNiveau2());
        $copyObj->setNiveau3($this->getNiveau3());
        $copyObj->setJoursFeries($this->getJoursFeries());
        $copyObj->setAgenda($this->getAgenda());
        $copyObj->setJoursIndisponibilites($this->getJoursIndisponibilites());
        $copyObj->setUtilisateurs($this->getUtilisateurs());
        $copyObj->setProfils($this->getProfils());
        $copyObj->setGestionsDesRendezVous($this->getGestionsDesRendezVous());
        $copyObj->setRapportNbrRdv($this->getRapportNbrRdv());
        $copyObj->setRapportDelaiObtention($this->getRapportDelaiObtention());
        $copyObj->setRapportActivite($this->getRapportActivite());
        $copyObj->setPerformanceGlobale($this->getPerformanceGlobale());
        $copyObj->setReferentielPrestation($this->getReferentielPrestation());
        $copyObj->setRechercheEtendueRdv($this->getRechercheEtendueRdv());
        $copyObj->setAlertRapportHebdo($this->getAlertRapportHebdo());
        $copyObj->setAlertRapportMens($this->getAlertRapportMens());
        $copyObj->setModifDureeRdv($this->getModifDureeRdv());
        $copyObj->setAffectationRdv($this->getAffectationRdv());
        $copyObj->setAnnulationRdv($this->getAnnulationRdv());

        if ($deepCopy && !$this->startCopy) {
            // important: temporarily setNew(false) because this affects the behavior of
            // the getter/setter methods for fkey referrer objects.
            $copyObj->setNew(false);
            // store object hash to prevent cycle
            $this->startCopy = true;

            foreach ($this->getTAgents() as $relObj) {
                if ($relObj !== $this) {  // ensure that we don't try to copy a reference to ourselves
                    $copyObj->addTAgent($relObj->copy($deepCopy));
                }
            }

            //unflag object copy
            $this->startCopy = false;
        } // if ($deepCopy)

        if ($makeNew) {
            $copyObj->setNew(true);
            $copyObj->setIdProfil(NULL); // this is a auto-increment column, so set to default value
        }
    }

    /**
     * Makes a copy of this object that will be inserted as a new row in table when saved.
     * It creates a new object filling in the simple attributes, but skipping any primary
     * keys that are defined for the table.
     *
     * If desired, this method can also make copies of all associated (fkey referrers)
     * objects.
     *
     * @param boolean $deepCopy Whether to also copy all rows that refer (by fkey) to the current row.
     * @return TProfil Clone of current object.
     * @throws PropelException
     */
    public function copy($deepCopy = false)
    {
        // we use get_class(), because this might be a subclass
        $clazz = get_class($this);
        $copyObj = new $clazz();
        $this->copyInto($copyObj, $deepCopy);

        return $copyObj;
    }

    /**
     * Returns a peer instance associated with this om.
     *
     * Since Peer classes are not to have any instance attributes, this method returns the
     * same instance for all member of this class. The method could therefore
     * be static, but this would prevent one from overriding the behavior.
     *
     * @return TProfilPeer
     */
    public function getPeer()
    {
        if (self::$peer === null) {
            self::$peer = new TProfilPeer();
        }

        return self::$peer;
    }

    /**
     * Declares an association between this object and a TTraduction object.
     *
     * @param             TTraduction $v
     * @return TProfil The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTraduction(TTraduction $v = null)
    {
        if ($v === null) {
            $this->setCodeLibelleProfil(NULL);
        } else {
            $this->setCodeLibelleProfil($v->getIdTraduction());
        }

        $this->aTTraduction = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTraduction object, it will not be re-added.
        if ($v !== null) {
            $v->addTProfil($this);
        }


        return $this;
    }


    /**
     * Get the associated TTraduction object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTraduction The associated TTraduction object.
     * @throws PropelException
     */
    public function getTTraduction(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTraduction === null && ($this->code_libelle_profil !== null) && $doQuery) {
            $this->aTTraduction = TTraductionQuery::create()->findPk($this->code_libelle_profil, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTraduction->addTProfils($this);
             */
        }

        return $this->aTTraduction;
    }

    /**
     * Declares an association between this object and a TOrganisation object.
     *
     * @param             TOrganisation $v
     * @return TProfil The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTOrganisation(TOrganisation $v = null)
    {
        if ($v === null) {
            $this->setIdOrganisation(NULL);
        } else {
            $this->setIdOrganisation($v->getIdOrganisation());
        }

        $this->aTOrganisation = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TOrganisation object, it will not be re-added.
        if ($v !== null) {
            $v->addTProfil($this);
        }


        return $this;
    }


    /**
     * Get the associated TOrganisation object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TOrganisation The associated TOrganisation object.
     * @throws PropelException
     */
    public function getTOrganisation(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTOrganisation === null && ($this->id_organisation !== null) && $doQuery) {
            $this->aTOrganisation = TOrganisationQuery::create()->findPk($this->id_organisation, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTOrganisation->addTProfils($this);
             */
        }

        return $this->aTOrganisation;
    }

    /**
     * Declares an association between this object and a TTypeProfil object.
     *
     * @param             TTypeProfil $v
     * @return TProfil The current object (for fluent API support)
     * @throws PropelException
     */
    public function setTTypeProfil(TTypeProfil $v = null)
    {
        if ($v === null) {
            $this->setIdTypeProfil(NULL);
        } else {
            $this->setIdTypeProfil($v->getIdTypeProfil());
        }

        $this->aTTypeProfil = $v;

        // Add binding for other direction of this n:n relationship.
        // If this object has already been added to the TTypeProfil object, it will not be re-added.
        if ($v !== null) {
            $v->addTProfil($this);
        }


        return $this;
    }


    /**
     * Get the associated TTypeProfil object
     *
     * @param PropelPDO $con Optional Connection object.
     * @param $doQuery Executes a query to get the object if required
     * @return TTypeProfil The associated TTypeProfil object.
     * @throws PropelException
     */
    public function getTTypeProfil(PropelPDO $con = null, $doQuery = true)
    {
        if ($this->aTTypeProfil === null && ($this->id_type_profil !== null) && $doQuery) {
            $this->aTTypeProfil = TTypeProfilQuery::create()->findPk($this->id_type_profil, $con);
            /* The following can be used additionally to
                guarantee the related object contains a reference
                to this object.  This level of coupling may, however, be
                undesirable since it could result in an only partially populated collection
                in the referenced object.
                $this->aTTypeProfil->addTProfils($this);
             */
        }

        return $this->aTTypeProfil;
    }


    /**
     * Initializes a collection based on the name of a relation.
     * Avoids crafting an 'init[$relationName]s' method name
     * that wouldn't work when StandardEnglishPluralizer is used.
     *
     * @param string $relationName The name of the relation to initialize
     * @return void
     */
    public function initRelation($relationName)
    {
        if ('TAgent' == $relationName) {
            $this->initTAgents();
        }
    }

    /**
     * Clears out the collTAgents collection
     *
     * This does not modify the database; however, it will remove any associated objects, causing
     * them to be refetched by subsequent calls to accessor method.
     *
     * @return TProfil The current object (for fluent API support)
     * @see        addTAgents()
     */
    public function clearTAgents()
    {
        $this->collTAgents = null; // important to set this to null since that means it is uninitialized
        $this->collTAgentsPartial = null;

        return $this;
    }

    /**
     * reset is the collTAgents collection loaded partially
     *
     * @return void
     */
    public function resetPartialTAgents($v = true)
    {
        $this->collTAgentsPartial = $v;
    }

    /**
     * Initializes the collTAgents collection.
     *
     * By default this just sets the collTAgents collection to an empty array (like clearcollTAgents());
     * however, you may wish to override this method in your stub class to provide setting appropriate
     * to your application -- for example, setting the initial array to the values stored in database.
     *
     * @param boolean $overrideExisting If set to true, the method call initializes
     *                                        the collection even if it is not empty
     *
     * @return void
     */
    public function initTAgents($overrideExisting = true)
    {
        if (null !== $this->collTAgents && !$overrideExisting) {
            return;
        }
        $this->collTAgents = new PropelObjectCollection();
        $this->collTAgents->setModel('TAgent');
    }

    /**
     * Gets an array of TAgent objects which contain a foreign key that references this object.
     *
     * If the $criteria is not null, it is used to always fetch the results from the database.
     * Otherwise the results are fetched from the database the first time, then cached.
     * Next time the same method is called without $criteria, the cached collection is returned.
     * If this TProfil is new, it will return
     * an empty collection or the current collection; the criteria is ignored on a new object.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     * @throws PropelException
     */
    public function getTAgents($criteria = null, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsPartial && !$this->isNew();
        if (null === $this->collTAgents || null !== $criteria  || $partial) {
            if ($this->isNew() && null === $this->collTAgents) {
                // return empty collection
                $this->initTAgents();
            } else {
                $collTAgents = TAgentQuery::create(null, $criteria)
                    ->filterByTProfil($this)
                    ->find($con);
                if (null !== $criteria) {
                    if (false !== $this->collTAgentsPartial && count($collTAgents)) {
                      $this->initTAgents(false);

                      foreach($collTAgents as $obj) {
                        if (false == $this->collTAgents->contains($obj)) {
                          $this->collTAgents->append($obj);
                        }
                      }

                      $this->collTAgentsPartial = true;
                    }

                    $collTAgents->getInternalIterator()->rewind();
                    return $collTAgents;
                }

                if($partial && $this->collTAgents) {
                    foreach($this->collTAgents as $obj) {
                        if($obj->isNew()) {
                            $collTAgents[] = $obj;
                        }
                    }
                }

                $this->collTAgents = $collTAgents;
                $this->collTAgentsPartial = false;
            }
        }

        return $this->collTAgents;
    }

    /**
     * Sets a collection of TAgent objects related by a one-to-many relationship
     * to the current object.
     * It will also schedule objects for deletion based on a diff between old objects (aka persisted)
     * and new objects from the given Propel collection.
     *
     * @param PropelCollection $tAgents A Propel collection.
     * @param PropelPDO $con Optional connection object
     * @return TProfil The current object (for fluent API support)
     */
    public function setTAgents(PropelCollection $tAgents, PropelPDO $con = null)
    {
        $tAgentsToDelete = $this->getTAgents(new Criteria(), $con)->diff($tAgents);

        $this->tAgentsScheduledForDeletion = unserialize(serialize($tAgentsToDelete));

        foreach ($tAgentsToDelete as $tAgentRemoved) {
            $tAgentRemoved->setTProfil(null);
        }

        $this->collTAgents = null;
        foreach ($tAgents as $tAgent) {
            $this->addTAgent($tAgent);
        }

        $this->collTAgents = $tAgents;
        $this->collTAgentsPartial = false;

        return $this;
    }

    /**
     * Returns the number of related TAgent objects.
     *
     * @param Criteria $criteria
     * @param boolean $distinct
     * @param PropelPDO $con
     * @return int             Count of related TAgent objects.
     * @throws PropelException
     */
    public function countTAgents(Criteria $criteria = null, $distinct = false, PropelPDO $con = null)
    {
        $partial = $this->collTAgentsPartial && !$this->isNew();
        if (null === $this->collTAgents || null !== $criteria || $partial) {
            if ($this->isNew() && null === $this->collTAgents) {
                return 0;
            }

            if($partial && !$criteria) {
                return count($this->getTAgents());
            }
            $query = TAgentQuery::create(null, $criteria);
            if ($distinct) {
                $query->distinct();
            }

            return $query
                ->filterByTProfil($this)
                ->count($con);
        }

        return count($this->collTAgents);
    }

    /**
     * Method called to associate a TAgent object to this object
     * through the TAgent foreign key attribute.
     *
     * @param    TAgent $l TAgent
     * @return TProfil The current object (for fluent API support)
     */
    public function addTAgent(TAgent $l)
    {
        if ($this->collTAgents === null) {
            $this->initTAgents();
            $this->collTAgentsPartial = true;
        }
        if (!in_array($l, $this->collTAgents->getArrayCopy(), true)) { // only add it if the **same** object is not already associated
            $this->doAddTAgent($l);
        }

        return $this;
    }

    /**
     * @param	TAgent $tAgent The tAgent object to add.
     */
    protected function doAddTAgent($tAgent)
    {
        $this->collTAgents[]= $tAgent;
        $tAgent->setTProfil($this);
    }

    /**
     * @param	TAgent $tAgent The tAgent object to remove.
     * @return TProfil The current object (for fluent API support)
     */
    public function removeTAgent($tAgent)
    {
        if ($this->getTAgents()->contains($tAgent)) {
            $this->collTAgents->remove($this->collTAgents->search($tAgent));
            if (null === $this->tAgentsScheduledForDeletion) {
                $this->tAgentsScheduledForDeletion = clone $this->collTAgents;
                $this->tAgentsScheduledForDeletion->clear();
            }
            $this->tAgentsScheduledForDeletion[]= $tAgent;
            $tAgent->setTProfil(null);
        }

        return $this;
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTTraductionRelatedByCodeNomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeNomUtilisateur', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTTraductionRelatedByCodePrenomUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodePrenomUtilisateur', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTEtablissementRelatedByIdEtablissementAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementAttache', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTEtablissementRelatedByIdEtablissementGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TEtablissementRelatedByIdEtablissementGere', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTOrganisationRelatedByIdOrganisationAttache($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationAttache', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTOrganisationRelatedByIdOrganisationGere($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TOrganisationRelatedByIdOrganisationGere', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTPrestation($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TPrestation', $join_behavior);

        return $this->getTAgents($query, $con);
    }


    /**
     * If this collection has already been initialized with
     * an identical criteria, it returns the collection.
     * Otherwise if this TProfil is new, it will return
     * an empty collection; or if this TProfil has previously
     * been saved, it will retrieve related TAgents from storage.
     *
     * This method is protected by default in order to keep the public
     * api reasonable.  You can provide public methods for those you
     * actually need in TProfil.
     *
     * @param Criteria $criteria optional Criteria object to narrow the query
     * @param PropelPDO $con optional connection object
     * @param string $join_behavior optional join type to use (defaults to Criteria::LEFT_JOIN)
     * @return PropelObjectCollection|TAgent[] List of TAgent objects
     */
    public function getTAgentsJoinTTraductionRelatedByCodeUtilisateur($criteria = null, $con = null, $join_behavior = Criteria::LEFT_JOIN)
    {
        $query = TAgentQuery::create(null, $criteria);
        $query->joinWith('TTraductionRelatedByCodeUtilisateur', $join_behavior);

        return $this->getTAgents($query, $con);
    }

    /**
     * Clears the current object and sets all attributes to their default values
     */
    public function clear()
    {
        $this->id_profil = null;
        $this->id_organisation = null;
        $this->code_libelle_profil = null;
        $this->id_type_profil = null;
        $this->organisation = null;
        $this->etablissement = null;
        $this->referentiel_type_prestation = null;
        $this->parametrage_prestation = null;
        $this->niveau_1 = null;
        $this->niveau_2 = null;
        $this->niveau_3 = null;
        $this->jours_feries = null;
        $this->agenda = null;
        $this->jours_indisponibilites = null;
        $this->utilisateurs = null;
        $this->profils = null;
        $this->gestions_des_rendez_vous = null;
        $this->rapport_nbr_rdv = null;
        $this->rapport_delai_obtention = null;
        $this->rapport_activite = null;
        $this->performance_globale = null;
        $this->referentiel_prestation = null;
        $this->recherche_etendue_rdv = null;
        $this->alert_rapport_hebdo = null;
        $this->alert_rapport_mens = null;
        $this->modif_duree_rdv = null;
        $this->affectation_rdv = null;
        $this->annulation_rdv = null;
        $this->alreadyInSave = false;
        $this->alreadyInValidation = false;
        $this->alreadyInClearAllReferencesDeep = false;
        $this->clearAllReferences();
        $this->applyDefaultValues();
        $this->resetModified();
        $this->setNew(true);
        $this->setDeleted(false);
    }

    /**
     * Resets all references to other model objects or collections of model objects.
     *
     * This method is a user-space workaround for PHP's inability to garbage collect
     * objects with circular references (even in PHP 5.3). This is currently necessary
     * when using Propel in certain daemon or large-volumne/high-memory operations.
     *
     * @param boolean $deep Whether to also clear the references on all referrer objects.
     */
    public function clearAllReferences($deep = false)
    {
        if ($deep && !$this->alreadyInClearAllReferencesDeep) {
            $this->alreadyInClearAllReferencesDeep = true;
            if ($this->collTAgents) {
                foreach ($this->collTAgents as $o) {
                    $o->clearAllReferences($deep);
                }
            }
            if ($this->aTTraduction instanceof Persistent) {
              $this->aTTraduction->clearAllReferences($deep);
            }
            if ($this->aTOrganisation instanceof Persistent) {
              $this->aTOrganisation->clearAllReferences($deep);
            }
            if ($this->aTTypeProfil instanceof Persistent) {
              $this->aTTypeProfil->clearAllReferences($deep);
            }

            $this->alreadyInClearAllReferencesDeep = false;
        } // if ($deep)

        if ($this->collTAgents instanceof PropelCollection) {
            $this->collTAgents->clearIterator();
        }
        $this->collTAgents = null;
        $this->aTTraduction = null;
        $this->aTOrganisation = null;
        $this->aTTypeProfil = null;
    }

    /**
     * return the string representation of this object
     *
     * @return string
     */
    public function __toString()
    {
        return (string) $this->exportTo(TProfilPeer::DEFAULT_STRING_FORMAT);
    }

    /**
     * return true is the object is in saving state
     *
     * @return boolean
     */
    public function isAlreadyInSave()
    {
        return $this->alreadyInSave;
    }

}
