<?php

class TPieceParamFormPeer extends BaseTPieceParamFormPeer
{

}
