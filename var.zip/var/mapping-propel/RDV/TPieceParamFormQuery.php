<?php

class TPieceParamFormQuery extends BaseTPieceParamFormQuery
{

}
