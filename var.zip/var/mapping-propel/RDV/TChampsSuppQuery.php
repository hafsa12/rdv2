<?php



/**
 * Skeleton subclass for performing query and update operations on the 'T_CHAMPS_SUPP' table.
 *
 *
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 * @package    propel.generator.RDV
 */
class TChampsSuppQuery extends BaseTChampsSuppQuery
{
    public function getChampSuppById($idChampsSupp)
    {
        return $this->findPk($idChampsSupp);
    }

    public function getListeChampsSupp($idOrg,$option=false)
    {
        $result = $this->findByIdOrganisation($idOrg);

        $liste = array();
        if($option) {
            $liste[" "] = $option;
        }
        foreach($result as $champs) {
            $liste[$champs->getIdChampsSupp()] = $champs->getCodeChamps();
        }
        return $liste;
    }
}
