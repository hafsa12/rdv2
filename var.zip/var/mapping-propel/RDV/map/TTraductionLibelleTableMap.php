<?php



/**
 * This class defines the structure of the 'T_TRADUCTION_LIBELLE' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TTraductionLibelleTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TTraductionLibelleTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_TRADUCTION_LIBELLE');
        $this->setPhpName('TTraductionLibelle');
        $this->setClassname('TTraductionLibelle');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(false);
        // columns
        $this->addForeignPrimaryKey('ID_TRADUCTION', 'IdTraduction', 'INTEGER' , 'T_TRADUCTION', 'ID_TRADUCTION', true, null, null);
        $this->addPrimaryKey('LANG', 'Lang', 'VARCHAR', true, 2, null);
        $this->addColumn('LIBELLE', 'Libelle', 'LONGVARCHAR', true, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('ID_TRADUCTION' => 'ID_TRADUCTION', ), null, null);
    } // buildRelations()

} // TTraductionLibelleTableMap
