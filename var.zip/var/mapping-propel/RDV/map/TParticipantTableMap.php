<?php



/**
 * This class defines the structure of the 'T_PARTICIPANT' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TParticipantTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TParticipantTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_PARTICIPANT');
        $this->setPhpName('TParticipant');
        $this->setClassname('TParticipant');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_PARTICIPANT', 'IdParticipant', 'INTEGER', true, null, null);
        $this->addColumn('NOM', 'Nom', 'VARCHAR', true, 255, null);
        $this->addColumn('PRENOM', 'Prenom', 'VARCHAR', true, 255, null);
        $this->addColumn('EMAIL', 'Email', 'VARCHAR', true, 255, null);
        $this->addColumn('ORGANISATION', 'Organisation', 'VARCHAR', true, 255, null);
        $this->addForeignKey('ID_RENDEZ_VOUS', 'IdRendezVous', 'INTEGER', 'T_RENDEZ_VOUS', 'ID_RENDEZ_VOUS', true, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TRendezVous', 'TRendezVous', RelationMap::MANY_TO_ONE, array('ID_RENDEZ_VOUS' => 'ID_RENDEZ_VOUS', ), null, null);
    } // buildRelations()

} // TParticipantTableMap
