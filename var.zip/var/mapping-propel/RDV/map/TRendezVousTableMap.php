<?php



/**
 * This class defines the structure of the 'T_RENDEZ_VOUS' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TRendezVousTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TRendezVousTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_RENDEZ_VOUS');
        $this->setPhpName('TRendezVous');
        $this->setClassname('TRendezVous');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_RENDEZ_VOUS', 'IdRendezVous', 'INTEGER', true, null, null);
        $this->addColumn('DATE_CREATION', 'DateCreation', 'TIMESTAMP', false, null, null);
        $this->addColumn('DATE_CONFIRMATION', 'DateConfirmation', 'DATE', false, null, null);
        $this->addColumn('DATE_ANNULATION', 'DateAnnulation', 'DATE', false, null, null);
        $this->addColumn('MOTIF_ANNULATION', 'MotifAnnulation', 'LONGVARCHAR', false, null, null);
        $this->addColumn('DATE_RDV', 'DateRdv', 'TIMESTAMP', false, null, null);
        $this->addColumn('DATE_FIN_RDV', 'DateFinRdv', 'TIMESTAMP', false, null, null);
        $this->addColumn('CODE_RDV', 'CodeRdv', 'VARCHAR', true, 10, null);
        $this->addColumn('ETAT_RDV', 'EtatRdv', 'CHAR', false, null, null);
        $this->getColumn('ETAT_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
  2 => '2',
  3 => '3',
  4 => '4',
  5 => '5',
));
        $this->addColumn('MODE_PRISE_RDV', 'ModePriseRdv', 'CHAR', true, null, '0');
        $this->getColumn('MODE_PRISE_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
  2 => '2',
  3 => '3',
));
        $this->addColumn('TYPE_PRISE_RDV', 'TypePriseRdv', 'CHAR', true, null, '0');
        $this->getColumn('TYPE_PRISE_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
  2 => '2',
  3 => '3',
));
        $this->addForeignKey('ID_CITOYEN', 'IdCitoyen', 'INTEGER', 'T_CITOYEN', 'ID_CITOYEN', true, null, null);
        $this->addForeignKey('ID_AGENT_ACCUEIL', 'IdAgentAccueil', 'INTEGER', 'T_AGENT', 'ID_AGENT', false, null, null);
        $this->addForeignKey('ID_ETABLISSEMENT', 'IdEtablissement', 'INTEGER', 'T_ETABLISSEMENT', 'ID_ETABLISSEMENT', true, null, null);
        $this->addForeignKey('ID_PRESTATION', 'IdPrestation', 'INTEGER', 'T_PRESTATION', 'ID_PRESTATION', true, null, null);
        $this->addForeignKey('ID_AGENT_RESSOURCE', 'IdAgentRessource', 'INTEGER', 'T_AGENT', 'ID_AGENT', false, null, null);
        $this->addForeignKey('ID_AGENT_TELEOPERATEUR', 'IdAgentTeleoperateur', 'INTEGER', 'T_AGENT', 'ID_AGENT', false, null, null);
        $this->addForeignKey('ID_AGENT_CONFIRMATION', 'IdAgentConfirmation', 'INTEGER', 'T_AGENT', 'ID_AGENT', false, null, null);
        $this->addForeignKey('ID_AGENT_ANNULATION', 'IdAgentAnnulation', 'INTEGER', 'T_AGENT', 'ID_AGENT', false, null, null);
        $this->addForeignKey('ID_REFERENT', 'IdReferent', 'INTEGER', 'T_REFERENT', 'ID_REFERENT', false, null, null);
        $this->addColumn('TAG_GATEWAY', 'TagGateway', 'CHAR', false, null, '0');
        $this->getColumn('TAG_GATEWAY', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('ID_UTILISATEUR', 'IdUtilisateur', 'VARCHAR', false, 255, null);
        $this->addColumn('ETAT_ACQUITTEMENT', 'EtatAcquittement', 'INTEGER', false, null, 0);
        $this->addColumn('DATE_ACQUITTEMENT', 'DateAcquittement', 'TIMESTAMP', false, null, null);
        $this->addColumn('CHAMP_SUPP_PRESTA', 'ChampSuppPresta', 'LONGVARCHAR', false, null, null);
        $this->addColumn('ID_CHEF_RESSOURCE', 'IdChefRessource', 'INTEGER', false, null, null);
        $this->addColumn('PARTAGE_RECAP', 'PartageRecap', 'CHAR', true, null, '0');
        $this->getColumn('PARTAGE_RECAP', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('NATURE_SESSION', 'NatureSession', 'CHAR', false, null, null);
        $this->getColumn('NATURE_SESSION', false)->setValueSet(array (
  0 => '1',
  1 => '2',
  2 => '3',
));
        $this->addColumn('LIEU_RDV', 'LieuRdv', 'LONGVARCHAR', false, null, null);
        $this->addColumn('LIEN_RDV', 'LienRdv', 'LONGVARCHAR', false, null, null);
        $this->addColumn('NOMBRE_PARTICIPANT', 'NombreParticipant', 'INTEGER', false, null, null);
        $this->addColumn('COMMENTAIRE', 'Commentaire', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('ID_VALEUR_REFERENTIEL', 'IdValeurReferentiel', 'INTEGER', 'T_VALEUR_REFERENTIEL', 'ID_VALEUR_REFERENTIEL', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TCitoyen', 'TCitoyen', RelationMap::MANY_TO_ONE, array('ID_CITOYEN' => 'ID_CITOYEN', ), null, null);
        $this->addRelation('TAgentRelatedByIdAgentAccueil', 'TAgent', RelationMap::MANY_TO_ONE, array('ID_AGENT_ACCUEIL' => 'ID_AGENT', ), null, null);
        $this->addRelation('TAgentRelatedByIdAgentAnnulation', 'TAgent', RelationMap::MANY_TO_ONE, array('ID_AGENT_ANNULATION' => 'ID_AGENT', ), null, null);
        $this->addRelation('TAgentRelatedByIdAgentConfirmation', 'TAgent', RelationMap::MANY_TO_ONE, array('ID_AGENT_CONFIRMATION' => 'ID_AGENT', ), null, null);
        $this->addRelation('TAgentRelatedByIdAgentRessource', 'TAgent', RelationMap::MANY_TO_ONE, array('ID_AGENT_RESSOURCE' => 'ID_AGENT', ), null, null);
        $this->addRelation('TAgentRelatedByIdAgentTeleoperateur', 'TAgent', RelationMap::MANY_TO_ONE, array('ID_AGENT_TELEOPERATEUR' => 'ID_AGENT', ), null, null);
        $this->addRelation('TValeurReferentiel', 'TValeurReferentiel', RelationMap::MANY_TO_ONE, array('ID_VALEUR_REFERENTIEL' => 'ID_VALEUR_REFERENTIEL', ), null, null);
        $this->addRelation('TEtablissement', 'TEtablissement', RelationMap::MANY_TO_ONE, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT', ), null, null);
        $this->addRelation('TPrestation', 'TPrestation', RelationMap::MANY_TO_ONE, array('ID_PRESTATION' => 'ID_PRESTATION', ), null, null);
        $this->addRelation('TReferent', 'TReferent', RelationMap::MANY_TO_ONE, array('ID_REFERENT' => 'ID_REFERENT', ), null, null);
        $this->addRelation('TBlobRdv', 'TBlobRdv', RelationMap::ONE_TO_MANY, array('ID_RENDEZ_VOUS' => 'ID_RENDEZ_VOUS', ), null, null, 'TBlobRdvs');
        $this->addRelation('TParticipant', 'TParticipant', RelationMap::ONE_TO_MANY, array('ID_RENDEZ_VOUS' => 'ID_RENDEZ_VOUS', ), null, null, 'TParticipants');
    } // buildRelations()

} // TRendezVousTableMap
