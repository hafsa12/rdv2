<?php



/**
 * This class defines the structure of the 'T_CHAMPS_SUPP' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TChampsSuppTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TChampsSuppTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_CHAMPS_SUPP');
        $this->setPhpName('TChampsSupp');
        $this->setClassname('TChampsSupp');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_CHAMPS_SUPP', 'IdChampsSupp', 'INTEGER', true, null, null);
        $this->addForeignKey('ID_ORGANISATION', 'IdOrganisation', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', true, null, null);
        $this->addColumn('CODE_CHAMPS', 'CodeChamps', 'VARCHAR', true, 250, null);
        $this->addForeignKey('CODE_LIBELLE', 'CodeLibelle', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', true, null, null);
        $this->addColumn('OBLIGATOIRE', 'Obligatoire', 'CHAR', true, null, '0');
        $this->getColumn('OBLIGATOIRE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('CHAMPS_TYPE', 'ChampsType', 'CHAR', true, null, 'TEXT');
        $this->getColumn('CHAMPS_TYPE', false)->setValueSet(array (
  0 => 'TEXT',
  1 => 'NUMERIC',
  2 => 'LISTE',
  3 => 'MULTICHOIX',
));
        $this->addColumn('VALUE_LISTE', 'ValueListe', 'LONGVARCHAR', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null);
        $this->addRelation('TPrestationRelatedByIdChampsSupp3', 'TPrestation', RelationMap::ONE_TO_MANY, array('ID_CHAMPS_SUPP' => 'ID_CHAMPS_SUPP_3', ), null, null, 'TPrestationsRelatedByIdChampsSupp3');
        $this->addRelation('TPrestationRelatedByIdChampsSupp1', 'TPrestation', RelationMap::ONE_TO_MANY, array('ID_CHAMPS_SUPP' => 'ID_CHAMPS_SUPP_1', ), null, null, 'TPrestationsRelatedByIdChampsSupp1');
        $this->addRelation('TPrestationRelatedByIdChampsSupp2', 'TPrestation', RelationMap::ONE_TO_MANY, array('ID_CHAMPS_SUPP' => 'ID_CHAMPS_SUPP_2', ), null, null, 'TPrestationsRelatedByIdChampsSupp2');
    } // buildRelations()

} // TChampsSuppTableMap
