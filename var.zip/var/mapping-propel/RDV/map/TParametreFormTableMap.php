<?php



/**
 * This class defines the structure of the 'T_PARAMETRE_FORM' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TParametreFormTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TParametreFormTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_PARAMETRE_FORM');
        $this->setPhpName('TParametreForm');
        $this->setClassname('TParametreForm');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_PARAMETRE_FORM', 'IdParametreForm', 'INTEGER', true, null, null);
        $this->addColumn('RDV_SIMILAIRE', 'RdvSimilaire', 'CHAR', true, null, '0');
        $this->getColumn('RDV_SIMILAIRE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('NB_JOUR_RDV_SIMILAIRE', 'NbJourRdvSimilaire', 'INTEGER', false, 3, null);
        $this->addColumn('DELAI_MIN', 'DelaiMin', 'INTEGER', true, 4, 0);
        $this->addColumn('RESSOURCE_VISIBLE', 'RessourceVisible', 'CHAR', true, null, '1');
        $this->getColumn('RESSOURCE_VISIBLE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('RESSOURCE_OBLIGATOIRE', 'RessourceObligatoire', 'CHAR', true, null, '0');
        $this->getColumn('RESSOURCE_OBLIGATOIRE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('CODE_COMMENTAIRE', 'CodeCommentaire', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('REFERENT_VISIBLE', 'ReferentVisible', 'CHAR', true, null, '0');
        $this->getColumn('REFERENT_VISIBLE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('TEXT_1_ACTIF', 'Text1Actif', 'CHAR', false, null, '0');
        $this->getColumn('TEXT_1_ACTIF', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('CODE_LIBELLE_TEXT_1', 'CodeLibelleText1', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('OBLIGATOIRE_TEXT_1', 'ObligatoireText1', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_TEXT_1', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('TEXT_2_ACTIF', 'Text2Actif', 'CHAR', false, null, '0');
        $this->getColumn('TEXT_2_ACTIF', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('CODE_LIBELLE_TEXT_2', 'CodeLibelleText2', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('OBLIGATOIRE_TEXT_2', 'ObligatoireText2', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_TEXT_2', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('TEXT_3_ACTIF', 'Text3Actif', 'CHAR', false, null, '0');
        $this->getColumn('TEXT_3_ACTIF', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('CODE_LIBELLE_TEXT_3', 'CodeLibelleText3', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('OBLIGATOIRE_TEXT_3', 'ObligatoireText3', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_TEXT_3', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('REF_1_ACTIF', 'Ref1Actif', 'CHAR', false, null, '0');
        $this->getColumn('REF_1_ACTIF', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('ID_REF_1', 'IdRef1', 'INTEGER', 'T_REFERENTIEL', 'ID_REFERENTIEL', false, null, null);
        $this->addForeignKey('CODE_LIBELLE_REF_1', 'CodeLibelleRef1', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('OBLIGATOIRE_REF_1', 'ObligatoireRef1', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_REF_1', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('REF_2_ACTIF', 'Ref2Actif', 'CHAR', false, null, '0');
        $this->getColumn('REF_2_ACTIF', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('ID_REF_2', 'IdRef2', 'INTEGER', 'T_REFERENTIEL', 'ID_REFERENTIEL', false, null, null);
        $this->addForeignKey('CODE_LIBELLE_REF_2', 'CodeLibelleRef2', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('OBLIGATOIRE_REF_2', 'ObligatoireRef2', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_REF_2', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('REF_3_ACTIF', 'Ref3Actif', 'CHAR', false, null, '0');
        $this->getColumn('REF_3_ACTIF', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('ID_REF_3', 'IdRef3', 'INTEGER', 'T_REFERENTIEL', 'ID_REFERENTIEL', false, null, null);
        $this->addForeignKey('CODE_LIBELLE_REF_3', 'CodeLibelleRef3', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('OBLIGATOIRE_REF_3', 'ObligatoireRef3', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_REF_3', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_NOM', 'ObligatoireNom', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_NOM', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_PRENOM', 'ObligatoirePrenom', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_PRENOM', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_DATE_NAISSANCE', 'ObligatoireDateNaissance', 'CHAR', true, null, '0');
        $this->getColumn('OBLIGATOIRE_DATE_NAISSANCE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_EMAIL', 'ObligatoireEmail', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_EMAIL', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_IDENTIFIANT', 'ObligatoireIdentifiant', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_IDENTIFIANT', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_TELEPHONE', 'ObligatoireTelephone', 'CHAR', false, null, '0');
        $this->getColumn('OBLIGATOIRE_TELEPHONE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_RAISON_SOCIAL', 'ObligatoireRaisonSocial', 'CHAR', true, null, '0');
        $this->getColumn('OBLIGATOIRE_RAISON_SOCIAL', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_ADRESSE', 'ObligatoireAdresse', 'CHAR', true, null, '0');
        $this->getColumn('OBLIGATOIRE_ADRESSE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('OBLIGATOIRE_FAX', 'ObligatoireFax', 'CHAR', true, null, '0');
        $this->getColumn('OBLIGATOIRE_FAX', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_NOM', 'VisibleNom', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_NOM', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_PRENOM', 'VisiblePrenom', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_PRENOM', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_DATE_NAISSANCE', 'VisibleDateNaissance', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_DATE_NAISSANCE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_EMAIL', 'VisibleEmail', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_EMAIL', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_IDENTIFIANT', 'VisibleIdentifiant', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_IDENTIFIANT', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_TELEPHONE', 'VisibleTelephone', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_TELEPHONE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_RAISON_SOCIAL', 'VisibleRaisonSocial', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_RAISON_SOCIAL', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_ADRESSE', 'VisibleAdresse', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_ADRESSE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('VISIBLE_FAX', 'VisibleFax', 'CHAR', true, null, '0');
        $this->getColumn('VISIBLE_FAX', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('TEXT_1_TYPE', 'Text1Type', 'CHAR', true, null, 'TEXT');
        $this->getColumn('TEXT_1_TYPE', false)->setValueSet(array (
  0 => 'TEXT',
  1 => 'NUMERIC',
  2 => 'LISTE',
  3 => 'MULTICHOIX',
));
        $this->addColumn('TEXT_2_TYPE', 'Text2Type', 'CHAR', true, null, 'TEXT');
        $this->getColumn('TEXT_2_TYPE', false)->setValueSet(array (
  0 => 'TEXT',
  1 => 'NUMERIC',
  2 => 'LISTE',
  3 => 'MULTICHOIX',
));
        $this->addColumn('TEXT_3_TYPE', 'Text3Type', 'CHAR', true, null, 'TEXT');
        $this->getColumn('TEXT_3_TYPE', false)->setValueSet(array (
  0 => 'TEXT',
  1 => 'NUMERIC',
  2 => 'LISTE',
  3 => 'MULTICHOIX',
));
        $this->addColumn('TEXT_1_LISTE', 'Text1Liste', 'LONGVARCHAR', false, null, null);
        $this->addColumn('TEXT_2_LISTE', 'Text2Liste', 'LONGVARCHAR', false, null, null);
        $this->addColumn('TEXT_3_LISTE', 'Text3Liste', 'LONGVARCHAR', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraductionRelatedByCodeCommentaire', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_COMMENTAIRE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleRef1', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_REF_1' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleRef2', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_REF_2' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleRef3', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_REF_3' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleText1', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_TEXT_1' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleText2', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_TEXT_2' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleText3', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_TEXT_3' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TReferentielRelatedByIdRef1', 'TReferentiel', RelationMap::MANY_TO_ONE, array('ID_REF_1' => 'ID_REFERENTIEL', ), null, null);
        $this->addRelation('TReferentielRelatedByIdRef2', 'TReferentiel', RelationMap::MANY_TO_ONE, array('ID_REF_2' => 'ID_REFERENTIEL', ), null, null);
        $this->addRelation('TReferentielRelatedByIdRef3', 'TReferentiel', RelationMap::MANY_TO_ONE, array('ID_REF_3' => 'ID_REFERENTIEL', ), null, null);
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_PARAMETRE_FORM' => 'ID_PARAMETRE_FORM', ), null, null, 'TOrganisations');
        $this->addRelation('TParametragePrestation', 'TParametragePrestation', RelationMap::ONE_TO_MANY, array('ID_PARAMETRE_FORM' => 'ID_PARAMETRE_FORM', ), null, null, 'TParametragePrestations');
        $this->addRelation('TPieceParamForm', 'TPieceParamForm', RelationMap::ONE_TO_MANY, array('ID_PARAMETRE_FORM' => 'ID_PARAMETRE_FORM', ), null, null, 'TPieceParamForms');
        $this->addRelation('TPrestation', 'TPrestation', RelationMap::ONE_TO_MANY, array('ID_PARAMETRE_FORM' => 'ID_PARAMETRE_FORM', ), null, null, 'TPrestations');
        $this->addRelation('TRefPrestation', 'TRefPrestation', RelationMap::ONE_TO_MANY, array('ID_PARAMETRE_FORM' => 'ID_PARAMETRE_FORM', ), null, null, 'TRefPrestations');
    } // buildRelations()

} // TParametreFormTableMap
