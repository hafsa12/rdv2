<?php



/**
 * This class defines the structure of the 'T_ETABLISSEMENT' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TEtablissementTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TEtablissementTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_ETABLISSEMENT');
        $this->setPhpName('TEtablissement');
        $this->setClassname('TEtablissement');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_ETABLISSEMENT', 'IdEtablissement', 'INTEGER', true, null, null);
        $this->addColumn('ACTIVE', 'Active', 'CHAR', true, null, '1');
        $this->getColumn('ACTIVE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('CODE_DENOMINATION_ETABLISSEMENT', 'CodeDenominationEtablissement', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('CODE_ADRESSE_ETABLISSEMENT', 'CodeAdresseEtablissement', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('CODE_POSTAL', 'CodePostal', 'VARCHAR', true, 5, null);
        $this->addColumn('TELEPHONE_ETABLISSEMENT', 'TelephoneEtablissement', 'VARCHAR', false, 200, null);
        $this->addColumn('MAIL_ETABLISSEMENT', 'MailEtablissement', 'VARCHAR', false, 45, null);
        $this->addForeignKey('CODE_DESCRIPTION_ETABLISSEMENT', 'CodeDescriptionEtablissement', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('LATITUDE_ETABLISSEMENT', 'LatitudeEtablissement', 'VARCHAR', false, 45, null);
        $this->addColumn('LONGITUDE_ETABLISSEMENT', 'LongitudeEtablissement', 'VARCHAR', false, 45, null);
        $this->addForeignKey('ID_ENTITE', 'IdEntite', 'INTEGER', 'T_ENTITE', 'ID_ENTITE', false, null, null);
        $this->addForeignKey('ID_ORGANISATION', 'IdOrganisation', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', true, null, null);
        $this->addForeignKey('ID_BLOB_PLAN', 'IdBlobPlan', 'INTEGER', 'T_BLOB', 'ID_BLOB', false, null, null);
        $this->addForeignKey('ID_TYPE_ETAB', 'IdTypeEtab', 'INTEGER', 'T_TYPE_ETAB', 'ID_TYPE_ETAB', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTypeEtab', 'TTypeEtab', RelationMap::MANY_TO_ONE, array('ID_TYPE_ETAB' => 'ID_TYPE_ETAB', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeAdresseEtablissement', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_ADRESSE_ETABLISSEMENT' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeDenominationEtablissement', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_DENOMINATION_ETABLISSEMENT' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeDescriptionEtablissement', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_DESCRIPTION_ETABLISSEMENT' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TBlob', 'TBlob', RelationMap::MANY_TO_ONE, array('ID_BLOB_PLAN' => 'ID_BLOB', ), null, null);
        $this->addRelation('TEntite', 'TEntite', RelationMap::MANY_TO_ONE, array('ID_ENTITE' => 'ID_ENTITE', ), null, null);
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null);
        $this->addRelation('TAgentRelatedByIdEtablissementAttache', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT_ATTACHE', ), null, null, 'TAgentsRelatedByIdEtablissementAttache');
        $this->addRelation('TAgentRelatedByIdEtablissementGere', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT_GERE', ), null, null, 'TAgentsRelatedByIdEtablissementGere');
        $this->addRelation('TAgentEtablissement', 'TAgentEtablissement', RelationMap::ONE_TO_MANY, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT', ), null, null, 'TAgentEtablissements');
        $this->addRelation('TRendezVous', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT', ), null, null, 'TRendezVouss');
        $this->addRelation('TTypePrestation', 'TTypePrestation', RelationMap::ONE_TO_MANY, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT', ), null, null, 'TTypePrestations');
    } // buildRelations()

} // TEtablissementTableMap
