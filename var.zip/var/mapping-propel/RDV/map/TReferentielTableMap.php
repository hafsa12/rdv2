<?php



/**
 * This class defines the structure of the 'T_REFERENTIEL' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TReferentielTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TReferentielTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_REFERENTIEL');
        $this->setPhpName('TReferentiel');
        $this->setClassname('TReferentiel');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_REFERENTIEL', 'IdReferentiel', 'INTEGER', true, null, null);
        $this->addForeignKey('CODE_LIBELLE_REFERENTIEL', 'CodeLibelleReferentiel', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_REFERENTIEL' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TParametreFormRelatedByIdRef1', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_REFERENTIEL' => 'ID_REF_1', ), null, null, 'TParametreFormsRelatedByIdRef1');
        $this->addRelation('TParametreFormRelatedByIdRef2', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_REFERENTIEL' => 'ID_REF_2', ), null, null, 'TParametreFormsRelatedByIdRef2');
        $this->addRelation('TParametreFormRelatedByIdRef3', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_REFERENTIEL' => 'ID_REF_3', ), null, null, 'TParametreFormsRelatedByIdRef3');
        $this->addRelation('TValeurReferentiel', 'TValeurReferentiel', RelationMap::ONE_TO_MANY, array('ID_REFERENTIEL' => 'ID_REFERENTIEL', ), null, null, 'TValeurReferentiels');
    } // buildRelations()

} // TReferentielTableMap
