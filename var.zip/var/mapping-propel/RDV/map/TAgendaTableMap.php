<?php



/**
 * This class defines the structure of the 'T_AGENDA' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TAgendaTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TAgendaTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_AGENDA');
        $this->setPhpName('TAgenda');
        $this->setClassname('TAgenda');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_AGENDA', 'IdAgenda', 'INTEGER', true, null, null);
        $this->addColumn('MAX_MOIS_PRISE_RDV', 'MaxMoisPriseRdv', 'INTEGER', false, 2, null);
        $this->addForeignKey('ID_AGENT', 'IdAgent', 'INTEGER', 'T_AGENT', 'ID_AGENT', false, null, null);
        $this->addForeignKey('ID_PRESTATION', 'IdPrestation', 'INTEGER', 'T_PRESTATION', 'ID_PRESTATION', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TAgent', 'TAgent', RelationMap::MANY_TO_ONE, array('ID_AGENT' => 'ID_AGENT', ), null, null);
        $this->addRelation('TPrestation', 'TPrestation', RelationMap::MANY_TO_ONE, array('ID_PRESTATION' => 'ID_PRESTATION', ), null, null);
        $this->addRelation('TPeriode', 'TPeriode', RelationMap::ONE_TO_MANY, array('ID_AGENDA' => 'ID_AGENDA', ), null, null, 'TPeriodes');
    } // buildRelations()

} // TAgendaTableMap
