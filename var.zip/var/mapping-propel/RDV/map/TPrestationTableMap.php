<?php



/**
 * This class defines the structure of the 'T_PRESTATION' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TPrestationTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TPrestationTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_PRESTATION');
        $this->setPhpName('TPrestation');
        $this->setClassname('TPrestation');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_PRESTATION', 'IdPrestation', 'INTEGER', true, null, null);
        $this->addForeignKey('ID_REF_PRESTATION', 'IdRefPrestation', 'INTEGER', 'T_REF_PRESTATION', 'ID_REF_PRESTATION', false, null, null);
        $this->addForeignKey('CODE_LIBELLE_PRESTATION', 'CodeLibellePrestation', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('ID_TYPE_PRESTATION', 'IdTypePrestation', 'INTEGER', 'T_TYPE_PRESTATION', 'ID_TYPE_PRESTATION', true, null, null);
        $this->addColumn('RDV_SIMILAIRE', 'RdvSimilaire', 'CHAR', true, null, '0');
        $this->getColumn('RDV_SIMILAIRE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('NB_JOUR_RDV_SIMILAIRE', 'NbJourRdvSimilaire', 'INTEGER', false, 3, null);
        $this->addColumn('DELAI_MIN', 'DelaiMin', 'INTEGER', true, 4, 0);
        $this->addColumn('PERIODICITE', 'Periodicite', 'INTEGER', true, 3, 0);
        $this->addColumn('RESSOURCE_VISIBLE', 'RessourceVisible', 'CHAR', true, null, '1');
        $this->getColumn('RESSOURCE_VISIBLE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('RESSOURCE_OBLIGATOIRE', 'RessourceObligatoire', 'CHAR', true, null, '0');
        $this->getColumn('RESSOURCE_OBLIGATOIRE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('ID_PARAMETRE_FORM', 'IdParametreForm', 'INTEGER', 'T_PARAMETRE_FORM', 'ID_PARAMETRE_FORM', false, null, null);
        $this->addForeignKey('CODE_COMMENTAIRE', 'CodeCommentaire', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('REFERENT_VISIBLE', 'ReferentVisible', 'CHAR', true, null, '0');
        $this->getColumn('REFERENT_VISIBLE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('ID_PARAMETRAGE_PRESTATION', 'IdParametragePrestation', 'INTEGER', 'T_PARAMETRAGE_PRESTATION', 'ID_PARAMETRAGE_PRESTATION', false, null, null);
        $this->addForeignKey('ID_CHAMPS_SUPP_1', 'IdChampsSupp1', 'INTEGER', 'T_CHAMPS_SUPP', 'ID_CHAMPS_SUPP', false, null, null);
        $this->addForeignKey('ID_CHAMPS_SUPP_2', 'IdChampsSupp2', 'INTEGER', 'T_CHAMPS_SUPP', 'ID_CHAMPS_SUPP', false, null, null);
        $this->addForeignKey('ID_CHAMPS_SUPP_3', 'IdChampsSupp3', 'INTEGER', 'T_CHAMPS_SUPP', 'ID_CHAMPS_SUPP', false, null, null);
        $this->addColumn('VISIOCONFERENCE', 'Visioconference', 'CHAR', true, null, '0');
        $this->getColumn('VISIOCONFERENCE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('RDV_GROUPE', 'RdvGroupe', 'CHAR', true, null, '0');
        $this->getColumn('RDV_GROUPE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('NOMBRE_MAX_PARTICIPANTS', 'NombreMaxParticipants', 'INTEGER', false, null, null);
        $this->addColumn('TYPE_SESSION', 'TypeSession', 'VARCHAR', false, 255, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraductionRelatedByCodeCommentaire', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_COMMENTAIRE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibellePrestation', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_PRESTATION' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TParametragePrestation', 'TParametragePrestation', RelationMap::MANY_TO_ONE, array('ID_PARAMETRAGE_PRESTATION' => 'ID_PARAMETRAGE_PRESTATION', ), null, null);
        $this->addRelation('TParametreForm', 'TParametreForm', RelationMap::MANY_TO_ONE, array('ID_PARAMETRE_FORM' => 'ID_PARAMETRE_FORM', ), null, null);
        $this->addRelation('TRefPrestation', 'TRefPrestation', RelationMap::MANY_TO_ONE, array('ID_REF_PRESTATION' => 'ID_REF_PRESTATION', ), null, null);
        $this->addRelation('TTypePrestation', 'TTypePrestation', RelationMap::MANY_TO_ONE, array('ID_TYPE_PRESTATION' => 'ID_TYPE_PRESTATION', ), null, null);
        $this->addRelation('TChampsSuppRelatedByIdChampsSupp1', 'TChampsSupp', RelationMap::MANY_TO_ONE, array('ID_CHAMPS_SUPP_1' => 'ID_CHAMPS_SUPP', ), null, null);
        $this->addRelation('TChampsSuppRelatedByIdChampsSupp2', 'TChampsSupp', RelationMap::MANY_TO_ONE, array('ID_CHAMPS_SUPP_2' => 'ID_CHAMPS_SUPP', ), null, null);
        $this->addRelation('TChampsSuppRelatedByIdChampsSupp3', 'TChampsSupp', RelationMap::MANY_TO_ONE, array('ID_CHAMPS_SUPP_3' => 'ID_CHAMPS_SUPP', ), null, null);
        $this->addRelation('TAgenda', 'TAgenda', RelationMap::ONE_TO_MANY, array('ID_PRESTATION' => 'ID_PRESTATION', ), null, null, 'TAgendas');
        $this->addRelation('TAgent', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_PRESTATION' => 'ID_PRESTATION_ATTACHE', ), null, null, 'TAgents');
        $this->addRelation('TAgentPrestation', 'TAgentPrestation', RelationMap::ONE_TO_MANY, array('ID_PRESTATION' => 'ID_PRESTATION', ), null, null, 'TAgentPrestations');
        $this->addRelation('TDelaiObtention', 'TDelaiObtention', RelationMap::ONE_TO_MANY, array('ID_PRESTATION' => 'ID_PRESTATION', ), null, null, 'TDelaiObtentions');
        $this->addRelation('TPiecePrestation', 'TPiecePrestation', RelationMap::ONE_TO_MANY, array('ID_PRESTATION' => 'ID_PRESTATION', ), null, null, 'TPiecePrestations');
        $this->addRelation('TRendezVous', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_PRESTATION' => 'ID_PRESTATION', ), null, null, 'TRendezVouss');
    } // buildRelations()

} // TPrestationTableMap
