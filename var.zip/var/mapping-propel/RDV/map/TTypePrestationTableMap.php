<?php



/**
 * This class defines the structure of the 'T_TYPE_PRESTATION' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TTypePrestationTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TTypePrestationTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_TYPE_PRESTATION');
        $this->setPhpName('TTypePrestation');
        $this->setClassname('TTypePrestation');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_TYPE_PRESTATION', 'IdTypePrestation', 'INTEGER', true, null, null);
        $this->addForeignKey('ID_REF_TYPE_PRESTATION', 'IdRefTypePrestation', 'INTEGER', 'T_REF_TYPE_PRESTATION', 'ID_REF_TYPE_PRESTATION', false, null, null);
        $this->addForeignKey('ID_ETABLISSEMENT', 'IdEtablissement', 'INTEGER', 'T_ETABLISSEMENT', 'ID_ETABLISSEMENT', true, null, null);
        $this->addForeignKey('CODE_LIBELLE_TYPE_PRESTATION', 'CodeLibelleTypePrestation', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('VISIBLE_CITOYEN', 'VisibleCitoyen', 'CHAR', true, null, '1');
        $this->getColumn('VISIBLE_CITOYEN', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_TYPE_PRESTATION' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TEtablissement', 'TEtablissement', RelationMap::MANY_TO_ONE, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT', ), null, null);
        $this->addRelation('TRefTypePrestation', 'TRefTypePrestation', RelationMap::MANY_TO_ONE, array('ID_REF_TYPE_PRESTATION' => 'ID_REF_TYPE_PRESTATION', ), null, null);
        $this->addRelation('TPrestation', 'TPrestation', RelationMap::ONE_TO_MANY, array('ID_TYPE_PRESTATION' => 'ID_TYPE_PRESTATION', ), null, null, 'TPrestations');
    } // buildRelations()

} // TTypePrestationTableMap
