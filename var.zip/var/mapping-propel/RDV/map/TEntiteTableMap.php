<?php



/**
 * This class defines the structure of the 'T_ENTITE' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TEntiteTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TEntiteTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_ENTITE');
        $this->setPhpName('TEntite');
        $this->setClassname('TEntite');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_ENTITE', 'IdEntite', 'INTEGER', true, null, null);
        $this->addForeignKey('ID_ENTITE_PARENT', 'IdEntiteParent', 'INTEGER', 'T_ENTITE', 'ID_ENTITE', false, null, null);
        $this->addForeignKey('CODE_LIBELLE', 'CodeLibelle', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('NIVEAU', 'Niveau', 'INTEGER', true, 2, 1);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TEntiteRelatedByIdEntiteParent', 'TEntite', RelationMap::MANY_TO_ONE, array('ID_ENTITE_PARENT' => 'ID_ENTITE', ), null, null);
        $this->addRelation('TEntiteRelatedByIdEntite', 'TEntite', RelationMap::ONE_TO_MANY, array('ID_ENTITE' => 'ID_ENTITE_PARENT', ), null, null, 'TEntitesRelatedByIdEntite');
        $this->addRelation('TEtablissement', 'TEtablissement', RelationMap::ONE_TO_MANY, array('ID_ENTITE' => 'ID_ENTITE', ), null, null, 'TEtablissements');
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_ENTITE' => 'ID_ENTITE', ), null, null, 'TOrganisations');
        $this->addRelation('TReferent', 'TReferent', RelationMap::ONE_TO_MANY, array('ID_ENTITE' => 'ID_ENTITE', ), null, null, 'TReferents');
    } // buildRelations()

} // TEntiteTableMap
