<?php



/**
 * This class defines the structure of the 'T_REF_TYPE_PRESTATION' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TRefTypePrestationTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TRefTypePrestationTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_REF_TYPE_PRESTATION');
        $this->setPhpName('TRefTypePrestation');
        $this->setClassname('TRefTypePrestation');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_REF_TYPE_PRESTATION', 'IdRefTypePrestation', 'INTEGER', true, null, null);
        $this->addForeignKey('ID_ORGANISATION', 'IdOrganisation', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', true, null, null);
        $this->addForeignKey('CODE_LIBELLE', 'CodeLibelle', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', true, null, null);
        $this->addForeignKey('ID_GROUPE', 'IdGroupe', 'INTEGER', 'T_GROUPE', 'ID_GROUPE', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TGroupe', 'TGroupe', RelationMap::MANY_TO_ONE, array('ID_GROUPE' => 'ID_GROUPE', ), null, null);
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null);
        $this->addRelation('TParametragePrestation', 'TParametragePrestation', RelationMap::ONE_TO_MANY, array('ID_REF_TYPE_PRESTATION' => 'ID_REF_TYPE_PRESTATION', ), null, null, 'TParametragePrestations');
        $this->addRelation('TTypePrestation', 'TTypePrestation', RelationMap::ONE_TO_MANY, array('ID_REF_TYPE_PRESTATION' => 'ID_REF_TYPE_PRESTATION', ), null, null, 'TTypePrestations');
    } // buildRelations()

} // TRefTypePrestationTableMap
