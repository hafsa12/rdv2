<?php



/**
 * This class defines the structure of the 'T_TRADUCTION' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TTraductionTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TTraductionTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_TRADUCTION');
        $this->setPhpName('TTraduction');
        $this->setClassname('TTraduction');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_TRADUCTION', 'IdTraduction', 'INTEGER', true, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TAgentRelatedByCodeNomUtilisateur', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_NOM_UTILISATEUR', ), null, null, 'TAgentsRelatedByCodeNomUtilisateur');
        $this->addRelation('TAgentRelatedByCodePrenomUtilisateur', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_PRENOM_UTILISATEUR', ), null, null, 'TAgentsRelatedByCodePrenomUtilisateur');
        $this->addRelation('TAgentRelatedByCodeUtilisateur', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_UTILISATEUR', ), null, null, 'TAgentsRelatedByCodeUtilisateur');
        $this->addRelation('TChampsSupp', 'TChampsSupp', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE', ), null, null, 'TChampsSupps');
        $this->addRelation('TEntite', 'TEntite', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE', ), null, null, 'TEntites');
        $this->addRelation('TEtablissementRelatedByCodeAdresseEtablissement', 'TEtablissement', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_ADRESSE_ETABLISSEMENT', ), null, null, 'TEtablissementsRelatedByCodeAdresseEtablissement');
        $this->addRelation('TEtablissementRelatedByCodeDenominationEtablissement', 'TEtablissement', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_DENOMINATION_ETABLISSEMENT', ), null, null, 'TEtablissementsRelatedByCodeDenominationEtablissement');
        $this->addRelation('TEtablissementRelatedByCodeDescriptionEtablissement', 'TEtablissement', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_DESCRIPTION_ETABLISSEMENT', ), null, null, 'TEtablissementsRelatedByCodeDescriptionEtablissement');
        $this->addRelation('TGroupe', 'TGroupe', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE', ), null, null, 'TGroupes');
        $this->addRelation('TJourFerie', 'TJourFerie', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_JOUR_FERIE', ), null, null, 'TJourFeries');
        $this->addRelation('TOrganisationRelatedByCodeAdresseOrganisation', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_ADRESSE_ORGANISATION', ), null, null, 'TOrganisationsRelatedByCodeAdresseOrganisation');
        $this->addRelation('TOrganisationRelatedByCodeDenominationOrganisation', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_DENOMINATION_ORGANISATION', ), null, null, 'TOrganisationsRelatedByCodeDenominationOrganisation');
        $this->addRelation('TOrganisationRelatedByCodeDescriptionOrganisation', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_DESCRIPTION_ORGANISATION', ), null, null, 'TOrganisationsRelatedByCodeDescriptionOrganisation');
        $this->addRelation('TOrganisationRelatedByCodeLibelleLien1', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_LIEN1', ), null, null, 'TOrganisationsRelatedByCodeLibelleLien1');
        $this->addRelation('TOrganisationRelatedByCodeLibelleLien2', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_LIEN2', ), null, null, 'TOrganisationsRelatedByCodeLibelleLien2');
        $this->addRelation('TOrganisationRelatedByCodeLibelleLien3', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_LIEN3', ), null, null, 'TOrganisationsRelatedByCodeLibelleLien3');
        $this->addRelation('TOrganisationRelatedByCodeMessageBienvenue', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_MESSAGE_BIENVENUE', ), null, null, 'TOrganisationsRelatedByCodeMessageBienvenue');
        $this->addRelation('TOrganisationRelatedByCodeTitreBienvenue', 'TOrganisation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_TITRE_BIENVENUE', ), null, null, 'TOrganisationsRelatedByCodeTitreBienvenue');
        $this->addRelation('TParametragePrestationRelatedByCodeCommentaire', 'TParametragePrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_COMMENTAIRE', ), null, null, 'TParametragePrestationsRelatedByCodeCommentaire');
        $this->addRelation('TParametragePrestationRelatedByCodeAide', 'TParametragePrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_AIDE', ), null, null, 'TParametragePrestationsRelatedByCodeAide');
        $this->addRelation('TParametragePrestationRelatedByCodeCommentaire', 'TParametragePrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_COMMENTAIRE', ), null, null, 'TParametragePrestationsRelatedByCodeCommentaire');
        $this->addRelation('TParametreFormRelatedByCodeCommentaire', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_COMMENTAIRE', ), null, null, 'TParametreFormsRelatedByCodeCommentaire');
        $this->addRelation('TParametreFormRelatedByCodeLibelleRef1', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_REF_1', ), null, null, 'TParametreFormsRelatedByCodeLibelleRef1');
        $this->addRelation('TParametreFormRelatedByCodeLibelleRef2', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_REF_2', ), null, null, 'TParametreFormsRelatedByCodeLibelleRef2');
        $this->addRelation('TParametreFormRelatedByCodeLibelleRef3', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_REF_3', ), null, null, 'TParametreFormsRelatedByCodeLibelleRef3');
        $this->addRelation('TParametreFormRelatedByCodeLibelleText1', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_TEXT_1', ), null, null, 'TParametreFormsRelatedByCodeLibelleText1');
        $this->addRelation('TParametreFormRelatedByCodeLibelleText2', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_TEXT_2', ), null, null, 'TParametreFormsRelatedByCodeLibelleText2');
        $this->addRelation('TParametreFormRelatedByCodeLibelleText3', 'TParametreForm', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_TEXT_3', ), null, null, 'TParametreFormsRelatedByCodeLibelleText3');
        $this->addRelation('TPieceParamPresta', 'TPieceParamPresta', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_PIECE', ), null, null, 'TPieceParamPrestas');
        $this->addRelation('TPiecePrestation', 'TPiecePrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_PIECE', ), null, null, 'TPiecePrestations');
        $this->addRelation('TPrestationRelatedByCodeCommentaire', 'TPrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_COMMENTAIRE', ), null, null, 'TPrestationsRelatedByCodeCommentaire');
        $this->addRelation('TPrestationRelatedByCodeLibellePrestation', 'TPrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_PRESTATION', ), null, null, 'TPrestationsRelatedByCodeLibellePrestation');
        $this->addRelation('TProfil', 'TProfil', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_PROFIL', ), null, null, 'TProfils');
        $this->addRelation('TReferentRelatedByCodeNomReferent', 'TReferent', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_NOM_REFERENT', ), null, null, 'TReferentsRelatedByCodeNomReferent');
        $this->addRelation('TReferentRelatedByCodePrenomReferent', 'TReferent', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_PRENOM_REFERENT', ), null, null, 'TReferentsRelatedByCodePrenomReferent');
        $this->addRelation('TReferentiel', 'TReferentiel', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_REFERENTIEL', ), null, null, 'TReferentiels');
        $this->addRelation('TRefPrestation', 'TRefPrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE', ), null, null, 'TRefPrestations');
        $this->addRelation('TRefPrestationRelatedByCodeAide', 'TRefPrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_AIDE', ), null, null, 'TRefPrestationsRelatedByCodeAide');
        $this->addRelation('TRefPrestationRelatedByCodeLibelle', 'TRefPrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE', ), null, null, 'TRefPrestationsRelatedByCodeLibelle');
        $this->addRelation('TRefTypePrestation', 'TRefTypePrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE', ), null, null, 'TRefTypePrestations');
        $this->addRelation('TTraductionLibelle', 'TTraductionLibelle', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'ID_TRADUCTION', ), null, null, 'TTraductionLibelles');
        $this->addRelation('TTypeEtabRelatedByCodeLibelle', 'TTypeEtab', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE', ), null, null, 'TTypeEtabsRelatedByCodeLibelle');
        $this->addRelation('TTypeEtabRelatedByCodeLibelleEtab', 'TTypeEtab', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_ETAB', ), null, null, 'TTypeEtabsRelatedByCodeLibelleEtab');
        $this->addRelation('TTypePrestation', 'TTypePrestation', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_TYPE_PRESTATION', ), null, null, 'TTypePrestations');
        $this->addRelation('TTypeProfil', 'TTypeProfil', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_TYPE_PROFIL', ), null, null, 'TTypeProfils');
        $this->addRelation('TValeurReferentiel', 'TValeurReferentiel', RelationMap::ONE_TO_MANY, array('ID_TRADUCTION' => 'CODE_LIBELLE_VALEUR_REFERENTIEL', ), null, null, 'TValeurReferentiels');
    } // buildRelations()

} // TTraductionTableMap
