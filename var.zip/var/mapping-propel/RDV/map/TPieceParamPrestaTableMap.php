<?php



/**
 * This class defines the structure of the 'T_PIECE_PARAM_PRESTA' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TPieceParamPrestaTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TPieceParamPrestaTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_PIECE_PARAM_PRESTA');
        $this->setPhpName('TPieceParamPresta');
        $this->setClassname('TPieceParamPresta');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_PIECE_PARAM_PRESTA', 'IdPieceParamPresta', 'INTEGER', true, null, null);
        $this->addForeignKey('ID_PARAMETRAGE_PRESTATION', 'IdParametragePrestation', 'INTEGER', 'T_PARAMETRAGE_PRESTATION', 'ID_PARAMETRAGE_PRESTATION', true, null, null);
        $this->addForeignKey('CODE_LIBELLE_PIECE', 'CodeLibellePiece', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', true, null, null);
        $this->addForeignKey('ID_BLOB_PIECE', 'IdBlobPiece', 'INTEGER', 'T_BLOB', 'ID_BLOB', false, null, null);
        $this->addColumn('UPLOAD', 'Upload', 'CHAR', true, null, '0');
        $this->getColumn('UPLOAD', false)->setValueSet(array (
  0 => '0',
  1 => '1',
  2 => '2',
));
        $this->addColumn('OBLIGATOIRE', 'Obligatoire', 'CHAR', true, null, '1');
        $this->getColumn('OBLIGATOIRE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TBlob', 'TBlob', RelationMap::MANY_TO_ONE, array('ID_BLOB_PIECE' => 'ID_BLOB', ), null, null);
        $this->addRelation('TParametragePrestation', 'TParametragePrestation', RelationMap::MANY_TO_ONE, array('ID_PARAMETRAGE_PRESTATION' => 'ID_PARAMETRAGE_PRESTATION', ), null, null);
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_PIECE' => 'ID_TRADUCTION', ), null, null);
    } // buildRelations()

} // TPieceParamPrestaTableMap
