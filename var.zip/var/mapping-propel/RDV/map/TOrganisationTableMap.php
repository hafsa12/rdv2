<?php



/**
 * This class defines the structure of the 'T_ORGANISATION' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TOrganisationTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TOrganisationTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_ORGANISATION');
        $this->setPhpName('TOrganisation');
        $this->setClassname('TOrganisation');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_ORGANISATION', 'IdOrganisation', 'INTEGER', true, null, null);
        $this->addForeignKey('CODE_DENOMINATION_ORGANISATION', 'CodeDenominationOrganisation', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('CODE_ADRESSE_ORGANISATION', 'CodeAdresseOrganisation', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('CODE_POSTAL', 'CodePostal', 'VARCHAR', true, 5, null);
        $this->addColumn('TELEPHONE_ORGANISATION', 'TelephoneOrganisation', 'VARCHAR', false, 200, null);
        $this->addColumn('MAIL_ORGANISATION', 'MailOrganisation', 'VARCHAR', false, 45, null);
        $this->addForeignKey('CODE_DESCRIPTION_ORGANISATION', 'CodeDescriptionOrganisation', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('CODE_TITRE_BIENVENUE', 'CodeTitreBienvenue', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('CODE_MESSAGE_BIENVENUE', 'CodeMessageBienvenue', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('ID_ENTITE', 'IdEntite', 'INTEGER', 'T_ENTITE', 'ID_ENTITE', true, null, null);
        $this->addColumn('TYPE_PRESTATION', 'TypePrestation', 'CHAR', true, null, '0');
        $this->getColumn('TYPE_PRESTATION', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addForeignKey('CODE_LIBELLE_LIEN1', 'CodeLibelleLien1', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('URL_LIEN1', 'UrlLien1', 'VARCHAR', false, 255, null);
        $this->addForeignKey('CODE_LIBELLE_LIEN2', 'CodeLibelleLien2', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('URL_LIEN2', 'UrlLien2', 'VARCHAR', false, 255, null);
        $this->addForeignKey('CODE_LIBELLE_LIEN3', 'CodeLibelleLien3', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('URL_LIEN3', 'UrlLien3', 'VARCHAR', false, 255, null);
        $this->addColumn('ACRONYME', 'Acronyme', 'VARCHAR', true, 50, null);
        $this->addColumn('NOM_DOMAINE', 'NomDomaine', 'VARCHAR', true, 255, null);
        $this->addForeignKey('ID_PARAMETRE_FORM', 'IdParametreForm', 'INTEGER', 'T_PARAMETRE_FORM', 'ID_PARAMETRE_FORM', false, null, null);
        $this->addColumn('RESSOURCE', 'Ressource', 'CHAR', true, null, '0');
        $this->getColumn('RESSOURCE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraductionRelatedByCodeAdresseOrganisation', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_ADRESSE_ORGANISATION' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeDenominationOrganisation', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_DENOMINATION_ORGANISATION' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeDescriptionOrganisation', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_DESCRIPTION_ORGANISATION' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleLien1', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_LIEN1' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleLien2', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_LIEN2' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeLibelleLien3', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_LIEN3' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeMessageBienvenue', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_MESSAGE_BIENVENUE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeTitreBienvenue', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_TITRE_BIENVENUE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TParametreForm', 'TParametreForm', RelationMap::MANY_TO_ONE, array('ID_PARAMETRE_FORM' => 'ID_PARAMETRE_FORM', ), null, null);
        $this->addRelation('TEntite', 'TEntite', RelationMap::MANY_TO_ONE, array('ID_ENTITE' => 'ID_ENTITE', ), null, null);
        $this->addRelation('TAgentRelatedByIdOrganisationAttache', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION_ATTACHE', ), null, null, 'TAgentsRelatedByIdOrganisationAttache');
        $this->addRelation('TAgentRelatedByIdOrganisationGere', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION_GERE', ), null, null, 'TAgentsRelatedByIdOrganisationGere');
        $this->addRelation('TChampsSupp', 'TChampsSupp', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TChampsSupps');
        $this->addRelation('TEtablissement', 'TEtablissement', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TEtablissements');
        $this->addRelation('TGroupe', 'TGroupe', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TGroupes');
        $this->addRelation('TJourFerie', 'TJourFerie', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISME', ), null, null, 'TJourFeries');
        $this->addRelation('TParametragePrestation', 'TParametragePrestation', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TParametragePrestations');
        $this->addRelation('TProfil', 'TProfil', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TProfils');
        $this->addRelation('TRefPrestation', 'TRefPrestation', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TRefPrestations');
        $this->addRelation('TRefTypePrestation', 'TRefTypePrestation', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TRefTypePrestations');
        $this->addRelation('TValeurReferentiel', 'TValeurReferentiel', RelationMap::ONE_TO_MANY, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null, 'TValeurReferentiels');
    } // buildRelations()

} // TOrganisationTableMap
