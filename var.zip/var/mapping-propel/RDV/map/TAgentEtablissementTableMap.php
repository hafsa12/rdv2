<?php



/**
 * This class defines the structure of the 'T_AGENT_ETABLISSEMENT' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TAgentEtablissementTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TAgentEtablissementTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_AGENT_ETABLISSEMENT');
        $this->setPhpName('TAgentEtablissement');
        $this->setClassname('TAgentEtablissement');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(false);
        // columns
        $this->addForeignPrimaryKey('ID_AGENT', 'IdAgent', 'INTEGER' , 'T_AGENT', 'ID_AGENT', true, null, null);
        $this->addForeignPrimaryKey('ID_ETABLISSEMENT', 'IdEtablissement', 'INTEGER' , 'T_ETABLISSEMENT', 'ID_ETABLISSEMENT', true, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TAgent', 'TAgent', RelationMap::MANY_TO_ONE, array('ID_AGENT' => 'ID_AGENT', ), null, null);
        $this->addRelation('TEtablissement', 'TEtablissement', RelationMap::MANY_TO_ONE, array('ID_ETABLISSEMENT' => 'ID_ETABLISSEMENT', ), null, null);
    } // buildRelations()

} // TAgentEtablissementTableMap
