<?php



/**
 * This class defines the structure of the 'T_PERIODE' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TPeriodeTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TPeriodeTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_PERIODE');
        $this->setPhpName('TPeriode');
        $this->setClassname('TPeriode');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_PERIODE', 'IdPeriode', 'INTEGER', true, null, null);
        $this->addColumn('DEBUT_PERIODE', 'DebutPeriode', 'DATE', false, null, null);
        $this->addColumn('FIN_PERIODE', 'FinPeriode', 'DATE', false, null, null);
        $this->addColumn('LUNDI_HEURE_DEBUT_1', 'LundiHeureDebut1', 'TIME', false, null, null);
        $this->addColumn('LUNDI_HEURE_FIN_1', 'LundiHeureFin1', 'TIME', false, null, null);
        $this->addColumn('LUNDI_CAPACITE_1', 'LundiCapacite1', 'INTEGER', true, 3, null);
        $this->addColumn('LUNDI_NB_RDV_SITE_1', 'LundiNbRdvSite1', 'INTEGER', false, 3, null);
        $this->addColumn('LUNDI_HEURE_DEBUT_2', 'LundiHeureDebut2', 'TIME', false, null, null);
        $this->addColumn('LUNDI_HEURE_FIN_2', 'LundiHeureFin2', 'TIME', false, null, null);
        $this->addColumn('LUNDI_CAPACITE_2', 'LundiCapacite2', 'INTEGER', false, 3, null);
        $this->addColumn('LUNDI_NB_RDV_SITE_2', 'LundiNbRdvSite2', 'INTEGER', true, 3, null);
        $this->addColumn('MARDI_HEURE_DEBUT_1', 'MardiHeureDebut1', 'TIME', false, null, null);
        $this->addColumn('MARDI_HEURE_FIN_1', 'MardiHeureFin1', 'TIME', false, null, null);
        $this->addColumn('MARDI_CAPACITE_1', 'MardiCapacite1', 'INTEGER', false, 3, null);
        $this->addColumn('MARDI_NB_RDV_SITE_1', 'MardiNbRdvSite1', 'INTEGER', true, 3, null);
        $this->addColumn('MARDI_HEURE_DEBUT_2', 'MardiHeureDebut2', 'TIME', false, null, null);
        $this->addColumn('MARDI_HEURE_FIN_2', 'MardiHeureFin2', 'TIME', false, null, null);
        $this->addColumn('MARDI_CAPACITE_2', 'MardiCapacite2', 'INTEGER', false, 3, null);
        $this->addColumn('MARDI_NB_RDV_SITE_2', 'MardiNbRdvSite2', 'INTEGER', true, 3, null);
        $this->addColumn('MERCREDI_HEURE_DEBUT_1', 'MercrediHeureDebut1', 'TIME', false, null, null);
        $this->addColumn('MERCREDI_HEURE_FIN_1', 'MercrediHeureFin1', 'TIME', false, null, null);
        $this->addColumn('MERCREDI_CAPACITE_1', 'MercrediCapacite1', 'INTEGER', false, 3, null);
        $this->addColumn('MERCREDI_NB_RDV_SITE_1', 'MercrediNbRdvSite1', 'INTEGER', true, 3, null);
        $this->addColumn('MERCREDI_HEURE_DEBUT_2', 'MercrediHeureDebut2', 'TIME', false, null, null);
        $this->addColumn('MERCREDI_HEURE_FIN_2', 'MercrediHeureFin2', 'TIME', false, null, null);
        $this->addColumn('MERCREDI_CAPACITE_2', 'MercrediCapacite2', 'INTEGER', false, 3, null);
        $this->addColumn('MERCREDI_NB_RDV_SITE_2', 'MercrediNbRdvSite2', 'INTEGER', true, 3, null);
        $this->addColumn('JEUDI_HEURE_DEBUT_1', 'JeudiHeureDebut1', 'TIME', false, null, null);
        $this->addColumn('JEUDI_HEURE_FIN_1', 'JeudiHeureFin1', 'TIME', false, null, null);
        $this->addColumn('JEUDI_CAPACITE_1', 'JeudiCapacite1', 'INTEGER', false, 3, null);
        $this->addColumn('JEUDI_NB_RDV_SITE_1', 'JeudiNbRdvSite1', 'INTEGER', true, 3, null);
        $this->addColumn('JEUDI_HEURE_DEBUT_2', 'JeudiHeureDebut2', 'TIME', false, null, null);
        $this->addColumn('JEUDI_HEURE_FIN_2', 'JeudiHeureFin2', 'TIME', false, null, null);
        $this->addColumn('JEUDI_CAPACITE_2', 'JeudiCapacite2', 'INTEGER', false, 3, null);
        $this->addColumn('JEUDI_NB_RDV_SITE_2', 'JeudiNbRdvSite2', 'INTEGER', true, 3, null);
        $this->addColumn('VENDREDI_HEURE_DEBUT_1', 'VendrediHeureDebut1', 'TIME', false, null, null);
        $this->addColumn('VENDREDI_HEURE_FIN_1', 'VendrediHeureFin1', 'TIME', false, null, null);
        $this->addColumn('VENDREDI_CAPACITE_1', 'VendrediCapacite1', 'INTEGER', false, 3, null);
        $this->addColumn('VENDREDI_NB_RDV_SITE_1', 'VendrediNbRdvSite1', 'INTEGER', true, 3, null);
        $this->addColumn('VENDREDI_HEURE_DEBUT_2', 'VendrediHeureDebut2', 'TIME', false, null, null);
        $this->addColumn('VENDREDI_HEURE_FIN_2', 'VendrediHeureFin2', 'TIME', false, null, null);
        $this->addColumn('VENDREDI_CAPACITE_2', 'VendrediCapacite2', 'INTEGER', false, 3, null);
        $this->addColumn('VENDREDI_NB_RDV_SITE_2', 'VendrediNbRdvSite2', 'INTEGER', true, 3, null);
        $this->addColumn('SAMEDI_HEURE_DEBUT_1', 'SamediHeureDebut1', 'TIME', false, null, null);
        $this->addColumn('SAMEDI_HEURE_FIN_1', 'SamediHeureFin1', 'TIME', false, null, null);
        $this->addColumn('SAMEDI_CAPACITE_1', 'SamediCapacite1', 'INTEGER', false, 3, null);
        $this->addColumn('SAMEDI_NB_RDV_SITE_1', 'SamediNbRdvSite1', 'INTEGER', true, 3, null);
        $this->addColumn('SAMEDI_HEURE_DEBUT_2', 'SamediHeureDebut2', 'TIME', false, null, null);
        $this->addColumn('SAMEDI_HEURE_FIN_2', 'SamediHeureFin2', 'TIME', false, null, null);
        $this->addColumn('SAMEDI_CAPACITE_2', 'SamediCapacite2', 'INTEGER', false, 3, null);
        $this->addColumn('SAMEDI_NB_RDV_SITE_2', 'SamediNbRdvSite2', 'INTEGER', true, 3, null);
        $this->addColumn('DIMANCHE_HEURE_DEBUT_1', 'DimancheHeureDebut1', 'TIME', false, null, null);
        $this->addColumn('DIMANCHE_HEURE_FIN_1', 'DimancheHeureFin1', 'TIME', false, null, null);
        $this->addColumn('DIMANCHE_CAPACITE_1', 'DimancheCapacite1', 'INTEGER', false, 3, null);
        $this->addColumn('DIMANCHE_NB_RDV_SITE_1', 'DimancheNbRdvSite1', 'INTEGER', true, 3, null);
        $this->addColumn('DIMANCHE_HEURE_DEBUT_2', 'DimancheHeureDebut2', 'TIME', false, null, null);
        $this->addColumn('DIMANCHE_HEURE_FIN_2', 'DimancheHeureFin2', 'TIME', false, null, null);
        $this->addColumn('DIMANCHE_CAPACITE_2', 'DimancheCapacite2', 'INTEGER', false, 3, null);
        $this->addColumn('DIMANCHE_NB_RDV_SITE_2', 'DimancheNbRdvSite2', 'INTEGER', true, 3, null);
        $this->addForeignKey('ID_AGENDA', 'IdAgenda', 'INTEGER', 'T_AGENDA', 'ID_AGENDA', true, null, null);
        $this->addColumn('PERIODICITE', 'Periodicite', 'INTEGER', true, 3, 0);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TAgenda', 'TAgenda', RelationMap::MANY_TO_ONE, array('ID_AGENDA' => 'ID_AGENDA', ), null, null);
    } // buildRelations()

} // TPeriodeTableMap
