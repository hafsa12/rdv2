<?php



/**
 * This class defines the structure of the 'T_JOUR_FERIE' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TJourFerieTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TJourFerieTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_JOUR_FERIE');
        $this->setPhpName('TJourFerie');
        $this->setClassname('TJourFerie');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_JOUR_FERIE', 'IdJourFerie', 'INTEGER', true, null, null);
        $this->addForeignKey('CODE_LIBELLE_JOUR_FERIE', 'CodeLibelleJourFerie', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('JOUR', 'Jour', 'INTEGER', false, 2, null);
        $this->addColumn('MOIS', 'Mois', 'INTEGER', false, 2, null);
        $this->addColumn('ANNEE', 'Annee', 'INTEGER', false, 4, null);
        $this->addForeignKey('ID_ORGANISME', 'IdOrganisme', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', true, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_JOUR_FERIE' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISME' => 'ID_ORGANISATION', ), null, null);
    } // buildRelations()

} // TJourFerieTableMap
