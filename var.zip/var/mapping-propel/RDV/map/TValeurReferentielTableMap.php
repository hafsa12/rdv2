<?php



/**
 * This class defines the structure of the 'T_VALEUR_REFERENTIEL' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TValeurReferentielTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TValeurReferentielTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_VALEUR_REFERENTIEL');
        $this->setPhpName('TValeurReferentiel');
        $this->setClassname('TValeurReferentiel');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(false);
        // columns
        $this->addPrimaryKey('ID_VALEUR_REFERENTIEL', 'IdValeurReferentiel', 'INTEGER', true, null, null);
        $this->addForeignKey('CODE_LIBELLE_VALEUR_REFERENTIEL', 'CodeLibelleValeurReferentiel', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('ID_REFERENTIEL', 'IdReferentiel', 'INTEGER', 'T_REFERENTIEL', 'ID_REFERENTIEL', true, null, null);
        $this->addForeignKey('ID_ORGANISATION', 'IdOrganisation', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', true, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_VALEUR_REFERENTIEL' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null);
        $this->addRelation('TReferentiel', 'TReferentiel', RelationMap::MANY_TO_ONE, array('ID_REFERENTIEL' => 'ID_REFERENTIEL', ), null, null);
        $this->addRelation('TCitoyenRelatedByIdRef1', 'TCitoyen', RelationMap::ONE_TO_MANY, array('ID_VALEUR_REFERENTIEL' => 'ID_REF_1', ), null, null, 'TCitoyensRelatedByIdRef1');
        $this->addRelation('TCitoyenRelatedByIdRef2', 'TCitoyen', RelationMap::ONE_TO_MANY, array('ID_VALEUR_REFERENTIEL' => 'ID_REF_2', ), null, null, 'TCitoyensRelatedByIdRef2');
        $this->addRelation('TCitoyenRelatedByIdRef3', 'TCitoyen', RelationMap::ONE_TO_MANY, array('ID_VALEUR_REFERENTIEL' => 'ID_REF_3', ), null, null, 'TCitoyensRelatedByIdRef3');
        $this->addRelation('TRendezVous', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_VALEUR_REFERENTIEL' => 'ID_VALEUR_REFERENTIEL', ), null, null, 'TRendezVouss');
    } // buildRelations()

} // TValeurReferentielTableMap
