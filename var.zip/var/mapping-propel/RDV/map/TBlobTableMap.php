<?php



/**
 * This class defines the structure of the 'T_BLOB' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TBlobTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TBlobTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_BLOB');
        $this->setPhpName('TBlob');
        $this->setClassname('TBlob');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_BLOB', 'IdBlob', 'INTEGER', true, null, null);
        $this->addColumn('NOM_BLOB', 'NomBlob', 'VARCHAR', true, 150, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TBlobRdv', 'TBlobRdv', RelationMap::ONE_TO_MANY, array('ID_BLOB' => 'ID_BLOB', ), null, null, 'TBlobRdvs');
        $this->addRelation('TEtablissement', 'TEtablissement', RelationMap::ONE_TO_MANY, array('ID_BLOB' => 'ID_BLOB_PLAN', ), null, null, 'TEtablissements');
        $this->addRelation('TPieceParamPresta', 'TPieceParamPresta', RelationMap::ONE_TO_MANY, array('ID_BLOB' => 'ID_BLOB_PIECE', ), null, null, 'TPieceParamPrestas');
        $this->addRelation('TPiecePrestation', 'TPiecePrestation', RelationMap::ONE_TO_MANY, array('ID_BLOB' => 'ID_BLOB_PIECE', ), null, null, 'TPiecePrestations');
    } // buildRelations()

} // TBlobTableMap
