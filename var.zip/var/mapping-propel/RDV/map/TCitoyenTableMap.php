<?php



/**
 * This class defines the structure of the 'T_CITOYEN' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TCitoyenTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TCitoyenTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_CITOYEN');
        $this->setPhpName('TCitoyen');
        $this->setClassname('TCitoyen');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_CITOYEN', 'IdCitoyen', 'INTEGER', true, null, null);
        $this->addColumn('RAISON_SOCIAL', 'RaisonSocial', 'VARCHAR', true, 200, null);
        $this->addColumn('NOM', 'Nom', 'VARCHAR', false, 45, null);
        $this->addColumn('PRENOM', 'Prenom', 'VARCHAR', false, 45, null);
        $this->addColumn('DATE_NAISSANCE', 'DateNaissance', 'DATE', false, null, null);
        $this->addColumn('IDENTIFIANT', 'Identifiant', 'VARCHAR', false, 45, null);
        $this->addColumn('ADRESSE', 'Adresse', 'LONGVARCHAR', true, null, null);
        $this->addColumn('MAIL', 'Mail', 'VARCHAR', false, 45, null);
        $this->addColumn('TELEPHONE', 'Telephone', 'VARCHAR', false, 45, null);
        $this->addColumn('FAX', 'Fax', 'VARCHAR', true, 45, null);
        $this->addColumn('TEXT_1', 'Text1', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('ID_REF_1', 'IdRef1', 'INTEGER', 'T_VALEUR_REFERENTIEL', 'ID_VALEUR_REFERENTIEL', false, null, null);
        $this->addColumn('TEXT_2', 'Text2', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('ID_REF_2', 'IdRef2', 'INTEGER', 'T_VALEUR_REFERENTIEL', 'ID_VALEUR_REFERENTIEL', false, null, null);
        $this->addColumn('TEXT_3', 'Text3', 'LONGVARCHAR', false, null, null);
        $this->addForeignKey('ID_REF_3', 'IdRef3', 'INTEGER', 'T_VALEUR_REFERENTIEL', 'ID_VALEUR_REFERENTIEL', false, null, null);
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TValeurReferentielRelatedByIdRef1', 'TValeurReferentiel', RelationMap::MANY_TO_ONE, array('ID_REF_1' => 'ID_VALEUR_REFERENTIEL', ), null, null);
        $this->addRelation('TValeurReferentielRelatedByIdRef2', 'TValeurReferentiel', RelationMap::MANY_TO_ONE, array('ID_REF_2' => 'ID_VALEUR_REFERENTIEL', ), null, null);
        $this->addRelation('TValeurReferentielRelatedByIdRef3', 'TValeurReferentiel', RelationMap::MANY_TO_ONE, array('ID_REF_3' => 'ID_VALEUR_REFERENTIEL', ), null, null);
        $this->addRelation('TRendezVous', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_CITOYEN' => 'ID_CITOYEN', ), null, null, 'TRendezVouss');
    } // buildRelations()

} // TCitoyenTableMap
