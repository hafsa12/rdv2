<?php



/**
 * This class defines the structure of the 'T_AGENT' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TAgentTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TAgentTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_AGENT');
        $this->setPhpName('TAgent');
        $this->setClassname('TAgent');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_AGENT', 'IdAgent', 'INTEGER', true, null, null);
        $this->addColumn('LOGIN', 'Login', 'VARCHAR', false, 45, null);
        $this->addColumn('MOT_DE_PASSE', 'MotDePasse', 'VARCHAR', false, 45, null);
        $this->addForeignKey('CODE_NOM_UTILISATEUR', 'CodeNomUtilisateur', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('CODE_PRENOM_UTILISATEUR', 'CodePrenomUtilisateur', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addForeignKey('CODE_UTILISATEUR', 'CodeUtilisateur', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', false, null, null);
        $this->addColumn('EMAIL_UTILISATEUR', 'EmailUtilisateur', 'VARCHAR', false, 45, null);
        $this->addColumn('TELEPHONE_UTILISATEUR', 'TelephoneUtilisateur', 'VARCHAR', false, 45, null);
        $this->addForeignKey('ID_ETABLISSEMENT_ATTACHE', 'IdEtablissementAttache', 'INTEGER', 'T_ETABLISSEMENT', 'ID_ETABLISSEMENT', false, null, null);
        $this->addForeignKey('ID_PROFIL', 'IdProfil', 'INTEGER', 'T_PROFIL', 'ID_PROFIL', false, null, null);
        $this->addForeignKey('ID_ORGANISATION_ATTACHE', 'IdOrganisationAttache', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', false, null, null);
        $this->addColumn('TENTATIVES_MDP', 'TentativesMdp', 'INTEGER', true, 1, null);
        $this->addForeignKey('ID_PRESTATION_ATTACHE', 'IdPrestationAttache', 'INTEGER', 'T_PRESTATION', 'ID_PRESTATION', false, null, null);
        $this->addForeignKey('ID_ETABLISSEMENT_GERE', 'IdEtablissementGere', 'INTEGER', 'T_ETABLISSEMENT', 'ID_ETABLISSEMENT', false, null, null);
        $this->addForeignKey('ID_ORGANISATION_GERE', 'IdOrganisationGere', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', false, null, null);
        $this->addColumn('ACTIF', 'Actif', 'INTEGER', true, 1, 1);
        $this->addColumn('ALERTE', 'Alerte', 'CHAR', true, null, '0');
        $this->getColumn('ALERTE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraductionRelatedByCodeNomUtilisateur', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_NOM_UTILISATEUR' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TTraductionRelatedByCodePrenomUtilisateur', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_PRENOM_UTILISATEUR' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TEtablissementRelatedByIdEtablissementAttache', 'TEtablissement', RelationMap::MANY_TO_ONE, array('ID_ETABLISSEMENT_ATTACHE' => 'ID_ETABLISSEMENT', ), null, null);
        $this->addRelation('TEtablissementRelatedByIdEtablissementGere', 'TEtablissement', RelationMap::MANY_TO_ONE, array('ID_ETABLISSEMENT_GERE' => 'ID_ETABLISSEMENT', ), null, null);
        $this->addRelation('TOrganisationRelatedByIdOrganisationAttache', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISATION_ATTACHE' => 'ID_ORGANISATION', ), null, null);
        $this->addRelation('TOrganisationRelatedByIdOrganisationGere', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISATION_GERE' => 'ID_ORGANISATION', ), null, null);
        $this->addRelation('TPrestation', 'TPrestation', RelationMap::MANY_TO_ONE, array('ID_PRESTATION_ATTACHE' => 'ID_PRESTATION', ), null, null);
        $this->addRelation('TProfil', 'TProfil', RelationMap::MANY_TO_ONE, array('ID_PROFIL' => 'ID_PROFIL', ), null, null);
        $this->addRelation('TTraductionRelatedByCodeUtilisateur', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_UTILISATEUR' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TAgenda', 'TAgenda', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT', ), null, null, 'TAgendas');
        $this->addRelation('TAgentEtablissement', 'TAgentEtablissement', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT', ), null, null, 'TAgentEtablissements');
        $this->addRelation('TAgentPrestation', 'TAgentPrestation', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT', ), null, null, 'TAgentPrestations');
        $this->addRelation('TPeriodeIndisponibilite', 'TPeriodeIndisponibilite', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT', ), null, null, 'TPeriodeIndisponibilites');
        $this->addRelation('TRendezVousRelatedByIdAgentAccueil', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT_ACCUEIL', ), null, null, 'TRendezVoussRelatedByIdAgentAccueil');
        $this->addRelation('TRendezVousRelatedByIdAgentAnnulation', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT_ANNULATION', ), null, null, 'TRendezVoussRelatedByIdAgentAnnulation');
        $this->addRelation('TRendezVousRelatedByIdAgentConfirmation', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT_CONFIRMATION', ), null, null, 'TRendezVoussRelatedByIdAgentConfirmation');
        $this->addRelation('TRendezVousRelatedByIdAgentRessource', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT_RESSOURCE', ), null, null, 'TRendezVoussRelatedByIdAgentRessource');
        $this->addRelation('TRendezVousRelatedByIdAgentTeleoperateur', 'TRendezVous', RelationMap::ONE_TO_MANY, array('ID_AGENT' => 'ID_AGENT_TELEOPERATEUR', ), null, null, 'TRendezVoussRelatedByIdAgentTeleoperateur');
    } // buildRelations()

} // TAgentTableMap
