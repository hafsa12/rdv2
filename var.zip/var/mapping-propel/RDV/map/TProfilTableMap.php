<?php



/**
 * This class defines the structure of the 'T_PROFIL' table.
 *
 *
 *
 * This map class is used by Propel to do runtime db structure discovery.
 * For example, the createSelectSql() method checks the type of a given column used in an
 * ORDER BY clause to know whether it needs to apply SQL to make the ORDER BY case-insensitive
 * (i.e. if it's a text column type).
 *
 * @package    propel.generator.RDV.map
 */
class TProfilTableMap extends TableMap
{

    /**
     * The (dot-path) name of this class
     */
    const CLASS_NAME = 'RDV.map.TProfilTableMap';

    /**
     * Initialize the table attributes, columns and validators
     * Relations are not initialized by this method since they are lazy loaded
     *
     * @return void
     * @throws PropelException
     */
    public function initialize()
    {
        // attributes
        $this->setName('T_PROFIL');
        $this->setPhpName('TProfil');
        $this->setClassname('TProfil');
        $this->setPackage('RDV');
        $this->setUseIdGenerator(true);
        // columns
        $this->addPrimaryKey('ID_PROFIL', 'IdProfil', 'INTEGER', true, null, null);
        $this->addForeignKey('ID_ORGANISATION', 'IdOrganisation', 'INTEGER', 'T_ORGANISATION', 'ID_ORGANISATION', true, null, null);
        $this->addForeignKey('CODE_LIBELLE_PROFIL', 'CodeLibelleProfil', 'INTEGER', 'T_TRADUCTION', 'ID_TRADUCTION', true, null, null);
        $this->addForeignKey('ID_TYPE_PROFIL', 'IdTypeProfil', 'INTEGER', 'T_TYPE_PROFIL', 'ID_TYPE_PROFIL', true, null, null);
        $this->addColumn('ORGANISATION', 'Organisation', 'CHAR', true, null, '0');
        $this->getColumn('ORGANISATION', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('ETABLISSEMENT', 'Etablissement', 'CHAR', true, null, '0');
        $this->getColumn('ETABLISSEMENT', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('REFERENTIEL_TYPE_PRESTATION', 'ReferentielTypePrestation', 'CHAR', true, null, '0');
        $this->getColumn('REFERENTIEL_TYPE_PRESTATION', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('PARAMETRAGE_PRESTATION', 'ParametragePrestation', 'CHAR', true, null, '0');
        $this->getColumn('PARAMETRAGE_PRESTATION', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('NIVEAU_1', 'Niveau1', 'CHAR', true, null, '0');
        $this->getColumn('NIVEAU_1', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('NIVEAU_2', 'Niveau2', 'CHAR', true, null, '0');
        $this->getColumn('NIVEAU_2', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('NIVEAU_3', 'Niveau3', 'CHAR', true, null, '0');
        $this->getColumn('NIVEAU_3', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('JOURS_FERIES', 'JoursFeries', 'CHAR', true, null, '0');
        $this->getColumn('JOURS_FERIES', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('AGENDA', 'Agenda', 'CHAR', true, null, '0');
        $this->getColumn('AGENDA', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('JOURS_INDISPONIBILITES', 'JoursIndisponibilites', 'CHAR', true, null, '0');
        $this->getColumn('JOURS_INDISPONIBILITES', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('UTILISATEURS', 'Utilisateurs', 'CHAR', true, null, '0');
        $this->getColumn('UTILISATEURS', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('PROFILS', 'Profils', 'CHAR', true, null, '0');
        $this->getColumn('PROFILS', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('GESTIONS_DES_RENDEZ_VOUS', 'GestionsDesRendezVous', 'CHAR', true, null, '0');
        $this->getColumn('GESTIONS_DES_RENDEZ_VOUS', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('RAPPORT_NBR_RDV', 'RapportNbrRdv', 'CHAR', true, null, '0');
        $this->getColumn('RAPPORT_NBR_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('RAPPORT_DELAI_OBTENTION', 'RapportDelaiObtention', 'CHAR', true, null, '0');
        $this->getColumn('RAPPORT_DELAI_OBTENTION', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('RAPPORT_ACTIVITE', 'RapportActivite', 'CHAR', true, null, '0');
        $this->getColumn('RAPPORT_ACTIVITE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('PERFORMANCE_GLOBALE', 'PerformanceGlobale', 'CHAR', true, null, '0');
        $this->getColumn('PERFORMANCE_GLOBALE', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('REFERENTIEL_PRESTATION', 'ReferentielPrestation', 'CHAR', true, null, '0');
        $this->getColumn('REFERENTIEL_PRESTATION', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('RECHERCHE_ETENDUE_RDV', 'RechercheEtendueRdv', 'CHAR', true, null, '0');
        $this->getColumn('RECHERCHE_ETENDUE_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('ALERT_RAPPORT_HEBDO', 'AlertRapportHebdo', 'CHAR', true, null, '0');
        $this->getColumn('ALERT_RAPPORT_HEBDO', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('ALERT_RAPPORT_MENS', 'AlertRapportMens', 'CHAR', true, null, '0');
        $this->getColumn('ALERT_RAPPORT_MENS', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('MODIF_DUREE_RDV', 'ModifDureeRdv', 'CHAR', true, null, '0');
        $this->getColumn('MODIF_DUREE_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('AFFECTATION_RDV', 'AffectationRdv', 'CHAR', true, null, '0');
        $this->getColumn('AFFECTATION_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        $this->addColumn('ANNULATION_RDV', 'AnnulationRdv', 'CHAR', true, null, '1');
        $this->getColumn('ANNULATION_RDV', false)->setValueSet(array (
  0 => '0',
  1 => '1',
));
        // validators
    } // initialize()

    /**
     * Build the RelationMap objects for this table relationships
     */
    public function buildRelations()
    {
        $this->addRelation('TTraduction', 'TTraduction', RelationMap::MANY_TO_ONE, array('CODE_LIBELLE_PROFIL' => 'ID_TRADUCTION', ), null, null);
        $this->addRelation('TOrganisation', 'TOrganisation', RelationMap::MANY_TO_ONE, array('ID_ORGANISATION' => 'ID_ORGANISATION', ), null, null);
        $this->addRelation('TTypeProfil', 'TTypeProfil', RelationMap::MANY_TO_ONE, array('ID_TYPE_PROFIL' => 'ID_TYPE_PROFIL', ), null, null);
        $this->addRelation('TAgent', 'TAgent', RelationMap::ONE_TO_MANY, array('ID_PROFIL' => 'ID_PROFIL', ), null, null, 'TAgents');
    } // buildRelations()

} // TProfilTableMap
