<?php

class TPieceParamForm extends BaseTPieceParamForm
{

}
