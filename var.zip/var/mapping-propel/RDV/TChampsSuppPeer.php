<?php



/**
 * Skeleton subclass for performing query and update operations on the 'T_CHAMPS_SUPP' table.
 *
 *
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 * @package    propel.generator.RDV
 */
class TChampsSuppPeer extends BaseTChampsSuppPeer
{
    /**
     * Retourne les champsSupp
     * @param mot cle , lang
     * @return array champsSupp
     */

    public function getChampsSuppByCriteres($criteriaVo, $count=false ,$con=null) {

        if($count) {
            $sql =  " SELECT COUNT(DISTINCT(ID_CHAMPS_SUPP)) AS NBRE_ELMNTS";
        }
        else {
            $sql =  " SELECT DISTINCT(ID_CHAMPS_SUPP), TTL1.LIBELLE, CODE_CHAMPS ";
        }

        $sql .=	" FROM T_TRADUCTION_LIBELLE TTL1, T_CHAMPS_SUPP CS ".
            " WHERE TTL1.ID_TRADUCTION=CS.CODE_LIBELLE".
            " AND TTL1.LANG='".$criteriaVo->getLang()."' ";

        $sql .= self::addCritere($criteriaVo);

        if (!$count && $criteriaVo->getSortByElement()) {
            $sql.= " order by ".$criteriaVo->getSortByElement()." ".$criteriaVo->getSensOrderBy();
        }
        if (!$count && $criteriaVo->getLimit()) {
            $sql .= " limit " . $criteriaVo->getOffset() . "," . $criteriaVo->getLimit();
        }
        $logger = Atexo_LoggerManager::getLogger("rdvLogInfo");
        $logger->debug($sql);
        if($con === null)
        {
            $con = Propel::getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
        }
        $stmt = $con->prepare($sql);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);
        $stmt->execute();

        $results = $stmt->fetchAll ();
        if($count) {
            return $results[0]["NBRE_ELMNTS"];
        }
        $listeTypePrestation = self::getResult($results);
        $logger->debug($listeTypePrestation);
        return $listeTypePrestation;
    }

    /**
     * @param $results
     * Retourner le resultat de la requete
     */
    private function getResult($results) {
        $i = 0;
        $listsChampsSupp = array();
        foreach($results as $result)
        {
            $listsChampsSupp[$i]["ID_CHAMPS_SUPP"] = $result["ID_CHAMPS_SUPP"];
            $listsChampsSupp[$i]["LIBELLE"] = $result["LIBELLE"];
            $listsChampsSupp[$i]["CODE_CHAMPS"] = $result["CODE_CHAMPS"];
            $i++;
        }
        return $listsChampsSupp;
    }

    /**
     * @param $criteriaVo
     * Ajouter les criteres
     */
    private function addCritere($criteriaVo) {
        $sql = "";
        if($criteriaVo->getMotCle()!=null) {
            $sql .= " AND TTL1.LIBELLE like '%".addslashes($criteriaVo->getMotCle())."%'";
        }
        if($criteriaVo->getIdOrganisation()) {
            $sql .= " AND (CS.ID_ORGANISATION ='".$criteriaVo->getIdOrganisation()."')";
        }
        return $sql;
    }
}
