<?php



/**
 * Skeleton subclass for performing query and update operations on the 'T_TYPE_ETAB' table.
 *
 *
 *
 * You should add additional methods to this class to meet the
 * application requirements.  This class will only be generated as
 * long as it does not already exist in the output directory.
 *
 * @package    propel.generator.RDV
 */
class TTypeEtabPeer extends BaseTTypeEtabPeer
{
    public function getTypeEtab($lang, $idOrg, $idTypeEtab=null) {

        $sql = "SELECT typeEtab.*, TTL1.LIBELLE AS CODE_LIBELLE, TTL2.LIBELLE AS CODE_LIBELLE_ETAB
                FROM T_TYPE_ETAB typeEtab
                LEFT JOIN T_TRADUCTION_LIBELLE TTL1 ON typeEtab.CODE_LIBELLE = TTL1.ID_TRADUCTION AND TTL1.LANG = '".$lang."'
                LEFT JOIN T_TRADUCTION_LIBELLE TTL2 ON typeEtab.CODE_LIBELLE_ETAB = TTL2.ID_TRADUCTION AND TTL2.LANG = '".$lang."'
                WHERE TypeEtab.ID_ORGANISATION = $idOrg ";
        if($idTypeEtab){
            $sql .= " AND ID_TYPE_ETAB = $idTypeEtab ";
        }
        $con = Propel::getConnection(Atexo_Config::getParameter("DB_NAME").Atexo_Config::getParameter("CONST_READ_ONLY"));
        $statement = $con->prepare($sql);
        $statement->execute();
        if($idTypeEtab){
            return $statement->fetchAll(PDO::FETCH_ASSOC)[0];
        }else{
            return $statement->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}
